ANRF ARG FULL PROPOSAL -- LaTeX PACKAGE (revision 4, both investigators' CVs)
============================================================================
Title : AI-Assisted Multiphysics Wave Dynamics in Nonlocal Piezo-Semiconductor
        Smart Materials for Intelligent Sensing and Advanced Micro/Nano Systems
Ref.  : 542026006644  (ARG, Use-Inspired Basic Research, 48 months)
PI    : Dr. Vipin Gupta, Gurugram University
Co-PI : Dr. M. S. Barak, Indira Gandhi University, Meerpur
Title, investigators, duration and the seven pre-proposal objectives are unchanged.

FILE INVENTORY
--------------
ANRF_ARG_Full_Proposal.tex     Main source (OTD2_ARG1 Sections 1-11, template order)
references.bib                 BibTeX database (51 entries, all cited; unsrtnat, numeric)
figures/framework.pdf, gantt.pdf  Figures used by the proposal (vector PDF)
figures/source/*.tex           Editable figure sources (TikZ / pgfgantt standalone)
ANRF_ARG_Full_Proposal_compiled.pdf  Compiled PDF (pdfLaTeX): 20 pages, A4
ANRF_ARG_Completion_Report.txt Completion report: completed / provisional items,
                               exact fields for PI input, ANRF compliance questions,
                               page-count and template check
ANRF_ARG_Discrepancies.txt     Discrepancy list (D1-D10), incl. the Co-PI CV ANRF grant
                               vs the PI-confirmed Rs 28 lakh MATRICS project
ANRF_ARG_Compliance_Audit.txt  Audit report: findings, status table, Co-PI rule,
                               traceability, equation audit, reference verification
                               table, ML checklist, OTD checks, consistency check
README.txt                     This file

COMPILATION -- OVERLEAF (recommended)
-------------------------------------
1. Overleaf > New Project > Upload Project > select this ZIP.
2. Menu > Main document: ANRF_ARG_Full_Proposal.tex  (set it if Overleaf picks another).
3. Menu > Compiler: pdfLaTeX (default) -- XeLaTeX and LuaLaTeX also work.
4. Click Recompile. Overleaf runs BibTeX automatically. Expected: 20 pages, no errors.
Note: the figures are ready-made PDFs in figures/. Their editable sources are in
figures/source/ (standalone files; compile them separately only if you edit a figure,
then copy the resulting PDF into figures/).

COMPILATION -- LOCAL (tested with TeX Live on 11-Oct-2026)
----------------------------------------------------------
  pdflatex ANRF_ARG_Full_Proposal   (or xelatex / lualatex)
  bibtex   ANRF_ARG_Full_Proposal
  pdflatex ANRF_ARG_Full_Proposal
  pdflatex ANRF_ARG_Full_Proposal
Tested: pdfLaTeX, XeLaTeX and LuaLaTeX each give 20 pages, 0 errors, 0 undefined
references, 0 overfull boxes.

FONT NOTE (exact vs substitute)
-------------------------------
pdfLaTeX/LuaLaTeX: Times via mathptmx (Nimbus Roman). XeLaTeX: TeX Gyre Termes. Both
are Times clones shipped with TeX Live and metric-compatible with Times; neither is
literally "Times New Roman". 12 pt, single spacing. For the exact font, compile with
XeLaTeX on a system that has Times New Roman, after replacing the \setmainfont block in
the preamble with \setmainfont{Times New Roman}.

WHAT CHANGED IN REVISION 2 (details in the audit report)
--------------------------------------------------------
- Removed the suggestion to keep the budget below Rs. 1 crore. The verified Co-PI rule is
  now stated with clause references, and the decision is left to the PI.
- Physics corrections: carrier-deformation stress term removed from the base model
  (thermodynamic reciprocity); thermal carrier term redefined via dn_eq/dT; heat flux
  renamed h_i; recombination heating and KG initial data stated.
- Overclaims qualified: H1a is now a conjecture; dissipation results are restricted to
  the harmonic conduction criterion; root completeness is limited to the cases where it
  can be guaranteed; the Hutson-White formula is to be re-derived before use.
- Scope narrowed to the pre-proposal: no 2D transient solver, no PINN inverse, no drift
  gain; memory-model identifiability is exploratory. Data augmentation added (it is in
  the pre-proposal).
- ML protocol: physical-unit errors, out-of-domain detection, leave-one-material-out
  test, break-even formula.
- Section 9 now lists the HSRF project from the PI's CV. CMT impact factor verified.
- Bibliography: issue numbers added; Composite Structures DOI added; verification
  status of every entry is tabulated.

REVISION 4 (both CVs)
---------------------
- Section 7 rebuilt from both CVs: complementary-capability table (Table 5), refined
  roles, five verified JOINT publications, facilities limited to documented evidence.
- Section 9: three separate rows (PI HSRF; Co-PI MATRICS Rs 28 lakh; Co-PI CV grant
  ANRF/ARGM/2025/000711/MTR); not merged; consequence for CFP Sec C item 8 noted.
- Bibliography: 2 joint papers added; two PI-VERIFY flags cleared.
- Page count is now 20 (the OTD limit, including references; about 16.6 excluding).

REVISION 3 (completion pass)
----------------------------
- Section 9: PI's HSRF project (Rs 6 lakh) and Co-PI's MATRICS project (Rs 28 lakh)
  entered separately; Co-PI project details are placeholders.
- Hutson-White benchmark (Eq. 9) now derived from the proposal's own equations.
- CFP clauses C(8), C(9), C(10), G(1), J(5) and the MATRICS FAQ checked; open questions
  for ANRF are in the completion report, Part D.
- Breakable long tables, tighter spacing, bibliography fixes. Still 19 pages.

ITEMS REQUIRING PI ACTION
-------------------------
See ANRF_ARG_Completion_Report.txt, Part C (exact fields) and Part D (ANRF questions),
and ANRF_ARG_Discrepancies.txt.
Most important: (1) budget level vs the Co-PI-from-PI-institution rule (Sec E item 4);
(2) whether the ongoing-project clause (Sec C item 9) affects the PI's HSRF project or
the Co-PI's MATRICS project; (3) overlap statements in Section 9.

PAGE LIMIT
----------
OTD: max 20 pages INCLUDING bibliography; CFP Sec J item 5: 20 pages EXCLUDING
references. Current: 20 pages including references (about 16.6 excluding), with about
0.4 page free on page 20. Replacing placeholders with short values (IFs, amounts,
dates) should shorten the PDF. Re-check the count after every edit.
