clc
clear
close all

rho3=2650;
rho2=1180;
rho1=7.14*10^3;
c0=6.785*10^10;
c442=1.43*10^9;
mu=0.508*10^11;
s441=1/mu;
s442=1/c442;
s0=1/c0;
a=1e-2;
b=2e-2;
c=3e-2;
tau=0.5*10^-13;
K=1.24*10^2;
Cv=3.9*10^2;
ka=10^12;
kb=10^13;
tau0=110;
mus=8*10^3;

c_t=sqrt(mu/rho1);

fp=1*10^6;

omp=2*pi*fp;   % sirf 100 kHz
f=linspace(70e3,200e3,30);
om=2*pi*f;
k=linspace(0,400,30);
%F=s443(x)

D=zeros(length(k),length(f));
for j=1:length(k)
  
for n=1:length(om)
    km=k(j);
jhi=km*b;

  omm=om(j);  

 
s443=s0*(1-omp^2./omm.^2);

alpha=a/b;
beta=c/b;
ohm=omm*b*sqrt(rho2*s442);
mustar=mu/(b*s442);
 kastar=(ka*b)/s442;
 kbstar=(kb*b)/s442;
 m1=s441/s442;
m3=s443/s442;
taunotestar=tau0/(b.*s442);
musstar=(mus.*s442)./(b);
alpha1star=sqrt((jhi.^2./b.^2)-(rho1.*Cv./rho2).*sqrt(1/rho2.*s442).*(i*ohm./(K*b))-(rho1*tau.*ohm.^2)/(rho2.*s442.*K.*b^2));

gamma1star=sqrt(jhi.^2-(rho1/rho2).*(ohm.^2/m1));
gamma2star=sqrt(jhi.^2-ohm.^2);
gamma3star=sqrt(jhi.^2-(rho3/rho2).*(ohm.^2./m3));

 %%% dispersion function F(K)=0
size(besseli(0,alpha1star*alpha));
A11=2*(m1/s442)*(gamma1star./b).*besseli(2,alpha*gamma1star);
A12=(-1/s442)*(gamma2star./b).*besseli(2,alpha*gamma2star);
A13=(1/s442)*(gamma2star./b).*besselk(2,alpha*gamma2star);
A21=2*(m1/s442)*(gamma1star./b).*besseli(2,alpha*gamma1star)+(kastar./(s442*b)).*besseli(1,alpha*gamma1star);
A22=-(kastar/(s442*b)).*besseli(1,alpha*gamma2star);
A23= -(kastar./(s442*b)).*besselk(1,alpha*gamma2star);
A32=(gamma2star./(b*s442)).*besseli(2,gamma2star);
A33=-(gamma2star/b*s442).*besselk(2,gamma2star);
A34=((-gamma3star.*m3)./(b*s442)).*besseli(2,gamma3star);
A35=((-gamma3star.*m3)./(b*s442)).*besselk(2,gamma3star);
A42=(gamma2star./(b*s442)).*besseli(2,gamma2star)+(kbstar/(b*s442)).*besseli(1,gamma2star);
A43=-(gamma2star./(b*s442)).*besselk(2,gamma2star)+(kbstar/(b*s442)).*besselk(1,gamma2star);
A44=-(kbstar/(b*s442)).*besseli(1,gamma3star);
A45=-(kbstar/(b*s442)).*besselk(1,gamma3star);
A54=(m3.*gamma3star)./(b.*s442).*besseli(2,beta.*gamma3star)+(musstar./s442).*(jhi.^2/b).*besseli(1,beta.*gamma3star)-(taunotestar/(beta*b*s442))*gamma3star.*besseli(2,beta.*gamma3star);
A55=(-m3./(b*s442)).*gamma3star.*besselk(2,beta*gamma3star)+(musstar/s442)*(jhi.^2/b).*besselk(1,beta.*gamma3star)+(taunotestar/(beta*b*s442))*gamma3star.*besselk(2,beta.*gamma3star);
A66=besseli(0,alpha1star*alpha);
%size(A11)
%size(A12)
%size(A13)
%size(A21)
%size(A22)
%size(A23)
%size(A32)
%size(A33)
%size(A34)
%size(A35)
%size(A42)
%size(A43)
%size(A44)
%size(A45)
%size(A54)
%size(A55)
%size(A66)
M=[A11 A12 A13 0 0 0; A21 A22 A23 0 0 0; 0 A32 A33 A34 A35 0; 0 A42 A43 A44 A45 0; 0 0 0 A54 A55 0; 0 0 0 0 0 A66];
D(j,n)=abs(det(M))
end
end
%end


