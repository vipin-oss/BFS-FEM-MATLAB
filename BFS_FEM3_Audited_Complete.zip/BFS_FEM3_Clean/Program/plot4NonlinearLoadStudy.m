function figs = plot4NonlinearLoadStudy(study)
%PLOT4NONLINEARLOADSTUDY SCI-style plots for Study 04.
%
%   figs = plot4NonlinearLoadStudy(study4)
%
% Fig05: nonlinear load--tip displacement curves.
% Fig06: coloured/overlaid deformed meshes.
% Fig07: coloured finite-strain fields E11, E12, and |Grad(E)|.
% No automatic file export is performed.

assert(isstruct(study) && isfield(study, 'results') && isfield(study, 'ellList'), ...
    'plot4NonlinearLoadStudy:invalid Study-4 result struct.');

ellList = study.ellList(:).';
colors = [0.0000 0.4470 0.7410; ...
          0.8500 0.3250 0.0980; ...
          0.4660 0.6740 0.1880];
markers = {'o', 's', '^'};
ellLabels = cell(1, numel(ellList));
for ie = 1:numel(ellList)
    ellLabels{ie} = ['$\ell/H=', num2str(ellList(ie)/study.opts.H, '%.2g'), '$'];
end

% =====================================================================
% Fig05: load--deflection curves.
% =====================================================================
figLoad = figure('Name', 'Fig05_Optional_NonlinearLoadDeflection', ...
    'Color', 'w', 'Position', [100 100 850 560]);
axLoad = axes(figLoad); hold(axLoad, 'on'); grid(axLoad, 'on'); box(axLoad, 'on');
hLoad = gobjects(1, numel(ellList));

for ie = 1:numel(ellList)
    item = study.results{ie};
    sol = item.solution;
    hLoad(ie) = plot(axLoad, item.tipDisplacement/study.opts.H, ...
        item.resultantForce/(study.opts.E*study.opts.H*study.opts.thickness), ...
        ['-' markers{1 + mod(ie - 1, numel(markers))}], ...
        'Color', colors(1 + mod(ie - 1, size(colors, 1)), :), ...
        'MarkerFaceColor', 'w', 'LineWidth', 1.8, 'MarkerSize', 5);
end

xlabel(axLoad, '$u_{\mathrm{tip}}/H$', 'Interpreter', 'latex');
ylabel(axLoad, '$F_{\mathrm{end}}/(EHt)$', 'Interpreter', 'latex');
title(axLoad, 'Nonlinear load--tip displacement response', ...
    'Interpreter', 'latex', 'FontWeight', 'normal');
legend(axLoad, hLoad, ellLabels, 'Interpreter', 'latex', ...
    'FontSize', 9, 'Box', 'on', 'Location', 'southoutside', ...
    'Orientation', 'horizontal');
applyStyle(figLoad);

% =====================================================================
% Fig06: deformed meshes, one panel per length scale.
% =====================================================================
figMesh = figure('Name', 'Fig05_Optional_DeformedMeshes', ...
    'Color', 'w', 'Position', [120 120 1180 420]);
tlMesh = tiledlayout(figMesh, 1, numel(ellList), ...
    'Padding', 'compact', 'TileSpacing', 'compact');

for ie = 1:numel(ellList)
    item = study.results{ie};
    sol = item.solution;
    ax = nexttile(tlMesh, ie); hold(ax, 'on'); box(ax, 'on'); axis(ax, 'equal');

    mesh = sol.mesh;
    patch(ax, 'Faces', mesh.connect, 'Vertices', mesh.X, ...
        'FaceColor', 'none', 'EdgeColor', [0.55 0.55 0.55], ...
        'LineStyle', ':', 'LineWidth', 0.7);
    patch(ax, 'Faces', mesh.connect, 'Vertices', item.deformedNodes, ...
        'FaceColor', 'none', 'EdgeColor', colors(1 + mod(ie - 1, size(colors, 1)), :), ...
        'LineWidth', 1.0);

    xlabel(ax, '$X_1/H$', 'Interpreter', 'latex');
    ylabel(ax, '$X_2/H$', 'Interpreter', 'latex');
    title(ax, ['$\ell/H=' num2str(item.ellOverH, '%.2g') '$'], ...
        'Interpreter', 'latex', 'FontWeight', 'normal');
    applyAxisStyle(ax);
end

% =====================================================================
% Fig07: finite-strain fields.  Compare classical ell=0 and strongest
% converged gradient case, avoiding an unnecessarily crowded 3x3 panel.
% =====================================================================
classicalIndex = find(ellList == 0, 1, 'first');
gradientIndex = numel(ellList);
selected = [classicalIndex, gradientIndex];
fieldNames = {'E_{11}', 'E_{12}', 'H|\mathcal{G}|'};

fieldData = cell(1, numel(selected));
allValues = cell(1, 3);
for k = 1:numel(selected)
    fieldData{k} = elementFields(study.results{selected(k)}.solution);
    allValues{1} = [allValues{1}; fieldData{k}.E11]; %#ok<AGROW>
    allValues{2} = [allValues{2}; fieldData{k}.E12]; %#ok<AGROW>
    allValues{3} = [allValues{3}; study.opts.H*fieldData{k}.Gnorm]; %#ok<AGROW>
end

figField = figure('Name', 'Fig05_FiniteStrainFields', ...
    'Color', 'w', 'Position', [140 140 1180 650]);
tlField = tiledlayout(figField, 2, 3, 'Padding', 'compact', 'TileSpacing', 'compact');

for k = 1:numel(selected)
    item = study.results{selected(k)};
    sol = item.solution;
    values = {fieldData{k}.E11, fieldData{k}.E12, study.opts.H*fieldData{k}.Gnorm};
    
    for f = 1:3
        ax = nexttile(tlField, (k - 1)*3 + f); hold(ax, 'on'); axis(ax, 'equal');
        patch(ax, 'Faces', sol.mesh.connect, 'Vertices', item.deformedNodes, ...
            'FaceVertexCData', values{f}, 'FaceColor', 'flat', ...
            'EdgeColor', [0.35 0.35 0.35], 'LineWidth', 0.25);
        colormap(ax, parula(256));
        cb = colorbar(ax);
        cb.TickLabelInterpreter = 'latex';
        ylabel(cb, ['$' fieldNames{f} '$'], 'Interpreter', 'latex');
        caxis(ax, [min(allValues{f}), max(allValues{f})]);
        xlabel(ax, '$x_1/H$', 'Interpreter', 'latex');
        ylabel(ax, '$x_2/H$', 'Interpreter', 'latex');
        title(ax, ['$\ell/H=' num2str(item.ellOverH, '%.2g') ',\ ' fieldNames{f} '$'], ...
            'Interpreter', 'latex', 'FontWeight', 'normal');
        applyAxisStyle(ax);
    end
end

figs = struct('loadDeflection', figLoad, 'deformedMeshes', figMesh, ...
              'fields', figField);

end

% =====================================================================
% Field recovery at element centres.
% =====================================================================
function fields = elementFields(sol)
mesh = sol.mesh;
dof = sol.dof;
D = sol.D(:, end);
fields.E11 = zeros(mesh.nElem, 1);
fields.E12 = zeros(mesh.nElem, 1);
fields.Gnorm = zeros(mesh.nElem, 1);

for e = 1:mesh.nElem
    eg = mesh.elemGeom(e);
    de = D(dof.elemDOF(e, :));
    dN = bfsShapeFunctionDerivatives(0, 0, eg.h1, eg.h2);
    s1 = 2/eg.h1; s2 = 2/eg.h2;
    s11 = s1*s1; s22 = s2*s2; s12 = s1*s2;

    gradU = zeros(2, 2);
    H = zeros(2, 2, 2);
    gradU(1, 1) = s1*dN.dNdxi(1, 1:16)*de(1:16);
    gradU(1, 2) = s2*dN.dNdeta(1, 1:16)*de(1:16);
    gradU(2, 1) = s1*dN.dNdxi(2, 17:32)*de(17:32);
    gradU(2, 2) = s2*dN.dNdeta(2, 17:32)*de(17:32);
    H(1, 1, 1) = s11*dN.d2Ndxi2(1, 1:16)*de(1:16);
    H(1, 2, 2) = s22*dN.d2Ndeta2(1, 1:16)*de(1:16);
    H(1, 1, 2) = s12*dN.d2Ndxideta(1, 1:16)*de(1:16);
    H(1, 2, 1) = H(1, 1, 2);
    H(2, 1, 1) = s11*dN.d2Ndxi2(2, 17:32)*de(17:32);
    H(2, 2, 2) = s22*dN.d2Ndeta2(2, 17:32)*de(17:32);
    H(2, 1, 2) = s12*dN.d2Ndxideta(2, 17:32)*de(17:32);
    H(2, 2, 1) = H(2, 1, 2);

    F = eye(2) + gradU;
    E = 0.5*(F.'*F - eye(2));
    G = zeros(2, 2, 2);
    for I = 1:2
        for J = 1:2
            for K = 1:2
                for m = 1:2
                    G(I, J, K) = G(I, J, K) + 0.5*( ...
                        H(m, I, K)*F(m, J) + F(m, I)*H(m, J, K));
                end
            end
        end
    end

    fields.E11(e) = E(1, 1);
    fields.E12(e) = E(1, 2);
    fields.Gnorm(e) = norm(G(:));
end
end

function applyStyle(fig)
axesList = findall(fig, 'Type', 'axes');
for k = 1:numel(axesList)
    if ~isa(axesList(k), 'matlab.graphics.illustration.ColorBar')
        applyAxisStyle(axesList(k));
    end
end
end

function applyAxisStyle(ax)
set(ax, 'FontName', 'Times New Roman', 'FontSize', 10, ...
    'LineWidth', 0.8, 'TickLabelInterpreter', 'latex', 'Layer', 'top');
end
