%% strain_gradient_bar_1d_FEM.m
%
% 1D strain-gradient bar FEM using C1 Hermite elements
%
% Model energy:
%   U = 1/2 * int_0^L EA [ (u')^2 + ell_g^2 (u'')^2 ] dx
%
% where ell_g^2 = l^2/10 according to the formulation.
%
% Governing equation for constant EA, static case:
%   EA*u'' - EA*ell_g^2*u'''' + q = 0
%
% DOFs per node:
%   d_i = [ u_i ; theta_i ], where theta_i = du/dx at node i
%
% Element DOFs:
%   d_e = [u1 theta1 u2 theta2]^T
%
% Boundary-condition examples included:
%   bc_case = "natural_slope" : u(0)=0 only; slope DOFs are free.
%                               This gives the classical linear solution
%                               for pure end-force loading because u''=0.
%   bc_case = "clamped_slope" : u(0)=0 and theta(0)=0.
%                               This imposes an additional higher-order
%                               essential condition and produces a boundary
%                               layer / size effect.
%   Right end: applied axial force F at u(L).
%   Natural higher-order boundary conditions are automatically satisfied
%   at unconstrained slope DOFs.

clear; clc; close all;

% ── AUDIT FIX 6: Reset root defaults — guard against environment contamination ──
% Ensures Times New Roman and 'tex' interpreter are active regardless of any
% residual settings left by previous MATLAB sessions or other scripts.
set(groot, 'defaultAxesFontName',             'Times New Roman');
set(groot, 'defaultAxesFontSize',             10);
set(groot, 'defaultTextFontName',             'Times New Roman');
set(groot, 'defaultTextFontSize',             10);
set(groot, 'defaultAxesTickLabelInterpreter', 'tex');
set(groot, 'defaultTextInterpreter',          'tex');

%% ==================== Input data ====================

L       = 1.0;          % bar length
E       = 200e9;        % Young's modulus
Area    = 1.0e-4;       % cross-sectional area
rho     = 7800;         % density, only used if dynamic mass matrix needed
l_micro = 0.05;         % ellipsoidal/spherical neighborhood length l
ell2    = l_micro^2/10; % effective strain-gradient parameter l_eff^2 = l^2/10
nel     = 100;          % number of Hermite elements
                        % For clamped_slope, boundary layer length is
                        % a = sqrt(ell2). Use element size Le << a.
nn      = nel + 1;      % number of nodes
ndof    = 2*nn;         % 2 DOFs per node: displacement and slope

F_tip   = 1.0e4;        % axial point load at right end, N
q0      = 0.0;          % uniform distributed axial load, N/m

% Choose boundary-condition case:
% "natural_slope" : only u(0)=0 is prescribed; slope DOFs are natural/free.
% "clamped_slope" : u(0)=0 and u'(0)=0 are prescribed.
bc_case = "clamped_slope";

%% ==================== Mesh ====================

xnode = linspace(0,L,nn).';
conn  = [(1:nel).' (2:nel+1).'];

%% ==================== Global matrices ====================

K = zeros(ndof,ndof);
M = zeros(ndof,ndof);   % optional consistent mass matrix
F = zeros(ndof,1);

% Gauss integration points
% Cubic Hermite: B1 terms are quadratic, B2 terms linear.
% 3-point Gauss is sufficient for stiffness and consistent load.
gauss_xi = [-sqrt(3/5), 0, sqrt(3/5)];
gauss_w  = [5/9, 8/9, 5/9];

for e = 1:nel

    n1 = conn(e,1);
    n2 = conn(e,2);
    xe = [xnode(n1), xnode(n2)];
    Le = xe(2)-xe(1);

    ke = zeros(4,4);
    me = zeros(4,4);
    fe = zeros(4,1);

    for gp = 1:length(gauss_xi)

        xi = gauss_xi(gp);       % parent coordinate in [-1,1]
        w  = gauss_w(gp);
        s  = (xi+1)/2;           % local coordinate in [0,1]
        J  = Le/2;               % dx/dxi

        [N, B1, B2] = hermite_shape_1d(s,Le);

        % Stiffness: int EA [B1^T B1 + ell2 B2^T B2] dx
        ke = ke + E*Area*(B1.'*B1 + ell2*(B2.'*B2))*J*w;

        % Optional consistent translational mass: int rho*A N^T N dx
        % Note: This includes slope DOFs because Hermite interpolation is used.
        me = me + rho*Area*(N.'*N)*J*w;

        % Consistent distributed load: int N^T q dx
        fe = fe + N.'*q0*J*w;

    end

    % Global DOF map: node i -> [2*i-1, 2*i]
    edofs = [2*n1-1, 2*n1, 2*n2-1, 2*n2];

    K(edofs,edofs) = K(edofs,edofs) + ke;
    M(edofs,edofs) = M(edofs,edofs) + me;
    F(edofs)       = F(edofs) + fe;

end

%% ==================== External point load ====================

% Apply axial force at right-end displacement DOF.
right_u_dof = 2*nn - 1;
F(right_u_dof) = F(right_u_dof) + F_tip;

%% ==================== Essential boundary conditions ====================

% Node 1 DOFs are:
%   DOF 1 = u(0)
%   DOF 2 = theta(0)=u'(0)
%
% For most validation tests, "natural_slope" is recommended because the
% higher-order boundary condition is then natural/free. For observing a
% clear strain-gradient boundary-layer effect, use "clamped_slope".

switch bc_case
    case "natural_slope"
        fixed_dofs = 1;        % u(0)=0 only
        fixed_vals = 0;
    case "clamped_slope"
        fixed_dofs = [1, 2];   % u(0)=0 and theta(0)=0
        fixed_vals = [0, 0];
    otherwise
        error('Unknown bc_case. Use "natural_slope" or "clamped_slope".');
end

all_dofs  = 1:ndof;
free_dofs = setdiff(all_dofs,fixed_dofs);

% Partition solution
D = zeros(ndof,1);
D(fixed_dofs) = fixed_vals;
F_eff = F(free_dofs) - K(free_dofs,fixed_dofs)*D(fixed_dofs);
D(free_dofs) = K(free_dofs,free_dofs)\F_eff;

%% ==================== Reactions ====================

R = K*D - F;

%% ==================== Post-processing ====================

u_node     = D(1:2:end);
theta_node = D(2:2:end);

fprintf('\n===== 1D Strain-Gradient Bar FEM =====\n');
fprintf('Number of elements       = %d\n', nel);
fprintf('BC case                  = %s\n', bc_case);
fprintf('L                         = %.6g m\n', L);
fprintf('E                         = %.6g Pa\n', E);
fprintf('Area                      = %.6g m^2\n', Area);
fprintf('micro length l            = %.6g m\n', l_micro);
fprintf('effective ell_g^2=l^2/10  = %.6g m^2\n', ell2);
fprintf('Tip displacement u(L)     = %.12e m\n', u_node(end));
fprintf('Tip slope theta(L)        = %.12e\n', theta_node(end));
fprintf('Left reaction force       = %.12e N\n', R(1));
fprintf('Left higher-order reaction= %.12e N*m approx.\n', R(2));

% Classical bar solution for comparison under end force: u = F*x/(EA)
u_classical_tip = F_tip*L/(E*Area);
fprintf('Classical tip displacement= %.12e m\n', u_classical_tip);
fprintf('Ratio SG/Classical        = %.12e\n', u_node(end)/u_classical_tip);

% Analytical check for q0=0 and pure tip load
if abs(q0) < 1e-14
    a = sqrt(ell2);
    switch bc_case
        case "natural_slope"
            u_exact_tip = F_tip*L/(E*Area);
        case "clamped_slope"
            % Exact solution with u(0)=0, u'(0)=0, M(L)=EA*a^2*u''(L)=0,
            % and N(L)=EA*(u' - a^2*u''')=F_tip:
            % u(L) = (F/EA)*(L - a*tanh(L/a))
            u_exact_tip = (F_tip/(E*Area))*(L - a*tanh(L/a));
    end
    fprintf('Exact SG tip displacement = %.12e m\n', u_exact_tip);
    fprintf('FE error vs exact SG      = %.12e %%\n', ...
            100*abs(u_node(end)-u_exact_tip)/abs(u_exact_tip));
end


%% =========================================================================
%%  PUBLICATION-QUALITY FIGURE — CORRECTED VERSION v2
%%
%%  Audit issues resolved:
%%    Issue 1 (CRITICAL)  : PaperPositionMode='manual' added in exportFig
%%    Issue 2 (MODERATE)  : Interpreter switched 'latex'→'tex' throughout
%%                          FontName='Times New Roman' now takes effect
%%                          Type 3 font risk eliminated
%%    Issue 3 (Minor)     : tiledlayout() called without fig handle argument
%%    Issue 4 (Minor)     : MS variable removed (no markers in this figure)
%%    Issue 5 (Minor)     : ylim uses data-driven margins (robust to bc_case)
%%    Issue 6 (Minor)     : groot defaults set at top of script
%%    Issue 7 (Moderate)  : Resolved via Issue 2 fix (tex interpreter)
%%
%%  INSERT LOCATION:
%%    Immediately after the post-processing fprintf block above.
%%    Immediately before the local function definitions at the bottom.
%%
%%  DO NOT modify any variable computed above this block.
%% =========================================================================

% ── Unit conversion ───────────────────────────────────────────────────────
%
%  Displacement: u_node is in metres.
%    u_node(end) ≈ 4.921×10⁻⁴ m = 492.1 µm  (clamped_slope, l=0.05 m).
%    Converting to µm gives clean axis values (0–500 range) and removes
%    the ×10⁻⁴ exponent that MATLAB would otherwise place on the y-axis.
%
%  Slope: theta_node is dimensionless (strain, m/m).
%    Values range from 0 to ~5×10⁻⁴.
%    Multiplying by 1×10⁴ gives 0–5 range; label states (×10⁻⁴).
%    Physical meaning is preserved: θ_actual = θ_displayed × 10⁻⁴.
%
%  No normalisation is introduced. These are unit-scaling transforms only.
%
u_plot     = u_node     * 1e6;   % metres → micrometres (µm)
theta_plot = theta_node * 1e4;   % m/m    → ×10⁻⁴  (dimensionless)

xnorm = xnode / L;               % spatial coordinate x/L  (dimensionless)

% ── Colour (Wong 2011 colorblind-safe palette, entry 1) ───────────────────
C_blue = [0.000, 0.447, 0.698];

% ── Line width constant ───────────────────────────────────────────────────
LW = 1.5;   % primary line width (pt) — per journal style guide

% ── Figure creation — exact paper dimensions ─────────────────────────────
%  176 mm × 72 mm = double-column figure for AMM / CMAME / IJES.
fig_w_mm = 176;
fig_h_mm =  72;

fig = figure('Color', 'white', ...
             'Units', 'centimeters', ...
             'Position', [2, 2, fig_w_mm/10, fig_h_mm/10]);

% ── Two-panel tiled layout ────────────────────────────────────────────────
% ISSUE 3 FIXED: tiledlayout called without fig handle — uses current figure
% (fig is current figure immediately after the figure() call above).
tl = tiledlayout(1, 2, ...
    'TileSpacing', 'compact', ...
    'Padding',     'compact');

% =========================================================================
%  Panel (a) — Axial displacement field u(x)
% =========================================================================
ax1 = nexttile(tl, 1);

plot(ax1, xnorm, u_plot, ...
    'Color',     C_blue, ...
    'LineStyle', '-', ...
    'LineWidth', LW);

% Apply uniform axis style (Times New Roman 10 pt, box, inward ticks, grid)
styleAxes(ax1);

% Axis labels
% ISSUE 2 FIXED: Interpreter='tex' — FontName='Times New Roman' is respected.
% With 'tex': \mu renders as µ; tick labels also use Times New Roman.
xlabel(ax1, 'x/L', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

ylabel(ax1, 'u(x) (\mum)', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

% Axis limits
% ISSUE 5 FIXED: margin derived from data range — robust to bc_case changes.
u_margin = (max(u_plot) - min(u_plot)) * 0.08;
xlim(ax1, [0, 1]);
ylim(ax1, [min(u_plot) - u_margin,  max(u_plot) + u_margin]);

% Panel label (a) — upper-left corner, 11 pt bold, Times New Roman
text(ax1, 0.04, 0.93, '(a)', ...
    'Units',      'normalized', ...
    'FontName',   'Times New Roman', ...
    'FontSize',   11, ...
    'FontWeight', 'bold', ...
    'Interpreter','none');

% =========================================================================
%  Panel (b) — Slope field θ(x) = du/dx
% =========================================================================
ax2 = nexttile(tl, 2);

plot(ax2, xnorm, theta_plot, ...
    'Color',     C_blue, ...
    'LineStyle', '-', ...
    'LineWidth', LW);

styleAxes(ax2);

% ISSUE 2 FIXED: Interpreter='tex'
xlabel(ax2, 'x/L', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

% Note on ylabel string:
%   \theta renders the Greek letter θ in 'tex' interpreter.
%   \times renders ×.
%   The label reads: θ(x) = du/dx  (×10⁻⁴)
%   Physical meaning: displayed value × 10⁻⁴ = actual du/dx (dimensionless).
ylabel(ax2, '\theta(x) = du/dx   (\times10^{-4})', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

% Axis limits
% ISSUE 5 FIXED: margin from data range.
theta_margin = (max(theta_plot) - min(theta_plot)) * 0.08;
xlim(ax2, [0, 1]);
ylim(ax2, [min(theta_plot) - theta_margin,  max(theta_plot) + theta_margin]);

% Panel label (b)
text(ax2, 0.04, 0.93, '(b)', ...
    'Units',      'normalized', ...
    'FontName',   'Times New Roman', ...
    'FontSize',   11, ...
    'FontWeight', 'bold', ...
    'Interpreter','none');

% ── Export ────────────────────────────────────────────────────────────────
exportFig(fig, 'Fig02_1D_disp_slope', fig_w_mm, fig_h_mm);

%% =========================================================================
%%  END OF PUBLICATION-QUALITY FIGURE BLOCK
%% =========================================================================


%% ==================== Local functions ====================

% ─────────────────────────────────────────────────────────────────────────
function styleAxes(ax)
% styleAxes  Apply uniform publication axis style.
%
%   Configures: Times New Roman 10 pt ticks, box on, inward ticks,
%   dotted grid (alpha 0.35), no minor grid, axis line width 0.8 pt.
%
%   AUDIT v2: TickLabelInterpreter changed from 'latex' to 'tex'.
%   With 'latex', MATLAB's LaTeX engine ignores FontName and uses
%   Computer Modern. With 'tex', FontName='Times New Roman' takes effect.
% ─────────────────────────────────────────────────────────────────────────
set(ax, ...
    'FontName',             'Times New Roman', ...
    'FontSize',             10, ...
    'LineWidth',            0.8, ...
    'Box',                  'on', ...
    'TickDir',              'in', ...
    'TickLength',           [0.015, 0.015], ...
    'XMinorTick',           'off', ...
    'YMinorTick',           'off', ...
    'GridLineStyle',        ':', ...
    'GridAlpha',            0.35, ...
    'MinorGridLineStyle',   'none', ...
    'TickLabelInterpreter', 'tex');     % FIXED: was 'latex' — now 'tex'
grid(ax, 'on');
end


% ─────────────────────────────────────────────────────────────────────────
function exportFig(figHandle, filename, width_mm, height_mm)
% exportFig  Export figure to EPS (vector), PDF (vector), PNG (600 dpi).
%
%   INPUTS
%     figHandle  — handle from figure()
%     filename   — base filename without extension
%     width_mm   — figure width  in millimetres (e.g. 176 for double-column)
%     height_mm  — figure height in millimetres (e.g.  72)
%
%   AUDIT v2 — CRITICAL FIX:
%     PaperPositionMode set to 'manual' BEFORE PaperPosition.
%     Without this, MATLAB's default 'auto' mode overrides PaperPosition,
%     placing the figure centered on the paper and adding white borders.
%     With 'manual', PaperPosition [0,0,w,h] is respected exactly.
% ─────────────────────────────────────────────────────────────────────────

% Force vector renderer — required for EPS/PDF vector output
set(figHandle, 'Renderer', 'painters');

w_cm = width_mm  / 10;
h_cm = height_mm / 10;

set(figHandle, 'Units',             'centimeters');
set(figHandle, 'Position',          [2, 2, w_cm, h_cm]);
set(figHandle, 'PaperUnits',        'centimeters');
set(figHandle, 'PaperPositionMode', 'manual');          % ← CRITICAL FIX
set(figHandle, 'PaperSize',         [w_cm, h_cm]);
set(figHandle, 'PaperPosition',     [0, 0, w_cm, h_cm]);

% EPS — colour vector (primary submission format)
print(figHandle, [filename, '.eps'], '-depsc', '-r0');

% PDF — vector (backup / supplementary)
print(figHandle, [filename, '.pdf'], '-dpdf',  '-r0');

% PNG — 600 dpi raster (online review / graphical abstract)
print(figHandle, [filename, '.png'], '-dpng',  '-r600');

fprintf('\n[exportFig] Saved  : %s  (.eps / .pdf / .png)\n', filename);
fprintf('[exportFig] Size   : %.0f x %.0f mm\n', width_mm, height_mm);
fprintf('[exportFig] Verify : open %s.eps — confirm no Type 3 fonts\n\n', filename);
end


% ─────────────────────────────────────────────────────────────────────────
function [N, B1, B2] = hermite_shape_1d(s, Le)
% Cubic Hermite shape functions on s in [0,1]
% DOFs: [u1, theta1, u2, theta2]
% u(s) = N1*u1 + N2*theta1 + N3*u2 + N4*theta2
% theta has dimension du/dx, so N2 and N4 include Le.

    % Shape functions
    N1 = 1 - 3*s^2 + 2*s^3;
    N2 = Le*(s - 2*s^2 + s^3);
    N3 = 3*s^2 - 2*s^3;
    N4 = Le*(-s^2 + s^3);
    N  = [N1, N2, N3, N4];

    % First derivatives wrt s
    dN1_ds =  -6*s + 6*s^2;
    dN2_ds =  Le*(1 - 4*s + 3*s^2);
    dN3_ds =   6*s - 6*s^2;
    dN4_ds =  Le*(-2*s + 3*s^2);

    % d/dx = (1/Le) d/ds
    B1 = (1/Le)*[dN1_ds, dN2_ds, dN3_ds, dN4_ds];

    % Second derivatives wrt s
    d2N1_ds2 =  -6 + 12*s;
    d2N2_ds2 =  Le*(-4 + 6*s);
    d2N3_ds2 =   6 - 12*s;
    d2N4_ds2 =  Le*(-2 + 6*s);

    % d2/dx2 = (1/Le^2) d2/ds2
    B2 = (1/Le^2)*[d2N1_ds2, d2N2_ds2, d2N3_ds2, d2N4_ds2];

end
