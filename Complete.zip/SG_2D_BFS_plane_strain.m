%% SG_2D_BFS_plane_strain.m
% 2D plane-strain strain-gradient elasticity using C1 Bogner-Fox-Schmit
% bicubic Hermite rectangular finite elements.
%
% Model:
%   W = 1/2 eps^T C eps + 1/2 a^2[(eps_x)^T C eps_x + (eps_y)^T C eps_y]
% where
%   a^2 = l_micro^2/10.
%
% DOFs per node:
%   [u, u_x, u_y, u_xy, v, v_x, v_y, v_xy]
%
% This is the natural 2D extension of the 1D Hermite code. It uses C1
% rectangular elements, so second derivatives of displacement are available.
%
% Example problem:
%   Rectangular plate/bar under plane strain.
%   Left edge: strain-gradient clamped, all Hermite DOFs set to zero.
%   Right edge: uniform horizontal traction tx.
%
% NOTE:
%   This code is intended as the first clean 2D validation framework.
%   Use rectangular domains/meshes. For arbitrary geometries, IGA or a
%   mixed C0 formulation is recommended.

clear; clc; close all;

%% -------------------- Input data --------------------
Lx = 1.0;             % length in x-direction, m
Ly = 0.20;            % height in y-direction, m
E  = 200e9;           % Young's modulus, Pa
nu = 0.30;            % Poisson's ratio
thickness = 1.0;      % out-of-plane thickness for 2D model

l_micro = 0.05;       % microstructural length l, m
a2 = l_micro^2/10;   % effective strain-gradient length squared

nelx = 20;            % elements in x direction
nely = 4;             % elements in y direction

traction_right = [1.0e6; 0.0];  % [tx; ty] Pa = N/m^2, applied on right edge
body_force = [0.0; 0.0];        % [bx; by] N/m^3, optional

bc_case = "clamped_gradient";
% "clamped_gradient" : all Hermite DOFs are fixed on the left edge.
% "classical_clamp"  : only u and v are fixed on the left edge.

%% -------------------- Material matrix: plane strain --------------------
lambda = E*nu/((1+nu)*(1-2*nu));
mu     = E/(2*(1+nu));
C = [lambda+2*mu, lambda,      0;
     lambda,      lambda+2*mu, 0;
     0,           0,           mu];

%% -------------------- Mesh --------------------
nnx = nelx + 1;
nny = nely + 1;
nnode = nnx*nny;
ndof_per_node = 8;
ndof = ndof_per_node*nnode;

xgrid = linspace(0,Lx,nnx);
ygrid = linspace(0,Ly,nny);

% node number function, with ix=1..nnx, iy=1..nny.
% IMPORTANT: the coordinates must follow the same numbering convention,
% i.e., x-index varies fastest. Do not use [X(:),Y(:)] from meshgrid here,
% because MATLAB column-major ordering would make the y-index vary fastest
% and would give hx=0 for many elements.
node_id = @(ix,iy) (iy-1)*nnx + ix;
coords = zeros(nnode,2);
for iy = 1:nny
    for ix = 1:nnx
        n = node_id(ix,iy);
        coords(n,:) = [xgrid(ix), ygrid(iy)];
    end
end

% Element connectivity: [bottom-left, bottom-right, top-right, top-left]
conn = zeros(nelx*nely,4);
e = 0;
for ey = 1:nely
    for ex = 1:nelx
        e = e + 1;
        n1 = node_id(ex,ey);
        n2 = node_id(ex+1,ey);
        n3 = node_id(ex+1,ey+1);
        n4 = node_id(ex,ey+1);
        conn(e,:) = [n1 n2 n3 n4];
    end
end
nel = size(conn,1);

%% -------------------- Assembly --------------------
K = sparse(ndof,ndof);
F = zeros(ndof,1);

% 4-point Gauss on [0,1]
[gp, gw] = gauss_1d_01(4);

for e = 1:nel
    nodes = conn(e,:);
    xy = coords(nodes,:);
    hx = xy(2,1) - xy(1,1);
    hy = xy(4,2) - xy(1,2);
    if hx <= 0 || hy <= 0
        error('Invalid element geometry at element %d: hx=%g, hy=%g. Check node numbering.', e, hx, hy);
    end
    detJ = hx*hy;

    Ke = zeros(32,32);
    Fe = zeros(32,1);

    for ig = 1:length(gp)
        s = gp(ig);
        ws = gw(ig);
        for jg = 1:length(gp)
            t = gp(jg);
            wt = gw(jg);
            wgt = ws*wt*detJ*thickness;

            [N, Nx, Ny, Nxx, Nyy, Nxy] = bfs_shape_2d(s,t,hx,hy);
            [B, Bx, By, Nv] = make_B_matrices(N,Nx,Ny,Nxx,Nyy,Nxy);

            Ke = Ke + (B.'*C*B + a2*(Bx.'*C*Bx + By.'*C*By))*wgt;

            % Body force contribution: int Nv^T b dOmega
            bvec = body_force;
            Fe = Fe + Nv.'*bvec*wgt;
        end
    end

    edofs = element_dofs(nodes,ndof_per_node);
    K(edofs,edofs) = K(edofs,edofs) + Ke;
    F(edofs) = F(edofs) + Fe;
end

%% -------------------- Right-edge traction --------------------
% Consistent edge load on elements at ex=nelx.
for ey = 1:nely
    e_right = (ey-1)*nelx + nelx;
    nodes = conn(e_right,:);
    xy = coords(nodes,:);
    hx = xy(2,1) - xy(1,1);
    hy = xy(4,2) - xy(1,2);
    if hx <= 0 || hy <= 0
        error('Invalid right-edge element geometry at element %d: hx=%g, hy=%g.', e_right, hx, hy);
    end
    edofs = element_dofs(nodes,ndof_per_node);
    Fe = zeros(32,1);

    s = 1.0; % right edge in local coordinate
    for jg = 1:length(gp)
        t = gp(jg);
        wt = gw(jg);
        edgeJ = hy;
        [N, Nx, Ny, Nxx, Nyy, Nxy] = bfs_shape_2d(s,t,hx,hy); %#ok<ASGLU>
        [~,~,~,Nv] = make_B_matrices(N,Nx,Ny,Nxx,Nyy,Nxy);
        Fe = Fe + Nv.'*traction_right*(edgeJ*wt*thickness);
    end
    F(edofs) = F(edofs) + Fe;
end

%% -------------------- Essential boundary conditions --------------------
fixed_dofs = [];
left_nodes = arrayfun(@(iy) node_id(1,iy), 1:nny);

switch bc_case
    case "clamped_gradient"
        % Fix all Hermite DOFs for both displacement components on left edge.
        for n = left_nodes
            fixed_dofs = [fixed_dofs, (n-1)*8 + (1:8)]; %#ok<AGROW>
        end
    case "classical_clamp"
        % Fix only displacement values u and v on left edge.
        for n = left_nodes
            fixed_dofs = [fixed_dofs, (n-1)*8 + [1,5]]; %#ok<AGROW>
        end
    otherwise
        error('Unknown bc_case.');
end
fixed_dofs = unique(fixed_dofs);

all_dofs = 1:ndof;
free_dofs = setdiff(all_dofs,fixed_dofs);

%% -------------------- Linear solve with diagonal scaling --------------------
% The BFS element contains displacement, first-derivative and mixed-derivative
% DOFs. These DOFs have different physical dimensions, so the raw stiffness
% matrix can be badly scaled. A diagonal equilibration is therefore used
% before solving. If the scaled matrix is still nearly singular, a very small
% diagonal regularization is added only to remove numerical mechanisms.
D = zeros(ndof,1);
Kff = K(free_dofs,free_dofs);
Ff  = F(free_dofs);

scale_diag = sqrt(abs(diag(Kff)));
scale_diag(scale_diag < eps) = 1.0;
Sscale = spdiags(1./scale_diag,0,length(free_dofs),length(free_dofs));

Kscaled = Sscale*Kff*Sscale;
Fscaled = Sscale*Ff;

cond_est = condest(Kscaled);
fprintf('\nEstimated condition number after scaling = %.4e\n', cond_est);

if ~isfinite(cond_est) || cond_est > 1.0e14
    reg = 1.0e-10*mean(abs(diag(Kscaled)));
    if reg == 0 || ~isfinite(reg)
        reg = 1.0e-10;
    end
    fprintf('Applying small numerical regularization = %.4e\n', reg);
    Kscaled = Kscaled + reg*speye(size(Kscaled));
end

y = Kscaled\Fscaled;
D(free_dofs) = Sscale*y;

R = K*D - F;

%% -------------------- Post-processing --------------------
u_nodes = D(1:8:end);
v_nodes = D(5:8:end);
umag = sqrt(u_nodes.^2 + v_nodes.^2);

right_nodes = arrayfun(@(iy) node_id(nnx,iy), 1:nny);
avg_ux_right = mean(u_nodes(right_nodes));
max_umag = max(umag);

fprintf('\n===== 2D strain-gradient plane-strain FEM: BFS C1 element =====\n');
fprintf('Mesh                     = %d x %d elements\n', nelx, nely);
fprintf('DOFs per node            = %d\n', ndof_per_node);
fprintf('Total DOFs               = %d\n', ndof);
fprintf('BC case                  = %s\n', bc_case);
fprintf('Lx x Ly                  = %.4g x %.4g m\n', Lx, Ly);
fprintf('E, nu                    = %.4g Pa, %.4g\n', E, nu);
fprintf('micro length l           = %.6g m\n', l_micro);
fprintf('a^2=l^2/10               = %.6g m^2\n', a2);
fprintf('Right traction tx        = %.6g Pa\n', traction_right(1));
fprintf('Average u on right edge  = %.12e m\n', avg_ux_right);
fprintf('Maximum displacement mag = %.12e m\n', max_umag);
fprintf('Total reaction Fx left   = %.12e N\n', sum(R(arrayfun(@(n) (n-1)*8+1,left_nodes))));

% Plot displacement magnitude and deformed mesh
%% =====================================================================
%% Figure 1 : Displacement magnitude contour
%% =====================================================================

figure('Color','w','Position',[100 100 750 280]);

patch('Faces',conn,...
      'Vertices',coords,...
      'FaceVertexCData',umag,...
      'FaceColor','interp',...
      'EdgeColor',[0.75 0.75 0.75]);

axis equal
axis tight
box on
grid on

cb = colorbar;
%cb.Label.String = 'Displacement magnitude (m)';
cb.FontSize = 12;

xlabel('$x$ (m)',...
    'Interpreter','latex',...
    'FontSize',12)

ylabel('$y$ (m)',...
    'Interpreter','latex',...
    'FontSize',12)

set(gca,...
    'FontName','Times New Roman',...
    'FontSize',12,...
    'LineWidth',1.2)

%% save manually as e1.eps



%% =====================================================================
%% Figure 2 : Original and deformed mesh
%% =====================================================================

scale = 0.15*max(Lx,Ly)/max(max_umag,eps);

figure('Color','w','Position',[100 100 750 320]);

hold on
grid on
box on
axis equal

% Original mesh
for e = 1:nel
    nodes = conn(e,[1 2 3 4 1]);
    plot(coords(nodes,1),...
         coords(nodes,2),...
         'k-',...
         'LineWidth',0.6);
end

% Deformed mesh
coords_def = coords + scale*[u_nodes,v_nodes];

for e = 1:nel
    nodes = conn(e,[1 2 3 4 1]);
    plot(coords_def(nodes,1),...
         coords_def(nodes,2),...
         'b-',...
         'LineWidth',1.2);
end

xlabel('$x$ (m)',...
    'Interpreter','latex',...
    'FontSize',12)

ylabel('$y$ (m)',...
    'Interpreter','latex',...
    'FontSize',12)

legend({'Original mesh','Deformed mesh'},...
       'Interpreter','latex',...
       'FontSize',12,...
       'Location','northeast')

set(gca,...
    'FontName','Times New Roman',...
    'FontSize',12,...
    'LineWidth',1.2)

%% save manually as e2.eps



%% =====================================================================
%% Figure 3 : Centerline axial displacement
%% =====================================================================

center_y = Ly/2;
[~,iy_center] = min(abs(ygrid-center_y));

center_nodes = arrayfun(@(ix) node_id(ix,iy_center),1:nnx);

figure('Color','w','Position',[100 100 750 450]);

plot(xgrid,...
     u_nodes(center_nodes),...
     'o-',...
     'LineWidth',2,...
     'MarkerSize',5,...
     'MarkerFaceColor','w');

grid on
box on

xlabel('$x$ (m)',...
    'Interpreter','latex',...
    'FontSize',12)

ylabel('$u(x,L_y/2)$ (m)',...
    'Interpreter','latex',...
    'FontSize',12)

set(gca,...
    'FontName','Times New Roman',...
    'FontSize',12,...
    'LineWidth',1.2)

%% save manually as e3.eps

%% ========================================================================
function edofs = element_dofs(nodes,ndof_per_node)
    edofs = zeros(1, numel(nodes)*ndof_per_node);
    c = 0;
    for a = 1:numel(nodes)
        n = nodes(a);
        edofs(c+1:c+ndof_per_node) = (n-1)*ndof_per_node + (1:ndof_per_node);
        c = c + ndof_per_node;
    end
end

function [gp,gw] = gauss_1d_01(n)
    switch n
        case 2
            x = [-1/sqrt(3), 1/sqrt(3)];
            w = [1, 1];
        case 3
            x = [-sqrt(3/5), 0, sqrt(3/5)];
            w = [5/9, 8/9, 5/9];
        case 4
            x = [-0.8611363115940526, -0.3399810435848563, ...
                  0.3399810435848563,  0.8611363115940526];
            w = [0.3478548451374538, 0.6521451548625461, ...
                 0.6521451548625461, 0.3478548451374538];
        otherwise
            error('Only n=2,3,4 implemented.');
    end
    gp = (x+1)/2;
    gw = w/2;
end

function [N, Nx, Ny, Nxx, Nyy, Nxy] = bfs_shape_2d(s,t,hx,hy)
% Bicubic Hermite tensor-product shape functions on [0,1]x[0,1].
% Local node order: 1=bottom-left, 2=bottom-right, 3=top-right, 4=top-left.
% Scalar DOFs per node: [w, w_x, w_y, w_xy].

    [Hx0,Hx1,Hx0x,Hx1x,Hx0xx,Hx1xx] = hermite_1d_two_nodes(s,hx);
    [Hy0,Hy1,Hy0y,Hy1y,Hy0yy,Hy1yy] = hermite_1d_two_nodes(t,hy);

    % side selectors for local nodes [BL BR TR TL]
    xs = [1 2 2 1];
    ys = [1 1 2 2];

    N   = zeros(1,16);
    Nx  = zeros(1,16);
    Ny  = zeros(1,16);
    Nxx = zeros(1,16);
    Nyy = zeros(1,16);
    Nxy = zeros(1,16);

    for a = 1:4
        ix = xs(a); iy = ys(a);
        p = (a-1)*4;

        % DOF w
        N(p+1)   = Hx0(ix)*Hy0(iy);
        Nx(p+1)  = Hx0x(ix)*Hy0(iy);
        Ny(p+1)  = Hx0(ix)*Hy0y(iy);
        Nxx(p+1) = Hx0xx(ix)*Hy0(iy);
        Nyy(p+1) = Hx0(ix)*Hy0yy(iy);
        Nxy(p+1) = Hx0x(ix)*Hy0y(iy);

        % DOF w_x
        N(p+2)   = Hx1(ix)*Hy0(iy);
        Nx(p+2)  = Hx1x(ix)*Hy0(iy);
        Ny(p+2)  = Hx1(ix)*Hy0y(iy);
        Nxx(p+2) = Hx1xx(ix)*Hy0(iy);
        Nyy(p+2) = Hx1(ix)*Hy0yy(iy);
        Nxy(p+2) = Hx1x(ix)*Hy0y(iy);

        % DOF w_y
        N(p+3)   = Hx0(ix)*Hy1(iy);
        Nx(p+3)  = Hx0x(ix)*Hy1(iy);
        Ny(p+3)  = Hx0(ix)*Hy1y(iy);
        Nxx(p+3) = Hx0xx(ix)*Hy1(iy);
        Nyy(p+3) = Hx0(ix)*Hy1yy(iy);
        Nxy(p+3) = Hx0x(ix)*Hy1y(iy);

        % DOF w_xy
        N(p+4)   = Hx1(ix)*Hy1(iy);
        Nx(p+4)  = Hx1x(ix)*Hy1(iy);
        Ny(p+4)  = Hx1(ix)*Hy1y(iy);
        Nxx(p+4) = Hx1xx(ix)*Hy1(iy);
        Nyy(p+4) = Hx1(ix)*Hy1yy(iy);
        Nxy(p+4) = Hx1x(ix)*Hy1y(iy);
    end
end

function [H0,H1,H0x,H1x,H0xx,H1xx] = hermite_1d_two_nodes(s,L)
% Hermite basis for two nodes on [0,1].
% H0 are value DOF functions at left/right, H1 are derivative DOF functions.
    h1 = 1 - 3*s^2 + 2*s^3;
    h2 = L*(s - 2*s^2 + s^3);
    h3 = 3*s^2 - 2*s^3;
    h4 = L*(-s^2 + s^3);

    dh1 = -6*s + 6*s^2;
    dh2 = L*(1 - 4*s + 3*s^2);
    dh3 = 6*s - 6*s^2;
    dh4 = L*(-2*s + 3*s^2);

    d2h1 = -6 + 12*s;
    d2h2 = L*(-4 + 6*s);
    d2h3 = 6 - 12*s;
    d2h4 = L*(-2 + 6*s);

    H0 = [h1, h3];
    H1 = [h2, h4];

    H0x = (1/L)*[dh1, dh3];
    H1x = (1/L)*[dh2, dh4];

    H0xx = (1/L^2)*[d2h1, d2h3];
    H1xx = (1/L^2)*[d2h2, d2h4];
end

function [B,Bx,By,Nv] = make_B_matrices(N,Nx,Ny,Nxx,Nyy,Nxy)
% Build plane-strain B matrix and its x/y derivatives for vector DOFs.
% Local vector DOF order per node:
%   [u,u_x,u_y,u_xy,v,v_x,v_y,v_xy]

    B  = zeros(3,32);
    Bx = zeros(3,32);
    By = zeros(3,32);
    Nv = zeros(2,32);

    for a = 1:4
        sp = (a-1)*4 + (1:4); % scalar shape positions
        up = (a-1)*8 + (1:4);
        vp = (a-1)*8 + (5:8);

        % displacement interpolation matrix
        Nv(1,up) = N(sp);
        Nv(2,vp) = N(sp);

        % B matrix: [eps_xx; eps_yy; gamma_xy]
        B(1,up) = Nx(sp);
        B(2,vp) = Ny(sp);
        B(3,up) = Ny(sp);
        B(3,vp) = Nx(sp);

        % dB/dx
        Bx(1,up) = Nxx(sp);
        Bx(2,vp) = Nxy(sp);
        Bx(3,up) = Nxy(sp);
        Bx(3,vp) = Nxx(sp);

        % dB/dy
        By(1,up) = Nxy(sp);
        By(2,vp) = Nyy(sp);
        By(3,up) = Nyy(sp);
        By(3,vp) = Nxy(sp);
    end
end
