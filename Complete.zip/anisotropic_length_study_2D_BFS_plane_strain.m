%% anisotropic_length_study_2D_BFS_plane_strain.m
%
% Direction-dependent/ellipsoidal strain-gradient length study for 2D
% plane-strain elasticity using C1 Bogner-Fox-Schmit rectangular elements.
%
% Energy:
%   W = 1/2 eps^T C eps
%       + 1/20 [ lx^2 eps_x^T C eps_x + ly^2 eps_y^T C eps_y ]
%
% Equivalently:
%   W = 1/2 eps^T C eps
%       + 1/2 [ ax^2 eps_x^T C eps_x + ay^2 eps_y^T C eps_y ]
% where
%   ax^2 = lx^2/10,   ay^2 = ly^2/10.
%
% Problem:
%   Rectangular plane-strain domain [0,Lx] x [0,Ly]
%   Left edge: strain-gradient clamped
%   Right edge: uniform horizontal traction
%
% -------------------------------------------------------------------------
%  FIGURE PACKAGE (publication-ready, matches Fig01-Fig05 style exactly):
%    MAIN    : Fig06  (a) u_R (um) bar chart ; (b) ratio bar chart
%    APPENDIX : FigA5  diagnostics (reaction error + condition number)
%    APPENDIX : FigA6  |u| contour fields (2x2, optional/supplementary)
% -------------------------------------------------------------------------

clear; clc; close all;

% ── Root defaults — IDENTICAL to all 1D/2D figures in this manuscript ─────
set(groot, 'defaultAxesFontName',             'Times New Roman');
set(groot, 'defaultAxesFontSize',             10);
set(groot, 'defaultTextFontName',             'Times New Roman');
set(groot, 'defaultTextFontSize',             10);
set(groot, 'defaultAxesTickLabelInterpreter', 'tex');
set(groot, 'defaultTextInterpreter',          'tex');

%% -------------------- Input data --------------------
Lx = 1.0;
Ly = 0.20;
E  = 200e9;
nu = 0.30;
thickness = 1.0;
nelx = 20;
nely = 4;
traction_right = [1.0e6; 0.0];
body_force = [0.0; 0.0];
bc_case = "clamped_gradient";

% Case list: {name, lx, ly}
case_names = { ...
    'nearly classical', ...
    'isotropic 0.05', ...
    'x-dominant', ...
    'y-dominant', ...
    'strong-x', ...
    'strong-y', ...
    'both large'};

lx_list = [0.005, 0.05, 0.10, 0.02, 0.20, 0.02, 0.20];
ly_list = [0.005, 0.05, 0.02, 0.10, 0.02, 0.20, 0.20];
ncase = numel(case_names);

avg_u_right = zeros(ncase,1);
max_umag    = zeros(ncase,1);
react_left  = zeros(ncase,1);
cond_est    = zeros(ncase,1);

%% -------------------- Run anisotropic cases --------------------
for i = 1:ncase
    fprintf('\n--- Solving case: %s, lx=%.5f, ly=%.5f ---\n', ...
        case_names{i}, lx_list(i), ly_list(i));
    [avg_u_right(i), max_umag(i), react_left(i), cond_est(i)] = ...
        solve_2d_sg_bfs_aniso(Lx,Ly,E,nu,thickness,nelx,nely, ...
                              lx_list(i),ly_list(i),traction_right, ...
                              body_force,bc_case,false);
end

u_ref = avg_u_right(1);
ratio = avg_u_right / u_ref;

applied_Fx = traction_right(1)*Ly*thickness;
reaction_error_percent = 100*abs(react_left + applied_Fx)/abs(applied_Fx);

%% -------------------- Print table --------------------
fprintf('\n===== 2D anisotropic/ellipsoidal length study =====\n');
fprintf('Mesh                 = %d x %d BFS elements\n', nelx, nely);
fprintf('Domain               = %.4g x %.4g m\n', Lx, Ly);
fprintf('Right traction tx    = %.6e Pa\n', traction_right(1));
fprintf('Applied resultant Fx = %.6e N\n\n', applied_Fx);

fprintf('%18s %10s %10s %14s %14s %20s %20s %14s %14s\n', ...
    'case','lx','ly','ax=lx/sqrt10','ay=ly/sqrt10','avg u right','max |u|','u/u_ref','Rx err %');
fprintf('%18s %10s %10s %14s %14s %20s %20s %14s %14s\n', ...
    '----','--','--','-------------','-------------','-----------','-------','-------','--------');
for i = 1:ncase
    fprintf('%18s %10.5f %10.5f %14.6e %14.6e %20.12e %20.12e %14.6f %14.6e\n', ...
        case_names{i}, lx_list(i), ly_list(i), lx_list(i)/sqrt(10), ly_list(i)/sqrt(10), ...
        avg_u_right(i), max_umag(i), ratio(i), reaction_error_percent(i));
end

%% ========================================================================
%%  PUBLICATION-QUALITY FIGURE — 2D ANISOTROPIC LENGTH-SCALE STUDY
%%
%%  Two-panel composite bar chart (MAIN manuscript):
%%    (a) Average right-edge displacement  bar_u_R  (um)  for 7 cases
%%    (b) Normalised displacement ratio  bar_u_R / bar_u_R,ref
%%
%%  The 7 anisotropic cases are labelled by index (1-7); the (lx, ly)
%%  definitions are given in the caption.
%%
%%  Visual identity: matches Fig01-Fig05 exactly.
%%  Uses identical styleAxes() and %exportFig() utility functions.
%% ========================================================================

% ── Unit conversion ────────────────────────────────────────────────────────
u_R_um = avg_u_right * 1e6;          % metres -> um

% ── Colour (Wong 2011, entry 1 — blue, identical to all figures) ───────────
C_blue = [0.000, 0.447, 0.698];
C_gray = [0.500, 0.500, 0.500];       % reference line in panel (b)

% ── Line and marker constants (identical to all figures) ──────────────────
LW_ref = 0.8;     % reference dotted line

% ── Case axis ─────────────────────────────────────────────────────────────
case_x = 1:ncase;

% ── Figure dimensions — identical to Fig02 / Fig04 / Fig05 ────────────────
fig_w_mm = 176;   % double-column width (mm)
fig_h_mm =  72;   % height (mm)
fig = figure('Color','white', ...
             'Units','centimeters', ...
             'Position',[2, 2, fig_w_mm/10, fig_h_mm/10]);

% ── Two-panel tiled layout (same spacing as all 1D/2D figures) ────────────
tl = tiledlayout(1, 2, ...
    'TileSpacing', 'compact', ...
    'Padding',     'compact');

% =========================================================================
%  Panel (a) — Average right-edge displacement vs case
% =========================================================================
ax1 = nexttile(tl, 1);
b1 = bar(ax1, case_x, u_R_um, 0.7);
b1.FaceColor = C_blue;
b1.EdgeColor = 'none';
styleAxes(ax1);
xlabel(ax1, 'Case', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
ylabel(ax1, 'Avg. right-edge displacement (\mum)', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
set(ax1, 'XTick', case_x);
% Non-zero y-axis origin: consistent with Fig02a (470-500 um),
% Fig04a (4.25-4.50 um).  Differences are small (~6%); a zero-based
% axis would make them invisible.
u_min = min(u_R_um);  u_max = max(u_R_um);  u_span = u_max - u_min;
ylim(ax1, [u_min - 0.25*u_span,  u_max + 0.20*u_span]);

% Panel label — identical position/style to all figures
text(ax1, 0.08, 0.95, '(a)', ...
    'Units',       'normalized', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11, ...
    'FontWeight',  'bold', ...
    'Interpreter', 'none');

% =========================================================================
%  Panel (b) — Normalised displacement ratio vs case
%
%  Normalisation: bar_u_R(case) / bar_u_R(case 1), where case 1 is the
%  near-classical reference (lx = ly = 0.005).  The dotted line at 1.0
%  marks the quasi-classical limit.
% =========================================================================
ax2 = nexttile(tl, 2);
b2 = bar(ax2, case_x, ratio, 0.7);
b2.FaceColor = C_blue;
b2.EdgeColor = 'none';
hold(ax2, 'on');
yline(ax2, 1.0, ...
    'Color',     C_gray, ...
    'LineStyle', ':', ...
    'LineWidth', LW_ref);
styleAxes(ax2);
xlabel(ax2, 'Case', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
% NOTE: tex interpreter has no overline/bar accent. Use plain 'u' with
% subscripts (same convention as Fig02/Fig04 axis labels); the averaging
% bar is reserved for the LaTeX manuscript text (\bar{u}_R), not the figure.
ylabel(ax2, 'u_R / u_{R,ref}', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
set(ax2, 'XTick', case_x);
r_min = min(ratio);  r_span = 1.0 - r_min;
ylim(ax2, [r_min - 0.20*r_span,  1.0 + 0.15*r_span]);

% Panel label
text(ax2, 0.08, 0.95, '(b)', ...
    'Units',       'normalized', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11, ...
    'FontWeight',  'bold', ...
    'Interpreter', 'none');

% ── %export main figure ────────────────────────────────────────────────────
%exportFig(fig, 'Fig06_2D_AnisotropicLengthEffect', fig_w_mm, fig_h_mm);

%% ========================================================================
%%  APPENDIX FIGURE A5 — Diagnostics: reaction balance + condition number
%%  Classification: Appendix / Supplementary Material.  NOT main text.
%% ========================================================================
fig_A5 = figure('Color','white', ...
                'Units','centimeters', ...
                'Position',[2, 10, fig_w_mm/10, fig_h_mm/10]);
tl_A5 = tiledlayout(1, 2, ...
    'TileSpacing', 'compact', ...
    'Padding',     'compact');

% ── Panel (a) — Reaction balance error ────────────────────────────────────
axA1 = nexttile(tl_A5, 1);
semilogy(axA1, case_x, reaction_error_percent, ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       1.5, ...
    'Marker',          'o', ...
    'MarkerSize',      6, ...
    'MarkerFaceColor', 'white');
styleAxes(axA1);
xlabel(axA1, 'Case', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
ylabel(axA1, 'Reaction balance error (\%)', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
set(axA1, 'XTick', case_x);
text(axA1, 0.08, 0.95, '(a)', ...
    'Units','normalized','FontName','Times New Roman', ...
    'FontSize',11,'FontWeight','bold','Interpreter','none');

% ── Panel (b) — Condition number ──────────────────────────────────────────
axA2 = nexttile(tl_A5, 2);
semilogy(axA2, case_x, cond_est, ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       1.5, ...
    'Marker',          'o', ...
    'MarkerSize',      6, ...
    'MarkerFaceColor', 'white');
styleAxes(axA2);
xlabel(axA2, 'Case', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
ylabel(axA2, 'Estimated condition number \kappa', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
set(axA2, 'XTick', case_x);
text(axA2, 0.08, 0.95, '(b)', ...
    'Units','normalized','FontName','Times New Roman', ...
    'FontSize',11,'FontWeight','bold','Interpreter','none');

%exportFig(fig_A5, 'FigA5_2D_AnisotropicDiagnostics', fig_w_mm, fig_h_mm);

%% ========================================================================
%%  APPENDIX FIGURE A6 — Displacement-magnitude contour fields (2x2)
%%  Classification: Appendix / Supplementary Material.  NOT main text.
%
%  NOTE: The |u| field for a plate under x-traction is dominated by the
%  axial displacement component and varies mainly in x.  The through-
%  thickness (y) variation is small for all cases.  These contours are
%  therefore supplementary field visualisations, not the primary evidence
%  for directional stiffening (which is provided by the bar chart, Fig06).
%  If a strain-field (eps_xx) contour is desired instead, the solver
%  would need to be extended to return strain at Gauss points.
%% ========================================================================
selected_cases = [2, 3, 4, 7];   % isotropic, x-dom, y-dom, both-large
ncont = numel(selected_cases);

% Re-solve selected cases with field output
contour_data = cell(1, ncont);
for k = 1:ncont
    idx = selected_cases(k);
    contour_data{k} = solve_2d_sg_bfs_aniso( ...
        Lx, Ly, E, nu, thickness, nelx, nely, ...
        lx_list(idx), ly_list(idx), traction_right, ...
        body_force, bc_case, true, case_names{idx});
end

% Shared colour scale across all panels
% Accumulate the maximum in METRES first, then convert to micrometres
% OUTSIDE the loop.  (Multiplying by 1e6 inside the loop would rescale
% the running maximum on every iteration -> 4.5 -> 4.5e6 -> 4.5e12 -> 4.5e18.)
cmin = 0;
cmax = 0;
for k = 1:ncont
    cmax = max(cmax, contour_data{k}.max_umag);
end
cmax = cmax * 1e6;   % metres -> micrometres

fig_w_c = 176;   fig_h_c = 110;   % mm (taller for 2x2 with colourbars)
fig_A6 = figure('Color','white', ...
                'Units','centimeters', ...
                'Position',[2, 2, fig_w_c/10, fig_h_c/10]);
tl_A6 = tiledlayout(2, 2, ...
    'TileSpacing', 'compact', ...
    'Padding',     'compact');

panel_labels = {'(a)', '(b)', '(c)', '(d)'};
for k = 1:ncont
    ax = nexttile(tl_A6, k);
    umag_um = contour_data{k}.umag_nodes * 1e6;

    % --- patch: per-vertex colour, interpolated across each element -------
    p = patch(ax, 'Faces',       contour_data{k}.conn, ...
                  'Vertices',    contour_data{k}.coords, ...
                  'FaceVertexCData', umag_um, ...
                  'FaceColor',   'interp', ...
                  'EdgeColor',   [0.7 0.7 0.7]);

    % --- Fill the subplot (do NOT use 'equal' on the 5:1 domain) ----------
    % 'axis equal' forces 1:1 data aspect; on Lx=1, Ly=0.2 the patch
    % would fill only 1/5 of the panel height (~80% whitespace).
    % Identical limits + auto aspect STRETCH the field to fill the panel.
    xlim(ax, [0, Lx]);
    ylim(ax, [0, Ly]);
    set(ax, 'DataAspectRatioMode',  'auto', ...
            'PlotBoxAspectRatioMode','auto');

    % --- Shared colour scale across all four panels -----------------------
    % (CLim works in all MATLAB releases; replaces deprecated caxis)
    set(ax, 'CLim', [cmin, cmax]);
    colormap(ax, parula);

    % --- Colorbar ----------------------------------------------------------
    cb = colorbar(ax);
    cb.Label.String      = '|u| (\mum)';
    cb.Label.Interpreter = 'tex';          % \mu -> micro sign -> 'um'
    cb.Label.FontName    = 'Times New Roman';
    cb.Label.FontSize    = 10;
    cb.FontName          = 'Times New Roman';
    cb.FontSize          = 9;

    % --- Axis labels (explicit tex interpreter) ----------------------------
    xlabel(ax, 'x (m)', 'Interpreter','tex', ...
           'FontName','Times New Roman','FontSize',10);
    ylabel(ax, 'y (m)', 'Interpreter','tex', ...
           'FontName','Times New Roman','FontSize',10);
    set(ax, 'FontName','Times New Roman','FontSize',10, ...
            'LineWidth',0.8,'Box','on','TickDir','in');

    % --- Title (explicit tex interpreter) ----------------------------------
    title(ax, sprintf('l_x=%.3f, l_y=%.3f', ...
         lx_list(selected_cases(k)), ly_list(selected_cases(k))), ...
         'Interpreter','tex', ...
         'FontName','Times New Roman','FontSize',10);

    % --- Panel label (white, top-left) -------------------------------------
    text(ax, 0.03, 0.92, panel_labels{k}, ...
         'Units','normalized','FontName','Times New Roman', ...
         'FontSize',11,'FontWeight','bold','Interpreter','none','Color','w');
end

%exportFig(fig_A6, 'FigA6_2D_AnisotropicContours', fig_w_c, fig_h_c);

%% ========================================================================
%%  UTILITY FUNCTIONS — identical to the 1D/2D figure package
%% ========================================================================

function styleAxes(ax)
% styleAxes — Uniform publication axis style.
%   Identical to all figures (Fig01-Fig05).
set(ax, ...
    'FontName',             'Times New Roman', ...
    'FontSize',             10, ...
    'LineWidth',            0.8, ...
    'Box',                  'on', ...
    'TickDir',              'in', ...
    'TickLength',           [0.015, 0.015], ...
    'XMinorTick',           'off', ...
    'YMinorTick',           'off', ...
    'GridLineStyle',        ':', ...
    'GridAlpha',            0.35, ...
    'MinorGridLineStyle',   'none', ...
    'TickLabelInterpreter', 'tex');
grid(ax, 'on');
end

function exportFig(figHandle, filename, width_mm, height_mm)
% %exportFig — %export to EPS (vector), PDF (vector), PNG (600 dpi).
set(figHandle, 'Renderer', 'painters');
w_cm = width_mm  / 10;
h_cm = height_mm / 10;
set(figHandle, 'Units',             'centimeters');
set(figHandle, 'Position',          [2, 2, w_cm, h_cm]);
set(figHandle, 'PaperUnits',        'centimeters');
set(figHandle, 'PaperPositionMode', 'manual');
set(figHandle, 'PaperSize',         [w_cm, h_cm]);
set(figHandle, 'PaperPosition',     [0, 0, w_cm, h_cm]);
print(figHandle, [filename, '.eps'], '-depsc', '-r0');
print(figHandle, [filename, '.pdf'], '-dpdf',  '-r0');
print(figHandle, [filename, '.png'], '-dpng',  '-r600');
fprintf('\n[%exportFig] Saved  : %s  (.eps / .pdf / .png)\n', filename);
fprintf('[%exportFig] Size   : %.0f x %.0f mm\n', width_mm, height_mm);
end

%% ========================================================================
%%  FEM SOLVER AND SHAPE FUNCTIONS
%%  Solver returns a struct when do_plots=true (for contour extraction).
%%  The numerical formulation is UNCHANGED.
%% ========================================================================

function varargout = solve_2d_sg_bfs_aniso(...
    Lx,Ly,E,nu,thickness,nelx,nely,lx,ly,traction_right,body_force,bc_case,do_plots,case_name)

    if nargin < 14
        case_name = '';
    end

    ax2 = lx^2/10;
    ay2 = ly^2/10;

    % Material matrix: plane strain
    lambda = E*nu/((1+nu)*(1-2*nu));
    mu     = E/(2*(1+nu));
    C = [lambda+2*mu, lambda,      0;
         lambda,      lambda+2*mu, 0;
         0,           0,           mu];

    % Mesh
    nnx = nelx + 1;
    nny = nely + 1;
    nnode = nnx*nny;
    ndof_per_node = 8;
    ndof = ndof_per_node*nnode;

    xgrid = linspace(0,Lx,nnx);
    ygrid = linspace(0,Ly,nny);
    node_id = @(ix,iy) (iy-1)*nnx + ix;

    coords = zeros(nnode,2);
    for iy = 1:nny
        for ix = 1:nnx
            n = node_id(ix,iy);
            coords(n,:) = [xgrid(ix), ygrid(iy)];
        end
    end

    conn = zeros(nelx*nely,4);
    e = 0;
    for ey = 1:nely
        for ex = 1:nelx
            e = e + 1;
            conn(e,:) = [node_id(ex,ey), node_id(ex+1,ey), ...
                         node_id(ex+1,ey+1), node_id(ex,ey+1)];
        end
    end

    nel = size(conn,1);
    K = sparse(ndof,ndof);
    F = zeros(ndof,1);

    [gp, gw] = gauss_1d_01(4);

    % Assembly
    for e = 1:nel
        nodes = conn(e,:);
        xy = coords(nodes,:);
        hx = xy(2,1) - xy(1,1);
        hy = xy(4,2) - xy(1,2);
        if hx <= 0 || hy <= 0
            error('Invalid element geometry at element %d: hx=%g, hy=%g.', e, hx, hy);
        end
        detJ = hx*hy;
        Ke = zeros(32,32);
        Fe = zeros(32,1);
        for ig = 1:length(gp)
            s = gp(ig); ws = gw(ig);
            for jg = 1:length(gp)
                t = gp(jg); wt = gw(jg);
                wgt = ws*wt*detJ*thickness;
                [N,Nx,Ny,Nxx,Nyy,Nxy] = bfs_shape_2d(s,t,hx,hy);
                [B,Bx,By,Nv] = make_B_matrices(N,Nx,Ny,Nxx,Nyy,Nxy);
                % Anisotropic/ellipsoidal gradient contribution:
                % lx controls x-gradient term; ly controls y-gradient term.
                Ke = Ke + (B.'*C*B + ax2*(Bx.'*C*Bx) + ay2*(By.'*C*By))*wgt;
                Fe = Fe + Nv.'*body_force*wgt;
            end
        end
        edofs = element_dofs(nodes,ndof_per_node);
        K(edofs,edofs) = K(edofs,edofs) + Ke;
        F(edofs) = F(edofs) + Fe;
    end

    % Right-edge traction
    for ey = 1:nely
        e_right = (ey-1)*nelx + nelx;
        nodes = conn(e_right,:);
        xy = coords(nodes,:);
        hx = xy(2,1) - xy(1,1);
        hy = xy(4,2) - xy(1,2);
        edofs = element_dofs(nodes,ndof_per_node);
        Fe = zeros(32,1);
        s = 1.0;
        for jg = 1:length(gp)
            t = gp(jg); wt = gw(jg);
            edgeJ = hy;
            [N,Nx,Ny,Nxx,Nyy,Nxy] = bfs_shape_2d(s,t,hx,hy); %#ok<ASGLU>
            [~,~,~,Nv] = make_B_matrices(N,Nx,Ny,Nxx,Nyy,Nxy);
            Fe = Fe + Nv.'*traction_right*(edgeJ*wt*thickness);
        end
        F(edofs) = F(edofs) + Fe;
    end

    % Essential BCs
    fixed_dofs = [];
    left_nodes = arrayfun(@(iy) node_id(1,iy), 1:nny);
    switch bc_case
        case "clamped_gradient"
            for n = left_nodes
                fixed_dofs = [fixed_dofs, (n-1)*8 + (1:8)]; %#ok<AGROW>
            end
        case "classical_clamp"
            for n = left_nodes
                fixed_dofs = [fixed_dofs, (n-1)*8 + [1,5]]; %#ok<AGROW>
            end
        otherwise
            error('Unknown bc_case.');
    end
    fixed_dofs = unique(fixed_dofs);
    free_dofs = setdiff(1:ndof,fixed_dofs);

    % Scaled solve
    Kff = K(free_dofs,free_dofs);
    Ff  = F(free_dofs);
    scale_diag = sqrt(abs(diag(Kff)));
    scale_diag(scale_diag < eps) = 1.0;
    Sscale = spdiags(1./scale_diag,0,length(free_dofs),length(free_dofs));
    Kscaled = Sscale*Kff*Sscale;
    Fscaled = Sscale*Ff;
    cond_est = condest(Kscaled);
    if ~isfinite(cond_est) || cond_est > 1.0e14
        reg = 1.0e-10*mean(abs(diag(Kscaled)));
        if reg == 0 || ~isfinite(reg)
            reg = 1.0e-10;
        end
        Kscaled = Kscaled + reg*speye(size(Kscaled));
    end
    y = Kscaled\Fscaled;
    D = zeros(ndof,1);
    D(free_dofs) = Sscale*y;

    R = K*D - F;

    u_nodes = D(1:8:end);
    v_nodes = D(5:8:end);
    umag = sqrt(u_nodes.^2 + v_nodes.^2);

    right_nodes = arrayfun(@(iy) node_id(nnx,iy), 1:nny);
    avg_ux_right = mean(u_nodes(right_nodes));
    max_umag = max(umag);
    total_Rx_left = sum(R(arrayfun(@(n) (n-1)*8+1,left_nodes)));

    if do_plots
        % Return field data as struct for external contour plotting
        varargout{1} = struct( ...
            'avg_ux_right', avg_ux_right, ...
            'max_umag',     max_umag, ...
            'total_Rx',     total_Rx_left, ...
            'cond_est',     cond_est, ...
            'u_nodes',      u_nodes, ...
            'v_nodes',      v_nodes, ...
            'umag_nodes',   umag, ...
            'coords',       coords, ...
            'conn',         conn);
    else
        varargout{1} = avg_ux_right;
        varargout{2} = max_umag;
        varargout{3} = total_Rx_left;
        varargout{4} = cond_est;
    end
end

function edofs = element_dofs(nodes,ndof_per_node)
    edofs = zeros(1, numel(nodes)*ndof_per_node);
    c = 0;
    for a = 1:numel(nodes)
        n = nodes(a);
        edofs(c+1:c+ndof_per_node) = (n-1)*ndof_per_node + (1:ndof_per_node);
        c = c + ndof_per_node;
    end
end

function [gp,gw] = gauss_1d_01(n)
    switch n
        case 4
            x = [-0.8611363115940526, -0.3399810435848563, ...
                  0.3399810435848563,  0.8611363115940526];
            w = [0.3478548451374538, 0.6521451548625461, ...
                 0.6521451548625461, 0.3478548451374538];
        otherwise
            error('Only n=4 implemented here.');
    end
    gp = (x+1)/2;
    gw = w/2;
end

function [N, Nx, Ny, Nxx, Nyy, Nxy] = bfs_shape_2d(s,t,hx,hy)
    [Hx0,Hx1,Hx0x,Hx1x,Hx0xx,Hx1xx] = hermite_1d_two_nodes(s,hx);
    [Hy0,Hy1,Hy0y,Hy1y,Hy0yy,Hy1yy] = hermite_1d_two_nodes(t,hy);
    xs = [1 2 2 1];
    ys = [1 1 2 2];
    N   = zeros(1,16);
    Nx  = zeros(1,16);
    Ny  = zeros(1,16);
    Nxx = zeros(1,16);
    Nyy = zeros(1,16);
    Nxy = zeros(1,16);
    for a = 1:4
        ix = xs(a); iy = ys(a);
        p = (a-1)*4;
        N(p+1)   = Hx0(ix)*Hy0(iy);
        Nx(p+1)  = Hx0x(ix)*Hy0(iy);
        Ny(p+1)  = Hx0(ix)*Hy0y(iy);
        Nxx(p+1) = Hx0xx(ix)*Hy0(iy);
        Nyy(p+1) = Hx0(ix)*Hy0yy(iy);
        Nxy(p+1) = Hx0x(ix)*Hy0y(iy);
        N(p+2)   = Hx1(ix)*Hy0(iy);
        Nx(p+2)  = Hx1x(ix)*Hy0(iy);
        Ny(p+2)  = Hx1(ix)*Hy0y(iy);
        Nxx(p+2) = Hx1xx(ix)*Hy0(iy);
        Nyy(p+2) = Hx1(ix)*Hy0yy(iy);
        Nxy(p+2) = Hx1x(ix)*Hy0y(iy);
        N(p+3)   = Hx0(ix)*Hy1(iy);
        Nx(p+3)  = Hx0x(ix)*Hy1(iy);
        Ny(p+3)  = Hx0(ix)*Hy1y(iy);
        Nxx(p+3) = Hx0xx(ix)*Hy1(iy);
        Nyy(p+3) = Hx0(ix)*Hy1yy(iy);
        Nxy(p+3) = Hx0x(ix)*Hy1y(iy);
        N(p+4)   = Hx1(ix)*Hy1(iy);
        Nx(p+4)  = Hx1x(ix)*Hy1(iy);
        Ny(p+4)  = Hx1(ix)*Hy1y(iy);
        Nxx(p+4) = Hx1xx(ix)*Hy1(iy);
        Nyy(p+4) = Hx1(ix)*Hy1yy(iy);
        Nxy(p+4) = Hx1x(ix)*Hy1y(iy);
    end
end

function [H0,H1,H0x,H1x,H0xx,H1xx] = hermite_1d_two_nodes(s,L)
    h1 = 1 - 3*s^2 + 2*s^3;
    h2 = L*(s - 2*s^2 + s^3);
    h3 = 3*s^2 - 2*s^3;
    h4 = L*(-s^2 + s^3);
    dh1 = -6*s + 6*s^2;
    dh2 = L*(1 - 4*s + 3*s^2);
    dh3 = 6*s - 6*s^2;
    dh4 = L*(-2*s + 3*s^2);
    d2h1 = -6 + 12*s;
    d2h2 = L*(-4 + 6*s);
    d2h3 = 6 - 12*s;
    d2h4 = L*(-2 + 6*s);
    H0 = [h1, h3];
    H1 = [h2, h4];
    H0x = (1/L)*[dh1, dh3];
    H1x = (1/L)*[dh2, dh4];
    H0xx = (1/L^2)*[d2h1, d2h3];
    H1xx = (1/L^2)*[d2h2, d2h4];
end

function [B,Bx,By,Nv] = make_B_matrices(N,Nx,Ny,Nxx,Nyy,Nxy)
    B  = zeros(3,32);
    Bx = zeros(3,32);
    By = zeros(3,32);
    Nv = zeros(2,32);
    for a = 1:4
        sp = (a-1)*4 + (1:4);
        up = (a-1)*8 + (1:4);
        vp = (a-1)*8 + (5:8);
        Nv(1,up) = N(sp);
        Nv(2,vp) = N(sp);
        B(1,up) = Nx(sp);
        B(2,vp) = Ny(sp);
        B(3,up) = Ny(sp);
        B(3,vp) = Nx(sp);
        Bx(1,up) = Nxx(sp);
        Bx(2,vp) = Nxy(sp);
        Bx(3,up) = Nxy(sp);
        Bx(3,vp) = Nxx(sp);
        By(1,up) = Nxy(sp);
        By(2,vp) = Nyy(sp);
        By(3,up) = Nyy(sp);
        By(3,vp) = Nxy(sp);
    end
end
