%% anisotropic_length_study_3D_Hermite_elasticity.m
% 3D anisotropic/ellipsoidal strain-gradient length study using C1
% tensor-product tricubic Hermite hexahedral elements.
%
% Energy:
%   W = 1/2 eps^T C eps
%     + 1/20 [ lx^2 eps_x^T C eps_x + ly^2 eps_y^T C eps_y + lz^2 eps_z^T C eps_z ]
%
% Equivalently:
%   ax^2 = lx^2/10, ay^2 = ly^2/10, az^2 = lz^2/10.
%
% Problem:
%   Cuboid [0,Lx]x[0,Ly]x[0,Lz]
%   Left face: strain-gradient clamped
%   Right face: uniform x-traction

clear; clc; close all;

%% -------------------- Input data --------------------
Lx = 1.0;
Ly = 0.20;
Lz = 0.20;

E  = 200e9;
nu = 0.30;

nelx = 4;
nely = 2;
nelz = 2;

traction_right = [1.0e6; 0.0; 0.0];
body_force = [0.0; 0.0; 0.0];
bc_case = "clamped_gradient";

% Case list: name, lx, ly, lz
case_names = { ...
    'nearly classical', ...
    'isotropic 0.05', ...
    'x-dominant', ...
    'y-dominant', ...
    'z-dominant', ...
    'strong-x', ...
    'strong-y', ...
    'strong-z', ...
    'both transverse', ...
    'all large'};

lx_list = [0.005, 0.05, 0.10, 0.02, 0.02, 0.20, 0.02, 0.02, 0.02, 0.20];
ly_list = [0.005, 0.05, 0.02, 0.10, 0.02, 0.02, 0.20, 0.02, 0.20, 0.20];
lz_list = [0.005, 0.05, 0.02, 0.02, 0.10, 0.02, 0.02, 0.20, 0.20, 0.20];

ncase = numel(case_names);
avg_u_right = zeros(ncase,1);
max_umag    = zeros(ncase,1);
react_left  = zeros(ncase,1);
cond_est    = zeros(ncase,1);

%% -------------------- Run cases --------------------
for i = 1:ncase
    fprintf('\n--- Solving case: %s, lx=%.5f, ly=%.5f, lz=%.5f ---\n', ...
        case_names{i}, lx_list(i), ly_list(i), lz_list(i));

    [avg_u_right(i), max_umag(i), react_left(i), cond_est(i)] = ...
        solve_3d_sg_hermite_aniso(Lx,Ly,Lz,E,nu,nelx,nely,nelz, ...
                                  lx_list(i),ly_list(i),lz_list(i), ...
                                  traction_right,body_force,bc_case,false,'');
end

u_ref = avg_u_right(1);
ratio = avg_u_right/u_ref;
applied_Fx = traction_right(1)*Ly*Lz;
reaction_error_percent = 100*abs(react_left + applied_Fx)/abs(applied_Fx);

%% -------------------- Print table --------------------
fprintf('\n===== 3D anisotropic/ellipsoidal length study =====\n');
fprintf('Mesh                 = %d x %d x %d Hermite hex elements\n', nelx, nely, nelz);
fprintf('Domain               = %.4g x %.4g x %.4g m\n', Lx, Ly, Lz);
fprintf('Right traction tx    = %.6e Pa\n', traction_right(1));
fprintf('Applied resultant Fx = %.6e N\n\n', applied_Fx);

fprintf('%18s %8s %8s %8s %20s %20s %14s %14s %14s\n', ...
    'case','lx','ly','lz','avg u right','max |u|','u/u_ref','Rx err %','condest');
fprintf('%18s %8s %8s %8s %20s %20s %14s %14s %14s\n', ...
    '----','--','--','--','-----------','-------','-------','--------','-------');
for i = 1:ncase
    fprintf('%18s %8.4f %8.4f %8.4f %20.12e %20.12e %14.6f %14.6e %14.6e\n', ...
        case_names{i}, lx_list(i), ly_list(i), lz_list(i), ...
        avg_u_right(i), max_umag(i), ratio(i), reaction_error_percent(i), cond_est(i));
end

%% -------------------- Plots --------------------
%% ============================================================
%% MAIN FIGURE : Normalized displacement ratio
%% ============================================================

figure('Color','w','Position',[100 100 850 650]);

bar(ratio,'FaceColor',[0.2 0.45 0.75]);

grid on
box on

set(gca,...
    'XTick',1:ncase,...
    'XTickLabel',case_names,...
    'XTickLabelRotation',35,...
    'FontName','Times New Roman',...
    'FontSize',12,...
    'LineWidth',1.5);

ylabel('$u/u_{\mathrm{ref}}$',...
       'Interpreter','latex',...
       'FontSize',12);

xlabel('Anisotropic length-scale cases',...
       'FontSize',12);

title('Normalized displacement ratio for anisotropic strain-gradient cases',...
      'FontSize',12);

%% ============================================================
%% REPRESENTATIVE FIELD PLOTS ONLY
%% Nearly Classical, Strong-x, All-large
%% ============================================================

selected = [1 6 10];

for kk = 1:numel(selected)

    i = selected(kk);

    solve_3d_sg_hermite_aniso( ...
        Lx,Ly,Lz,E,nu,...
        nelx,nely,nelz,...
        lx_list(i),...
        ly_list(i),...
        lz_list(i),...
        traction_right,...
        body_force,...
        bc_case,...
        true,...
        case_names{i});

end

%% ========================================================================
function [avg_ux_right, max_umag, total_Rx_left, cond_est] = solve_3d_sg_hermite_aniso(...
    Lx,Ly,Lz,E,nu,nelx,nely,nelz,lx,ly,lz,traction_right,body_force,bc_case,do_plots,case_name)

    ax2 = lx^2/10;
    ay2 = ly^2/10;
    az2 = lz^2/10;

    lambda = E*nu/((1+nu)*(1-2*nu));
    mu     = E/(2*(1+nu));
    C = [lambda+2*mu, lambda,      lambda,      0,  0,  0;
         lambda,      lambda+2*mu, lambda,      0,  0,  0;
         lambda,      lambda,      lambda+2*mu, 0,  0,  0;
         0,           0,           0,           mu, 0,  0;
         0,           0,           0,           0,  mu, 0;
         0,           0,           0,           0,  0,  mu];

    nnx = nelx + 1; nny = nely + 1; nnz = nelz + 1;
    nnode = nnx*nny*nnz;
    ndof_per_node = 24;
    ndof = ndof_per_node*nnode;

    xgrid = linspace(0,Lx,nnx);
    ygrid = linspace(0,Ly,nny);
    zgrid = linspace(0,Lz,nnz);
    node_id = @(ix,iy,iz) (iz-1)*nnx*nny + (iy-1)*nnx + ix;
    coords = zeros(nnode,3);
    for iz = 1:nnz
        for iy = 1:nny
            for ix = 1:nnx
                n = node_id(ix,iy,iz);
                coords(n,:) = [xgrid(ix), ygrid(iy), zgrid(iz)];
            end
        end
    end

    conn = zeros(nelx*nely*nelz,8);
    e = 0;
    for ez = 1:nelz
        for ey = 1:nely
            for ex = 1:nelx
                e = e + 1;
                conn(e,:) = [node_id(ex,ey,ez), node_id(ex+1,ey,ez), ...
                             node_id(ex+1,ey+1,ez), node_id(ex,ey+1,ez), ...
                             node_id(ex,ey,ez+1), node_id(ex+1,ey,ez+1), ...
                             node_id(ex+1,ey+1,ez+1), node_id(ex,ey+1,ez+1)];
            end
        end
    end
    nel = size(conn,1);

    K = sparse(ndof,ndof);
    F = zeros(ndof,1);
    [gp, gw] = gauss_1d_01(3);

    for e = 1:nel
        nodes = conn(e,:);
        xy = coords(nodes,:);
        hx = xy(2,1)-xy(1,1);
        hy = xy(4,2)-xy(1,2);
        hz = xy(5,3)-xy(1,3);
        if hx <= 0 || hy <= 0 || hz <= 0
            error('Invalid element geometry at element %d.', e);
        end
        detJ = hx*hy*hz;
        Ke = zeros(192,192);
        Fe = zeros(192,1);

        for ig = 1:length(gp)
            s = gp(ig); ws = gw(ig);
            for jg = 1:length(gp)
                t = gp(jg); wt = gw(jg);
                for kg = 1:length(gp)
                    r = gp(kg); wr = gw(kg);
                    wgt = ws*wt*wr*detJ;
                    [N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz] = hermite_shape_3d(s,t,r,hx,hy,hz);
                    [B,Bx,By,Bz,Nv] = make_B_matrices_3d(N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz);
                    Ke = Ke + (B.'*C*B + ax2*(Bx.'*C*Bx) + ay2*(By.'*C*By) + az2*(Bz.'*C*Bz))*wgt;
                    Fe = Fe + Nv.'*body_force*wgt;
                end
            end
        end
        edofs = element_dofs(nodes,ndof_per_node);
        K(edofs,edofs) = K(edofs,edofs) + Ke;
        F(edofs) = F(edofs) + Fe;
    end

    % Right-face traction
    for ez = 1:nelz
        for ey = 1:nely
            e_right = (ez-1)*nelx*nely + (ey-1)*nelx + nelx;
            nodes = conn(e_right,:);
            xy = coords(nodes,:);
            hx = xy(2,1)-xy(1,1);
            hy = xy(4,2)-xy(1,2);
            hz = xy(5,3)-xy(1,3);
            edofs = element_dofs(nodes,ndof_per_node);
            Fe = zeros(192,1);
            s = 1.0;
            for jg = 1:length(gp)
                t = gp(jg); wt = gw(jg);
                for kg = 1:length(gp)
                    r = gp(kg); wr = gw(kg);
                    faceJ = hy*hz;
                    [N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz] = hermite_shape_3d(s,t,r,hx,hy,hz); %#ok<ASGLU>
                    [~,~,~,~,Nv] = make_B_matrices_3d(N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz);
                    Fe = Fe + Nv.'*traction_right*(wt*wr*faceJ);
                end
            end
            F(edofs) = F(edofs) + Fe;
        end
    end

    % BCs
    fixed_dofs = [];
    left_nodes = [];
    for iz = 1:nnz
        for iy = 1:nny
            left_nodes(end+1) = node_id(1,iy,iz); %#ok<AGROW>
        end
    end
    switch bc_case
        case "clamped_gradient"
            for n = left_nodes
                fixed_dofs = [fixed_dofs, (n-1)*24 + (1:24)]; %#ok<AGROW>
            end
        case "classical_clamp"
            for n = left_nodes
                fixed_dofs = [fixed_dofs, (n-1)*24 + [1,9,17]]; %#ok<AGROW>
            end
        otherwise
            error('Unknown bc_case.');
    end
    fixed_dofs = unique(fixed_dofs);
    free_dofs = setdiff(1:ndof,fixed_dofs);

    % Scaled solve
    Kff = K(free_dofs,free_dofs);
    Ff  = F(free_dofs);
    scale_diag = sqrt(abs(diag(Kff)));
    scale_diag(scale_diag < eps) = 1.0;
    Sscale = spdiags(1./scale_diag,0,length(free_dofs),length(free_dofs));
    Kscaled = Sscale*Kff*Sscale;
    Fscaled = Sscale*Ff;
    cond_est = condest(Kscaled);
    if ~isfinite(cond_est) || cond_est > 1.0e14
        reg = 1.0e-10*mean(abs(diag(Kscaled)));
        if reg == 0 || ~isfinite(reg), reg = 1.0e-10; end
        Kscaled = Kscaled + reg*speye(size(Kscaled));
    end
    y = Kscaled\Fscaled;
    D = zeros(ndof,1);
    D(free_dofs) = Sscale*y;
    R = K*D - F;

    u_nodes = D(1:24:end);
    v_nodes = D(9:24:end);
    w_nodes = D(17:24:end);
    umag = sqrt(u_nodes.^2 + v_nodes.^2 + w_nodes.^2);

    right_nodes = [];
    for iz = 1:nnz
        for iy = 1:nny
            right_nodes(end+1) = node_id(nnx,iy,iz); %#ok<AGROW>
        end
    end
    avg_ux_right = mean(u_nodes(right_nodes));
    max_umag = max(umag);
    left_u_value_dofs = arrayfun(@(n) (n-1)*24+1, left_nodes);
    total_Rx_left = sum(R(left_u_value_dofs));

    if do_plots
        figure('Color','w');
        scatter3(coords(:,1),coords(:,2),coords(:,3),55,umag,'filled');
        axis equal tight; colorbar; grid on;
        xlabel('x'); ylabel('y'); zlabel('z');
        title(sprintf('%s: |u|, lx=%.3f, ly=%.3f, lz=%.3f', case_name, lx, ly, lz));
        view(35,25);
    end
end

%% ========================================================================
function edofs = element_dofs(nodes,ndof_per_node)
    edofs = zeros(1,numel(nodes)*ndof_per_node);
    c = 0;
    for a = 1:numel(nodes)
        n = nodes(a);
        edofs(c+1:c+ndof_per_node) = (n-1)*ndof_per_node + (1:ndof_per_node);
        c = c + ndof_per_node;
    end
end

function [gp,gw] = gauss_1d_01(n)
    switch n
        case 3
            x = [-sqrt(3/5), 0, sqrt(3/5)];
            w = [5/9, 8/9, 5/9];
        otherwise
            error('Only n=3 implemented here.');
    end
    gp = (x+1)/2;
    gw = w/2;
end

function [H0,H1,H0x,H1x,H0xx,H1xx] = hermite_1d_two_nodes(s,L)
    h1 = 1 - 3*s^2 + 2*s^3;
    h2 = L*(s - 2*s^2 + s^3);
    h3 = 3*s^2 - 2*s^3;
    h4 = L*(-s^2 + s^3);
    dh1 = -6*s + 6*s^2;
    dh2 = L*(1 - 4*s + 3*s^2);
    dh3 = 6*s - 6*s^2;
    dh4 = L*(-2*s + 3*s^2);
    d2h1 = -6 + 12*s;
    d2h2 = L*(-4 + 6*s);
    d2h3 = 6 - 12*s;
    d2h4 = L*(-2 + 6*s);
    H0 = [h1, h3]; H1 = [h2, h4];
    H0x = (1/L)*[dh1, dh3]; H1x = (1/L)*[dh2, dh4];
    H0xx = (1/L^2)*[d2h1, d2h3]; H1xx = (1/L^2)*[d2h2, d2h4];
end

function [N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz] = hermite_shape_3d(s,t,r,hx,hy,hz)
    [Hx0,Hx1,Hx0x,Hx1x,Hx0xx,Hx1xx] = hermite_1d_two_nodes(s,hx);
    [Hy0,Hy1,Hy0y,Hy1y,Hy0yy,Hy1yy] = hermite_1d_two_nodes(t,hy);
    [Hz0,Hz1,Hz0z,Hz1z,Hz0zz,Hz1zz] = hermite_1d_two_nodes(r,hz);
    xs = [1 2 2 1 1 2 2 1];
    ys = [1 1 2 2 1 1 2 2];
    zs = [1 1 1 1 2 2 2 2];
    combos = [0 0 0; 1 0 0; 0 1 0; 0 0 1; 1 1 0; 1 0 1; 0 1 1; 1 1 1];
    N=zeros(1,64); Nx=N; Ny=N; Nz=N; Nxx=N; Nyy=N; Nzz=N; Nxy=N; Nxz=N; Nyz=N;
    for a = 1:8
        ix=xs(a); iy=ys(a); iz=zs(a); p=(a-1)*8;
        for q=1:8
            cx=combos(q,1); cy=combos(q,2); cz=combos(q,3);
            [X,Xx,Xxx] = pickH(cx,ix,Hx0,Hx1,Hx0x,Hx1x,Hx0xx,Hx1xx);
            [Y,Yy,Yyy] = pickH(cy,iy,Hy0,Hy1,Hy0y,Hy1y,Hy0yy,Hy1yy);
            [Z,Zz,Zzz] = pickH(cz,iz,Hz0,Hz1,Hz0z,Hz1z,Hz0zz,Hz1zz);
            id=p+q;
            N(id)=X*Y*Z; Nx(id)=Xx*Y*Z; Ny(id)=X*Yy*Z; Nz(id)=X*Y*Zz;
            Nxx(id)=Xxx*Y*Z; Nyy(id)=X*Yyy*Z; Nzz(id)=X*Y*Zzz;
            Nxy(id)=Xx*Yy*Z; Nxz(id)=Xx*Y*Zz; Nyz(id)=X*Yy*Zz;
        end
    end
end

function [H,Hd,Hdd] = pickH(flag,idx,H0,H1,H0d,H1d,H0dd,H1dd)
    if flag == 0
        H=H0(idx); Hd=H0d(idx); Hdd=H0dd(idx);
    else
        H=H1(idx); Hd=H1d(idx); Hdd=H1dd(idx);
    end
end

function [B,Bx,By,Bz,Nv] = make_B_matrices_3d(N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz)
    B=zeros(6,192); Bx=B; By=B; Bz=B; Nv=zeros(3,192);
    for a=1:8
        sp=(a-1)*8+(1:8); up=(a-1)*24+(1:8); vp=(a-1)*24+(9:16); wp=(a-1)*24+(17:24);
        Nv(1,up)=N(sp); Nv(2,vp)=N(sp); Nv(3,wp)=N(sp);
        B(1,up)=Nx(sp); B(2,vp)=Ny(sp); B(3,wp)=Nz(sp);
        B(4,vp)=Nz(sp); B(4,wp)=Ny(sp);
        B(5,up)=Nz(sp); B(5,wp)=Nx(sp);
        B(6,up)=Ny(sp); B(6,vp)=Nx(sp);
        Bx(1,up)=Nxx(sp); Bx(2,vp)=Nxy(sp); Bx(3,wp)=Nxz(sp);
        Bx(4,vp)=Nxz(sp); Bx(4,wp)=Nxy(sp); Bx(5,up)=Nxz(sp); Bx(5,wp)=Nxx(sp); Bx(6,up)=Nxy(sp); Bx(6,vp)=Nxx(sp);
        By(1,up)=Nxy(sp); By(2,vp)=Nyy(sp); By(3,wp)=Nyz(sp);
        By(4,vp)=Nyz(sp); By(4,wp)=Nyy(sp); By(5,up)=Nyz(sp); By(5,wp)=Nxy(sp); By(6,up)=Nyy(sp); By(6,vp)=Nxy(sp);
        Bz(1,up)=Nxz(sp); Bz(2,vp)=Nyz(sp); Bz(3,wp)=Nzz(sp);
        Bz(4,vp)=Nzz(sp); Bz(4,wp)=Nyz(sp); Bz(5,up)=Nzz(sp); Bz(5,wp)=Nxz(sp); Bz(6,up)=Nyz(sp); Bz(6,vp)=Nxz(sp);
    end
end
