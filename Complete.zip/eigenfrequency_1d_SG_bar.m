%% eigenfrequency_1d_SG_bar.m
%
% Free-vibration analysis of a 1D strain-gradient bar using C1 Hermite FEM.
%
% Strain-gradient energy:
%   U = 1/2 int_0^L EA[(u')^2 + a^2(u'')^2] dx
% where
%   a^2 = l_micro^2/10.
%
% Semi-discrete eigenvalue problem:
%   K phi = omega^2 M phi
%
% DOFs per node: [u_i, theta_i]^T,  theta_i = du/dx at node i.
%
% Boundary condition (SG bar):
%   u(0)=0, theta(0)=u'(0)=0.  Right end is natural/free.
%
% NOTE:
%   For l=0, the slope boundary condition is not a classical axial-bar
%   boundary condition. Therefore, a separate standard C0 linear FEM
%   classical reference is computed with u(0)=0 only.

clear; clc; close all;

% ── Root defaults (consistent with Fig01 and Fig02) ───────────────────────
set(groot,'defaultAxesFontName',             'Times New Roman');
set(groot,'defaultAxesFontSize',             10);
set(groot,'defaultTextFontName',             'Times New Roman');
set(groot,'defaultTextFontSize',             10);
set(groot,'defaultAxesTickLabelInterpreter', 'tex');
set(groot,'defaultTextInterpreter',          'tex');

%% ==================== Input data ====================

L    = 1.0;          % length, m
E    = 200e9;        % Young's modulus, Pa
Area = 1.0e-4;       % area, m^2
rho  = 7800;         % density, kg/m^3

nel     = 120;       % number of Hermite elements
n_modes = 6;         % number of modes to extract and plot

% Microstructural lengths for frequency study
l_list = [0.005 0.01 0.02 0.05 0.075 0.10 0.15 0.20];

%% ==================== Classical reference (C0 linear FEM) ====================

[omega_cl, freq_cl, xlin, modes_cl] = solve_classical_bar_eigen_linearFEM(...
    nel, L, E, Area, rho, n_modes);

fprintf('\n===== Classical axial bar reference: C0 linear FEM =====\n');
fprintf('Boundary condition: u(0)=0, free at x=L\n');
fprintf('%8s %20s %20s\n','mode','omega rad/s','frequency Hz');
for m = 1:n_modes
    fprintf('%8d %20.8e %20.8e\n', m, omega_cl(m), freq_cl(m));
end

%% ==================== SG frequency study (C1 Hermite FEM) ====================

omega_sg = zeros(length(l_list), n_modes);
freq_sg  = zeros(length(l_list), n_modes);

for i = 1:length(l_list)
    l_micro = l_list(i);
    a2      = l_micro^2 / 10;
    [omega_i, freq_i] = solve_sg_bar_eigen_hermite(...
        nel, L, E, Area, rho, a2, n_modes);
    omega_sg(i,:) = omega_i(:).';
    freq_sg(i,:)  = freq_i(:).';
end

%% ==================== Print tables ====================

fprintf('\n===== Strain-gradient bar frequency study: C1 Hermite FEM =====\n');
fprintf('Boundary condition: u(0)=0 and u''(0)=0; free at x=L\n');
fprintf('nel = %d\n\n', nel);

header = sprintf('%10s','l_micro');
for m = 1:n_modes
    header = [header, sprintf('%18s',['f',num2str(m),' (Hz)'])]; %#ok<AGROW>
end
fprintf('%s\n', header);
fprintf('%s\n', repmat('-',1,length(header)));
for i = 1:length(l_list)
    line = sprintf('%10.5f', l_list(i));
    for m = 1:n_modes
        line = [line, sprintf('%18.6e', freq_sg(i,m))]; %#ok<AGROW>
    end
    fprintf('%s\n', line);
end

freq_ratio = freq_sg ./ freq_cl(:).';

fprintf('\n===== Normalized SG frequencies f_SG/f_classical =====\n');
header = sprintf('%10s','l_micro');
for m = 1:n_modes
    header = [header, sprintf('%14s',['mode ',num2str(m)])]; %#ok<AGROW>
end
fprintf('%s\n', header);
fprintf('%s\n', repmat('-',1,length(header)));
for i = 1:length(l_list)
    line = sprintf('%10.5f', l_list(i));
    for m = 1:n_modes
        line = [line, sprintf('%14.6f', freq_ratio(i,m))]; %#ok<AGROW>
    end
    fprintf('%s\n', line);
end


%% =========================================================================
%%  PUBLICATION-QUALITY FIGURE — FREE-VIBRATION PARAMETRIC STUDY
%%
%%  TWO-PANEL composite figure:
%%    (a) Natural frequencies (kHz) vs l/L  — all 6 modes
%%    (b) Normalised frequency ratio f_SG/f_classical vs l/L — all 6 modes
%%
%%  Mode shapes → Supplementary Material (FigS2_ModeShapes)
%%
%%  Visual identity: matches Fig01_1D_BoundaryLayer and Fig02_MicroLengthEffect.
%%  Uses identical styleAxes() and exportFig() utility functions.
%%
%%  INSERT LOCATION:
%%    Replace everything from "%% FIGURE C1" through the end of
%%    "%% FIGURE C3" (including the mode-shape figure block) with this block.
%%    All local functions below remain unchanged.
%%
%%  DO NOT modify any computed array above this block.
%% =========================================================================

% ── Unit conversion ────────────────────────────────────────────────────────
%  Frequencies: freq_sg is in Hz.  Divide by 1000 for kHz.
%  kHz gives clean axis ticks (0–20 kHz) with no scientific notation.
%  This is consistent with the engineering-scale unit convention of Fig01/02.
%  x-axis: l/L (dimensionless, L=1 m so numerically equal to l in metres,
%  but dimensionless and consistent with Fig01/02).

freq_sg_kHz  = freq_sg  / 1000;    % Hz → kHz
% freq_cl_kHz removed (dead variable — see note above)
lL           = l_list   / L;       % l/L  (dimensionless x-axis)

% ── Colour palette — Wong (2011), exactly 6 colours for 6 modes ───────────
%  Colorblind-safe; print-safe.  Same palette as Fig01/02 (first 6 entries).
C_modes = [
    0.000, 0.447, 0.698;   % Mode 1 — Blue
    0.851, 0.325, 0.098;   % Mode 2 — Vermillion
    0.929, 0.694, 0.125;   % Mode 3 — Orange
    0.000, 0.620, 0.451;   % Mode 4 — Green
    0.502, 0.000, 0.502;   % Mode 5 — Purple
    0.302, 0.600, 0.898;   % Mode 6 — Sky Blue
];

% AUDIT FIX: Remove dead variable freq_cl_kHz (defined but never used).
% freq_cl_kHz  = freq_cl / 1000;   % removed — unused

% ── Line width (identical to Fig01/02) ────────────────────────────────────
LW = 1.5;    % primary line width (pt)

% ── Figure dimensions (identical to Fig02_MicroLengthEffect) ──────────────
%  Two-panel horizontal layout at double-column width.
%  Six mode lines per panel require 4 mm extra height for the taller legend.
fig_w_mm = 176;   % double-column width — same as Fig01 and Fig02
fig_h_mm =  82;   % 10 mm taller than Fig01/02 to accommodate 6-entry legend

fig = figure('Color','white', ...
             'Units','centimeters', ...
             'Position',[2, 2, fig_w_mm/10, fig_h_mm/10]);

% ── Two-panel tiled layout (same spacing as Fig01/02) ─────────────────────
tl = tiledlayout(1, 2, ...
    'TileSpacing', 'compact', ...
    'Padding',     'compact');

% =========================================================================
%  Panel (a) — Natural frequencies (kHz) vs l/L
%
%  All 6 modes plotted as continuous curves (no markers needed —
%  6 distinct colours provide sufficient visual discrimination).
%  Frequencies increase monotonically with l/L for every mode,
%  with higher modes showing greater absolute enhancement.
% =========================================================================
ax1 = nexttile(tl, 1);

% AUDIT FIX: hold called once before loop, not redundantly inside it.
hold(ax1, 'on');
for m = 1:n_modes
    plot(ax1, lL, freq_sg_kHz(:,m), ...
        'Color',     C_modes(m,:), ...
        'LineStyle', '-', ...
        'LineWidth', LW);
end

styleAxes(ax1);

xlabel(ax1, 'l/L', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

ylabel(ax1, 'Natural frequency (kHz)', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

% x-axis: start from 0 even though smallest l/L = 0.005
xlim(ax1, [0, max(lL)]);
ylim(ax1, [0, max(freq_sg_kHz(:)) * 1.10]);

% Legend panel (a) — free-form positioning via normalized axes coordinates.
% Adjust the four values in 'Position' [left bottom width height] to place
% the legend anywhere you like without it being anchored to a corner keyword.
%   left   = 0 is the left edge of the axes,  1 is the right edge
%   bottom = 0 is the bottom edge of the axes, 1 is the top edge
%   width and height are fractions of the axes size
% Current setting places the box in the lower-left area, clear of all curves.
leg_entries = arrayfun(@(m) sprintf('Mode %d', m), 1:n_modes, 'UniformOutput', false);
leg1 = legend(ax1, leg_entries, ...
    'FontName',   'Times New Roman', ...
    'FontSize',   9.5, ...
    'Box',        'on', ...
    'EdgeColor',  [0.4, 0.4, 0.4], ...
    'Interpreter','tex');
% ── Move legend to your preferred position ────────────────────────────────
% Change the four numbers [left, bottom, width, height] freely.
% Example positions (normalized units relative to the axes):
%   Lower-left  : [0.04, 0.04, 0.28, 0.42]
%   Upper-left  : [0.04, 0.55, 0.28, 0.42]
%   Lower-right : [0.68, 0.04, 0.28, 0.42]
%   Upper-right : [0.68, 0.55, 0.28, 0.42]
leg1.Units    = 'normalized';
leg1.Position = [0.04, 0.04, 0.28, 0.42];   % ← edit these four values freely

% Panel label
text(ax1, 0.04, 0.93, '(a)', ...
    'Units',      'normalized', ...
    'FontName',   'Times New Roman', ...
    'FontSize',   11, ...
    'FontWeight', 'bold', ...
    'Interpreter','none');

% =========================================================================
%  Panel (b) — Normalised frequency ratio f_SG/f_classical vs l/L
%
%  Classical reference: C0 linear FEM with u(0)=0 only (free right end).
%  SG bar: u(0)=theta(0)=0 (clamped slope).
%  The ratio exceeds 1.0 for all modes because the SG model stiffens the
%  response via the gradient energy term.  Higher modes show a larger
%  enhancement because short-wavelength deformation patterns incur
%  proportionally larger strain-gradient energy penalties.
%
%  Note: the ratio at the smallest l/L value is NOT necessarily 1.0
%  because the boundary conditions of the two models differ.
% =========================================================================
ax2 = nexttile(tl, 2);

% Reference line at ratio = 1.0 (classical limit, for visual orientation)
yline(ax2, 1.0, ...
    'Color',     [0.5, 0.5, 0.5], ...
    'LineStyle', ':', ...
    'LineWidth', 0.8);
hold(ax2, 'on');

for m = 1:n_modes
    plot(ax2, lL, freq_ratio(:,m), ...
        'Color',     C_modes(m,:), ...
        'LineStyle', '-', ...
        'LineWidth', LW);
end

styleAxes(ax2);

xlabel(ax2, 'l/L', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

ylabel(ax2, 'f_{SG} / f_{classical}', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

xlim(ax2, [0, max(lL)]);
% Lower bound slightly below 1 to show the reference line clearly
r_min = min(freq_ratio(:));
r_max = max(freq_ratio(:));
ylim(ax2, [min(0.98, r_min - 0.02*(r_max-r_min)), ...
           r_max + 0.06*(r_max-r_min)]);

% Legend panel (b) — free-form positioning, same mechanism as panel (a).
% Adjust 'Position' [left bottom width height] independently of panel (a).
leg2 = legend(ax2, leg_entries, ...
    'FontName',   'Times New Roman', ...
    'FontSize',   9.5, ...
    'Box',        'on', ...
    'EdgeColor',  [0.4, 0.4, 0.4], ...
    'Interpreter','tex');
% ── Move legend to your preferred position ────────────────────────────────
% Same coordinate system as panel (a) — normalized to this axes box.
% Example: lower-left of panel (b), just above the y = 1 reference line.
leg2.Units    = 'normalized';
leg2.Position = [0.04, 0.04, 0.28, 0.42];   % ← edit these four values freely

% Panel label
text(ax2, 0.04, 0.93, '(b)', ...
    'Units',      'normalized', ...
    'FontName',   'Times New Roman', ...
    'FontSize',   11, ...
    'FontWeight', 'bold', ...
    'Interpreter','none');

% ── Export main figure ─────────────────────────────────────────────────────
exportFig(fig, 'Fig03_FrequencyStudy', fig_w_mm, fig_h_mm);


%% =========================================================================
%%  SUPPLEMENTARY FIGURE — Mode Shapes
%%
%%  Classification: Supplementary Material  (FigS2_ModeShapes)
%%
%%  Scientific justification for exclusion from main manuscript:
%%    1. The mode shapes of the SG bar are smooth sinusoidal profiles
%%       qualitatively identical to classical bar modes. They confirm
%%       the formulation is numerically stable but contain no information
%%       not already captured by the frequency values in panels (a) and (b).
%%    2. The scientific message of this figure — frequency enhancement
%%       with l/L — is fully communicated by panels (a) and (b).
%%    3. Including a 3-panel main figure with mode shapes would require
%%       a figure* environment with reduced panel sizes, making the
%%       frequency curves harder to read at journal print width.
%%    4. Mode shapes are standard validation output; placing them in
%%       supplementary material follows the convention of CMAME, AMM,
%%       and IJES for FEM verification figures.
%% =========================================================================

l_selected = 0.05;
a2_selected = l_selected^2 / 10;

[omega_sel, freq_sel, xh, Dh_modes] = solve_sg_bar_eigen_hermite(...
    nel, L, E, Area, rho, a2_selected, n_modes);

fig_s = figure('Color','white', ...
               'Units','centimeters', ...
               'Position',[22, 2, 88/10, 80/10]);   % single-column

ax_s = axes(fig_s);
hold(ax_s, 'on');

for m = 1:n_modes
    [xplot, uplot] = evaluate_hermite_mode_shape(xh, Dh_modes(:,m), nel, 30);
    uplot = uplot / max(abs(uplot));
    plot(ax_s, xplot/L, uplot, ...
        'Color',     C_modes(m,:), ...
        'LineStyle', '-', ...
        'LineWidth', LW);
end

styleAxes(ax_s);

xlabel(ax_s, 'x/L', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

ylabel(ax_s, 'Normalised mode shape', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

ylim(ax_s, [-1.15, 1.15]);

leg_s = legend(ax_s, leg_entries, ...
    'FontName',   'Times New Roman', ...
    'FontSize',   9.5, ...
    'Box',        'on', ...
    'EdgeColor',  [0.4, 0.4, 0.4], ...
    'Interpreter','tex');
% Free-form position for supplementary mode-shape figure.
leg_s.Units    = 'normalized';
leg_s.Position = [0.68, 0.04, 0.28, 0.42];  % ← edit freely

exportFig(fig_s, 'FigS2_ModeShapes', 88, 80);


%% ==================== Local functions ====================

% ─────────────────────────────────────────────────────────────────────────
function styleAxes(ax)
% styleAxes — Uniform publication axis style.
%   Identical to Fig01_1D_BoundaryLayer and Fig02_MicroLengthEffect.
%   Times New Roman 10 pt, box on, inward ticks, dotted grid alpha=0.35,
%   no minor grid, axis frame 0.8 pt, TickLabelInterpreter='tex'.
set(ax, ...
    'FontName',             'Times New Roman', ...
    'FontSize',             10, ...
    'LineWidth',            0.8, ...
    'Box',                  'on', ...
    'TickDir',              'in', ...
    'TickLength',           [0.015, 0.015], ...
    'XMinorTick',           'off', ...
    'YMinorTick',           'off', ...
    'GridLineStyle',        ':', ...
    'GridAlpha',            0.35, ...
    'MinorGridLineStyle',   'none', ...
    'TickLabelInterpreter', 'tex');
grid(ax, 'on');
end


% ─────────────────────────────────────────────────────────────────────────
function exportFig(figHandle, filename, width_mm, height_mm)
% exportFig — Export figure to EPS (vector), PDF (vector), PNG (600 dpi).
%   Identical to Fig01 and Fig02 export function.
%   PaperPositionMode='manual' prevents MATLAB default centering.
set(figHandle, 'Renderer', 'painters');

w_cm = width_mm  / 10;
h_cm = height_mm / 10;

set(figHandle, 'Units',             'centimeters');
set(figHandle, 'Position',          [2, 2, w_cm, h_cm]);
set(figHandle, 'PaperUnits',        'centimeters');
set(figHandle, 'PaperPositionMode', 'manual');
set(figHandle, 'PaperSize',         [w_cm, h_cm]);
set(figHandle, 'PaperPosition',     [0, 0, w_cm, h_cm]);

print(figHandle, [filename, '.eps'], '-depsc', '-r0');
print(figHandle, [filename, '.pdf'], '-dpdf',  '-r0');
print(figHandle, [filename, '.png'], '-dpng',  '-r600');

fprintf('\n[exportFig] Saved  : %s  (.eps / .pdf / .png)\n', filename);
fprintf('[exportFig] Size   : %.0f x %.0f mm\n', width_mm, height_mm);
end


% ─────────────────────────────────────────────────────────────────────────
function [omega, freq, xnode, modes_full] = solve_sg_bar_eigen_hermite(...
    nel,L,E,A,rho,a2,n_modes)

    nn   = nel + 1;
    ndof = 2*nn;
    xnode = linspace(0,L,nn).';
    conn  = [(1:nel).' (2:nel+1).'];

    K = zeros(ndof,ndof);
    M = zeros(ndof,ndof);

    gp_xi = [-sqrt(3/5), 0, sqrt(3/5)];
    gp_w  = [5/9, 8/9, 5/9];

    for e = 1:nel
        n1 = conn(e,1);
        n2 = conn(e,2);
        Le = xnode(n2)-xnode(n1);
        ke = zeros(4,4);
        me = zeros(4,4);
        for gp = 1:length(gp_xi)
            xi = gp_xi(gp);
            w  = gp_w(gp);
            s  = (xi+1)/2;
            J  = Le/2;
            [N,B1,B2] = hermite_shape_1d(s,Le);
            ke = ke + E*A*(B1.'*B1 + a2*(B2.'*B2))*J*w;
            me = me + rho*A*(N.'*N)*J*w;
        end
        edofs = [2*n1-1, 2*n1, 2*n2-1, 2*n2];
        K(edofs,edofs) = K(edofs,edofs) + ke;
        M(edofs,edofs) = M(edofs,edofs) + me;
    end

    % SG essential BC: u(0)=0, theta(0)=0
    fixed = [1 2];
    free  = setdiff(1:ndof, fixed);
    Kff   = K(free,free);
    Mff   = M(free,free);

    [V,D] = eig(Kff, Mff);
    lam   = real(diag(D));
    lam(lam < 0 & abs(lam) < 1e-8) = 0;
    [lam_sorted, idx] = sort(lam, 'ascend');
    V = V(:,idx);

    omega_all = sqrt(lam_sorted);
    positive  = omega_all > 1e-6;
    omega_all = omega_all(positive);
    V = V(:,positive);

    omega = omega_all(1:n_modes);
    freq  = omega / (2*pi);

    modes_full = zeros(ndof, n_modes);
    for m = 1:n_modes
        modes_full(free,m) = V(:,m);
        u_dofs = modes_full(1:2:end,m);
        modes_full(:,m) = modes_full(:,m) / max(abs(u_dofs));
    end
end


% ─────────────────────────────────────────────────────────────────────────
function [omega, freq, xnode, modes_full] = solve_classical_bar_eigen_linearFEM(...
    nel,L,E,A,rho,n_modes)

    nn    = nel + 1;
    xnode = linspace(0,L,nn).';
    conn  = [(1:nel).' (2:nel+1).'];

    K = zeros(nn,nn);
    M = zeros(nn,nn);

    for e = 1:nel
        n1 = conn(e,1);
        n2 = conn(e,2);
        Le = xnode(n2)-xnode(n1);
        ke = E*A/Le * [1 -1; -1 1];
        me = rho*A*Le/6 * [2 1; 1 2];
        edofs = [n1 n2];
        K(edofs,edofs) = K(edofs,edofs) + ke;
        M(edofs,edofs) = M(edofs,edofs) + me;
    end

    fixed = 1;
    free  = setdiff(1:nn, fixed);

    [V,D] = eig(K(free,free), M(free,free));
    lam   = real(diag(D));
    [lam_sorted, idx] = sort(lam, 'ascend');
    V = V(:,idx);

    omega_all = sqrt(lam_sorted);
    omega     = omega_all(1:n_modes);
    freq      = omega / (2*pi);

    modes_full = zeros(nn, n_modes);
    for m = 1:n_modes
        modes_full(free,m) = V(:,m);
        modes_full(:,m)    = modes_full(:,m) / max(abs(modes_full(:,m)));
    end
end


% ─────────────────────────────────────────────────────────────────────────
function [N,B1,B2] = hermite_shape_1d(s,Le)

    N1 = 1 - 3*s^2 + 2*s^3;
    N2 = Le*(s - 2*s^2 + s^3);
    N3 = 3*s^2 - 2*s^3;
    N4 = Le*(-s^2 + s^3);
    N  = [N1, N2, N3, N4];

    dN1 = -6*s + 6*s^2;
    dN2 = Le*(1 - 4*s + 3*s^2);
    dN3 = 6*s - 6*s^2;
    dN4 = Le*(-2*s + 3*s^2);
    B1  = (1/Le)*[dN1, dN2, dN3, dN4];

    d2N1 = -6 + 12*s;
    d2N2 = Le*(-4 + 6*s);
    d2N3 = 6 - 12*s;
    d2N4 = Le*(-2 + 6*s);
    B2   = (1/Le^2)*[d2N1, d2N2, d2N3, d2N4];
end


% ─────────────────────────────────────────────────────────────────────────
function [xplot,uplot] = evaluate_hermite_mode_shape(xnode,D,nel,nper)

    xplot = [];
    uplot = [];

    for e = 1:nel
        n1   = e;
        n2   = e + 1;
        Le   = xnode(n2) - xnode(n1);
        edofs = [2*n1-1, 2*n1, 2*n2-1, 2*n2];
        de   = D(edofs);
        for a = 1:nper
            s          = (a-1)/(nper-1);
            [N,~,~]    = hermite_shape_1d(s, Le);
            xplot(end+1,1) = xnode(n1) + s*Le; %#ok<AGROW>
            uplot(end+1,1) = N*de;              %#ok<AGROW>
        end
    end
end
