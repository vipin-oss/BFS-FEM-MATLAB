%% mesh_convergence_2D_BFS_plane_strain.m
%
% Mesh convergence study for 2D plane-strain strain-gradient elasticity
% using C1 Bogner-Fox-Schmit rectangular elements.
%
% Model:
%   W = 1/2 eps^T C eps + 1/2 a^2[(eps_x)^T C eps_x + (eps_y)^T C eps_y]
%   a^2 = l_micro^2/10
%
% Problem:
%   Rectangular domain [0,Lx]x[0,Ly]
%   Left edge: strain-gradient clamped
%   Right edge: uniform traction tx
%
% Quantity checked:
%   average right-edge displacement \bar{u}(Lx)
%
% -------------------------------------------------------------------------
%  FIGURE PACKAGE (publication-ready, matches Fig01-Fig04 style exactly):
%    MAIN   : Fig05  (a) u_R (um) vs total DOFs ; (b) rel. error (%) vs h
%    APPENDIX: FigA3 reaction-balance error ; FigA4 condition number
% -------------------------------------------------------------------------

clear; clc; close all;

% ── Root defaults — IDENTICAL to all 1D/2D figures in this manuscript ─────
set(groot, 'defaultAxesFontName',             'Times New Roman');
set(groot, 'defaultAxesFontSize',             10);
set(groot, 'defaultTextFontName',             'Times New Roman');
set(groot, 'defaultTextFontSize',             10);
set(groot, 'defaultAxesTickLabelInterpreter', 'tex');
set(groot, 'defaultTextInterpreter',          'tex');

%% -------------------- Input data --------------------
Lx = 1.0;
Ly = 0.20;
E  = 200e9;
nu = 0.30;
thickness = 1.0;
l_micro = 0.05;
traction_right = [1.0e6; 0.0];
body_force = [0.0; 0.0];
bc_case = "clamped_gradient";

% Keep element aspect ratio approximately constant: nelx/nely = Lx/Ly = 5
mesh_list = [5 1;
             10 2;
             15 3;
             20 4;
             30 6;
             40 8];
ncase = size(mesh_list,1);

avg_u_right = zeros(ncase,1);
max_umag    = zeros(ncase,1);
react_left  = zeros(ncase,1);
cond_est    = zeros(ncase,1);
ndof_list   = zeros(ncase,1);
h_list      = zeros(ncase,1);

%% -------------------- Run mesh convergence --------------------
for i = 1:ncase
    nelx = mesh_list(i,1);
    nely = mesh_list(i,2);
    fprintf('\n--- Solving mesh %d x %d ---\n', nelx, nely);
    [avg_u_right(i), max_umag(i), react_left(i), cond_est(i), ndof_list(i)] = ...
        solve_2d_sg_bfs(Lx,Ly,E,nu,thickness,nelx,nely,l_micro, ...
                        traction_right,body_force,bc_case,false);
    h_list(i) = Lx/nelx;
end

% Use finest mesh as reference
u_ref = avg_u_right(end);
err_percent = 100*abs(avg_u_right - u_ref)/abs(u_ref);

applied_Fx = traction_right(1)*Ly*thickness;
reaction_error_percent = 100*abs(react_left + applied_Fx)/abs(applied_Fx);

%% -------------------- Print table --------------------
fprintf('\n===== 2D SG mesh convergence study =====\n');
fprintf('l_micro              = %.6e m\n', l_micro);
fprintf('a=l/sqrt(10)         = %.6e m\n', l_micro/sqrt(10));
fprintf('Domain               = %.4g x %.4g m\n', Lx, Ly);
fprintf('Right traction tx    = %.6e Pa\n', traction_right(1));
fprintf('Applied resultant Fx = %.6e N\n', applied_Fx);
fprintf('Reference mesh       = %d x %d\n\n', mesh_list(end,1), mesh_list(end,2));

fprintf('%8s %8s %10s %14s %20s %16s %16s %16s\n', ...
    'nelx','nely','DOFs','h','avg u right','error (%)','Rx error (%)','condest');
fprintf('%8s %8s %8s %14s %20s %16s %16s %16s\n', ...
    '----','----','----','-','-----------','---------','------------','-------');
for i = 1:ncase
    fprintf('%8d %8d %10d %14.6e %20.12e %16.6e %16.6e %16.6e\n', ...
        mesh_list(i,1), mesh_list(i,2), ndof_list(i), h_list(i), ...
        avg_u_right(i), err_percent(i), reaction_error_percent(i), cond_est(i));
end

%% ========================================================================
%%  PUBLICATION-QUALITY FIGURE — 2D MESH CONVERGENCE STUDY
%%
%%  Two-panel composite figure (MAIN manuscript):
%%    (a) Average right-edge displacement  bar_u_R  (um)  vs  total DOFs
%%    (b) Relative error (%)  vs  element size  h = Lx / nelx   (log-log)
%%
%%  Appendix figures (reaction error, condition number) generated separately
%%  below this block.
%%
%%  Visual identity: matches Fig01_1D_BoundaryLayer, Fig02_MicroLengthEffect,
%%  Fig03_EigenfrequencyResponse and Fig04_2D_MicroLengthEffect exactly.
%%  Uses identical styleAxes() and exportFig() utility functions.
%% ========================================================================

% ── Unit conversion ────────────────────────────────────────────────────────
%  avg_u_right is in metres; multiply by 1e6 for micrometres.
%  Consistent with the um convention of Fig02 and Fig04.
u_R_um = avg_u_right * 1e6;          % metres -> um

%  Relative error is already in %. The zero-error reference point (finest
%  mesh) is floored at machine eps ONLY for log-scale plotting; the error
%  CALCULATION itself is unchanged.
err_plot = max(err_percent, eps);

% ── Colour (Wong 2011, entry 1 — blue, identical to all figures) ───────────
C_blue = [0.000, 0.447, 0.698];

% ── Line and marker constants (identical to all figures) ──────────────────
LW = 1.5;     % primary line width
MS = 6;       % marker size

% ── Shared x-range margin for DOF abscissa (panels a, A3, A4) ─────────────
x_span = max(ndof_list) - min(ndof_list);
xlim_dof = [min(ndof_list)-0.05*x_span, max(ndof_list)+0.05*x_span];

% ── Figure dimensions — identical to Fig02 / Fig04 ────────────────────────
fig_w_mm = 176;   % double-column width (mm)
fig_h_mm =  72;   % height (mm)
fig = figure('Color','white', ...
             'Units','centimeters', ...
             'Position',[2, 2, fig_w_mm/10, fig_h_mm/10]);

% ── Two-panel tiled layout (same spacing as all 1D/2D figures) ────────────
tl = tiledlayout(1, 2, ...
    'TileSpacing', 'compact', ...
    'Padding',     'compact');

% =========================================================================
%  Panel (a) — Average right-edge displacement vs total DOFs
% =========================================================================
ax1 = nexttile(tl, 1);
plot(ax1, ndof_list, u_R_um, ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       LW, ...
    'Marker',          'o', ...
    'MarkerSize',      MS, ...
    'MarkerFaceColor', 'white');
styleAxes(ax1);
xlabel(ax1, 'Total degrees of freedom', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
ylabel(ax1, 'Avg. right-edge displacement (\mum)', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

% Axis limits: 8% headroom below minimum, 4% above maximum (Fig02/Fig04 rule)
u_span = max(u_R_um) - min(u_R_um);
xlim(ax1, xlim_dof);
ylim(ax1, [min(u_R_um) - 0.08*u_span,  max(u_R_um) + 0.04*u_span]);

% Panel label — identical position/style to all figures
text(ax1, 0.14, 0.93, '(a)', ...
    'Units',       'normalized', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11, ...
    'FontWeight',  'bold', ...
    'Interpreter', 'none');

% =========================================================================
%  Panel (b) — Relative error vs element size  (log-log)
%
%  XDir is reversed so that mesh refinement progresses left -> right,
%  giving the same reading direction as panel (a). The error calculation
%  and the finest-mesh reference are unchanged.
% =========================================================================
ax2 = nexttile(tl, 2);
loglog(ax2, h_list, err_plot, ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       LW, ...
    'Marker',          'o', ...
    'MarkerSize',      MS, ...
    'MarkerFaceColor', 'white');
set(ax2, 'XDir', 'reverse');                  % refinement progresses L -> R
styleAxes(ax2);
xlabel(ax2, 'Element size, h = L_x/n_{elx} (m)', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
ylabel(ax2, 'Relative error (\%)', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

% Log-scale limits with a half-decade margin
xlim(ax2, [min(h_list)*0.8, max(h_list)*1.25]);
ylim(ax2, [min(err_plot(err_plot > 0))*0.5,  max(err_plot)*2]);

% Panel label
text(ax2, 0.14, 0.93, '(b)', ...
    'Units',       'normalized', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11, ...
    'FontWeight',  'bold', ...
    'Interpreter', 'none');

% ── Export main figure ────────────────────────────────────────────────────
exportFig(fig, 'Fig05_2D_MeshConvergence', fig_w_mm, fig_h_mm);

%% ========================================================================
%%  APPENDIX FIGURE A3 — Reaction balance error (vs total DOFs)
%%  Classification: Appendix / Supplementary Material.  NOT main text.
%% ========================================================================
fig_A3 = figure('Color','white', ...
                'Units','centimeters', ...
                'Position',[2, 10, 88/10, 72/10]);    % single-column
ax_A3 = axes(fig_A3);
semilogy(ax_A3, ndof_list, reaction_error_percent, ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       LW, ...
    'Marker',          'o', ...
    'MarkerSize',      MS, ...
    'MarkerFaceColor', 'white');
styleAxes(ax_A3);
xlabel(ax_A3, 'Total degrees of freedom', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
ylabel(ax_A3, 'Reaction balance error (\%)', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
xlim(ax_A3, xlim_dof);
exportFig(fig_A3, 'FigA3_2D_ConvergenceReactionError', 88, 72);

%% ========================================================================
%%  APPENDIX FIGURE A4 — Condition number (vs total DOFs)
%%  Classification: Appendix / Supplementary Material.  NOT main text.
%  NOTE: semilogy is used (rather than the linear axis of FigA2) because the
%  condition number spans several decades across the DOF range.
%% ========================================================================
fig_A4 = figure('Color','white', ...
                'Units','centimeters', ...
                'Position',[22, 10, 88/10, 72/10]);   % single-column
ax_A4 = axes(fig_A4);
semilogy(ax_A4, ndof_list, cond_est, ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       LW, ...
    'Marker',          'o', ...
    'MarkerSize',      MS, ...
    'MarkerFaceColor', 'white');
styleAxes(ax_A4);
xlabel(ax_A4, 'Total degrees of freedom', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
ylabel(ax_A4, 'Estimated condition number \kappa', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
xlim(ax_A4, xlim_dof);
exportFig(fig_A4, 'FigA4_2D_ConvergenceConditionNumber', 88, 72);

%% ========================================================================
%%  UTILITY FUNCTIONS — identical to the 1D/2D figure package
%% ========================================================================

function styleAxes(ax)
% styleAxes — Uniform publication axis style.
%   Identical to all figures (Fig01-Fig04).
%   Times New Roman 10 pt ticks, box on, inward ticks, dotted grid,
%   GridAlpha=0.35, no minor grid, axis frame 0.8 pt, 'tex' interpreter.
set(ax, ...
    'FontName',             'Times New Roman', ...
    'FontSize',             10, ...
    'LineWidth',            0.8, ...
    'Box',                  'on', ...
    'TickDir',              'in', ...
    'TickLength',           [0.015, 0.015], ...
    'XMinorTick',           'off', ...
    'YMinorTick',           'off', ...
    'GridLineStyle',        ':', ...
    'GridAlpha',            0.35, ...
    'MinorGridLineStyle',   'none', ...
    'TickLabelInterpreter', 'tex');
grid(ax, 'on');
end

function exportFig(figHandle, filename, width_mm, height_mm)
% exportFig — Export to EPS (vector), PDF (vector), PNG (600 dpi).
%   Identical to the export function used in all figures.
set(figHandle, 'Renderer', 'painters');
w_cm = width_mm  / 10;
h_cm = height_mm / 10;
set(figHandle, 'Units',             'centimeters');
set(figHandle, 'Position',          [2, 2, w_cm, h_cm]);
set(figHandle, 'PaperUnits',        'centimeters');
set(figHandle, 'PaperPositionMode', 'manual');
set(figHandle, 'PaperSize',         [w_cm, h_cm]);
set(figHandle, 'PaperPosition',     [0, 0, w_cm, h_cm]);
print(figHandle, [filename, '.eps'], '-depsc', '-r0');
print(figHandle, [filename, '.pdf'], '-dpdf',  '-r0');
print(figHandle, [filename, '.png'], '-dpng',  '-r600');
fprintf('\n[exportFig] Saved  : %s  (.eps / .pdf / .png)\n', filename);
fprintf('[exportFig] Size   : %.0f x %.0f mm\n', width_mm, height_mm);
end

%% ========================================================================
%%  FEM SOLVER AND SHAPE FUNCTIONS  (UNCHANGED)
%% ========================================================================

function [avg_ux_right, max_umag, total_Rx_left, cond_est, ndof] = solve_2d_sg_bfs(...
    Lx,Ly,E,nu,thickness,nelx,nely,l_micro,traction_right,body_force,bc_case,do_plots)

    a2 = l_micro^2/10;

    % Material matrix: plane strain
    lambda = E*nu/((1+nu)*(1-2*nu));
    mu     = E/(2*(1+nu));
    C = [lambda+2*mu, lambda,      0;
         lambda,      lambda+2*mu, 0;
         0,           0,           mu];

    % Mesh
    nnx = nelx + 1;
    nny = nely + 1;
    nnode = nnx*nny;
    ndof_per_node = 8;
    ndof = ndof_per_node*nnode;

    xgrid = linspace(0,Lx,nnx);
    ygrid = linspace(0,Ly,nny);
    node_id = @(ix,iy) (iy-1)*nnx + ix;

    coords = zeros(nnode,2);
    for iy = 1:nny
        for ix = 1:nnx
            n = node_id(ix,iy);
            coords(n,:) = [xgrid(ix), ygrid(iy)];
        end
    end

    conn = zeros(nelx*nely,4);
    e = 0;
    for ey = 1:nely
        for ex = 1:nelx
            e = e + 1;
            conn(e,:) = [node_id(ex,ey), node_id(ex+1,ey), ...
                         node_id(ex+1,ey+1), node_id(ex,ey+1)];
        end
    end

    nel = size(conn,1);
    K = sparse(ndof,ndof);
    F = zeros(ndof,1);

    [gp, gw] = gauss_1d_01(4);

    % Assembly
    for e = 1:nel
        nodes = conn(e,:);
        xy = coords(nodes,:);
        hx = xy(2,1) - xy(1,1);
        hy = xy(4,2) - xy(1,2);
        if hx <= 0 || hy <= 0
            error('Invalid element geometry at element %d: hx=%g, hy=%g.', e, hx, hy);
        end
        detJ = hx*hy;
        Ke = zeros(32,32);
        Fe = zeros(32,1);
        for ig = 1:length(gp)
            s = gp(ig); ws = gw(ig);
            for jg = 1:length(gp)
                t = gp(jg); wt = gw(jg);
                wgt = ws*wt*detJ*thickness;
                [N,Nx,Ny,Nxx,Nyy,Nxy] = bfs_shape_2d(s,t,hx,hy);
                [B,Bx,By,Nv] = make_B_matrices(N,Nx,Ny,Nxx,Nyy,Nxy);
                Ke = Ke + (B.'*C*B + a2*(Bx.'*C*Bx + By.'*C*By))*wgt;
                Fe = Fe + Nv.'*body_force*wgt;
            end
        end
        edofs = element_dofs(nodes,ndof_per_node);
        K(edofs,edofs) = K(edofs,edofs) + Ke;
        F(edofs) = F(edofs) + Fe;
    end

    % Right-edge traction
    for ey = 1:nely
        e_right = (ey-1)*nelx + nelx;
        nodes = conn(e_right,:);
        xy = coords(nodes,:);
        hx = xy(2,1) - xy(1,1);
        hy = xy(4,2) - xy(1,2);
        edofs = element_dofs(nodes,ndof_per_node);
        Fe = zeros(32,1);
        s = 1.0;
        for jg = 1:length(gp)
            t = gp(jg); wt = gw(jg);
            edgeJ = hy;
            [N,Nx,Ny,Nxx,Nyy,Nxy] = bfs_shape_2d(s,t,hx,hy); %#ok<ASGLU>
            [~,~,~,Nv] = make_B_matrices(N,Nx,Ny,Nxx,Nyy,Nxy);
            Fe = Fe + Nv.'*traction_right*(edgeJ*wt*thickness);
        end
        F(edofs) = F(edofs) + Fe;
    end

    % Essential BCs
    fixed_dofs = [];
    left_nodes = arrayfun(@(iy) node_id(1,iy), 1:nny);
    switch bc_case
        case "clamped_gradient"
            for n = left_nodes
                fixed_dofs = [fixed_dofs, (n-1)*8 + (1:8)]; %#ok<AGROW>
            end
        case "classical_clamp"
            for n = left_nodes
                fixed_dofs = [fixed_dofs, (n-1)*8 + [1,5]]; %#ok<AGROW>
            end
        otherwise
            error('Unknown bc_case.');
    end
    fixed_dofs = unique(fixed_dofs);
    free_dofs = setdiff(1:ndof,fixed_dofs);

    % Scaled solve
    Kff = K(free_dofs,free_dofs);
    Ff  = F(free_dofs);
    scale_diag = sqrt(abs(diag(Kff)));
    scale_diag(scale_diag < eps) = 1.0;
    Sscale = spdiags(1./scale_diag,0,length(free_dofs),length(free_dofs));
    Kscaled = Sscale*Kff*Sscale;
    Fscaled = Sscale*Ff;
    cond_est = condest(Kscaled);
    if ~isfinite(cond_est) || cond_est > 1.0e14
        reg = 1.0e-10*mean(abs(diag(Kscaled)));
        if reg == 0 || ~isfinite(reg)
            reg = 1.0e-10;
        end
        Kscaled = Kscaled + reg*speye(size(Kscaled));
    end
    y = Kscaled\Fscaled;
    D = zeros(ndof,1);
    D(free_dofs) = Sscale*y;

    R = K*D - F;

    u_nodes = D(1:8:end);
    v_nodes = D(5:8:end);
    umag = sqrt(u_nodes.^2 + v_nodes.^2);

    right_nodes = arrayfun(@(iy) node_id(nnx,iy), 1:nny);
    avg_ux_right = mean(u_nodes(right_nodes));
    max_umag = max(umag);
    total_Rx_left = sum(R(arrayfun(@(n) (n-1)*8+1,left_nodes)));

    if do_plots
        fprintf('\n===== Detailed 2D SG field for mesh %d x %d =====\n', nelx, nely);
        fprintf('Average u on right edge  = %.12e m\n', avg_ux_right);
        fprintf('Maximum displacement mag = %.12e m\n', max_umag);
        fprintf('Total reaction Fx left   = %.12e N\n', total_Rx_left);
        fprintf('Condition estimate       = %.12e\n',   cond_est);
    end
end

function edofs = element_dofs(nodes,ndof_per_node)
    edofs = zeros(1, numel(nodes)*ndof_per_node);
    c = 0;
    for a = 1:numel(nodes)
        n = nodes(a);
        edofs(c+1:c+ndof_per_node) = (n-1)*ndof_per_node + (1:ndof_per_node);
        c = c + ndof_per_node;
    end
end

function [gp,gw] = gauss_1d_01(n)
    switch n
        case 4
            x = [-0.8611363115940526, -0.3399810435848563, ...
                  0.3399810435848563,  0.8611363115940526];
            w = [0.3478548451374538, 0.6521451548625461, ...
                 0.6521451548625461, 0.3478548451374538];
        otherwise
            error('Only n=4 implemented here.');
    end
    gp = (x+1)/2;
    gw = w/2;
end

function [N, Nx, Ny, Nxx, Nyy, Nxy] = bfs_shape_2d(s,t,hx,hy)
    [Hx0,Hx1,Hx0x,Hx1x,Hx0xx,Hx1xx] = hermite_1d_two_nodes(s,hx);
    [Hy0,Hy1,Hy0y,Hy1y,Hy0yy,Hy1yy] = hermite_1d_two_nodes(t,hy);
    xs = [1 2 2 1];
    ys = [1 1 2 2];
    N   = zeros(1,16);
    Nx  = zeros(1,16);
    Ny  = zeros(1,16);
    Nxx = zeros(1,16);
    Nyy = zeros(1,16);
    Nxy = zeros(1,16);
    for a = 1:4
        ix = xs(a); iy = ys(a);
        p = (a-1)*4;
        N(p+1)   = Hx0(ix)*Hy0(iy);
        Nx(p+1)  = Hx0x(ix)*Hy0(iy);
        Ny(p+1)  = Hx0(ix)*Hy0y(iy);
        Nxx(p+1) = Hx0xx(ix)*Hy0(iy);
        Nyy(p+1) = Hx0(ix)*Hy0yy(iy);
        Nxy(p+1) = Hx0x(ix)*Hy0y(iy);
        N(p+2)   = Hx1(ix)*Hy0(iy);
        Nx(p+2)  = Hx1x(ix)*Hy0(iy);
        Ny(p+2)  = Hx1(ix)*Hy0y(iy);
        Nxx(p+2) = Hx1xx(ix)*Hy0(iy);
        Nyy(p+2) = Hx1(ix)*Hy0yy(iy);
        Nxy(p+2) = Hx1x(ix)*Hy0y(iy);
        N(p+3)   = Hx0(ix)*Hy1(iy);
        Nx(p+3)  = Hx0x(ix)*Hy1(iy);
        Ny(p+3)  = Hx0(ix)*Hy1y(iy);
        Nxx(p+3) = Hx0xx(ix)*Hy1(iy);
        Nyy(p+3) = Hx0(ix)*Hy1yy(iy);
        Nxy(p+3) = Hx0x(ix)*Hy1y(iy);
        N(p+4)   = Hx1(ix)*Hy1(iy);
        Nx(p+4)  = Hx1x(ix)*Hy1(iy);
        Ny(p+4)  = Hx1(ix)*Hy1y(iy);
        Nxx(p+4) = Hx1xx(ix)*Hy1(iy);
        Nyy(p+4) = Hx1(ix)*Hy1yy(iy);
        Nxy(p+4) = Hx1x(ix)*Hy1y(iy);
    end
end

function [H0,H1,H0x,H1x,H0xx,H1xx] = hermite_1d_two_nodes(s,L)
    h1 = 1 - 3*s^2 + 2*s^3;
    h2 = L*(s - 2*s^2 + s^3);
    h3 = 3*s^2 - 2*s^3;
    h4 = L*(-s^2 + s^3);
    dh1 = -6*s + 6*s^2;
    dh2 = L*(1 - 4*s + 3*s^2);
    dh3 = 6*s - 6*s^2;
    dh4 = L*(-2*s + 3*s^2);
    d2h1 = -6 + 12*s;
    d2h2 = L*(-4 + 6*s);
    d2h3 = 6 - 12*s;
    d2h4 = L*(-2 + 6*s);
    H0 = [h1, h3];
    H1 = [h2, h4];
    H0x = (1/L)*[dh1, dh3];
    H1x = (1/L)*[dh2, dh4];
    H0xx = (1/L^2)*[d2h1, d2h3];
    H1xx = (1/L^2)*[d2h2, d2h4];
end

function [B,Bx,By,Nv] = make_B_matrices(N,Nx,Ny,Nxx,Nyy,Nxy)
    B  = zeros(3,32);
    Bx = zeros(3,32);
    By = zeros(3,32);
    Nv = zeros(2,32);
    for a = 1:4
        sp = (a-1)*4 + (1:4);
        up = (a-1)*8 + (1:4);
        vp = (a-1)*8 + (5:8);
        Nv(1,up) = N(sp);
        Nv(2,vp) = N(sp);
        B(1,up) = Nx(sp);
        B(2,vp) = Ny(sp);
        B(3,up) = Ny(sp);
        B(3,vp) = Nx(sp);
        Bx(1,up) = Nxx(sp);
        Bx(2,vp) = Nxy(sp);
        Bx(3,up) = Nxy(sp);
        Bx(3,vp) = Nxx(sp);
        By(1,up) = Nxy(sp);
        By(2,vp) = Nyy(sp);
        By(3,up) = Nyy(sp);
        By(3,vp) = Nxy(sp);
    end
end
