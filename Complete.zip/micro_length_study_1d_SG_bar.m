%% micro_length_study_1d_SG_bar.m
%
% Micro-length parameter study for 1D strain-gradient bar FEM
% Uses C1 cubic Hermite finite elements.
%
% Energy:
%   U = 1/2 int_0^L EA[(u')^2 + a^2(u'')^2] dx
% where
%   a^2 = l_micro^2/10.
%
% Boundary condition used:
%   u(0)=0, u'(0)=0, axial end force F at x=L.
%
% Exact solution for q0=0:
%   u(L) = (F/EA)*(L - a*tanh(L/a)), for a > 0.
% Classical limit l=0:
%   u(L) = F*L/(EA).

clear; clc; close all;

% ── Root defaults: protect against residual MATLAB session settings ────────
set(groot, 'defaultAxesFontName',             'Times New Roman');
set(groot, 'defaultAxesFontSize',             10);
set(groot, 'defaultTextFontName',             'Times New Roman');
set(groot, 'defaultTextFontSize',             10);
set(groot, 'defaultAxesTickLabelInterpreter', 'tex');
set(groot, 'defaultTextInterpreter',          'tex');

%% ==================== Input data ====================

L     = 1.0;       % length, m
E     = 200e9;     % Young's modulus, Pa
Area  = 1.0e-4;    % area, m^2
F_tip = 1.0e4;     % end force, N
q0    = 0.0;       % distributed load, N/m

nel = 200;         % elements — resolves boundary layers accurately

% Microstructural neighbourhood lengths l (discrete FEM evaluation points)
l_list = [0.0, 0.005, 0.01, 0.02, 0.05, 0.075, 0.10, 0.15, 0.20];

u_classical = F_tip * L / (E * Area);   % 5.000e-4 m = 500 µm

u_tip_FE    = zeros(size(l_list));
u_tip_exact = zeros(size(l_list));      % exact at the same discrete points
ratio_FE    = zeros(size(l_list));
ratio_exact = zeros(size(l_list));
left_moment = zeros(size(l_list));      % higher-order reaction (supplementary)

%% ==================== Run study ====================

for i = 1:length(l_list)
    l_micro = l_list(i);
    a2      = l_micro^2 / 10;
    a       = sqrt(a2);

    [u_tip_FE(i), left_moment(i)] = solve_sg_bar_tip(nel,L,E,Area,a2,F_tip,q0);

    if l_micro == 0
        u_tip_exact(i) = u_classical;
    else
        u_tip_exact(i) = (F_tip/(E*Area)) * (L - a*tanh(L/a));
    end

    ratio_FE(i)    = u_tip_FE(i)    / u_classical;
    ratio_exact(i) = u_tip_exact(i) / u_classical;
end

%% ==================== Print table ====================

fprintf('\n===== Micro-length parameter study: 1D strain-gradient bar =====\n');
fprintf('nel = %d\n', nel);
fprintf('Classical tip displacement = %.12e m\n\n', u_classical);
fprintf('%10s %14s %20s %20s %16s %18s\n', ...
    'l_micro','a=l/sqrt(10)','u_FE','u_exact','FE/classical','left moment');
fprintf('%10s %14s %20s %20s %16s %18s\n', ...
    '-------','------------','----','-------','------------','-----------');
for i = 1:length(l_list)
    a = l_list(i) / sqrt(10);
    fprintf('%10.5f %14.6e %20.12e %20.12e %16.8f %18.6e\n', ...
        l_list(i), a, u_tip_FE(i), u_tip_exact(i), ratio_FE(i), left_moment(i));
end


%% =========================================================================
%%  PUBLICATION-QUALITY FIGURE — MAIN MANUSCRIPT (v2)
%%
%%  TWO-PANEL composite figure (panel (c) removed per revision request):
%%    (a) Tip displacement u(L) in µm  vs  l/L
%%    (b) Normalised ratio u_SG(L)/u_classical(L)  vs  l/L
%%
%%  Visual identity: matches Fig01_1D_BoundaryLayer exactly.
%%
%%  KEY CHANGE FROM v1:
%%    The Exact SG curve was invisible in v1 because:
%%      - It was plotted BEFORE the FEM curve.
%%      - The FEM solution agrees to <0.001 µm (< 0.003% of axis range),
%%        so the FEM solid+circles layer completely covered the Exact SG line.
%%    Fix applied:
%%      - Plot FEM FIRST (z-layer: bottom).
%%      - Plot Exact SG SECOND (z-layer: top) as a dense 200-point dashed
%%        line in vermillion. The dashes appear between and over the FEM
%%        circle markers, making both curves visually distinguishable.
%%      - Exact SG is evaluated on a dense linspace (200 points) to produce
%%        a smooth, continuously dashed curve rather than discrete markers.
%%
%%  Higher-order reaction |R_theta(0)| is generated as a separate
%%  supplementary figure (see block below).
%% =========================================================================

% ── Unit conversion ────────────────────────────────────────────────────────
%  Both u_tip_FE and u_tip_exact are in metres.
%  Range: ~468.4 µm (l/L=0.20) to 500.0 µm (l/L=0).
%  µm avoids scientific-notation tick labels — same convention as Fig01.
%
u_FE_um    = u_tip_FE    * 1e6;   % metres → µm  (discrete, 9 FEM points)
u_exact_um = u_tip_exact * 1e6;   % metres → µm  (discrete, same 9 points)
u_cl_um    = u_classical  * 1e6;  % 500.0 µm  (classical reference scalar)

%  x-axis: l/L (dimensionless, consistent with Fig01's x/L convention).
lL = l_list / L;   % 9 discrete points matching the FEM evaluation

%  Dense analytical curve for smooth Exact SG line (200 points).
%  Evaluated independently of the FEM grid so the dashed segments are
%  continuous across the full x-range and not tied to FEM marker positions.
lL_dense   = linspace(0, max(lL), 200);    % dense l/L vector
u_exact_dense_um = zeros(size(lL_dense));   % pre-allocate
for k = 1:length(lL_dense)
    l_k = lL_dense(k) * L;
    a_k = sqrt(l_k^2 / 10);
    if l_k == 0
        u_exact_dense_um(k) = u_cl_um;
    else
        u_exact_dense_um(k) = (F_tip/(E*Area)) * (L - a_k*tanh(L/a_k)) * 1e6;
    end
end
ratio_exact_dense = u_exact_dense_um / u_cl_um;  % normalised, dense

% ── Colour palette (Wong 2011, colorblind-safe — identical to Fig01) ──────
C_blue   = [0.000, 0.447, 0.698];   % FEM — primary data
C_vermil = [0.851, 0.325, 0.098];   % Exact SG — analytical reference
C_orange = [0.929, 0.694, 0.125];   % Classical — baseline reference

% ── Line and marker constants (identical to Fig01) ────────────────────────
LW_data = 1.5;   % FEM solid line
LW_SG   = 1.5;   % Exact SG dashed — same weight keeps visual balance
LW_cl   = 1.0;   % Classical dotted reference
MS      = 6;     % FEM marker size (pt)

% ── Figure — exact dimensions matching Fig01_1D_BoundaryLayer ─────────────
fig_w_mm = 176;   % double-column width (mm) — identical to Fig01
fig_h_mm =  72;   % height (mm) — identical to Fig01

fig = figure('Color', 'white', ...
             'Units', 'centimeters', ...
             'Position', [2, 2, fig_w_mm/10, fig_h_mm/10]);

% ── Two-panel tiled layout (identical spacing to Fig01) ───────────────────
tl = tiledlayout(1, 2, ...
    'TileSpacing', 'compact', ...
    'Padding',     'compact');

% =========================================================================
%  Panel (a) — Tip displacement u(L) vs l/L
%
%  PLOTTING ORDER (z-layer: bottom → top):
%    1. yline — Classical reference (orange dotted, bottommost)
%    2. plot  — FEM (blue solid + open circles, middle)
%    3. plot  — Exact SG dense curve (vermillion dashed, topmost)
%
%  The dashed Exact SG line sits ON TOP of the FEM circles, so its
%  dashes appear between and over the markers, making both distinguishable.
% =========================================================================
ax1 = nexttile(tl, 1);

% 1. Classical reference — plotted first (bottommost layer)
yline(ax1, u_cl_um, ...
    'Color',     C_orange, ...
    'LineStyle', ':', ...
    'LineWidth', LW_cl);
hold(ax1, 'on');

% 2. FEM — discrete markers on solid line (middle layer)
plot(ax1, lL, u_FE_um, ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       LW_data, ...
    'Marker',          'o', ...
    'MarkerSize',      MS, ...
    'MarkerFaceColor', 'white');

% 3. Exact SG — dense dashed curve (topmost layer)
%    Plotted AFTER FEM so its dashes appear on top of FEM circles.
%    Dense x-grid ensures continuous dashes across the full x-range.
plot(ax1, lL_dense, u_exact_dense_um, ...
    'Color',     C_vermil, ...
    'LineStyle', '--', ...
    'LineWidth', LW_SG);

% Apply uniform axis style (identical to Fig01)
styleAxes(ax1);

% Axis labels
xlabel(ax1, 'l/L', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

ylabel(ax1, 'u(L) (\mum)', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

% Axis limits — 8% headroom below minimum, 4% above maximum
u_span = u_cl_um - min(u_FE_um);
xlim(ax1, [0, max(lL)]);
ylim(ax1, [min(u_FE_um) - 0.08*u_span,  u_cl_um + 0.04*u_span]);

% Legend — 3 entries in plot-creation order: Classical → FEM → Exact SG
legend(ax1, {'Classical', 'FEM', 'Exact SG'}, ...
    'Location',   'southwest', ...
    'FontName',   'Times New Roman', ...
    'FontSize',   9.5, ...
    'Box',        'on', ...
    'EdgeColor',  [0.4, 0.4, 0.4], ...
    'Interpreter','tex');

% Panel label (a) — upper-left corner, identical position to Fig01
text(ax1, 0.09, 0.93, '(a)', ...
    'Units',      'normalized', ...
    'FontName',   'Times New Roman', ...
    'FontSize',   11, ...
    'FontWeight', 'bold', ...
    'Interpreter','none');

% =========================================================================
%  Panel (b) — Normalised displacement ratio u_SG(L)/u_classical(L)
%
%  Same plotting order as panel (a):
%    1. yline — Classical reference at ratio = 1.0
%    2. plot  — FEM ratio (discrete markers)
%    3. plot  — Exact SG ratio (dense dashed, topmost)
% =========================================================================
ax2 = nexttile(tl, 2);

% 1. Classical reference at ratio = 1
yline(ax2, 1.0, ...
    'Color',     C_orange, ...
    'LineStyle', ':', ...
    'LineWidth', LW_cl);
hold(ax2, 'on');

% 2. FEM ratio (middle layer)
plot(ax2, lL, ratio_FE, ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       LW_data, ...
    'Marker',          'o', ...
    'MarkerSize',      MS, ...
    'MarkerFaceColor', 'white');

% 3. Exact SG ratio — dense dashed (topmost layer)
plot(ax2, lL_dense, ratio_exact_dense, ...
    'Color',     C_vermil, ...
    'LineStyle', '--', ...
    'LineWidth', LW_SG);

styleAxes(ax2);

xlabel(ax2, 'l/L', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

ylabel(ax2, 'u_{SG}(L) / u_{cl}(L)', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

% Axis limits
r_span = 1.0 - min(ratio_FE);
xlim(ax2, [0, max(lL)]);
ylim(ax2, [min(ratio_FE) - 0.08*r_span,  1.0 + 0.04*r_span]);

% Panel (b): suppress legend — line styles are already established in panel (a).
% A repeated legend carries no new information and adds visual clutter.
legend(ax2, 'off');

% Panel label (b)
text(ax2, 0.08, 0.93, '(b)', ...
    'Units',      'normalized', ...
    'FontName',   'Times New Roman', ...
    'FontSize',   11, ...
    'FontWeight', 'bold', ...
    'Interpreter','none');

% ── Export main figure ─────────────────────────────────────────────────────
exportFig(fig, 'Fig02_micro_length_study', fig_w_mm, fig_h_mm);


%% =========================================================================
%%  SUPPLEMENTARY FIGURE — Higher-order reaction moment |R_theta(0)|
%%
%%  Classification: Supplementary Material
%%
%%  Physical note:
%%    R_theta(0) is the work-conjugate of the imposed BC theta(0)=0.
%%    It is identically zero in classical elasticity.
%%    For L/a >> 1 (satisfied for all l values here): R_theta(0) = F*a.
%%    The linear reference F*a = F*l/sqrt(10) is confirmed analytically.
%%
%%  This panel is separated from the main figure because:
%%    1. Panels (a)+(b) tell the complete stiffness story.
%%    2. The reaction quantity is less physically intuitive for non-specialist
%%       readers — it belongs in a supplementary validation section.
%%    3. Removing it from the main figure allows (a)+(b) to be placed at
%%       the same 176×72 mm dimensions as Fig01_1D_BoundaryLayer.
%% =========================================================================

% Dense reference line for supplementary figure
lL_ref_supp = linspace(0, max(lL), 200);
R_ref_supp  = F_tip * (lL_ref_supp * L) / sqrt(10);   % F * a [N·m], linear

fig_s = figure('Color', 'white', ...
               'Units', 'centimeters', ...
               'Position', [22, 2, 88/10, 72/10]);   % single-column

ax_s = axes(fig_s);

% Reference line (gray dash-dot, behind FEM)
plot(ax_s, lL_ref_supp, R_ref_supp, ...
    'Color',     [0.5, 0.5, 0.5], ...
    'LineStyle', '-.', ...
    'LineWidth', 0.8);
hold(ax_s, 'on');

% FEM higher-order reaction
plot(ax_s, lL, abs(left_moment), ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       LW_data, ...
    'Marker',          'o', ...
    'MarkerSize',      MS, ...
    'MarkerFaceColor', 'white');

styleAxes(ax_s);

xlabel(ax_s, 'l/L', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

ylabel(ax_s, '|R_{\theta}(0)| (N{\cdot}m)', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

xlim(ax_s, [0, max(lL)]);
ylim(ax_s, [0, max(abs(left_moment)) * 1.10]);

legend(ax_s, {'Exact: R = F{\cdot}a', 'FEM'}, ...
    'Location',   'northwest', ...
    'FontName',   'Times New Roman', ...
    'FontSize',   9.5, ...
    'Box',        'on', ...
    'EdgeColor',  [0.4, 0.4, 0.4], ...
    'Interpreter','tex');

exportFig(fig_s, 'FigS1_reaction_moment', 88, 72);


%% ==================== Local functions ====================

% ─────────────────────────────────────────────────────────────────────────
function styleAxes(ax)
% styleAxes — Uniform publication axis style.
%   Identical to Fig01_1D_BoundaryLayer (strain_gradient_bar_1d_FEM_pub_v2.m).
%   Times New Roman 10 pt, box on, inward ticks, dotted grid alpha=0.35,
%   no minor grid, axis frame 0.8 pt, TickLabelInterpreter='tex'.
set(ax, ...
    'FontName',             'Times New Roman', ...
    'FontSize',             10, ...
    'LineWidth',            0.8, ...
    'Box',                  'on', ...
    'TickDir',              'in', ...
    'TickLength',           [0.015, 0.015], ...
    'XMinorTick',           'off', ...
    'YMinorTick',           'off', ...
    'GridLineStyle',        ':', ...
    'GridAlpha',            0.35, ...
    'MinorGridLineStyle',   'none', ...
    'TickLabelInterpreter', 'tex');
grid(ax, 'on');
end


% ─────────────────────────────────────────────────────────────────────────
function exportFig(figHandle, filename, width_mm, height_mm)
% exportFig — Export figure to EPS (vector), PDF (vector), PNG (600 dpi).
%   Identical to Fig01 export function.
%   PaperPositionMode='manual' prevents MATLAB default centering.
set(figHandle, 'Renderer', 'painters');

w_cm = width_mm  / 10;
h_cm = height_mm / 10;

set(figHandle, 'Units',             'centimeters');
set(figHandle, 'Position',          [2, 2, w_cm, h_cm]);
set(figHandle, 'PaperUnits',        'centimeters');
set(figHandle, 'PaperPositionMode', 'manual');
set(figHandle, 'PaperSize',         [w_cm, h_cm]);
set(figHandle, 'PaperPosition',     [0, 0, w_cm, h_cm]);

print(figHandle, [filename, '.eps'], '-depsc', '-r0');
print(figHandle, [filename, '.pdf'], '-dpdf',  '-r0');
print(figHandle, [filename, '.png'], '-dpng',  '-r600');

fprintf('\n[exportFig] Saved  : %s  (.eps / .pdf / .png)\n', filename);
fprintf('[exportFig] Size   : %.0f x %.0f mm\n', width_mm, height_mm);
end


% ─────────────────────────────────────────────────────────────────────────
function [uL, Rmoment0] = solve_sg_bar_tip(nel,L,E,A,a2,F_tip,q0)

    nn   = nel + 1;
    ndof = 2*nn;
    xnode = linspace(0,L,nn).';
    conn  = [(1:nel).' (2:nel+1).'];

    K = zeros(ndof,ndof);
    F = zeros(ndof,1);

    gp_xi = [-sqrt(3/5), 0, sqrt(3/5)];
    gp_w  = [5/9, 8/9, 5/9];

    for e = 1:nel
        n1 = conn(e,1);
        n2 = conn(e,2);
        Le = xnode(n2) - xnode(n1);
        ke = zeros(4,4);
        fe = zeros(4,1);
        for gp = 1:length(gp_xi)
            xi = gp_xi(gp);
            w  = gp_w(gp);
            s  = (xi+1)/2;
            J  = Le/2;
            [N,B1,B2] = hermite_shape_1d(s,Le);
            ke = ke + E*A*(B1.'*B1 + a2*(B2.'*B2))*J*w;
            fe = fe + N.'*q0*J*w;
        end
        edofs = [2*n1-1, 2*n1, 2*n2-1, 2*n2];
        K(edofs,edofs) = K(edofs,edofs) + ke;
        F(edofs)       = F(edofs) + fe;
    end

    F(2*nn-1) = F(2*nn-1) + F_tip;

    fixed = [1 2];
    free  = setdiff(1:ndof, fixed);
    D     = zeros(ndof,1);
    D(free) = K(free,free) \ F(free);
    R = K*D - F;

    uL       = D(2*nn-1);
    Rmoment0 = R(2);

end


% ─────────────────────────────────────────────────────────────────────────
function [N,B1,B2] = hermite_shape_1d(s,Le)

    N1 = 1 - 3*s^2 + 2*s^3;
    N2 = Le*(s - 2*s^2 + s^3);
    N3 = 3*s^2 - 2*s^3;
    N4 = Le*(-s^2 + s^3);
    N  = [N1, N2, N3, N4];

    dN1 = -6*s + 6*s^2;
    dN2 = Le*(1 - 4*s + 3*s^2);
    dN3 = 6*s - 6*s^2;
    dN4 = Le*(-2*s + 3*s^2);
    B1  = (1/Le)*[dN1, dN2, dN3, dN4];

    d2N1 = -6 + 12*s;
    d2N2 = Le*(-4 + 6*s);
    d2N3 = 6 - 12*s;
    d2N4 = Le*(-2 + 6*s);
    B2   = (1/Le^2)*[d2N1, d2N2, d2N3, d2N4];

end
