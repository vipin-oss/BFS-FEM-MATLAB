%% micro_length_study_2D_BFS_plane_strain.m
%
% Microstructural length-scale study for 2D plane-strain strain-gradient
% elasticity using C1 Bogner-Fox-Schmit rectangular elements.
%
% Model:
%   W = 1/2 eps^T C eps + 1/2 a^2[(eps_x)^T C eps_x + (eps_y)^T C eps_y]
%   a^2 = l_micro^2/10
%
% Problem:
%   Rectangular domain [0,Lx] x [0,Ly]
%   Left edge: strain-gradient clamped
%   Right edge: uniform traction tx

clear; clc; close all;

% ── Root defaults — identical to 1D figure package ────────────────────────
set(groot, 'defaultAxesFontName',             'Times New Roman');
set(groot, 'defaultAxesFontSize',             10);
set(groot, 'defaultTextFontName',             'Times New Roman');
set(groot, 'defaultTextFontSize',             10);
set(groot, 'defaultAxesTickLabelInterpreter', 'tex');
set(groot, 'defaultTextInterpreter',          'tex');

%% ==================== Input data ====================

Lx = 1.0;
Ly = 0.20;
E  = 200e9;
nu = 0.30;
thickness = 1.0;

nelx = 20;
nely = 4;

traction_right = [1.0e6; 0.0];
body_force     = [0.0;   0.0];

l_list = [0.005 0.01 0.02 0.05 0.075 0.10 0.15 0.20];

bc_case = "clamped_gradient";

%% ==================== Run study ====================

avg_u_right = zeros(size(l_list));
max_umag    = zeros(size(l_list));
react_left  = zeros(size(l_list));
cond_est    = zeros(size(l_list));

for i = 1:length(l_list)
    l_micro = l_list(i);
    fprintf('\n--- Solving 2D SG problem for l = %.5f ---\n', l_micro);
    [avg_u_right(i), max_umag(i), react_left(i), cond_est(i)] = ...
        solve_2d_sg_bfs(Lx, Ly, E, nu, thickness, nelx, nely, l_micro, ...
                        traction_right, body_force, bc_case, false);
end

% Normalization by the smallest-l result (quasi-reference state).
u_ref = avg_u_right(1);
ratio = avg_u_right / u_ref;

applied_Fx             = traction_right(1) * Ly * thickness;
reaction_error_percent = 100 * abs(react_left + applied_Fx) / abs(applied_Fx);

%% ==================== Print table ====================

fprintf('\n===== 2D SG microstructural length study =====\n');
fprintf('Mesh              = %d x %d BFS elements\n', nelx, nely);
fprintf('Domain            = %.4g x %.4g m\n', Lx, Ly);
fprintf('Right traction tx = %.6e Pa\n', traction_right(1));
fprintf('Applied Fx        = %.6e N\n\n', applied_Fx);

fprintf('%10s %14s %20s %20s %16s %16s\n', ...
    'l_micro', 'a=l/sqrt(10)', 'avg u right', 'max |u|', 'u/u_ref', 'Rx error (%)');
fprintf('%s\n', repmat('-', 1, 96));
for i = 1:length(l_list)
    a = l_list(i) / sqrt(10);
    fprintf('%10.5f %14.6e %20.12e %20.12e %16.8f %16.6e\n', ...
        l_list(i), a, avg_u_right(i), max_umag(i), ratio(i), ...
        reaction_error_percent(i));
end


%% =========================================================================
%%  PUBLICATION-QUALITY FIGURE — 2D MICRO-LENGTH PARAMETRIC STUDY
%%
%%  Two-panel composite figure (main manuscript):
%%    (a) Average right-edge displacement  bar_u_R  (µm)  vs  l/Lx
%%    (b) Normalised displacement ratio  bar_u_R / bar_u_{R,ref}  vs  l/Lx
%%
%%  Appendix figures (reaction error, condition number) generated separately
%%  below this block.
%%
%%  Visual identity: matches Fig01_1D_BoundaryLayer, Fig02_MicroLengthEffect,
%%  and Fig03_EigenfrequencyResponse exactly.
%%  Uses identical styleAxes() and exportFig() utility functions.
%% =========================================================================

% ── Unit conversion ────────────────────────────────────────────────────────
%  avg_u_right is in metres; multiply by 1e6 for micrometres.
%  Typical range ~3.7–4.5 µm — no scientific notation required.
%  Consistent with the µm convention of Fig02_MicroLengthEffect.
%
u_R_um = avg_u_right * 1e6;    % metres → µm

%  x-axis: l/Lx (dimensionless).
%  Lx = 1.0 m, so l/Lx equals l numerically, but dimensionless
%  and consistent with the l/L convention of the 1D studies.
%
lLx = l_list / Lx;             % l/Lx (dimensionless)

% ── Colour (Wong 2011, entry 1 — blue, identical to 1D FEM colour) ────────
C_blue  = [0.000, 0.447, 0.698];
C_gray  = [0.500, 0.500, 0.500];   % reference line in panel (b)

% ── Line and marker constants (identical to 1D package) ───────────────────
LW      = 1.5;    % primary line width (pt)
LW_ref  = 0.8;    % reference dotted line
MS      = 6;      % marker size (pt)

% ── Figure dimensions — identical to Fig02_MicroLengthEffect ──────────────
fig_w_mm = 176;   % double-column width (mm)
fig_h_mm =  72;   % height (mm)

fig = figure('Color', 'white', ...
             'Units', 'centimeters', ...
             'Position', [2, 2, fig_w_mm/10, fig_h_mm/10]);

% ── Two-panel tiled layout (same spacing as all 1D figures) ───────────────
tl = tiledlayout(1, 2, ...
    'TileSpacing', 'compact', ...
    'Padding',     'compact');

% =========================================================================
%  Panel (a) — Average right-edge displacement vs l/Lx
% =========================================================================
ax1 = nexttile(tl, 1);

plot(ax1, lLx, u_R_um, ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       LW, ...
    'Marker',          'o', ...
    'MarkerSize',      MS, ...
    'MarkerFaceColor', 'white');

styleAxes(ax1);

xlabel(ax1, 'l/L_x', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

ylabel(ax1, 'Avg. right-edge displacement (\mum)', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

% Axis limits: 8% headroom below minimum, 4% above maximum
u_span = max(u_R_um) - min(u_R_um);
xlim(ax1, [0, max(lLx)]);
ylim(ax1, [min(u_R_um) - 0.08*u_span,  max(u_R_um) + 0.04*u_span]);

% Panel label — identical position/style to all 1D figures
text(ax1, 0.14, 0.93, '(a)', ...
    'Units',      'normalized', ...
    'FontName',   'Times New Roman', ...
    'FontSize',   11, ...
    'FontWeight', 'bold', ...
    'Interpreter','none');

% =========================================================================
%  Panel (b) — Normalised displacement ratio vs l/Lx
%
%  Normalisation: bar_u_R(l/Lx) / bar_u_R(l_min)
%  where l_min = 0.005 m is the smallest value in l_list.
%  This ratio equals 1.000 at l/Lx = 0.005 (leftmost point) and
%  decreases monotonically as l/Lx increases, reflecting stiffening.
% =========================================================================
ax2 = nexttile(tl, 2);

% Reference dotted line at ratio = 1.000 (quasi-classical reference)
yline(ax2, 1.0, ...
    'Color',     C_gray, ...
    'LineStyle', ':', ...
    'LineWidth', LW_ref);
hold(ax2, 'on');

plot(ax2, lLx, ratio, ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       LW, ...
    'Marker',          'o', ...
    'MarkerSize',      MS, ...
    'MarkerFaceColor', 'white');

styleAxes(ax2);

xlabel(ax2, 'l/L_x', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

ylabel(ax2, 'u_R(l/L_x) / u_{R,ref}', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

% Axis limits
r_span = 1.0 - min(ratio);
xlim(ax2, [0, max(lLx)]);
ylim(ax2, [min(ratio) - 0.08*r_span,  1.0 + 0.04*r_span]);

% Panel label
text(ax2, 0.14, 0.93, '(b)', ...
    'Units',      'normalized', ...
    'FontName',   'Times New Roman', ...
    'FontSize',   11, ...
    'FontWeight', 'bold', ...
    'Interpreter','none');

% ── Export main figure ─────────────────────────────────────────────────────
% exportFig(fig, 'Fig04_2D_MicroLengthEffect', fig_w_mm, fig_h_mm);
% To save: uncomment the line above after setting a writable output folder.


%% =========================================================================
%%  APPENDIX FIGURE A1 — Reaction balance error
%%  Classification: Appendix / Supplementary Material
%%  NOT part of the main manuscript figure.
%% =========================================================================

fig_A1 = figure('Color', 'white', ...
                'Units', 'centimeters', ...
                'Position', [2, 10, 88/10, 72/10]);   % single-column

ax_A1 = axes(fig_A1);

semilogy(ax_A1, lLx, reaction_error_percent, ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       LW, ...
    'Marker',          'o', ...
    'MarkerSize',      MS, ...
    'MarkerFaceColor', 'white');

styleAxes(ax_A1);

xlabel(ax_A1, 'l/L_x', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

ylabel(ax_A1, 'Reaction balance error (%)', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

xlim(ax_A1, [0, max(lLx)]);

% exportFig(fig_A1, 'FigA1_2D_ReactionError', 88, 72);


%% =========================================================================
%%  APPENDIX FIGURE A2 — Condition number
%%  Classification: Appendix / Supplementary Material
%%  NOT part of the main manuscript figure.
%% =========================================================================

fig_A2 = figure('Color', 'white', ...
                'Units', 'centimeters', ...
                'Position', [22, 10, 88/10, 72/10]);   % single-column

ax_A2 = axes(fig_A2);

plot(ax_A2, lLx, cond_est, ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       LW, ...
    'Marker',          'o', ...
    'MarkerSize',      MS, ...
    'MarkerFaceColor', 'white');

styleAxes(ax_A2);

xlabel(ax_A2, 'l/L_x', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

ylabel(ax_A2, 'Estimated condition number \kappa', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);

xlim(ax_A2, [0, max(lLx)]);
ylim(ax_A2, [0, max(cond_est) * 1.10]);

% exportFig(fig_A2, 'FigA2_2D_ConditionNumber', 88, 72);


%% ==================== Utility functions ====================

% ─────────────────────────────────────────────────────────────────────────
function styleAxes(ax)
% styleAxes — Uniform publication axis style.
%   Identical to all 1D figures (Fig01–Fig03).
%   Times New Roman 10 pt ticks, 11 pt labels, box on, inward ticks,
%   dotted grid GridAlpha=0.35, no minor grid, axis frame 0.8 pt,
%   TickLabelInterpreter='tex'.
set(ax, ...
    'FontName',             'Times New Roman', ...
    'FontSize',             10, ...
    'LineWidth',            0.8, ...
    'Box',                  'on', ...
    'TickDir',              'in', ...
    'TickLength',           [0.015, 0.015], ...
    'XMinorTick',           'off', ...
    'YMinorTick',           'off', ...
    'GridLineStyle',        ':', ...
    'GridAlpha',            0.35, ...
    'MinorGridLineStyle',   'none', ...
    'TickLabelInterpreter', 'tex');
grid(ax, 'on');
end


% ─────────────────────────────────────────────────────────────────────────
function exportFig(figHandle, filename, width_mm, height_mm)
% exportFig — Export to EPS (vector), PDF (vector), PNG (600 dpi).
%   Identical to the export function used in all 1D figures.
%   PaperPositionMode='manual' prevents MATLAB default centering.
set(figHandle, 'Renderer', 'painters');

w_cm = width_mm  / 10;
h_cm = height_mm / 10;

set(figHandle, 'Units',             'centimeters');
set(figHandle, 'Position',          [2, 2, w_cm, h_cm]);
set(figHandle, 'PaperUnits',        'centimeters');
set(figHandle, 'PaperPositionMode', 'manual');
set(figHandle, 'PaperSize',         [w_cm, h_cm]);
set(figHandle, 'PaperPosition',     [0, 0, w_cm, h_cm]);

print(figHandle, [filename, '.eps'], '-depsc', '-r0');
print(figHandle, [filename, '.pdf'], '-dpdf',  '-r0');
print(figHandle, [filename, '.png'], '-dpng',  '-r600');

fprintf('\n[exportFig] Saved  : %s  (.eps / .pdf / .png)\n', filename);
fprintf('[exportFig] Size   : %.0f x %.0f mm\n', width_mm, height_mm);
end


%% ==================== FEM solver and shape functions ====================
%  All functions below are UNCHANGED from the original script.
%  Only the plotting section above has been redesigned.

function [avg_ux_right, max_umag, total_Rx_left, cond_est] = solve_2d_sg_bfs(...
    Lx,Ly,E,nu,thickness,nelx,nely,l_micro,traction_right,body_force,bc_case,do_plots)

    a2 = l_micro^2/10;

    lambda = E*nu/((1+nu)*(1-2*nu));
    mu     = E/(2*(1+nu));

    C = [lambda+2*mu, lambda,      0;
         lambda,      lambda+2*mu, 0;
         0,           0,           mu];

    nnx   = nelx + 1;
    nny   = nely + 1;
    nnode = nnx*nny;
    ndof_per_node = 8;
    ndof  = ndof_per_node*nnode;

    xgrid = linspace(0,Lx,nnx);
    ygrid = linspace(0,Ly,nny);

    node_id = @(ix,iy) (iy-1)*nnx + ix;

    coords = zeros(nnode,2);
    for iy = 1:nny
        for ix = 1:nnx
            n = node_id(ix,iy);
            coords(n,:) = [xgrid(ix), ygrid(iy)];
        end
    end

    conn = zeros(nelx*nely,4);
    e = 0;
    for ey = 1:nely
        for ex = 1:nelx
            e = e+1;
            conn(e,:) = [node_id(ex,ey),   node_id(ex+1,ey), ...
                         node_id(ex+1,ey+1), node_id(ex,ey+1)];
        end
    end

    nel = size(conn,1);
    K   = sparse(ndof,ndof);
    F   = zeros(ndof,1);

    [gp, gw] = gauss_1d_01(4);

    for e = 1:nel
        nodes = conn(e,:);
        xy    = coords(nodes,:);
        hx    = xy(2,1) - xy(1,1);
        hy    = xy(4,2) - xy(1,2);
        if hx <= 0 || hy <= 0
            error('Invalid element geometry at element %d: hx=%g, hy=%g.', e, hx, hy);
        end
        detJ = hx*hy;
        Ke   = zeros(32,32);
        Fe   = zeros(32,1);
        for ig = 1:length(gp)
            s = gp(ig); ws = gw(ig);
            for jg = 1:length(gp)
                t = gp(jg); wt = gw(jg);
                wgt = ws*wt*detJ*thickness;
                [N,Nx,Ny,Nxx,Nyy,Nxy] = bfs_shape_2d(s,t,hx,hy);
                [B,Bx,By,Nv] = make_B_matrices(N,Nx,Ny,Nxx,Nyy,Nxy);
                Ke = Ke + (B.'*C*B + a2*(Bx.'*C*Bx + By.'*C*By))*wgt;
                Fe = Fe + Nv.'*body_force*wgt;
            end
        end
        edofs = element_dofs(nodes,ndof_per_node);
        K(edofs,edofs) = K(edofs,edofs) + Ke;
        F(edofs)       = F(edofs) + Fe;
    end

    for ey = 1:nely
        e_right = (ey-1)*nelx + nelx;
        nodes   = conn(e_right,:);
        xy      = coords(nodes,:);
        hx      = xy(2,1) - xy(1,1);
        hy      = xy(4,2) - xy(1,2);
        edofs   = element_dofs(nodes,ndof_per_node);
        Fe      = zeros(32,1);
        s       = 1.0;
        for jg = 1:length(gp)
            t = gp(jg); wt = gw(jg);
            edgeJ = hy;
            [N,Nx,Ny,Nxx,Nyy,Nxy] = bfs_shape_2d(s,t,hx,hy); %#ok<ASGLU>
            [~,~,~,Nv] = make_B_matrices(N,Nx,Ny,Nxx,Nyy,Nxy);
            Fe = Fe + Nv.'*traction_right*(edgeJ*wt*thickness);
        end
        F(edofs) = F(edofs) + Fe;
    end

    fixed_dofs  = [];
    left_nodes  = arrayfun(@(iy) node_id(1,iy), 1:nny);
    switch bc_case
        case "clamped_gradient"
            for n = left_nodes
                fixed_dofs = [fixed_dofs, (n-1)*8 + (1:8)]; %#ok<AGROW>
            end
        case "classical_clamp"
            for n = left_nodes
                fixed_dofs = [fixed_dofs, (n-1)*8 + [1,5]]; %#ok<AGROW>
            end
        otherwise
            error('Unknown bc_case.');
    end
    fixed_dofs = unique(fixed_dofs);
    free_dofs  = setdiff(1:ndof, fixed_dofs);

    Kff         = K(free_dofs,free_dofs);
    Ff          = F(free_dofs);
    scale_diag  = sqrt(abs(diag(Kff)));
    scale_diag(scale_diag < eps) = 1.0;
    Sscale      = spdiags(1./scale_diag,0,length(free_dofs),length(free_dofs));
    Kscaled     = Sscale*Kff*Sscale;
    Fscaled     = Sscale*Ff;
    cond_est    = condest(Kscaled);

    if ~isfinite(cond_est) || cond_est > 1.0e14
        reg = 1.0e-10*mean(abs(diag(Kscaled)));
        if reg == 0 || ~isfinite(reg), reg = 1.0e-10; end
        Kscaled = Kscaled + reg*speye(size(Kscaled));
    end

    y = Kscaled \ Fscaled;
    D = zeros(ndof,1);
    D(free_dofs) = Sscale*y;
    R = K*D - F;

    u_nodes = D(1:8:end);
    v_nodes = D(5:8:end);
    umag    = sqrt(u_nodes.^2 + v_nodes.^2);

    right_nodes  = arrayfun(@(iy) node_id(nnx,iy), 1:nny);
    avg_ux_right = mean(u_nodes(right_nodes));
    max_umag     = max(umag);
    total_Rx_left = sum(R(arrayfun(@(n) (n-1)*8+1, left_nodes)));

    if do_plots
        fprintf('\n===== Detailed 2D SG field for l = %.5f =====\n', l_micro);
        fprintf('Average u on right edge  = %.12e m\n', avg_ux_right);
        fprintf('Maximum displacement mag = %.12e m\n', max_umag);
        fprintf('Total reaction Fx left   = %.12e N\n', total_Rx_left);
        fprintf('Condition estimate       = %.12e\n',   cond_est);
    end
end


function edofs = element_dofs(nodes,ndof_per_node)
    edofs = zeros(1, numel(nodes)*ndof_per_node);
    c = 0;
    for a = 1:numel(nodes)
        n = nodes(a);
        edofs(c+1:c+ndof_per_node) = (n-1)*ndof_per_node + (1:ndof_per_node);
        c = c + ndof_per_node;
    end
end

function [gp,gw] = gauss_1d_01(n)
    switch n
        case 4
            x = [-0.8611363115940526, -0.3399810435848563, ...
                  0.3399810435848563,  0.8611363115940526];
            w = [0.3478548451374538,  0.6521451548625461, ...
                 0.6521451548625461,  0.3478548451374538];
        otherwise
            error('Only n=4 implemented here.');
    end
    gp = (x+1)/2;
    gw = w/2;
end

function [N, Nx, Ny, Nxx, Nyy, Nxy] = bfs_shape_2d(s,t,hx,hy)
    [Hx0,Hx1,Hx0x,Hx1x,Hx0xx,Hx1xx] = hermite_1d_two_nodes(s,hx);
    [Hy0,Hy1,Hy0y,Hy1y,Hy0yy,Hy1yy] = hermite_1d_two_nodes(t,hy);

    xs = [1 2 2 1];
    ys = [1 1 2 2];
    N   = zeros(1,16); Nx  = zeros(1,16); Ny  = zeros(1,16);
    Nxx = zeros(1,16); Nyy = zeros(1,16); Nxy = zeros(1,16);

    for a = 1:4
        ix = xs(a); iy = ys(a);
        p  = (a-1)*4;
        N(p+1)   = Hx0(ix)*Hy0(iy);   Nx(p+1)  = Hx0x(ix)*Hy0(iy);
        Ny(p+1)  = Hx0(ix)*Hy0y(iy);  Nxx(p+1) = Hx0xx(ix)*Hy0(iy);
        Nyy(p+1) = Hx0(ix)*Hy0yy(iy); Nxy(p+1) = Hx0x(ix)*Hy0y(iy);
        N(p+2)   = Hx1(ix)*Hy0(iy);   Nx(p+2)  = Hx1x(ix)*Hy0(iy);
        Ny(p+2)  = Hx1(ix)*Hy0y(iy);  Nxx(p+2) = Hx1xx(ix)*Hy0(iy);
        Nyy(p+2) = Hx1(ix)*Hy0yy(iy); Nxy(p+2) = Hx1x(ix)*Hy0y(iy);
        N(p+3)   = Hx0(ix)*Hy1(iy);   Nx(p+3)  = Hx0x(ix)*Hy1(iy);
        Ny(p+3)  = Hx0(ix)*Hy1y(iy);  Nxx(p+3) = Hx0xx(ix)*Hy1(iy);
        Nyy(p+3) = Hx0(ix)*Hy1yy(iy); Nxy(p+3) = Hx0x(ix)*Hy1y(iy);
        N(p+4)   = Hx1(ix)*Hy1(iy);   Nx(p+4)  = Hx1x(ix)*Hy1(iy);
        Ny(p+4)  = Hx1(ix)*Hy1y(iy);  Nxx(p+4) = Hx1xx(ix)*Hy1(iy);
        Nyy(p+4) = Hx1(ix)*Hy1yy(iy); Nxy(p+4) = Hx1x(ix)*Hy1y(iy);
    end
end

function [H0,H1,H0x,H1x,H0xx,H1xx] = hermite_1d_two_nodes(s,L)
    h1 = 1 - 3*s^2 + 2*s^3;   h2 = L*(s - 2*s^2 + s^3);
    h3 = 3*s^2 - 2*s^3;        h4 = L*(-s^2 + s^3);
    dh1 = -6*s + 6*s^2;        dh2 = L*(1 - 4*s + 3*s^2);
    dh3 = 6*s - 6*s^2;         dh4 = L*(-2*s + 3*s^2);
    d2h1 = -6 + 12*s;          d2h2 = L*(-4 + 6*s);
    d2h3 = 6 - 12*s;           d2h4 = L*(-2 + 6*s);
    H0 = [h1, h3];  H1 = [h2, h4];
    H0x  = (1/L)*[dh1,  dh3];   H1x  = (1/L)*[dh2,  dh4];
    H0xx = (1/L^2)*[d2h1, d2h3]; H1xx = (1/L^2)*[d2h2, d2h4];
end

function [B,Bx,By,Nv] = make_B_matrices(N,Nx,Ny,Nxx,Nyy,Nxy)
    B  = zeros(3,32); Bx = zeros(3,32);
    By = zeros(3,32); Nv = zeros(2,32);
    for a = 1:4
        sp = (a-1)*4 + (1:4);
        up = (a-1)*8 + (1:4);
        vp = (a-1)*8 + (5:8);
        Nv(1,up) = N(sp);   Nv(2,vp) = N(sp);
        B(1,up)  = Nx(sp);  B(2,vp)  = Ny(sp);
        B(3,up)  = Ny(sp);  B(3,vp)  = Nx(sp);
        Bx(1,up) = Nxx(sp); Bx(2,vp) = Nxy(sp);
        Bx(3,up) = Nxy(sp); Bx(3,vp) = Nxx(sp);
        By(1,up) = Nxy(sp); By(2,vp) = Nyy(sp);
        By(3,up) = Nyy(sp); By(3,vp) = Nxy(sp);
    end
end
