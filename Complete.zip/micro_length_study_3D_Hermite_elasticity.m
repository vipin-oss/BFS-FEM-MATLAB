%% micro_length_study_3D_Hermite_elasticity.m
%
% Microstructural length-scale study for 3D strain-gradient elasticity
% using C1 tensor-product tricubic Hermite hexahedral elements.
%
% Model:
%   W = 1/2 eps^T C eps
%       + 1/2 a^2 [eps_x^T C eps_x + eps_y^T C eps_y + eps_z^T C eps_z]
%   a^2 = l_micro^2/10.
%
% Problem:
%   Cuboid [0,Lx]x[0,Ly]x[0,Lz]
%   Left face: strain-gradient clamped
%   Right face: uniform x-traction
%
% -------------------------------------------------------------------------
%  FIGURE PACKAGE (publication-ready, matches Fig01-Fig07 style exactly):
%    MAIN : Fig08  (a) ratio u/u_ref vs l/Lx ; (b) condition number vs l/Lx
%    MAIN : Fig09  3D coloured displacement field (2 views, l/Lx = 0.05)
%  (Export manually from the figure window.)
% -------------------------------------------------------------------------

clear; clc; close all;

% ── Root defaults — IDENTICAL to all 1D/2D figures in this manuscript ─────
set(groot, 'defaultAxesFontName',             'Times New Roman');
set(groot, 'defaultAxesFontSize',             10);
set(groot, 'defaultTextFontName',             'Times New Roman');
set(groot, 'defaultTextFontSize',             10);
set(groot, 'defaultAxesTickLabelInterpreter', 'tex');
set(groot, 'defaultTextInterpreter',          'tex');

%% -------------------- Input data --------------------
Lx = 1.0;
Ly = 0.20;
Lz = 0.20;
E  = 200e9;
nu = 0.30;
nelx = 4;
nely = 2;
nelz = 2;
traction_right = [1.0e6; 0.0; 0.0];
body_force = [0.0; 0.0; 0.0];
bc_case = "clamped_gradient";

l_list = [0.005 0.01 0.02 0.05 0.075 0.10 0.15 0.20];
ncase = length(l_list);

avg_u_right = zeros(ncase,1);
max_umag    = zeros(ncase,1);
react_left  = zeros(ncase,1);
cond_est    = zeros(ncase,1);

%% -------------------- Run length study --------------------
for i = 1:ncase
    l_micro = l_list(i);
    fprintf('\n--- Solving 3D SG problem for l = %.5f ---\n', l_micro);
    [avg_u_right(i), max_umag(i), react_left(i), cond_est(i)] = ...
        solve_3d_sg_hermite(Lx,Ly,Lz,E,nu,nelx,nely,nelz,l_micro, ...
                            traction_right,body_force,bc_case,false);
end

u_ref = avg_u_right(1);
ratio = avg_u_right / u_ref;
applied_Fx = traction_right(1)*Ly*Lz;
reaction_error_percent = 100*abs(react_left + applied_Fx)/abs(applied_Fx);

%% -------------------- Print table --------------------
fprintf('\n===== 3D SG microstructural length study =====\n');
fprintf('Mesh                 = %d x %d x %d Hermite hex elements\n', nelx, nely, nelz);
fprintf('Domain               = %.4g x %.4g x %.4g m\n', Lx, Ly, Lz);
fprintf('Right traction tx    = %.6e Pa\n', traction_right(1));
fprintf('Applied resultant Fx = %.6e N\n\n', applied_Fx);
fprintf('%10s %14s %20s %20s %16s %16s %16s\n', ...
    'l_micro','a=l/sqrt(10)','avg u right','max |u|','u/u_ref','Rx error (%)','condest');
fprintf('%10s %14s %20s %20s %16s %16s %16s\n', ...
    '-------','------------','-----------','-------','-------','------------','-------');
for i = 1:ncase
    a = l_list(i)/sqrt(10);
    fprintf('%10.5f %14.6e %20.12e %20.12e %16.8f %16.6e %16.6e\n', ...
        l_list(i), a, avg_u_right(i), max_umag(i), ratio(i), ...
        reaction_error_percent(i), cond_est(i));
end

%% ========================================================================
%%  PUBLICATION-QUALITY FIGURE — Fig08_3D_MicroLengthEffect
%%
%%  Two-panel composite (MAIN manuscript):
%%    (a) Normalised displacement ratio  u/u_ref  vs  l/Lx
%%    (b) Estimated condition number  kappa  vs  l/Lx
%%
%%  Visual identity: matches Fig04_2D_MicroLengthEffect exactly.
%% ========================================================================

% ── Shared abscissa: l/Lx (dimensionless, consistent with Fig02/Fig04) ─────
lLx = l_list / Lx;

% ── Colour (Wong 2011, entry 1 — blue, identical to all figures) ──────────
C_blue = [0.000, 0.447, 0.698];

% ── Line and marker constants (identical to all figures) ──────────────────
LW = 1.5;     % primary line width
MS = 6;       % marker size

% ── Figure dimensions — identical to Fig02 / Fig04 ────────────────────────
fig_w_mm = 176;   % double-column width (mm)
fig_h_mm =  72;   % height (mm)
fig = figure('Color','white', ...
             'Units','centimeters', ...
             'Position',[2, 2, fig_w_mm/10, fig_h_mm/10]);

% ── Two-panel tiled layout (same spacing as all figures) ──────────────────
tl = tiledlayout(1, 2, ...
    'TileSpacing', 'compact', ...
    'Padding',     'compact');

% =========================================================================
%  Panel (a) — Normalised displacement ratio vs l/Lx
% =========================================================================
ax1 = nexttile(tl, 1);
plot(ax1, lLx, ratio, ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       LW, ...
    'Marker',          'o', ...
    'MarkerSize',      MS, ...
    'MarkerFaceColor', 'white');
styleAxes(ax1);
xlabel(ax1, 'l/L_x', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
ylabel(ax1, 'u_{SG}/u_{ref}', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
xlim(ax1, [0, max(lLx)]);
r_span = max(ratio) - min(ratio);
ylim(ax1, [min(ratio) - 0.15*r_span,  max(ratio) + 0.10*r_span]);

% Panel label — identical position/style to all figures
text(ax1, 0.14, 0.93, '(a)', ...
    'Units',       'normalized', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11, ...
    'FontWeight',  'bold', ...
    'Interpreter', 'none');

% =========================================================================
%  Panel (b) — Estimated condition number vs l/Lx
% =========================================================================
ax2 = nexttile(tl, 2);
plot(ax2, lLx, cond_est, ...
    'Color',           C_blue, ...
    'LineStyle',       '-', ...
    'LineWidth',       LW, ...
    'Marker',          'o', ...
    'MarkerSize',      MS, ...
    'MarkerFaceColor', 'white');
styleAxes(ax2);
xlabel(ax2, 'l/L_x', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
ylabel(ax2, 'Estimated condition number \kappa', ...
    'Interpreter', 'tex', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11);
xlim(ax2, [0, max(lLx)]);
k_span = max(cond_est) - min(cond_est);
ylim(ax2, [min(cond_est) - 0.15*k_span,  max(cond_est) + 0.10*k_span]);

% Panel label
text(ax2, 0.14, 0.93, '(b)', ...
    'Units',       'normalized', ...
    'FontName',    'Times New Roman', ...
    'FontSize',    11, ...
    'FontWeight',  'bold', ...
    'Interpreter', 'none');


%% ========================================================================
%%  PUBLICATION-QUALITY FIGURE — Fig09_3D_DisplacementField
%%
%%  Two-panel 3D displacement-magnitude field (l/Lx = 0.05):
%%    (a) front-right view  — shows the loaded (x=Lx) face and top
%%    (b) back-left view    — shows the clamped (x=0) face
%%  Shared colour scale, single shared colorbar.
%% ========================================================================

l_field = 0.05;
field_data = solve_3d_sg_hermite(Lx,Ly,Lz,E,nu,nelx,nely,nelz,l_field, ...
                                 traction_right,body_force,bc_case,true);

umag_um = field_data.umag_nodes * 1e6;     % metres -> micrometres
coords  = field_data.coords;
conn    = field_data.conn;

% ── Boundary quad-faces of the hex mesh ───────────────────────────────────
bf_nodes = extract_boundary_faces_hex(conn);

% ── Shared colour scale: 0 to global max |u| ──────────────────────────────
cmin = 0;
cmax = max(umag_um);

% ── Figure ────────────────────────────────────────────────────────────────
fig_w_3d = 176;   % double-column width (mm)
fig_h_3d =  85;   % height (mm)
fig3d = figure('Color','white', ...
               'Units','centimeters', ...
               'Position',[2, 2, fig_w_3d/10, fig_h_3d/10]);

tl3d = tiledlayout(1, 2, ...
    'TileSpacing', 'compact', ...
    'Padding',     'compact');

% Two complementary viewing angles (az, el)
view_angles = [135, 25;   % (a) front-right: loaded face + top
               -45, 25];  % (b) back-left:  clamped face + top
panel_labels = {'(a)', '(b)'};

for k = 1:2
    ax = nexttile(tl3d, k);
    hold(ax, 'on');

    patch(ax, 'Faces',           bf_nodes, ...
               'Vertices',       coords, ...
               'FaceVertexCData', umag_um, ...
               'FaceColor',      'interp', ...
               'EdgeColor',      [0.5 0.5 0.5], ...
               'LineWidth',      0.4);

    set(ax, 'CLim', [cmin, cmax]);
    colormap(ax, parula);

    view(ax, view_angles(k,1), view_angles(k,2));
    axis(ax, 'equal');
    xlim(ax, [0, Lx]);
    ylim(ax, [0, Ly]);
    zlim(ax, [0, Lz]);

    % --- 3D axes style (Times New Roman, consistent with package) ----------
    set(ax, 'FontSize',  10, ...
            'FontName',  'Times New Roman', ...
            'LineWidth', 0.8, ...
            'Box',       'on', ...
            'TickDir',   'in', ...
            'TickLength',[0.015 0.015], ...
            'GridLineStyle', ':', ...
            'GridAlpha', 0.35, ...
            'XMinorTick','off', 'YMinorTick','off', ...
            'TickLabelInterpreter', 'tex');
    grid(ax, 'on');

    xlabel(ax, 'x (m)', 'Interpreter','tex', ...
           'FontName','Times New Roman','FontSize',11);
    ylabel(ax, 'y (m)', 'Interpreter','tex', ...
           'FontName','Times New Roman','FontSize',11);
    zlabel(ax, 'z (m)', 'Interpreter','tex', ...
           'FontName','Times New Roman','FontSize',11);

    % --- Panel label (black bold, white background box for visibility) -----
    %  In 3D the top-left corner often has white empty space, so white
    %  text is invisible there. Use black text on a white semi-opaque
    %  background box so the label is readable on any surface colour.
    text(ax, 0.04, 0.94, panel_labels{k}, ...
         'Units','normalized', ...
         'FontName','Times New Roman', ...
         'FontSize',11, ...
         'FontWeight','bold', ...
         'Interpreter','none', ...
         'Color','k', ...
         'BackgroundColor','w', ...
         'EdgeColor','none', ...
         'Margin',2, ...
         'Clipping','off');
end

% --- Single shared colourbar on the right of the layout -------------------
% --- Shared colourbar -----------------------------------
cb = colorbar;

cb.Label.String      = '|u| (\mu m)';
cb.Label.Interpreter = 'tex';
cb.Label.FontName    = 'Times New Roman';
cb.Label.FontSize    = 10;

cb.FontName          = 'Times New Roman';
cb.FontSize          = 9;

%% ========================================================================
%%  UTILITY FUNCTIONS
%% ========================================================================

function styleAxes(ax)
% styleAxes — Uniform publication axis style for 2D panels (Fig08).
set(ax, ...
    'FontName',             'Times New Roman', ...
    'FontSize',             10, ...
    'LineWidth',            0.8, ...
    'Box',                  'on', ...
    'TickDir',              'in', ...
    'TickLength',           [0.015, 0.015], ...
    'XMinorTick',           'off', ...
    'YMinorTick',           'off', ...
    'GridLineStyle',        ':', ...
    'GridAlpha',            0.35, ...
    'MinorGridLineStyle',   'none', ...
    'TickLabelInterpreter', 'tex');
grid(ax, 'on');
end

function bf_nodes = extract_boundary_faces_hex(conn)
% Extract boundary quad-faces from a hexahedral mesh.
%   conn     : Nel x 8  node-connectivity (standard hex ordering).
%   Returns bf_nodes (Nbf x 4): the 4 nodes of each boundary face.
%   A face shared by two elements is interior and removed; faces that
%   appear exactly once (after sorting their node IDs) are boundary.
nel = size(conn, 1);
% 6 quad faces per element, consistent winding:
%   face 1 (z-min): 1 2 3 4
%   face 2 (z-max): 5 6 7 8
%   face 3 (y-min): 1 2 6 5
%   face 4 (y-max): 4 3 7 8
%   face 5 (x-min): 1 4 8 5
%   face 6 (x-max): 2 3 7 6
face_def = [1 2 3 4;  5 6 7 8;  1 2 6 5;  4 3 7 8;  1 4 8 5;  2 3 7 6];
all_faces  = zeros(nel*6, 4);
all_sorted = zeros(nel*6, 4);
for e = 1:nel
    for f = 1:6
        idx = (e-1)*6 + f;
        fc = conn(e, face_def(f,:));
        all_faces(idx,:)  = fc;
        all_sorted(idx,:) = sort(fc);
    end
end
% A face is a boundary face iff its sorted node-list appears exactly once.
[~, ~, ic] = unique(all_sorted, 'rows');
counts     = accumarray(ic, 1);
is_boundary = counts(ic) == 1;
bf_nodes    = all_faces(is_boundary, :);
end

%% ========================================================================
%%  FEM SOLVER AND SHAPE FUNCTIONS  (UNCHANGED)
%%  Only the do_plots branch returns field data as a struct for external
%%  plotting, consistent with the 2D anisotropic solver.
%% ========================================================================

function varargout = solve_3d_sg_hermite(...
    Lx,Ly,Lz,E,nu,nelx,nely,nelz,l_micro,traction_right,body_force,bc_case,do_plots)

    a2 = l_micro^2/10;

    % Material matrix: 3D isotropic elasticity
    lambda = E*nu/((1+nu)*(1-2*nu));
    mu     = E/(2*(1+nu));
    C = [lambda+2*mu, lambda,      lambda,      0,  0,  0;
         lambda,      lambda+2*mu, lambda,      0,  0,  0;
         lambda,      lambda,      lambda+2*mu, 0,  0,  0;
         0,           0,           0,           mu, 0,  0;
         0,           0,           0,           0,  mu, 0;
         0,           0,           0,           0,  0,  mu];

    % Mesh
    nnx = nelx + 1;
    nny = nely + 1;
    nnz = nelz + 1;
    nnode = nnx*nny*nnz;
    ndof_per_node = 24;
    ndof = ndof_per_node*nnode;

    xgrid = linspace(0,Lx,nnx);
    ygrid = linspace(0,Ly,nny);
    zgrid = linspace(0,Lz,nnz);

    node_id = @(ix,iy,iz) (iz-1)*nnx*nny + (iy-1)*nnx + ix;

    coords = zeros(nnode,3);
    for iz = 1:nnz
        for iy = 1:nny
            for ix = 1:nnx
                n = node_id(ix,iy,iz);
                coords(n,:) = [xgrid(ix), ygrid(iy), zgrid(iz)];
            end
        end
    end

    conn = zeros(nelx*nely*nelz,8);
    e = 0;
    for ez = 1:nelz
        for ey = 1:nely
            for ex = 1:nelx
                e = e + 1;
                conn(e,:) = [node_id(ex,ey,ez), node_id(ex+1,ey,ez), ...
                             node_id(ex+1,ey+1,ez), node_id(ex,ey+1,ez), ...
                             node_id(ex,ey,ez+1), node_id(ex+1,ey,ez+1), ...
                             node_id(ex+1,ey+1,ez+1), node_id(ex,ey+1,ez+1)];
            end
        end
    end

    nel = size(conn,1);
    K = sparse(ndof,ndof);
    F = zeros(ndof,1);

    [gp, gw] = gauss_1d_01(3);

    % Assembly
    for e = 1:nel
        nodes = conn(e,:);
        xy = coords(nodes,:);
        hx = xy(2,1) - xy(1,1);
        hy = xy(4,2) - xy(1,2);
        hz = xy(5,3) - xy(1,3);
        if hx <= 0 || hy <= 0 || hz <= 0
            error('Invalid element geometry at element %d: hx=%g, hy=%g, hz=%g.', e, hx, hy, hz);
        end
        detJ = hx*hy*hz;
        Ke = zeros(192,192);
        Fe = zeros(192,1);
        for ig = 1:length(gp)
            s = gp(ig); ws = gw(ig);
            for jg = 1:length(gp)
                t = gp(jg); wt = gw(jg);
                for kg = 1:length(gp)
                    r = gp(kg); wr = gw(kg);
                    wgt = ws*wt*wr*detJ;
                    [N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz] = hermite_shape_3d(s,t,r,hx,hy,hz);
                    [B,Bx,By,Bz,Nv] = make_B_matrices_3d(N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz);
                    Ke = Ke + (B.'*C*B + a2*(Bx.'*C*Bx + By.'*C*By + Bz.'*C*Bz))*wgt;
                    Fe = Fe + Nv.'*body_force*wgt;
                end
            end
        end
        edofs = element_dofs(nodes,ndof_per_node);
        K(edofs,edofs) = K(edofs,edofs) + Ke;
        F(edofs) = F(edofs) + Fe;
    end

    % Right-face traction x=Lx
    for ez = 1:nelz
        for ey = 1:nely
            e_right = (ez-1)*nelx*nely + (ey-1)*nelx + nelx;
            nodes = conn(e_right,:);
            xy = coords(nodes,:);
            hx = xy(2,1) - xy(1,1);
            hy = xy(4,2) - xy(1,2);
            hz = xy(5,3) - xy(1,3);
            edofs = element_dofs(nodes,ndof_per_node);
            Fe = zeros(192,1);
            s = 1.0;
            for jg = 1:length(gp)
                t = gp(jg); wt = gw(jg);
                for kg = 1:length(gp)
                    r = gp(kg); wr = gw(kg);
                    faceJ = hy*hz;
                    [N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz] = hermite_shape_3d(s,t,r,hx,hy,hz); %#ok<ASGLU>
                    [~,~,~,~,Nv] = make_B_matrices_3d(N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz);
                    Fe = Fe + Nv.'*traction_right*(wt*wr*faceJ);
                end
            end
            F(edofs) = F(edofs) + Fe;
        end
    end

    % BCs
    fixed_dofs = [];
    left_nodes = [];
    for iz = 1:nnz
        for iy = 1:nny
            left_nodes(end+1) = node_id(1,iy,iz); %#ok<AGROW>
        end
    end
    switch bc_case
        case "clamped_gradient"
            for n = left_nodes
                fixed_dofs = [fixed_dofs, (n-1)*24 + (1:24)]; %#ok<AGROW>
            end
        case "classical_clamp"
            for n = left_nodes
                fixed_dofs = [fixed_dofs, (n-1)*24 + [1,9,17]]; %#ok<AGROW>
            end
        otherwise
            error('Unknown bc_case.');
    end
    fixed_dofs = unique(fixed_dofs);
    free_dofs = setdiff(1:ndof,fixed_dofs);

    % Scaled solve
    Kff = K(free_dofs,free_dofs);
    Ff  = F(free_dofs);
    scale_diag = sqrt(abs(diag(Kff)));
    scale_diag(scale_diag < eps) = 1.0;
    Sscale = spdiags(1./scale_diag,0,length(free_dofs),length(free_dofs));
    Kscaled = Sscale*Kff*Sscale;
    Fscaled = Sscale*Ff;
    cond_est = condest(Kscaled);
    if ~isfinite(cond_est) || cond_est > 1.0e14
        reg = 1.0e-10*mean(abs(diag(Kscaled)));
        if reg == 0 || ~isfinite(reg)
            reg = 1.0e-10;
        end
        Kscaled = Kscaled + reg*speye(size(Kscaled));
    end
    y = Kscaled\Fscaled;
    D = zeros(ndof,1);
    D(free_dofs) = Sscale*y;

    R = K*D - F;

    u_nodes = D(1:24:end);
    v_nodes = D(9:24:end);
    w_nodes = D(17:24:end);
    umag = sqrt(u_nodes.^2 + v_nodes.^2 + w_nodes.^2);

    right_nodes = [];
    for iz = 1:nnz
        for iy = 1:nny
            right_nodes(end+1) = node_id(nnx,iy,iz); %#ok<AGROW>
        end
    end
    avg_ux_right = mean(u_nodes(right_nodes));
    max_umag = max(umag);

    left_u_value_dofs = arrayfun(@(n) (n-1)*24+1, left_nodes);
    total_Rx_left = sum(R(left_u_value_dofs));

    if do_plots
        % Return field data as struct for external plotting
        varargout{1} = struct( ...
            'avg_ux_right', avg_ux_right, ...
            'max_umag',     max_umag, ...
            'total_Rx',     total_Rx_left, ...
            'cond_est',     cond_est, ...
            'u_nodes',      u_nodes, ...
            'v_nodes',      v_nodes, ...
            'w_nodes',      w_nodes, ...
            'umag_nodes',   umag, ...
            'coords',       coords, ...
            'conn',         conn);
    else
        varargout{1} = avg_ux_right;
        varargout{2} = max_umag;
        varargout{3} = total_Rx_left;
        varargout{4} = cond_est;
    end
end

function edofs = element_dofs(nodes,ndof_per_node)
    edofs = zeros(1,numel(nodes)*ndof_per_node);
    c = 0;
    for a = 1:numel(nodes)
        n = nodes(a);
        edofs(c+1:c+ndof_per_node) = (n-1)*ndof_per_node + (1:ndof_per_node);
        c = c + ndof_per_node;
    end
end

function [gp,gw] = gauss_1d_01(n)
    switch n
        case 3
            x = [-sqrt(3/5), 0, sqrt(3/5)];
            w = [5/9, 8/9, 5/9];
        otherwise
            error('Only n=3 implemented here.');
    end
    gp = (x+1)/2;
    gw = w/2;
end

function [H0,H1,H0x,H1x,H0xx,H1xx] = hermite_1d_two_nodes(s,L)
    h1 = 1 - 3*s^2 + 2*s^3;
    h2 = L*(s - 2*s^2 + s^3);
    h3 = 3*s^2 - 2*s^3;
    h4 = L*(-s^2 + s^3);
    dh1 = -6*s + 6*s^2;
    dh2 = L*(1 - 4*s + 3*s^2);
    dh3 = 6*s - 6*s^2;
    dh4 = L*(-2*s + 3*s^2);
    d2h1 = -6 + 12*s;
    d2h2 = L*(-4 + 6*s);
    d2h3 = 6 - 12*s;
    d2h4 = L*(-2 + 6*s);
    H0 = [h1, h3];
    H1 = [h2, h4];
    H0x = (1/L)*[dh1, dh3];
    H1x = (1/L)*[dh2, dh4];
    H0xx = (1/L^2)*[d2h1, d2h3];
    H1xx = (1/L^2)*[d2h2, d2h4];
end

function [N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz] = hermite_shape_3d(s,t,r,hx,hy,hz)
    [Hx0,Hx1,Hx0x,Hx1x,Hx0xx,Hx1xx] = hermite_1d_two_nodes(s,hx);
    [Hy0,Hy1,Hy0y,Hy1y,Hy0yy,Hy1yy] = hermite_1d_two_nodes(t,hy);
    [Hz0,Hz1,Hz0z,Hz1z,Hz0zz,Hz1zz] = hermite_1d_two_nodes(r,hz);
    xs = [1 2 2 1 1 2 2 1];
    ys = [1 1 2 2 1 1 2 2];
    zs = [1 1 1 1 2 2 2 2];
    N   = zeros(1,64); Nx  = zeros(1,64); Ny  = zeros(1,64); Nz  = zeros(1,64);
    Nxx = zeros(1,64); Nyy = zeros(1,64); Nzz = zeros(1,64);
    Nxy = zeros(1,64); Nxz = zeros(1,64); Nyz = zeros(1,64);
    combos = [0 0 0; 1 0 0; 0 1 0; 0 0 1; 1 1 0; 1 0 1; 0 1 1; 1 1 1];
    for a = 1:8
        ix = xs(a); iy = ys(a); iz = zs(a);
        p = (a-1)*8;
        for q = 1:8
            cx = combos(q,1); cy = combos(q,2); cz = combos(q,3);
            [X,Xx,Xxx] = pickH(cx,ix,Hx0,Hx1,Hx0x,Hx1x,Hx0xx,Hx1xx);
            [Y,Yy,Yyy] = pickH(cy,iy,Hy0,Hy1,Hy0y,Hy1y,Hy0yy,Hy1yy);
            [Z,Zz,Zzz] = pickH(cz,iz,Hz0,Hz1,Hz0z,Hz1z,Hz0zz,Hz1zz);
            id = p+q;
            N(id)   = X*Y*Z;
            Nx(id)  = Xx*Y*Z;
            Ny(id)  = X*Yy*Z;
            Nz(id)  = X*Y*Zz;
            Nxx(id) = Xxx*Y*Z;
            Nyy(id) = X*Yyy*Z;
            Nzz(id) = X*Y*Zzz;
            Nxy(id) = Xx*Yy*Z;
            Nxz(id) = Xx*Y*Zz;
            Nyz(id) = X*Yy*Zz;
        end
    end
end

function [H,Hd,Hdd] = pickH(flag,idx,H0,H1,H0d,H1d,H0dd,H1dd)
    if flag == 0
        H = H0(idx); Hd = H0d(idx); Hdd = H0dd(idx);
    else
        H = H1(idx); Hd = H1d(idx); Hdd = H1dd(idx);
    end
end

function [B,Bx,By,Bz,Nv] = make_B_matrices_3d(N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz)
    B  = zeros(6,192);
    Bx = zeros(6,192);
    By = zeros(6,192);
    Bz = zeros(6,192);
    Nv = zeros(3,192);
    for a = 1:8
        sp = (a-1)*8 + (1:8);
        up = (a-1)*24 + (1:8);
        vp = (a-1)*24 + (9:16);
        wp = (a-1)*24 + (17:24);
        Nv(1,up) = N(sp);
        Nv(2,vp) = N(sp);
        Nv(3,wp) = N(sp);
        B(1,up) = Nx(sp);
        B(2,vp) = Ny(sp);
        B(3,wp) = Nz(sp);
        B(4,vp) = Nz(sp);
        B(4,wp) = Ny(sp);
        B(5,up) = Nz(sp);
        B(5,wp) = Nx(sp);
        B(6,up) = Ny(sp);
        B(6,vp) = Nx(sp);
        Bx(1,up) = Nxx(sp);
        Bx(2,vp) = Nxy(sp);
        Bx(3,wp) = Nxz(sp);
        Bx(4,vp) = Nxz(sp);
        Bx(4,wp) = Nxy(sp);
        Bx(5,up) = Nxz(sp);
        Bx(5,wp) = Nxx(sp);
        Bx(6,up) = Nxy(sp);
        Bx(6,vp) = Nxx(sp);
        By(1,up) = Nxy(sp);
        By(2,vp) = Nyy(sp);
        By(3,wp) = Nyz(sp);
        By(4,vp) = Nyz(sp);
        By(4,wp) = Nyy(sp);
        By(5,up) = Nyz(sp);
        By(5,wp) = Nxy(sp);
        By(6,up) = Nyy(sp);
        By(6,vp) = Nxy(sp);
        Bz(1,up) = Nxz(sp);
        Bz(2,vp) = Nyz(sp);
        Bz(3,wp) = Nzz(sp);
        Bz(4,vp) = Nzz(sp);
        Bz(4,wp) = Nyz(sp);
        Bz(5,up) = Nzz(sp);
        Bz(5,wp) = Nxz(sp);
        Bz(6,up) = Nyz(sp);
        Bz(6,vp) = Nxz(sp);
    end
end
