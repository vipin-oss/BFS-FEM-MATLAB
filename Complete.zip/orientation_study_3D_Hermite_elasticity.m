%% orientation_study_3D_Hermite_elasticity.m
%
% Orientation-dependent anisotropic strain-gradient study for 3D
% elasticity using C1 tensor-product tricubic Hermite hexahedral elements.
%
% EXTENSION:
%   The ellipsoidal characteristic-length tensor is rotated about the
%   z-axis by an angle theta:
%
%     AAT_rot = R^T * diag(lx^2, ly^2, lz^2) * R
%
%   where R is the z-rotation matrix.  This produces a FULL symmetric
%   3x3 tensor, introducing cross-derivative terms in the gradient energy.
%
%   The gradient stiffness becomes:
%     Kg = (1/10) * sum_{i,j} AAT_rot(i,j) * Bi^T C Bj
%
%   which reduces to the original diagonal form when theta = 0.
%
% Study parameters:
%   lx = 0.20 m (dominant semi-axis)
%   ly = lz = 0.02 m (transverse semi-axes)
%   Rotation about z-axis: 0°, 15°, 30°, 45°, 60°, 75°, 90°
%
% Outputs:
%   - Average right-face displacement, max |u|, first natural frequency
%   - Normalized displacement ratio u(theta)/u(0°)
%   - Relative stiffness increase vs isotropic reference
%
% Figures (publication-quality, no auto-export):
%   Fig A+B: Two-panel — (a) u(theta)/u(0°) vs angle
%                      — (b) relative stiffness (%) vs angle
%   Fig C  (optional): 3D rotated ellipsoid visualization
%
% -------------------------------------------------------------------------

clear all; clc; close all;

% ── Root defaults — IDENTICAL to all 1D/2D/3D figures ────────────────────
set(groot, 'defaultAxesFontName',             'Times New Roman');
set(groot, 'defaultAxesFontSize',             10);
set(groot, 'defaultTextFontName',             'Times New Roman');
set(groot, 'defaultTextFontSize',             10);
set(groot, 'defaultAxesTickLabelInterpreter', 'tex');
set(groot, 'defaultTextInterpreter',          'tex');

%% -------------------- Input data --------------------
Lx = 1.0;
Ly = 0.20;
Lz = 0.20;
E  = 200e9;
nu = 0.30;
rho = 7800;            % mass density for eigenvalue analysis
nelx = 4;
nely = 2;
nelz = 2;
traction_right = [1.0e6; 0.0; 0.0];
body_force = [0.0; 0.0; 0.0];
bc_case = "clamped_gradient";

% Ellipsoidal semi-axes (fixed; only orientation varies)
lx = 0.20;
ly = 0.02;
lz = 0.02;

% Volume-equivalent isotropic reference length
l_iso = (lx*ly*lz)^(1/3);     % preserves ellipsoid volume

% Orientation angles (rotation about z-axis)
angle_list = [0, 15, 30, 45, 60, 75, 90];
nangle = numel(angle_list);

%% -------------------- Run orientation sweep --------------------
avg_u_right = zeros(nangle,1);
max_umag    = zeros(nangle,1);
freq_first  = zeros(nangle,1);
cond_est    = zeros(nangle,1);

for ia = 1:nangle
    theta_deg = angle_list(ia);
    fprintf('\n--- Solving orientation theta = %d° ---\n', theta_deg);

    % Build rotated AAT tensor
    AAT_rot = build_rotated_AAT(lx, ly, lz, theta_deg);

    [avg_u_right(ia), max_umag(ia), freq_first(ia), cond_est(ia)] = ...
        solve_3d_sg_rotated(Lx,Ly,Lz,E,nu,rho,nelx,nely,nelz, ...
                            AAT_rot, traction_right, body_force, bc_case);
end

% Isotropic reference case
fprintf('\n--- Solving isotropic reference (l_iso = %.5f) ---\n', l_iso);
AAT_iso = diag([l_iso^2, l_iso^2, l_iso^2]);
[avg_u_iso, ~, freq_iso, ~] = ...
    solve_3d_sg_rotated(Lx,Ly,Lz,E,nu,rho,nelx,nely,nelz, ...
                        AAT_iso, traction_right, body_force, bc_case);

% Derived quantities
u0      = avg_u_right(1);                          % reference (theta=0)
ratio   = avg_u_right / u0;                        % u(theta)/u(0°)
k_rel   = (avg_u_iso ./ avg_u_right - 1) * 100;   % relative stiffness increase (%)

%% -------------------- Print table --------------------
fprintf('\n===== 3D Orientation study =====\n');
fprintf('Ellipsoid: lx=%.4f, ly=%.4f, lz=%.4f, rotation about z\n', lx, ly, lz);
fprintf('Isotropic ref: l_iso=%.6f m\n', l_iso);
fprintf('Mesh = %d x %d x %d\n\n', nelx, nely, nelz);
fprintf('%6s %12s %12s %12s %12s %12s %12s\n', ...
    'theta', 'u_avg(um)', 'u/u0', 'k_rel(%)', 'f1(Hz)', 'f1/f_iso', 'condest');
fprintf('%6s %12s %12s %12s %12s %12s %12s\n', ...
    '-----', '--------', '----', '-------', '------', '-------', '-------');
for ia = 1:nangle
    fprintf('%5d° %12.4f %12.5f %12.3f %12.1f %12.5f %12.3e\n', ...
        angle_list(ia), avg_u_right(ia)*1e6, ratio(ia), k_rel(ia), ...
        freq_first(ia), freq_first(ia)/freq_iso, cond_est(ia));
end
fprintf('%5s %12.4f %12.5f %12.3f %12.1f %12.5f %12s\n', ...
    'iso', avg_u_iso*1e6, avg_u_iso/u0, 0.0, freq_iso, 1.0, '-');


%% ========================================================================
%%  PUBLICATION-QUALITY FIGURE — 5-panel orientation study
%% ========================================================================
%%  PUBLICATION-QUALITY FIGURE — 4-panel orientation study (2x2)
%%    (a) Rotating ellipsoid schematic (0, 45, 90 deg)
%%    (b) Normalized displacement ratio  u(theta)/u(0)
%%    (c) Normalized frequency ratio     f1/f_iso
%%    (d) Estimated condition number     kappa
%% ========================================================================

close all;   % <-- सभी पुरानी figures बंद कर देगा

C_blue   = [0.000, 0.447, 0.698];
C_green  = [0.466, 0.674, 0.188];
C_red    = [0.639, 0.078, 0.184];
C_gray   = [0.500, 0.500, 0.500];

LW     = 1.5;
LW_ref = 0.8;
MS     = 6;

fig = figure('Color','white', 'Units','centimeters', ...
             'Position',[2, 2, 17.6, 15.0]);

% --- Panel (a) — Rotating ellipsoid schematic ---
ax_a = subplot(2, 2, 1);
hold(ax_a, 'on');
schematic_angles = [0, 45, 90];
ellipsoid_colors = [C_blue; C_green; C_red];
for ka = 1:3
    AAT_ell = build_rotated_AAT(lx, ly, lz, schematic_angles(ka));
    [Xe, Ye, Ze] = ellipsoid_surface(AAT_ell, 30);
    surf(ax_a, Xe, Ye, Ze, 'FaceColor', ellipsoid_colors(ka,:), ...
         'FaceAlpha', 0.20, 'EdgeColor', ellipsoid_colors(ka,:), ...
         'EdgeAlpha', 0.75, 'LineWidth', 1.0);
end
set3Dstyle(ax_a);
axis(ax_a, 'equal');
view(ax_a, 35, 25);
legend(ax_a, {'\theta = 0^\circ', '\theta = 45^\circ', '\theta = 90^\circ'}, ...
       'Location', 'east', 'FontName', 'Times New Roman', ...
       'FontSize', 9, 'Interpreter', 'tex', 'Box', 'off');
text(ax_a, 0.05, 0.93, '(a)', 'Units','normalized', ...
     'FontName','Times New Roman','FontSize',11, ...
     'FontWeight','bold','Interpreter','none');

% --- Panel (b) — Normalized displacement ratio ---
ax_b = subplot(2, 2, 2);
plot(ax_b, angle_list, ratio, ...
    'Color', C_blue, 'LineStyle', '-', 'LineWidth', LW, ...
    'Marker', 'o', 'MarkerSize', MS, 'MarkerFaceColor', 'white');
styleAxes(ax_b);
xlabel(ax_b, 'Orientation angle \theta (degrees)', ...
    'Interpreter','tex','FontName','Times New Roman','FontSize',11);
ylabel(ax_b, 'u(\theta)/u(0^\circ)', ...
    'Interpreter','tex','FontName','Times New Roman','FontSize',11);
xlim(ax_b, [0, 90]);
r_span = max(ratio) - min(ratio);
ylim(ax_b, [1.0 - 0.15*r_span, max(ratio) + 0.10*r_span]);
text(ax_b, 0.14, 0.93, '(b)', 'Units','normalized', ...
     'FontName','Times New Roman','FontSize',11, ...
     'FontWeight','bold','Interpreter','none');

% --- Panel (c) — Normalized frequency ratio ---
ax_c = subplot(2, 2, 3);
hold(ax_c, 'on');
yline(ax_c, 1.0, 'Color', C_gray, 'LineStyle', ':', 'LineWidth', LW_ref);
plot(ax_c, angle_list, freq_first/freq_iso, ...
    'Color', C_green, 'LineStyle', '-', 'LineWidth', LW, ...
    'Marker', 'd', 'MarkerSize', MS, 'MarkerFaceColor', 'white');
styleAxes(ax_c);
xlabel(ax_c, 'Orientation angle \theta (degrees)', ...
    'Interpreter','tex','FontName','Times New Roman','FontSize',11);
ylabel(ax_c, 'f_1 / f_{iso}', ...
    'Interpreter','tex','FontName','Times New Roman','FontSize',11);
xlim(ax_c, [0, 90]);
f_span = max(freq_first/freq_iso) - min(freq_first/freq_iso);
ylim(ax_c, [min(freq_first/freq_iso) - 0.15*f_span, ...
            max(freq_first/freq_iso) + 0.10*f_span]);
text(ax_c, 0.14, 0.93, '(c)', 'Units','normalized', ...
     'FontName','Times New Roman','FontSize',11, ...
     'FontWeight','bold','Interpreter','none');

% --- Panel (d) — Estimated condition number ---
ax_d = subplot(2, 2, 4);
plot(ax_d, angle_list, cond_est, ...
    'Color', C_red, 'LineStyle', '-', 'LineWidth', LW, ...
    'Marker', '^', 'MarkerSize', MS, 'MarkerFaceColor', 'white');
styleAxes(ax_d);
xlabel(ax_d, 'Orientation angle \theta (degrees)', ...
    'Interpreter','tex','FontName','Times New Roman','FontSize',11);
ylabel(ax_d, 'Estimated condition number \kappa', ...
    'Interpreter','tex','FontName','Times New Roman','FontSize',11);
xlim(ax_d, [0, 90]);
kappa_span = max(cond_est) - min(cond_est);
ylim(ax_d, [min(cond_est) - 0.10*kappa_span, max(cond_est) + 0.10*kappa_span]);
text(ax_d, 0.14, 0.93, '(d)', 'Units','normalized', ...
     'FontName','Times New Roman','FontSize',11, ...
     'FontWeight','bold','Interpreter','none');
%% ========================================================================
%%  UTILITY FUNCTIONS
%% ========================================================================

function styleAxes(ax)
set(ax, ...
    'FontName',             'Times New Roman', ...
    'FontSize',             10, ...
    'LineWidth',            0.8, ...
    'Box',                  'on', ...
    'TickDir',              'in', ...
    'TickLength',           [0.015, 0.015], ...
    'XMinorTick',           'off', ...
    'YMinorTick',           'off', ...
    'GridLineStyle',        ':', ...
    'GridAlpha',            0.35, ...
    'MinorGridLineStyle',   'none', ...
    'TickLabelInterpreter', 'tex');
grid(ax, 'on');
end

function set3Dstyle(ax)
% set3Dstyle — 3D axes style matching the manuscript package.
set(ax, 'FontSize',             9, ...
        'FontName',             'Times New Roman', ...
        'LineWidth',            0.8, ...
        'Box',                  'on', ...
        'TickDir',              'in', ...
        'TickLength',           [0.012 0.012], ...
        'GridLineStyle',        ':', ...
        'GridAlpha',            0.35, ...
        'XMinorTick',           'off', ...
        'YMinorTick',           'off', ...
        'TickLabelInterpreter', 'tex');
grid(ax, 'on');
xlabel(ax, 'x (m)', 'Interpreter','tex', ...
       'FontName','Times New Roman','FontSize',9);
ylabel(ax, 'y (m)', 'Interpreter','tex', ...
       'FontName','Times New Roman','FontSize',9);
zlabel(ax, 'z (m)', 'Interpreter','tex', ...
       'FontName','Times New Roman','FontSize',9);
end

function AAT_rot = build_rotated_AAT(lx, ly, lz, theta_deg)
% Build the rotated ellipsoidal characteristic-length tensor.
%   AAT_rot = R^T * diag(lx^2, ly^2, lz^2) * R
%   R is the rotation matrix about the z-axis.
    theta = theta_deg * pi / 180;
    c = cos(theta);  s = sin(theta);
    R = [ c, -s, 0;
          s,  c, 0;
          0,  0, 1];
    D = diag([lx^2, ly^2, lz^2]);
    AAT_rot = R' * D * R;
end

function [X, Y, Z] = ellipsoid_surface(AAT, n)
% Generate ellipsoid surface points from a 3x3 AAT tensor.
%   The ellipsoid satisfies x^T AAT^{-1} x = 1.
    [V, D] = eig(AAT);
    semi_axes = sqrt(diag(D));   % semi-axis lengths = sqrt(eigenvalues)
    % Parametric sphere, then scale and rotate
    [u, v] = meshgrid(linspace(0, 2*pi, n), linspace(0, pi, n));
    sx = semi_axes(1) * cos(u) .* sin(v);
    sy = semi_axes(2) * sin(u) .* sin(v);
    sz = semi_axes(3) * cos(v);
    % Apply rotation V
    X = V(1,1)*sx + V(1,2)*sy + V(1,3)*sz;
    Y = V(2,1)*sx + V(2,2)*sy + V(2,3)*sz;
    Z = V(3,1)*sx + V(3,2)*sy + V(3,3)*sz;
end


%% ========================================================================
%%  FEM SOLVER — generalized for rotated AAT tensor
%%  Modifications vs original anisotropic solver:
%%    (1) Gradient stiffness uses full AAT_rot (cross-derivative terms)
%%    (2) Consistent mass matrix assembled for eigenvalue analysis
%%    (3) First natural frequency computed via generalized eigenproblem
%%  Hermite interpolation, Gauss integration, BCs, scaling: UNCHANGED.
%% ========================================================================

function [avg_ux_right, max_umag, freq_first, cond_est] = ...
    solve_3d_sg_rotated(Lx,Ly,Lz,E,nu,rho,nelx,nely,nelz, ...
                        AAT_rot, traction_right, body_force, bc_case)

    lambda = E*nu/((1+nu)*(1-2*nu));
    mu     = E/(2*(1+nu));
    C = [lambda+2*mu, lambda,      lambda,      0,  0,  0;
         lambda,      lambda+2*mu, lambda,      0,  0,  0;
         lambda,      lambda,      lambda+2*mu, 0,  0,  0;
         0,           0,           0,           mu, 0,  0;
         0,           0,           0,           0,  mu, 0;
         0,           0,           0,           0,  0,  mu];

    nnx = nelx + 1;  nny = nely + 1;  nnz = nelz + 1;
    nnode = nnx*nny*nnz;
    ndof_per_node = 24;
    ndof = ndof_per_node*nnode;

    xgrid = linspace(0,Lx,nnx);
    ygrid = linspace(0,Ly,nny);
    zgrid = linspace(0,Lz,nnz);
    node_id = @(ix,iy,iz) (iz-1)*nnx*nny + (iy-1)*nnx + ix;

    coords = zeros(nnode,3);
    for iz = 1:nnz
        for iy = 1:nny
            for ix = 1:nnx
                n = node_id(ix,iy,iz);
                coords(n,:) = [xgrid(ix), ygrid(iy), zgrid(iz)];
            end
        end
    end

    conn = zeros(nelx*nely*nelz,8);
    e = 0;
    for ez = 1:nelz
        for ey = 1:nely
            for ex = 1:nelx
                e = e + 1;
                conn(e,:) = [node_id(ex,ey,ez),     node_id(ex+1,ey,ez), ...
                             node_id(ex+1,ey+1,ez), node_id(ex,ey+1,ez), ...
                             node_id(ex,ey,ez+1),   node_id(ex+1,ey,ez+1), ...
                             node_id(ex+1,ey+1,ez+1), node_id(ex,ey+1,ez+1)];
            end
        end
    end

    nel = size(conn,1);
    K = sparse(ndof,ndof);
    M = sparse(ndof,ndof);        % NEW: consistent mass matrix
    F = zeros(ndof,1);

    [gp, gw] = gauss_1d_01(3);

    % AAT_rot components (symmetric)
    m11 = AAT_rot(1,1);  m22 = AAT_rot(2,2);  m33 = AAT_rot(3,3);
    m12 = AAT_rot(1,2);  m13 = AAT_rot(1,3);  m23 = AAT_rot(2,3);

    for e = 1:nel
        nodes = conn(e,:);
        xy = coords(nodes,:);
        hx = xy(2,1)-xy(1,1);
        hy = xy(4,2)-xy(1,2);
        hz = xy(5,3)-xy(1,3);
        if hx <= 0 || hy <= 0 || hz <= 0
            error('Invalid element geometry at element %d.', e);
        end
        detJ = hx*hy*hz;
        Ke = zeros(192,192);
        Me = zeros(192,192);       % NEW
        Fe = zeros(192,1);
        for ig = 1:length(gp)
            s = gp(ig); ws = gw(ig);
            for jg = 1:length(gp)
                t = gp(jg); wt = gw(jg);
                for kg = 1:length(gp)
                    r = gp(kg); wr = gw(kg);
                    wgt = ws*wt*wr*detJ;

                    [N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz] = hermite_shape_3d(s,t,r,hx,hy,hz);
                    [B,Bx,By,Bz,Nv] = make_B_matrices_3d(N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz);

                    % Classical stiffness
                    Kcl = B.'*C*B;

                    % ---- ROTATED gradient stiffness ----
                    % Kg = (1/10) * sum_ij AAT(i,j) * Bi' C Bj
                    % Expanded for symmetric AAT_rot:
                    Kg = (1/10) * ( ...
                        m11*(Bx.'*C*Bx) + m22*(By.'*C*By) + m33*(Bz.'*C*Bz) ...
                      + m12*(Bx.'*C*By + By.'*C*Bx) ...
                      + m13*(Bx.'*C*Bz + Bz.'*C*Bx) ...
                      + m23*(By.'*C*Bz + Bz.'*C*By) );

                    Ke = Ke + (Kcl + Kg) * wgt;

                    % Consistent mass matrix
                    Me = Me + rho * (Nv.'*Nv) * wgt;

                    Fe = Fe + Nv.'*body_force*wgt;
                end
            end
        end
        edofs = element_dofs(nodes,ndof_per_node);
        K(edofs,edofs) = K(edofs,edofs) + Ke;
        M(edofs,edofs) = M(edofs,edofs) + Me;
        F(edofs) = F(edofs) + Fe;
    end

    % Right-face traction x=Lx (UNCHANGED)
    for ez = 1:nelz
        for ey = 1:nely
            e_right = (ez-1)*nelx*nely + (ey-1)*nelx + nelx;
            nodes = conn(e_right,:);
            xy = coords(nodes,:);
            hx = xy(2,1)-xy(1,1);
            hy = xy(4,2)-xy(1,2);
            hz = xy(5,3)-xy(1,3);
            edofs = element_dofs(nodes,ndof_per_node);
            Fe = zeros(192,1);
            s = 1.0;
            for jg = 1:length(gp)
                t = gp(jg); wt = gw(jg);
                for kg = 1:length(gp)
                    r = gp(kg); wr = gw(kg);
                    faceJ = hy*hz;
                    [N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz] = hermite_shape_3d(s,t,r,hx,hy,hz); %#ok<ASGLU>
                    [~,~,~,~,Nv] = make_B_matrices_3d(N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz);
                    Fe = Fe + Nv.'*traction_right*(wt*wr*faceJ);
                end
            end
            F(edofs) = F(edofs) + Fe;
        end
    end

    % Essential BCs (UNCHANGED)
    fixed_dofs = [];
    left_nodes = [];
    for iz = 1:nnz
        for iy = 1:nny
            left_nodes(end+1) = node_id(1,iy,iz); %#ok<AGROW>
        end
    end
    switch bc_case
        case "clamped_gradient"
            for n = left_nodes
                fixed_dofs = [fixed_dofs, (n-1)*24 + (1:24)]; %#ok<AGROW>
            end
        case "classical_clamp"
            for n = left_nodes
                fixed_dofs = [fixed_dofs, (n-1)*24 + [1,9,17]]; %#ok<AGROW>
            end
        otherwise
            error('Unknown bc_case.');
    end
    fixed_dofs = unique(fixed_dofs);
    free_dofs = setdiff(1:ndof, fixed_dofs);

    % Scaled linear solve (UNCHANGED strategy)
    Kff = K(free_dofs,free_dofs);
    Ff  = F(free_dofs);
    Mff = M(free_dofs,free_dofs);

    scale_diag = sqrt(abs(diag(Kff)));
    scale_diag(scale_diag < eps) = 1.0;
    Sscale = spdiags(1./scale_diag, 0, length(free_dofs), length(free_dofs));

    Kscaled = Sscale*Kff*Sscale;
    Fscaled = Sscale*Ff;
    Mscaled = Sscale*Mff*Sscale;

    cond_est = condest(Kscaled);
    if ~isfinite(cond_est) || cond_est > 1.0e14
        reg = 1.0e-10*mean(abs(diag(Kscaled)));
        if reg == 0 || ~isfinite(reg), reg = 1.0e-10; end
        Kscaled = Kscaled + reg*speye(size(Kscaled));
    end

    % Static solve
    y = Kscaled \ Fscaled;
    D = zeros(ndof,1);
    D(free_dofs) = Sscale * y;
    R = K*D - F;

    % Post-processing (UNCHANGED)
    u_nodes = D(1:24:end);
    v_nodes = D(9:24:end);
    w_nodes = D(17:24:end);
    umag = sqrt(u_nodes.^2 + v_nodes.^2 + w_nodes.^2);

    right_nodes = [];
    for iz = 1:nnz
        for iy = 1:nny
            right_nodes(end+1) = node_id(nnx,iy,iz); %#ok<AGROW>
        end
    end
    avg_ux_right = mean(u_nodes(right_nodes));
    max_umag = max(umag);

    % ---- Eigenvalue analysis: first natural frequency ----
    % Regularize derivative-DOF mass entries (Hermite derivative DOFs
    % have zero consistent mass; add small inertia for definiteness).
    Mff_reg = Mff;
    for i = 1:length(free_dofs)
        pos = mod(free_dofs(i)-1, 24);       % 0-based position in 24-DOF block
        if ~ismember(pos, [0, 8, 16])        % derivative DOF
            Mff_reg(i,i) = Mff_reg(i,i) + 1e-8*abs(Kff(i,i));
        end
    end
    Mscaled_reg = Sscale * Mff_reg * Sscale;

    try
        [~, omega2] = eigs(Kscaled, Mscaled_reg, 1, 'smallestabs');
        freq_first = sqrt(real(omega2(1))) / (2*pi);
    catch
        freq_first = 0;
    end
end


%% ========================================================================
%%  ELEMENT FORMULATION (UNCHANGED)
%% ========================================================================

function edofs = element_dofs(nodes,ndof_per_node)
    edofs = zeros(1,numel(nodes)*ndof_per_node);
    c = 0;
    for a = 1:numel(nodes)
        n = nodes(a);
        edofs(c+1:c+ndof_per_node) = (n-1)*ndof_per_node + (1:ndof_per_node);
        c = c + ndof_per_node;
    end
end

function [gp,gw] = gauss_1d_01(n)
    switch n
        case 3
            x = [-sqrt(3/5), 0, sqrt(3/5)];
            w = [5/9, 8/9, 5/9];
        otherwise
            error('Only n=3 implemented here.');
    end
    gp = (x+1)/2;
    gw = w/2;
end

function [H0,H1,H0x,H1x,H0xx,H1xx] = hermite_1d_two_nodes(s,L)
    h1 = 1 - 3*s^2 + 2*s^3;
    h2 = L*(s - 2*s^2 + s^3);
    h3 = 3*s^2 - 2*s^3;
    h4 = L*(-s^2 + s^3);
    dh1 = -6*s + 6*s^2;
    dh2 = L*(1 - 4*s + 3*s^2);
    dh3 = 6*s - 6*s^2;
    dh4 = L*(-2*s + 3*s^2);
    d2h1 = -6 + 12*s;
    d2h2 = L*(-4 + 6*s);
    d2h3 = 6 - 12*s;
    d2h4 = L*(-2 + 6*s);
    H0 = [h1, h3]; H1 = [h2, h4];
    H0x = (1/L)*[dh1, dh3]; H1x = (1/L)*[dh2, dh4];
    H0xx = (1/L^2)*[d2h1, d2h3]; H1xx = (1/L^2)*[d2h2, d2h4];
end

function [N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz] = hermite_shape_3d(s,t,r,hx,hy,hz)
    [Hx0,Hx1,Hx0x,Hx1x,Hx0xx,Hx1xx] = hermite_1d_two_nodes(s,hx);
    [Hy0,Hy1,Hy0y,Hy1y,Hy0yy,Hy1yy] = hermite_1d_two_nodes(t,hy);
    [Hz0,Hz1,Hz0z,Hz1z,Hz0zz,Hz1zz] = hermite_1d_two_nodes(r,hz);
    xs = [1 2 2 1 1 2 2 1];
    ys = [1 1 2 2 1 1 2 2];
    zs = [1 1 1 1 2 2 2 2];
    N=zeros(1,64); Nx=N; Ny=N; Nz=N; Nxx=N; Nyy=N; Nzz=N; Nxy=N; Nxz=N; Nyz=N;
    combos = [0 0 0; 1 0 0; 0 1 0; 0 0 1; 1 1 0; 1 0 1; 0 1 1; 1 1 1];
    for a = 1:8
        ix=xs(a); iy=ys(a); iz=zs(a); p=(a-1)*8;
        for q=1:8
            cx=combos(q,1); cy=combos(q,2); cz=combos(q,3);
            [X,Xx,Xxx] = pickH(cx,ix,Hx0,Hx1,Hx0x,Hx1x,Hx0xx,Hx1xx);
            [Y,Yy,Yyy] = pickH(cy,iy,Hy0,Hy1,Hy0y,Hy1y,Hy0yy,Hy1yy);
            [Z,Zz,Zzz] = pickH(cz,iz,Hz0,Hz1,Hz0z,Hz1z,Hz0zz,Hz1zz);
            id=p+q;
            N(id)=X*Y*Z; Nx(id)=Xx*Y*Z; Ny(id)=X*Yy*Z; Nz(id)=X*Y*Zz;
            Nxx(id)=Xxx*Y*Z; Nyy(id)=X*Yyy*Z; Nzz(id)=X*Y*Zzz;
            Nxy(id)=Xx*Yy*Z; Nxz(id)=Xx*Y*Zz; Nyz(id)=X*Yy*Zz;
        end
    end
end

function [H,Hd,Hdd] = pickH(flag,idx,H0,H1,H0d,H1d,H0dd,H1dd)
    if flag == 0
        H=H0(idx); Hd=H0d(idx); Hdd=H0dd(idx);
    else
        H=H1(idx); Hd=H1d(idx); Hdd=H1dd(idx);
    end
end

function [B,Bx,By,Bz,Nv] = make_B_matrices_3d(N,Nx,Ny,Nz,Nxx,Nyy,Nzz,Nxy,Nxz,Nyz)
    B=zeros(6,192); Bx=B; By=B; Bz=B; Nv=zeros(3,192);
    for a=1:8
        sp=(a-1)*8+(1:8); up=(a-1)*24+(1:8); vp=(a-1)*24+(9:16); wp=(a-1)*24+(17:24);
        Nv(1,up)=N(sp); Nv(2,vp)=N(sp); Nv(3,wp)=N(sp);
        B(1,up)=Nx(sp); B(2,vp)=Ny(sp); B(3,wp)=Nz(sp);
        B(4,vp)=Nz(sp); B(4,wp)=Ny(sp); B(5,up)=Nz(sp); B(5,wp)=Nx(sp); B(6,up)=Ny(sp); B(6,vp)=Nx(sp);
        Bx(1,up)=Nxx(sp); Bx(2,vp)=Nxy(sp); Bx(3,wp)=Nxz(sp);
        Bx(4,vp)=Nxz(sp); Bx(4,wp)=Nxy(sp); Bx(5,up)=Nxz(sp); Bx(5,wp)=Nxx(sp); Bx(6,up)=Nxy(sp); Bx(6,vp)=Nxx(sp);
        By(1,up)=Nxy(sp); By(2,vp)=Nyy(sp); By(3,wp)=Nyz(sp);
        By(4,vp)=Nyz(sp); By(4,wp)=Nyy(sp); By(5,up)=Nyz(sp); By(5,wp)=Nxy(sp); By(6,up)=Nyy(sp); By(6,vp)=Nxy(sp);
        Bz(1,up)=Nxz(sp); Bz(2,vp)=Nyz(sp); Bz(3,wp)=Nzz(sp);
        Bz(4,vp)=Nzz(sp); Bz(4,wp)=Nyz(sp); Bz(5,up)=Nzz(sp); Bz(5,wp)=Nxz(sp); Bz(6,up)=Nyz(sp); Bz(6,vp)=Nxz(sp);
    end
end
