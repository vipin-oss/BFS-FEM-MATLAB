# CHANGELOG — FEM4 final package

## 2026-09-05 — Final submission-readiness patch (Task 5)

Scope: exactly two vulnerabilities closed; no other content touched.

### 1. Figure-5 λ-sweep robustness (mesh refinement of the figure-of-merit study)

**What was done.** The entire ten-point μ₀ sweep of `studies/lambda_study.m`
(logspace 2.51e-8 → 2.51e-6 C/m, i.e. Λ = 0.419 → 4.19e-3; 16×2 production
mesh) was **recomputed from scratch** on refined 32×4 and 60×12 meshes with a
new script `studies/lambda_study_refined.m` — identical grid, material
constants, BCs, tip load, DOF-scaling path and observable (max|φ|). To make
the 60×12 sweep tractable, `fem/solve_system.m` gained an opt-in
`opts.no_cond` flag (default `false`, behaviour unchanged) that skips the
diagnostic-only `cond_number1` estimates; condest on the raw ~1e30-conditioned
60×12 system is prohibitively slow/OOM in Octave and does not affect the
solution vector. Regression check: the default path reproduces the shipped
16×2 CSV to ~10 significant digits (peak 2.9404e-10 V at Λ = 1.1650e-2);
the shipped `output/lambda_study.csv` / `.mat` and the frozen
`data/lambda_study.csv` are restored byte-identical to the previous package.

**Results (output/lambda_study_refined.csv, all recomputed, none invented).**

| mesh | sampled peak max\|φ\| | at Λ |
|---|---|---|
| 16×2 (baseline) | 2.9404e-10 V | 1.165e-2 |
| 32×4 | 3.0138e-10 V | 1.943e-2 |
| 60×12 | 2.4569e-10 V | 3.242e-2 (flat: adjacent sample within 0.2%) |

- The **rise–maximum–fall (self-stiffening) shape is robust**: single interior
  maximum on every mesh; no refinement turns the response monotone.
- **Quantitative values carry the through-thickness resolution caveat**
  (already flagged in §4.8/§5.1): peak moves from Λ≈1.17e-2 to Λ≈3.24e-2;
  at Λ=0.419 the refined potential is 2.5× the baseline value, at
  Λ=4.19e-3 it is 0.45× of it (baseline curve steeper on both flanks).
- **Internal consistency cross-check**: at μ₀ = 1.0e-6 C/m the refined 60×12
  sweep gives max|φ| = 1.900907e-10 V, reproducing the §5.1 field-export
  value 1.90e-10 V exactly (to the stated precision).

**Manuscript updates.** Figure 5 (Fig04_lambda_R3) regenerated as a three-mesh
figure (60×12 refined curve primary, 32×4 and 16×2 baseline for comparison;
generator: `paper_figures/gen_lambda_refined_figure.py`, PAPER_V9 style,
data `data/lambda_study.csv` + `data/lambda_study_refined.csv`).
§5.2: new refinement paragraph; caption, Table 5 row, conclusions and
limitations updated with the refined numbers; every previously quoted
sweep value is now explicitly scoped to its mesh.
*Corrected in passing (pre-existing error made visible by the multi-curve
update): the panel-(b) description said the normalized ratio "rises as Λ
decreases and then flattens" — the data (all three meshes) show it nearly
constant at large Λ and **falling** as Λ decreases; the paragraph now states
the correct direction (same mechanism, corrected wording).*

### 2. h_crit provenance (abstract / conclusions)

The body (§4 fit, §5.6, Tables 5/7) already stated that A = 24.2011,
p = 0.8998, R² = 0.99984 are a log–log least-squares fit to **four
source-reported** critical-thickness roots inherited from the companion
full-resolution campaign. The abstract and the conclusions now make the same
provenance explicit ("obtained by an empirical power-law fit to four
source-reported critical-thickness roots" / "fitted to four source-reported
roots"). The result itself is unchanged and not weakened.

### Build verification (after patch)

41 pages, 0 errors, 0 overfull boxes, 0 undefined references/citations;
equations still (1)–(70), 10 figures, 7 tables, 63 references; Figure 5
caption p26 / first reference p25; all figures within 0–1 page of first
mention (Fig 6/8/9 captions shifted +1 page from the longer Figure-5 caption
block — placement rules unchanged); new three-mesh figure confirmed embedded
in the compiled PDF (pixel-level colour check).

### Files added / changed in this patch

- `manuscript/main_final.tex` — §5.2 + caption + Table 5 + abstract +
  conclusions + limitations edits (8 edits, all assertion-verified)
- `manuscript/main_final.pdf` / `.bbl` — recompiled
- `manuscript/Fig04_lambda_R3.eps` + `-eps-converted-to.pdf` — regenerated
  (three-mesh figure, same 515.52×219.6 pt canvas)
- `program/MATLAB_COMPLETE_PROGRAM/fem/solve_system.m` — opt-in
  `opts.no_cond` (default false; default path regression-verified unchanged)
- `program/MATLAB_COMPLETE_PROGRAM/studies/lambda_study_refined.m` — NEW
- `program/MATLAB_COMPLETE_PROGRAM/output/lambda_study_refined.csv` + `.mat` — NEW
- `program/paper_figures/gen_lambda_refined_figure.py` — NEW (Figure-5 generator)
- `program/paper_figures/PAPER_V9_FIGURES/data/lambda_study_refined.csv` — NEW
- `program/paper_figures/PAPER_V9_FIGURES/plot_paper_fig04.m` — header note
  (shipped figure source; kept as 16×2 reference implementation)
- `CHANGELOG.md` — this file

**No known fatal or major scientific blocker remains after this patch.**
