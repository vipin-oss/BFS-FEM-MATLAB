# FEM4 — Final Package

**Coupled piezoelectric–flexoelectric beam/plate analysis with a 36-DOF conforming C¹
Bogner–Fox–Schmit (BFS) finite element (Mindlin Form-II strain-gradient elasticity).**

This package contains everything needed to (a) compile the final manuscript
(single-column journal layout) and (b) run the complete MATLAB program that
produced every number in it.

Packaged: 2026-09-05.

---

## Contents

```
FEM4_final_package/
├── README.md                        ← this file
├── CHANGELOG.md                     ← patch history (final submission-readiness patch)
├── manuscript/                      ← final manuscript (LaTeX, single-column)
│   ├── main_final.tex               ← manuscript source (article, 11pt, A4)
│   ├── main_final.pdf               ← compiled output — 41 pages, ready to read/submit
│   ├── main_final.bbl               ← pre-built bibliography (compile without bibtex)
│   ├── MANUSCRIPT_REFERENCES.bib    ← 63 references, all cited in the text
│   ├── FINAL_COMPLETE_MASTER_CALCULATION.tex
│   │                                ← frozen closed-form master calculation
│   │                                  (the mathematical authority for paper AND program)
│   └── Fig01…Fig10 (.eps + cropped .pdf)
│                                    ← exactly the 10 figures included by main_final.tex
└── program/                         ← the complete working program
    ├── MATLAB_COMPLETE_PROGRAM/     ← full solver + verification suite (89 .m files)
    │                                  entry points: main, run_full_scientific_regression
    │                                  results CSVs in output/ (paper's data source)
    ├── 0_START_HERE_RUN_GUIDE.md    ← how to run (see note below about its PART A)
    └── paper_figures/               ← figure-generation code
        ├── PAPER_V9_FIGURES/        ← MATLAB scripts for paper figures 1–9 (+ frozen data)
        ├── gen_fixed_figures.py     ← Python/matplotlib: regenerated Fig 3 & Fig 8 (rev. R3)
        ├── gen_meshconv_figure.py   ← Python/matplotlib: mesh-convergence figure
        └── gen_lambda_refined_figure.py
                                     ← Python/matplotlib: SHIPPED Figure 5 (three-mesh
                                       λ sweep: 16×2 baseline + 32×4/60×12 refined)
```

---

## 1. Manuscript layout

The manuscript follows the author's single-column journal layout (the PAPER5
template): `\documentclass[11pt,a4paper]{article}` + `geometry` 2.3 cm margins +
`\linespread{1.2}`, bold `\LARGE` title, standard `abstract` environment, bold
"Keywords:" label, default (normalsize) captions, globally numbered equations,
author-year citations in square brackets (natbib `plainnat`, unnumbered
reference list with printed DOIs), figures at full text width with top-of-page
float placement, page numbers bottom-center.

## 2. Compiling the manuscript

```bash
cd manuscript
pdflatex main_final      # pass 1
bibtex main_final        # OPTIONAL — main_final.bbl is already included
pdflatex main_final      # pass 2
pdflatex main_final      # pass 3 (cross-references settle)
```

Verified result: **41 pages, 0 errors, 0 overfull boxes, 0 undefined
references/citations.** All 10 figures land within 0–1 page of their first
mention; no blank or half-empty pages in the body.

Requirements (standard TeX Live / Overleaf — nothing exotic):
- `geometry`, `natbib` + `plainnat` (texlive-latex-recommended/base)
- `siunitx` (texlive-science)
- Ghostscript only if EPS→PDF conversion is ever re-triggered; the
  pre-converted `Fig*-eps-converted-to.pdf` files are shipped (cropped to the
  EPS bounding boxes), so normally it is not.

On **Overleaf**: upload the whole `manuscript/` folder and set the compiler to
pdfLaTeX — it compiles as-is.

Notes:
- All equation/figure/table numbering is automatic (`\label`/`\ref`); there are
  no hard-coded numbers.
- `FINAL_COMPLETE_MASTER_CALCULATION.tex` is a reference document (the
  closed-form derivations). It is *not* part of the manuscript build.

## 3. Running the program

Written for MATLAB (any recent release); verified to run with **zero errors in
GNU Octave 9.4** as well. From `program/`:

```matlab
cd MATLAB_COMPLETE_PROGRAM
main                            % master pipeline — all verification checks print PASS
run_full_scientific_regression  % 20/20 regression checks PASS
```

Single studies (each writes its own CSV into `output/`):

```matlab
studies/lambda_study             % Λ sweep          → lambda_study.csv
studies/hcrit_study              % critical-thickness roots → hcrit_study.csv
studies/aspect_ratio_study       % L/h sweep        → aspect_ratio_study.csv
studies/convergence_study        % Tier-1 benchmark → convergence_study.csv
studies/boundary_condition_study % BC sensitivity   → boundary_condition_study.csv
```

The `output/` folder already contains the computed CSVs that the manuscript's
numbers trace to.

**Note on `0_START_HERE_RUN_GUIDE.md`:** its PART A describes an earlier
20-figure working suite (`FIGURES_REFINED`) that is *not* part of this final
package (superseded by the paper figures). PART B (running the solver) is fully
applicable. The paper-figure scripts live in `paper_figures/`:
`PAPER_V9_FIGURES/plot_paper_fig01.m … plot_paper_fig09.m` (MATLAB, data frozen
in `PAPER_V9_FIGURES/data/`), plus the two Python scripts that produced the final
revised figures (Fig 3/Fig 8 `_R3` and the mesh-convergence figure). The Python
scripts contain absolute output paths from the build machine — edit the
`savefig(...)` paths before running them.

## 4. Key verified results (all traceable to `program/MATLAB_COMPLETE_PROGRAM/output/`)

| Quantity | Value |
|---|---|
| Tier-1 benchmark rates (from quoted norms) | r_L2 = 3.9998, r_H1 = 2.9963, r_G = 1.9995 |
| Free-edge point value (12×4→24×8→48×16) | successive-difference rate p = 1.82, u\* = 1.6988×10⁻⁹ m |
| Euler–Bernoulli reference (Ẽ = E/(1−ν²) = 109.89 GPa) | FL³/(3ẼI) = 2.912×10⁻¹⁶ m |
| Converged full-clamp tip deflection (60×12) | 2.80×10⁻¹⁶ m (−3.8 % vs EB; 16×2 carries ~4 % discretization offset) |
| Actuator benchmark | ML²/(2ẼI) = 109.2 nm vs FEM 91.15 nm (−16.5 %) |
| h_crit roots (µm) | 6.9353, 12.9840, 18.8471, 24.0201 |
| Conditioning (raw / DOF-scaled) | 4.71×10²⁹→4.57×10³⁴ / 7.64×10⁶→1.03×10¹¹ |
| Peak potential (dual-mesh disclosure) | 2.96×10⁻¹⁰ V (16×2) vs 1.90×10⁻¹⁰ V (60×12 export) |

## 5. Changelog of the packaging passes

1. **Content fixes (first pass).** Last leftover of the old biased two-interval
   Richardson estimate (`2.18`) in §4.1 replaced by the successive-difference
   rate `1.82`; `studies/convergence_study.m` estimator actually corrected in
   code to `r = ln(d1/d2)/ln 2` (reproduces p = 1.8242, u\* = 1.698780×10⁻⁹ m
   from the shipped CSV tips).
2. **Re-template (this pass).** Manuscript moved from Elsevier `elsarticle`
   two-column to the single-column PAPER5 layout described in §1. Scientific
   content untouched.
3. **Figure-canvas fix (critical).** The pre-converted figure PDFs shipped in
   the workspace were *uncropped A4 canvases* (595×842 pt instead of the EPS
   bounding boxes), which made every figure render with large white margins and
   wrecked float placement. All converted PDFs were regenerated with
   `gs -dEPSCrop` and now match their EPS bounding boxes exactly. (This defect
   also existed in the earlier two-column PDF.)

## 6. Deliberately NOT included (removed as not needed)

- The previous two-column Elsevier version (`main_elsarticle_5p.tex` /
   `.bbl`) and earlier manuscript stages (`main.tex`, `mainR1/R2/R3`,
   `blueprint.tex`, revision notes).
- Superseded figure versions (non-R3 `Fig03/04/08` EPS) and PNG previews.
- `FIGURES_REFINED/` — the earlier 20-figure working suite (pre-paper).
- `FINAL_REFERENCES.bib` (unused by `main_final.tex`).

All of the above still exist in the project workspace if they are ever needed.


---

## Patch note (2026-09-05, final submission-readiness)

See `CHANGELOG.md`. In brief: (1) the Figure-5 λ-sweep was recomputed on
refined 32×4 and 60×12 meshes (`studies/lambda_study_refined.m`,
`opts.no_cond` option added to `solve_system.m`, default behaviour unchanged);
the rise–maximum–fall shape is mesh-robust, quantitative peak values carry the
through-thickness resolution caveat, and the refined 60×12 sweep reproduces
the §5.1 field-export value at μ₀ = 1e-6 exactly. Figure 5, §5.2, Table 5,
conclusions and limitations updated accordingly (a pre-existing backwards
direction wording in the panel-(b) description was corrected). (2) The
abstract and conclusions now state explicitly that the h_crit ∝ ℓ^0.90 law is
an empirical fit to four source-reported roots. Build after patch: 41 pages,
0 errors / 0 overfull / 0 undefined.
