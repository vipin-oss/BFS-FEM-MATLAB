# START HERE — How to Run the MATLAB Program

Zip contents:

```
MATLAB_COMPLETE_PROGRAM/   ← full production solver + verification suite (~88 .m files)
FIGURES_REFINED/           ← 20 final figure scripts (one figure per script) + helpers + data/
0_START_HERE_RUN_GUIDE.md  ← this file
```

> Honest note: every script in this zip was written for **Genuine MATLAB** and was
> verified to run with **zero errors in GNU Octave 9.4.0** (the only interpreter
> available in the build sandbox). On your MATLAB, formatting (Times New Roman,
> LaTeX labels, `parula`) renders natively. Nothing depends on Octave.

---

## PART A — THE 20 FINAL FIGURES (what you asked to run yourself)

Location: `FIGURES_REFINED/`

Each `gen_FXX_*.m` script:

- loads its data from `FIGURES_REFINED/data/` (a private copy of the verified CSVs),
- opens **ONE** figure window (no `subplot`/`tiledlayout`/`nexttile`),
- applies the frozen style: Times New Roman, axis labels 22 pt LaTeX,
  tick labels 18 pt, legend 17 pt LaTeX `Box=off`, lines 2.5 pt, markers 8 pt,
  axes `LineWidth=1.5`, `Box=on`, `TickDir=in`, no grid, no title, white background,
  colourblind-safe colours, **no rainbow/jet**, signed fields on diverging
  zero-centred maps, positive scalars on sequential maps,
- does **NOT** export anything (no `print`/`saveas`/`exportgraphics`),
- leaves the figure **open** for you to inspect and export.

### Step 1 — open the folder

```matlab
cd('FIGURES_REFINED')   % from wherever you unzipped
```

(Not strictly required — each script self-adds its own folder via `ROOT()` and
finds `data/` automatically — but it is the cleanest way.)

### Step 2 — run ONE script, inspect ONE figure

```matlab
gen_F01_schematic
```

A single figure window opens. Look at it. When you are happy:

```matlab
print -depsc2 F01_schematic   % vector EPS for the paper
% or use File > Save As > .eps  (or .pdf/.png as you prefer)
```

Then run the next script, one at a time. Do **not** use
`saveas(...,'epsc')`; use `print -depsc2` or the File menu so the vector
output is publication quality.

### Step 3 — repeat for F01 … F20 (in any order)

```matlab
gen_F02_phi_surface
gen_F03_u_field
gen_F04_v_field
gen_F05_lambda
gen_F06_lambda_norm
gen_F07_etaem
gen_F08_energy_partition
gen_F09_hcrit
gen_F10_conditioning_3d
gen_F11_conditioning_2d
gen_F12_validation_convergence
gen_F13_validation_pzt
gen_F14_validation_actuator
gen_F15_bc_sensitivity
gen_F16_etaem_waterfall
gen_F17_energy_vs_ny
gen_F18_boundary_profiles
gen_F19_diagnostic_muT
gen_F20_uelec_heatmap
```

### The 20 figures at a glance

| Script | Figure | Data source | Class | Key caveat |
|---|---|---|---|---|
| gen_F01 | geometry / computational schematic | frozen §2.12 + material data | MAIN | schematic, not data |
| gen_F02 | φ field 3D surface | field_export.csv (COMPUTED) | MAIN | signed φ → zero-centred diverging map |
| gen_F03 | u field | field_export.csv | MAIN | symmetric ± scale |
| gen_F04 | v field | field_export.csv | MAIN | symmetric ± scale |
| gen_F05 | Λ response, max|φ| vs Λ | lambda_study.csv | MAIN | broad-sampled max, NOT the optimum |
| gen_F06 | normalized max|φ|/μ₀ vs Λ | lambda_study.csv (derived) | MAIN | monotone ×8 fall = converse stiffening |
| gen_F07 | η_EM vs L/h | aspect + brackets + mesh study | MAIN | descriptive fixed-Ny slope; **not converged** |
| gen_F08 | energy partition vs L/h | aspect_ratio_study.csv | MAIN | denominator outruns numerator |
| gen_F09 | h_crit scaling | hcrit_study.csv | MAIN | roots **source-reported**; empirical trend only |
| gen_F10 | conditioning 3D (true geometry) | CONDITIONING_TRUE_GEOMETRY_RESULTS.csv | MAIN | 22.8–23.8 orders of magnitude |
| gen_F11 | conditioning 2D backup | CONDITIONING_TRUE_GEOMETRY_RESULTS.csv | SUPP | backup to F10 |
| gen_F12 | Tier-1 convergence | convergence_study.csv | MAIN | rates from reported norms; **no fabricated error curve** |
| gen_F13 | PZT-5H chain (w_timo bars) | tier2_benchmark.csv | MAIN | paper value source-reported |
| gen_F14 | actuator ana vs FEM | actuator_response.csv | MAIN | 307.37 pm **source-reported** |
| gen_F15 | BC sensitivity (tip deflection) | boundary_condition_study.csv | MAIN | single response; potential kept separate |
| gen_F16 | η_EM mesh waterfall | aspect + brackets + mesh study | SUPP | gaps honest; no interpolated surface |
| gen_F17 | energy vs Ny | ETAEM_ELEMENT_ENERGY_LOCALIZATION.csv | SUPP | U_elas converged; U_grad/U_elec grow |
| gen_F18 | boundary-layer profiles | forensic rows CSVs | SUPP | physical but under-resolved |
| gen_F19 | diagnostic μ_T causality | ASPECT_RATIO_TENSOR_CAUSALITY.csv | DIAG | not production; not regenerable |
| gen_F20 | U_elec spatial heatmap | forensic elem CSV | SUPP | physical element-centre axes |

Classification: **MAIN 14** (F01–F10, F12–F15), **SUPP 5** (F11, F16, F17, F18, F20),
**DIAG 1** (F19). Likely redundant pairs — you decide at inspection: F10↔F11
(same data, 3D vs 2D), F07↔F16 (same data, envelope vs waterfall).

---

## PART B — THE FULL SOLVER + VERIFICATION SUITE

Location: `MATLAB_COMPLETE_PROGRAM/`

These regenerate the numbers behind the figures (solver, studies, verification).
Run them only if you want to re-produce the CSVs; the figure scripts already ship
with the computed CSVs, so figures do **not** require this part.

```matlab
cd('MATLAB_COMPLETE_PROGRAM')

main                          % master pipeline — 8/8 checks PASS
run_full_scientific_regression % 20/20 regression checks PASS
verification/final_independent_calculations
%   → Λ dual-form agreement, D_Voigt finite-difference check,
%     strong-form residual, energy Gauss quadrature, h_crit normal equations
```

Other entry points (single studies — each writes its own CSV):

```matlab
studies/lambda_study            % Λ sweep  → lambda_study.csv
studies/hcrit_study             % h_crit  → hcrit_study.csv
studies/aspect_ratio_study      % L/h sweep → aspect_ratio_study.csv
studies/convergence_study       % Tier-1  → convergence_study.csv
studies/boundary_condition_study
studies/field_export            % full field dump → field_export.csv
studies/conditioning_reconciliation
```

> `generate_all_figures.m` in this folder is **superseded** by the 20 individual
> scripts in `FIGURES_REFINED/` — use those for the paper.

---

## Standing scientific caveats (do not remove)

1. **η_EM exponent is NOT converged.** Only the qualitative trend (η_EM decreases
   with L/h) is robust; every fixed-Ny exponent is descriptive. The figure labels
   say so — keep those labels.
2. **Tier-3b actuator deflection** 307.37 pm is **source-reported**; this model
   computes 89.14 nm analytic / 91.15 nm FEM for the same load. F14 identifies the
   source value explicitly. Do not force agreement.
3. **h_crit roots in F09 are source-reported**; the fitted line
   (A=24.2011, p=0.8998, R²=0.99984) is computed. Keep the "empirical scaling
   trend" wording.
4. **F19 (diagnostic μ_T)** is a diagnostic only; it is not production and its CSV
   is preserved-not-regenerable.
5. Freeze chain is unchanged: frozen master calculation, equations, solver, and
   CSVs were **not modified** by the figure scripts.
