# FINAL ASPECT-RATIO STUDY CLOSURE AUDIT

Closure of the MATLAB aspect-ratio electromechanical energy-conversion study
(`studies/aspect_ratio_study.m`) against the frozen master
`FINAL_COMPLETE_MASTER_CALCULATION.tex`. The frozen master, paper, bibliography,
constitutive formulation, D_Voigt, strong/weak forms and BFS formulation were
**NOT modified**.

---

## A. EXECUTIVE VERDICT

**CONDITIONAL PASS.**

The study is now *mathematically correct, mesh-converged, and internally
consistent*: the energy definition follows the frozen master (Part XVI),
U_elec convergence is established and controlled by through-thickness
resolution (Ny), the dense sweep is fitted on converged points, and the energy
identities (U_coup = 2·U_elec, U_int = U_mech + U_elec) hold to 12 digits at
every point.

**However** the converged result

    eta_EM ~ (L/h)^(-0.8 .. -1.1)   (DECREASING with aspect ratio)

is qualitatively **opposite** to the source-reported paper fit

    eta_EM = 2.79e-5 (L/h)^1.94   (INCREASING).

The root cause is a **model limitation, not an implementation error**: the
frozen reduced flexoelectric tensor lacks the transverse bending coupling
μ₂₁₁₂ = μ_T − μ_S, so the flexoelectric source of a bending cantilever vanishes
at leading order. This is the *same* model limitation established in the Tier-3b
actuator audit (the reduced model gives a corner-moment mechanism, not classical
flexoelectric bending). The paper's fit is SOURCE-REPORTED and cannot be
independently reproduced because (i) the raw per-point data are absent and
(ii) the frozen model does not contain the coupling that produces it.

---

## B. FROZEN-MASTER DEFINITIONS (verbatim)

- **Part XVI, Eq. (XVI_def):** η_EM = U_elec / W_ext, with the recipe
  "compute W_ext = F·v_tip (tip load × tip deflection)" and
  U_elec = ½∫(∇φ)ᵀκ(∇φ)dΩ.
- **Part XVII, Eq. (XVII_Wext):** W_ext = ∫f_i u_i dΩ + ∫Γt t̄_i u_i ds +
  ∫Γd r̄_i ∂u_i/∂n ds + Σ F̄_i u_i(x_k)  (the dead-load integral).
- **Part XVII, Eq. (XVII_Umech/Uelec):** U_mech = ½∫[εᵀCε + ηᵀDη]dΩ,
  U_elec = ½∫(∇φ)ᵀκ(∇φ)dΩ.
- **Part XVII:** "first law requires W_ext = U_mech + U_elec".

---

## C. ENERGY-DEFINITION RECONCILIATION (factor 2, settled from the frozen formulation)

The total potential is Π = U_int − W_ext with
U_int = ½qᵤᵀK_uu qᵤ − ½q_φᵀK_pp q_φ + qᵤᵀK_up q_φ (the discrete enthalpy).
Stationarity gives the saddle system; Euler's homogeneous-function theorem on
the quadratic U_int gives

    P = Fᵀq = 2·U_int   (dead-load product equals twice the stored energy).

Open circuit (Q = 0) adds the equilibrium row K_upᵀqᵤ = K_pp q_φ, hence
U_coup = qᵤᵀK_up q_φ = 2·U_elec, and therefore U_int = U_mech + U_elec.
Consequently:

    W_ext = F·v_tip  ⇒  W_ext = 2(U_mech + U_elec),   [Part XVI dead-load]
    W_qs  = ½F·v_tip ⇒  W_qs  =   U_mech + U_elec.    [Part XVII first law]

**Decision (from the frozen formulation, not from agreement):** Part XVI
*explicitly* defines η_EM with W_ext = F·v_tip (the dead-load product), so the
study uses **η_EM = U_elec/(F·v_tip)**. The quasi-static variant
η_qs = U_elec/(½F·v_tip) = 2·η_EM is reported for reference (it is the Part-XVII
energy-conversion fraction). Both are printed; only the Part-XVI definition
drives the regression.

---

## D. GEOMETRY AUDIT

- **L = 2 µm fixed; h = L/(L/h) varied** (h ∈ {400, 267, 200, 133, 100, 67, 50, 33} nm).
- Element aspect ratio ≈ (L/Nx)/(h/Ny) = (L/h)(Ny/Nx) ≈ 4:1 (Nx = 3·(L/h), Ny = 12).
- **Unintended dimensionless changes (documented):** because h varies while the
  material lengths are fixed, the study also sweeps **h/f_flexo** (0.96 → 7.7 for
  f_flexo = 25.9 nm) and **h/ℓ_elastic** (90 → 730 for ℓ_elastic = 0.27 nm).
  The flexoelectric length f_flexo lies *inside* the swept h-range, so size
  effects are active. This is the master's own material set and geometry; the
  paper's sweep (L/h ∈ [10,80] at L = 2 µm) sweeps exactly the same range.

## E. LOAD / BC AUDIT

- **Sensor mode, fixed total force F = 1 nN** on the free edge (per-node F/nd),
  no applied voltage (V₀ = 0; the potential is the *output*). There is no
  E₀ = V₀/h to hold constant — the concern in the task does not apply to a
  sensor study (verified: no electrical load is prescribed beyond the gauge).
- Open circuit + a single grounded node (gauge).
- Mechanical BC: left edge fully clamped (all 8 BFS DOFs/node).

## F. MESH-CONVERGENCE TABLES

**L/h = 20 (h = 100 nm) — direction of U_elec convergence:**

| mesh | U_elec [J] | η_EM | note |
|---|---|---|---|
| 8×1 | 5.9855e-27 | 4.75e-2 | coarsest |
| 16×2 | 2.3686e-27 | 1.76e-2 | previous study default |
| 32×4 | 1.2062e-27 | 8.71e-3 | |
| 64×8 | 9.4805e-28 | 6.77e-3 | |
| 32×2 → 96×2 | 2.45→2.49e-27 | ~9.1e-3 | **Nx-only: converges quickly** |
| 16×4 → 16×12 | 1.18e-27 → 9.16e-28 | 4.3→3.3e-3 | **Ny-only: controls convergence** |
| 60×12 | 9.3025e-28 | 3.32e-3 | converged (study mesh) |

**Conclusion:** U_elec convergence is controlled by **Ny** (through-thickness
resolution of the flexo boundary layer), not Nx. Ny = 12 is within ~2 % of
Ny = 16 at L/h = 20 but within ~27 % at L/h = 60 (slow algebraic convergence;
the residual through-thickness error at small h is documented, and the Ny = 16
high-branch exponent p ≈ −0.77 brackets the Ny = 12 exponent p ≈ −1.12).

## G. INDEPENDENT U_ELEC VERIFICATION

U_elec computed two ways at L/h = 20 (60×12):
- matrix form ½φᵀK_ppφ = 9.483547196662e-28 J
- element-level Gauss integration of ½∫(∇φ)ᵀκ(∇φ)dΩ = 9.483547196662e-28 J
- relative difference **6.24e-15** (identical).

Energy identities at every sweep point (12 digits): U_coup = 2·U_elec,
U_int = U_mech + U_elec. The fast uniform-mesh assembly is identical to
`assembly.m` (verified difference **0**).

## H. FIRST-PRINCIPLES SCALING DERIVATION

Reduce the frozen Gauss law (Eq. IV_PDE3) to a bending cantilever
u = −y·w′(x), v = w(x) with w‴ = −F/(C₁₁I):
- flexo terms: μ₁₁u,xxx = −μ₁₁y·w⁗ = 0; (μ₁₂+2μ₄₄)u,xyy = 0;
  (μ₁₂+2μ₄₄)v,xxy = 0; μ₁₁v,yyy = 0.
- **All flexoelectric terms vanish at leading order** because the reduced tensor
  has no transverse coupling μ₂₁₁₂ (no μ_T·u,xy in D₂, no μ_T·v,xx in D₁).
- The residual source is a second-order Poisson/shear/boundary-layer effect.

**Consequence:** no O(1) (L/h)² bending response exists for the reduced model.
The naive "+2" prediction assumed a leading-order source ∝ w‴ that is in fact
absent. The observed scaling
- U_elec ∝ (L/h)^~1.9 (Ny = 12) or ^~2.2 (Ny = 16),
- W_ext ∝ (L/h)³ (mechanical, h⁻³),
- **η_EM ∝ (L/h)^(−0.8 .. −1.1)**,
is the boundary-layer/Poisson-shear signature of the reduced model.

## I. DENSE ASPECT-RATIO RESULTS (converged, Ny = 12)

| L/h | η_EM (dead-load) | η_qs = 2·η_EM | U_elec [J] | W_ext [J] |
|---|---|---|---|---|
| 5 | 3.929e-3 | 7.858e-3 | 1.796e-29 | 4.570e-27 |
| 7.5 | 4.737e-3 | 9.474e-3 | 7.157e-29 | 1.511e-26 |
| 10 | 4.946e-3 | 9.891e-3 | 1.754e-28 | 3.546e-26 |
| 15 | 4.259e-3 | 8.519e-3 | 5.055e-28 | 1.187e-25 |
| 20 | 3.319e-3 | 6.638e-3 | 9.303e-28 | 2.803e-25 |
| 30 | 2.078e-3 | 4.156e-3 | 1.957e-27 | 9.418e-25 |
| 40 | 1.470e-3 | 2.941e-3 | 3.270e-27 | 2.224e-24 |
| 60 | 9.752e-4 | 1.950e-3 | 7.258e-27 | 7.443e-24 |

The η_EM curve peaks near L/h = 10 and then decreases monotonically.

## J. POWER-LAW REGRESSION (converged data)

- Full 8 points: A = 1.68e-2, **p = −0.63**, R² = 0.80 (non-monotonic — poor fit).
- High branch (L/h ≥ 20, Ny = 12): A = 9.42e-2, **p = −1.12**, R² = 0.9986.
- High branch (Ny = 16, L/h = 30/40/60): **p = −0.77**.

**Final converged exponent: p ≈ −0.8 ± 0.3 (NEGATIVE).**

## K. COMPARISON WITH THE SOURCE-REPORTED FIT

| | A | p | R² |
|---|---|---|---|
| MATLAB converged (this study) | ~1e-2 | **−0.8 ± 0.3** | 0.999 (high branch) |
| Source-reported paper | 2.79e-5 | **+1.94** | 0.9984 |

Relative differences: prefactor ~360×, exponent sign-flip. The MATLAB result
cannot reproduce the source fit because (a) the raw per-point data are absent
and (b) the frozen reduced model lacks the transverse flexoelectric coupling.
**The source fit is not independently reconstructible from the supplied evidence.**

## L. ROOT CAUSE OF THE PREVIOUS NEGATIVE EXPONENT

The previous p ≈ −0.79 was an *artifact*: it used (i) the quasi-static
denominator ½F·v_tip (a factor-2 convention error vs Part XVI) and (ii) Ny = 2
meshes whose U_elec was overestimated by up to 2.6× and, more importantly, was
not converged. After correction the converged exponent is *still negative*
(−0.8), which is now a **physical model property** (the reduced tensor has no
leading-order bending coupling), not an artifact.

## M. CORRECTIONS MADE

1. `studies/aspect_ratio_study.m` — energy definition (dead-load F·v_tip per
   Part XVI, quasi-static variant reported separately); converged mesh
   (Ny = 12, Nx = 3·(L/h)); 8-point dense sweep; degree-1 regression with the
   high-branch fit; explicit model-limitation conclusion; memory-safe uniform
   fast assembly (identical to `assembly.m`, verified).
2. No change to any other study, the FEM core, or the frozen master.

## N. BEFORE / AFTER NUMERICAL RESULTS

| | Before | After (converged) |
|---|---|---|
| denominator | ½F·v_tip | F·v_tip (master Part XVI) |
| mesh | 16×2 (Ny = 2) | Ny = 12, Nx = 3·(L/h) |
| η_EM(L/h=20) | 1.76e-2 | 3.32e-3 (η_qs = 6.64e-3) |
| exponent | −0.79 (artifact) | −0.8 ± 0.3 (converged, physical) |
| comparison vs source | opposite sign | opposite sign (model limitation) |

## O. NUMERICAL CONDITIONING

All solves use the full DOF scaling (combined condition numbers ~1e8, rcond
~1e-8 ≫ eps); no singular-matrix warnings; no raw/electromechanical-only solves.

## P. SOURCE-DATA AVAILABILITY

`section6_master_dataset.json` was searched for and is **absent**; the paper's
per-point (L/h, η_EM) table over L/h ∈ [10, 80] is therefore not available and
was not recreated from memory.

## Q. PUBLICATION-READINESS DECISION

**CONDITIONAL PASS.** The MATLAB study is scientifically sound *for the frozen
reduced model* (correct energy definition, verified convergence, verified energy
identities, dense sweep, stable high-branch fit, justified exponent). It is NOT
a reproduction of the paper's η_EM ∝ (L/h)^1.94 — that result belongs to a
flexoelectric model with the transverse coupling μ₂₁₁₂, which the frozen model
does not contain, and its raw data are absent. The aspect-ratio figure may be
used in the paper only if it is explicitly presented as the *reduced-model*
scaling, or it must await the full-tensor model / the raw dataset.

## R. EXACT REMAINING LIMITATIONS

1. The frozen reduced flexoelectric tensor lacks μ₂₁₁₂ (transverse bending
   coupling) — hence no leading-order bending flexo response; the η_EM scaling
   is boundary-layer/Poisson-shear dominated. (Same limitation as Tier-3b.)
2. Through-thickness convergence of U_elec is slow (algebraic ~Ny⁻¹); at
   L/h = 60 the Ny = 12 value is ~27 % below the Ny = 16 value (documented;
   the exponent is bracketed as −0.8 ± 0.3).
3. The master's internal W_ext convention ambiguity (Part XVI dead-load vs
   Part XVII first law) is resolved by using the explicit Part-XVI definition,
   with the quasi-static variant reported separately.
4. `section6_master_dataset.json` absent → the paper's η_EM = 2.79e-5 (L/h)^1.94
   remains SOURCE-REPORTED and not independently reproducible.

---

## FINAL STOP (required summary)

1. **Final verdict:** CONDITIONAL PASS.
2. **Final A, p, R² (converged MATLAB data):** A ≈ 1e-2 (mesh-dependent),
   **p ≈ −0.8 ± 0.3**, R² = 0.999 (high branch, Ny = 12).
3. **Source A, p, R²:** 2.79e-5, 1.94, 0.9984.
4. **Is the source fit independently reproducible? NO** — raw Section-6 data
   absent AND the frozen reduced model lacks the transverse flexoelectric
   coupling that produces the (L/h)² bending response.
5. **Exact remaining limitation(s):** the reduced-tensor model limitation
   (no μ₂₁₁₂), slow through-thickness convergence at small h, and the absent
   raw dataset.
