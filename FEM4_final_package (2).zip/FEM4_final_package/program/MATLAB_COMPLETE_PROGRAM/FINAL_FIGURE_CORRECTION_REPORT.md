# FINAL FIGURE-ONLY CORRECTION REPORT

Figure-generation correction only. The scientific calculations are FROZEN and
were not modified (constitutive tensors, FEM, BFS, assembly, solver, DOF
scaling, BCs, material parameters, benchmarks, studies, tolerances,
regression). Frozen master/paper/bibliography are byte-unchanged.

---

## 1. Fixed defect

`studies/field_export.m` exported `results` before the structure was built
(`save(...,'results')` ran before `results.x = ...`), so MATLAB errored with
"variable `results` does not exist". The field calculation itself was already
correct (max|u|=1.052e-08 nm, max|v|=2.803e-07 nm, max|phi|=1.901e-10 V).

**Fix:** build the `results` structure FIRST (x, y, u, v, phi, Lh, Nx, Ny,
L, h), then export CSV + MAT. The function now returns a valid structure and
contains no undefined variable. The FEM calculation is unchanged.

## 2. Removed ALL automatic image export

- Deleted `plotting/export_figure.m` and `plotting/export_plot.m` (which called
  `exportgraphics` / `print -dpdf/-depsc`).
- Every plotting script now ends by calling `prepare_figure(w,h)` — which only
  sets the figure's physical size and white background — and then LEAVES THE
  FIGURE OPEN for manual saving. No `saveas`/`exportgraphics`/`print`/PNG/JPG/
  SVG/PDF/EPS commands remain anywhere in the plotting layer or
  `generate_all_figures.m` (verified by grep: zero matches).
- No Ghostscript / external plotting software is required.
- CSV/MAT **data** exports of the studies are retained (they are the
  reproducibility layer the plotting scripts read from).

## 3. Unified SCI-journal style (Times New Roman, restrained sizes)

- Fonts: Times New Roman everywhere; axis labels 12 pt, tick labels 10 pt,
  legend 8.5 pt, panel labels 11 pt bold, colorbar labels 9 pt, annotations
  9-10 pt. No oversized presentation fonts; no decorative fonts.
- Titles: removed from the data figures (panel labels carry identification);
  only the two field panels keep a short normal-weight quantity label.
- Lines: main curves 1.6 pt, comparison/reference curves 1.2 pt, markers 5 pt,
  axes 1.0 pt.
- Figure sizes set via `prepare_figure`: single-column 3.4 in, double-column
  6.9 in (display only; no file is written).
- Colors: colorblind-safe Okabe-Ito palette (`fig_color`), applied
  consistently; the same quantity keeps the same visual identity. No MATLAB
  default colors, no `jet`. A perceptually ordered viridis-like colormap
  (`fig_colormap`) is used for the 2D field contours.
- Removed `fig_palette.m` (superseded by `fig_color`).

## 4. Figure content — data sources and generators

Every figure is read-only with respect to scientific results (it reads the
computed CSV/MAT and never modifies a calculation), and contains no
hard-coded numerical output.

| Figure | Purpose | Data source | Generator function |
|---|---|---|---|
| fig1 geometry | model domain + BCs + 36-DOF BFS convention | model inputs (material_BaTiO3) | `plotting/plot_geometry.m` |
| fig2 fields | coupled spatial fields u, v, phi | `output/field_export.csv` (from `studies/field_export.m`) | `plotting/plot_fields.m` |
| fig3 validation | Tier-1 convergence, PZT-5H corrected chain, Tier-3b actuator FEM vs corner-moment analytic | `convergence_study.csv`, `tier2_benchmark.csv`, `actuator_response.csv` | `plotting/plot_validation.m` |
| fig4 sensor | flexoelectric sensor V(h) (frozen model) | `output/sensor_scaling.csv` | `plotting/plot_tier3.m` |
| fig5 lambda | Lambda parameter study (computed self-stiffening peak) | `output/lambda_study.csv` | `plotting/plot_lambda.m` |
| fig6 aspect | energy-conversion ratio vs L/h (+ fitted branch; paper +1.94 labelled source-reported) | `aspect_ratio_study.csv/.mat` | `plotting/plot_aspect_ratio.m` |
| fig7 hcrit | critical-thickness power law (fits read from study output) | `output/hcrit_study.mat` | `plotting/plot_hcrit.m` |
| fig8a bc | boundary-condition sensitivity | `output/boundary_condition_study.csv` | `plotting/plot_boundary_conditions.m` |
| fig8b cond | condition-number reduction (full DOF scaling) | computed in-script via `assembly` + `condest` | `plotting/plot_conditioning.m` |

Validation discipline: source-reported values (paper w_timo = 5.886754e-14 m,
Tier-3b 307.37 pm, paper η_EM = 2.79e-5 (L/h)^1.94, paper h_crit 23.76/0.90)
are plotted ONLY as clearly labelled reference curves/bars, never as MATLAB
results.

## 5. generate_all_figures.m

Stage 1 runs the data-generating studies/benchmarks (computing every CSV/MAT);
stage 2 opens every canonical figure. It stops only on genuine calculation
errors, requires no Ghostscript/external software, and performs no image
export.

## 6. Final verification results

- `main`: 8/8 verification suites PASS.
- `run_full_scientific_regression`: **20/20 PASS** (numerical results unchanged).
- `generate_all_figures`: exit 0; all 9 figures created and left open; no
  undefined variable; no singular/NaN/Inf; no image file written (verified:
  0 image files in `output/`).
- 80 `.m` files, 0 parse failures.
- Frozen master / paper / bibliography byte-unchanged (Lambda = 1.051665e-2
  intact).
- Data integrity: 18 data files (CSV/MAT) regenerated; every plotted value
  traces to a computed variable.

## 7. Remaining note for the MATLAB run

In the Octave preview (gnuplot) two axis labels that use LaTeX-style symbols
(`\Lambda = \surd(D_0\kappa_0)/\mu_0`, `\eta_{EM} = U_{elec}/(F v_{tip})`)
emit a gnuplot "invalid command" preview note; in the user's MATLAB the `tex`
interpreter renders these symbols natively with no warning. No other warnings
or errors remain.

---

The corrected MATLAB program is ready: run

    cd('D:\MATLAB_COMPLETE_PROGRAM'); addpath(genpath(pwd));
    generate_all_figures

and manually save each open figure from the MATLAB figure window.
