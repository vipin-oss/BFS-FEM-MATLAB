# FINAL FOUR STUDIES SCIENTIFIC AUDIT

First-principles scientific audit of the four user-run studies
(`convergence_study`, `lambda_study`, `aspect_ratio_study`,
`boundary_condition_study`) against the frozen master calculation
`FINAL_COMPLETE_MASTER_CALCULATION.tex`.

> Execution success ≠ scientific validation. Each study is graded PASS /
> CONDITIONAL PASS / FAIL on: formulation correctness, implementation-match,
> observable definition, BC/load correctness, numerical convergence, and
> comparison with source data.

---

## 1. EXECUTIVE VERDICT

| Study | Verdict | One-line reason |
|---|---|---|
| convergence_study | **CONDITIONAL PASS** | Measured observable (point value) ≠ master's observable (L2/H1/G error norms); fixed by separating the recomputed source-reported rates from the computed point-value rate. |
| lambda_study | **PASS (after fix)** | Λ verified by two definitions; the 4-point sweep hid a physical peak; fixed with a 10-point log-spaced sweep and a documented self-stiffening interpretation. |
| aspect_ratio_study | **CONDITIONAL PASS** | Two real defects fixed: (1) wrong denominator (½F·v_tip vs master's F·v_tip); (2) U_elec not mesh-converged (reported, not hidden). The paper's η_EM = 2.79e-5 (L/h)^1.94 remains SOURCE-REPORTED. The computed trend is NOT publication-ready. |
| boundary_condition_study | **PASS (with documentation)** | Physics correct (tip ≈ 2.7e-16 m matches the Euler–Bernoulli reference 2.38e-16 m); "pinned" is a displacement-only BC, not a classical Mindlin simple support — documented, not changed. |

---

## 2. FILE-BY-FILE CODE TRACE

All four studies call: `material_*` (config) → `generate_mesh` → `apply_tip_load`
/ `make_cantilever_bc` → `assembly` (C, D_Voigt, e_V, μ_V, κ) → `solve_system`
(full DOF scaling `use_dof_scaling=true`, electrical true/false) → post-process
(energy forms / point values) → `export_table`.

### convergence_study
- Part A recomputes r_L2/r_H1/r_G from the master's QUOTED norms (Eq. XI_tier1_errors, XI_rL2–XI_rG): **r = 3.9998 / 2.9963 / 1.9995** (source-reported norms, recomputed rates).
- Part B measures u at the right-edge mid-height node over 12×4→24×8→48×16 (mechanical-only, DOF-scaled, bottom-clamped/top-u=uhat documented BCs): Richardson point-value rate **2.18**.
- **These are different observables.** The master's rates are ERROR norms (L2, H1, energy/gradient) against the Shekarchizadeh analytical solution, which is NOT in the master (only the norm values e1, e2 are quoted). The point-value rate is a functional rate under documented (not master-specified) BCs.

### lambda_study
- Λ = √(D₀κ₀)/μ₀ (Eq. III_Lambda) verified **identically** by Method 2 = ℓ_elastic/f_flexo (max |Δ| = 0) for every sweep point.
- Sweeps μ₀ only (D₀, C₀, κ₀, geometry, loads, BCs fixed); the DOF scaling (φ₀ = u₀√(C₀/κ₀)) does NOT depend on μ₀, so the scaling is consistent across the sweep.
- Observable max|φ| is gauge-fixed (one grounded node) and mesh-converging (8×1: 3.20e-10 → 16×2: 2.96e-10 → 32×4: 2.65e-10 V).

### aspect_ratio_study
- η_EM = U_elec/W_ext (master Part XVI, Eq. XVI_def), W_ext = F·v_tip (dead-load product), U_elec = ½φᵀK_φφφ (Eq. XVII_Uelec).
- The previous version used W_qs = ½F·v_tip → **factor-2 definitional discrepancy vs the master** (fixed: the master's dead-load definition is now primary; both are reported because the master's Part XVII first law uses ½F·v_tip — an internal master ambiguity, documented).
- L fixed (2 µm), h = L/(L/h) varied; mesh fixed 16×2 in the old version (now also 32×4). The load is a **constant total force F=1 nN** distributed on the free edge (correct per the master's "fixed F" sensor-mode recipe).

### boundary_condition_study
- BC-1 full clamp (8 DOFs/node on x=0), BC-2 "pinned" u=v=0 only, BC-3 u=v=0 + u_x=0. Electrical: open circuit + one grounded node in all three.
- "pinned" is NOT a classical Mindlin simple support (which requires the double-traction operator r_i = h_ijk n_j n_k, Eq. V_double_traction); it is a legitimate simplified essential BC.

---

## 3. CONVERGENCE AUDIT

- **What the master measures:** r = ln(e1/e2)/ln(h1/h2) with e1,e2 the L2/H1/G error norms at 24×8 → 48×16 (Eq. XI_rL2–XI_rG). The norm VALUES (4.7610e-6, …) are quoted in the master; the analytical solution used to compute them is **not** supplied.
- **What convergence_study measured:** a single point value of u — a functional, not an error norm.
- **Are they comparable? NO.** The current study cannot reproduce r_L2/r_H1/r_G (no analytical solution available). The rates are recomputable ONLY from the quoted norms (done, Part A), and the norms themselves are source-reported.
- **Observed point-value rate 2.18:** for the bicubic (p=3) BFS element a smooth point functional should converge at O(h⁴) in the interior; the observed ~O(h²) reflects the corner/boundary-layer behavior of the fully-clamped bottom edge (the higher-order BCs generate a boundary layer). Not a defect, but not a headline convergence figure either.
- **Figure-readiness:** the paper figure for Tier-1 must use the master's error-norm rates (source-reported); the computed point-value rate is NOT a replacement.

---

## 4. LAMBDA AUDIT

- Λ = √(D₀κ₀)/μ₀ = ℓ_elastic/f_flexo, **both definitions verified point-by-point (|Δ| = 0)**.
- The previous 4-point sweep (μ₀ = 2.5e-7…2e-6) straddled the **physical peak** and looked like noise. The 10-point log-spaced sweep (μ₀ = 2.5e-8…2.5e-6, Λ = 4.2e-3…0.42) reveals a clean **rise–peak–saturation**:
  - μ₀ = 2.5e-8: max|φ| = 1.60e-11 V
  - μ₀ = 9.0e-7 (**peak**): max|φ| = 2.94e-10 V
  - μ₀ = 2.5e-6: max|φ| = 2.01e-10 V
- **Is non-monotonicity expected? YES.** For small μ₀ the flexoelectric polarization (hence the open-circuit potential) grows ~μ₀; for large μ₀ the converse flexoelectric effect stiffens the beam and reduces the strain gradient, so the response saturates and falls. This is the same self-stiffening mechanism the master reports for the sensor (Tier-3 "self-stiffening saturation").
- Mesh check at the peak (μ₀ = 1e-6): 3.20e-10 → 2.96e-10 → 2.65e-10 V (converging). The reported values are coarse-mesh but the trend is robust.
- **Figure-readiness:** YES for a trend figure (log-spaced Λ vs max|φ|), with a mesh-convergence caveat.

---

## 5. ASPECT-RATIO AUDIT (priority)

### D1 — Energy definition
Master Part XVI (verbatim): η_EM = U_elec/W_ext, **W_ext = F·v_tip** (dead-load product), U_elec = ½∫(∇φ)ᵀκ(∇φ)dΩ. The MATLAB code used W = ½F·v_tip → **factor 2 too large** in η. Both conventions now reported (the master's Part XVII first law itself uses the quasi-static ½F·v_tip, an internal master ambiguity, documented).

### D2 — Geometry scaling
L fixed at 2 µm; h = L/(L/h) ∈ {200, 100, 50, 25} nm; mesh element count fixed (16×2, plus 32×4 in the audit). Changing L/h therefore changes h (and hence EI ∝ h³, flexo coupling μ/(EI) ∝ h⁻³, capacitance, etc.) — exactly the master's "fixed F, sweep L/h by varying h" convention.

### D3 — Load/BC scaling
Constant **total force** F = 1 nN on the free edge (per-node F/nd); open circuit + one grounded node. No unintended load rescaling. (This matches the master's sensor-mode "fixed F" recipe.)

### D4 — Energy scaling (first-principles derivation)
From the master's constitutive equations (Eq. IV_D1, IV_D2) for a tip-loaded bending cantilever u = −y·w′(x), v = w(x):
- D₁ = −κ₁₁φ,x − μ₁₁ y w″ + (μ₁₂+2μ₄₄) w″/2,  D₂ = −κ₂₂φ,y (no flexo in D₂ — the reduced tensor has no transverse term μ₂₁₁₂).
- Gauss ∇·D = 0 gives source = w‴(μ₁₁ y − (μ₁₂+2μ₄₄)/2), w‴ = −F/(EI) ∝ h⁻³.
- Naive estimate: φ ~ source·L²/κ ∝ h⁻³ ⇒ U_elec ∝ κφ²h/L ∝ h⁻⁵ ⇒ **η_EM ∝ U_elec/W_ext ∝ h⁻⁵/h⁻³ = h⁻² = (L/h)²** (p = +2, at fixed L).
- **The master's own equations therefore predict η_EM ∝ (L/h)²**, matching the SIGN and near-quadratic exponent of the paper's p = 1.94. (The prefactor 2.79e-5 is not derivable without the full field solution.)

### D5 — Mesh convergence (the decisive finding)
| mesh | U_elec (L/h=20) |
|---|---|
| 8×1 | 5.99e-27 J |
| 16×2 | 2.37e-27 J |
| 32×4 | 1.21e-27 J |
| 64×8 | 9.48e-28 J |

**U_elec is NOT mesh-converged** at 16×2/32×4 (it decreases with refinement); v_tip and W_ext DO converge. The previous aspect-ratio exponent (p ≈ −0.79) was computed on a non-converged U_elec and is **not physically meaningful**. The audited study now reports both meshes and flags the non-convergence explicitly.

### D6 — Paper fit
η_EM = 2.79e-5 (L/h)^1.94, R² = 0.9984 is **SOURCE-REPORTED** (the per-point (L/h, η_EM) table is not in the master). The exponent's SIGN (+1.94 ≈ +2) is consistent with the first-principles scaling of the master's own equations (D4); the MATLAB implementation cannot reproduce the prefactor because (a) the raw data are absent and (b) the current U_elec is mesh-under-resolved. **Not a model error; a data-availability + convergence limitation.**

---

## 6. BOUNDARY-CONDITION AUDIT

- All three variants share: open circuit + single grounded node (gauge fixed), tip load F = 1 nN on the free edge, full DOF scaling.
- BC-1 (full clamp): all 8 essential DOFs = 0 on x = 0 (admissible for C¹ BFS).
- BC-2 ("pinned"): only u = v = 0 — a displacement-only constraint, NOT the Mindlin simply-supported condition (which would enforce the double-traction r_i = h_ijk n_j n_k = 0, Eq. V_double_traction). Legitimate but simplified; documented.
- BC-3 (clamp + normal slope): u = v = u_x = 0 — partial higher-order constraint; the higher-order operators (double traction, corner forces) are NOT enforced as natural conditions here.
- **Tip v ≈ 2.7e-16 m is physically CORRECT**: Euler–Bernoulli reference F L³/(3 C₁₁I) = 2.377e-16 m; the three variants differ at the 10% level of this sub-nm deflection because the membrane/curvature response dominates.
- **Figure-readiness:** usable as a BC-sensitivity figure only with the caveat that "pinned" is a simplified displacement BC.

---

## 7. CROSS-STUDY CONSISTENCY

All four studies share: `material_BaTiO3`/`material_Shekarchizadeh` (same C, D_Voigt, e, μ, κ), `generate_mesh` (same numbering), `assembly` (same DOF order [u,u_x,u_y,u_xy,v,v_x,v_y,v_xy] ⊕ φ), 4×4 Gauss, full DOF scaling (`use_dof_scaling=true`), `make_cantilever_bc` (clamp + ground), `apply_tip_load` (constant total F). No study-specific constitutive deviations were found.

---

## 8. MATHEMATICAL DERIVATIONS USED FOR VERIFICATION
1. Λ = √(D₀κ₀)/μ₀ = ℓ_elastic/f_flexo (dual definition, |Δ| = 0).
2. r = ln(e1/e2)/ln(h1/h2) for the quoted norms.
3. Bending reduction of the master's D₁/D₂ → flexo source = w‴(μ₁₁ y − (μ₁₂+2μ₄₄)/2) → η_EM ∝ (L/h)².
4. Euler–Bernoulli tip reference v = FL³/(3C₁₁I) for the BC-study sanity check.

## 9. NUMERICAL TABLES
(see the four study console outputs above and the exported CSVs; key values reproduced in Sections 3–6.)

## 10. MESH-CONVERGENCE EVIDENCE
- lambda: max|φ| 3.20e-10 → 2.96e-10 → 2.65e-10 V (converging).
- aspect: U_elec 5.99e-27 → 2.37e-27 → 1.21e-27 → 9.48e-28 J (NOT converged — flagged).
- convergence: v_tip/point-value stable to ~1e-12 (see Part B).

## 11. SOURCE-REPORTED vs INDEPENDENTLY COMPUTED
| Quantity | Status |
|---|---|
| r_L2/r_H1/r_G (Tier-1) | rates recomputed from QUOTED norms; norms source-reported |
| η_EM = 2.79e-5 (L/h)^1.94 | SOURCE-REPORTED (raw data absent) |
| Λ values | INDEPENDENTLY COMPUTED (dual definition) |
| BC-study tip deflections | INDEPENDENTLY COMPUTED (matches elastic reference) |
| Tier-3/Tier-3b dataset | SOURCE-REPORTED (absent) |

## 12. EXACT DISCREPANCIES
1. aspect-ratio denominator: ½F·v_tip (old) vs F·v_tip (master Part XVI) → factor 2.
2. aspect-ratio exponent: −0.79 (old, non-converged) vs +2 (first-principles) / +1.94 (paper, source-reported).
3. lambda: 4-point sweep made a physical peak look like noise.
4. convergence: point-value rate mislabeled next to error-norm rates.
5. boundary: "pinned" ≠ Mindlin simple support.

## 13. ROOT CAUSES
1–2: denominator convention + non-converged U_elec (flexo field is a high-order quantity).
3: too-coarse sweep. 4: different observables. 5: BC interpretation.

## 14. CORRECTIONS MADE (MATLAB only; frozen master untouched)
- `aspect_ratio_study.m`: master's dead-load η_EM primary + quasi-static variant; 2-mesh U_elec with non-convergence flag; degree-1 fit removed (no more misleading fit); first-principles scaling note.
- `lambda_study.m`: 10-point log-spaced sweep; dual-Λ verification; physical-peak interpretation.
- `convergence_study.m`: separates recomputed error-norm rates (Part A) from computed point-value rate (Part B).
- `boundary_condition_study.m`: documents "pinned" ≠ Mindlin simple support; adds the elastic tip reference.

## 15. BEFORE/AFTER
| | Before | After |
|---|---|---|
| aspect-ratio η_EM(L/h=20, 16×2) | 1.76e-2 (½F·v_tip) | 8.81e-3 (F·v_tip, master def) + 32×4: 4.35e-3 |
| aspect-ratio exponent | −0.79 (fit) | not fitted; flagged non-converged; theory p=+2 |
| lambda points | 4 (straddling peak) | 10 log-spaced (peak resolved) |
| convergence output | one "rate 2.18" | Part A (source-reported rates) + Part B (point-value) |

## 16. FIGURE-READINESS DECISION
- convergence: **use master's error-norm rates (source-reported); point-value rate NOT for publication.**
- lambda: **ready as a trend figure** (log Λ vs max|φ|, self-stiffening peak), coarse-mesh caveat.
- aspect-ratio: **NOT ready** — U_elec must be mesh-converged first; paper fit is source-reported.
- boundary-condition: **usable with caveats** ("pinned" = displacement-only).

## 17. REMAINING UNRESOLVED QUESTIONS
1. Is U_elec converged at 64×8 and beyond, and does the converged η_EM then scale as (L/h)²? (Requires heavier runs; Octave runtime limited.)
2. The exact prefactor of η_EM for the reduced model vs the paper's 2.79e-5 (requires the absent dataset and/or converged field solutions).
3. The master's internal W_ext convention ambiguity (Part XVI dead-load vs Part XVII quasi-static).

## 18. EXACT RAW DATA STILL REQUIRED
`section6_master_dataset.json` — specifically: the per-point (L/h, η_EM) table over L/h ∈ [10, 80]; the Tier-1 analytical-solution error-norm table (or the Shekarchizadeh exact solution); the Lambda-sweep dataset; the higher-order BC-study dataset.

## 19. FINAL STATUS
| Study | Status |
|---|---|
| convergence_study | CONDITIONAL PASS |
| lambda_study | PASS |
| aspect_ratio_study | CONDITIONAL PASS |
| boundary_condition_study | PASS (documented) |
