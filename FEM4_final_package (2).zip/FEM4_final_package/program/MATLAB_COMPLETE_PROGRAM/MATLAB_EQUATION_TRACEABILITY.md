# MATLAB Equation Traceability

Every major MATLAB function is traceable to the frozen master calculation
`FINAL_COMPLETE_MASTER_CALCULATION.tex`. Columns: MATLAB file → function →
master equation(s) → master Part → purpose → verification routine.

## Constitutive layer

| MATLAB file | Function | Master equation | Part | Purpose | Verified by |
|---|---|---|---|---|---|
| `constitutive/constitutive_C.m` | `constitutive_C` | Eq. (I_C_matrix); (XI_C11_BT..XI_C33_BT); (XI_C_PZT) | I, XI | plane-strain elastic Voigt matrix C (3×3) | `verify_symmetry`, benchmarks |
| `constitutive/constitutive_D.m` | `constitutive_D` | Eq. (III_W), (III_Dmatrix), (III_Dentries) | III | Mindlin Form-II D_Voigt (6×6, 18 non-zero entries) | `verify_D_voigt` |
| `constitutive/piezoelectric_e.m` | `piezoelectric_e` | Eq. (II_e_components), (II_eV_matrix) | II | reduced piezo matrix e_V (2×3) | `verify_symmetry` |
| `constitutive/flexoelectric_mu.m` | `flexoelectric_mu` | Eq. (II_mu_components), (II_muV), (IV_D1, IV_D2) | II, IV | reduced flexo matrix μ_V (2×6), with ½ factors on the 2η slots | `verify_symmetry` |
| `constitutive/dielectric_kappa.m` | `dielectric_kappa` | Eq. (IV_PDE3); Part I symmetry reductions | I, IV | permittivity κ (2×2) | `verify_symmetry` |

## FEM layer (36-DOF BFS element)

| MATLAB file | Function | Master equation | Part | Purpose | Verified by |
|---|---|---|---|---|---|
| `fem/hermite_cubic.m` | `hermite_cubic` | Eq. (VII_hermite), (VII_dH1..VII_ddH2) | VII | 1D cubic Hermite basis + 1st/2nd derivatives | `verify_B_matrices` |
| `fem/bfs_shape_functions.m` | `bfs_shape_functions` | Eq. (VII_bfs), (VII_interp) | VII | tensor-product BFS values N1..N4 | `verify_B_matrices` |
| `fem/bfs_shape_derivatives.m` | `bfs_shape_derivatives` | Eq. (VII_chain), (VIII_dNx..VIII_dNxy) | VII, VIII | physical derivatives Nx,Ny,Nxx,Nyy,Nxy | `verify_B_matrices` |
| `fem/B_e_matrix.m` | `B_e_matrix` | Eq. (VIII_Be) | VIII | strain operator B_e (3×32) | `verify_B_matrices` |
| `fem/B_eta_matrix.m` | `B_eta_matrix` | Eq. (VIII_Beta); (I_eta_voigt) | VIII, I | strain-gradient operator B_η (6×32) | `verify_B_matrices` |
| `fem/B_phi_matrix.m` | `B_phi_matrix` | Eq. (VIII_Bphi); (VII_lagrange) | VIII, VII | field operator B_φ (2×4) | `verify_B_matrices` |
| `fem/gauss_legendre_4x4.m` | `gauss_legendre_4x4` | Eq. (VIII_gauss) | VIII | 4-point Gauss rule (2n−1=7≥6) | `verify_quadrature` |
| `fem/element_stiffness.m` | `element_stiffness` | Eq. (VIII_Kuu) | VIII | K_uuᵉ = ∫(B_eᵀCB_e + B_ηᵀDB_η) | `verify_symmetry` |
| `fem/element_coupling.m` | `element_coupling` | Eq. (VIII_Kuphi) | VIII | K_uφᵉ = ∫(B_eᵀeᵀ + B_ηᵀμᵀ)B_φ | `verify_symmetry` |
| `fem/element_electrical.m` | `element_electrical` | Eq. (VIII_Kphiphi) | VIII | K_φφᵉ = ∫B_φᵀκB_φ | `verify_symmetry` |
| `fem/generate_mesh.m` | `generate_mesh` | Eq. (VII_parent, VII_physical, VII_map) | VII | rectangular mesh, node/element numbering | benchmarks |
| `fem/assembly.m` | `assembly` | Eq. (VIII_element_system) | VIII | sparse global K_uu, K_uφ, K_φφ | `verify_symmetry` |
| `fem/assembly_Kuu.m` | `assembly_Kuu` | Eq. (VIII_Kuu) | VIII | mechanical-block-only assembly | studies |
| `fem/apply_boundary_conditions.m` | `apply_boundary_conditions` | Part V (boundary operators) | V | essential-BC elimination | benchmarks |
| `fem/make_cantilever_bc.m` | `make_cantilever_bc` | Part V (kinematic clamp + ground) | V | clamped cantilever + φ ground | benchmarks |
| `fem/apply_tip_load.m` | `apply_tip_load` | Part XI Table (end shear F) | XI | distributed end-shear load | benchmarks |
| `fem/solve_system.m` | `solve_system` | Eq. (VI_saddle), (VIII_element_system), (IX_congruence) | VI, VIII, IX | assemble→scale→constrain→solve | `verify_energy_balance` |

## Scaling layer

| MATLAB file | Function | Master equation | Part | Purpose | Verified by |
|---|---|---|---|---|---|
| `scaling/characteristic_lengths.m` | `characteristic_lengths` | Eq. (III_lelastic, III_fflexo, III_Lambda) | III | ℓ_elastic, f_flexo, Λ | `verify_dimensions` |
| `scaling/nondimensionalize.m` | `nondimensionalize` | Eq. (IX_eps0..IX_U0), (IX_transforms) | IX | reference scales | `verify_dimensions` |
| `scaling/precondition_system.m` | `precondition_system` | Eq. (IX_S, IX_congruence) | IX | S = diag(C₀^−½Iᵤ, κ₀^−½I_φ); K̄ = SKS | `plot_conditioning` |
| `scaling/dof_scaling_vector.m` | `dof_scaling_vector` | Eq. (IX_transforms) | IX | full non-dimensional DOF scaling T = [u₀, u₀/L₀, u₀/L₀, u₀/L₀²]⊕φ₀ | `verify_conditioning`, `conditioning_reconciliation` |
| `scaling/condition_number.m` | `condition_number` | Eq. (X_ratio, X_before, X_after) | X | condest before/after (computed, never claimed) | `plot_conditioning` |

## Verification layer

| MATLAB file | Function | Master equation | Part | Checks |
|---|---|---|---|---|
| `verification/verify_D_voigt.m` | `verify_D_voigt` | Eq. (III_I1..III_I5), (III_Dentries) | III | invariant energy, FD Hessian, symmetry |
| `verification/verify_B_matrices.m` | `verify_B_matrices` | Eq. (VII_hermite_nodal), (VIII_dNx..dNxy) | VII, VIII | cardinality, FD derivatives, epsV/ηV |
| `verification/verify_symmetry.m` | `verify_symmetry` | Eq. (VI_transpose), (VIII_transp_proof) | VI, VIII | K_uu/K_pp symmetry, K_φu = K_uφᵀ |
| `verification/verify_quadrature.m` | `verify_quadrature` | Eq. (VIII_gauss) | VIII | monomial exactness, 4×4 vs 10×10 |
| `verification/verify_dimensions.m` | `verify_dimensions` | Eq. (III_lelastic..III_Lambda) | III | length scales, ℓ_ref distinct |
| `verification/verify_energy_balance.m` | `verify_energy_balance` | Eq. (XVII_Wext..XVII_residual) | XVII | W_ext, U_mech, U_elec, residual |
| `verification/verify_limiting_cases.m` | `verify_limiting_cases` | Part XII (Cases 1..8) | XII | decoupling + residual (D=0 cases structural-only) |
| `verification/verify_randomized_D.m` | `verify_randomized_D` | Eq. (III_I1..III_I5, III_Dentries) | III | 120-seed randomized invariant-energy/symmetry/conjugacy |
| `verification/verify_randomized_strong_form.m` | `verify_randomized_strong_form` | Eq. (IV_PDE1..IV_PDE3) | IV | 60-seed randomized strong-form coefficient regression |
| `verification/verify_BFS_cardinality.m` | `verify_BFS_cardinality` | Eq. (VII_hermite_nodal, VII_bfs) | VII | full 32×32 nodal-cardinality matrix == I |
| `verification/verify_B_fd.m` | `verify_B_fd` | Eq. (VIII_dNx..VIII_dNxy) | VIII | multi-step-size (1e-3..1e-7) FD convergence |
| `verification/verify_quadrature_blocks.m` | `verify_quadrature_blocks` | Eq. (VIII_gauss, VIII_Kuu/Kuphi/Kphiphi) | VIII | all 3 blocks × aspect ratios 1..20 × 4/6/8/10-point |
| `verification/verify_definiteness.m` | `verify_definiteness` | Eq. (VI_saddle) | VI, VIII | rigid-body/gauge null vectors; PSD; saddle indefiniteness |
| `verification/verify_energy_multimesh.m` | `verify_energy_multimesh` | Eq. (XVII_Wext..XVII_residual) | XVII | energy identity on 1-el/2x1/5x1/8x2 meshes |

## Benchmark / study layer

| MATLAB file | Function | Master equation | Part | Notes |
|---|---|---|---|---|
| `benchmarks/benchmark_tier1.m` | `benchmark_tier1` | Eq. (XI_tier1_errors), (XI_rL2..XI_rG) | XI | rates reproduced from supplied norms; optional FEM |
| `benchmarks/benchmark_tier2.m` | `benchmark_tier2` | Eq. (XI_k31_ieee..XI_wtimo), (XI_poisson) | XI | corrected IEEE k₃₁², E_open, w_timo |
| `benchmarks/benchmark_tier3_sensor.m` | `benchmark_tier3_sensor` | Eq. (XI_tier3_fit) | XI | source-reported; optional model V(h) |
| `benchmarks/benchmark_tier3_actuator.m` | `benchmark_tier3_actuator` | Eq. (XI_tier3b) | XI | source-reported; optional model solve |
| `studies/convergence_study.m` | `convergence_study` | Eq. (XI_rL2..XI_rG); Part XIII | XI, XIII | observed rate, documented BCs |
| `studies/hcrit_study.m` | `hcrit_study` | Eq. (XIV_f), (XIV_roots), (XV_fit_ours) | XIV, XV | independent fit A=24.20, p=0.8998 |
| `studies/lambda_study.m` | `lambda_study` | Eq. (III_Lambda) | III | Λ sweep (mu₀ varied) |
| `studies/aspect_ratio_study.m` | `aspect_ratio_study` | Eq. (XVI_def, XVI_fit) | XVI | η_EM vs L/h (this model) |
| `studies/boundary_condition_study.m` | `boundary_condition_study` | Eq. (V_gen_traction..V_charge) | V | 3 documented BC variants |

## Key corrected conventions (carried into the code)

- k₃₁² = d₃₁²/(s₁₁ᴱ ε₃₃ᵀ) = e₃₁²/(E ε₃₃ᵀ) = 0.1511 (Eq. XI_k31_ieee / XI_k31_std);
  the paper's 0.131243 is β² = k₃₁²/(1+k₃₁²) (Eq. XI_beta).
- E_open = E/(1−k₃₁²) = 71.38 GPa (Eq. XI_Eopen_exact); E(1+β²) = 68.5533 GPa is wrong.
- ℓ_elastic = √(D₀/C₀) = 0.2726 nm (material) ≠ ℓ_ref = 1 µm (normalization).
- E = −B_φ q_φ is encoded in the saddle sign convention: the (2,2) block is −K_φφ
  (Eq. VI_saddle), not inside B_φ.
