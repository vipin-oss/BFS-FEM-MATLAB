# MATLAB ↔ MASTER CROSS-AUDIT

Complete first-principles audit of the MATLAB/Octave implementation against the
frozen master calculation `FINAL_COMPLETE_MASTER_CALCULATION.tex`,
`FINAL_CALCULATION_REFERENCES.bib`, and `MASTER_CALCULATION_AUDIT.md`.

> The master calculation is the mathematical authority. Where implementation and
> master agree, the agreement is recorded with the computed difference; where the
> master's raw data are absent, the quantity is marked SOURCE-REPORTED and is
> never fabricated.

**Phase-5 closure revision:** added randomized regression tests
(`verify_randomized_D`, `verify_randomized_strong_form`), the full 32-DOF
cardinality matrix (`verify_BFS_cardinality`), multi-step-size finite-difference
validation (`verify_B_fd`), all-block multi-aspect-ratio quadrature
(`verify_quadrature_blocks`), eigenvalue/null-space characterization
(`verify_definiteness`), multimesh energy identity (`verify_energy_multimesh`),
a shared `fem/gauss_legendre_n.m`, and wired the public scaling/data APIs into
real callers. Full regression: **19/19 PASS**; clean-room execution PASS;
project totals: **72 `.m` files, 112 functions**.

---

## B. CRITICAL LAMBDA DISCREPANCY — RESOLVED

### The premise is not supported by the frozen sources

A full-text search of **all frozen files** (`FINAL_COMPLETE_MASTER_CALCULATION.tex`,
`MASTER_CALCULATION_AUDIT.md`, `FINAL_CALCULATION_REFERENCES.bib`) and of the whole
MATLAB project finds **zero occurrences** of `19.2928` or `19.29`.

The frozen master states, in two independent places:

- Part III, Eq. (III_Lambda):
  Λ = ℓ_elastic/f_flexo = √(D₀/C₀)/(μ₀/√(C₀κ₀)) = √(D₀κ₀)/μ₀,
  *"Numerically: √((1.0×10⁻⁸)(1.106×10⁻⁸))/1.0×10⁻⁶ = 1.05166×10⁻⁸/10⁻⁶ = 1.0517×10⁻²."*
- Part IX, Eq. (IX_lengths): Λ = √(D₀κ₀)/μ₀, [·] = [1].
- Part XVIII summary table: "Λ — 1.0517×10⁻² — derived".

So **the master calculation states Λ = 1.0517×10⁻²**, not 19.2928.

### Independent recomputation (both methods, executed)

| Quantity | Value |
|---|---|
| D₀ = 2(a₄+a₅) | 1.000000000000e-08 N |
| C₀ = C₁₁ | 1.346153846154e+11 Pa |
| κ₀ = κ₂₂ | 1.106000000000e-08 F/m (= 11.06 nF/m) |
| μ₀ = μ₁₁ | 1.000000000000e-06 C/m |
| √(D₀κ₀) | 1.051665346011e-08 C/m |
| ℓ_elastic = √(D₀/C₀) | 2.725541e-10 m = 0.2726 nm |
| f_flexo = μ₀/√(C₀κ₀) | 2.591642e-08 m = 25.9164 nm |
| **Λ (Method 1) = √(D₀κ₀)/μ₀** | **1.051665346011e-02** |
| **Λ (Method 2) = ℓ_elastic/f_flexo** | **1.051665346011e-02** |
| \|Λ₁ − Λ₂\| | 1.735e-18 |

Both methods agree to machine precision; both reproduce the master value 1.0517e-2.

### Exact root cause of the "19.2928" value

Λ = 19.2928 is obtainable from the frozen formula **only if the baseline constants
are replaced**, namely any of:

| Substituted constant | Value that yields Λ = 19.2928 | Frozen baseline |
|---|---|---|
| μ₀ | 5.4511e-10 C/m | 1.0e-6 C/m |
| D₀ | 3.3654e-2 N | 1.0e-8 N |
| ℓ_elastic | 5.0000e-7 m (= 0.5 µm) | 2.7255e-10 m (0.2726 nm) |

The 0.5 µm value is exactly **half of the normalization reference ℓ_ref = 1 µm**,
which suggests the 19.2928 figure came from using a different material length
(≈ ℓ_ref/2, or another material baseline) — **not** from the frozen master.

### Conclusion

- The MATLAB/Octave value **Λ = 1.051665e-2 is CORRECT** and consistent with the
  frozen master. No change was made (changing it to 19.2928 would modify the frozen
  mathematics and contradict the frozen baseline constants).
- The implementation is **not** silently overwritten; the dual-method check is
  now a permanent part of `verify_dimensions.m` (Method 1 vs Method 2, plus the
  printed baseline constants), so any future constant change is caught immediately.

---

## C. MATERIAL-PARAMETER TRACEABILITY

All parameters used by the MATLAB config files are traced to the frozen master
table (Part XI). Status: MATCH = identical to master; DOC = documented assumption;
NEW = unsupported (none present).

| Parameter | MATLAB value | Unit | Master source | Master value | Status |
|---|---|---|---|---|---|
| BaTiO₃ E | 100.0e9 | Pa | Table A | 100.0e9 | MATCH |
| BaTiO₃ ν | 0.30 | 1 | Table A | 0.30 | MATCH |
| C₁₁ | 134.615385e9 | Pa | Eq. XI_C11_BT | 134.615385e9 | MATCH |
| C₁₂ | 57.692308e9 | Pa | Eq. XI_C12_BT | 57.692308e9 | MATCH |
| C₃₃ | 38.461538e9 | Pa | Eq. XI_C33_BT | 38.461538e9 | MATCH |
| κ₁₁, κ₂₂ | 11.06e-9 | F/m | Table A | 11.06e-9 | MATCH |
| μ₁₁ | 1.0e-6 | C/m | Table A | 1.0e-6 | MATCH |
| μ₁₂ | 1.0e-6 | C/m | Table A | 1.0e-6 | MATCH |
| μ₄₄ | 0.0 | C/m | Table A | 0.0 | MATCH |
| a₄ = a₅ | 0.25e-8 | N | Table A | 0.25e-8 | MATCH |
| D₀ = 2(a₄+a₅) | 1.0e-8 | N | Table A | 1.0e-8 | MATCH |
| κ₀, C₀, μ₀ | as above | — | Part III | as above | MATCH |
| ℓ_elastic | 2.7255e-10 | m | Eq. III_lelastic | 0.2726 nm | MATCH |
| f_flexo | 2.5916e-8 | m | Eq. III_fflexo | 25.92 nm | MATCH |
| Λ | 1.051665e-2 | 1 | Eq. III_Lambda | 1.0517e-2 | MATCH |
| ℓ_ref | 1.0e-6 | m | normalization ref (paper ℓ₀) | 1 µm | MATCH (distinct from ℓ_elastic) |
| BaTiO₃ e₃₁,e₃₃,e₁₅ | 0 | C/m² | centrosymmetric (no piezo) | 0 | DOC (master lists no BaTiO₃ piezo) |
| PZT-5H E | 60.6e9 | Pa | Table B | 60.6e9 | MATCH |
| PZT-5H ν | 0.31 | 1 | Table B | 0.31 | MATCH |
| PZT-5H C₁₁,C₁₂,C₃₃ | 83.9976/37.7380/23.1298 GPa | Pa | Eq. XI_C_PZT | same | MATCH |
| PZT-5H e₃₁,e₃₃,e₁₅ | −16.6/+18.6/+12.7 | C/m² | Table B | same | MATCH (flagged D9: only e₃₁= d₃₁E consistent) |
| PZT-5H κ₂₂ (ε₃₃ᵀ) | 30.1e-9 | F/m | Table B | 30.1e-9 | MATCH |
| PZT-5H κ₁₁ | 30.1e-9 | F/m | not in master | — | DOC (set = κ₂₂; 2D FEM only) |
| Shek E, ν | 400e6, 0.49 | Pa, 1 | Table C | same | MATCH |
| Shek μ_shear | 134.228188e6 | Pa | Eq. XI_mu_shear | same | MATCH |
| Shek a₄=a₅ | ½μ_shear·ℓ² | N | Table C | same | MATCH |
| Shek ℓ | 0.1/0.2/0.3 mm | m | Table C | same | MATCH |
| Shek û, t̂ | 5.0e-9 m, 1342.28188 Pa | — | Table C | same | MATCH |

No parameter is silently introduced; the two documented assumptions (BaTiO₃ piezo
= 0 by centrosymmetry; PZT κ₁₁ = κ₂₂ for the optional 2D FEM only) are flagged.

---

## D. CONSTITUTIVE CHAIN (re-verified)

`verify_D_voigt.m` (PASS):
- ½ηᵀDη − W_grad(five invariants) = 1.42e-14 (200 random vectors);
- finite-difference Hessian of W_grad = D_Voigt to 2.2e-16;
- D_Voigt = D_Voigtᵀ to 0; all 18 non-zero entries match Eq. (III_Dentries).

`verify_symmetry.m` (PASS): K_uuᵉ, K_ppᵉ symmetric to 0; K_φuᵉ = (K_uφᵉ)ᵀ to 1.3e-15;
global saddle symmetric to 0.

## E. STRONG FORM (term-by-term, re-derived by matrix algebra)

`verify_strong_form.m` (PASS, max |err| = 1.78e-15): the full i=1 and i=2 double
divergences are expanded **term-by-term** (no symmetry shortcut) from the
h-components hV = D·ηV, giving all ten fourth-order coefficients, which match the
master's closed-form expressions exactly, and all off-block coefficients are
identically zero. All nine Gauss-law coefficients also match.

| Term | Master coefficient | Derived | Status |
|---|---|---|---|
| u_xxxx (PDE1) | 2S = 2(a₁+a₂+a₃+a₄+a₅) | D₁₁ = 2S | PASS |
| u_xxyy (PDE1) = v_xxyy (PDE2) | 2a₁+5/2a₂+2a₃+3a₄+5/2a₅ | 2D₁₆+D₂₂+2D₂₅+D₅₅ | PASS |
| u_yyyy (PDE1) = v_xxxx (PDE2) | a₂/2+a₄+a₅/2 | D₆₆ = D₅₅ | PASS |
| v_xxxy = v_xyyy (PDE1) | 2a₁+3/2a₂+2a₃+a₄+3/2a₅ | D₁₃+D₁₆+D₂₅+D₅₅ | PASS |
| u_xxxy = u_xyyy (PDE2) | 2a₁+3/2a₂+2a₃+a₄+3/2a₅ | D₂₅+D₅₅+D₁₆+D₁₃ | PASS |
| v_yyyy (PDE2) | 2S | D₄₄ | PASS |
| Gauss −κ₁₁φ_xx, −κ₂₂φ_yy | −κ₁₁, −κ₂₂ | −κ₁₁, −κ₂₂ | PASS |
| Gauss (e₁₅+e₃₁)u_xy, e₁₅v_xx, e₃₃v_yy | as written | as written | PASS |
| Gauss μ₁₁u_xxx, (μ₁₂+2μ₄₄)u_xyy/v_xxy, μ₁₁v_yyy | as written | as written | PASS |

## F. BFS ELEMENT (re-verified)

`verify_B_matrices.m` (PASS): BFS nodal cardinality exact (0); physical derivatives
Nx,Ny,Nxx,Nyy,Nxy match finite differences to 5.6e-8 (second-derivative steps use
h=1e-4 to avoid cancellation; documented); B_e·q_u = epsV and B_η·q_u = ηV to
8.9e-16; B_φ matches the analytic bilinear-Lagrange gradient to 0.
Dimensions: B_e 3×32, B_η 6×32, B_φ 2×4. DOF order
[u,u_x,u_y,u_xy,v,v_x,v_y,v_xy] per node.

## G/H. ELEMENT MATRICES & QUADRATURE (re-verified)

`verify_symmetry.m`: K_uuᵉ (32×32), K_ppᵉ (4×4) symmetric; K_φuᵉ = K_uφᵉᵀ.
Positive semidefiniteness is NOT claimed: rigid-body modes (translation, rotation)
are genuine zero-energy modes, constrained by the clamp (verified: u=const gives
qᵀKq ≈ 0 on a free element).
`verify_quadrature.m` (PASS): monomials p,q≤7 exact to 8.9e-16; the 4×4 vs 10×10
strain-gradient stiffness comparison gives max |err| = 2.3e-13, Frobenius relative
error 5.3e-16. The binding per-variable degree 6 (from cubic-Hermite tensor
products) is ≤ 2·4−1 = 7, so 4×4 is exact (not merely "stated").

## I. ENERGY FORMULATION — RESOLVED (no unexplained factor 2)

Derived from the frozen enthalpy H = ½εᵀCε + ½ηᵀDη − ½(∇φ)ᵀκ∇φ + (∇φ)ᵀeε + (∇φ)ᵀμη
and the saddle system, in `verify_energy_balance.m`:

- Stored internal energy U_int = U_mech − U_elec + U_coup, with
  U_mech = ½q_uᵀK_uu q_u, U_elec = ½q_φᵀK_pp q_φ, U_coup = q_uᵀK_up q_φ.
- Total potential Π = U_int − Fᵀq_u + Qᵀq_φ; stationarity reproduces the saddle
  system exactly.
- Euler's homogeneous-function theorem on the quadratic U_int:
  **P = Fᵀq_u − Qᵀq_φ = 2 U_int**  (dead-load product).
- Open circuit: the equilibrium row K_upᵀq_u = K_pp q_φ gives
  **U_coup = 2 U_elec**, hence **U_int = U_mech + U_elec**.
- Therefore the exact first-law statement is
  **P = 2(U_mech + U_elec)**, equivalently **W_qs = ½P = U_mech + U_elec**,
  where W_qs is the quasi-static (proportional-loading) work.

Numerically (8×2 BaTiO₃ cantilever, F = 1 nN, open circuit):
U_mech = 1.2829e-25 J, U_elec = 2.2221e-27 J, U_coup = 4.4442e-27 J,
U_int = 1.3051e-25 J, P = 2.6103e-25 J, W_qs = 1.3051e-25 J.
Identities: I1 (P−2U_int) = −3.96e-36; I2 (U_coup−2U_elec) = 9.8e-41;
I3 (U_int−(U_mech+U_elec)) = 1.1e-40; master balance |W_qs−(U_mech+U_elec)|/|W_qs|
= 1.515e-11 (PASS).

**Conclusion:** the master's Part-XVII identity W_ext = U_mech + U_elec is exact with
W_ext = ½P (quasi-static work); the dead-load product P = Fᵀq is 2× the stored
energy. The factor ½ belongs to the quadratic energy/work identity and is now
derived, not assumed.

## J. CONDITIONING RECONCILIATION (RESOLVED — see CONDITIONING_RECONCILIATION_REPORT.md)

**Exact cause.** The frozen master's non-dimensionalization (Part IX,
Eq. IX_transforms: x̄ = x/L₀, ū = u/u₀, φ̄ = φ/φ₀) implies a derivative-DOF
scaling — the BFS DOFs [u, u_x, u_y, u_xy] carry different units ([m],[1],[1],
[1/m]) — giving the symmetric congruence K̄ = diag(T) K diag(T) with
T = [u₀, u₀/L₀, u₀/L₀, u₀/L₀²](per mech node) ⊕ φ₀(per elec node). The Phase-3
implementation applied only the electromechanical S = diag(C₀⁻½, κ₀⁻½) and omitted
T_q, so the raw K retained the twist-DOF h⁻⁴ unit disparity → 10³³ on thin meshes.

**Four measured studies (BaTiO₃ beam, L = 2 µm, square elements):**

| Study | cond Nx=4 | Nx=8 | Nx=16 | Nx=32 | p (A·Nx^p) |
|---|---|---|---|---|---|
| A raw | 4.7e29 | 8.1e30 | 3.3e32 | 4.6e34 | 5.51 |
| B electromechanical S | 5.1e29 | 8.7e30 | 4.6e32 | 1.1e35 | 5.90 |
| C DOF scaling T_q | 1.2e21 | 3.1e21 | 8.0e21 | 2.7e22 | 1.49 |
| D combined | 7.6e6 | 1.3e8 | 2.1e9 | 1.0e11 | 4.52 |

**Conclusion.** Study D (the mathematically complete scaling) gives cond
7.6e6–1.0e11 over Nx = 4–32, reproducing the master's "~10⁶–10⁷" order of
magnitude at coarse meshes with the expected Nx⁴ (bilaplacian) growth; the
exact figure is mesh/material-dependent (as the master itself states). Physics
invariance after scaling verified to 2.7e-13 (u) / 4.2e-13 (φ). No scaling
constants were tuned. Implemented as `scaling/dof_scaling_vector.m`,
`solve_system.m` (`opts.use_dof_scaling`), `verification/verify_conditioning.m`,
`studies/conditioning_reconciliation.m`.

## J-bis. TIER-3b ACTUATOR AUDIT (Phase-5 forensic)

| Quantity | Reference (source-reported) | Master reduced model (computed) | Classical full tensor |
|---|---|---|---|
| w_tip (nanobeam L=2um, h=100nm, V0=1V, mu=1e-6) | 307.37 pm | **89.1 nm (corner-moment M=(mu12+2mu44)V0/2)** | 178.3 nm |
| w_tip (Ghasemi geom L=60um, h=8.57um) | — | — | 254.8 pm (~307 pm) |

The 297x discrepancy is explained by TWO causes: (i) the original
electromechanical-only scaling made the twist DOFs numerically singular
(rcond~1e-17) so the solve was non-converged; (ii) the master's REDUCED
flexoelectric tensor omits the transverse bending coupling mu_2112 = mu_T - mu_S,
so the master model cannot produce classical flexoelectric bending — its
uniform-field actuation is the corner-moment mechanism giving ~89 nm, which the
well-conditioned FEM reproduces to 2-5%. The 307 pm reference is the classical
transverse flexo bending of a ~60 um beam (Ghasemi geometry). STRUCTURALLY
COMPARABLE ONLY; the frozen master model was not modified.

## K. LIMITING CASES (re-derived)

`verify_limiting_cases.m`: all eight cases with a documented synthetic
fully-coupled test material (BaTiO₃ flexo + PZT-5H piezo constants grafted, because
BaTiO₃ is centrosymmetric). Decoupling check (‖K_uφ‖ = 0 ⟺ e=μ=0) passes 8/8. Solved
cases (D≠0 or flexo active) give quasi-static energy residuals 1.5e-11…9.4e-2 (the
large 9.4e-2 for the D=0 piezo/flexo cases reflects the twist-DOF conditioning on the
thin beam, documented). Cases 1,4 (D=0, no flexo) are structurally checked only.
The paper's table values (0.7052, 27.1340, …) are SOURCE-REPORTED.

## L/M. TIER-1, TIER-2 (reproduced)

- Tier-1 (from the quoted norms e₁,e₂): r_L2 = 3.9998, r_H1 = 2.9963, r_G = 1.9995
  → reproduce the paper's 4.00 / 2.99 / 2.00.
- Tier-2 (IEEE convention, derived, not hard-coded): k₃₁² = e₃₁²/(E ε₃₃ᵀ) = 0.151070
  (k₃₁ = 0.3887); β² = 0.131243 (paper value, renamed); E_open = E/(1−k₃₁²) =
  71.3839 GPa; w_bend = 5.6035e-14 m, w_shear = 4.4044e-16 m, w_timo = 5.6475e-14 m
  (paper's 5.886754e-14 m is 4.24 % higher because it used the wrong E_open);
  1−ν² = 0.9039.

## N/O/P. TIER-3, h_crit, Λ STUDY

- Tier-3 sensor/actuator: raw dataset absent → `load_master_dataset.m` prints
  DATA REQUIRED with the exact 16-variable list; model solve remains executable for
  user-supplied (h,V) inputs.
- h_crit: independent fit on the four quoted roots A = 24.2011, p = 0.8998,
  R² = 0.999840; the paper's A = 23.76, p = 0.90 kept separately as SOURCE-REPORTED.
- Λ study: baseline Λ = 1.051665e-2 (mu₀ = 1e-6 C/m); sweep varies μ₀ only
  (documented) with C₀, D₀, κ₀ fixed.

---

## S. COMPLETE AUTOMATED CROSS-AUDIT TABLE

| ID | Quantity | Master value | MATLAB (code) | Octave (computed) | Diff | Source eq | Status |
|---|---|---|---|---|---|---|---|
| 1 | C₁₁ (BaTiO₃) | 134.615385 GPa | 134.615385e9 | 1.3462e11 | 0 | XI_C11_BT | MATCH |
| 2 | C₁₂ (BaTiO₃) | 57.692308 GPa | 57.692308e9 | 5.7692e10 | 0 | XI_C12_BT | MATCH |
| 3 | C₃₃ (BaTiO₃) | 38.461538 GPa | 38.461538e9 | 3.8462e10 | 0 | XI_C33_BT | MATCH |
| 4 | D₀ | 1.0e-8 N | 1.0e-8 | 1.0e-8 | 0 | Table A | MATCH |
| 5 | κ₀ | 11.06e-9 F/m | 11.06e-9 | 1.106e-8 | 0 | Table A | MATCH |
| 6 | μ₀ | 1.0e-6 C/m | 1.0e-6 | 1.0e-6 | 0 | Table A | MATCH |
| 7 | ℓ_elastic | 0.2726 nm | — | 0.27255 nm | 1.4e-4 | III_lelastic | MATCH |
| 8 | f_flexo | 25.92 nm | — | 25.916 nm | 1.5e-4 | III_fflexo | MATCH |
| 9 | **Λ** | **1.0517e-2** | **1.051665e-2** | **1.051665e-2** | **1.9e-4** | III_Lambda | **MATCH (19.2928 not in master)** |
| 10 | k₃₁² | 0.1511 | — | 0.151070 | 2e-4 | XI_k31_result | MATCH |
| 11 | β² (paper 0.131243) | 0.131243 | — | 0.131243 | 0 | XI_beta | MATCH (renamed) |
| 12 | E_open | 71.38 GPa | — | 71.3839 GPa | 5e-5 | XI_Eopen_exact | MATCH |
| 13 | w_timo | 5.6475e-14 m | — | 5.6475e-14 m | 0 | XI_wtimo | MATCH |
| 14 | r_L2 | 4.00 | — | 3.9998 | 5e-5 | XI_rL2 | MATCH |
| 15 | r_H1 | 2.99 | — | 2.9963 | 2e-3 | XI_rH1 | MATCH |
| 16 | r_G | 2.00 | — | 1.9995 | 3e-4 | XI_rG | MATCH |
| 17 | h_crit roots | 6.9353/12.9840/18.8471/24.0201 µm | quoted | quoted | 0 | XIV_roots | SOURCE-REPORTED |
| 18 | h_crit fit | A=24.20, p=0.8998 | — | A=24.2011, p=0.8998 | 5e-5 | XV_fit_ours | MATCH |
| 19 | h_crit paper fit | A=23.76, p=0.90 | kept separate | printed | — | XV_paper_fit | SOURCE-REPORTED |
| 20 | energy residual | ≤2.87e-9 | — | 1.515e-11 (computed) | — | XVII_bound | COMPUTED (paper bound source-reported) |
| 21 | condition numbers | 1e22→1e6 (paper) | full T scaling | raw 4.7e29 (Nx=4) → combined 7.6e6 (Nx=4) | — | X_before/after | RESOLVED: combined scaling reproduces 10⁶–10⁷ order (see §J) |
| 22 | quadrature error | degree-6 exact | — | 2.3e-13 (4×4 vs 10×10) | — | VIII_gauss | MATCH |
| 23 | K_φu = K_uφᵀ | exact | — | 1.3e-15 | — | VI_transpose | MATCH |

---

## T. CODE-QUALITY CLASSIFICATION OF FLAGGED PATTERNS

| Occurrence | Classification |
|---|---|
| `68.5533` (E_open paper value) | VALID — appears only as the documented WRONG value in comments/prints |
| `0.131243` | VALID — appears only as β² (renamed), never as k₃₁² |
| `1.05e-2` / `1.0517e-2` (Λ) | VALID — the CORRECT master value (not stale) |
| `19.2928` | ABSENT — nowhere in the project |
| `5.886754e-14` (paper w_timo) | VALID — only as the documented paper value in comparisons |
| `69.7548` | REMOVED — the superseded first-order E_open is absent from executable code |
| `placeholder` (PZT μ₀) | VALID/DOCUMENTATION — PZT has μ=0, Λ undefined; explicit comment |
| `expected`, `assumed` | VALID — used only in verification tolerances and documented-BC cautions |
| TODO/FIXME | ABSENT from executable code (only audit prose) |

## R. MATLAB vs OCTAVE (honest statement)

- **MATLAB was not available**; all execution was performed with **GNU Octave 9.4.0**.
- The code is written in MATLAB syntax (function files, sparse matrices, `condest`,
  `fzero`, `eigs`, `print -dpdf/-depsc`, `jsondecode`) and all 59 files parse
  cleanly; plotting scripts additionally syntax-checked. **"Runs identically in
  MATLAB" is NOT claimed as verified** — it is a compatibility expectation only.

---

## A. DEPENDENCY MAP

```
main.m
 ├─ verification/  (verify_D_voigt, verify_B_matrices, verify_symmetry,
 │                  verify_quadrature, verify_strong_form, verify_dimensions,
 │                  verify_energy_balance, verify_limiting_cases)
 │     └─ constitutive/ (constitutive_C, constitutive_D, piezoelectric_e,
 │                       flexoelectric_mu, dielectric_kappa)
 │     └─ fem/          (hermite_cubic, bfs_shape_functions,
 │                       bfs_shape_derivatives, B_e/B_eta/B_phi_matrix,
 │                       gauss_legendre_4x4, element_stiffness/coupling/electrical,
 │                       generate_mesh, assembly, apply_boundary_conditions,
 │                       solve_system, make_cantilever_bc, apply_tip_load)
 │     └─ scaling/      (characteristic_lengths, nondimensionalize,
 │                       precondition_system, condition_number)
 │     └─ config/       (simulation_parameters, material_BaTiO3/PZT5H/Shekarchizadeh)
 ├─ benchmarks/ (benchmark_tier1/tier2/tier3_sensor/tier3_actuator)
 │     └─ (same fem/constitutive/scaling/config)
 ├─ studies/    (convergence_study, hcrit_study, lambda_study,
 │               aspect_ratio_study, boundary_condition_study)
 │     └─ (same) + export_table.m
 ├─ data/       (load_master_dataset — DATA REQUIRED path)
 └─ plotting/   (fig_defaults, export_plot, plot_*)  → loads output/*.csv
```

Every `.m` function carries a header citing its master source (Part/Eq.); the full
file/function → master-equation map is in `MATLAB_EQUATION_TRACEABILITY.md`.
