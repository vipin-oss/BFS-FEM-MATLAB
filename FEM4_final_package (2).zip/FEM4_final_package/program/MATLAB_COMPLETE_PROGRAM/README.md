# MATLAB Complete Program — Coupled Piezoelectric–Flexoelectric BFS FEM

Complete, executable MATLAB implementation of the 36-DOF conforming C¹
Bogner–Fox–Schmit finite element model for coupled piezoelectric–flexoelectric
continuum media with Mindlin Form-II strain-gradient elasticity.

**Mathematical authority (frozen):**
- `FINAL_COMPLETE_MASTER_CALCULATION.tex` (the closed master calculation)
- `FINAL_CALCULATION_REFERENCES.bib`
- `MASTER_CALCULATION_AUDIT.md`

No mathematics is modified here. Where the master does not provide the raw
data needed to reproduce a number, this project marks it
**DATA REQUIRED / SOURCE-REPORTED** and never fabricates it.

---

## 1. Project layout

```
MATLAB_COMPLETE_PROGRAM/
├── main.m                        entry point (verification + analytic benchmarks)
├── README.md                     this file
├── MATLAB_EQUATION_TRACEABILITY.md   file/function → master-equation map
├── MATLAB_IMPLEMENTATION_AUDIT.md    implementation audit report
├── export_table.m                CSV writer with headers/units
├── config/                       material + simulation parameters
│   ├── simulation_parameters.m
│   ├── material_BaTiO3.m
│   ├── material_PZT5H.m
│   └── material_Shekarchizadeh.m
├── constitutive/                 C, D_Voigt, e_V, mu_V, kappa
├── fem/                          BFS element, B matrices, assembly, solver
├── scaling/                      length scales, non-dimensionalization, conditioning
├── verification/                 PASS/FAIL numerical checks
├── benchmarks/                   Tier 1, 2, 3 (sensor), 3b (actuator)
├── studies/                      convergence, h_crit, Lambda, aspect ratio, BCs
├── plotting/                     publication-format figure scripts
├── data/                         (raw datasets, if supplied — currently empty)
└── output/                       CSV/MAT/PDF/EPS exports (created on run)
```

## 2. First run (MATLAB)

```matlab
cd MATLAB_COMPLETE_PROGRAM
main
```

`main` adds the project folders to the path, runs the seven verification
scripts and the analytic benchmark parts. Expect every verification line to
print **PASS**.

## 3. Verification suite (all PASS/FAIL with tolerances)

| Script | Checks |
|---|---|
| `verify_D_voigt.m` | ½ηᵀDη vs five-invariant energy; FD Hessian; symmetry |
| `verify_B_matrices.m` | BFS nodal cardinality; derivatives vs FD; B_e/B_η/B_φ |
| `verify_symmetry.m` | K_uu/K_pp symmetry; K_φu = K_uφᵀ; saddle symmetry |
| `verify_quadrature.m` | monomial exactness p,q≤7; 4×4 vs 10×10 reference |
| `verify_strong_form.m` | term-by-term PDE1/PDE2/Gauss coefficient reconstruction |
| `verify_dimensions.m` | ℓ_elastic = 0.2726 nm, f_flexo = 25.92 nm, Λ = 1.0517e-2 (dual method) |
| `verify_energy_balance.m` | W_ext, U_mech, U_elec + 4 derived energy identities |
| `verify_limiting_cases.m` | 8 cases: decoupling + energy residual |
| `verify_conditioning.m` | congruence symmetry, physics invariance, cond reduction |
| `verify_randomized_D.m` | 120 fixed-seed random moduli/eta vectors (invariant energy, symmetry, conjugacy) |
| `verify_randomized_strong_form.m` | 60 fixed-seed random material sets (all PDE/Gauss coefficients) |
| `verify_BFS_cardinality.m` | full 32×32 nodal-cardinality matrix == identity |
| `verify_B_fd.m` | multi-step-size (1e-3..1e-7) finite-difference convergence of B-matrix derivatives |
| `verify_quadrature_blocks.m` | all 3 element blocks × aspect ratios 1..20 × 4x4 vs 10x10 Gauss |
| `verify_definiteness.m` | rigid-body/gauge null vectors; PSD; saddle indefiniteness; spectrum span |
| `verify_energy_multimesh.m` | energy identity on 1-element, 2x1, 5x1, 8x2 meshes |

`run_full_scientific_regression.m` runs all **19** checks at once (PASS/FAIL).
`studies/conditioning_reconciliation.m` produces the four conditioning
studies (A raw / B electromechanical / C DOF / D combined), the thin-mesh
asymptotics, and the physics-invariance proof — see
`CONDITIONING_RECONCILIATION_REPORT.md` for the full reconciliation of the
master's 10⁶–10⁷ vs the thin-mesh 10³³.

## 4. Benchmarks

```matlab
benchmark_tier1(false)        % reproduce quoted Tier-1 rates (supplied norms)
benchmark_tier1(true)         % + independent FEM (documented BCs)
benchmark_tier2(false)        % corrected PZT-5H analytic chain
benchmark_tier2(true)         % + 2D BFS FEM comparison
benchmark_tier3_sensor()      % data-required report (+ optional h list)
benchmark_tier3_sensor([100e-9 200e-9 500e-9 1e-6 2e-6])   % model V(h)
benchmark_tier3_actuator(1.0)
```

Key corrected values (see master, Part XI / Appendix D):
- k₃₁² = d₃₁²/(s₁₁ᴱ ε₃₃ᵀ) = e₃₁²/(E ε₃₃ᵀ) = **0.1511** (k₃₁ = 0.39);
- β² = k₃₁²/(1+k₃₁²) = 0.131243 (the paper's value, renamed — NOT k₃₁²);
- E_open = E/(1−k₃₁²) = **71.38 GPa** (the old 68.5533 GPa is wrong);
- w_timo = **5.6475e-14 m**.

## 5. Studies (each exports CSV + MAT to `output/`)

```matlab
convergence_study()          % observed BFS convergence (documented BCs)
hcrit_study(false)           % independent fit on the 4 quoted roots
hcrit_study(true)            % + FEM fzero machinery (slow)
lambda_study()               % Λ sweep (mu₀ varied, documented)
aspect_ratio_study()         % η_EM vs L/h (this model; paper fit is source-reported)
boundary_condition_study()   % 3 BC variants
```

## 6. Plotting (run after the corresponding study)

```matlab
plot_convergence, plot_sensor_scaling, plot_actuator_response,
plot_hcrit, plot_lambda_response, plot_energy_conversion,
plot_conditioning, plot_boundary_conditions, plot_mesh_convergence
```

Figures use Times New Roman, 22 pt labels, 2.5 pt lines, and export PDF+EPS
to `output/`. Scripts error (never fabricate) if the underlying CSV is absent.

## 7. Documented limitations (honest, from the master)

1. **`section6_master_dataset.json` is not supplied.** Tier-3 (h,V) sensor
   data, actuator reference deflections, per-mesh convergence tables,
   condition-number tables, the η_EM sweep and the energy-partition table are
   **source-reported**. The code detects the missing file and prints
   DATA REQUIRED.
2. **h_crit regression.** Only the four quoted roots are available; the
   independent fit is A = 24.20, p = 0.8998, R² = 0.99984. The paper's
   A = 23.76, p = 0.90 used additional (unavailable) data and is kept
   separately as source-reported.
3. **Conditioning (reconciled).** The raw BFS system is ill-conditioned on
   thin meshes (~10³³) because the twist (u_xy) DOFs carry units of [1/m]
   while value DOFs carry [m]. The mathematically complete scaling is the
   symmetric congruence K̄ = diag(T) K diag(T) with T = [1, 1/L₀, 1/L₀,
   1/L₀²] (per mech node) ⊕ √(C₀/κ₀) (per elec node), derived from the
   master's non-dimensionalization (Part IX, Eq. IX_transforms) — implemented
   as `scaling/dof_scaling_vector.m` and `solve_system(...,'use_dof_scaling',true)`.
   After this scaling the condition number is 7.6e6 (Nx=4) … 1.0e11 (Nx=32),
   reproducing the master's "10⁶–10⁷" order of magnitude with the expected
   Nx⁴ (bilaplacian) growth; physics is invariant (verified to 2.7e-13).
   See `CONDITIONING_RECONCILIATION_REPORT.md`.
4. **Energy identity (derived, not assumed).** Dead-load product P = Fᵀq =
   2 U_int (Euler's theorem); open-circuit U_coup = 2 U_elec, hence
   U_int = U_mech + U_elec and the master's W_ext = U_mech + U_elec holds for
   the quasi-static work ½Fᵀq. All four identities are verified in
   `verify_energy_balance.m`.
5. **Λ baseline.** Λ = √(D₀κ₀)/μ₀ = 1.0517e-2 from D₀ = 1e-8 N,
   κ₀ = 11.06 nF/m, μ₀ = 1e-6 C/m (the frozen master value; a figure 19.2928
   appears nowhere in the frozen sources — see `MATLAB_MASTER_CROSS_AUDIT.md` §B).
