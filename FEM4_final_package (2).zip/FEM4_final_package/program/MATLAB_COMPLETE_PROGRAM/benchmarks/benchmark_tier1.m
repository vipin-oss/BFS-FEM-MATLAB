function results = benchmark_tier1(do_fem)
% BENCHMARK_TIER1  Shekarchizadeh (2022) strain-gradient simple-shear
% convergence benchmark.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part XI, Eq. (XI_tier1_errors, XI_rL2, XI_rH1, XI_rG);
%   Part XI, Table (material inventory, set C), Eq. (XI_mu_shear).
%
% PART A (REPRODUCED FROM SUPPLIED VALUES): the paper's quoted error norms
% e1, e2 for the 24x8 -> 48x16 mesh halving are used to recompute the rates
%   r = ln(e1/e2)/ln(h1/h2), h1/h2 = 2.
% PART B (optional, do_fem = true): an independent BFS FEM solution of the
% simple-shear plate (Case 1: prescribed top displacement uhat) is run on
% 12x4 / 24x8 / 48x16 meshes and an OBSERVED convergence rate is computed
% against the finest mesh as reference. The exact boundary-condition set is
% NOT specified in the master; the documented assumption here is:
%   bottom edge fully clamped; top edge u = uhat, v = 0; sides free.
% This independent rate is clearly labelled as computed under these
% documented assumptions and is NOT claimed to reproduce the paper's setup.
if nargin < 1, do_fem = false; end
p = simulation_parameters();
fprintf('=== TIER 1: Shekarchizadeh (2022) strain-gradient convergence ===\n');

% ---- PART A: reproduce the quoted rates ----
e1 = [4.7610e-6, 4.2180e-5, 1.6290e-3];   % L2, H1, G at 24x8
e2 = [2.9760e-7, 5.2860e-6, 4.0740e-4];   % L2, H1, G at 48x16
names = {'L2','H1','G'};
results.r = zeros(3,1);
for k = 1:3
    results.r(k) = log(e1(k)/e2(k))/log(2);
    fprintf('  r_%s = ln(%.4e/%.4e)/ln2 = %.4f   (paper: 4.00/2.99/2.00)\n', ...
        names{k}, e1(k), e2(k), results.r(k));
end
fprintf(['  NOTE: rates above are REPRODUCED FROM SUPPLIED error norms ' ...
         '(raw FEM error data absent).\n']);
% regression gate: rates match the paper's 4.00 / 2.99 / 2.00 within 1 %.
results.all_pass = abs(results.r(1)-4.00)/4.00 < 1e-2 && ...
                   abs(results.r(2)-2.99)/2.99 < 1e-2 && ...
                   abs(results.r(3)-2.00)/2.00 < 1e-2;

% ---- PART B: independent FEM (optional) ----
results.fem_r = nan(3,1);
if do_fem
    ell = 0.3e-3;
    mat = material_Shekarchizadeh(ell);
    meshes = {[12 4], [24 8], [48 16]};
    tip = zeros(1,3);
    for mi = 1:3
        mesh = generate_mesh(meshes{mi}(1), meshes{mi}(2), mat.L, mat.H);
        tip(mi) = simple_shear_u(mesh, mat, mat.uhat);
        fprintf('  FEM mesh %2dx%-2d : top-u displacement field solved (sample tip value %.6e)\n', ...
            meshes{mi}(1), meshes{mi}(2), tip(mi));
    end
    % observed rate using finest mesh as reference (Richardson)
    results.fem_r = [log(abs(tip(1)-tip(3))/abs(tip(2)-tip(3)))/log(2); 0; 0];
    fprintf('  Independent observed rate (L2-proxy, finest-mesh reference, documented BCs): %.4f\n', results.fem_r(1));
    fprintf('  CAUTION: this rate uses assumed BCs; the paper quoted rates are Part A only.\n');
end
fprintf('=== TIER 1 done ===\n\n');
end

function tip = simple_shear_u(mesh, mat, uhat)
% documented BC assumption: bottom fully clamped, top u=uhat (v=0), sides free
nnode = mesh.nnode; nmech = 8*nnode;
dof = []; val = [];
% bottom edge y = 0: all 8 DOFs = 0
bott = find(abs(mesh.coords(:,2)) < 1e-15);
for n = bott'
    dof = [dof, 8*(n-1)+(1:8)]; val = [val, zeros(1,8)];
end
% top edge y = H: u = uhat (comp 1), v = 0 (comp 5)
top = find(abs(mesh.coords(:,2) - mesh.Ly) < 1e-15);
for n = top'
    dof = [dof, 8*(n-1)+1, 8*(n-1)+5]; val = [val, uhat, 0];
end
bc.dof = dof(:); bc.val = val(:);
opts.loads = struct('F', zeros(nmech,1), 'Q', []);
opts.bc = bc; opts.use_dof_scaling = true; opts.electrical = false;
out = solve_system(mesh, mat, opts);
% measure a FREE DOF: u at the right-edge mid-height node
right = find(abs(mesh.coords(:,1)-mesh.Lx) < 1e-15);
[~, mid] = min(abs(mesh.coords(right,2) - mesh.Ly/2));
tip = out.q_u(8*(right(mid)-1)+1);
end
