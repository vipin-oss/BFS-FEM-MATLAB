function results = benchmark_tier2(do_fem)
% BENCHMARK_TIER2  PZT-5H piezoelectric cantilever (corrected benchmark).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part XI, Eq. (XI_k31_ieee, XI_k31_std, XI_k31_result) IEEE convention;
%   Eq. (XI_beta) reduced fraction beta^2 (paper's 0.131243, renamed);
%   Eq. (XI_Eopen_exact) E_open = E/(1-k31^2);
%   Eq. (XI_wbend, XI_wshear, XI_wtimo) Timoshenko deflection;
%   Eq. (XI_poisson) 1-nu^2 = 0.9039.
%
% Convention (resolved in the master): k31^2 = d31^2/(s11^E eps33^T)
% = e31^2/(E eps33^T) = 0.1511 (k31 = 0.39). The paper's 0.131243 is the
% reduced fraction beta^2 = k31^2/(1+k31^2) and is NOT called k31^2.
% The old value 68.5533 GPa (= E(1+beta^2)) is NOT the open-circuit
% modulus; the exact value is E/(1-k31^2) = 71.38 GPa.
if nargin < 1, do_fem = false; end
mat = material_PZT5H();
E = mat.E; nu = mat.nu;
e31 = abs(mat.e31);            % magnitude enters k31^2
eps33T = mat.kappa22;          % free permittivity epsilon_33^T
L = mat.L_beam; h = mat.h_beam; b = mat.b_beam; F = mat.F_beam;

fprintf('=== TIER 2: PZT-5H piezoelectric cantilever (IEEE k31 convention) ===\n');
% ---- coupling factor ----
k31sq = e31^2/(E*eps33T);
k31   = sqrt(k31sq);
beta2 = k31sq/(1+k31sq);       % the paper's 0.131243, renamed beta^2
fprintf('  e31 = %.2f C/m^2 (magnitude), E = %.1f GPa, eps33^T = %.3e F/m\n', e31, E/1e9, eps33T);
fprintf('  k31^2 = e31^2/(E eps33^T) = %.2f/(%.2f) = %.6f   (k31 = %.4f, lit 0.39)\n', ...
    e31^2, E*eps33T, k31sq, k31);
fprintf('  beta^2 = k31^2/(1+k31^2) = %.6f  (paper value 0.131243, renamed; NOT k31^2)\n', beta2);

% ---- open-circuit modulus ----
E_open = E/(1-k31sq);
fprintf('  E_open = E/(1-k31^2) = %.1f/%.6f = %.4f GPa   (old 68.5533 GPa is E(1+beta^2), WRONG)\n', ...
    E/1e9, 1-k31sq, E_open/1e9);

% ---- Timoshenko deflection ----
I = b*h^3/12;
w_bend = F*L^3/(3*E_open*I);
G = E_open/(2*(1+nu)); ks = 5/6; A = b*h;
w_shear = F*L/(ks*G*A);
w_timo = w_bend + w_shear;
fprintf('  I = b h^3/12 = %.4e m^4\n', I);
fprintf('  w_bend  = FL^3/(3 E_open I) = %.4e m\n', w_bend);
fprintf('  w_shear = FL/(ks G A)        = %.4e m   (ks = 5/6)\n', w_shear);
fprintf('  w_timo  = %.4e m  (paper 5.886754e-14 m -> %.2f%% higher, uses wrong E_open)\n', ...
    w_timo, (5.886754e-14 - w_timo)/w_timo*100);

% ---- Poisson restraint ----
pois = 1 - nu^2;
fprintf('  1 - nu^2 = %.4f\n', pois);

results.k31sq = k31sq; results.k31 = k31; results.beta2 = beta2;
results.E_open = E_open; results.w_bend = w_bend; results.w_shear = w_shear;
results.w_timo = w_timo; results.poisson = pois;
% regression gate: corrected values must match the master within 0.1 % rel.
tolr = 1e-3;
results.all_pass = abs(k31sq-0.151070)/0.151070 < tolr && ...
                   abs(beta2-0.131243)/0.131243 < tolr && ...
                   abs(E_open-71.3839e9)/71.3839e9 < tolr && ...
                   abs(w_timo-5.6475e-14)/5.6475e-14 < tolr && ...
                   abs(pois-0.9039)/0.9039 < tolr;

% ---- optional 2D BFS FEM comparison ----
results.fem_tip = nan;
if do_fem
    fprintf('  --- 2D BFS FEM (plane strain, documented twist-DOF constraint) ---\n');
    p = simulation_parameters();
    mesh = generate_mesh(p.mesh_tier2(1), p.mesh_tier2(2), L, h);
    nnode = mesh.nnode; nmech = 8*nnode;
    % clamp left edge + constrain twist DOFs (u_xy comp 4, v_xy comp 8) for
    % the second-order (D=0) piezo problem (documented; see audit)
    dof = []; val = [];
    left = find(abs(mesh.coords(:,1)) < 1e-15);
    for n = left'
        dof = [dof, 8*(n-1)+(1:8)]; val = [val, zeros(1,8)];
    end
    for n = 1:nnode
        dof = [dof, 8*(n-1)+4, 8*(n-1)+8]; val = [val, 0, 0];
    end
    dof = [dof, nmech + 1]; val = [val, 0];   % ground phi at node 1
    % deduplicate (left-edge twist DOFs are already clamped)
    [dof, ia] = unique(dof(:)); val = val(ia);
    bc.dof = dof(:); bc.val = val(:);
    Fvec = apply_tip_load(mesh, F, 'v');
    opts.loads = struct('F', Fvec, 'Q', []);
    opts.bc = bc; opts.use_dof_scaling = true; opts.electrical = true;
    out = solve_system(mesh, mat, opts);
    % tip deflection: v at the mid-height node of the right edge
    right = find(abs(mesh.coords(:,1) - L) < 1e-15);
    [~, mid] = min(abs(mesh.coords(right,2) - h/2));
    tipnode = right(mid);
    results.fem_tip = out.q_u(8*(tipnode-1)+5);
    fprintf('  FEM tip deflection (mesh %dx%d) = %.4e m  vs analytic w_timo = %.4e m\n', ...
        p.mesh_tier2(1), p.mesh_tier2(2), results.fem_tip, w_timo);
    fprintf('  NOTE: paper quotes 1.49%% 2D-vs-1D deviation at L/h=100 (source-reported; raw FEM data absent).\n');
end
% ---- CSV/MAT export (direct export of the COMPUTED values) ----
if ~exist('output','dir'), mkdir('output'); end
export_table(fullfile('output','tier2_benchmark.csv'), ...
    {'k31sq','k31','beta2','E_open_GPa','w_bend_m','w_shear_m','w_timo_m','poisson','fem_tip_m'}, ...
    [k31sq, k31, beta2, E_open/1e9, w_bend, w_shear, w_timo, pois, results.fem_tip], ...
    {'','','','GPa','m','m','m','','m'});
save(fullfile('output','tier2_benchmark.mat'), 'results');
fprintf('  exported output/tier2_benchmark.csv and .mat\n');
fprintf('=== TIER 2 done ===\n\n');
end
