function results = benchmark_tier3_sensor(h_list)
% BENCHMARK_TIER3_SENSOR  Abdollahi flexoelectric sensor (open circuit).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part XI, Eq. (XI_tier3_fit): V_ind ~ h^(-1.0002), R^2 = 0.9999
%   (h >= 500 nm), with self-stiffening saturation below 100 nm.
%
% DATA STATUS: the raw (h, V) dataset (section6_master_dataset.json) is
% NOT supplied. The quoted regression is therefore SOURCE-REPORTED and is
% printed for reference only; it is not recomputed here and no data are
% invented. The flexoelectric sensor FEM solve below is fully executable:
% call with an explicit thickness list, e.g.
%   benchmark_tier3_sensor([100e-9, 200e-9, 500e-9, 1e-6, 2e-6])
% and the open-circuit potential is computed for each thickness.
if nargin < 1, h_list = []; end
mat = material_BaTiO3();
fprintf('=== TIER 3: Abdollahi flexoelectric sensor (open circuit) ===\n');

fprintf('  SOURCE-REPORTED regression (paper): V_ind ~ h^(-1.0002), R^2 = 0.9999 (h>=500 nm);\n');
fprintf('    self-stiffening saturation below 100 nm.\n');
D = load_master_dataset();   % prints DATA REQUIRED with the exact variable list
results.paper_p    = -1.0002;
results.paper_R2   = 0.9999;
results.h          = [];
results.V          = [];

if isempty(h_list)
    fprintf('  No thickness list supplied: sensor FEM solve SKIPPED.\n');
    fprintf('  Provide h_list (m) to compute V_ind(h) with the coupled BFS model.\n');
    results.data_available = false;
else
    results.data_available = true;
    results.h = h_list(:);
    results.V = zeros(size(results.h));
    L = mat.L_beam;
    for k = 1:numel(h_list)
        h = h_list(k);
        mesh = generate_mesh(20, 2, L, h);
        results.V(k) = sensor_voltage(mesh, mat, mat.F_sensor);
        fprintf('  h = %8.1f nm : V_ind = %.6e V\n', h*1e9, results.V(k));
    end
    fprintf('  NOTE: this V_ind(h) is computed by THIS model (documented mesh/BCs);\n');
    fprintf('        it is NOT claimed to reproduce the paper''s dataset values.\n');
    if ~exist('output','dir'), mkdir('output'); end
    export_table(fullfile('output','sensor_scaling.csv'), {'h','V_ind'}, [results.h, results.V], {'m','V'});
    save(fullfile('output','sensor_scaling.mat'), 'results');
    fprintf('  exported output/sensor_scaling.csv and .mat\n');
end
fprintf('=== TIER 3 sensor done ===\n\n');
end

function V = sensor_voltage(mesh, mat, F)
% Open-circuit flexoelectric sensor: cantilever, tip shear F, ground at one
% node, no surface charge (open circuit). Returns max |phi|.
Fvec = apply_tip_load(mesh, F, 'v');
bc = make_cantilever_bc(mesh);
opts.loads = struct('F', Fvec, 'Q', []);
opts.bc = bc; opts.use_dof_scaling = true; opts.electrical = true;
out = solve_system(mesh, mat, opts);
V = max(abs(out.q_phi));
end
