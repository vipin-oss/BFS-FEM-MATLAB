function m = material_BaTiO3()
% MATERIAL_BATIO3  Barium titanate benchmark set (Tiers 3, 3b, limiting cases,
% h_crit, eta_EM).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part XI, Table (material inventory, set A), Eq. (XI_C11_BT..XI_C33_BT);
%   Part III, Eq. (III_lelastic, III_fflexo, III_Lambda).
%
% Units: SI. Every constant is taken from the frozen master calculation.
m.name  = 'BaTiO3';
m.E     = 100.0e9;          % [Pa] Young modulus (Abdollahi 2014)
m.nu    = 0.30;             % [1]  Poisson ratio
% Plane-strain moduli (Part XI, Eq. XI_C11_BT .. XI_C33_BT)
m.C11 = m.E*(1-m.nu)/((1+m.nu)*(1-2*m.nu));   % [Pa] 134.615385e9
m.C12 = m.E*m.nu /((1+m.nu)*(1-2*m.nu));      % [Pa]  57.692308e9
m.C33 = m.E/(2*(1+m.nu));                     % [Pa]  38.461538e9
% Dielectric permittivity
m.kappa11 = 11.06e-9;       % [F/m]
m.kappa22 = 11.06e-9;       % [F/m]
% Piezoelectric constants: zero (BaTiO3 is centrosymmetric; no piezo)
m.e31 = 0.0; m.e33 = 0.0; m.e15 = 0.0;   % [C/m^2]
% Flexoelectric moduli (Abdollahi 2014)
m.mu11 = 1.0e-6;            % [C/m] longitudinal
m.mu12 = 1.0e-6;            % [C/m] transversal
m.mu44 = 0.0;               % [C/m] shear (baseline isotropic shear)
% Mindlin Form-II strain-gradient moduli a1..a5 [N]
% Baseline: D = 2(a4+a5) = 1e-8 N  with a4 = a5 = 0.25e-8 N (master table A)
m.a1 = 0.0; m.a2 = 0.0; m.a3 = 0.0;
m.a4 = 0.25e-8; m.a5 = 0.25e-8;
% Characteristic reference values (Part III)
m.C0     = m.C11;                                   % [Pa]
m.kappa0 = m.kappa22;                               % [F/m]
m.mu0    = m.mu11;                                  % [C/m]
m.D0     = 2*(m.a1+m.a2+m.a3+m.a4+m.a5);            % [N]  = 2(a4+a5) = 1e-8
m.ell_ref = 1.0e-6;   % [m]  normalization reference ONLY (paper's ell_0);
                      %      NOT the material strain-gradient length
                      %      ell_elastic = sqrt(D0/C0) = 0.2726 nm.
% Benchmark geometry/loads (master table A)
m.L_beam  = 2.0e-6;   % [m] nanobeam length
m.h_beam  = 100e-9;   % [m] nanobeam thickness (L/h = 20)
m.F_sensor= 1.0e-9;   % [N] end shear load (sensor)
m.V0      = 1.0;      % [V] prescribed actuation potential
end
