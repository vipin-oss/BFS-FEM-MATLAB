function m = material_PZT5H()
% MATERIAL_PZT5H  PZT-5H piezoelectric benchmark set (Tier 2).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part XI, Table (material inventory, set B); Eq. (XI_C_PZT);
%   Eq. (XI_k31_ieee, XI_k31_std, XI_k31_result) -- IEEE coupling convention.
%
% NOTE (Appendix D, item D9): the master flags that of the paper's
% (e31, e33, e15) = (-16.6, +18.6, +12.7) C/m^2, only e31 = d31*E is
% consistent with the IEEE PZT-5H set (e31^1D = d31/s11^E = 16.6 C/m^2).
% e33 and e15 resemble a different material set and are NOT used by the
% Tier-2 deflection (only e31 enters through k31^2). They are retained
% here for completeness of the constitutive block, with the flag.
%
% Units: SI.
m.name  = 'PZT-5H';
m.E     = 60.6e9;          % [Pa]  short-circuit Young modulus (1/s11^E)
m.nu    = 0.31;            % [1]
% Plane-strain moduli (Part XI, Eq. XI_C_PZT)
m.C11 = m.E*(1-m.nu)/((1+m.nu)*(1-2*m.nu));   % [Pa] 83.997589e9
m.C12 = m.E*m.nu /((1+m.nu)*(1-2*m.nu));      % [Pa] 37.738047e9
m.C33 = m.E/(2*(1+m.nu));                     % [Pa] 23.129771e9
% Piezoelectric constants (paper table B, flagged: see D9)
m.e31 = -16.6;             % [C/m^2]
m.e33 = +18.6;             % [C/m^2]
m.e15 = +12.7;             % [C/m^2]
% Dielectric permittivity (free epsilon_33^T used in k31^2)
m.kappa22 = 30.1e-9;       % [F/m]  epsilon_33^T (master table B)
% kappa11 is NOT given in the master (only kappa22 is listed). It is set
% equal to kappa22 here as a DOCUMENTED ASSUMPTION for the optional 2D FEM
% only; the analytic Tier-2 benchmark does not use it.
m.kappa11 = 30.1e-9;       % [F/m] assumption (see above)
% Mindlin strain-gradient moduli: zero for the linear piezoelectric benchmark
m.a1 = 0; m.a2 = 0; m.a3 = 0; m.a4 = 0; m.a5 = 0;   % [N]
% No flexoelectricity in the piezoelectric benchmark
m.mu11 = 0; m.mu12 = 0; m.mu44 = 0;                 % [C/m]
% Characteristic reference values
m.C0     = m.C11;
m.kappa0 = m.kappa22;
m.mu0    = 1.0;            % [C/m] placeholder (mu = 0 for PZT; Lambda undefined)
m.D0     = 0;              % [N]
m.ell_ref= 1e-6;           % [m] normalization reference only
% Cantilever geometry/load (master table B)
m.L_beam = 100e-6;         % [m]
m.h_beam = 10e-6;          % [m]
m.b_beam = 1.0;            % [m] unit width (1D beam reference)
m.F_beam = 1.0e-6;         % [N] tip shear load
end
