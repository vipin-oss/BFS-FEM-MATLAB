function m = material_Shekarchizadeh(ell)
% MATERIAL_SHEKARCHIZADEH  Strain-gradient benchmark set (Tier 1).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part XI, Table (material inventory, set C); Eq. (XI_mu_shear).
%
% Inputs: ell [m] strain-gradient length scale (0.1, 0.2 or 0.3 mm).
% Units: SI.
if nargin < 1, ell = 0.3e-3; end
m.name  = 'Shekarchizadeh2022';
m.E     = 400.0e6;         % [Pa]
m.nu    = 0.49;            % [1]
m.mu_shear = m.E/(2*(1+m.nu));              % [Pa] 134.228188e6
m.C11 = m.E*(1-m.nu)/((1+m.nu)*(1-2*m.nu)); % [Pa] plane-strain
m.C12 = m.E*m.nu /((1+m.nu)*(1-2*m.nu));
m.C33 = m.E/(2*(1+m.nu));
% Mindlin Form-II moduli: a1 = a2 = a3 = 0 ; a4 = a5 = (1/2) mu_shear ell^2
m.a1 = 0; m.a2 = 0; m.a3 = 0;
m.a4 = 0.5*m.mu_shear*ell^2;   % [N]
m.a5 = 0.5*m.mu_shear*ell^2;   % [N]
% No electrical coupling in Tier 1
m.kappa11 = 0; m.kappa22 = 0;   % [F/m] (no electrical field)
m.mu11 = 0; m.mu12 = 0; m.mu44 = 0;
m.e31 = 0; m.e33 = 0; m.e15 = 0;
% Characteristic values
m.C0 = m.C11; m.kappa0 = 1; m.mu0 = 1;
m.D0 = 2*(m.a1+m.a2+m.a3+m.a4+m.a5);
m.ell = ell;               % [m] the actual material gradient length
m.ell_ref = 1e-3;          % [m] normalization reference only
% Plate geometry / prescribed data (master table C)
m.L = 1.5e-3;              % [m]
m.H = 0.5e-3;              % [m]
m.uhat = 5.0e-9;           % [m] prescribed top displacement (Case 1) = 1e-5 H
m.that = 1342.28188;       % [N/m^2] prescribed top shear traction (Case 2) = 1e-5 mu_shear
end
