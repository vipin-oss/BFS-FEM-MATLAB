function p = simulation_parameters()
% SIMULATION_PARAMETERS  Default global parameters for the whole project.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part I (units/definitions), Part VIII (Gauss quadrature),
%   Part IX (non-dimensionalization), Part X (conditioning).
%
% Returns a struct of default simulation settings. All values are
% deterministic; there are no hidden globals and no magic numbers in the
% core code (this is the single documented source of default numerics).
p.tol_eq        = 1e-12;   % [1] tolerance for "equals zero" checks
p.tol_sym       = 1e-10;   % [1] symmetry tolerance
p.tol_energy    = 1e-9;    % [1] energy-balance acceptance tolerance
p.gauss_n       = 4;       % [-] 1D Gauss order (4x4 tensor product, Part VIII)
p.mesh_tier1_coarse = [24 8];   % [-] Shekarchizadeh coarse mesh
p.mesh_tier1_fine   = [48 16];  % [-] Shekarchizadeh fine mesh
p.mesh_tier1_ref    = [96 32];  % [-] finest mesh (numerical reference only)
p.mesh_tier2 = [40 4];          % [-] PZT-5H cantilever default mesh (Nx x Ny)
p.mesh_small = [4 2];           % [-] tiny mesh for verification/energy scripts
% Publication figure formatting (plotting layer)
p.fig.font   = 'Times New Roman';
p.fig.fs     = 22;   % axis label font size
p.fig.lw     = 2.5;  % line width
p.fig.ms     = 8;    % marker size
p.fig.fmt    = {'-dpdf','-depsc'};  % export formats (MATLAB-compatible)
% Output/data directories (relative to project root)
p.out_dir   = fullfile('output');
p.data_dir  = fullfile('data');
p.dataset_file = 'section6_master_dataset.json'; % referenced by master; NOT supplied
end
