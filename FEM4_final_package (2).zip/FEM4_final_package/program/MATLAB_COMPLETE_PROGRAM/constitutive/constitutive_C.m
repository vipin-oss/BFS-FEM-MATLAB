function C = constitutive_C(C11, C12, C33)
% CONSTITUTIVE_C  Plane-strain elastic Voigt matrix (3x3).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part I, Eq. (I_C_matrix); Part XI, Eq. (XI_C11_BT..XI_C33_BT),
%   Eq. (XI_C_PZT).
%
%   C = [ C11  C12   0
%         C12  C11   0
%          0    0   C33 ]
%
% Acting on epsV = [eps11; eps22; gamma12] (engineering shear gamma = 2 eps12).
% Units: C11, C12, C33 in [Pa].
if nargin < 3 || isempty(C33), C33 = (C11 - C12)/2; end
C = [C11, C12, 0;
     C12, C11, 0;
     0,   0,  C33];
end
