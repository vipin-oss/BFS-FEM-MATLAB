function D = constitutive_D(a1, a2, a3, a4, a5)
% CONSTITUTIVE_D  Mindlin Form-II strain-gradient Voigt matrix D_Voigt (6x6).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part III, Eq. (III_W) five invariants, Eq. (III_Dmatrix),
%   Eq. (III_Dentries) -- the 18 non-zero entries.
%
%   etaV = [eta111; eta112; eta221; eta222; 2*eta121; 2*eta122]
%   W_grad = (1/2) etaV^T D etaV,   D = D^T.
%
% Inputs: a1..a5 [N] the five Mindlin moduli.
S = a1 + a2 + a3 + a4 + a5;
D11 = 2*S;
D22 = 2*(a3 + a4);
D33 = 2*(a3 + a4);
D44 = 2*S;
D55 = a2/2 + a4 + a5/2;
D66 = a2/2 + a4 + a5/2;
D13 = a1 + 2*a3;
D24 = a1 + 2*a3;
D16 = a1/2 + a2;
D45 = a1/2 + a2;
D25 = a1/2 + a5;
D36 = a1/2 + a5;
D = [ D11,  0,   D13,   0,    0,   D16;
       0,  D22,   0,   D24,  D25,    0;
      D13,   0,  D33,    0,    0,   D36;
       0,  D24,   0,   D44,  D45,    0;
       0,  D25,   0,   D45,  D55,    0;
      D16,   0,  D36,    0,    0,   D66 ];
end
