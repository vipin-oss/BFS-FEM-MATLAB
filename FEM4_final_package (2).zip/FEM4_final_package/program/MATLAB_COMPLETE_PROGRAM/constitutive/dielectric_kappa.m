function kappa = dielectric_kappa(kappa11, kappa22)
% DIELECTRIC_KAPPA  Diagonal permittivity matrix (2x2).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part I, Sec. "Material symmetry reductions"; Part IV, Eq. (IV_PDE3).
%
% Units: [F/m].
kappa = [kappa11, 0; 0, kappa22];
end
