function muV = flexoelectric_mu(mu11, mu12, mu44)
% FLEXOELECTRIC_MU  Reduced 2D flexoelectric Voigt matrix mu_V (2x6).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part II, Sec. "Reduced 2D flexoelectric tensor components",
%   Eq. (II_mu_components), Eq. (II_muV); Part IV, Eq. (IV_D1, IV_D2).
%
%   etaV = [eta111; eta112; eta221; eta222; 2*eta121; 2*eta122]
%   D_flexo = mu_V * etaV
%      D1 = mu11*eta111 + (mu12+2*mu44)*eta122
%      D2 = (mu12+2*mu44)*eta121 + mu11*eta222
%
% Because slots 5,6 carry the factor-2 engineering components, the
% coupling of the 1/2*(...) components enters with the half factors below.
% Units: mu11, mu12, mu44 in [C/m].
mc = mu12 + 2*mu44;   % isotropic transverse+shear combination (Eq. II_mu_components)
muV = [ mu11, 0, 0, 0,      0,      mc/2;     % row 1 -> D1
        0,    0, 0, mu11,   mc/2,   0      ]; % row 2 -> D2
end
