function eV = piezoelectric_e(e15, e31, e33)
% PIEZOELECTRIC_E  Reduced 2D piezoelectric Voigt matrix e_V (2x3).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part II, Sec. "Reduced 2D piezoelectric tensor components",
%   Eq. (II_e_components), Eq. (II_eV_matrix).
%
%   e_V = [ 0    0   e15
%           e31 e33   0  ]
%
% Acts on epsV = [eps11; eps22; gamma12]:
%   D_piezo = e_V * epsV ;  sigma_piezo = e_V^T * grad(phi).
% Units: [C/m^2].
eV = [ 0,   0,  e15;
       e31, e33, 0  ];
end
