This folder is reserved for raw benchmark datasets.

The frozen master calculation references section6_master_dataset.json
(Tier-3 sensor (h,V) table, actuator reference deflections, per-mesh
convergence tables, condition-number tables, eta_EM sweep, energy
partition table). That file is NOT supplied; the code prints
DATA REQUIRED where it would be needed and never fabricates values.

Drop the dataset here (as section6_master_dataset.json) to enable the
data-dependent recomputations.
