function D = load_master_dataset(filename)
% LOAD_MASTER_DATASET  Load the raw Section-6 numerical dataset, or report
% exactly what is missing (never fabricate).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part XI/XVII (numerical verification) — the dataset
%   section6_master_dataset.json is referenced but NOT supplied.
%
% Required variables (per the master's source-data notes):
%   tier3_h          : thickness list [m] for the sensor regression
%   tier3_V          : open-circuit voltage list [V]  (same length as tier3_h)
%   tier3b_w_eff     : actuator tip deflection, effective mu12 = 1e-6 C/m [m]
%   tier3b_w_bulk    : actuator tip deflection, bulk mu12 = 8e-9 C/m [m]
%   tier2_mesh_Lh    : L/h list used for the 2D FEM comparison
%   tier2_mesh_w     : FEM tip deflections per L/h [m]
%   cond_mesh        : mesh descriptors for the conditioning table
%   cond_raw         : raw condition numbers
%   cond_scaled      : scaled condition numbers
%   etaEM_Lh         : L/h list for the eta_EM sweep
%   etaEM            : eta_EM values
%   energy_W_ext     : external work values [J]
%   energy_U_mech    : mechanical energy values [J]
%   energy_U_elec    : electrical energy values [J]
%   hcrit_ell        : ell list [m] used for the paper's h_crit fit
%   hcrit_roots      : h_crit roots [m] (same length as hcrit_ell)
%
% Usage:
%   D = load_master_dataset();            % uses default filename
%   D = load_master_dataset('path.json'); % explicit file
%
% If the file is absent, D is returned empty and this function prints
% 'DATA REQUIRED' with the exact variable list above.
if nargin < 1, filename = 'section6_master_dataset.json'; end
D = struct();
if ~exist(filename, 'file')
    fprintf('DATA REQUIRED: dataset file "%s" not found.\n', filename);
    fprintf('  Required variables (as referenced by the master calculation):\n');
    req = {'tier3_h','tier3_V','tier3b_w_eff','tier3b_w_bulk','tier2_mesh_Lh', ...
           'tier2_mesh_w','cond_mesh','cond_raw','cond_scaled','etaEM_Lh', ...
           'etaEM','energy_W_ext','energy_U_mech','energy_U_elec','hcrit_ell','hcrit_roots'};
    for k = 1:numel(req), fprintf('    - %s\n', req{k}); end
    fprintf('  No data are fabricated; dependent benchmarks remain SOURCE-REPORTED.\n');
    D.available = false;
    return;
end
% attempt a JSON parse (MATLAB jsondecode; Octave 9.4 also provides it)
try
    D = jsondecode(fileread(filename));
    D.available = true;
    fprintf('loaded %s\n', filename);
catch err
    fprintf('DATA REQUIRED: "%s" exists but could not be parsed: %s\n', filename, err.message);
    D.available = false;
end
end
