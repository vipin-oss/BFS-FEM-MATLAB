function export_table(filename, header, data, units)
% EXPORT_TABLE  Write a data table to CSV with a header row.
%
% Project-wide data-export helper (Part 17 of the task specification:
% automatic data export to CSV/MAT with clear column names and units).
%
% Inputs:
%   filename : char, full path to the .csv file
%   header   : cellstr of column names
%   data     : numeric matrix (rows = samples, cols = columns)
%   units    : (optional) cellstr of units appended to the header names
if nargin < 4, units = {}; end
fid = fopen(filename, 'w');
if fid < 0, error('export_table: cannot open %s', filename); end
% header line
for c = 1:numel(header)
    if isempty(units)
        fprintf(fid, '%s', header{c});
    else
        fprintf(fid, '%s [%s]', header{c}, units{c});
    end
    if c < numel(header), fprintf(fid, ','); end
end
fprintf(fid, '\n');
% data rows
for r = 1:size(data,1)
    for c = 1:size(data,2)
        fprintf(fid, '%.12e', data(r,c));
        if c < size(data,2), fprintf(fid, ','); end
    end
    fprintf(fid, '\n');
end
fclose(fid);
end
