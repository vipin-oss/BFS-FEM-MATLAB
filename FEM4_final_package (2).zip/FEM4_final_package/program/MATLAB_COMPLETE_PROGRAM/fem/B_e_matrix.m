function Be = B_e_matrix(xi, eta, a, b)
% B_E_MATRIX  Strain operator B_e (3x32) at (xi,eta).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VIII, Eq. (VIII_Be) per-node block.
%
%   epsV = B_e q_u^e, epsV = [eps11; eps22; gamma12]
%   eps11 = u,x ; eps22 = v,y ; gamma12 = u,y + v,x
%
% Per-node mechanical DOF order (Part VII, Eq. VII_node_dof):
%   [u, u_x, u_y, u_xy, v, v_x, v_y, v_xy]
% Node column block: cols 1..4 = u-family, cols 5..8 = v-family.
%
% Output: Be (3x32), double.
Be = zeros(3,32);
for p = 1:4
    d = bfs_shape_derivatives(p, xi, eta, a, b);
    c0 = (p-1)*8;
    % row 1: eps11 = u,x
    Be(1, c0+1:c0+4) = d.Nx;
    % row 2: eps22 = v,y
    Be(2, c0+5:c0+8) = d.Ny;
    % row 3: gamma12 = u,y + v,x
    Be(3, c0+1:c0+4) = d.Ny;
    Be(3, c0+5:c0+8) = d.Nx;
end
end
