function Beta = B_eta_matrix(xi, eta, a, b)
% B_ETA_MATRIX  Strain-gradient operator B_eta (6x32) at (xi,eta).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VIII, Eq. (VIII_Beta) per-node block;
%   Part I, Eq. (I_eta_voigt) the 6-component etaV.
%
%   etaV = B_eta q_u^e, etaV = [eta111; eta112; eta221; eta222; 2*eta121; 2*eta122]
%   eta111 = u,xx ; eta112 = u,xy ; eta221 = v,xy ; eta222 = v,yy ;
%   2*eta121 = u,xy + v,xx ; 2*eta122 = u,yy + v,xy .
%
% Per-node mechanical DOF order: [u, u_x, u_y, u_xy, v, v_x, v_y, v_xy].
% Output: Beta (6x32).
Beta = zeros(6,32);
for p = 1:4
    d = bfs_shape_derivatives(p, xi, eta, a, b);
    c0 = (p-1)*8;
    % row 1: eta111 = u,xx
    Beta(1, c0+1:c0+4) = d.Nxx;
    % row 2: eta112 = u,xy
    Beta(2, c0+1:c0+4) = d.Nxy;
    % row 3: eta221 = v,xy
    Beta(3, c0+5:c0+8) = d.Nxy;
    % row 4: eta222 = v,yy
    Beta(4, c0+5:c0+8) = d.Nyy;
    % row 5: 2*eta121 = u,xy + v,xx
    Beta(5, c0+1:c0+4) = d.Nxy;
    Beta(5, c0+5:c0+8) = d.Nxx;
    % row 6: 2*eta122 = u,yy + v,xy
    Beta(6, c0+1:c0+4) = d.Nyy;
    Beta(6, c0+5:c0+8) = d.Nxy;
end
end
