function Bphi = B_phi_matrix(xi, eta, a, b)
% B_PHI_MATRIX  Electric-field operator B_phi (2x4) at (xi,eta).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VIII, Eq. (VIII_Bphi);
%   Part VII, Eq. (VII_lagrange) bilinear Lagrange basis.
%
%   grad(phi) = B_phi q_phi^e ,  E = -B_phi q_phi^e
%   Np^I(xi,eta) = (1/4)(1+xiI xi)(1+etaI eta)
%
% Electrical DOF order: [phi] per node, nodes 1..4.
% Output: Bphi (2x4): row1 = dNp/dx, row2 = dNp/dy.
xiP  = [-1, 1, 1,-1];
etaP = [-1,-1, 1, 1];
Bphi = zeros(2,4);
for p = 1:4
    Bphi(1,p) = (1/(4*a))*xiP(p)*(1+etaP(p)*eta);   % dNp/dx
    Bphi(2,p) = (1/(4*b))*(1+xiP(p)*xi)*etaP(p);    % dNp/dy
end
end
