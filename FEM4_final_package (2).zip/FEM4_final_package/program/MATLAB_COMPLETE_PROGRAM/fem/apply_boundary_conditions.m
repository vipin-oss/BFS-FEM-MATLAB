function [Kr, fr, freeidx, fixedidx] = apply_boundary_conditions(K, f, bcdof, bcval)
% APPLY_BOUNDARY_CONDITIONS  Essential-BC elimination for K x = f.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part V (boundary operators), Part IX (scaling); standard symmetric
%   elimination of constrained DOFs.
%
% Inputs:
%   K     : n x n system matrix
%   f     : n x 1 load vector
%   bcdof : k x 1 global DOF indices to fix (essential BCs)
%   bcval : k x 1 prescribed values
% Outputs:
%   Kr : reduced matrix (free DOFs)
%   fr : reduced load
%   freeidx : indices of free DOFs (column)
%   fixedidx: indices of fixed DOFs (column)
n = size(K,1);
if isempty(bcdof)
    Kr = K; fr = f; freeidx = (1:n)'; fixedidx = zeros(0,1); return;
end
bcdof = bcdof(:); bcval = bcval(:);
if numel(unique(bcdof)) ~= numel(bcdof)
    error('apply_boundary_conditions: duplicate DOF in bcdof');
end
fixed = false(n,1); fixed(bcdof) = true;
fixedidx = find(fixed);
freeidx  = find(~fixed);
bcv = zeros(n,1); bcv(bcdof) = bcval;
Kr = K(freeidx, freeidx);
fr = f(freeidx) - K(freeidx, fixedidx)*bcv(fixedidx);
end
