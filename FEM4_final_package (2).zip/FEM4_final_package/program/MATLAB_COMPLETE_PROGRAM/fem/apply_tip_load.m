function F = apply_tip_load(mesh, Ftot, direction)
% APPLY_TIP_LOAD  Build the mechanical nodal-force vector for an end load.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part XI, Table (applied end shear load F, Tier 2 / Tier 3).
%
% The total force Ftot is applied on the free (right) edge. Two documented
% options:
%   direction = 'v' (default): transverse (bending) load on the v DOF;
%   direction = 'u': axial load on the u DOF.
% The load is distributed equally over the right-edge nodes (consistent
% with an end-shear resultant); for the 1D-beam comparison the tip value
% is read at the free edge mid node.
%
% Inputs: mesh, Ftot [N], direction ('v'|'u').
% Output: F (8*nnode x 1) mechanical nodal-force vector.
if nargin < 3, direction = 'v'; end
nnode = mesh.nnode; nmech = 8*nnode;
F = zeros(nmech,1);
tolx = 1e-12*mesh.Lx;
right_nodes = find(abs(mesh.coords(:,1) - mesh.Lx) < tolx);
nd = numel(right_nodes);
switch lower(direction)
    case 'v',  dofcomp = 5;   % v DOF is component 5 of [u u_x u_y u_xy v v_x v_y v_xy]
    case 'u',  dofcomp = 1;
    otherwise, error('apply_tip_load: direction must be ''u'' or ''v''');
end
for n = right_nodes'
    F(8*(n-1) + dofcomp) = Ftot/nd;
end
end
