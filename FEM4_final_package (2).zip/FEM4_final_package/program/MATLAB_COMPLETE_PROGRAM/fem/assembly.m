function [Kuu, Kup, Kpp] = assembly(mesh, mat)
% ASSEMBLY  Sparse global assembly of the three blocks.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VIII, Eq. (VIII_element_system, VIII_Kuu, VIII_Kuphi, VIII_Kphiphi).
%
% DOF numbering:
%   mechanical: node n -> global mech DOFs 8*(n-1)+(1..8) =
%                [u, u_x, u_y, u_xy, v, v_x, v_y, v_xy]
%   electrical: node n -> global elec DOF n.
%
% Inputs: mesh (struct from generate_mesh), mat (material struct with
% fields C11,C12,C33,a1..a5,e15,e31,e33,mu11,mu12,mu44,kappa11,kappa22).
% Outputs: Kuu (8*nnode x 8*nnode), Kup (8*nnode x nnode),
%          Kpp (nnode x nnode) -- all sparse.
C   = constitutive_C(mat.C11, mat.C12, mat.C33);
D   = constitutive_D(mat.a1, mat.a2, mat.a3, mat.a4, mat.a5);
eV  = piezoelectric_e(mat.e15, mat.e31, mat.e33);
muV = flexoelectric_mu(mat.mu11, mat.mu12, mat.mu44);
kap = dielectric_kappa(mat.kappa11, mat.kappa22);

nmech = 8*mesh.nnode;
nelec = mesh.nnode;
a = mesh.a; b = mesh.b;

Kuu = sparse(nmech, nmech);
Kup = sparse(nmech, nelec);
Kpp = sparse(nelec, nelec);

for e = 1:mesh.nelem
    en = mesh.conn(e,:);              % 4 global node ids
    edof_u = zeros(1,32);             % element mech DOF -> global
    for p = 1:4
        edof_u((p-1)*8+(1:8)) = 8*(en(p)-1)+(1:8);
    end
    edof_p = en;                      % element elec DOF -> global (4)

    Kuu_e = element_stiffness(a, b, C, D);
    Kup_e = element_coupling(a, b, eV, muV);
    Kpp_e = element_electrical(a, b, kap);

    Kuu(edof_u, edof_u) = Kuu(edof_u, edof_u) + sparse(Kuu_e);
    Kup(edof_u, edof_p) = Kup(edof_u, edof_p) + sparse(Kup_e);
    Kpp(edof_p, edof_p) = Kpp(edof_p, edof_p) + sparse(Kpp_e);
end
end
