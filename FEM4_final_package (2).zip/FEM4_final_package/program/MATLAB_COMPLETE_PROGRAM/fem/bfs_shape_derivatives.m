function d = bfs_shape_derivatives(p, xi, eta, a, b)
% BFS_SHAPE_DERIVATIVES  Physical-space derivatives of the 4 BFS functions
% of node p at (xi,eta).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VII, Eq. (VII_chain) chain rule;
%   Part VIII, Eq. (VIII_dNx..VIII_dNxy) explicit derivative entries.
%
% With d/dx = (1/a) d/dxi and d/dy = (1/b) d/deta, for N1..N4 of node p:
%   N1 = H0i H0j ; N2 = a H1i H0j ; N3 = b H0i H1j ; N4 = ab H1i H1j
%   dN1/dx = (1/a) H0i' H0j , dN1/dy = (1/b) H0i H0j'
%   dN2/dx = H1i' H0j      , dN2/dy = (a/b) H1i H0j'
%   dN3/dx = (b/a) H0i' H1j, dN3/dy = H0i H1j'
%   dN4/dx = b H1i' H1j    , dN4/dy = a H1i H1j'
%   d2N1/dx2 = (1/a^2) H0i'' H0j, d2N1/dy2 = (1/b^2) H0i H0j'',
%   d2N1/dxdy = (1/(ab)) H0i' H0j'
%   ... etc. (all eight entries implemented below, no abbreviation).
%
% Inputs: p (1..4), xi, eta, a, b.
% Output struct d with fields Nx, Ny, Nxx, Nyy, Nxy (each 1x4).
[hi, hj] = node_hermite_index(p);
hx = hermite_cubic(xi);
hy = hermite_cubic(eta);
% value/slope families and derivatives at (xi)
H0i  = pick(hx,'H0',hi); H0ip  = pick(hx,'H0p',hi); H0ipp = pick(hx,'H0pp',hi);
H1i  = pick(hx,'H1',hi); H1ip  = pick(hx,'H1p',hi); H1ipp = pick(hx,'H1pp',hi);
% value/slope families and derivatives at (eta)
H0j  = pick(hy,'H0',hj); H0jp  = pick(hy,'H0p',hj); H0jpp = pick(hy,'H0pp',hj);
H1j  = pick(hy,'H1',hj); H1jp  = pick(hy,'H1p',hj); H1jpp = pick(hy,'H1pp',hj);

% first derivatives
d.Nx  = [ (1/a)*H0ip*H0j,      H1ip*H0j,        (b/a)*H0ip*H1j,      b*H1ip*H1j    ];
d.Ny  = [ (1/b)*H0i*H0jp,  (a/b)*H1i*H0jp,         H0i*H1jp,          a*H1i*H1jp   ];
% second derivatives
d.Nxx = [ (1/a^2)*H0ipp*H0j, (1/a)*H1ipp*H0j, (b/a^2)*H0ipp*H1j, (b/a)*H1ipp*H1j ];
d.Nyy = [ (1/b^2)*H0i*H0jpp, (a/b^2)*H1i*H0jpp, (1/b)*H0i*H1jpp, (a/b)*H1i*H1jpp ];
d.Nxy = [ (1/(a*b))*H0ip*H0jp, (1/b)*H1ip*H0jp, (1/a)*H0ip*H1jp, H1ip*H1jp       ];
end

% ---- private helpers (subfunctions) ----
function [i, j] = node_hermite_index(p)
xiP  = [-1, 1, 1,-1];
etaP = [-1,-1, 1, 1];
i = 1 + (xiP(p) > 0);
j = 1 + (etaP(p) > 0);
end

function v = pick(h, fam, k)
switch fam
    case 'H0'
        if k==1, v = h.H01; else, v = h.H02; end
    case 'H1'
        if k==1, v = h.H11; else, v = h.H12; end
    case 'H0p'
        if k==1, v = h.H01p; else, v = h.H02p; end
    case 'H1p'
        if k==1, v = h.H11p; else, v = h.H12p; end
    case 'H0pp'
        if k==1, v = h.H01pp; else, v = h.H02pp; end
    case 'H1pp'
        if k==1, v = h.H11pp; else, v = h.H12pp; end
    otherwise
        error('bfs_shape_derivatives:pick: unknown family %s', fam);
end
end
