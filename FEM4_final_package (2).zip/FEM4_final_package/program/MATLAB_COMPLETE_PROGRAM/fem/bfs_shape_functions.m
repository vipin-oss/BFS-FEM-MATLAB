function N = bfs_shape_functions(p, xi, eta, a, b)
% BFS_SHAPE_FUNCTIONS  Tensor-product BFS shape-function VALUES at (xi,eta).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VII, Eq. (VII_bfs) tensor-product BFS functions;
%   Eq. (VII_interp) nodal interpolation.
%
% For node p (local 1..4 -> (xiI,etaI) = (-1,-1),(+1,-1),(+1,+1),(-1,+1))
% the four shape functions for one scalar component w in {u,v} are
%   N1 = H0i(xi) H0j(eta)      (value DOF)
%   N2 = a H1i(xi) H0j(eta)    (w_x DOF)
%   N3 = b H0i(xi) H1j(eta)    (w_y DOF)
%   N4 = ab H1i(xi) H1j(eta)   (w_xy DOF)
%
% Inputs: p (1..4), xi, eta in [-1,1], a,b element half-widths [m].
% Output: N (1x4).
[hi, hj] = node_hermite_index(p);
hx = hermite_cubic(xi);
hy = hermite_cubic(eta);
H0i = pick(hx, 'H0', hi); H1i = pick(hx, 'H1', hi);
H0j = pick(hy, 'H0', hj); H1j = pick(hy, 'H1', hj);
N = [ H0i*H0j,  a*H1i*H0j,  b*H0i*H1j,  a*b*H1i*H1j ];
end

% ---- private helpers (subfunctions) ----
function [i, j] = node_hermite_index(p)
% local node -> (i,j) Hermite families: 1:(-1,-1) 2:(+1,-1) 3:(+1,+1) 4:(-1,+1)
xiP  = [-1, 1, 1,-1];
etaP = [-1,-1, 1, 1];
i = 1 + (xiP(p) > 0);
j = 1 + (etaP(p) > 0);
end

function v = pick(h, fam, k)
% fam 'H0' -> value family (H01/H02); 'H1' -> slope family (H11/H12)
if strcmp(fam, 'H0')
    if k == 1, v = h.H01; else, v = h.H02; end
else
    if k == 1, v = h.H11; else, v = h.H12; end
end
end
