function Kup = element_coupling(a, b, eV, muV)
% ELEMENT_COUPLING  Electromechanical coupling element matrix K_uphi^e (32x4).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VIII, Eq. (VIII_Kuphi):
%   K_uphi^e = int_Omega (B_e^T e_V^T + B_eta^T mu_V^T) B_phi dOmega
%
% Note: K_phiu^e = (K_uphi^e)^T by construction (Part VIII,
% Eq. VIII_transp_proof). E = -B_phi q_phi is built into the sign
% convention of the saddle-point system, NOT into this matrix.
%
% Inputs: a,b; eV (2x3); muV (2x6).
% Output: Kup (32x4).
[gp, gw] = gauss_legendre_4x4();
Kup = zeros(32,4);
for i = 1:4
    xi = gp(i); wi = gw(i);
    for j = 1:4
        eta = gp(j); wj = gw(j);
        Be   = B_e_matrix(xi, eta, a, b);
        Beta = B_eta_matrix(xi, eta, a, b);
        Bphi = B_phi_matrix(xi, eta, a, b);
        Kup = Kup + (wi*wj)*(Be'*eV' + Beta'*muV')*Bphi*(a*b);
    end
end
end
