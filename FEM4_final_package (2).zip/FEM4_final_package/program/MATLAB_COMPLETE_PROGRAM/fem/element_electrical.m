function Kpp = element_electrical(a, b, kappa)
% ELEMENT_ELECTRICAL  Dielectric element matrix K_phiphi^e (4x4).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VIII, Eq. (VIII_Kphiphi):
%   K_phiphi^e = int_Omega B_phi^T kappa B_phi dOmega
%
% In the saddle system this block enters with a minus sign
% (Part VI, Eq. VI_saddle): [K_uu, K_uphi; K_phiu, -K_phiphi].
%
% Inputs: a,b; kappa (2x2).
% Output: Kpp (4x4) symmetric positive semi-definite.
[gp, gw] = gauss_legendre_4x4();
Kpp = zeros(4,4);
for i = 1:4
    xi = gp(i); wi = gw(i);
    for j = 1:4
        eta = gp(j); wj = gw(j);
        Bphi = B_phi_matrix(xi, eta, a, b);
        Kpp = Kpp + (wi*wj)*(Bphi'*kappa*Bphi)*(a*b);
    end
end
Kpp = (Kpp + Kpp')/2;
end
