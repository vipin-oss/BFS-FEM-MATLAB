function Kuu = element_stiffness(a, b, C, D)
% ELEMENT_STIFFNESS  Mechanical element matrix K_uu^e (32x32).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VIII, Eq. (VIII_Kuu):
%   K_uu^e = int_Omega (B_e^T C B_e + B_eta^T D_Voigt B_eta) dOmega
%
% det(J) = a*b (Part VII, Eq. VII_jac). 4x4 Gauss rule (exact: Part VIII).
%
% Inputs: a,b half-widths [m]; C (3x3); D = D_Voigt (6x6).
% Output: Kuu (32x32) symmetric.
[gp, gw] = gauss_legendre_4x4();
Kuu = zeros(32,32);
for i = 1:4
    xi = gp(i); wi = gw(i);
    for j = 1:4
        eta = gp(j); wj = gw(j);
        Be   = B_e_matrix(xi, eta, a, b);
        Beta = B_eta_matrix(xi, eta, a, b);
        Kuu = Kuu + (wi*wj)*(Be'*C*Be + Beta'*D*Beta)*(a*b);
    end
end
Kuu = (Kuu + Kuu')/2;   % enforce exact symmetry against roundoff
end
