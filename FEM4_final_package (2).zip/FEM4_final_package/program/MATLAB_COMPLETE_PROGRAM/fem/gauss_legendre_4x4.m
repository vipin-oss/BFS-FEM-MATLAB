function [gp, gw] = gauss_legendre_4x4()
% GAUSS_LEGENDRE_4X4  4-point Gauss-Legendre rule on [-1,1].
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VIII, Sec. "Why 4x4 Gauss-Legendre quadrature is exact",
%   Eq. (VIII_gauss): 2n-1 = 7 >= 6 (the per-variable degree of the
%   binding integrand B_eta^T D B_eta / B_e^T C B_e).
%
% Output: gp (4x1) points, gw (4x1) weights.
r1 = sqrt(3 - 2*sqrt(6/5))/sqrt(7);   % = 0.339981043584856... (inner)
r2 = sqrt(3 + 2*sqrt(6/5))/sqrt(7);   % = 0.861136311594053... (outer)
w_inner = (18 + sqrt(30))/36;         % = 0.652145154862546... (for +-r1)
w_outer = (18 - sqrt(30))/36;         % = 0.347854845137454... (for +-r2)
gp = [-r2; -r1;  r1;  r2];
gw = [ w_outer;  w_inner;  w_inner;  w_outer];
end
