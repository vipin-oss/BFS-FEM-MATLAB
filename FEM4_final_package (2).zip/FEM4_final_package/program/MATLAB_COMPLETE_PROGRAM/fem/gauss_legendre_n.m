function [gp, gw] = gauss_legendre_n(n)
% GAUSS_LEGENDRE_N  Generic n-point Gauss-Legendre rule on [-1,1].
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VIII (quadrature; 2n-1 exactness). Used by verification scripts as
%   the high-order reference for the 4x4 rule.
%
% Nodes by Newton iteration on the Legendre polynomial P_n; weights by the
% standard formula w_i = 2 / ((1-x_i^2) P_n'(x_i)^2).
gp = zeros(n,1); gw = zeros(n,1);
m = floor((n+1)/2);
for i = 1:m
    z = cos(pi*(i - 0.25)/(n + 0.5));
    for it = 1:100
        [P, Pp] = legendre_poly(n, z);
        dz = -P/Pp; z = z + dz;
        if abs(dz) < 1e-15, break; end
    end
    [~, Pp] = legendre_poly(n, z);
    gp(i) = -z; gw(i) = 2/((1-z^2)*Pp^2);
    gp(n+1-i) = z; gw(n+1-i) = gw(i);
end
end

function [P, Pp] = legendre_poly(n, x)
P0 = 1; P1 = x;
for k = 2:n
    P = ((2*k-1)*x*P1 - (k-1)*P0)/k; P0 = P1; P1 = P;
end
if n == 0, P = P0; elseif n == 1, P = P1; end
Pp = n*(x*P - P0)/(x^2 - 1);
end
