function mesh = generate_mesh(nx, ny, Lx, Ly)
% GENERATE_MESH  Structured rectangular mesh of BFS elements.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VII, Eq. (VII_parent, VII_physical, VII_map) element geometry.
%
% Domain [0,Lx] x [0,Ly], nx elements in x, ny in y.
% Node numbering: row-major over y (bottom row first):
%   node index = (ix-1)*(ny+1) + iy, ix=1..nx+1, iy=1..ny+1.
% Element (ex,ey) connectivity (CCW):
%   bl = node(ex,ey), br = node(ex+1,ey), tr = node(ex+1,ey+1), tl = node(ex,ey+1)
%   local node order 1..4 = [bl, br, tr, tl] matches
%   (xi,eta)=(-1,-1),(+1,-1),(+1,+1),(-1,+1).
%
% Output struct mesh:
%   .nx .ny .Lx .Ly .nnode .nelem .coords (nnode x 2) .conn (nelem x 4)
%   .a (half width), .b (half height) per element (uniform mesh).
mesh.nx = nx; mesh.ny = ny; mesh.Lx = Lx; mesh.Ly = Ly;
mesh.nnode = (nx+1)*(ny+1);
mesh.nelem = nx*ny;
mesh.coords = zeros(mesh.nnode,2);
dx = Lx/nx; dy = Ly/ny;
for ix = 1:nx+1
    for iy = 1:ny+1
        n = (ix-1)*(ny+1) + iy;
        mesh.coords(n,:) = [(ix-1)*dx, (iy-1)*dy];
    end
end
mesh.conn = zeros(mesh.nelem,4);
for ex = 1:nx
    for ey = 1:ny
        e = (ex-1)*ny + ey;
        bl = (ex-1)*(ny+1) + ey;
        br = bl + (ny+1);
        tr = br + 1;
        tl = bl + 1;
        mesh.conn(e,:) = [bl, br, tr, tl];
    end
end
mesh.a = dx/2;   % element half-width  (uniform)
mesh.b = dy/2;   % element half-height (uniform)
end
