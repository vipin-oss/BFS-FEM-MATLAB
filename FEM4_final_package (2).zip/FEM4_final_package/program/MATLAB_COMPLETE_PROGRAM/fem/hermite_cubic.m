function h = hermite_cubic(zeta)
% HERMITE_CUBIC  1D cubic Hermite basis functions and derivatives on [-1,1].
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VII, Eq. (VII_hermite, VII_dH1, VII_dH2, VII_ddH1, VII_ddH2).
%
%   H01(z) = (2-3z+z^3)/4   value at node 1 (z=-1)
%   H02(z) = (2+3z-z^3)/4   value at node 2 (z=+1)
%   H11(z) = (1-z-z^2+z^3)/4   slope at node 1
%   H12(z) = (-1-z+z^2+z^3)/4  slope at node 2
%
% Input: zeta (scalar or vector). Output: struct h with the 4 functions and
% their first (p) and second (pp) derivatives.
h.H01 = (2 - 3*zeta + zeta.^3)/4;
h.H02 = (2 + 3*zeta - zeta.^3)/4;
h.H11 = (1 - zeta - zeta.^2 + zeta.^3)/4;
h.H12 = (-1 - zeta + zeta.^2 + zeta.^3)/4;
h.H01p = (-3 + 3*zeta.^2)/4;
h.H02p = ( 3 - 3*zeta.^2)/4;
h.H11p = (-1 - 2*zeta + 3*zeta.^2)/4;
h.H12p = (-1 + 2*zeta + 3*zeta.^2)/4;
h.H01pp = ( 3*zeta)/2;
h.H02pp = (-3*zeta)/2;
h.H11pp = (-1 + 3*zeta)/2;
h.H12pp = ( 1 + 3*zeta)/2;
end
