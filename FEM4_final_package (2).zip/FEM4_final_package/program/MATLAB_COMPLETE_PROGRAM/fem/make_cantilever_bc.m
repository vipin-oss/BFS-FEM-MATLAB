function bc = make_cantilever_bc(mesh, ground_node)
% MAKE_CANTILEVER_BC  Essential BCs for a left-edge-clamped cantilever.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part V (boundary operators); Part IX (scaling). Essential kinematic
%   conditions on the clamped edge: u = u_x = u_y = u_xy = 0 and
%   v = v_x = v_y = v_xy = 0 (all 8 mechanical DOFs), plus a single
%   reference ground for the electric potential (open circuit).
%
% Inputs: mesh; ground_node (optional) node id at which phi = 0.
% Output: bc struct with .dof (global DOF indices) and .val (values).
nnode = mesh.nnode; nmech = 8*nnode;
tolx = 1e-12*mesh.Lx;
left_nodes = find(abs(mesh.coords(:,1) - 0) < tolx);   % x = 0 edge
dof = zeros(8*numel(left_nodes),1); val = zeros(size(dof));
k = 0;
for n = left_nodes'
    for d = 1:8
        k = k + 1;
        dof(k) = 8*(n-1) + d;   % mech DOFs of clamped node
    end
end
% electrical ground (single reference point for open circuit)
if nargin < 2 || isempty(ground_node)
    % default: node nearest (0,0)
    [~, ground_node] = min(sum(mesh.coords.^2, 2));
end
dof(k+1) = nmech + ground_node;   % phi DOF
val(k+1) = 0;
bc.dof = dof; bc.val = val;
end
