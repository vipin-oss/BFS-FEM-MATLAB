function out = solve_system(mesh, mat, opts)
% SOLVE_SYSTEM  Assemble, scale, constrain and solve the coupled system.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VI, Eq. (VI_saddle) saddle-point system;
%   Part VIII, Eq. (VIII_element_system) element system;
%   Part IX, Eq. (IX_congruence) symmetric congruence scaling.
%
% System (unscaled):
%   [ K_uu      K_uphi  ] [ q_u   ]   [ F_u  ]
%   [ K_uphi^T -K_phiphi] [ q_phi ] = [ -Q   ]
%
% with K_phiu = K_uphi^T enforced exactly (assembly builds Kup and uses
% its transpose).
%
% Inputs:
%   mesh : struct from generate_mesh
%   mat  : material struct
%   opts : struct with fields
%     .loads : struct .F (8*nnode x 1 mech nodal force), .Q (nnode x 1 charge)
%     .bc    : struct .dof (global DOF indices 1..8*nnode+nnode), .val (values)
%     .use_scaling     : logical (default false) electromechanical congruence S only
%     .use_dof_scaling : logical (default false) FULL non-dimensional DOF scaling
%                        (value/slope/twist + electrical), the mathematically
%                        complete scaling of Part IX (see dof_scaling_vector.m and
%                        CONDITIONING_RECONCILIATION_REPORT.md)
%     .electrical  : logical (default true)
%     .no_cond     : logical (default false) skip the diagnostic-only
%                    condition-number estimates; the solution vector is
%                    unaffected. Used by refined-mesh sweeps where condest
%                    on the raw ill-conditioned system is prohibitively slow.
% Outputs (struct out):
%   .q_u, .q_phi, .q (full), .K (saddle), .f, .cond (struct), .Kbar, .S.
nmech = 8*mesh.nnode; nelec = mesh.nnode;
if nargin < 3, opts = struct(); end
if ~isfield(opts,'loads'),      opts.loads = struct('F',[],'Q',[]); end
if ~isfield(opts,'bc'),         opts.bc = struct('dof',[],'val',[]); end
if ~isfield(opts,'use_scaling'),opts.use_scaling = false; end
if ~isfield(opts,'use_dof_scaling'),opts.use_dof_scaling = false; end
if ~isfield(opts,'electrical'), opts.electrical = true; end
if ~isfield(opts,'no_cond'),    opts.no_cond = false; end

[Kuu, Kup, Kpp] = assembly(mesh, mat);

F = zeros(nmech,1); Q = zeros(nelec,1);
if ~isempty(opts.loads.F), F = opts.loads.F(:); end
if ~isempty(opts.loads.Q), Q = opts.loads.Q(:); end

bc_dof = opts.bc.dof(:); bc_val = opts.bc.val(:);

if ~opts.electrical
    % mechanical-only problem (e.g. pure strain-gradient Tier 1)
    % The raw K_uu carries the BFS twist-DOF (u_xy, v_xy) scale disparity
    % (~1e-20..1e-28 on thin/high-aspect meshes), so a raw backslash is
    % numerically singular in MATLAB. The full derivative-DOF scaling
    % (use_dof_scaling) removes it; the electromechanical-only S does not
    % (it is uniform over the mechanical DOFs). Unified congruence below.
    K = Kuu; f = F;
    if opts.use_dof_scaling
        s = dof_scaling_vector(mesh.nnode, mesh.Lx, 1.0, 1.0, 1.0);
        s = s(1:nmech);                  % mechanical part only (u0=1, no elec)
    elseif opts.use_scaling
        s = mat.C0^(-1/2)*ones(nmech,1); % uniform (does NOT fix twist disparity)
    else
        s = ones(nmech,1);
    end
    if any(s ~= 1)
        Kbar = diag(sparse(s))*K*diag(sparse(s)); fbar = f.*s;
        bc_val_s = bc_val ./ s(bc_dof);
        [Kred_s, fred_s, freeidx_s] = reduce(Kbar, fbar, bc_dof, bc_val_s);
        if opts.no_cond, k_sc = NaN; else, k_sc = cond_number1(Kred_s); end
        xr = Kred_s \ fred_s;
        qbar = zeros(nmech,1); qbar(freeidx_s) = xr;
        bcv = zeros(nmech,1); bcv(bc_dof) = bc_val_s;
        qbar = qbar + bcv;               % place prescribed values back
        q = s.*qbar;                     % transform back to physical DOFs
        [Kred, ~, ~] = reduce(K, f, bc_dof, bc_val);
        if opts.no_cond, k_raw = NaN; else, k_raw = cond_number1(Kred); end
    else
        [Kred, fred, freeidx] = reduce(K, f, bc_dof, bc_val);
        if opts.no_cond, k_raw = NaN; else, k_raw = cond_number1(Kred); end
        xr = Kred \ fred;
        q = zeros(nmech,1); q(freeidx) = xr;
        bcv = zeros(nmech,1); bcv(bc_dof) = bc_val;
        q = q + bcv;                     % place prescribed values back
        k_sc = k_raw;
    end
    out.q_u = q; out.q_phi = zeros(0,1); out.q = q;
    out.K = Kuu; out.f = F; out.Kbar = Kuu; out.S = speye(nmech);
    out.cond.raw = k_raw; out.cond.scaled = k_sc;
    out.cond.improvement = k_raw/k_sc;
    out.info = sprintf('mechanical-only solve, %d DOFs', nmech);
    return;
end

% ---- full coupled solve ----
K = [Kuu, Kup; Kup', -Kpp];
f = [F; -Q(:)];

[Kred, fred, freeidx] = reduce(K, f, bc_dof, bc_val);
if opts.no_cond, k_raw = NaN; else, k_raw = cond_number1(Kred); end

% Unified symmetric-congruence scaling: Kbar = diag(s) K diag(s), fbar = f.*s.
%   use_dof_scaling -> s = dof_scaling_vector (FULL non-dimensionalization,
%       value/slope/twist + electrical, Part IX; see CONDITIONING_RECONCILIATION_REPORT)
%   use_scaling     -> s = [C0^-1/2 (mech); kappa0^-1/2 (elec)] (Part IX, Eq. IX_S)
%   neither         -> s = 1 (raw physical system)
if opts.use_dof_scaling
    s = dof_scaling_vector(mesh.nnode, mesh.Lx, 1.0, mat.C0, mat.kappa0);
elseif opts.use_scaling
    su = mat.C0^(-1/2); sp = mat.kappa0^(-1/2);
    s = [su*ones(nmech,1); sp*ones(nelec,1)];
else
    s = ones(nmech+nelec,1);
end
if any(s ~= 1)
    Kbar = diag(sparse(s))*K*diag(sparse(s)); fbar = f.*s;
    bc_val_s = bc_val ./ s(bc_dof);
    [Kred_s, fred_s, freeidx_s] = reduce(Kbar, fbar, bc_dof, bc_val_s);
    xr = Kred_s \ fred_s;
    qbar = zeros(nmech+nelec,1); qbar(freeidx_s) = xr;
    bcv = zeros(nmech+nelec,1); bcv(bc_dof) = bc_val_s;
    qbar = qbar + bcv;                 % place prescribed values back
    q = s.*qbar;                       % transform back to physical DOFs
    if opts.no_cond, k_sc = NaN; else, k_sc = cond_number1(Kred_s); end
    out.Kbar = Kbar; out.S = diag(sparse(s));
else
    xr = Kred \ fred;
    q = zeros(nmech+nelec,1); q(freeidx) = xr;
    bcv = zeros(nmech+nelec,1); bcv(bc_dof) = bc_val;
    q = q + bcv;                       % place prescribed values back
    k_sc = k_raw;
    out.Kbar = K; out.S = speye(nmech+nelec);
end
out.q_u   = q(1:nmech);
out.q_phi = q(nmech+1:end);
out.q     = q;
out.K     = K; out.f = f;
out.cond.raw    = k_raw;
out.cond.scaled = k_sc;
out.cond.improvement = k_raw/k_sc;
out.info = sprintf('coupled solve, %d mech + %d elec DOFs', nmech, nelec);
end

% ---- local helpers ----
function [Kr, fr, freeidx] = reduce(K, f, bcdof, bcval)
[Kr, fr, freeidx, ~] = apply_boundary_conditions(K, f, bcdof, bcval);
end

function c = cond_number1(A)
if issparse(A), c = condest(A); else, c = cond(A); end
end
