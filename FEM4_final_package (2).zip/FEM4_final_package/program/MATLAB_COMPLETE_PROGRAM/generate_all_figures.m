function generate_all_figures()
% GENERATE_ALL_FIGURES  Reproducibly generate and OPEN the complete
% publication figure set from the frozen model.
%
% Stage 1: run every study/benchmark (this COMPUTES the CSV/MAT outputs).
% Stage 2: run every plotting script (READS those outputs and creates the
%          formatted MATLAB figures, left OPEN on screen).
%
% NO image file is written automatically: the user saves each figure
% manually from the MATLAB figure window. No Ghostscript or external
% plotting software is required. The flow is never reversed:
%
%     frozen equations -> MATLAB solve -> CSV/MAT -> plotting script -> figure
%
% Stops only on genuine calculation errors.
root = fileparts(mfilename('fullpath'));
addpath(genpath(root));

fprintf('==============================================================\n');
fprintf(' STAGE 1/2 -- compute the data (studies & benchmarks)\n');
fprintf('==============================================================\n');
benchmark_tier1(false);            % Tier-1 rates (from quoted norms)
benchmark_tier2(false);            % PZT-5H corrected chain -> tier2_benchmark.csv
benchmark_tier3_sensor([50 100 200 500 1000 2000]*1e-9);  % sensor V(h) (this model)
benchmark_tier3_actuator(1.0);     % actuator -> actuator_response.csv
convergence_study();               % -> convergence_study.csv
hcrit_study(false);                % -> hcrit_study.csv/.mat
lambda_study();                    % -> lambda_study.csv
aspect_ratio_study();              % -> aspect_ratio_study.csv/.mat
boundary_condition_study();        % -> boundary_condition_study.csv
field_export(20, 60, 12);          % -> field_export.csv/.mat (spatial fields)

fprintf('\n==============================================================\n');
fprintf(' STAGE 2/2 -- create and format the figures (left open on screen)\n');
fprintf('==============================================================\n');
plot_geometry();                   % model schematic + BFS DOFs
plot_fields();                     % coupled spatial fields (u, v, phi)
plot_validation();                 % Tier-1 / PZT-5H / Tier-3b validation
plot_tier3();                      % flexoelectric sensor V(h)
plot_lambda();                     % figure-of-merit parameter study
plot_aspect_ratio();               % energy-conversion ratio vs L/h
plot_hcrit();                      % critical-thickness power law
plot_boundary_conditions();        % boundary-condition sensitivity
plot_conditioning();               % condition-number reduction

fprintf('\nAll figures are now open in MATLAB figure windows.\n');
fprintf('Save each manually (File > Save As, e.g. vector PDF/EPS).\n');
fprintf('Figure set:\n');
fprintf('  fig1  geometry schematic + BFS DOFs        (plot_geometry)\n');
fprintf('  fig2  coupled spatial fields u, v, phi     (plot_fields)\n');
fprintf('  fig3  validation: Tier-1 / PZT-5H / Tier-3b (plot_validation)\n');
fprintf('  fig4  sensor V(h)                          (plot_tier3)\n');
fprintf('  fig5  Lambda parameter study               (plot_lambda)\n');
fprintf('  fig6  energy-conversion ratio vs L/h       (plot_aspect_ratio)\n');
fprintf('  fig7  critical-thickness power law         (plot_hcrit)\n');
fprintf('  fig8a boundary-condition sensitivity       (plot_boundary_conditions)\n');
fprintf('  fig8b condition-number reduction           (plot_conditioning)\n');
end
