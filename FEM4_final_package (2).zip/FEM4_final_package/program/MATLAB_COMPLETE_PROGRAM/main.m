% MAIN  Top-level entry point of the coupled piezoelectric-flexoelectric
% BFS finite element program.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex (the sole
% authority). See MATLAB_EQUATION_TRACEABILITY.md for the full map.
%
% What main.m does (fast, deterministic):
%   1. adds the project folders to the path;
%   2. runs the verification suite (D_Voigt, B matrices, symmetry,
%      quadrature, dimensions, energy balance, limiting cases);
%   3. runs the analytic benchmark parts (Tier 1 rates reproduced from the
%      quoted norms; Tier 2 full corrected analytic chain);
%   4. prints a summary.
%
% The FEM studies (convergence/hcrit/lambda/aspect-ratio/boundary-condition)
% are run separately via their own scripts; see README.md.
root = fileparts(mfilename('fullpath'));
addpath(fullfile(root,'config'), fullfile(root,'constitutive'), fullfile(root,'fem'), ...
        fullfile(root,'scaling'), fullfile(root,'verification'), fullfile(root,'benchmarks'), ...
        fullfile(root,'studies'), fullfile(root,'plotting'), fullfile(root,'data'), root);

fprintf('==========================================================\n');
fprintf(' Coupled piezoelectric-flexoelectric BFS FEM  (master model)\n');
fprintf('==========================================================\n\n');

fprintf('--- verification suite ---\n');
verify_D_voigt(false);
verify_B_matrices(false);
verify_symmetry(false);
verify_quadrature(false);
verify_strong_form(false);
verify_dimensions(false);
verify_energy_balance(false);
verify_limiting_cases(false);

fprintf('--- benchmark (analytic parts) ---\n');
benchmark_tier1(false);      % reproduce quoted Tier-1 rates
benchmark_tier2(false);      % corrected PZT-5H analytic chain
benchmark_tier3_sensor();    % data-required report (source-reported)
benchmark_tier3_actuator(1.0);

fprintf('==========================================================\n');
fprintf(' main.m done. Run studies separately (see README.md).\n');
fprintf('==========================================================\n');
