DATA EXPORTS ONLY (no figures are written here)
=================================================

This directory holds the scientific-data exports (CSV + MAT) produced by the
studies/benchmarks. Plotting scripts READ these files; they never write
figures here.

To generate the figures: run generate_all_figures (or the individual
plot_* scripts). The MATLAB figures are LEFT OPEN on screen for you to save
manually -- no image file is created automatically.

Files here are regenerated on demand; none is a hidden input to any
calculation (scripts always compute first, then export).
