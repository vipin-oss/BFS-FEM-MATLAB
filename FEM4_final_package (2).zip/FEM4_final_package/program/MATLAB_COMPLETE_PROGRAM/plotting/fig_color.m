function c = fig_color(k)
% FIG_COLOR  k-th color of a colorblind-safe (Okabe-Ito) publication palette.
% The same parameter keeps the same visual identity across all figures.
pal = [0.000 0.447 0.698;   % 1 blue
       0.902 0.624 0.000;   % 2 orange
       0.000 0.620 0.451;   % 3 green
       0.835 0.369 0.000;   % 4 vermillion
       0.337 0.706 0.914;   % 5 sky blue
       0.800 0.475 0.655;   % 6 reddish purple
       0.400 0.400 0.400];  % 7 grey
if nargin < 1, k = 1; end
c = pal(min(max(1, round(k)), size(pal,1)), :);
end
