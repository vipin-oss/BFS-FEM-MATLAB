function fig_defaults()
% FIG_DEFAULTS  Global publication style (SCI-journal typography).
%
% Font: Times New Roman, normal weight, restrained sizes:
%   axis labels 11-12 pt (set per-axes via label_axes),
%   tick labels 9-10 pt (axes FontSize),
%   legend 8.5-10 pt (set per-figure),
%   panel labels 11 pt bold.
% Lines: main ~1.6-1.8 pt, comparison ~1.2 pt, markers 5-7 pt, axes 1.0 pt.
set(0, 'DefaultAxesFontName', 'Times New Roman');
set(0, 'DefaultTextFontName', 'Times New Roman');
set(0, 'DefaultAxesFontSize', 10);       % tick-label size
set(0, 'DefaultLineLineWidth', 1.6);     % main-curve default
set(0, 'DefaultLineMarkerSize', 6);
set(0, 'DefaultAxesLineWidth', 1.0);
end
