function label_axes(ax, xstr, ystr)
% LABEL_AXES  Axis labels at 12 pt Times New Roman (publication size).
xlabel(ax, xstr, 'FontName', 'Times New Roman', 'FontSize', 12);
ylabel(ax, ystr, 'FontName', 'Times New Roman', 'FontSize', 12);
end
