function plot_aspect_ratio()
% PLOT_ASPECT_RATIO  Energy-conversion ratio eta_EM = U_elec/(F v_tip) versus
% L/h (log-log), frozen reduced model. Reads output/aspect_ratio_study.csv and
% output/aspect_ratio_study.mat (run aspect_ratio_study.m). Nothing is
% hard-coded: the points, the fitted high-branch line, and the clearly
% labelled source-reported paper line all come from the computed/loaded values.
% Leaves the figure open for manual saving.
fig_defaults();
f = 'output/aspect_ratio_study.csv';
if ~exist(f,'file'), warning('plot_aspect_ratio: run aspect_ratio_study.m first (missing %s)', f); return; end
d = dlmread(f, ',', 1, 0);
Lh = d(:,1); eta = d(:,12);       % col 12 = eta_EM (dead-load definition)

fig = figure('Color','w');
prepare_figure(3.4, 2.8);
ax = axes; hold(ax,'on');
loglog(ax, Lh, eta, 's', 'Color', fig_color(1), ...
       'LineWidth', 1.6, 'MarkerSize', 5, 'MarkerFaceColor', fig_color(1));
if exist('output/aspect_ratio_study.mat','file')
    S = load('output/aspect_ratio_study.mat', 'results');
    r = S.results;
    Lhc = linspace(min(Lh(Lh>=20)), max(Lh), 60);
    loglog(ax, Lhc, r.A_high*Lhc.^r.p_high, '--', 'Color', [0.3 0.3 0.3], 'LineWidth', 1.2);
    loglog(ax, Lhc, 2.79e-5*Lhc.^1.94, ':', 'Color', fig_color(2), 'LineWidth', 1.2);
    legend(ax, {'computed \eta_{EM}', ...
                sprintf('fit  A=%.3g (L/h)^{%.2f}', r.A_high, r.p_high), ...
                'paper 2.79e-5 (L/h)^{1.94} (source-reported)'}, ...
           'Location', 'northeast', 'FontName', 'Times New Roman', 'FontSize', 8.5);
end
label_axes(ax, 'aspect ratio  L/h', '\eta_{EM} = U_{elec}/(F v_{tip})');
style_axes(ax);
end
