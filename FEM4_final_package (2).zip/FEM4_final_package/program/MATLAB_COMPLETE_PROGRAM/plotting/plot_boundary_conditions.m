function plot_boundary_conditions()
% PLOT_BOUNDARY_CONDITIONS  Boundary-condition sensitivity of the
% flexoelectric cantilever: tip deflection bars (left axis) and potential
% line (right axis). Portable dual-axis overlay (works in MATLAB and Octave).
% Reads output/boundary_condition_study.csv (run boundary_condition_study.m).
% Leaves the figure open for manual saving.
fig_defaults();
f = 'output/boundary_condition_study.csv';
if ~exist(f,'file'), warning('plot_boundary_conditions: run boundary_condition_study.m first (missing %s)', f); return; end
d = dlmread(f, ',', 1, 0);   % variant, tip_v, max_phi

fig = figure('Color','w');
prepare_figure(3.4, 2.8);
cL = fig_color(1); cR = fig_color(2);

axL = axes; hold(axL,'on');
bar(axL, d(:,1), d(:,2)*1e16, 0.5, 'FaceColor', cL, 'EdgeColor', 'none');
set(axL, 'YColor', cL, 'XTick', 1:3, 'XTickLabel', {'clamped','pinned','clamp+slope'});
ylabel(axL, 'tip deflection  [10^{-16} m]', 'Color', cL, 'FontName','Times New Roman','FontSize',11);

axR = axes('Position', get(axL,'Position'), 'Color', 'none', ...
           'XAxisLocation','bottom', 'YAxisLocation','right', ...
           'XTick', [], 'YColor', cR); hold(axR,'on');
plot(axR, d(:,1), d(:,3)*1e10, '-o', 'Color', cR, 'LineWidth', 1.6, 'MarkerSize', 5);
ylabel(axR, 'max |\phi|  [10^{-10} V]', 'Color', cR, 'FontName','Times New Roman','FontSize',11);

xlabel(axL, 'boundary condition', 'FontName','Times New Roman','FontSize',12);
style_axes(axL); style_axes(axR);
end
