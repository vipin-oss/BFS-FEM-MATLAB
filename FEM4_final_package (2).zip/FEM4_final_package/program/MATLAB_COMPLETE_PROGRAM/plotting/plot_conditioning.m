function plot_conditioning()
% PLOT_CONDITIONING  Condition-number reduction by the full DOF scaling
% (raw vs scaled), computed by assembly + condest (no ill-conditioned solve,
% no warnings). No hard-coded results. Leaves the figure open for manual
% saving.
fig_defaults();
mat = material_BaTiO3();
mesh = generate_mesh(8, 2, mat.L_beam, mat.h_beam);
nmech = 8*mesh.nnode; nelec = mesh.nnode;
Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
bc = make_cantilever_bc(mesh);
[Kuu,Kup,Kpp] = assembly(mesh, mat);
K = [Kuu,Kup; Kup',-Kpp];
f = [Fvec; zeros(nelec,1)];

[Kr,~] = apply_boundary_conditions(K, f, bc.dof, bc.val);
k_raw = condest(Kr);
sD = dof_scaling_vector(mesh.nnode, mesh.Lx, 1.0, mat.C0, mat.kappa0);
Kd = diag(sparse(sD))*K*diag(sparse(sD));
[KrD,~] = apply_boundary_conditions(Kd, f.*sD, bc.dof, bc.val./sD(bc.dof));
k_scaled = condest(KrD);

fig = figure('Color','w');
prepare_figure(3.4, 2.8);
ax = axes; hold(ax,'on');
bar(ax, 1, k_raw, 0.5, 'FaceColor', [0.75 0.75 0.75], 'EdgeColor','none');
bar(ax, 2, k_scaled, 0.5, 'FaceColor', fig_color(1), 'EdgeColor','none');
set(ax,'YScale','log','XTick',[1 2],'XTickLabel',{'raw','full DOF scaling'});
ylabel(ax, 'condition number  (condest)', 'FontName','Times New Roman','FontSize',12);
style_axes(ax);
end
