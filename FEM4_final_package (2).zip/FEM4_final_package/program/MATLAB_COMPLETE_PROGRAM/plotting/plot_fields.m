function plot_fields()
% PLOT_FIELDS  Coupled spatial fields of the flexoelectric sensor solve:
%   (a) u displacement, (b) v displacement, (c) electric potential phi.
% Reads output/field_export.csv (run studies/field_export.m first).
% Nodal fields are drawn directly (no interpolation, no hard-coded limits;
% the two displacement panels share a symmetric color scale for comparison).
% Leaves the figure open for manual saving.
fig_defaults();
f = 'output/field_export.csv';
if ~exist(f,'file')
    warning('plot_fields: run studies/field_export.m first (missing %s)', f);
    return;
end
d = dlmread(f, ',', 1, 0);
x = d(:,1); y = d(:,2); u = d(:,3); v = d(:,4); phi = d(:,5);
cmap = fig_colormap(256);

fig = figure('Color','w');
prepare_figure(6.9, 2.8);

uL = max(max(abs(u)), max(abs(v)));   % symmetric limit for u and v

% ---- (a) u ----
ax1 = subplot(1,3,1);
scatter(ax1, x, y, 18, u, 'filled');
caxis(ax1, [-uL uL]); colormap(ax1, cmap);
add_panel_label(ax1, '(a)');
label_axes(ax1, 'x [\mum]', 'y [nm]');
title(ax1, 'u  [nm]', 'FontSize', 11, 'FontWeight', 'normal');
style_axes(ax1); cb1 = colorbar(ax1); colorbar_label(cb1, 'nm');

% ---- (b) v ----
ax2 = subplot(1,3,2);
scatter(ax2, x, y, 18, v, 'filled');
caxis(ax2, [-uL uL]); colormap(ax2, cmap);
add_panel_label(ax2, '(b)');
label_axes(ax2, 'x [\mum]', 'y [nm]');
title(ax2, 'v  [nm]', 'FontSize', 11, 'FontWeight', 'normal');
style_axes(ax2); cb2 = colorbar(ax2); colorbar_label(cb2, 'nm');

% ---- (c) phi ----
ax3 = subplot(1,3,3);
scatter(ax3, x, y, 18, phi, 'filled');
caxis(ax3, [min(phi) max(phi)]); colormap(ax3, cmap);
add_panel_label(ax3, '(c)');
label_axes(ax3, 'x [\mum]', 'y [nm]');
title(ax3, '\phi  [V]', 'FontSize', 11, 'FontWeight', 'normal');
style_axes(ax3); cb3 = colorbar(ax3); colorbar_label(cb3, 'V');
end

function colorbar_label(cb, str)
% Portable colorbar label (MATLAB: cb.Label.String ; Octave: ylabel(cb,str)).
try
    cb.Label.String = str;
    cb.FontName = 'Times New Roman';
    cb.FontSize = 9;
catch
    try, ylabel(cb, str); catch, end
end
end
