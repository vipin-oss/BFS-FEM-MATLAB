function plot_geometry()
% PLOT_GEOMETRY  Model schematic: the 2D nanobeam domain, boundary conditions
% and the 36-DOF BFS convention. Drawn from the ACTUAL model inputs
% (L = 2 um, h = 100 nm, clamped left edge, open circuit, tip load F).
% Leaves the figure open for manual saving (no automatic file export).
fig_defaults();
mat = material_BaTiO3();
L = mat.L_beam; h = mat.h_beam;

fig = figure('Color', 'w');
prepare_figure(6.9, 2.6);

% ---- (a) geometry + BCs ----
ax1 = subplot(1,2,1);
hold(ax1,'on');
XL = L*1e6; YL = h*1e9;    % x in um, y in nm
fill(ax1, [0 XL XL 0], [0 0 YL YL], [0.90 0.94 0.99], 'EdgeColor','k','LineWidth',0.8);
plot(ax1, [0 0], [0 YL], 'r-', 'LineWidth', 3);            % clamped edge
quiver(ax1, XL, YL/2, 0, -0.6*YL/3, 0.9, 'k', 'LineWidth', 1.2, 'MaxHeadSize', 2.0);
text(ax1, XL*0.97, YL*0.32, 'F', 'FontName','Times New Roman','FontSize',10);
plot(ax1, [0 XL], [YL YL], 'k-', 'LineWidth', 0.6);
plot(ax1, [0 XL], [0 0], 'k-', 'LineWidth', 0.6);
text(ax1, XL*0.22, YL*1.10, 'open circuit, D_2 = 0', 'FontName','Times New Roman','FontSize',9);
plot(ax1, [0 0.35*XL], [0 0], 'k-', 'LineWidth', 1.0);
plot(ax1, [0 0], [0 0.5*YL], 'k-', 'LineWidth', 1.0);
text(ax1, 0.35*XL, -0.16*YL, 'x', 'FontSize', 11);
text(ax1, -0.04*XL, 0.5*YL, 'y', 'FontSize', 11);
text(ax1, 0.02, 0.96, '\Omega', 'Units','normalized','FontSize',11);
text(ax1, -0.08*XL, YL/2, 'clamped', 'FontSize', 9, 'Rotation', 90, 'HorizontalAlignment','center');
label_axes(ax1, 'x  [\mum]', 'y  [nm]');
add_panel_label(ax1, '(a)');
axis(ax1, [-0.15*XL 1.12*XL  -0.35*YL 1.28*YL]);
style_axes(ax1);

% ---- (b) BFS DOF convention ----
ax2 = subplot(1,2,2); hold(ax2,'on'); axis(ax2,'off');
add_panel_label(ax2, '(b)');
eX = [0.12 0.88 0.88 0.12 0.12]; eY = [0.15 0.15 0.72 0.72 0.15];
plot(ax2, eX, eY, 'k-', 'LineWidth', 1.1);
nxi = [0.12 0.88 0.88 0.12]; net = [0.15 0.15 0.72 0.72];
plot(ax2, nxi, net, 'o', 'MarkerSize', 6, 'MarkerFaceColor', fig_color(2), 'MarkerEdgeColor','k');
text(ax2, 0.16, 0.78, ...
     sprintf(['per node:  u, u_x, u_y, u_xy\n', ...
              '           v, v_x, v_y, v_xy\n', ...
              '           phi   (4 nodes)']), ...
     'FontName','Times New Roman','FontSize',10, 'VerticalAlignment','top');
text(ax2, 0.02, 0.05, '32 mechanical + 4 electrical DOFs', ...
     'FontName','Times New Roman','FontSize',9, 'Color',[0.3 0.3 0.3]);
end
