function plot_hcrit()
% PLOT_HCRIT  Critical-thickness power law: h_crit vs ell with the independent
% fit and the source-reported paper fit, ALL read from the study output
% (output/hcrit_study.mat, run studies/hcrit_study.m). No hard-coded fit
% coefficients. Leaves the figure open for manual saving.
fig_defaults();
f = 'output/hcrit_study.mat';
if ~exist(f,'file')
    warning('plot_hcrit: run studies/hcrit_study.m first (missing %s)', f);
    return;
end
S = load(f, 'results'); r = S.results;
ell   = r.ell(:)*1e6;           % um (normalized by ell_ref = 1 um)
hcrit = r.hcrit(:)*1e6;         % um
A  = r.A; p  = r.p;             % independent fit (computed by hcrit_study)
Ap = r.paper_A; pp = r.paper_p; % source-reported paper fit

fig = figure('Color','w');
prepare_figure(3.4, 2.8);
ax = axes; hold(ax,'on');
ell_cont = linspace(min(ell)*0.8, max(ell)*1.05, 200);
loglog(ax, ell, hcrit, 's', 'Color', fig_color(1), ...
       'LineWidth', 1.6, 'MarkerSize', 5, 'MarkerFaceColor', fig_color(1));
loglog(ax, ell_cont, A*ell_cont.^p, '-', 'Color', [0.3 0.3 0.3], 'LineWidth', 1.2);
loglog(ax, ell_cont, Ap*ell_cont.^pp, '--', 'Color', fig_color(2), 'LineWidth', 1.2);
legend(ax, {'quoted roots (source-reported)', ...
            sprintf('independent fit  %.3g (\\ell/\\ell_{ref})^{%.2f}', A, p), ...
            sprintf('paper (source-reported)  %.2f (\\ell/\\ell_{ref})^{%.2f}', Ap, pp)}, ...
       'Location', 'northwest', 'FontName', 'Times New Roman', 'FontSize', 8.5);
label_axes(ax, '\ell / \ell_{ref}', 'h_{crit} / \ell_{ref}');
style_axes(ax);
end
