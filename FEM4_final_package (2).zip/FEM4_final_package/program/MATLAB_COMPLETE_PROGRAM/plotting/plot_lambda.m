function plot_lambda()
% PLOT_LAMBDA  Flexoelectric figure-of-merit study: open-circuit potential
% versus Lambda (log-x). Reads output/lambda_study.csv (run lambda_study.m).
% The computed self-stiffening peak emerges from the data; nothing is
% hard-coded. Leaves the figure open for manual saving.
fig_defaults();
f = 'output/lambda_study.csv';
if ~exist(f,'file'), warning('plot_lambda: run lambda_study.m first (missing %s)', f); return; end
d = dlmread(f, ',', 1, 0);   % mu0, Lambda, max_phi
fig = figure('Color','w');
prepare_figure(3.4, 2.8);
ax = axes;
semilogx(ax, d(:,2), d(:,3), '-o', 'Color', fig_color(1), ...
         'LineWidth', 1.6, 'MarkerSize', 5, 'MarkerFaceColor', fig_color(1));
label_axes(ax, '\Lambda = \surd(D_0\kappa_0)/\mu_0', 'max |\phi|  [V]');
style_axes(ax);
end
