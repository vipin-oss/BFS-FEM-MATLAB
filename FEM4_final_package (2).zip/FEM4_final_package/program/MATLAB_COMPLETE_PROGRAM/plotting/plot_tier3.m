function plot_tier3()
% PLOT_TIER3  Flexoelectric sensor: open-circuit voltage versus thickness
% (log-log), frozen reduced model. Reads output/sensor_scaling.csv (generated
% by benchmark_tier3_sensor(h_list)). The paper's V ~ h^-1.0002 regression is
% SOURCE-REPORTED and is NOT drawn from fabricated data.
% Leaves the figure open for manual saving.
fig_defaults();
f = 'output/sensor_scaling.csv';
if ~exist(f,'file')
    warning('plot_tier3: run benchmark_tier3_sensor([h_list]) first (missing %s)', f);
    return;
end
d = dlmread(f, ',', 1, 0);
fig = figure('Color','w');
prepare_figure(3.4, 2.8);
ax = axes;
loglog(ax, d(:,1)*1e9, d(:,2), '-s', 'Color', fig_color(1), ...
       'LineWidth', 1.6, 'MarkerSize', 5, 'MarkerFaceColor', fig_color(1));
label_axes(ax, 'thickness  h  [nm]', 'open-circuit voltage  V  [V]');
style_axes(ax);
end
