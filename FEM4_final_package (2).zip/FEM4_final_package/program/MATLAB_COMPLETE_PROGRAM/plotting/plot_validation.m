function plot_validation()
% PLOT_VALIDATION  Numerical/analytical validation (3 panels):
%   (a) Tier-1 convergence (computed point values; the recomputed r_L2/r_H1/r_G
%       from the quoted norms are annotated);
%   (b) PZT-5H corrected open-circuit tip deflection vs the paper-reported
%       (linearized, source-reported) value;
%   (c) Tier-3b actuator: corner-moment analytical vs FEM tip deflection
%       (the 307.37 pm literature value is NOT plotted as a MATLAB result).
% Reads output/convergence_study.csv, tier2_benchmark.csv, actuator_response.csv.
% Leaves the figure open for manual saving.
fig_defaults();
f1='output/convergence_study.csv'; f2='output/tier2_benchmark.csv'; f3='output/actuator_response.csv';
if ~exist(f1,'file'), warning('plot_validation: run convergence_study.m first'); return; end
if ~exist(f2,'file'), warning('plot_validation: run benchmark_tier2(false) first'); return; end
if ~exist(f3,'file'), warning('plot_validation: run benchmark_tier3_actuator.m first'); return; end

d1 = dlmread(f1, ',', 1, 0);   % nx, ny, tip_u, r_L2, r_H1, r_G
d2 = dlmread(f2, ',', 1, 0);   % k31sq,k31,beta2,E_open_GPa,w_bend,w_shear,w_timo,poisson,fem_tip
d3 = dlmread(f3, ',', 1, 0);   % V0, w_computed, w_analytical, M, paper_eff, paper_bulk

fig = figure('Color','w');
prepare_figure(6.9, 2.8);

% ---- (a) Tier-1 ----
ax1 = subplot(1,3,1); hold(ax1,'on');
plot(ax1, d1(:,1), abs(d1(:,3)), '-o', 'Color', fig_color(1), 'LineWidth',1.6, 'MarkerSize',5);
label_axes(ax1, 'elements in x', '|u(right-mid)|  [m]');
add_panel_label(ax1, '(a)');
style_axes(ax1);
text(ax1, 0.60, 0.30, sprintf('rL2=%.2f  rH1=%.2f  rG=%.2f', d1(1,4), d1(1,5), d1(1,6)), ...
     'Units','normalized','FontName','Times New Roman','FontSize',9, ...
     'BackgroundColor','w','EdgeColor',[0.6 0.6 0.6]);

% ---- (b) PZT-5H ----
ax2 = subplot(1,3,2); hold(ax2,'on');
w_paper = 5.886754e-14;   % paper-reported (source-reported, labelled)
w_corr  = d2(1,7);        % corrected w_timo (computed)
bar(ax2, 1, w_paper*1e14, 0.5, 'FaceColor', [0.75 0.75 0.75], 'EdgeColor','none');
bar(ax2, 2, w_corr*1e14,  0.5, 'FaceColor', fig_color(1), 'EdgeColor','none');
set(ax2,'XTick',[1 2],'XTickLabel',{'paper','corrected'});
ylabel(ax2,'w_{tip}  [10^{-14} m]','FontName','Times New Roman','FontSize',12);
add_panel_label(ax2, '(b)');
style_axes(ax2);
text(ax2, 0.05, 0.92, sprintf('k31^2=%.4f   E_open=%.1f GPa', d2(1,1), d2(1,4)), ...
     'Units','normalized','FontName','Times New Roman','FontSize',9,'VerticalAlignment','top');

% ---- (c) Tier-3b actuator ----
ax3 = subplot(1,3,3); hold(ax3,'on');
w_ana = abs(d3(1,3)); w_fem = abs(d3(1,2));
bar(ax3, 1, w_ana*1e9, 0.5, 'FaceColor', [0.75 0.75 0.75], 'EdgeColor','none');
bar(ax3, 2, w_fem*1e9, 0.5, 'FaceColor', fig_color(1), 'EdgeColor','none');
set(ax3,'XTick',[1 2],'XTickLabel',{'corner-moment','FEM'});
ylabel(ax3,'|w_{tip}|  [nm]','FontName','Times New Roman','FontSize',12);
add_panel_label(ax3, '(c)');
style_axes(ax3);
end
