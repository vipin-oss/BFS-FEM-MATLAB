function prepare_figure(w, h)
% PREPARE_FIGURE  Set the figure's physical (display) size to a publication
% dimension and give it a white background. It does NOT export any image
% file -- the user saves every figure manually from the MATLAB figure window.
%
% Recommended SCI sizes (set by the caller, not forced on screen):
%   single-column 3.3-3.5 in ; double-column 6.8-7.0 in.
if nargin < 1, w = 3.4; end
if nargin < 2, h = 2.8; end
set(gcf, 'Color', 'w', 'Units', 'inches', 'Position', [1 1 w h]);
% (Paper size is set only so that a MANUAL Save-As in MATLAB produces a
% correctly sized file; nothing is written automatically.)
set(gcf, 'PaperUnits', 'inches', 'PaperPosition', [0 0 w h], 'PaperSize', [w h]);
end
