function style_axes(ax)
% STYLE_AXES  Apply the shared axes typography to a given axes handle.
% Tick labels: 9-10 pt (Times New Roman); axes line 1.0 pt; grid on.
set(ax, 'FontName', 'Times New Roman', 'FontSize', 10, ...
        'LineWidth', 1.0, 'Box', 'on', 'TickDir', 'out');
grid(ax, 'on');
try
    set(ax, 'GridAlpha', 0.15, 'MinorGridAlpha', 0.05);
catch
end
end
