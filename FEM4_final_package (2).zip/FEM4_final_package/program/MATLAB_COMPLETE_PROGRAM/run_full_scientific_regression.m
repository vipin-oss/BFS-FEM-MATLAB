function run_full_scientific_regression()
% RUN_FULL_SCIENTIFIC_REGRESSION  One-shot PASS/FAIL regression over the
% complete scientific chain of the implementation against the frozen master.
%
% Executes (in order):
%   1  D_Voigt reconstruction        (verify_D_voigt)
%   2  energy conjugacy / symmetry   (verify_D_voigt + verify_symmetry)
%   3  strong-form coefficients      (verify_strong_form)
%   4  Hermite cardinality + B_e/B_eta/B_phi  (verify_B_matrices)
%   5  element matrices + transpose  (verify_symmetry)
%   6  quadrature exactness          (verify_quadrature)
%   7  Lambda (dual method)          (verify_dimensions)
%   8  energy identity (factor 1/2)  (verify_energy_balance)
%   9  conditioning reconciliation   (verify_conditioning)
%  10  limiting cases                (verify_limiting_cases)
%  11  PZT-5H benchmark              (benchmark_tier2, analytic)
%  12  Tier-1 convergence            (benchmark_tier1, quoted norms)
%  13  h_crit regression             (hcrit_study)
%
% Prints a final summary table of PASS/FAIL.
root = fileparts(mfilename('fullpath'));
addpath(fullfile(root,'config'),fullfile(root,'constitutive'),fullfile(root,'fem'), ...
        fullfile(root,'scaling'),fullfile(root,'verification'),fullfile(root,'benchmarks'), ...
        fullfile(root,'studies'),fullfile(root,'data'),root);

fprintf('===============================================================\n');
fprintf(' FULL SCIENTIFIC REGRESSION  (master model vs Octave implementation)\n');
fprintf('===============================================================\n\n');

R = struct();
R(1).name  = 'D_Voigt reconstruction';            R(1).res  = verify_D_voigt(true);
R(2).name  = 'D_Voigt randomized (N=120)';        R(2).res  = verify_randomized_D(true);
R(3).name  = 'BFS cardinality + B matrices';      R(3).res  = verify_B_matrices(true);
R(4).name  = 'BFS 32-DOF cardinality matrix';     R(4).res  = verify_BFS_cardinality(true);
R(5).name  = 'B-matrix FD step convergence';      R(5).res  = verify_B_fd(true);
R(6).name  = 'element symmetry + transpose';      R(6).res  = verify_symmetry(true);
R(7).name  = 'definiteness signatures';           R(7).res  = verify_definiteness(true);
R(8).name  = 'quadrature exactness';              R(8).res  = verify_quadrature(true);
R(9).name  = 'quadrature blocks (all, multi-AR)'; R(9).res  = verify_quadrature_blocks(true);
R(10).name = 'strong-form coefficients';          R(10).res = verify_strong_form(true);
R(11).name = 'strong-form randomized (N=60)';     R(11).res = verify_randomized_strong_form(true);
R(12).name = 'Lambda dual method + lengths';      R(12).res = verify_dimensions(true);
R(13).name = 'energy identity (factor 1/2)';      R(13).res = verify_energy_balance(true);
R(14).name = 'energy identity (multimesh)';       R(14).res = verify_energy_multimesh(true);
R(15).name = 'conditioning reconciliation';       R(15).res = verify_conditioning(true);
R(16).name = 'limiting cases (8)';                R(16).res = verify_limiting_cases(true);
R(17).name = 'PZT-5H benchmark';                  R(17).res = bench_tier2_summary();
R(18).name = 'Tier-1 convergence (quoted norms)'; R(18).res = bench_tier1_summary();
R(19).name = 'h_crit regression';                 R(19).res = hcrit_summary();
R(20).name = 'notebook cross-check (28 quantities)'; R(20).res = crosscheck_calculation(true);

fprintf('---------------------------------------------------------------\n');
fprintf(' FINAL REGRESSION SUMMARY\n');
fprintf('---------------------------------------------------------------\n');
allok = true;
for k = 1:numel(R)
    ok = R(k).res.all_pass;
    allok = allok && ok;
    fprintf('  %-38s : %s\n', R(k).name, passfail(ok));
end
fprintf('---------------------------------------------------------------\n');
fprintf('  OVERALL: %s\n', passfail(allok));
fprintf('===============================================================\n');
end

function r = bench_tier2_summary()
r = benchmark_tier2(false);
end

function r = bench_tier1_summary()
r = benchmark_tier1(false);
end

function r = hcrit_summary()
r = hcrit_study(false);
end

function s = passfail(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
