function L = characteristic_lengths(D0, C0, kappa0, mu0)
% CHARACTERISTIC_LENGTHS  Internal length scales and the dimensionless
% flexoelectric figure of merit.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part III, Eq. (III_lelastic, III_fflexo, III_Lambda);
%   Part IX, Eq. (IX_lengths) (unit cancellation).
%
%   ell_elastic = sqrt(D0/C0)        [m]  material strain-gradient length
%   f_flexo     = mu0/sqrt(C0*kappa0)[m]  flexoelectric length
%   Lambda      = sqrt(D0*kappa0)/mu0[1]  dimensionless
%
% CRITICAL (master Appendix D, item D5): ell_elastic is DISTINCT from the
% normalization reference ell_ref = 1e-6 m. Do not conflate them.
%
% Inputs: D0 [N], C0 [Pa], kappa0 [F/m], mu0 [C/m].
L.ell_elastic = sqrt(D0/C0);
L.f_flexo     = mu0/sqrt(C0*kappa0);
L.Lambda      = sqrt(D0*kappa0)/mu0;   % == ell_elastic/f_flexo
end
