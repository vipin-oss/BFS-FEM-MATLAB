function out = condition_number(K, Kbar)
% CONDITION_NUMBER  Condition-number comparison before/after scaling.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part X, Eq. (X_ratio, X_before, X_after, X_improvement).
%
% Uses condest (sparse 1-norm estimate) when the matrix is sparse, and
% cond (2-norm, full) otherwise. Reports the ratio out.improvement.
%
% NOTE: the master reports the ~1e22..1e23 -> 1e6..1e7 reduction as
% source-reported (raw dataset absent). This function computes the ACTUAL
% numbers for whatever system it is given and never prints a claimed
% improvement that was not numerically computed.
if issparse(K), out.k_raw = condest(K); else, out.k_raw = cond(K); end
if issparse(Kbar), out.k_scaled = condest(Kbar); else, out.k_scaled = cond(Kbar); end
out.improvement = out.k_raw / out.k_scaled;   % [1]
end
