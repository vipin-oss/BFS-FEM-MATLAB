function T = dof_scaling_vector(nnode, L0, u0, C0, kappa0)
% DOF_SCALING_VECTOR  Non-dimensional DOF scaling derived from the master's
% canonical transformations.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part IX, Eq. (IX_transforms):  x = L0 xbar, u = u0 ubar,
%   phi = phi0 phibar with phi0 = u0 sqrt(C0/kappa0).
%
% Field-scaling DERIVATION of the DOF transformation (not guessed):
%   ubar      = u / u0                              =>  u     = u0 * ubar
%   ubar_,x   = d(u/u0)/d(x/L0) = (L0/u0) u_,x      =>  u_,x  = (u0/L0)   * ubar_,x
%   ubar_,y   = (L0/u0) u_,y                        =>  u_,y  = (u0/L0)   * ubar_,y
%   ubar_,xy  = (L0^2/u0) u_,xy                     =>  u_,xy = (u0/L0^2) * ubar_,xy
%   phibar    = phi / phi0                          =>  phi   = phi0 * phibar
%
% So with q = [u u_x u_y u_xy v v_x v_y v_xy](per node) ; phi(per node),
% the congruence   q = T .* qbar   (elementwise)   gives
%   Kbar = diag(T) K diag(T),   fbar = diag(T) f,   qbar = Kbar\fbar,  q = T.*qbar .
%
% This is a symmetric congruence: it changes the numerical representation
% only, never the physical solution (verified in verify_conditioning.m).
%
% Inputs:
%   nnode  : number of nodes
%   L0     : [m] reference length (chosen; default domain length)
%   u0     : [m] reference displacement (uniform factor, cancels in cond)
%   C0     : [Pa] reference elasticity
%   kappa0 : [F/m] reference permittivity
% Output: T (8*nnode + nnode) x 1 scaling vector.
if nargin < 2 || isempty(L0), L0 = 1.0; end
if nargin < 3 || isempty(u0), u0 = 1.0; end
if nargin < 4 || isempty(C0), C0 = 1.0; end
if nargin < 5 || isempty(kappa0), kappa0 = 1.0; end

nmech = 8*nnode;
T = zeros(nmech + nnode, 1);
phi0 = u0*sqrt(C0/kappa0);          % [V] reference potential (Eq. IX_phi0)
for n = 1:nnode
    b = 8*(n-1);
    T(b+1) = u0;        % u
    T(b+2) = u0/L0;     % u_x
    T(b+3) = u0/L0;     % u_y
    T(b+4) = u0/L0^2;   % u_xy
    T(b+5) = u0;        % v
    T(b+6) = u0/L0;     % v_x
    T(b+7) = u0/L0;     % v_y
    T(b+8) = u0/L0^2;   % v_xy
end
T(nmech+1:end) = phi0;             % phi
end
