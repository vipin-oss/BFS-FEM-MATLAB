function s = nondimensionalize(mat, L0, u0)
% NONDIMENSIONALIZE  Reference scales and canonical transformations.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part IX, Eq. (IX_eps0..IX_U0) reference scales;
%   Eq. (IX_transforms) canonical non-dimensional transformations.
%
% Inputs:
%   mat : material struct (fields C0, kappa0, D0, mu0, ...)
%   L0  : [m] reference length
%   u0  : [m] reference displacement
%
% Output struct s with dimensional reference quantities:
%   eps0, eta0, sigma0, phi0, E0, D0ref, F0, U0   (SI)
% and barred constitutive scales:
%   Cbar, Dbar, kappabar, ebar, mubar.
if nargin < 3, u0 = 1.0; end
C0 = mat.C0; kappa0 = mat.kappa0;
s.eps0   = u0/L0;                        % [1]
s.eta0   = u0/L0^2;                      % [1/m]
s.sigma0 = C0*s.eps0;                    % [Pa]
s.phi0   = u0*sqrt(C0/kappa0);           % [V]
s.E0     = s.phi0/L0;                    % [V/m]
s.D0ref  = kappa0*s.E0;                  % [C/m^2]  (D0ref avoids clash with D0 [N])
s.F0     = s.sigma0*L0^2;                % [N]
s.U0     = C0*u0^2;                      % [J]
% Barred constitutive scales (Eq. IX_transforms)
s.Cbar      = 1;                         % C/C0
s.Dbar      = mat.D0/(C0*L0^2);
s.kappabar  = 1;                         % kappa/kappa0
s.ebar      = 1/sqrt(C0*kappa0);         % scale for e_V
s.mubar     = 1/(L0*sqrt(C0*kappa0));    % scale for mu_V
end
