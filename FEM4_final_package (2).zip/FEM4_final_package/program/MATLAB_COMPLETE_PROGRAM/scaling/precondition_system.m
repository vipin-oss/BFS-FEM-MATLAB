function [Kbar, S] = precondition_system(K, nmech, nelec, C0, kappa0)
% PRECONDITION_SYSTEM  Symmetric congruence preconditioning.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part IX, Eq. (IX_S, IX_congruence); Part X (conditioning).
%
%   S    = diag(C0^(-1/2) I_u , kappa0^(-1/2) I_phi)
%   Kbar = S * K * S
%
% The full saddle matrix K is ordered [u; phi] (nmech + nelec rows).
% All four blocks of Kbar are then O(1).
%
% Inputs: K (sparse or full), nmech, nelec, C0 [Pa], kappa0 [F/m].
assert(size(K,1) == nmech + nelec, 'precondition_system: dimension mismatch');
su = C0^(-1/2);    % [1/Pa^0.5]
sp = kappa0^(-1/2);% [1/(F/m)^0.5]
S = [ su*speye(nmech),      sparse(nmech,nelec);
      sparse(nelec,nmech),  sp*speye(nelec) ];
Kbar = S * K * S;
end
