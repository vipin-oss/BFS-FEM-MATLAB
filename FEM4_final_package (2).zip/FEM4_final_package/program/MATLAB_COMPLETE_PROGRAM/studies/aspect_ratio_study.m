function results = aspect_ratio_study()
% ASPECT_RATIO_STUDY  Energy-conversion ratio eta_EM = U_elec/W_ext versus
% aspect ratio L/h  (final, mesh-converged, audited version).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part XVI, Eq. (XVI_def): eta_EM = U_elec/W_ext, with
%     W_ext = F*v_tip (tip load x tip deflection, DEAD-LOAD product),
%     U_elec = 1/2 int (grad phi)' kappa (grad phi) dOmega;
%   Eq. (XVI_fit): eta_EM = 2.79e-5 (L/h)^1.94, R^2 = 0.9984
%     (SOURCE-REPORTED: the per-point table is not supplied).
%
% PHASE-7 CLOSURE (see FINAL_ASPECT_RATIO_CLOSURE_AUDIT.md + the forensic
% closure): every number below is COMPUTED by this script from the material
% constants, geometry, mesh, full-DOF-scaled FEM solve and the frozen energy
% definitions. Nothing is hard-coded. The full-context CSV is a direct export
% of these computed variables.
fprintf('=== aspect-ratio energy-conversion study (mesh-converged, Ny=12) ===\n');
mat = material_BaTiO3();
L = mat.L_beam;
Lh_list = [5, 7.5, 10, 15, 20, 30, 40, 60];
nLh = numel(Lh_list);

% ---- main sweep (Ny = 12) + a Ny = 8 companion for the convergence flag ----
eta   = zeros(nLh,1); eta_qs = zeros(nLh,1);
Umech = zeros(nLh,1); Uelec = zeros(nLh,1); Ucoup = zeros(nLh,1);
Wext  = zeros(nLh,1); Wqs = zeros(nLh,1);   vtip = zeros(nLh,1);
Uelec8 = zeros(nLh,1); rel_chg = zeros(nLh,1); conv_flag = cell(nLh,1);
Nxs = zeros(nLh,1); Nys = zeros(nLh,1); hs = zeros(nLh,1);

for k = 1:nLh
    Lh = Lh_list(k); h = L/Lh;
    Ny = 12; Nx = max(36, 3*Lh);
    [U_m,U_e,U_c,W,v] = solve_one(L, h, Nx, Ny, mat);
    eta(k) = U_e/W; eta_qs(k) = U_e/(0.5*W);
    Umech(k)=U_m; Uelec(k)=U_e; Ucoup(k)=U_c; Wext(k)=W; Wqs(k)=0.5*W; vtip(k)=v;
    Nxs(k)=Nx; Nys(k)=Ny; hs(k)=h;
    % companion Ny=8 for the mesh-convergence column
    [~,U_e8,~,~,~] = solve_one(L, h, max(24, 2*Lh), 8, mat);
    Uelec8(k) = U_e8;
    rel_chg(k) = abs(U_e8 - U_e)/abs(U_e);
    conv_flag{k} = ternary(rel_chg(k) < 0.02, 'converged(<2%)', 'not-converged');
    fprintf('  L/h=%3d (h=%5.1fnm, %dx%d) : eta_EM=%.4e  U_elec=%.3e J  W_ext=%.3e J  rel_chg=%.2f\n', ...
        Lh, h*1e9, Nx, Ny, eta(k), U_e, W, rel_chg(k));
end

% ---- power-law regression (computed) ----
lx = log(Lh_list'); ly = log(eta);
pf = polyfit(lx, ly, 1);
A = exp(pf(2)); p = pf(1); yfit = polyval(pf, lx);
R2 = 1 - sum((ly-yfit).^2)/sum((ly-mean(ly)).^2);
ih = Lh_list >= 20;
pfh = polyfit(lx(ih), ly(ih), 1);
Ah = exp(pfh(2)); ph = pfh(1); yh = polyval(pfh, lx(ih));
R2h = 1 - sum((ly(ih)-yh).^2)/sum((ly(ih)-mean(ly(ih))).^2);
n = numel(ih); s2 = sum((ly(ih)-yh).^2)/(n-2);
se_p = sqrt(s2/sum((lx(ih)-mean(lx(ih))).^2));  % std err of p (t_{.975,2}=4.303)
fprintf('\n  converged power-law (dead-load eta_EM = A*(L/h)^p):\n');
fprintf('    full 8 points : A = %.4e , p = %.4f , R2 = %.4f\n', A, p, R2);
fprintf('    high branch (L/h>=20) : A = %.4e , p = %.4f , R2 = %.4f , se(p)=%.4f , 95%%CI p=%.4f+-%.4f\n', ...
    Ah, ph, R2h, se_p, ph, 4.303*se_p);
fprintf('  source-reported fit (separate, raw data absent): A = 2.79e-5, p = 1.94, R2 = 0.9984\n');
fprintf('  CONCLUSION: the frozen REDUCED flexoelectric model gives eta_EM DECREASING with L/h\n');
fprintf('  (p ~ -1), opposite to the paper +1.94, because the reduced tensor lacks the\n');
fprintf('  transverse bending coupling mu_2112 (forensically proven). SOURCE-REPORTED fit.\n');

results.Lh = Lh_list; results.L = L*ones(nLh,1); results.h = hs;
results.Nx = Nxs; results.Ny = Nys; results.mu0 = mat.mu0*ones(nLh,1);
results.eta = eta; results.eta_qs = eta_qs;
results.Umech = Umech; results.Uelec = Uelec; results.Ucoup = Ucoup;
results.Wext = Wext; results.Wqs = Wqs; results.vtip = vtip;
results.Uelec_Ny8 = Uelec8; results.rel_mesh_change = rel_chg;
results.mesh_converged = conv_flag;
results.A = A; results.p = p; results.R2 = R2;
results.A_high = Ah; results.p_high = ph; results.R2_high = R2h; results.se_p = se_p;
if ~exist('output','dir'), mkdir('output'); end
export_table(fullfile('output','aspect_ratio_study.csv'), ...
    {'L_over_h','L','h','Nx','Ny','mu0','U_mech','U_elec','U_coup','W_ext','W_qs','eta_EM','eta_qs','tip_v','rel_mesh_change'}, ...
    [Lh_list(:), L*ones(nLh,1), hs, Nxs, Nys, mat.mu0*ones(nLh,1), Umech, Uelec, Ucoup, Wext, Wqs, eta, eta_qs, vtip, rel_chg], ...
    {'','m','m','','','C/m','J','J','J','J','J','','','m',''});
save(fullfile('output','aspect_ratio_study.mat'), 'results');
fprintf('  exported output/aspect_ratio_study.csv and .mat\n');
fprintf('=== aspect-ratio study done ===\n\n');
end

function [U_m,U_e,U_c,W,v] = solve_one(L, h, Nx, Ny, mat)
% One coupled open-circuit sensor solve (full DOF scaling) returning the
% energies and the tip deflection. Uniform-mesh fast assembly (identical to
% assembly.m for the uniform mesh, verified to 0 difference).
mesh = generate_mesh(Nx, Ny, L, h);
Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
bc = make_cantilever_bc(mesh);
nmech = 8*mesh.nnode; nelec = mesh.nnode; a = mesh.a; b = mesh.b;
C  = constitutive_C(mat.C11, mat.C12, mat.C33);
D  = constitutive_D(mat.a1, mat.a2, mat.a3, mat.a4, mat.a5);
eV = piezoelectric_e(mat.e15, mat.e31, mat.e33);
muV= flexoelectric_mu(mat.mu11, mat.mu12, mat.mu44);
kap= dielectric_kappa(mat.kappa11, mat.kappa22);
Kuue = element_stiffness(a,b,C,D);
Kupe = element_coupling(a,b,eV,muV);
Kppe = element_electrical(a,b,kap);
Kuu = sparse(nmech,nmech); Kup = sparse(nmech,nelec); Kpp = sparse(nelec,nelec);
for e = 1:mesh.nelem
    en = mesh.conn(e,:); ed = zeros(1,32);
    for p = 1:4, ed((p-1)*8+(1:8)) = 8*(en(p)-1)+(1:8); end
    Kuu(ed,ed) = Kuu(ed,ed) + Kuue;
    Kup(ed,en) = Kup(ed,en) + Kupe;
    Kpp(en,en) = Kpp(en,en) + Kppe;
end
K = [Kuu, Kup; Kup', -Kpp]; f = [Fvec; zeros(nelec,1)];
sD = dof_scaling_vector(mesh.nnode, mesh.Lx, 1.0, mat.C0, mat.kappa0);
Kd = diag(sparse(sD))*K*diag(sparse(sD)); fd = f.*sD;
[Kdr, fdr, freeidx] = apply_boundary_conditions(Kd, fd, bc.dof, bc.val./sD(bc.dof));
xr = Kdr \ fdr;
qbar = zeros(nmech+nelec,1); qbar(freeidx) = xr;
bcv = zeros(nmech+nelec,1); bcv(bc.dof) = bc.val./sD(bc.dof);
qbar = qbar + bcv; q = sD.*qbar;
q_u = q(1:nmech); q_phi = q(nmech+1:end);
U_m = 0.5*q_u'*Kuu*q_u;
U_e = 0.5*q_phi'*Kpp*q_phi;
U_c = q_u'*Kup*q_phi;
W   = Fvec'*q_u;                       % dead-load F*v_tip (Part XVI)
right = find(abs(mesh.coords(:,1)-L) < 1e-15);
[~, mid] = min(abs(mesh.coords(right,2) - h/2));
v = q_u(8*(right(mid)-1)+5);           % tip v
end

function s = ternary(cond, a, b)
if cond, s = a; else, s = b; end
end
