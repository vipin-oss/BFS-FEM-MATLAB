function results = boundary_condition_study()
% BOUNDARY_CONDITION_STUDY  Higher-order boundary-condition comparison.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part V, Eq. (V_gen_traction, V_double_traction, V_corner, V_charge)
%   boundary operators; Part IX essential vs natural conditions.
%
% Three documented mechanical BC variants of the flexoelectric cantilever
% are solved (all with the same tip load F and open circuit):
%   BC-1: left edge fully clamped (all 8 mech DOFs)      [essential]
%   BC-2: left edge "pinned": u=v=0 only (slopes/twist free).
%         NOTE (PHASE-6 audit): this is a DISPLACEMENT-ONLY constraint, NOT a
%         classical Mindlin simply-supported condition (which in strain-gradient
%         theory involves the double-traction operator r_i = h_ijk n_j n_k,
%         master Eq. V_double_traction). It is a legitimate simplified
%         essential BC, but it is NOT the higher-order simple support.
%   BC-3: left edge u=v=0 AND normal slope u_x=0 only   [partial higher-order]
% PHYSICAL SANITY (PHASE-6 audit): the tip deflections ~2.7e-16 m are CORRECT
% for F=1 nN on this stiff nanobeam (L=2 um, h=100 nm):
%   v_elastic = F L^3/(3 E_bend I) = 2.912e-16 m (Euler-Bernoulli reference,
%   E_bend = E/(1-nu^2) = 109.89 GPa = C11 - C12^2/C11 the plane-strain
%   BENDING modulus; the former 2.38e-16 used the full C11 and was WRONG).
% The three BC variants are near-degenerate because the membrane/curvature
% response dominates; the differences are O(10%) of a sub-nm deflection.
% This is an explicit boundary-condition sensitivity check, not a claim about
% the paper's "higher-order boundary-condition study" (which is source-reported).
%
% Exports: output/boundary_condition_study.csv
fprintf('=== boundary-condition study (flexoelectric cantilever, F=1 nN) ===\n');
mat = material_BaTiO3();
mesh = generate_mesh(16, 2, mat.L_beam, mat.h_beam);
nnode = mesh.nnode; nmech = 8*nnode;
Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
right = find(abs(mesh.coords(:,1) - mesh.Lx) < 1e-15);
[~, mid] = min(abs(mesh.coords(right,2) - mat.h_beam/2));
tipnode = right(mid);
left = find(abs(mesh.coords(:,1)) < 1e-15);

results.bc_name = {'full clamp','pinned','clamp+normal-slope'};
results.tip_v = zeros(1,3); results.tip_phi = zeros(1,3);

for bcno = 1:3
    dof = []; val = [];
    for n = left'
        switch bcno
            case 1   % full clamp: all 8 mech DOFs
                dof = [dof, 8*(n-1)+(1:8)]; val = [val, zeros(1,8)];
            case 2   % pinned: u (1) and v (5) only
                dof = [dof, 8*(n-1)+1, 8*(n-1)+5]; val = [val, 0, 0];
            case 3   % u, v and normal slope u_x (comp 2)
                dof = [dof, 8*(n-1)+1, 8*(n-1)+2, 8*(n-1)+5]; val = [val, 0, 0, 0];
        end
    end
    dof = [dof, nmech+1]; val = [val, 0];   % ground
    bc.dof = dof(:); bc.val = val(:);
    opts.loads = struct('F', Fvec, 'Q', []);
    opts.bc = bc; opts.use_dof_scaling = true; opts.electrical = true;
    out = solve_system(mesh, mat, opts);
    results.tip_v(bcno)   = out.q_u(8*(tipnode-1)+5);
    results.tip_phi(bcno) = max(abs(out.q_phi));
    fprintf('  BC-%d %-18s : tip v = %.4e m, max|phi| = %.4e V\n', ...
        bcno, results.bc_name{bcno}, results.tip_v(bcno), results.tip_phi(bcno));
end
fprintf('  (Euler-Bernoulli elastic reference v_tip = F L^3/(3 E_bend I) = %.4e m,\n', ...
    mat.F_sensor*mat.L_beam^3/(3*(mat.E/(1-mat.nu^2))*(mat.h_beam^3/12)));
fprintf('   with E_bend = E/(1-nu^2) = %.2f GPa)\n', mat.E/(1-mat.nu^2)/1e9);
if ~exist('output','dir'), mkdir('output'); end
export_table(fullfile('output','boundary_condition_study.csv'), {'variant','tip_v','max_phi'}, ...
    [(1:3)', results.tip_v(:), results.tip_phi(:)], {'','m','V'});
save(fullfile('output','boundary_condition_study.mat'), 'results');
fprintf('  exported output/boundary_condition_study.csv and .mat\n');
fprintf('=== boundary-condition study done ===\n\n');
end
