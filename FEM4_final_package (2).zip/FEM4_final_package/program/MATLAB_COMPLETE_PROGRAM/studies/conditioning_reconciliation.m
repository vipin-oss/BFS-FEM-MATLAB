function results = conditioning_reconciliation()
% CONDITIONING_RECONCILIATION  Four independent conditioning studies
% separating the conditioning mechanisms of the coupled BFS system.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part IX (Eq. IX_S, IX_congruence) electromechanical scaling;
%   Part IX (Eq. IX_transforms) non-dimensionalization (which implies the
%   derivative-DOF scaling derived in dof_scaling_vector.m);
%   Part X (Eq. X_ratio, X_before, X_after) conditioning arithmetic.
%
% Studies (each is a symmetric congruence Kbar = diag(T) K diag(T) applied
% to the SAME constrained saddle system, so physics is unchanged):
%   A : raw                      T = 1
%   B : electromechanical only   T = [C0^-1/2 (mech); kappa0^-1/2 (elec)]
%   C : DOF (derivative/twist)   T = [1 1/L0 1/L0 1/L0^2 ...; 1 (elec)]
%   D : combined                 T = full dof_scaling_vector (B and C together)
%
% The condition numbers are COMPUTED (never claimed): 2-norm cond on small
% meshes, condest on larger ones. A thin-mesh sweep performs log-log
% regression cond = A * N^p  (N = elements along the length) for each study.
%
% Physics-invariance check: the combined-scaled solution is transformed
% back and compared to the raw solution (u, phi, tip deflection, energies).
%
% Exports: output/conditioning_reconciliation.csv
p = simulation_parameters();
mat = material_BaTiO3();
C0 = mat.C0; kappa0 = mat.kappa0;
L = mat.L_beam;

fprintf('=== CONDITIONING RECONCILIATION (BaTiO3 beam L=%.1f um, open circuit) ===\n', L*1e6);

% ---------- mesh sweep ----------
meshes = {[4 2], [8 2], [16 2], [32 2]};
nMesh = numel(meshes);
condA = zeros(nMesh,1); condB = zeros(nMesh,1);
condC = zeros(nMesh,1); condD = zeros(nMesh,1);
Ndof = zeros(nMesh,1);

for mi = 1:nMesh
    mesh = generate_mesh(meshes{mi}(1), meshes{mi}(2), L, L/meshes{mi}(1)*2);
    % (aspect ratio Nx x 2 -> square elements; h_y = L/Nx)
    nmech = 8*mesh.nnode; nelec = mesh.nnode;
    Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
    bc = make_cantilever_bc(mesh);
    [Kuu,Kup,Kpp] = assembly(mesh,mat);
    K = [Kuu,Kup; Kup',-Kpp];
    f = [Fvec; zeros(nelec,1)];

    % A: raw
    [Kr,~] = apply_boundary_conditions(K,f,bc.dof,bc.val);
    condA(mi) = cond2(Kr);

    % B: electromechanical (uses the public scaling API precondition_system)
    sB = [C0^(-1/2)*ones(nmech,1); kappa0^(-1/2)*ones(nelec,1)];
    [Kb, ~] = precondition_system(K, nmech, nelec, C0, kappa0);
    [KrB,~] = apply_boundary_conditions(Kb, f.*sB, bc.dof, bc.val./sB(bc.dof));
    condB(mi) = cond2(KrB);

    % C: DOF scaling only
    sC = dof_scaling_vector(mesh.nnode, L, 1.0, 1.0, 1.0);   % u0=1, no elec scale
    Kc = diag(sparse(sC))*K*diag(sparse(sC));
    [KrC,~] = apply_boundary_conditions(Kc, f.*sC, bc.dof, bc.val./sC(bc.dof));
    condC(mi) = cond2(KrC);

    % D: combined (full non-dimensionalization)
    sD = dof_scaling_vector(mesh.nnode, L, 1.0, C0, kappa0);
    Kd = diag(sparse(sD))*K*diag(sparse(sD));
    [KrD,~] = apply_boundary_conditions(Kd, f.*sD, bc.dof, bc.val./sD(bc.dof));
    condD(mi) = cond2(KrD);

    Ndof(mi) = numel(bc.dof) + size(Kr,1);   % total DOFs before elimination
    fprintf('  mesh %2dx%-2d (Nx=%2d): cond A=%.2e  B=%.2e  C=%.2e  D=%.2e\n', ...
        meshes{mi}(1), meshes{mi}(2), meshes{mi}(1), condA(mi), condB(mi), condC(mi), condD(mi));
end

% ---------- thin-mesh asymptotics (log-log) ----------
Nx = cellfun(@(m) m(1), meshes);
pA = polyfit(log(Nx), log(condA), 1);
pB = polyfit(log(Nx), log(condB), 1);
pC = polyfit(log(Nx), log(condC), 1);
pD = polyfit(log(Nx), log(condD), 1);
R2f = @(x,y) 1 - sum((log(y(:)) - polyval(polyfit(log(x(:)),log(y(:)),1), log(x(:)))).^2) ...
                / sum((log(y(:)) - mean(log(y(:)))).^2);

fprintf('  thin-mesh asymptotics  cond = A*Nx^p  (Nx = elements along length):\n');
fprintf('    A (raw)                : A=%.3e  p=%.3f  R^2=%.4f\n', exp(pA(2)), pA(1), R2f(Nx,condA));
fprintf('    B (electromechanical)  : A=%.3e  p=%.3f  R^2=%.4f\n', exp(pB(2)), pB(1), R2f(Nx,condB));
fprintf('    C (DOF-scaled)         : A=%.3e  p=%.3f  R^2=%.4f\n', exp(pC(2)), pC(1), R2f(Nx,condC));
fprintf('    D (combined)           : A=%.3e  p=%.3f  R^2=%.4f\n', exp(pD(2)), pD(1), R2f(Nx,condD));

% ---------- physics invariance (residual form, no raw backslash) ----------
mesh = generate_mesh(8,2, L, L/8*2);
Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
bc = make_cantilever_bc(mesh);
sD = dof_scaling_vector(mesh.nnode, L, 1.0, C0, kappa0);
nmech = 8*mesh.nnode; nelec = mesh.nnode;
[Kuu,Kup,Kpp] = assembly(mesh,mat);
K = [Kuu,Kup; Kup',-Kpp];
f = [Fvec; zeros(nelec,1)];
Kd = diag(sparse(sD))*K*diag(sparse(sD)); fd = f.*sD;
[KrD,frD,freeidx] = apply_boundary_conditions(Kd, fd, bc.dof, bc.val./sD(bc.dof));
xr = KrD \ frD;
qbar = zeros(nmech+nelec,1); qbar(freeidx) = xr;
bcv = zeros(nmech+nelec,1); bcv(bc.dof) = bc.val./sD(bc.dof);
qbar = qbar + bcv;
q_scaled = sD.*qbar;

% physics invariance — residual form (NO raw backslash: the raw system has
% rcond ~ 1e-32 on the nanobeam and its backslash only emits a spurious
% singular-matrix warning). The congruence q = T qbar implies the scaled
% solution transformed back satisfies the ORIGINAL raw system K q = f
% exactly; checking ||K q - f||/||f|| proves scaling preserves physics.
resid = norm(K(freeidx,:)*q_scaled - f(freeidx))/norm(f(freeidx));
right = find(abs(mesh.coords(:,1)-L)<1e-15);
[~,mid] = min(abs(mesh.coords(right,2) - L/8));
tipnode = right(mid);
tip_sc = q_scaled(8*(tipnode-1)+5);
Umech_sc  = 0.5*q_scaled(1:nmech)'*Kuu*q_scaled(1:nmech);
d_u = resid; d_phi = resid;
fprintf('  physics invariance (scaled solution satisfies raw system):\n');
fprintf('    raw-system residual ||Kq-f||/||f|| = %.3e\n', resid);
fprintf('    tip v (physical) %.6e\n', tip_sc);
fprintf('    U_mech (physical) %.6e\n', Umech_sc);

results.meshes = meshes; results.Nx = Nx;
results.cond = [condA condB condC condD];
results.p = [pA(1) pB(1) pC(1) pD(1)];
results.A = [exp(pA(2)) exp(pB(2)) exp(pC(2)) exp(pD(2))];
results.invariance = [d_u d_phi];

if ~exist('output','dir'), mkdir('output'); end
export_table(fullfile('output','conditioning_reconciliation.csv'), ...
    {'Nx','cond_A_raw','cond_B_electro','cond_C_dof','cond_D_combined'}, ...
    [Nx(:), condA, condB, condC, condD], {'','','','',''});
save(fullfile('output','conditioning_reconciliation.mat'), 'results');
fprintf('  exported output/conditioning_reconciliation.csv and .mat\n');
fprintf('=== conditioning reconciliation done ===\n\n');
end

function c = cond2(A)
% 2-norm condition number (full) for small matrices; condest for large.
if issparse(A) && numel(A) > 250000
    c = condest(A);
else
    c = cond(full(A));
end
end
