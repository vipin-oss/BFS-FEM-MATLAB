function results = convergence_study()
% CONVERGENCE_STUDY  Mesh convergence of the Tier-1 simple-shear plate.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part XI, Eq. (XI_tier1_errors, XI_rL2, XI_rH1, XI_rG);
%   Part XIII (mesh convergence protocol).
%
% PHASE-6 SCIENTIFIC AUDIT CLARIFICATION (see FINAL_FOUR_STUDIES_SCIENTIFIC_AUDIT.md):
%   The master's Tier-1 rates r_L2 = 4.00, r_H1 = 2.99, r_G = 2.00 are
%   ERROR-NORM convergence rates, obtained from the quoted error norms
%     e1 = (4.7610e-6, 4.2180e-5, 1.6290e-3)  at 24x8
%     e2 = (2.9760e-7, 5.2860e-6, 4.0740e-4)  at 48x16
%   via r = ln(e1/e2)/ln(2). Those norms are measured against the
%   Shekarchizadeh analytical solution, which is NOT in the master (only the
%   norm VALUES are quoted). The rates themselves ARE recomputable from the
%   quoted norms (and are printed below); the error norms are source-reported.
%
%   This script ADDITIONALLY measures the convergence of a single POINT
%   value (u at the right-edge mid-height node) under documented BCs
%   (bottom clamped, top u=uhat/v=0, sides free). A point value is a
%   DIFFERENT observable from the L2/H1/G error norms and is NOT comparable
%   to the master's rates. It is reported here for completeness only.
fprintf('=== convergence study (Tier-1 simple shear, ell = 0.3 mm) ===\n');
mat = material_Shekarchizadeh(0.3e-3);
meshes = {[12 4], [24 8], [48 16]};

% ---- Part A: recompute the master's error-norm rates from the quoted norms ----
e1 = [4.7610e-6, 4.2180e-5, 1.6290e-3];   % L2, H1, G at 24x8
e2 = [2.9760e-7, 5.2860e-6, 4.0740e-4];   % L2, H1, G at 48x16
names = {'L2','H1','G'};
r_err = zeros(3,1);
fprintf('  [A] master error-norm rates (recomputed from the QUOTED norms):\n');
for k = 1:3
    r_err(k) = log(e1(k)/e2(k))/log(2);
    fprintf('      r_%s = ln(%.4e/%.4e)/ln2 = %.4f   (master reports 4.00/2.99/2.00)\n', ...
        names{k}, e1(k), e2(k), r_err(k));
end
fprintf('      (the error norms e1,e2 are source-reported; the analytical solution\n');
fprintf('       required to recompute them is not in the master)\n');

% ---- Part B: computed point-value convergence (documented BCs) ----
tip = zeros(1,3); dof_free = zeros(1,3);
fprintf('  [B] computed point-value convergence (documented BCs):\n');
for mi = 1:3
    mesh = generate_mesh(meshes{mi}(1), meshes{mi}(2), mat.L, mat.H);
    [tip(mi), dof_free(mi)] = shear_u_tip(mesh, mat, mat.uhat);
    fprintf('      mesh %2dx%-2d : u(right-mid) = %.8e m  (free DOFs %d)\n', ...
        meshes{mi}(1), meshes{mi}(2), tip(mi), dof_free(mi));
end
d1 = abs(tip(1)-tip(2));   % successive difference, coarse pair (12x4 -> 24x8)
d2 = abs(tip(2)-tip(3));   % successive difference, fine pair   (24x8 -> 48x16)
r = log(d1/d2)/log(2);     % successive-difference estimator; the two-interval
                           % form ln|u1-u3|/|u2-u3| is biased high (2.18 here)
ustar = tip(3) + d2/(2^r - 1);   % Richardson-extrapolated free-edge value
fprintf('      successive-difference Richardson point-value rate = %.4f\n', r);
fprintf('      Richardson-extrapolated u* = %.4e m\n', ustar);
fprintf('      NOTE: this is a POINT-VALUE (functional) rate, NOT the L2/H1/G\n');
fprintf('      error-norm rates of [A]; it is not comparable and is not a\n');
fprintf('      publication replacement for them.\n');

results.meshes = meshes; results.tip = tip; results.rate = r;
results.ustar = ustar; results.d1 = d1; results.d2 = d2;
results.r_err = r_err; results.e1 = e1; results.e2 = e2;
header = {'nx','ny','tip_u','r_L2','r_H1','r_G'};
data = [12 4 tip(1) r_err(1) r_err(2) r_err(3);
        24 8 tip(2) r_err(1) r_err(2) r_err(3);
        48 16 tip(3) r_err(1) r_err(2) r_err(3)];
if ~exist('output','dir'), mkdir('output'); end
export_table(fullfile('output','convergence_study.csv'), header, data, ...
    {'','','m','','',''});
save(fullfile('output','convergence_study.mat'), 'results');
fprintf('  exported output/convergence_study.csv and .mat\n');
fprintf('=== convergence study done ===\n\n');
end

function [tip, nfree] = shear_u_tip(mesh, mat, uhat)
nnode = mesh.nnode; nmech = 8*nnode;
dof = []; val = [];
bott = find(abs(mesh.coords(:,2)) < 1e-15);
for n = bott'
    dof = [dof, 8*(n-1)+(1:8)]; val = [val, zeros(1,8)];
end
top = find(abs(mesh.coords(:,2) - mesh.Ly) < 1e-15);
for n = top'
    dof = [dof, 8*(n-1)+1, 8*(n-1)+5]; val = [val, uhat, 0];
end
bc.dof = dof(:); bc.val = val(:);
opts.loads = struct('F', zeros(nmech,1), 'Q', []);
opts.bc = bc; opts.use_dof_scaling = true; opts.electrical = false;
out = solve_system(mesh, mat, opts);
right = find(abs(mesh.coords(:,1)-mesh.Lx) < 1e-15);
[~, mid] = min(abs(mesh.coords(right,2) - mesh.Ly/2));
tip = out.q_u(8*(right(mid)-1)+1);
nfree = numel(out.q_u) - numel(dof);
end
