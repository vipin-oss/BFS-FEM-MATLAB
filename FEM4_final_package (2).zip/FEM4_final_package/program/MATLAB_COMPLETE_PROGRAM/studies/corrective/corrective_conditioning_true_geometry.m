function results = corrective_conditioning_true_geometry()
% CORRECTIVE_CONDITIONING_TRUE_GEOMETRY  (NEW COMPUTED STUDY — Issue A)
% Conditioning study on the TRUE production geometry  L = 2 um, h = 100 nm
% (fixed thickness, 2 elements through thickness), Nx refined 4 -> 32.
%
% This is a corrective companion to conditioning_reconciliation.m, which used
% generate_mesh(Nx, 2, L, L/Nx*2) (square elements, thickness shrinking with
% Nx). Everything here is IDENTICAL to that study except the geometry:
%   - same material_BaTiO3, constitutive matrices, couplings, BCs, DOF order
%   - same four scaling strategies (raw / electromechanical / DOF / combined)
%   - same condition-number definition (cond2: cond for small, condest large)
%   - same full symmetric-congruence scaling via dof_scaling_vector
% Nothing in the production solver is modified; no production output is
% overwritten (new CSV: CONDITIONING_TRUE_GEOMETRY_RESULTS.csv).
%
% Exports: output/CONDITIONING_TRUE_GEOMETRY_RESULTS.csv (+ .mat)
mat = material_BaTiO3();
C0 = mat.C0; kappa0 = mat.kappa0;
L  = mat.L_beam;    % 2e-6 m
h  = mat.h_beam;    % 100e-9 m  (TRUE production thickness, FIXED)

fprintf('=== CORRECTIVE CONDITIONING: TRUE GEOMETRY L=%.1f um, h=%.0f nm ===\n', L*1e6, h*1e9);
fprintf('    (fixed thickness; 2 elements through thickness; Nx = 4..32)\n');

meshes = {[4 2], [8 2], [16 2], [32 2]};
nMesh = numel(meshes);
Nx = zeros(nMesh,1); Ny = zeros(nMesh,1);
nnode = zeros(nMesh,1); nmech = zeros(nMesh,1); nelec = zeros(nMesh,1); nDOF = zeros(nMesh,1);
condA = zeros(nMesh,1); condB = zeros(nMesh,1); condC = zeros(nMesh,1); condD = zeros(nMesh,1);

for mi = 1:nMesh
    mesh = generate_mesh(meshes{mi}(1), meshes{mi}(2), L, h);   % FIXED Ly = h
    nmech(mi) = 8*mesh.nnode; nelec(mi) = mesh.nnode;
    Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
    bc = make_cantilever_bc(mesh);
    [Kuu,Kup,Kpp] = assembly(mesh, mat);
    K = [Kuu, Kup; Kup', -Kpp];
    f = [Fvec; zeros(nelec(mi),1)];

    % A: raw
    [Kr,~] = apply_boundary_conditions(K, f, bc.dof, bc.val);
    condA(mi) = cond2(Kr);

    % B: electromechanical only (public precondition_system, as in original)
    sB = [C0^(-1/2)*ones(nmech(mi),1); kappa0^(-1/2)*ones(nelec(mi),1)];
    [Kb, ~] = precondition_system(K, nmech(mi), nelec(mi), C0, kappa0);
    [KrB,~] = apply_boundary_conditions(Kb, f.*sB, bc.dof, bc.val./sB(bc.dof));
    condB(mi) = cond2(KrB);

    % C: DOF scaling only (u0=1, no electrical scale)
    sC = dof_scaling_vector(mesh.nnode, L, 1.0, 1.0, 1.0);
    Kc = diag(sparse(sC))*K*diag(sparse(sC));
    [KrC,~] = apply_boundary_conditions(Kc, f.*sC, bc.dof, bc.val./sC(bc.dof));
    condC(mi) = cond2(KrC);

    % D: combined (full non-dimensionalization)
    sD = dof_scaling_vector(mesh.nnode, L, 1.0, C0, kappa0);
    Kd = diag(sparse(sD))*K*diag(sparse(sD));
    [KrD,~] = apply_boundary_conditions(Kd, f.*sD, bc.dof, bc.val./sD(bc.dof));
    condD(mi) = cond2(KrD);

    Nx(mi) = meshes{mi}(1); Ny(mi) = meshes{mi}(2);
    nnode(mi) = mesh.nnode; nDOF(mi) = nmech(mi) + nelec(mi);
    fprintf('  mesh %2dx%-2d (Nx=%2d): cond A=%.2e B=%.2e C=%.2e D=%.2e\n', ...
        Nx(mi), Ny(mi), Nx(mi), condA(mi), condB(mi), condC(mi), condD(mi));
end

% ---- physics-invariance residual on one true-geometry mesh (residual form) ----
mesh = generate_mesh(8, 2, L, h);
nmech8 = 8*mesh.nnode; nelec8 = mesh.nnode;
Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
bc = make_cantilever_bc(mesh);
sD = dof_scaling_vector(mesh.nnode, L, 1.0, C0, kappa0);
[Kuu,Kup,Kpp] = assembly(mesh, mat);
K = [Kuu, Kup; Kup', -Kpp];
f = [Fvec; zeros(nelec8,1)];
Kd = diag(sparse(sD))*K*diag(sparse(sD)); fd = f.*sD;
[KrD, frD, freeidx] = apply_boundary_conditions(Kd, fd, bc.dof, bc.val./sD(bc.dof));
xr = KrD \ frD;
qbar = zeros(nmech8+nelec8,1); qbar(freeidx) = xr;
bcv = zeros(nmech8+nelec8,1); bcv(bc.dof) = bc.val./sD(bc.dof);
qbar = qbar + bcv;
q_scaled = sD.*qbar;
resid = norm(K(freeidx,:)*q_scaled - f(freeidx))/norm(f(freeidx));
right = find(abs(mesh.coords(:,1)-L)<1e-15);
[~,mid] = min(abs(mesh.coords(right,2) - h/2));
tipnode = right(mid);
tip_sc = q_scaled(8*(tipnode-1)+5);
Umech_sc = 0.5*q_scaled(1:nmech8)'*Kuu*q_scaled(1:nmech8);
fprintf('  physics invariance (mesh 8x2, true geometry): residual ||Kq-f||/||f|| = %.3e\n', resid);
fprintf('    tip v = %.4e m ; U_mech = %.4e J\n', tip_sc, Umech_sc);

results.L = L; results.h = h;
results.Nx = Nx; results.Ny = Ny; results.nnode = nnode; results.nDOF = nDOF;
results.condA = condA; results.condB = condB; results.condC = condC; results.condD = condD;
results.redAB = condA./condB; results.redAC = condA./condC; results.redAD = condA./condD;
results.log10AD = log10(condA./condD);
results.residual = resid;

if ~exist('output','dir'), mkdir('output'); end
export_table(fullfile('output','CONDITIONING_TRUE_GEOMETRY_RESULTS.csv'), ...
    {'Nx','Ny','Lx_m','Ly_m','nnode','nmech','nelec','totalDOF', ...
     'condA_raw','condB_electro','condC_dof','condD_combined', ...
     'red_AB','red_AC','red_AD','log10_A_over_D'}, ...
    [Nx, Ny, L*ones(nMesh,1), h*ones(nMesh,1), nnode, nmech, nelec, nDOF, ...
     condA, condB, condC, condD, ...
     condA./condB, condA./condC, condA./condD, log10(condA./condD)], ...
    {'','','m','m','','','','','','','','','','','',''});
save(fullfile('output','CONDITIONING_TRUE_GEOMETRY_RESULTS.mat'), 'results');
fprintf('  exported output/CONDITIONING_TRUE_GEOMETRY_RESULTS.csv and .mat\n');
fprintf('=== corrective conditioning study done ===\n\n');
end

function c = cond2(A)
% Identical to the original study's cond2 (same condition-number definition).
if issparse(A) && numel(A) > 250000
    c = condest(A);
else
    c = cond(full(A));
end
end
