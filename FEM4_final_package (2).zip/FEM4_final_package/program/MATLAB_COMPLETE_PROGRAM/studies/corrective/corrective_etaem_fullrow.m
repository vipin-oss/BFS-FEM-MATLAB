function corrective_etaem_fullrow(Lh, Ny)
% Full-quantity single row (same solve as corrective_etaem_mesh_study).
mat = material_BaTiO3(); L = mat.L_beam; h = L/Lh;
Nx = max(36, 3*Lh);
mesh = generate_mesh(Nx, Ny, L, h);
Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
bc = make_cantilever_bc(mesh);
nmech = 8*mesh.nnode; nelec = mesh.nnode; a = mesh.a; b = mesh.b;
C  = constitutive_C(mat.C11, mat.C12, mat.C33);
D  = constitutive_D(mat.a1, mat.a2, mat.a3, mat.a4, mat.a5);
eV = piezoelectric_e(mat.e15, mat.e31, mat.e33);
muV= flexoelectric_mu(mat.mu11, mat.mu12, mat.mu44);
kap= dielectric_kappa(mat.kappa11, mat.kappa22);
Kuue = element_stiffness(a,b,C,D);
Kupe = element_coupling(a,b,eV,muV);
Kppe = element_electrical(a,b,kap);
Kuu = sparse(nmech,nmech); Kup = sparse(nmech,nelec); Kpp = sparse(nelec,nelec);
for e = 1:mesh.nelem
    en = mesh.conn(e,:); ed = zeros(1,32);
    for p = 1:4, ed((p-1)*8+(1:8)) = 8*(en(p)-1)+(1:8); end
    Kuu(ed,ed) = Kuu(ed,ed) + Kuue;
    Kup(ed,en) = Kup(ed,en) + Kupe;
    Kpp(en,en) = Kpp(en,en) + Kppe;
end
K = [Kuu, Kup; Kup', -Kpp]; f = [Fvec; zeros(nelec,1)];
sD = dof_scaling_vector(mesh.nnode, mesh.Lx, 1.0, mat.C0, mat.kappa0);
Kd = diag(sparse(sD))*K*diag(sparse(sD)); fd = f.*sD;
[Kdr, fdr, freeidx] = apply_boundary_conditions(Kd, fd, bc.dof, bc.val./sD(bc.dof));
xr = Kdr \ fdr;
qbar = zeros(nmech+nelec,1); qbar(freeidx) = xr;
bcv = zeros(nmech+nelec,1); bcv(bc.dof) = bc.val./sD(bc.dof);
qbar = qbar + bcv; q = sD.*qbar;
q_u = q(1:nmech); q_phi = q(nmech+1:end);
U_m = 0.5*q_u'*Kuu*q_u; U_e = 0.5*q_phi'*Kpp*q_phi; U_c = q_u'*Kup*q_phi;
W = Fvec'*q_u;
right = find(abs(mesh.coords(:,1) - L) < 1e-15);
[~, mid] = min(abs(mesh.coords(right,2) - h/2));
tipnode = right(mid); v = q_u(8*(tipnode-1)+5);
printf('FULLROW %d %.15e %.15e %.15e %.15e %.15e %.15e %.15e\n', ...
    Ny, v, U_m, U_e, U_c, W, 0.5*W, U_e/W);
end
