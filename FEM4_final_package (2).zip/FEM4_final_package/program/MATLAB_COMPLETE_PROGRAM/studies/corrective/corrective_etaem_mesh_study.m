function results = corrective_etaem_mesh_study()
% CORRECTIVE_ETAEM_MESH_STUDY  (NEW COMPUTED STUDY — Issue B)
% Through-thickness (Ny) refinement of eta_EM at the two high-slenderness
% points L/h = 40 and 60, on the TRUE production geometry with the FROZEN
% production Nx convention (Nx = max(36, 3*L/h)), identical to the production
% aspect_ratio_study.m solve (full DOF scaling, open circuit, tip load F).
%
% The production Ny=12 values are NOT overwritten; they are reproduced here
% for reference and extended to Ny = 16, 24, 32 (and 48 where feasible).
% Everything is COMPUTED from the frozen model; nothing is hard-coded.
%
% Exports: output/ETAEM_HIGH_SLENDERNESS_MESH_STUDY.csv (+ .mat)
mat = material_BaTiO3();
L = mat.L_beam;
Lh_list = [40, 60];
Ny_list = [8, 12, 16, 24, 32, 48];

fprintf('=== CORRECTIVE eta_EM MESH STUDY (high slenderness, Ny refinement) ===\n');
fprintf('    production Nx = max(36, 3*L/h); true geometry L=%.1f um; F=%.1f nN; open circuit\n', L*1e6, mat.F_sensor*1e9);

rows = {};
k = 0;
for li = 1:numel(Lh_list)
    Lh = Lh_list(li); h = L/Lh;
    Nx = max(36, 3*Lh);
    prev_eta = NaN;
    for nj = 1:numel(Ny_list)
        Ny = Ny_list(nj);
        t0 = tic;
        [U_m, U_e, U_c, W, v, nnode, nDOF] = solve_one(L, h, Nx, Ny, mat);
        eta = U_e/W;                    % dead-load definition (production)
        rel_prev = (eta - prev_eta)/prev_eta;   % successive change
        prev_eta = eta;
        k = k + 1;
        rows{k,1} = Lh; rows{k,2} = L; rows{k,3} = h; rows{k,4} = Nx; rows{k,5} = Ny;
        rows{k,6} = L/Nx; rows{k,7} = h/Ny; rows{k,8} = nnode; rows{k,9} = nDOF;
        rows{k,10} = v; rows{k,11} = U_m; rows{k,12} = U_e; rows{k,13} = U_c;
        rows{k,14} = W; rows{k,15} = 0.5*W; rows{k,16} = eta; rows{k,17} = rel_prev;
        fprintf('  L/h=%3d Ny=%2d (%dx%d, DOF=%6d): eta_EM=%.4e  v_tip=%.3e  U_elec=%.3e  rel_prev=%+.4f  [%.1fs]\n', ...
            Lh, Ny, Nx, Ny, nDOF, eta, v, U_e, rel_prev, toc(t0));
    end
    % reference Ny=12 for this L/h
    ref = find(cell2mat(rows(:,1))==Lh & cell2mat(rows(:,5))==12);
    eta12 = rows{ref(1),16};
    fprintf('  -> L/h=%d Ny=12 reference eta_EM = %.4e\n', Lh, eta12);
end

M = cell2mat(rows);
% rel change vs Ny=12
rel12 = nan(size(M,1),1);
for i = 1:size(M,1)
    Lhi = M(i,1);
    r = find(M(:,1)==Lhi & M(:,5)==12);
    rel12(i) = (M(i,16) - M(r,16))/M(r,16);
end
M = [M, rel12];

results.L_over_h = M(:,1); results.L = M(:,2); results.h = M(:,3);
results.Nx = M(:,4); results.Ny = M(:,5);
results.dx = M(:,6); results.dy = M(:,7);
results.nnode = M(:,8); results.nDOF = M(:,9);
results.v_tip = M(:,10); results.U_mech = M(:,11); results.U_elec = M(:,12);
results.U_coup = M(:,13); results.W_ext = M(:,14); results.W_qs = M(:,15);
results.eta_EM = M(:,16); results.rel_prev = M(:,17); results.rel_vs_Ny12 = M(:,18);

if ~exist('output','dir'), mkdir('output'); end
export_table(fullfile('output','ETAEM_HIGH_SLENDERNESS_MESH_STUDY.csv'), ...
    {'L_over_h','L','h','Nx','Ny','dx','dy','nnode','totalDOF', ...
     'v_tip','U_mech','U_elec','U_coup','W_ext','W_qs','eta_EM', ...
     'rel_change_prev','rel_change_vs_Ny12'}, ...
    M, {'','m','m','','','m','m','','','m','J','J','J','J','J','','',''});
save(fullfile('output','ETAEM_HIGH_SLENDERNESS_MESH_STUDY.mat'), 'results');
fprintf('  exported output/ETAEM_HIGH_SLENDERNESS_MESH_STUDY.csv and .mat\n');
fprintf('=== corrective eta_EM mesh study done ===\n\n');
end

function [U_m, U_e, U_c, W, v, nnode, nDOF] = solve_one(L, h, Nx, Ny, mat)
% Identical to aspect_ratio_study.m solve_one: coupled open-circuit sensor
% solve with full DOF scaling; energies and tip deflection returned.
mesh = generate_mesh(Nx, Ny, L, h);
Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
bc = make_cantilever_bc(mesh);
nmech = 8*mesh.nnode; nelec = mesh.nnode; a = mesh.a; b = mesh.b;
C  = constitutive_C(mat.C11, mat.C12, mat.C33);
D  = constitutive_D(mat.a1, mat.a2, mat.a3, mat.a4, mat.a5);
eV = piezoelectric_e(mat.e15, mat.e31, mat.e33);
muV= flexoelectric_mu(mat.mu11, mat.mu12, mat.mu44);
kap= dielectric_kappa(mat.kappa11, mat.kappa22);
Kuue = element_stiffness(a,b,C,D);
Kupe = element_coupling(a,b,eV,muV);
Kppe = element_electrical(a,b,kap);
Kuu = sparse(nmech,nmech); Kup = sparse(nmech,nelec); Kpp = sparse(nelec,nelec);
for e = 1:mesh.nelem
    en = mesh.conn(e,:); ed = zeros(1,32);
    for p = 1:4, ed((p-1)*8+(1:8)) = 8*(en(p)-1)+(1:8); end
    Kuu(ed,ed) = Kuu(ed,ed) + Kuue;
    Kup(ed,en) = Kup(ed,en) + Kupe;
    Kpp(en,en) = Kpp(en,en) + Kppe;
end
K = [Kuu, Kup; Kup', -Kpp]; f = [Fvec; zeros(nelec,1)];
sD = dof_scaling_vector(mesh.nnode, mesh.Lx, 1.0, mat.C0, mat.kappa0);
Kd = diag(sparse(sD))*K*diag(sparse(sD)); fd = f.*sD;
[Kdr, fdr, freeidx] = apply_boundary_conditions(Kd, fd, bc.dof, bc.val./sD(bc.dof));
xr = Kdr \ fdr;
qbar = zeros(nmech+nelec,1); qbar(freeidx) = xr;
bcv = zeros(nmech+nelec,1); bcv(bc.dof) = bc.val./sD(bc.dof);
qbar = qbar + bcv; q = sD.*qbar;
q_u = q(1:nmech); q_phi = q(nmech+1:end);
U_m = 0.5*q_u'*Kuu*q_u;
U_e = 0.5*q_phi'*Kpp*q_phi;
U_c = q_u'*Kup*q_phi;
W = Fvec'*q_u;                 % dead-load product (= F*v_tip for tip v-load)
right = find(abs(mesh.coords(:,1) - L) < 1e-15);
[~, mid] = min(abs(mesh.coords(right,2) - h/2));
tipnode = right(mid);
v = q_u(8*(tipnode-1)+5);
nnode = mesh.nnode; nDOF = nmech + nelec;
end
