function etaem_dump_profiles(Lh, Ny)
% ETAEM_DUMP_PROFILES  Solve (L/h, Ny) with production API and dump:
%   ROWS  = through-thickness U_elec (Ny values, ey=1 bottom .. Ny top)
%   COLS  = along-length U_elec (Nx values, ex=1 clamp .. Nx tip)
%   ELEM  = per-element (ex, ey, U_elec) for the spatial heatmap
% to CSVs under output/forensic/. No new physics; production solve only.
mat = material_BaTiO3(); L = mat.L_beam; h = L/Lh;
Nx = max(36, 3*Lh);
mesh = generate_mesh(Nx, Ny, L, h);
nmech = 8*mesh.nnode; nelec = mesh.nnode; a = mesh.a; b = mesh.b;
kap = dielectric_kappa(mat.kappa11, mat.kappa22);
Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
bc = make_cantilever_bc(mesh);
[Kuu,Kup,Kpp] = assembly(mesh, mat);
K = [Kuu, Kup; Kup', -Kpp]; f = [Fvec; zeros(nelec,1)];
sD = dof_scaling_vector(mesh.nnode, mesh.Lx, 1.0, mat.C0, mat.kappa0);
Kd = diag(sparse(sD))*K*diag(sparse(sD)); fd = f.*sD;
[Kdr, fdr, freeidx] = apply_boundary_conditions(Kd, fd, bc.dof, bc.val./sD(bc.dof));
xr = Kdr \ fdr;
qbar = zeros(nmech+nelec,1); qbar(freeidx) = xr;
bcv = zeros(nmech+nelec,1); bcv(bc.dof) = bc.val./sD(bc.dof);
qbar = qbar + bcv; q = sD.*qbar;
q_u = q(1:nmech); q_phi = q(nmech+1:end);
[gp, gw] = gauss_legendre_4x4();
Ue_row = zeros(Ny,1); Ue_col = zeros(Nx,1);
Ue_el = zeros(mesh.nelem,3);
for e = 1:mesh.nelem
    en = mesh.conn(e,:); ed = zeros(1,32);
    for p = 1:4, ed((p-1)*8+(1:8)) = 8*(en(p)-1)+(1:8); end
    qe = q_u(ed); qp = q_phi(en);
    u = 0;
    for i = 1:4, for j = 1:4
        Bp = B_phi_matrix(gp(i), gp(j), a, b);
        gphi = Bp*qp;
        u = u + 0.5*(gphi'*kap*gphi)*(a*b)*gw(i)*gw(j);
    end, end
    ey = mod(e-1,Ny)+1; ex = floor((e-1)/Ny)+1;
    Ue_row(ey) = Ue_row(ey) + u;
    Ue_col(ex) = Ue_col(ex) + u;
    Ue_el(e,:) = [ex, ey, u];
end
if ~exist('output/forensic','dir'), mkdir('output','forensic'); end
dlmwrite(sprintf('output/forensic/rows_Lh%d_Ny%d.csv', Lh, Ny), [(1:Ny)', Ue_row], 'precision', '%.15e');
dlmwrite(sprintf('output/forensic/cols_Lh%d_Ny%d.csv', Lh, Ny), [(1:Nx)', Ue_col], 'precision', '%.15e');
dlmwrite(sprintf('output/forensic/elem_Lh%d_Ny%d.csv', Lh, Ny), Ue_el, 'precision', '%.15e');
printf('DONE %d %d %.6e\n', Lh, Ny, sum(Ue_row));
end
