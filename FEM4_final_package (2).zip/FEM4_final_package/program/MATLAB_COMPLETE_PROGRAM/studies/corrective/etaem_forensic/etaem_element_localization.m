function etaem_element_localization(Lh, Ny)
% ETAEM_ELEMENT_LOCALIZATION  Element-wise decomposition of the dielectric
% energy U_elec and the strain-gradient energy U_grad for one (L/h, Ny) solve
% on the TRUE production geometry (full DOF scaling, open circuit, tip F).
% Computes, per element, the Gauss-quadrature contributions and aggregates
% them by column (x) and row (y) to expose WHERE the mesh-dependent energy
% is localized. Uses only production API. Writes one CSV block to stdout.
mat = material_BaTiO3(); L = mat.L_beam; h = L/Lh;
Nx = max(36, 3*Lh);
mesh = generate_mesh(Nx, Ny, L, h);
nmech = 8*mesh.nnode; nelec = mesh.nnode; a = mesh.a; b = mesh.b;
C  = constitutive_C(mat.C11, mat.C12, mat.C33);
Dv = constitutive_D(mat.a1, mat.a2, mat.a3, mat.a4, mat.a5);
kap= dielectric_kappa(mat.kappa11, mat.kappa22);
Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
bc = make_cantilever_bc(mesh);
% assemble
[Kuu,Kup,Kpp] = assembly(mesh, mat);
K = [Kuu, Kup; Kup', -Kpp]; f = [Fvec; zeros(nelec,1)];
sD = dof_scaling_vector(mesh.nnode, mesh.Lx, 1.0, mat.C0, mat.kappa0);
Kd = diag(sparse(sD))*K*diag(sparse(sD)); fd = f.*sD;
[Kdr, fdr, freeidx] = apply_boundary_conditions(Kd, fd, bc.dof, bc.val./sD(bc.dof));
xr = Kdr \ fdr;
qbar = zeros(nmech+nelec,1); qbar(freeidx) = xr;
bcv = zeros(nmech+nelec,1); bcv(bc.dof) = bc.val./sD(bc.dof);
qbar = qbar + bcv; q = sD.*qbar;
q_u = q(1:nmech); q_phi = q(nmech+1:end);

% ---- element-wise energies (4x4 Gauss) ----
[gp, gw] = gauss_legendre_4x4();
Ue = zeros(mesh.nelem,1);  % dielectric 0.5 (grad phi)' kappa (grad phi)
Ug = zeros(mesh.nelem,1);  % strain-gradient 0.5 eta' D eta
Uel= zeros(mesh.nelem,1);  % classical elastic 0.5 eps' C eps
for e = 1:mesh.nelem
    en = mesh.conn(e,:);
    ed = zeros(1,32);
    for p = 1:4, ed((p-1)*8+(1:8)) = 8*(en(p)-1)+(1:8); end
    qe = q_u(ed); qp = q_phi(en);
    for i = 1:4, for j = 1:4
        Bp = B_phi_matrix(gp(i), gp(j), a, b);
        Be = B_e_matrix(gp(i), gp(j), a, b);
        Bt = B_eta_matrix(gp(i), gp(j), a, b);
        gphi = Bp*qp; eps = Be*qe; eta = Bt*qe;
        Ue(e)  = Ue(e)  + 0.5*(gphi'*kap*gphi)*(a*b)*gw(i)*gw(j);
        Ug(e)  = Ug(e)  + 0.5*(eta'*Dv*eta)*(a*b)*gw(i)*gw(j);
        Uel(e) = Uel(e) + 0.5*(eps'*C*eps)*(a*b)*gw(i)*gw(j);
    end, end
end
Ue_tot = sum(Ue); Ug_tot = sum(Ug); Uel_tot = sum(Uel);
Ue_mat = 0.5*q_phi'*Kpp*q_phi;   % matrix-form cross-check

% ---- column/row aggregation ----
% mesh nodes: node index = (ix-1)*(Ny+1)+iy ; element (ex,ey) index e=(ex-1)*Ny+ey
col = zeros(Nx,1); row = zeros(Ny,1);
for ex = 1:Nx, for ey = 1:Ny
    e = (ex-1)*Ny + ey;
    col(ex) = col(ex) + Ue(e);
    row(ey) = row(ey) + Ue(e);
end, end
f_clamp = col(1)/Ue_tot;  f_tip = col(Nx)/Ue_tot;
f_col12 = (col(1)+col(2))/Ue_tot;
f_top = row(Ny)/Ue_tot; f_bot = row(1)/Ue_tot;
f_mid = sum(row(2:Ny-1))/Ue_tot;
% corners (clamp-top, clamp-bottom)
f_corner = 0;
for ey = [1 Ny]
    e = (1-1)*Ny + ey; f_corner = f_corner + Ue(e);
end
f_corner = f_corner/Ue_tot;
% gradient-energy localization
gcol = zeros(Nx,1);
for ex = 1:Nx, for ey = 1:Ny, gcol(ex) = gcol(ex) + Ug((ex-1)*Ny+ey); end, end
g_clamp = gcol(1)/Ug_tot; g_tip = gcol(Nx)/Ug_tot;

printf('LOC %d %d %d %.6e %.6e %.6e %.6e %.6e %.6e %.6e %.6e %.6e %.6e %.6e %.6e\n', ...
  Lh, Ny, Nx, Ue_tot, Ug_tot, Uel_tot, Ue_mat, ...
  f_clamp, f_tip, f_col12, f_top, f_bot, f_mid, f_corner, g_clamp, g_tip);
% nodal phi along clamped edge and centerline for locality
x0 = find(abs(mesh.coords(:,1)) < 1e-15);   % clamp nodes
xc = find(abs(mesh.coords(:,2) - h/2) < 1e-14); % centerline
[~,ordx] = sort(mesh.coords(xc,1));
phic = q_phi(xc(ordx));
phimax0 = max(abs(q_phi(x0)));
phimaxL = max(abs(q_phi(find(abs(mesh.coords(:,1)-L)<1e-15))));
printf('PHI %d %d %.6e %.6e %.6e %.6e\n', Lh, Ny, max(abs(q_phi)), phimax0, phimaxL, max(abs(phic)));
end
