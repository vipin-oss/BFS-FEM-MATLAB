function etaem_field_probe(Lh, Ny)
% ETAEM_FIELD_PROBE  Element-wise max of |grad phi| and |P|=|mu eta| plus
% through-thickness and along-length profiles of U_elec, for one (L/h, Ny).
% Production API only. Prints a diagnostic block.
mat = material_BaTiO3(); L = mat.L_beam; h = L/Lh;
Nx = max(36, 3*Lh);
mesh = generate_mesh(Nx, Ny, L, h);
nmech = 8*mesh.nnode; nelec = mesh.nnode; a = mesh.a; b = mesh.b;
kap= dielectric_kappa(mat.kappa11, mat.kappa22);
muV= flexoelectric_mu(mat.mu11, mat.mu12, mat.mu44);
Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
bc = make_cantilever_bc(mesh);
[Kuu,Kup,Kpp] = assembly(mesh, mat);
K = [Kuu, Kup; Kup', -Kpp]; f = [Fvec; zeros(nelec,1)];
sD = dof_scaling_vector(mesh.nnode, mesh.Lx, 1.0, mat.C0, mat.kappa0);
Kd = diag(sparse(sD))*K*diag(sparse(sD)); fd = f.*sD;
[Kdr, fdr, freeidx] = apply_boundary_conditions(Kd, fd, bc.dof, bc.val./sD(bc.dof));
xr = Kdr \ fdr;
qbar = zeros(nmech+nelec,1); qbar(freeidx) = xr;
bcv = zeros(nmech+nelec,1); bcv(bc.dof) = bc.val./sD(bc.dof);
qbar = qbar + bcv; q = sD.*qbar;
q_u = q(1:nmech); q_phi = q(nmech+1:end);
[gp, gw] = gauss_legendre_4x4();
Emax=0; Earg=[0 0]; Pmax=0; Parg=[0 0]; Ue_row=zeros(Ny,1); Ue_col=zeros(Nx,1);
for e = 1:mesh.nelem
    en = mesh.conn(e,:); ed = zeros(1,32);
    for p = 1:4, ed((p-1)*8+(1:8)) = 8*(en(p)-1)+(1:8); end
    qe = q_u(ed); qp = q_phi(en);
    for i = 1:4, for j = 1:4
        Bp = B_phi_matrix(gp(i), gp(j), a, b);
        Bt = B_eta_matrix(gp(i), gp(j), a, b);
        gphi = Bp*qp; eta = Bt*qe; P = muV*eta;
        En = norm(gphi); Pn = norm(P);
        if En>Emax, Emax=En; Earg=[e i j]; end
        if Pn>Pmax, Pmax=Pn; Parg=[e i j]; end
        Ue_row_e = 0.5*(gphi'*kap*gphi)*(a*b)*gw(i)*gw(j);
        ey = mod(e-1,Ny)+1; ex = floor((e-1)/Ny)+1;
        Ue_row(ey) = Ue_row(ey) + Ue_row_e;
        Ue_col(ex) = Ue_col(ex) + Ue_row_e;
    end, end
end
% locate max element
[eE,~,~]=deal(Earg); eyE=mod(eE-1,Ny)+1; exE=floor((eE-1)/Ny)+1;
[eP,~,~]=deal(Parg); eyP=mod(eP-1,Ny)+1; exP=floor((eP-1)/Ny)+1;
printf('PROBE %d %d %.6e %.6e %d %d %.6e %d %d\n', Lh, Ny, Emax, Pmax, exE, eyE, max(Ue_col), exP, eyP);
printf('ROWS '); for k=1:Ny, printf('%.3e ', Ue_row(k)); end; printf('\n');
printf('COLS '); for k=1:5, printf('%.3e ', Ue_col(k)); end; printf('... '); for k=Nx-4:Nx, printf('%.3e ', Ue_col(k)); end; printf('\n');
end
