function results = field_export(Lh, Nx, Ny)
% FIELD_EXPORT  Solve the coupled flexoelectric sensor problem on the
% nanobeam and export the nodal spatial fields (x, y, u, v, phi) for the
% 2D contour figures.
%
% Everything here is COMPUTED from the frozen model (full DOF scaling,
% open circuit, tip load F): nothing is hard-coded or read from a CSV.
%
% Inputs: Lh = L/h (default 20), Nx x Ny mesh (default 80 x 12).
% Exports: output/field_export.csv  (x[um], y[nm], u[nm], v[nm], phi[V]).
if nargin < 1, Lh = 20; end
if nargin < 2, Nx = 80; end
if nargin < 3, Ny = 12; end

mat = material_BaTiO3();
L = mat.L_beam; h = L/Lh;
mesh = generate_mesh(Nx, Ny, L, h);
Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
bc = make_cantilever_bc(mesh);
nmech = 8*mesh.nnode; nelec = mesh.nnode; a = mesh.a; b = mesh.b;

C  = constitutive_C(mat.C11, mat.C12, mat.C33);
D  = constitutive_D(mat.a1, mat.a2, mat.a3, mat.a4, mat.a5);
eV = piezoelectric_e(mat.e15, mat.e31, mat.e33);
muV= flexoelectric_mu(mat.mu11, mat.mu12, mat.mu44);
kap= dielectric_kappa(mat.kappa11, mat.kappa22);
Kuue = element_stiffness(a,b,C,D);
Kupe = element_coupling(a,b,eV,muV);
Kppe = element_electrical(a,b,kap);
Kuu = sparse(nmech,nmech); Kup = sparse(nmech,nelec); Kpp = sparse(nelec,nelec);
for e = 1:mesh.nelem
    en = mesh.conn(e,:); ed = zeros(1,32);
    for p = 1:4, ed((p-1)*8+(1:8)) = 8*(en(p)-1)+(1:8); end
    Kuu(ed,ed) = Kuu(ed,ed) + Kuue;
    Kup(ed,en) = Kup(ed,en) + Kupe;
    Kpp(en,en) = Kpp(en,en) + Kppe;
end
K = [Kuu, Kup; Kup', -Kpp]; f = [Fvec; zeros(nelec,1)];
sD = dof_scaling_vector(mesh.nnode, mesh.Lx, 1.0, mat.C0, mat.kappa0);
Kd = diag(sparse(sD))*K*diag(sparse(sD)); fd = f.*sD;
[Kdr, fdr, freeidx] = apply_boundary_conditions(Kd, fd, bc.dof, bc.val./sD(bc.dof));
xr = Kdr \ fdr;
qbar = zeros(nmech+nelec,1); qbar(freeidx) = xr;
bcv = zeros(nmech+nelec,1); bcv(bc.dof) = bc.val./sD(bc.dof);
qbar = qbar + bcv; q = sD.*qbar;
q_u = q(1:nmech); q_phi = q(nmech+1:end);

% nodal fields
x = mesh.coords(:,1)*1e6;   % um
y = mesh.coords(:,2)*1e9;   % nm
u = q_u(1:8:end)*1e9;       % nm
v = q_u(5:8:end)*1e9;       % nm
phi = q_phi;                % V

% quick summary
fprintf('field_export (L/h=%d, mesh %dx%d): max|u|=%.3e nm, max|v|=%.3e nm, max|phi|=%.3e V\n', ...
    Lh, Nx, Ny, max(abs(u)), max(abs(v)), max(abs(phi)));

% build the valid output structure FIRST (so the data export below is well
% defined and the function returns a valid structure)
results.x = x; results.y = y; results.u = u; results.v = v; results.phi = phi;
results.Lh = Lh; results.Nx = Nx; results.Ny = Ny; results.L = L; results.h = h;

% data export only (CSV + MAT) -- no image files are produced here
if ~exist('output','dir'), mkdir('output'); end
export_table(fullfile('output','field_export.csv'), ...
    {'x_um','y_nm','u_nm','v_nm','phi_V'}, [x, y, u, v, phi], ...
    {'um','nm','nm','nm','V'});
save(fullfile('output','field_export.mat'), 'results');
fprintf('  exported output/field_export.csv and .mat\n');
end
