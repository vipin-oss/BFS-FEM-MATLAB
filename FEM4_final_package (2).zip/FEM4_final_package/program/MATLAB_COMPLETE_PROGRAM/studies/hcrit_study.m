function results = hcrit_study(do_fem)
% HCRIT_STUDY  Critical-thickness power law: independent regression on the
% four source-reported roots + optional FEM root-finding machinery.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part XIV, Eq. (XIV_f) f(h) = |V_coupled - V_pure|/|V_pure| - 0.05 = 0;
%   Eq. (XIV_roots) the four quoted roots;
%   Part XV, Eq. (XV_fit_ours) independent regression,
%   Eq. (XV_paper_fit) the source-reported paper fit.
%
% INDEPENDENT REGRESSION (documented): the four roots quoted in the master
% are the only h_crit data available; the fit below reproduces
%   A = 24.20, p = 0.8998, R^2 = 0.99984.
% The paper's A = 23.76, p = 0.90, R^2 = 0.9990 used additional
% (unavailable) data and is kept SEPARATE as source-reported.
%
% Normalization: ell_ref = 1 um (paper's ell_0) is a chosen reference, NOT
% the material length ell_elastic = 0.2726 nm.
%
% OPTIONAL FEM (do_fem = true): runs the f(h) root problem with fzero on a
% small mesh for one ell to demonstrate the machinery; reproducing the
% paper's roots exactly requires its (unavailable) mesh sequence/raw data.
if nargin < 1, do_fem = false; end
fprintf('=== h_crit power-law study ===\n');
ell   = [0.25 0.50 0.75 1.00]*1e-6;        % m
hcrit = [6.9353 12.9840 18.8471 24.0201]*1e-6;  % m  (source-reported roots)
ell_ref = 1e-6;                             % normalization reference (paper's ell_0)

% --- independent regression on the four roots ---
lx = log(ell/ell_ref); ly = log(hcrit/ell_ref);
pfit = polyfit(lx, ly, 1);
A = exp(pfit(2)); pp = pfit(1);
yfit = polyval(pfit, lx);
R2 = 1 - sum((ly-yfit).^2)/sum((ly-mean(ly)).^2);
fprintf('  independent fit on 4 quoted roots: A = %.4f, p = %.4f, R^2 = %.6f\n', A, pp, R2);
fprintf('  -> h_crit/ell_ref = %.4f (ell/ell_ref)^%.4f\n', A, pp);
fprintf('  paper (source-reported, separate): A = 23.76, p = 0.90, R^2 = 0.9990\n');
fprintf('  (paper fit used additional unsupplied data; not reconstructible here)\n');

results.ell = ell; results.hcrit = hcrit;
results.A = A; results.p = pp; results.R2 = R2;
results.paper_A = 23.76; results.paper_p = 0.90; results.paper_R2 = 0.9990;
% regression gate: independent fit must match A=24.20, p=0.8998 within 0.5 %.
results.all_pass = abs(A-24.20)/24.20 < 5e-3 && abs(pp-0.8998)/0.8998 < 5e-3 && R2 > 0.999;

if do_fem
    fprintf('  --- optional FEM fzero root for ell = 0.5 um (small mesh, demo) ---\n');
    hroot = fem_hcrit_root(0.5e-6);
    fprintf('  FEM fzero h_crit (mesh 16x2, this model) = %.4f um (paper: 12.9840 um; source-reported)\n', hroot*1e6);
    results.fem_root = hroot;
else
    results.fem_root = nan;
    fprintf('  FEM root-finding SKIPPED (pass do_fem=true); paper roots are source-reported.\n');
end
if ~exist('output','dir'), mkdir('output'); end
export_table(fullfile('output','hcrit_study.csv'), ...
    {'ell_um','hcrit_um','A','p','R2','paper_A','paper_p'}, ...
    [ell(:)*1e6, hcrit(:)*1e6, repmat(A,numel(ell),1), repmat(pp,numel(ell),1), ...
     repmat(R2,numel(ell),1), repmat(results.paper_A,numel(ell),1), repmat(results.paper_p,numel(ell),1)], ...
    {'um','um','','','','',''});
save(fullfile('output','hcrit_study.mat'), 'results');
fprintf('  exported output/hcrit_study.csv and .mat\n');
fprintf('=== h_crit study done ===\n\n');
end

function hroot = fem_hcrit_root(ell)
% f(h) = |V_coupled(h) - V_pure(h)|/|V_pure(h)| - 0.05, root by fzero.
% Documented: small mesh 16x2; D0 = C0*ell^2 sets the gradient length.
mat0 = material_BaTiO3();
C0 = mat0.C11;
hroot = nan;
hlo = 4e-6; hhi = 30e-6;
fh = @(h) hcrit_f(h, mat0, C0, ell);
if fh(hlo)*fh(hhi) > 0
    fprintf('    bracket does not straddle root (f(%.1f)=%.3f, f(%.1f)=%.3f)\n', ...
        hlo*1e6, fh(hlo), hhi*1e6, fh(hhi));
    return;
end
hroot = fzero(fh, [hlo, hhi]);
end

function f = hcrit_f(h, mat0, C0, ell)
% V_coupled: D = C0*ell^2 ; V_pure: D = 0
L = mat0.L_beam;
mesh = generate_mesh(16, 2, L, h);
Fvec = apply_tip_load(mesh, mat0.F_sensor, 'v');
bc = make_cantilever_bc(mesh);
% coupled: D = C0*ell^2 ; pure: D = 0
matC = set_gradient(mat0, C0*ell^2);
matP = set_gradient(mat0, 0);
Vc = sensor_max_phi(mesh, matC, Fvec, bc);
Vp = sensor_max_phi(mesh, matP, Fvec, bc);
f = abs(Vc - Vp)/abs(Vp) - 0.05;
end

function mat = set_gradient(mat0, D0)
mat = mat0;
mat.a1 = 0; mat.a2 = 0; mat.a3 = 0;
mat.a4 = 0.5*D0; mat.a5 = 0.5*D0;   % 2(a4+a5) = D0
end

function V = sensor_max_phi(mesh, mat, Fvec, bc)
opts.loads = struct('F', Fvec, 'Q', []);
opts.bc = bc; opts.use_dof_scaling = true; opts.electrical = true;
out = solve_system(mesh, mat, opts);
V = max(abs(out.q_phi));
end
