function results = lambda_study_refined()
% LAMBDA_STUDY_REFINED  Through-thickness refinement check of the Figure-5
% flexoelectric figure-of-merit sweep (companion to lambda_study.m).
%
% Purpose (final submission patch): the baseline sweep of lambda_study.m uses
% the 16x2 production mesh, and the manuscript reports that clamp-layer
% electrical quantities converge slowly with through-thickness refinement
% (max|phi| at mu0=1e-6: 8x1: 3.2e-10 -> 16x2: 2.96e-10 -> 32x4: 2.65e-10;
% 60x12 field export: 1.90e-10 V).  This script repeats the EXACT same sweep
% (same mu0 grid, material constants, BCs, tip load, DOF scaling and
% observable max|phi|) on refined meshes 32x4 and 60x12, so that the
% robustness of the rise-maximum-fall (self-stiffening) behaviour and of the
% peak location can be assessed against through-thickness refinement.
%
% The ONLY differences to lambda_study.m are:
%   (1) the meshes (32x4 and 60x12 instead of 16x2);
%   (2) opts.no_cond = true, which skips the diagnostic-only condition-number
%       estimates inside solve_system (condest on the raw ~1e30-conditioned
%       60x12 system is prohibitively slow in Octave); the solution vector is
%       unaffected by this option.
%
% Output: output/lambda_study_refined.csv and .mat
%   columns: mu0 [C/m], Lambda [], max_phi_32x4 [V], max_phi_60x12 [V]
fprintf('=== Lambda study REFINED (32x4 and 60x12, same sweep as lambda_study) ===\n');
mat0 = material_BaTiO3();
D0 = mat0.D0; kappa0 = mat0.kappa0;
L = mat0.L_beam; h = mat0.h_beam;
mu0_list = logspace(-7.6, -5.6, 10);          % C/m, identical grid to lambda_study
n = numel(mu0_list);
Lambda = sqrt(D0*kappa0)./mu0_list(:);
meshes = [32 4; 60 12];
V = zeros(n, 2);
for m = 1:2
    nx = meshes(m,1); ny = meshes(m,2);
    fprintf('--- mesh %dx%d ---\n', nx, ny);
    t0 = tic;
    mesh = generate_mesh(nx, ny, L, h);
    for k = 1:n
        mat = mat0;
        mat.mu0  = mu0_list(k);
        mat.mu11 = mu0_list(k); mat.mu12 = mu0_list(k); mat.mu44 = 0;
        Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
        bc = make_cantilever_bc(mesh);
        opts.loads = struct('F', Fvec, 'Q', []);
        opts.bc = bc; opts.use_dof_scaling = true; opts.electrical = true;
        opts.no_cond = true;
        out = solve_system(mesh, mat, opts);
        V(k,m) = max(abs(out.q_phi));
        fprintf('  mu0 = %.2e : Lambda = %.4e : max|phi| = %.4e V (%.0f s elapsed)\n', ...
            mu0_list(k), Lambda(k), V(k,m), toc(t0));
    end
    [Vmax, imax] = max(V(:,m));
    fprintf('  mesh %dx%d PEAK: max|phi| = %.4e V at mu0 = %.2e (Lambda = %.4e)\n', ...
        nx, ny, Vmax, mu0_list(imax), Lambda(imax));
end
results.mu0 = mu0_list(:); results.Lambda = Lambda;
results.V_32x4 = V(:,1); results.V_60x12 = V(:,2);
if ~exist('output','dir'), mkdir('output'); end
export_table(fullfile('output','lambda_study_refined.csv'), ...
    {'mu0','Lambda','max_phi_32x4','max_phi_60x12'}, ...
    [mu0_list(:), Lambda, V(:,1), V(:,2)], {'C/m','','V','V'});
save(fullfile('output','lambda_study_refined.mat'), 'results');
fprintf('exported output/lambda_study_refined.csv and .mat\n');
fprintf('=== lambda study refined done ===\n');
end
