function results = crosscheck_calculation(quiet)
% CROSSCHECK_CALCULATION  Notebook <-> MATLAB cross-validation.
%
% Every quantity below is COMPUTED here from the material/geometry inputs
% (never copied from the notebook). The "master" column holds the frozen
% notebook value used only as a REFERENCE for the comparison; the "matlab"
% column is the value this script recomputes independently.
%
% Exports: MATLAB_CALCULATION_CROSSCHECK.csv (root of the project).
%
% Classification per row: COMPUTED / RECOMPUTED-FROM-SUPPLIED-DATA /
% SOURCE-REPORTED / DIAGNOSTIC / NOT-REPRODUCIBLE.
if nargin < 1, quiet = false; end

Q = {};   % {name, master_eq, master_val, matlab_val, class}

% ---- BaTiO3 baseline + characteristic lengths (all computed) ----
mB = material_BaTiO3();
C11 = mB.C11; C12 = mB.C12; C33 = mB.C33;
D0 = 2*(mB.a1+mB.a2+mB.a3+mB.a4+mB.a5);
Lc = characteristic_lengths(D0, mB.C0, mB.kappa0, mB.mu0);
Q(end+1,:) = addrow('BaTiO3 C11 [GPa]', 'XI_C11_BT', 134.615385, C11/1e9, 'COMPUTED');
Q(end+1,:) = addrow('BaTiO3 C12 [GPa]', 'XI_C12_BT', 57.692308, C12/1e9, 'COMPUTED');
Q(end+1,:) = addrow('BaTiO3 C33 [GPa]', 'XI_C33_BT', 38.461538, C33/1e9, 'COMPUTED');
Q(end+1,:) = addrow('D0 [N]', 'Table A', 1.0e-8, D0, 'COMPUTED');
Q(end+1,:) = addrow('ell_elastic [m]', 'III_lelastic', 2.7255e-10, Lc.ell_elastic, 'COMPUTED');
Q(end+1,:) = addrow('f_flexo [m]', 'III_fflexo', 2.5916e-8, Lc.f_flexo, 'COMPUTED');
Q(end+1,:) = addrow('Lambda [-]', 'III_Lambda', 1.0517e-2, Lc.Lambda, 'COMPUTED');

% ---- PZT-5H corrected chain (all computed) ----
mP = material_PZT5H();
k31sq = mP.e31^2/(mP.E*mP.kappa22);   % e31 magnitude (|e31|=16.6)
k31 = sqrt(k31sq); beta2 = k31sq/(1+k31sq);
Eopen = mP.E/(1-k31sq);
Lb=mP.L_beam; hb=mP.h_beam; bb=mP.b_beam; Fb=mP.F_beam;
I = bb*hb^3/12;
w_bend = Fb*Lb^3/(3*Eopen*I);
G = Eopen/(2*(1+mP.nu)); w_shear = Fb*Lb/((5/6)*G*bb*hb);
w_timo = w_bend + w_shear;
Q(end+1,:) = addrow('k31^2 [-]', 'XI_k31_result', 0.151070, k31sq, 'COMPUTED');
Q(end+1,:) = addrow('k31 [-]', 'XI_k31_result', 0.3887, k31, 'COMPUTED');
Q(end+1,:) = addrow('beta^2 [-]', 'XI_beta', 0.131243, beta2, 'COMPUTED');
Q(end+1,:) = addrow('E_open [GPa]', 'XI_Eopen_exact', 71.3839, Eopen/1e9, 'COMPUTED');
Q(end+1,:) = addrow('w_bend [m]', 'XI_wbend', 5.6035e-14, w_bend, 'COMPUTED');
Q(end+1,:) = addrow('w_shear [m]', 'XI_wshear', 4.4044e-16, w_shear, 'COMPUTED');
Q(end+1,:) = addrow('w_timo [m]', 'XI_wtimo', 5.6475e-14, w_timo, 'COMPUTED');
Q(end+1,:) = addrow('1 - nu^2 [-]', 'XI_poisson', 0.9039, 1-mP.nu^2, 'COMPUTED');

% ---- Tier-1 rates (recomputed from the supplied quoted norms) ----
e1 = [4.7610e-6, 4.2180e-5, 1.6290e-3];
e2 = [2.9760e-7, 5.2860e-6, 4.0740e-4];
r = log(e1./e2)/log(2);
Q(end+1,:) = addrow('Tier-1 r_L2 [-]', 'XI_rL2', 4.00, r(1), 'RECOMPUTED-FROM-SUPPLIED-DATA');
Q(end+1,:) = addrow('Tier-1 r_H1 [-]', 'XI_rH1', 2.99, r(2), 'RECOMPUTED-FROM-SUPPLIED-DATA');
Q(end+1,:) = addrow('Tier-1 r_G [-]', 'XI_rG', 2.00, r(3), 'RECOMPUTED-FROM-SUPPLIED-DATA');

% ---- h_crit independent regression (computed from the 4 quoted roots) ----
ell = [0.25 0.50 0.75 1.00]*1e-6; hcrit = [6.9353 12.9840 18.8471 24.0201]*1e-6;
pf = polyfit(log(ell/1e-6), log(hcrit/1e-6), 1);
hc_A = exp(pf(2)); hc_p = pf(1);
yf = polyval(pf, log(ell/1e-6)); hc_R2 = 1 - sum((log(hcrit/1e-6)-yf).^2)/sum((log(hcrit/1e-6)-mean(log(hcrit/1e-6))).^2);
Q(end+1,:) = addrow('h_crit A [-]', 'XV_fit_ours', 24.2011, hc_A, 'COMPUTED');
Q(end+1,:) = addrow('h_crit p [-]', 'XV_fit_ours', 0.8998, hc_p, 'COMPUTED');
Q(end+1,:) = addrow('h_crit R2 [-]', 'XV_R2_ours', 0.99984, hc_R2, 'COMPUTED');

% ---- Tier-3b corner-moment analytical (computed) ----
V0=1.0; w_ana = (mB.mu12+2*mB.mu44)/2*V0*mB.L_beam^2/(2*mB.C11*(mB.h_beam^3/12));
Q(end+1,:) = addrow('Tier-3b corner moment [N]', 'XII-cornermechanism', (mB.mu12+2*mB.mu44)/2, (mB.mu12+2*mB.mu44)/2*V0, 'COMPUTED');
Q(end+1,:) = addrow('Tier-3b w_analytical [m]', 'XI_tier3b(model)', 8.9143e-8, w_ana, 'COMPUTED');

% ---- source-reported (no raw data) ----
Q(end+1,:) = addrow('Tier-3 V ~ h^p p [-]', 'XI_tier3_fit', -1.0002, NaN, 'SOURCE-REPORTED');
Q(end+1,:) = addrow('Tier-3b paper w_eff [m]', 'XI_tier3b', 307.37e-12, NaN, 'SOURCE-REPORTED');
Q(end+1,:) = addrow('eta_EM paper A [-]', 'XVI_fit', 2.79e-5, NaN, 'SOURCE-REPORTED');
Q(end+1,:) = addrow('eta_EM paper p [-]', 'XVI_fit', 1.94, NaN, 'SOURCE-REPORTED');
Q(end+1,:) = addrow('conditioning 1e22->1e6', 'X_before/after', NaN, NaN, 'SOURCE-REPORTED');

% ---- assemble table ----
n = size(Q,1);
results.name = Q(:,1); results.eq = Q(:,2);
results.master = cellfun(@num2str_e, Q(:,3), 'UniformOutput', false);
results.matlab = cellfun(@num2str_e, Q(:,4), 'UniformOutput', false);
results.class = Q(:,5);

% numeric diff where both are numbers
absd = zeros(n,1); reld = zeros(n,1); st = cell(n,1);
for k = 1:n
    mv = Q{k,3}; xv = Q{k,4};
    if isnumeric(mv) && isnumeric(xv) && ~isnan(mv) && ~isnan(xv)
        absd(k) = abs(xv-mv); reld(k) = absd(k)/abs(mv);
        st{k} = 'MATCH'   ; if reld(k) > 5e-3, st{k}='MISMATCH'; end
    else
        absd(k)=NaN; reld(k)=NaN; st{k}='NOT-RECONSTRUCTIBLE';
    end
end
results.abs_diff = absd; results.rel_diff = reld; results.status = st;

% ---- export CSV (root of project) ----
root = fileparts(fileparts(mfilename('fullpath')));
fid = fopen(fullfile(root,'MATLAB_CALCULATION_CROSSCHECK.csv'),'w');
fprintf(fid,'Quantity,MasterEquation,MasterValue,MATLABValue,AbsDiff,RelDiff,Status,Class\n');
for k = 1:n
    fprintf(fid,'%s,%s,%s,%s,%.6e,%.6e,%s,%s\n', ...
        Q{k,1}, Q{k,2}, results.master{k}, results.matlab{k}, absd(k), reld(k), st{k}, Q{k,5});
end
fclose(fid);

results.all_pass = ~any(strcmp(st,'MISMATCH'));
if ~quiet
    fprintf('crosscheck_calculation: %d quantities written to MATLAB_CALCULATION_CROSSCHECK.csv\n', n);
    fprintf('  matches=%d  mismatches=%d  not-reconstructible=%d\n', ...
        sum(strcmp(st,'MATCH')), sum(strcmp(st,'MISMATCH')), sum(strcmp(st,'NOT-RECONSTRUCTIBLE')));
    fprintf('  OVERALL: %s\n\n', ternary(results.all_pass,'PASS','FAIL'));
end
end

function row = addrow(name, eq, mv, xv, cls)
row = {name, eq, mv, xv, cls};
end

function s = num2str_e(x)
if isnumeric(x) && ~isnan(x), s = sprintf('%.6e', x); else, s = 'NaN'; end
end
function s = ternary(c,a,b)
if c, s = a; else, s = b; end
end
