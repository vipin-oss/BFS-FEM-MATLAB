function results = verify_BFS_cardinality(quiet)
% VERIFY_BFS_CARDINALITY  Complete 32x32 nodal-cardinality matrix of the BFS
% element, verified as the identity.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VII, Eq. (VII_hermite_nodal) nodal properties;
%   Part VII, Eq. (VII_bfs, VII_interp).
%
% Construction (no shortcut): for source node p (1..4) and source DOF
% d (1..8 = [u,u_x,u_y,u_xy,v,v_x,v_y,v_xy]), the interpolant is one of the
% 8 basis products (u-family N1..N4 or v-family N1..N4 of node p). At each
% target node q the four nodal functionals
%   1: value, 2: d/dx, 3: d/dy, 4: d^2/dxdy
% are applied to the u-family interpolant (rows 1-4) and to the v-family
% interpolant (rows 5-8). The 32x32 matrix M(f-of-q, d-of-p) must equal the
% identity: each DOF is 1 under its own functional at its own node and 0
% under every other functional/node.
%
% Also verifies the Hermite basis endpoints H(+-1), H'(+-1), H''(+-1).
if nargin < 1, quiet = false; end
a = 0.7; b = 0.4;                    % arbitrary half-widths
nodes_xi  = [-1,1,1,-1];
nodes_eta = [-1,-1,1,1];

% ---- Hermite endpoint values ----
hv = hermite_cubic([-1, 1]);
H_expected = struct('H01', [1 0], 'H02', [0 1], 'H11', [0 0], 'H12', [0 0]);
Hp_expected= struct('H01', [0 0], 'H02', [0 0], 'H11', [1 0], 'H12', [0 1]);
herr = 0;
for nm = {'H01','H02','H11','H12'}
    herr = max(herr, max(abs(hv.(nm{1}) - H_expected.(nm{1}))));
    herr = max(herr, max(abs(hv.([nm{1} 'p']) - Hp_expected.(nm{1}))));
end

% ---- 32x32 cardinality matrix ----
M = zeros(32,32);
for q = 1:4                       % target node
    xi = nodes_xi(q); eta = nodes_eta(q);
    for p = 1:4                   % source node
        d = bfs_shape_derivatives(p, xi, eta, a, b);
        N = bfs_shape_functions(p, xi, eta, a, b);
        % rows 1..4: functionals on u-family ; cols 1..4 (u-family of node p)
        M((q-1)*8+1, (p-1)*8+1) = N(1);
        M((q-1)*8+2, (p-1)*8+1) = d.Nx(1);
        M((q-1)*8+3, (p-1)*8+1) = d.Ny(1);
        M((q-1)*8+4, (p-1)*8+1) = d.Nxy(1);
        M((q-1)*8+1, (p-1)*8+2) = N(2);
        M((q-1)*8+2, (p-1)*8+2) = d.Nx(2);
        M((q-1)*8+3, (p-1)*8+2) = d.Ny(2);
        M((q-1)*8+4, (p-1)*8+2) = d.Nxy(2);
        M((q-1)*8+1, (p-1)*8+3) = N(3);
        M((q-1)*8+2, (p-1)*8+3) = d.Nx(3);
        M((q-1)*8+3, (p-1)*8+3) = d.Ny(3);
        M((q-1)*8+4, (p-1)*8+3) = d.Nxy(3);
        M((q-1)*8+1, (p-1)*8+4) = N(4);
        M((q-1)*8+2, (p-1)*8+4) = d.Nx(4);
        M((q-1)*8+3, (p-1)*8+4) = d.Ny(4);
        M((q-1)*8+4, (p-1)*8+4) = d.Nxy(4);
        % rows 5..8: functionals on v-family ; cols 5..8 (v-family of node p)
        M((q-1)*8+5, (p-1)*8+5) = N(1);
        M((q-1)*8+6, (p-1)*8+5) = d.Nx(1);
        M((q-1)*8+7, (p-1)*8+5) = d.Ny(1);
        M((q-1)*8+8, (p-1)*8+5) = d.Nxy(1);
        M((q-1)*8+5, (p-1)*8+6) = N(2);
        M((q-1)*8+6, (p-1)*8+6) = d.Nx(2);
        M((q-1)*8+7, (p-1)*8+6) = d.Ny(2);
        M((q-1)*8+8, (p-1)*8+6) = d.Nxy(2);
        M((q-1)*8+5, (p-1)*8+7) = N(3);
        M((q-1)*8+6, (p-1)*8+7) = d.Nx(3);
        M((q-1)*8+7, (p-1)*8+7) = d.Ny(3);
        M((q-1)*8+8, (p-1)*8+7) = d.Nxy(3);
        M((q-1)*8+5, (p-1)*8+8) = N(4);
        M((q-1)*8+6, (p-1)*8+8) = d.Nx(4);
        M((q-1)*8+7, (p-1)*8+8) = d.Ny(4);
        M((q-1)*8+8, (p-1)*8+8) = d.Nxy(4);
    end
end
errM = max(max(abs(M - eye(32))));
results.hermite_error = herr;
results.cardinality_error = errM;
results.M = M;
results.all_pass = (herr < 1e-13) && (errM < 1e-13);
if ~quiet
    fprintf('verify_BFS_cardinality:\n');
    fprintf('  Hermite endpoints H(+-1), H''(+-1)      : max |err| = %.3e  [tol 1e-13] %s\n', herr, pf(herr<1e-13));
    fprintf('  32x32 cardinality matrix M == I         : max |err| = %.3e  [tol 1e-13] %s\n', errM, pf(errM<1e-13));
    fprintf('  (full 32-DOF matrix verified; no shortcut)\n');
    fprintf('  OVERALL: %s\n\n', pf(results.all_pass));
end
end
function s = pf(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
