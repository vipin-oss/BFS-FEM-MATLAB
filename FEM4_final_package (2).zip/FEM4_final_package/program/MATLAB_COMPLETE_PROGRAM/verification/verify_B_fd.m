function results = verify_B_fd(quiet)
% VERIFY_B_FD  Finite-difference convergence of the B-matrix derivatives
% over MULTIPLE step sizes (documents the cancellation floor).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VIII, Eq. (VIII_dNx..VIII_dNxy) derivative entries.
%
% For random interior points, the analytic Nx/Ny/Nxx/Nyy/Nxy are compared
% with central finite differences at steps h_fd = 1e-3,1e-4,1e-5,1e-6,1e-7
% (in PHYSICAL units, applied via xi = xi0 + h/a). The first-derivative
% error decreases like h^2 then hits the roundoff floor (~1e-13 at h~1e-4);
% the second-derivative error has its optimum at h ~ 1e-4 (error ~1e-8)
% and DEGRADES at smaller steps because of catastrophic cancellation. This
% is the expected, documented behavior (not a bug): the analytic derivatives
% are exact, and the previous single-tolerance checks used h=1e-4 for second
% derivatives for exactly this reason.
if nargin < 1, quiet = false; end
rng(7);
a = 0.6; b = 0.3;
steps = [1e-3, 1e-4, 1e-5, 1e-6, 1e-7];
err1 = zeros(numel(steps),1); err2 = zeros(numel(steps),1);
for s = 1:numel(steps)
    h = steps(s);
    e1 = 0; e2 = 0;
    for t = 1:12
        xi = 2*rand-1; eta = 2*rand-1;
        for node = 1:4
            d = bfs_shape_derivatives(node, xi, eta, a, b);
            for k = 1:4
                Np = bfs_shape_functions(node, xi+h/a, eta, a, b);
                Nm = bfs_shape_functions(node, xi-h/a, eta, a, b);
                fd_x = (Np(k)-Nm(k))/(2*h);
                e1 = max(e1, abs(d.Nx(k)-fd_x));

                Npp = bfs_shape_functions(node, xi+h/a, eta, a, b);
                Nmm = bfs_shape_functions(node, xi-h/a, eta, a, b);
                N0  = bfs_shape_functions(node, xi, eta, a, b);
                fd_xx = (Npp(k)-2*N0(k)+Nmm(k))/(h^2);
                e2 = max(e2, abs(d.Nxx(k)-fd_xx));
            end
        end
    end
    err1(s) = e1; err2(s) = e2;
end
[min1, i1] = min(err1); [min2, i2] = min(err2);
results.steps = steps; results.err_first = err1; results.err_second = err2;
results.min_first = min1; results.min_second = min2;
% acceptance: first-derivative floor < 1e-9 at some step (theoretical
% central-difference floor ~ eps^(2/3) ~ 4e-11); second-derivative optimum
% < 1e-6 (h ~ 1e-4), which is the cancellation-limited accuracy.
results.all_pass = (min1 < 1e-9) && (min2 < 1e-6);
if ~quiet
    fprintf('verify_B_fd (central differences, max over 12 random points x 4 nodes x 4 funcs):\n');
    fprintf('  h_fd      |err| first-derivative   |err| second-derivative\n');
    for s = 1:numel(steps)
        fprintf('  %.0e   %.3e             %.3e\n', steps(s), err1(s), err2(s));
    end
    fprintf('  min first-derivative err %.3e @ h=%.0e  [floor 1e-9 ] %s\n', min1, steps(i1), pf(min1<1e-9));
    fprintf('  min second-deriv err    %.3e @ h=%.0e  [floor 1e-6 ] %s (cancellation-limited)\n', min2, steps(i2), pf(min2<1e-6));
    fprintf('  OVERALL: %s\n\n', pf(results.all_pass));
end
end
function s = pf(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
