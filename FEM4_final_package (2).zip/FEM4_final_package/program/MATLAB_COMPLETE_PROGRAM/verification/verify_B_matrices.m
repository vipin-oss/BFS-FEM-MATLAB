function results = verify_B_matrices(quiet)
% VERIFY_B_MATRICES  Verify BFS nodal cardinality and the derivative chains
% entering B_e, B_eta, B_phi against finite differences.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VII, Eq. (VII_hermite_nodal) nodal properties;
%   Part VIII, Eq. (VIII_dNx..VIII_dNxy) derivative entries;
%   Eq. (VIII_Be, VIII_Beta, VIII_Bphi).
%
% Checks:
%  (1) nodal cardinality: each BFS function is 1 for its own DOF and 0 for
%      all others at the four nodes;
%  (2) Nx, Ny, Nxx, Nyy, Nxy match finite differences of the shape
%      functions in physical space;
%  (3) B_eta * q_u reproduces etaV = [u,xx; u,xy; v,xy; v,yy; u,xy+v,xx; u,yy+v,xy]
%      and B_e * q_u reproduces epsV for a random element DOF vector;
%  (4) B_phi rows equal dNp/dx, dNp/dy of the bilinear Lagrange functions.
if nargin < 1, quiet = false; end
p = simulation_parameters();
tol = p.tol_eq;
a = 0.7; b = 0.4;   % arbitrary half-widths

% ---- (1) nodal cardinality ----
nodes_xi  = [-1, 1, 1,-1];
nodes_eta = [-1,-1, 1, 1];
err_card = 0;
for node = 1:4
    % assemble the 8 nodal DOF values for u-family functions of all nodes
    % expected: DOF 'u' of this node = 1, 'u_x','u_y','u_xy' of this node = 0,
    % all other nodes = 0.
    for node2 = 1:4
        N = bfs_shape_functions(node2, nodes_xi(node), nodes_eta(node), a, b);
        d = bfs_shape_derivatives(node2, nodes_xi(node), nodes_eta(node), a, b);
        % N = [value, a*slope_xi, b*slope_eta, ab*slope_xi_eta]
        target = (node2 == node);
        err_card = max(err_card, abs(N(1) - target));        % value
        err_card = max(err_card, abs(N(2) - 0));             % u_x  (0 at all nodes)
        err_card = max(err_card, abs(N(3) - 0));             % u_y
        err_card = max(err_card, abs(N(4) - 0));             % u_xy
        % derivative-consistency of the cardinal DOFs: the physical-space
        % derivatives of the derivative-DOF shape functions equal 1 at
        % their own node (d(N2)/dx = 1, d(N3)/dy = 1, d2(N4)/dxdy = 1)
        if node2 == node
            err_card = max(err_card, abs(d.Nx(2) - 1));      % d(N2)/dx = 1
            err_card = max(err_card, abs(d.Ny(3) - 1));      % d(N3)/dy = 1
            err_card = max(err_card, abs(d.Nxy(4) - 1));     % d2(N4)/dxdy = 1
        end
    end
end

% ---- (2) derivatives vs finite differences ----
eps = 1e-6;    % step for first derivatives
eps2 = 1e-4;   % step for second derivatives (avoids cancellation)
rng(1);
err_d = 0;
for t = 1:20
    xi  = 2*rand-1; eta = 2*rand-1;
    for node = 1:4
        d = bfs_shape_derivatives(node, xi, eta, a, b);
        for k = 1:4
            N_xp = bfs_shape_functions(node, xi+eps/a, eta, a, b);   % perturb physical x
            N_xm = bfs_shape_functions(node, xi-eps/a, eta, a, b);
            fd_x = (N_xp(k) - N_xm(k))/(2*eps);
            err_d = max(err_d, abs(d.Nx(k) - fd_x));

            N_yp = bfs_shape_functions(node, xi, eta+eps/b, a, b);
            N_ym = bfs_shape_functions(node, xi, eta-eps/b, a, b);
            fd_y = (N_yp(k) - N_ym(k))/(2*eps);
            err_d = max(err_d, abs(d.Ny(k) - fd_y));

            N_xx = bfs_shape_functions(node, xi+eps2/a, eta, a, b);
            N_xxm = bfs_shape_functions(node, xi-eps2/a, eta, a, b);
            N_0 = bfs_shape_functions(node, xi, eta, a, b);
            fd_xx = (N_xx(k) - 2*N_0(k) + N_xxm(k))/(eps2^2);
            err_d = max(err_d, abs(d.Nxx(k) - fd_xx));

            N_yy = bfs_shape_functions(node, xi, eta+eps2/b, a, b);
            N_yym = bfs_shape_functions(node, xi, eta-eps2/b, a, b);
            fd_yy = (N_yy(k) - 2*N_0(k) + N_yym(k))/(eps2^2);
            err_d = max(err_d, abs(d.Nyy(k) - fd_yy));

            N_xy = bfs_shape_functions(node, xi+eps2/a, eta+eps2/b, a, b);
            N_xmyp = bfs_shape_functions(node, xi-eps2/a, eta+eps2/b, a, b);
            N_xpym = bfs_shape_functions(node, xi+eps2/a, eta-eps2/b, a, b);
            N_xmym = bfs_shape_functions(node, xi-eps2/a, eta-eps2/b, a, b);
            fd_xy = (N_xy(k) - N_xmyp(k) - N_xpym(k) + N_xmym(k))/(4*eps2^2);
            err_d = max(err_d, abs(d.Nxy(k) - fd_xy));
        end
    end
end

% ---- (3) B_e and B_eta reproduce epsV / etaV from a random q_u ----
rng(2);
q_u = randn(32,1);
xi = 0.31; eta = -0.22;
Be   = B_e_matrix(xi, eta, a, b);
Beta = B_eta_matrix(xi, eta, a, b);
epsV = Be*q_u; etaV = Beta*q_u;
% reconstruct via the interpolation: u(xi,eta), v(xi,eta) and derivatives
u   = 0; ux = 0; uy = 0; uxx = 0; uyy = 0; uxy = 0;
v   = 0; vx = 0; vy = 0; vxx = 0; vyy = 0; vxy = 0;
for node = 1:4
    N = bfs_shape_functions(node, xi, eta, a, b);
    d = bfs_shape_derivatives(node, xi, eta, a, b);
    qn = q_u((node-1)*8+(1:8));   % [u u_x u_y u_xy v v_x v_y v_xy] (8x1)
    u  = u  + N*qn(1:4);
    v  = v  + N*qn(5:8);
    ux = ux + d.Nx*qn(1:4);   uy = uy + d.Ny*qn(1:4);
    uxx= uxx+ d.Nxx*qn(1:4);  uyy= uyy+ d.Nyy*qn(1:4); uxy = uxy + d.Nxy*qn(1:4);
    vx = vx + d.Nx*qn(5:8);   vy = vy + d.Ny*qn(5:8);
    vxx= vxx+ d.Nxx*qn(5:8);  vyy= vyy+ d.Nyy*qn(5:8); vxy = vxy + d.Nxy*qn(5:8);
end
epsV_ref = [ux; vy; uy+vx];
etaV_ref = [uxx; uxy; vxy; vyy; uxy+vxx; uyy+vxy];
err_e   = max(abs(epsV - epsV_ref));
err_eta = max(abs(etaV - etaV_ref));

% ---- (4) B_phi vs analytic ----
Bphi = B_phi_matrix(xi, eta, a, b);
nodes_xi  = [-1,1,1,-1]; nodes_eta = [-1,-1,1,1];
Bphi_ref = zeros(2,4);
for node = 1:4
    Bphi_ref(1,node) = (1/(4*a))*nodes_xi(node)*(1+nodes_eta(node)*eta);
    Bphi_ref(2,node) = (1/(4*b))*(1+nodes_xi(node)*xi)*nodes_eta(node);
end
err_phi = max(max(abs(Bphi - Bphi_ref)));

tol2 = 1e-6;
ok1 = err_card < tol; ok2 = err_d < tol2; ok3 = (err_e < tol2) && (err_eta < tol2); ok4 = err_phi < tol;
results.cardinality_error = err_card;
results.derivative_error  = err_d;
results.Be_error          = err_e;
results.Beta_error        = err_eta;
results.Bphi_error        = err_phi;
results.all_pass = ok1 && ok2 && ok3 && ok4;

if ~quiet
    fprintf('verify_B_matrices:\n');
    fprintf('  (1) BFS nodal cardinality        : max |err| = %.3e  [tol %.1e]  %s\n', err_card, tol, pf(ok1));
    fprintf('  (2) derivatives vs finite diff   : max |err| = %.3e  [tol %.1e]  %s\n', err_d, tol2, pf(ok2));
    fprintf('  (3a) B_e  reproduces epsV        : max |err| = %.3e  [tol %.1e]  %s\n', err_e, tol2, pf(ok3));
    fprintf('  (3b) B_eta reproduces etaV       : max |err| = %.3e  [tol %.1e]  %s\n', err_eta, tol2, pf(ok3));
    fprintf('  (4) B_phi vs analytic dNp        : max |err| = %.3e  [tol %.1e]  %s\n', err_phi, tol2, pf(ok4));
    fprintf('  OVERALL: %s\n\n', pf(results.all_pass));
end
end

function s = pf(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
