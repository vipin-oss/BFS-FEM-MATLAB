function results = verify_D_voigt(quiet)
% VERIFY_D_VOIGT  Independent reconstruction of D_Voigt from the five
% Mindlin invariants.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part III, Eq. (III_W) five invariants, Eq. (III_I1..III_I5),
%   Eq. (III_Dmatrix, III_Dentries).
%
% Checks:
%  (1) 0.5*etaV' D etaV == W_grad(five invariants) for random eta vectors;
%  (2) D == finite-difference Hessian of W_grad w.r.t. etaV (6 components);
%  (3) D == D^T.
%
% Prints PASS/FAIL lines. Returns struct of computed errors.
if nargin < 1, quiet = false; end
p = simulation_parameters();
tol = p.tol_eq;

% reference D from the constitutive routine
a1 = 1.3; a2 = 0.7; a3 = 0.9; a4 = 1.1; a5 = 0.4;   % arbitrary [N] moduli
Dref = constitutive_D(a1, a2, a3, a4, a5);

% ---- (1) quadratic-form identity vs invariant energy ----
rng(0);
err1 = 0;
for n = 1:200
    etaV = randn(6,1);          % [A B E F 2C 2D]
    W1 = 0.5*etaV'*Dref*etaV;
    W2 = W_grad_invariants(a1,a2,a3,a4,a5, etaV);
    err1 = max(err1, abs(W1 - W2));
end

% ---- (2) finite-difference Hessian ----
Dfd = fd_hessian(a1,a2,a3,a4,a5);
err2 = max(max(abs(Dfd - Dref)));

% ---- (3) symmetry ----
err3 = max(max(abs(Dref - Dref')));

ok1 = err1 < tol; ok2 = err2 < 1e-7; ok3 = err3 < tol;
results.quadratic_form_error = err1;
results.fd_hessian_error     = err2;
results.symmetry_error       = err3;
results.all_pass = ok1 && ok2 && ok3;

if ~quiet
    fprintf('verify_D_voigt:\n');
    fprintf('  (1) 0.5*etaV'' D etaV - W_grad(invariants): max |err| = %.3e  [tol %.1e]  %s\n', err1, tol, pf(ok1));
    fprintf('  (2) finite-difference Hessian D_fd - D_ref   : max |err| = %.3e  [tol %.1e]  %s\n', err2, 1e-7, pf(ok2));
    fprintf('  (3) D - D'' symmetry                         : max |err| = %.3e  [tol %.1e]  %s\n', err3, tol, pf(ok3));
    fprintf('  OVERALL: %s\n\n', pf(results.all_pass));
end
end

% ---- the five invariants written out in the 6 components [A B E F 2C 2D] ----
function W = W_grad_invariants(a1,a2,a3,a4,a5, etaV)
A = etaV(1); B = etaV(2); E = etaV(3); F = etaV(4);
C = etaV(5)/2; D = etaV(6)/2;   % etaV slots 5,6 carry 2*eta121, 2*eta122
I1 = (A+E)*(A+D) + (B+F)*(C+F);
I2 = (A+D)^2 + (C+F)^2;
I3 = (A+E)^2 + (B+F)^2;
I4 = A^2 + B^2 + 2*C^2 + 2*D^2 + E^2 + F^2;
I5 = A^2 + 2*B*C + C^2 + 2*D*E + D^2 + F^2;
W  = a1*I1 + a2*I2 + a3*I3 + a4*I4 + a5*I5;
end

% ---- finite-difference Hessian of W_grad at etaV = 0 ----
function D = fd_hessian(a1,a2,a3,a4,a5)
h = 1e-5;
D = zeros(6,6);
for i = 1:6
    for j = 1:6
        ei = zeros(6,1); ei(i) = 1;
        ej = zeros(6,1); ej(j) = 1;
        if i == j
            D(i,j) = (W_grad_invariants(a1,a2,a3,a4,a5, 2*h*ei) ...
                    - 2*W_grad_invariants(a1,a2,a3,a4,a5, 0*ei) ...
                    + W_grad_invariants(a1,a2,a3,a4,a5,-2*h*ei)) / (4*h^2);
        else
            D(i,j) = ( W_grad_invariants(a1,a2,a3,a4,a5,  h*ei+h*ej) ...
                     - W_grad_invariants(a1,a2,a3,a4,a5,  h*ei-h*ej) ...
                     - W_grad_invariants(a1,a2,a3,a4,a5, -h*ei+h*ej) ...
                     + W_grad_invariants(a1,a2,a3,a4,a5, -h*ei-h*ej)) / (4*h^2);
        end
    end
end
end

function s = pf(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
