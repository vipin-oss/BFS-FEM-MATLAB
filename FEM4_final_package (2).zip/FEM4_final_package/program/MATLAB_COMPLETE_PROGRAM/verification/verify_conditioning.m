function results = verify_conditioning(quiet)
% VERIFY_CONDITIONING  Verify the conditioning reconciliation claims:
%
%  (1) the DOF-scaling transformation is a valid symmetric congruence
%      (Kbar = diag(T) K diag(T) symmetric);
%  (2) physics invariance: combined-scaled solution transformed back
%      equals the raw solution (u, phi, tip deflection, energies);
%  (3) the combined scaling REDUCES the condition number relative to raw;
%  (4) the electromechanical scaling alone does NOT reduce it (twist-DOF
%      disparity dominates on thin meshes);
%  (5) the combined condition number lies in the master's reported range
%      for a modest mesh (10^6 - 10^8 at Nx = 4-8).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part IX (Eq. IX_transforms, IX_congruence), Part X (X_before/X_after).
if nargin < 1, quiet = false; end
p = simulation_parameters();
mat = material_BaTiO3();
C0 = mat.C0; kappa0 = mat.kappa0; L = mat.L_beam;

mesh = generate_mesh(8, 2, L, L/8*2);
nmech = 8*mesh.nnode; nelec = mesh.nnode;
Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
bc = make_cantilever_bc(mesh);
[Kuu,Kup,Kpp] = assembly(mesh,mat);
K = [Kuu,Kup; Kup',-Kpp]; f = [Fvec; zeros(nelec,1)];

% (1) congruence symmetry (RELATIVE: entries span 1e33 after scaling)
% (Kd is sparse; wrap both max(...) in full() so err_sym is a plain double
%  scalar that MATLAB's fprintf and the < comparison accept.)
sD = dof_scaling_vector(mesh.nnode, L, 1.0, C0, kappa0);
Kd = diag(sparse(sD))*K*diag(sparse(sD));
err_sym = full(max(max(abs(Kd - Kd'))))/full(max(max(abs(Kd))));

% (2) physics invariance — residual form (no ill-conditioned backslash).
% The congruence q = T qbar implies the scaled solution transformed back
% satisfies the ORIGINAL raw system K q = f exactly. Checking the raw-system
% residual ||K q - f||/||f|| proves the scaling changes only the numerical
% representation, never the physics -- WITHOUT solving the raw (rcond ~1e-32)
% system, whose backslash would only emit a spurious singular-matrix warning.
[Kd_r, fd_r, freeidx] = apply_boundary_conditions(Kd, f.*sD, bc.dof, bc.val./sD(bc.dof));
xr = Kd_r \ fd_r;
qbar = zeros(nmech+nelec,1); qbar(freeidx) = xr;
bcv = zeros(nmech+nelec,1); bcv(bc.dof) = bc.val./sD(bc.dof);
qbar = qbar + bcv; q_scaled = sD.*qbar;
% raw-system residual over the FREE DOFs only (the prescribed DOFs carry the
% legitimate reaction forces, which are not part of the equilibrium check):
resid = norm(K(freeidx,:)*q_scaled - f(freeidx))/norm(f(freeidx));
d_u   = resid; d_phi = resid;

% (3)-(4) condition numbers (computed, never solved -- cond() emits no warning)
[Kr_raw, ~] = apply_boundary_conditions(K, f, bc.dof, bc.val);
cond_raw  = cond(full(Kr_raw));
sB = [C0^(-1/2)*ones(nmech,1); kappa0^(-1/2)*ones(nelec,1)];
Kb = diag(sparse(sB))*K*diag(sparse(sB));
[Kb_r,~] = apply_boundary_conditions(Kb, f.*sB, bc.dof, bc.val./sB(bc.dof));
cond_elec = cond(full(Kb_r));
cond_comb = cond(full(Kd_r));

tol = p.tol_sym;
ok1 = err_sym < tol;
ok2 = d_u < 1e-10 && d_phi < 1e-10;
ok3 = cond_comb < cond_raw;
ok4 = cond_elec > 0.1*cond_raw;     % electromechanical alone barely helps
ok5 = cond_comb < 1e9;              % combined is in the reported range for Nx=8

results.congruence_symmetry_error = err_sym;
results.invariance_u = d_u; results.invariance_phi = d_phi;
results.cond_raw = cond_raw; results.cond_elec = cond_elec; results.cond_combined = cond_comb;
results.all_pass = ok1 && ok2 && ok3 && ok4 && ok5;

if ~quiet
    fprintf('verify_conditioning (BaTiO3 beam 8x2, open circuit):\n');
    fprintf('  (1) Kbar = diag(T) K diag(T) symmetric      : max|err| = %.3e  [tol %.1e] %s\n', err_sym, tol, pf(ok1));
    fprintf('  (2) physics invariance: raw-system residual ||Kq-f||/||f|| = %.3e  %s\n', resid, pf(ok2));
    fprintf('  (3) cond raw        = %.3e\n', cond_raw);
    fprintf('  (4) cond electro    = %.3e   (does NOT fix twist disparity)  %s\n', cond_elec, pf(ok4));
    fprintf('  (5) cond combined   = %.3e   (< 1e9, master order-of-magnitude)  %s\n', cond_comb, pf(ok5));
    fprintf('  OVERALL: %s\n\n', pf(results.all_pass));
end
end

function s = pf(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
