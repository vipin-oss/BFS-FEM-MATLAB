function results = verify_dimensions(quiet)
% VERIFY_DIMENSIONS  Dimensional audit of constitutive quantities and
% characteristic length scales.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part III, Eq. (III_lelastic, III_fflexo, III_Lambda) and the
%   dimensional checks; Part IX, Eq. (IX_eps0..IX_U0).
%
% Checks (numeric, using the BaTiO3 baseline):
%   ell_elastic = sqrt(D0/C0) = 0.2726 nm  (material length)
%   f_flexo     = mu0/sqrt(C0 kappa0) = 25.92 nm
%   Lambda      = sqrt(D0 kappa0)/mu0 = 1.0517e-2 (dimensionless)
% and re-states the unit cancellations. Also confirms ell_elastic is
% DISTINCT from ell_ref = 1 um (master Appendix D, item D5).
if nargin < 1, quiet = false; end
p = simulation_parameters();
mat = material_BaTiO3();
L = characteristic_lengths(mat.D0, mat.C0, mat.kappa0, mat.mu0);

ell_elastic = L.ell_elastic;    % [m]
f_flexo     = L.f_flexo;        % [m]
Lambda      = L.Lambda;         % [1]

% ---- CRITICAL Lambda DISCREPANCY (Phase-3 audit) ----
% The frozen master (Part III, Eq. III_Lambda; Part IX, Eq. IX_lengths)
% derives  Lambda = sqrt(D0*kappa0)/mu0 = 1.0517e-2  from the BASELINE
% constants D0 = 1e-8 N, kappa0 = 11.06 nF/m, mu0 = 1e-6 C/m.
% A value 19.2928 appears NOWHERE in the frozen sources; it would require
% mu0 = 5.45e-10 C/m, or D0 = 0.0337 N, or ell_elastic = 0.5 um, none of
% which are the frozen baseline. The dual-method check below confirms the
% master value; the implementation is NOT changed to 19.2928 (that would
% modify the frozen mathematics).
Lambda1 = sqrt(mat.D0*mat.kappa0)/mat.mu0;   % Method 1
Lambda2 = ell_elastic/f_flexo;               % Method 2
err_dual = abs(Lambda1 - Lambda2);

% expected values from the master
ell_elastic_ref = 2.7255e-10;   % 0.2726 nm
f_flexo_ref     = 2.5916e-8;    % 25.92 nm
Lambda_ref      = 1.0517e-2;
tol = 1e-3;

ok1 = abs(ell_elastic - ell_elastic_ref)/ell_elastic_ref < tol;
ok2 = abs(f_flexo     - f_flexo_ref)/f_flexo_ref < tol;
ok3 = abs(Lambda      - Lambda_ref)/Lambda_ref < tol;
ok4 = mat.ell_ref == 1.0e-6;    % normalization reference, distinct quantity
ok5 = err_dual < 1e-15;         % dual-method agreement
results.ell_elastic = ell_elastic;
results.f_flexo     = f_flexo;
results.Lambda      = Lambda;
results.Lambda_dual_error = err_dual;
results.all_pass = ok1 && ok2 && ok3 && ok4 && ok5;

if ~quiet
    fprintf('verify_dimensions:\n');
    fprintf('  D0 = %.1e N ; C0 = %.4e Pa ; kappa0 = %.3e F/m ; mu0 = %.1e C/m\n', ...
        mat.D0, mat.C0, mat.kappa0, mat.mu0);
    fprintf('  ell_elastic = sqrt(D0/C0)        = %.4e m = %.4f nm  (ref 0.2726 nm) %s\n', ell_elastic, ell_elastic*1e9, pf(ok1));
    fprintf('  f_flexo     = mu0/sqrt(C0 kappa0)= %.4e m = %.4f nm  (ref 25.92 nm)  %s\n', f_flexo, f_flexo*1e9, pf(ok2));
    fprintf('  Lambda M1   = sqrt(D0 kappa0)/mu0= %.8e [-]  (ref 1.0517e-2) %s\n', Lambda1, pf(ok3));
    fprintf('  Lambda M2   = ell_elastic/f_flexo= %.8e [-]  (dual method)  %s\n', Lambda2, pf(ok5));
    fprintf('  |Lambda1-Lambda2|               = %.3e\n', err_dual);
    fprintf('  ell_ref (normalization, distinct)= %.1e m  %s\n', mat.ell_ref, pf(ok4));
    % cross-check the public non-dimensionalization API (nondimensionalize.m)
    nd = nondimensionalize(mat, 1.0, 1.0);   % L0 = 1 m, u0 = 1 m
    err_nd = max([ abs(nd.eps0-1.0), abs(nd.phi0-sqrt(mat.C0/mat.kappa0)), ...
                   abs(nd.F0-mat.C0), abs(nd.U0-mat.C0) ]);
    fprintf('  nondimensionalize reference scales (eps0/phi0/F0/U0): max |err| = %.3e  %s\n', err_nd, pf(err_nd<1e-12));
    results.nondim_ref_scale_error = err_nd;
    results.all_pass = results.all_pass && err_nd < 1e-12;
    fprintf('  [C]=Pa [D]=N [e]=C/m^2 [mu]=C/m [kappa]=F/m ; lengths [m]; Lambda [1]\n');
    fprintf('  OVERALL: %s\n\n', pf(results.all_pass));
end
end

function s = pf(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
