function results = verify_energy_balance(quiet)
% VERIFY_ENERGY_BALANCE  First-law energy partition derived from the frozen
% variational formulation (no unexplained factor 2).
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part IV, Eq. (IV_Pi) total potential PI = U_int - W_ext;
%   Part VI, Eq. (VI_saddle) discrete system;
%   Part XVII, Eq. (XVII_Wext, XVII_Umech, XVII_Uelec, XVII_residual).
%
% DERIVATION (first principles, from the frozen enthalpy):
%   H = 1/2 eps'C eps + 1/2 eta'D eta - 1/2 (grad phi)'kappa (grad phi)
%     + (grad phi)' e eps + (grad phi)' mu eta
%   Discrete stored internal energy:
%     U_int = 1/2 q_u' K_uu q_u - 1/2 q_phi' K_pp q_phi + q_u' K_up q_phi
%           = U_mech - U_elec + U_coup
%   Total potential:  PI = U_int - F' q_u + Q' q_phi   (dead-load product).
%   Stationarity reproduces the saddle system exactly:
%     dPI/dq_u = K_uu q_u + K_up q_phi - F = 0
%     dPI/dq_phi = K_up' q_u - K_pp q_phi + Q = 0  ->  K_up' q_u - K_pp q_phi = -Q
%
%   Euler's homogeneous-function theorem on the QUADRATIC U_int:
%     q' grad(U_int) = 2 U_int.
%   At equilibrium grad(U_int) = [F; -Q], hence
%     (DEAD-LOAD PRODUCT)  P = F' q_u - Q' q_phi = 2 U_int .        (identity I1)
%
%   Open-circuit equilibrium (Q = 0): the second row gives
%     K_up' q_u = K_pp q_phi  ->  q_u' K_up q_phi = q_phi' K_pp q_phi = 2 U_elec,
%   i.e. the coupling energy equals TWICE the stored dielectric energy,
%     U_coup = 2 U_elec,                                            (identity I2)
%   so that  U_int = U_mech - U_elec + U_coup = U_mech + U_elec.    (identity I3)
%
%   Hence the exact first-law statement is
%     P = 2 (U_mech + U_elec),  equivalently  W_qs = P/2 = U_mech + U_elec,
%   where W_qs = (1/2) P is the QUASI-STATIC loading work (proportional
%   loading 0 -> load). This is the factor 1/2: the master's W_ext (Eq.
%   XVII_Wext, written as the dead-load integral) equals U_mech + U_elec
%   only under the quasi-static-work interpretation W_ext = P/2.
%
% The script verifies ALL FOUR identities numerically and prints each.
if nargin < 1, quiet = false; end
mat  = material_BaTiO3();
mesh = generate_mesh(8, 2, mat.L_beam, mat.h_beam);

F = apply_tip_load(mesh, mat.F_sensor, 'v');
bc = make_cantilever_bc(mesh);

opts.loads = struct('F', F, 'Q', []);
opts.bc = bc; opts.use_dof_scaling = true; opts.electrical = true;
out = solve_system(mesh, mat, opts);

q_u = out.q_u; q_phi = out.q_phi;
[Kuu, Kup, Kpp] = assembly(mesh, mat);

U_mech = 0.5*q_u'*Kuu*q_u;
U_elec = 0.5*q_phi'*Kpp*q_phi;
U_coup = q_u'*Kup*q_phi;
U_int  = U_mech - U_elec + U_coup;
P      = F'*q_u;                 % dead-load product (Q = 0, open circuit)
W_qs   = 0.5*P;                  % quasi-static loading work

% identities (must all be machine-precision zero)
e1 = P - 2*U_int;                % I1: dead-load product = 2 * stored energy
e2 = U_coup - 2*U_elec;          % I2: coupling energy = 2 * dielectric energy
e3 = U_int - (U_mech + U_elec);  % I3: stored = mech + elec (open circuit)
% residuals (relative, guard against zero denominator)
r_qs  = abs(W_qs - (U_mech + U_elec))/abs(W_qs);          % master's balance (W_ext = P/2)
r_dead= abs(P - 2*(U_mech + U_elec))/abs(P);              % dead-load form

tol = simulation_parameters().tol_energy;
ok1 = abs(e1) < tol*max(1,abs(P));
ok2 = abs(e2) < tol*max(1,abs(U_coup));
ok3 = abs(e3) < tol*max(1,abs(U_mech));
ok4 = r_qs < tol; ok5 = r_dead < tol;

results.U_mech = U_mech; results.U_elec = U_elec;
results.U_coup = U_coup; results.U_int = U_int;
results.P = P; results.W_qs = W_qs;
results.e1 = e1; results.e2 = e2; results.e3 = e3;
results.r_qs = r_qs; results.r_dead = r_dead;
results.all_pass = ok1 && ok2 && ok3 && ok4 && ok5;

if ~quiet
    fprintf('verify_energy_balance (first-principles derivation, open circuit):\n');
    fprintf('  U_mech  = 1/2 q_u'' K_uu q_u            = %.6e J\n', U_mech);
    fprintf('  U_elec  = 1/2 q_phi'' K_pp q_phi        = %.6e J\n', U_elec);
    fprintf('  U_coup  = q_u'' K_up q_phi              = %.6e J\n', U_coup);
    fprintf('  U_int   = U_mech - U_elec + U_coup     = %.6e J\n', U_int);
    fprintf('  P       = F'' q_u (dead-load product)   = %.6e J\n', P);
    fprintf('  W_qs    = P/2 (quasi-static work)      = %.6e J\n', W_qs);
    fprintf('  I1: P - 2 U_int                        = %.3e  [tol %.1e] %s\n', e1, tol*max(1,abs(P)), pf(ok1));
    fprintf('  I2: U_coup - 2 U_elec                  = %.3e  [tol %.1e] %s\n', e2, tol*max(1,abs(U_coup)), pf(ok2));
    fprintf('  I3: U_int - (U_mech + U_elec)          = %.3e  [tol %.1e] %s\n', e3, tol*max(1,abs(U_mech)), pf(ok3));
    fprintf('  master balance   |W_qs-(U_mech+U_elec)|/|W_qs|   = %.3e  [tol %.1e] %s\n', r_qs, tol, pf(ok4));
    fprintf('  dead-load form   |P-2(U_mech+U_elec)|/|P|       = %.3e  [tol %.1e] %s\n', r_dead, tol, pf(ok5));
    fprintf('  OVERALL: %s\n\n', pf(results.all_pass));
end
end

function s = pf(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
