function results = verify_energy_multimesh(quiet)
% VERIFY_ENERGY_MULTIMESH  Energy identity verified on 1-element, 2x1, 5x1
% and a production mesh (8x2), with the coupling energy shown explicitly.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part XVII (Eq. XVII_Wext..XVII_residual); the identities derived in
%   verify_energy_balance.m:
%     P = F'q = 2 U_int ,  U_coup = 2 U_elec ,  U_int = U_mech + U_elec ,
%     W_qs = 0.5 P = U_mech + U_elec.
% No hard-coded factor 1/2: it is DERIVED from Euler's theorem and the
% open-circuit equilibrium row.
if nargin < 1, quiet = false; end
mat = material_BaTiO3();
meshes = { [1 1], [2 1], [5 1], [8 2] };
labels = {'1 element','2x1','5x1','8x2 (production)'};
nMesh = numel(meshes);
results.P = zeros(nMesh,1); results.Umech = zeros(nMesh,1);
results.Uelec = zeros(nMesh,1); results.Ucoup = zeros(nMesh,1);
results.Uint = zeros(nMesh,1); results.R_qs = zeros(nMesh,1);
results.e1 = zeros(nMesh,1); results.e2 = zeros(nMesh,1); results.e3 = zeros(nMesh,1);
allok = true;
if ~quiet, fprintf('verify_energy_multimesh (BaTiO3, open circuit, F = 1 nN):\n'); end
for mi = 1:nMesh
    mesh = generate_mesh(meshes{mi}(1), meshes{mi}(2), mat.L_beam, mat.h_beam);
    Fvec = apply_tip_load(mesh, mat.F_sensor, 'v');
    bc = make_cantilever_bc(mesh);
    opts.loads = struct('F',Fvec,'Q',[]); opts.bc = bc;
    opts.use_dof_scaling = true; opts.electrical = true;
    out = solve_system(mesh, mat, opts);
    [Kuu,Kup,Kpp] = assembly(mesh, mat);
    U_mech = 0.5*out.q_u'*Kuu*out.q_u;
    U_elec = 0.5*out.q_phi'*Kpp*out.q_phi;
    U_coup = out.q_u'*Kup*out.q_phi;
    U_int  = U_mech - U_elec + U_coup;
    P      = Fvec'*out.q_u;
    W_qs   = 0.5*P;
    results.P(mi)=P; results.Umech(mi)=U_mech; results.Uelec(mi)=U_elec;
    results.Ucoup(mi)=U_coup; results.Uint(mi)=U_int;
    e1 = P - 2*U_int; e2 = U_coup - 2*U_elec; e3 = U_int - (U_mech+U_elec);
    R  = abs(W_qs - (U_mech+U_elec))/abs(W_qs);
    results.e1(mi)=e1; results.e2(mi)=e2; results.e3(mi)=e3; results.R_qs(mi)=R;
    ok = (abs(e1)<1e-9*max(1,abs(P))) && (abs(e2)<1e-9*max(1,abs(U_coup))) ...
       && (abs(e3)<1e-9*max(1,abs(U_mech))) && R < 1e-8;
    allok = allok && ok;
    if ~quiet
        fprintf('  %-16s: P=%.3e  U_mech=%.3e  U_elec=%.3e  U_coup=%.3e  | I1=%.1e I2=%.1e I3=%.1e R_qs=%.1e  %s\n', ...
            labels{mi}, P, U_mech, U_elec, U_coup, e1, e2, e3, R, pf(ok));
    end
end
results.all_pass = allok;
if ~quiet
    fprintf('  (I1: P-2U_int ; I2: U_coup-2U_elec ; I3: U_int-(U_mech+U_elec))\n');
    fprintf('  OVERALL: %s\n\n', pf(allok));
end
end
function s = pf(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
