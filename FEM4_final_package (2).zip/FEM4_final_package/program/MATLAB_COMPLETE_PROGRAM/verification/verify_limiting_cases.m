function results = verify_limiting_cases(quiet)
% VERIFY_LIMITING_CASES  The eight canonical limiting cases.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part XII (Cases 1..8) and Table (limiting cases).
%
% For each case the script activates/deactivates the constitutive
% couplings, assembles the coupled system and reports:
%   ||K_uphi||_F  (coupling-block Frobenius norm)  -> decoupling check
%   energy residual (quasi-static convention)      -> only for well-posed cases
%
% Decoupling PASS/FAIL: ||K_uphi|| == 0 (within tol) exactly for the cases
% with no electromechanical coupling (e=0 and mu=0), and > 0 otherwise.
%
% IMPLEMENTATION FINDING (documented, MATLAB_IMPLEMENTATION_AUDIT.md):
%   The test material must carry ALL couplings (piezo + flexo + gradient),
%   so each limiting case is non-trivial. Because BaTiO3 is centrosymmetric
%   (e = 0), the piezo constants of PZT-5H are grafted onto the BaTiO3 set
%   to form a SYNTHETIC fully-coupled test material (the paper's exact
%   limiting-case material parameters are source-reported / unavailable).
%
%   CONDITIONING FINDING (not a spurious mode, not a bug): the twist DOF
%   (u_xy) energy of the BFS element scales as ~C*b^2*(a*b). On the 20:1
%   nanobeam mesh (a = 125 nm, b = 25 nm) this is ~2.5e-19 J, i.e. ~16
%   orders below the dominant (value/slope) DOFs (~1e-4 J), so the raw
%   mechanical block is numerically near-singular in double precision.
%   This intra-mechanical disparity is DISTINCT from the electromechanical
%   C0/kappa0 disparity that the master's symmetric congruence scaling
%   (Part IX-X) removes. Cases 1, 2, 4, 7 (D = 0) are therefore not
%   solved here: the script reports the DECOUPLING check and flags the
%   mechanical solve as 'twist-DOF ill-conditioned (thin beam)' instead of
%   fabricating a residual.
if nargin < 1, quiet = false; end
p = simulation_parameters();
tol = p.tol_eq;

% synthetic fully-coupled test material (documented above)
mat0 = material_BaTiO3();
mat0.e31 = -16.6; mat0.e33 = +18.6; mat0.e15 = +12.7;   % [C/m^2] from PZT-5H set

mesh = generate_mesh(8, 2, mat0.L_beam, mat0.h_beam);
F = apply_tip_load(mesh, mat0.F_sensor, 'v');
bc = make_cantilever_bc(mesh);

cases = { ...
  'Case 1  pure piezo        (mu=0, D=0)', [1 0 0]; ...
  'Case 2  pure flexo        (e=0,  D=0)', [0 1 0]; ...
  'Case 3  pure Mindlin grad (e=0, mu=0)', [0 0 1]; ...
  'Case 4  classical elast   (e=0,mu=0,D=0)', [0 0 0]; ...
  'Case 5  gradient + piezo  (mu=0)',      [1 0 1]; ...
  'Case 6  gradient + flexo  (e=0)',       [0 1 1]; ...
  'Case 7  piezo + flexo     (D=0)',       [1 1 0]; ...
  'Case 8  fully coupled                  ', [1 1 1] };

ncase = size(cases,1);
results.norm_Kup = zeros(ncase,1);
results.max_phi  = zeros(ncase,1);
results.R_qs     = nan(ncase,1);
results.decoupling_pass = false(ncase,1);
results.solved   = false(ncase,1);

if ~quiet, fprintf('verify_limiting_cases (mesh 8x2, synthetic fully-coupled material, F=1 nN):\n'); end
for c = 1:ncase
    cfg = cases{c,2};
    mat = set_couplings(mat0, cfg(1), cfg(2), cfg(3));
    [Kuu, Kup, Kpp] = assembly(mesh, mat);
    nK = norm(Kup, 'fro');
    results.norm_Kup(c) = nK;
    decoupled = (cfg(1)==0 && cfg(2)==0);
    results.decoupling_pass(c) = (decoupled && nK < tol) || (~decoupled && nK > 0);

    % well-posed (solvable with the BFS element) ONLY if the strain-gradient
    % stiffness is active (D != 0): with D = 0 the bicubic twist DOFs (u_xy,
    % v_xy) have no stiffness from the second-order membrane energy, so the
    % mechanical block is exactly singular (the flexo/piezo coupling enters
    % K_uphi, NOT K_uu, and cannot stabilize the twist DOFs). D = 0 cases
    % (Cases 1, 2, 4, 7) are therefore checked STRUCTURALLY only (the
    % decoupling norm ||K_uphi||), never solved.
    wellposed = (cfg(3) ~= 0);
    if wellposed
        % D != 0 cases are physically well-posed, but on the nanobeam the raw
        % physical matrix carries the BFS twist-DOF (u_xy, v_xy) scale
        % disparity (~1e-28), so a raw solve is numerically singular
        % (MATLAB: "RCOND ~ 1e-32"). The master's full non-dimensionalization
        % (Part IX, use_dof_scaling = true) removes this disparity while
        % preserving the physical solution (invariance proven in
        % verify_conditioning). Solve with the FULL scaling:
        opts.loads = struct('F', F, 'Q', []);
        opts.bc = bc; opts.use_dof_scaling = true; opts.electrical = true;
        out = solve_system(mesh, mat, opts);
        q_u = out.q_u; q_phi = out.q_phi;
        U_mech = 0.5*q_u'*Kuu*q_u;
        U_elec = 0.5*q_phi'*Kpp*q_phi;
        W_qs = 0.5*(F'*q_u);
        R = abs(W_qs - (U_mech+U_elec))/abs(W_qs);
        results.R_qs(c) = R;
        results.max_phi(c) = max(abs(q_phi));
        results.solved(c) = true;
        if ~quiet
            fprintf('  %-40s ||K_uphi||=%.6e  R_qs=%.2e  %s\n', cases{c,1}, nK, R, pf(results.decoupling_pass(c)));
        end
    else
        if ~quiet
            fprintf('  %-40s ||K_uphi||=%.6e  (D=0: twist-DOF ill-conditioned on thin beam; decoupling check only)  %s\n', ...
                cases{c,1}, nK, pf(results.decoupling_pass(c)));
        end
    end
end
results.all_pass = all(results.decoupling_pass);
if ~quiet
    fprintf('  OVERALL: %s  (paper table values are source-reported; compare structurally only)\n\n', pf(results.all_pass));
end
end

function mat = set_couplings(mat0, e_on, mu_on, D_on)
mat = mat0;
if ~e_on
    mat.e31 = 0; mat.e33 = 0; mat.e15 = 0;
end
if ~mu_on
    mat.mu11 = 0; mat.mu12 = 0; mat.mu44 = 0;
end
if ~D_on
    mat.a1 = 0; mat.a2 = 0; mat.a3 = 0; mat.a4 = 0; mat.a5 = 0;
end
end

function s = pf(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
