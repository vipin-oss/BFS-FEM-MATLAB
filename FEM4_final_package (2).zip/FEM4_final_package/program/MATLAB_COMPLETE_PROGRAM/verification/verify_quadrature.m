function results = verify_quadrature(quiet)
% VERIFY_QUADRATURE  4x4 Gauss-Legendre exactness for the BFS integrands.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VIII, Sec. "Polynomial degree of every integrand" and
%   Eq. (VIII_gauss): the binding integrand has per-variable degree 6 and
%   2*n-1 = 7 >= 6, so the 4x4 rule is exact.
%
% Checks:
%  (1) monomials xi^p eta^q integrated exactly for p,q <= 7;
%  (2) B_eta^T D B_eta element stiffness equals a 10x10 high-order
%      reference to machine precision (quadrature error ~ 0).
if nargin < 1, quiet = false; end
p = simulation_parameters();
[gp, gw] = gauss_legendre_4x4();

% ---- (1) monomial exactness on [-1,1]^2 ----
err_mon = 0;
for pp = 0:7
    for qq = 0:7
        num = 0;
        for i = 1:4, for j = 1:4
            num = num + gw(i)*gw(j)*(gp(i)^pp)*(gp(j)^qq);
        end; end
        if mod(pp,2)==0 && mod(qq,2)==0
            exact = 4/((pp+1)*(qq+1));   % integral of even monomials
        else
            exact = 0;
        end
        err_mon = max(err_mon, abs(num - exact));
    end
end

% ---- (2) strain-gradient stiffness vs 10-point reference ----
a = 0.6; b = 0.3;
D = constitutive_D(1.0, 2.0, 0.5, 1.5, 0.75);
K4 = zeros(32,32);
for i = 1:4, for j = 1:4
    Beta = B_eta_matrix(gp(i), gp(j), a, b);
    K4 = K4 + gw(i)*gw(j)*(Beta'*D*Beta)*(a*b);
end; end

[gph, gwh] = gauss_legendre_n(10);
K10 = zeros(32,32);
for i = 1:10, for j = 1:10
    Beta = B_eta_matrix(gph(i), gph(j), a, b);
    K10 = K10 + gwh(i)*gwh(j)*(Beta'*D*Beta)*(a*b);
end; end
err_k = max(max(abs(K4 - K10)));
fro_rel = norm(K4 - K10, 'fro')/norm(K10, 'fro');

ok1 = err_mon < 1e-14; ok2 = err_k < 1e-10;
results.monomial_error = err_mon;
results.stiffness_abs_error = err_k;
results.stiffness_fro_rel = fro_rel;
results.all_pass = ok1 && ok2;

if ~quiet
    fprintf('verify_quadrature:\n');
    fprintf('  (1) monomials p,q<=7 exact      : max |err| = %.3e  [tol 1e-14] %s\n', err_mon, pf(ok1));
    fprintf('  (2) K(eta) 4x4 vs 10x10 ref     : max |err| = %.3e  [tol 1e-10] %s\n', err_k, pf(ok2));
    fprintf('      Frobenius relative error    : %.3e\n', fro_rel);
    fprintf('  OVERALL: %s\n\n', pf(results.all_pass));
end
end

function s = pf(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
