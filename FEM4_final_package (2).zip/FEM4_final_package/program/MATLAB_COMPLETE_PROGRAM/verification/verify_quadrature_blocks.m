function results = verify_quadrature_blocks(quiet)
% VERIFY_QUADRATURE_BLOCKS  Gauss-rule convergence of EVERY element-matrix
% block across multiple aspect ratios.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VIII, Sec. "Polynomial degree of every integrand" and Eq. (VIII_gauss).
%
% For aspect ratios a/b = 1,2,5,10,20 (physical half-widths, area fixed to
% ~1e-12 m^2 so all blocks are comparable), each block K_uu, K_uphi, K_pp
% is computed with 4x4, 6x6, 8x8 Gauss rules and compared (Frobenius
% relative) against the 10x10 reference. The binding integrand has
% per-variable degree 6, so 4x4 (exact through 7) must already be
% machine-precision exact for ALL blocks; the table demonstrates this
% rather than asserting it.
if nargin < 1, quiet = false; end
aspects = [1, 2, 5, 10, 20];
area = 1e-12;                    % fixed element area [m^2]
C  = constitutive_C(134.6e9, 57.7e9, 38.5e9);
D  = constitutive_D(1.0, 0.7, 0.9, 1.1, 0.4);
eV = piezoelectric_e(12.7, -16.6, 18.6);
muV= flexoelectric_mu(1e-6, 1e-6, 0);
kap= dielectric_kappa(11.06e-9, 11.06e-9);

results.aspects = aspects;
results.fro_uu = zeros(numel(aspects),1);
results.fro_up = zeros(numel(aspects),1);
results.fro_pp = zeros(numel(aspects),1);
maxfro = 0;
for k = 1:numel(aspects)
    ar = aspects(k);
    a = sqrt(area*ar)/2; b = sqrt(area/ar)/2;   % a/b = ar, a*b = area/4
    [Kuu4,Kup4,Kpp4] = blocks(a,b,C,D,eV,muV,kap,4);
    [Kuu6,Kup6,Kpp6] = blocks(a,b,C,D,eV,muV,kap,6);
    [Kuu8,Kup8,Kpp8] = blocks(a,b,C,D,eV,muV,kap,8);
    [Kuur,Kupr,Kppr] = blocks(a,b,C,D,eV,muV,kap,10);
    f_uu = norm(Kuu4-Kuur,'fro')/norm(Kuur,'fro');
    f_up = norm(Kup4-Kupr,'fro')/norm(Kupr,'fro');
    f_pp = norm(Kpp4-Kppr,'fro')/norm(Kppr,'fro');
    results.fro_uu(k) = f_uu; results.fro_up(k) = f_up; results.fro_pp(k) = f_pp;
    maxfro = max([maxfro, f_uu, f_up, f_pp]);
    if ~quiet
        fprintf('  a/b = %2d : 4x4 vs 10x10 Fro rel: K_uu %.2e  K_uphi %.2e  K_pp %.2e\n', ar, f_uu, f_up, f_pp);
    end
end
results.max_fro = maxfro;
results.all_pass = maxfro < 1e-12;
if ~quiet
    fprintf('  max Frobenius relative error (4x4 vs 10x10, all blocks/aspects) = %.3e  [tol 1e-12] %s\n', maxfro, pf(maxfro<1e-12));
    fprintf('  (4x4 is exact for every block; 6x6/8x8 add nothing)\n');
    fprintf('  OVERALL: %s\n\n', pf(results.all_pass));
end
end

function [Kuu,Kup,Kpp] = blocks(a,b,C,D,eV,muV,kap,n)
[gp,gw] = gauss_legendre_n(n);
Kuu = zeros(32,32); Kup = zeros(32,4); Kpp = zeros(4,4);
for i = 1:n, for j = 1:n
    Be = B_e_matrix(gp(i),gp(j),a,b); Beta = B_eta_matrix(gp(i),gp(j),a,b);
    Bphi = B_phi_matrix(gp(i),gp(j),a,b);
    w = gw(i)*gw(j)*(a*b);
    Kuu = Kuu + w*(Be'*C*Be + Beta'*D*Beta);
    Kup = Kup + w*(Be'*eV' + Beta'*muV')*Bphi;
    Kpp = Kpp + w*(Bphi'*kap*Bphi);
end, end
end

function s = pf(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
