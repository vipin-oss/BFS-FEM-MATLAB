function results = verify_randomized_D(quiet)
% VERIFY_RANDOMIZED_D  Deterministic randomized regression of the Mindlin
% D_Voigt against the five-invariant gradient energy.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part III, Eq. (III_W, III_I1..III_I5, III_Dmatrix, III_Dentries);
%   Part IV, Eq. (IV_h111..IV_h222) hV = D etaV.
%
% Fixed RNG seed (reproducible). For N = 120 random cases:
%   (a1..a5) random positive moduli;
%   etaV random 6-vector;
%   checks:  W_grad(five invariants) == 1/2 etaV' D etaV;
%            hV = D etaV is consistent (energy conjugate);
%            D == D^T;
%   reports max/mean/95th-percentile absolute and relative errors.
if nargin < 1, quiet = false; end
rng(20240817);            % fixed deterministic seed
N = 120;
err_quad = zeros(N,1); err_sym = zeros(N,1); err_conj = zeros(N,1);
for k = 1:N
    a = rand(1,5) + 0.1;               % positive random moduli [N]
    eta = 0.5*(rand(6,1) - 0.5)*1e2;   % random 6-vector (magnitude ~10)
    D = constitutive_D(a(1),a(2),a(3),a(4),a(5));
    W1 = 0.5*eta'*D*eta;
    W2 = W_grad_invariants(a, eta);
    err_quad(k) = abs(W1 - W2)/(abs(W2) + 1e-300);
    err_sym(k)  = max(max(abs(D - D')))/max(max(abs(D)));
    % conjugacy: hV' eta == 2 W1 (since hV = D eta)
    hV = D*eta;
    err_conj(k) = abs(hV'*eta - 2*W1)/(abs(2*W1) + 1e-300);
end
results.max_abs = max(err_quad); results.mean_abs = mean(err_quad);
results.p95 = quantile(err_quad, 0.95);
results.max_rel = max(err_quad); results.sym_rel = max(err_sym);
results.conj_rel = max(err_conj);
results.all_pass = (max(err_quad) < 1e-12) && (max(err_sym) < 1e-14) && (max(err_conj) < 1e-12);
if ~quiet
    fprintf('verify_randomized_D (N = %d, fixed seed):\n', N);
    fprintf('  W_grad == 1/2 eta^T D eta : max abs err %.3e  mean %.3e  95th-pct %.3e  [tol 1e-12] %s\n', ...
        max(err_quad), mean(err_quad), quantile(err_quad,0.95), pf(max(err_quad)<1e-12));
    fprintf('  D == D^T (relative)       : %.3e  [tol 1e-14] %s\n', max(err_sym), pf(max(err_sym)<1e-14));
    fprintf('  hV = D eta ; hV^T eta = 2W: %.3e  [tol 1e-12] %s\n', max(err_conj), pf(max(err_conj)<1e-12));
    fprintf('  OVERALL: %s\n\n', pf(results.all_pass));
end
end

function W = W_grad_invariants(a, etaV)
% five invariants in the 6 components [A B E F 2C 2D]
A = etaV(1); B = etaV(2); E = etaV(3); F = etaV(4);
C = etaV(5)/2; D = etaV(6)/2;
I1 = (A+E)*(A+D) + (B+F)*(C+F);
I2 = (A+D)^2 + (C+F)^2;
I3 = (A+E)^2 + (B+F)^2;
I4 = A^2 + B^2 + 2*C^2 + 2*D^2 + E^2 + F^2;
I5 = A^2 + 2*B*C + C^2 + 2*D*E + D^2 + F^2;
W  = a(1)*I1 + a(2)*I2 + a(3)*I3 + a(4)*I4 + a(5)*I5;
end

function s = pf(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
