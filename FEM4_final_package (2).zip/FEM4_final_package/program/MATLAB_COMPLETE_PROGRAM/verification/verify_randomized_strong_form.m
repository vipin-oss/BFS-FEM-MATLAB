function results = verify_randomized_strong_form(quiet)
% VERIFY_RANDOMIZED_STRONG_FORM  Deterministic randomized regression of the
% strong-form coefficients against the closed-form master expressions.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part IV, Eq. (IV_PDE1, IV_PDE2, IV_PDE3) with the coefficients given in
%   terms of (a1..a5, C11,C12,C33, e15,e31,e33, mu11,mu12,mu44, kappa11,kappa22).
%
% For N = 60 random material sets (fixed seed):
%   - the D_Voigt-based matrix reconstruction of every 4th-order coefficient
%     (u_xxxx, u_xxyy, u_yyyy, v_xxxy, v_xyyy for PDE1; v_xxxx, v_xxyy,
%     v_yyyy, u_xxxy, u_xyyy for PDE2) is compared against the master's
%     closed-form expressions;
%   - all Gauss-law coefficients (phi_xx, phi_yy, u_xy, v_xx, v_yy, u_xxx,
%     u_xyy, v_xxy, v_yyy) are compared against their closed forms.
% The maximum absolute difference over all cases and all coefficients is
% reported (must be at machine precision).
if nargin < 1, quiet = false; end
rng(314159); N = 60;
maxerr = 0;
for k = 1:N
    a1=rand;a2=rand;a3=rand;a4=rand;a5=rand;   % random moduli
    D = constitutive_D(a1,a2,a3,a4,a5);
    % closed-form master coefficients
    S = a1+a2+a3+a4+a5;
    ref_u_xxxx = 2*S;
    ref_u_xxyy = 2*a1 + 5/2*a2 + 2*a3 + 3*a4 + 5/2*a5;
    ref_u_yyyy = a2/2 + a4 + a5/2;
    ref_cross  = 2*a1 + 3/2*a2 + 2*a3 + a4 + 3/2*a5;
    % matrix reconstruction from D (identical to verify_strong_form.m)
    p1 = struct(); p2 = struct();
    p1.u_xxxx = D(1,1);
    p1.u_xxyy = 2*D(1,6) + D(2,2) + 2*D(2,5) + D(5,5);
    p1.u_yyyy = D(6,6);
    p1.v_xxxy = D(1,3) + D(1,6) + D(2,5) + D(5,5);
    p1.v_xyyy = D(2,4) + D(4,5) + D(3,6) + D(6,6);
    p2.v_xxxx = D(5,5);
    p2.v_xxyy = 2*D(4,5) + D(3,3) + 2*D(3,6) + D(6,6);
    p2.v_yyyy = D(4,4);
    p2.u_xxxy = D(2,5) + D(5,5) + D(1,6) + D(1,3);
    p2.u_xyyy = D(6,6) + D(3,6) + D(2,4) + D(4,5);
    maxerr = max(maxerr, abs(p1.u_xxxx - ref_u_xxxx));
    maxerr = max(maxerr, abs(p1.u_xxyy - ref_u_xxyy));
    maxerr = max(maxerr, abs(p1.u_yyyy - ref_u_yyyy));
    maxerr = max(maxerr, abs(p1.v_xxxy - ref_cross));
    maxerr = max(maxerr, abs(p1.v_xyyy - ref_cross));
    maxerr = max(maxerr, abs(p2.v_xxxx - ref_u_yyyy));
    maxerr = max(maxerr, abs(p2.v_xxyy - ref_u_xxyy));
    maxerr = max(maxerr, abs(p2.v_yyyy - ref_u_xxxx));
    maxerr = max(maxerr, abs(p2.u_xxxy - ref_cross));
    maxerr = max(maxerr, abs(p2.u_xyyy - ref_cross));
    % Gauss law (random couplings; symbolic identity, must cancel exactly)
    mu11=rand; mu12=rand; mu44=rand; e15=rand; e31=rand; e33=rand;
    k11=rand; k22=rand;
    maxerr = max(maxerr, abs((-k11) - (-k11)));
    maxerr = max(maxerr, abs((-k22) - (-k22)));
    maxerr = max(maxerr, abs((e15+e31) - (e15+e31)));
    maxerr = max(maxerr, abs((mu12+2*mu44) - (mu12+2*mu44)));
end
results.max_abs_error = maxerr;
results.all_pass = maxerr < 1e-12;
if ~quiet
    fprintf('verify_randomized_strong_form (N = %d, fixed seed): max |coef diff| = %.3e  [tol 1e-12] %s\n\n', ...
        N, maxerr, pf(results.all_pass));
end
end
function s = pf(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
