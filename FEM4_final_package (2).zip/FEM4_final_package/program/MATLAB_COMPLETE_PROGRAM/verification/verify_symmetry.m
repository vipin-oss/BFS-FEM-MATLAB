function results = verify_symmetry(quiet)
% VERIFY_SYMMETRY  Element/global symmetry and coupling-transpose identity.
%
% Mathematical source: FINAL_COMPLETE_MASTER_CALCULATION.tex
%   Part VI, Eq. (VI_transpose) K_phiu = K_uphi^T;
%   Part VIII, Eq. (VIII_transp_proof) element transpose proof;
%   Eq. (VI_saddle) symmetric indefinite saddle structure.
%
% Checks:
%  (1) K_uu^e symmetric; (2) K_phiphi^e symmetric;
%  (3) K_phiu^e == (K_uphi^e)^T (element level, computed independently);
%  (4) global saddle matrix symmetric.
if nargin < 1, quiet = false; end
p = simulation_parameters();
tol = p.tol_sym;
mat = material_BaTiO3();
mesh = generate_mesh(2, 1, 2.0e-6, 0.2e-6);   % tiny mesh

a = mesh.a; b = mesh.b;
C   = constitutive_C(mat.C11, mat.C12, mat.C33);
D   = constitutive_D(mat.a1, mat.a2, mat.a3, mat.a4, mat.a5);
eV  = piezoelectric_e(mat.e15, mat.e31, mat.e33);
muV = flexoelectric_mu(mat.mu11, mat.mu12, mat.mu44);
kap = dielectric_kappa(mat.kappa11, mat.kappa22);

Kuu_e = element_stiffness(a, b, C, D);
Kup_e = element_coupling(a, b, eV, muV);
Kpp_e = element_electrical(a, b, kap);

% independent adjoint form K_phiu^e = int (Bphi' e Be + Bphi' mu Beta)
[gp, gw] = gauss_legendre_4x4();
Kpu_e = zeros(4,32);
for i = 1:4, xi = gp(i); wi = gw(i);
    for j = 1:4, eta = gp(j); wj = gw(j);
        Be = B_e_matrix(xi,eta,a,b); Beta = B_eta_matrix(xi,eta,a,b);
        Bphi = B_phi_matrix(xi,eta,a,b);
        Kpu_e = Kpu_e + (wi*wj)*(Bphi'*eV*Be + Bphi'*muV*Beta)*(a*b);
    end
end

err_kuu  = max(max(abs(Kuu_e - Kuu_e')));
err_kpp  = max(max(abs(Kpp_e - Kpp_e')));
err_adj  = max(max(abs(Kpu_e - Kup_e')));

% global saddle symmetry
% (assembly returns SPARSE blocks, so max(max(...)) is a 1x1 SPARSE; MATLAB's
%  fprintf rejects sparse inputs, unlike Octave. Wrap in full() to store a
%  plain double scalar -- the numerical value and the test are unchanged.)
[Kuu, Kup, Kpp] = assembly(mesh, mat);
Ksaddle = [Kuu, Kup; Kup', -Kpp];
err_glob = full(max(max(abs(Ksaddle - Ksaddle'))));

ok1 = err_kuu < tol; ok2 = err_kpp < tol; ok3 = err_adj < tol; ok4 = err_glob < tol;
results.Kuu_symmetry_error  = err_kuu;
results.Kpp_symmetry_error  = err_kpp;
results.adjoint_error       = err_adj;
results.saddle_symmetry_error = err_glob;
results.all_pass = ok1 && ok2 && ok3 && ok4;

if ~quiet
    fprintf('verify_symmetry:\n');
    fprintf('  (1) K_uu^e symmetric            : max |err| = %.3e  [tol %.1e]  %s\n', err_kuu, tol, pf(ok1));
    fprintf('  (2) K_phiphi^e symmetric        : max |err| = %.3e  [tol %.1e]  %s\n', err_kpp, tol, pf(ok2));
    fprintf('  (3) K_phiu^e == (K_uphi^e)^T    : max |err| = %.3e  [tol %.1e]  %s\n', err_adj, tol, pf(ok3));
    fprintf('  (4) global saddle symmetric     : max |err| = %.3e  [tol %.1e]  %s\n', err_glob, tol, pf(ok4));
    fprintf('  OVERALL: %s\n\n', pf(results.all_pass));
end
end

function s = pf(ok)
if ok, s = 'PASS'; else, s = 'FAIL'; end
end
