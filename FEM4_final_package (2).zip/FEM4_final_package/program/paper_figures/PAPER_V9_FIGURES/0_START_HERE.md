# Ab kya karna hai — Figure 1 se shuru

Yeh folder **sirf figures** hai. Solver (`main`) yahan se **mat** chalana.

Solver zip alag thi (`BFS_FEM_MATLAB_PROGRAM.zip`).
Yeh zip figures ki hai.

---

## 1. Unzip

Is zip ko yahan rakhna best hai (path apna ho to badal lena):

```
D:\Research\Communicated Papers\FEM\FEM4\PAPER_V9_FIGURES
```

Unzip ke baad aapko yeh files dikhni chahiye:

- `0_START_HERE.md`   ← yeh file
- `FIGURE_SETTINGS.m` ← saari figures ki global setting
- `plot_paper_fig01.m` … `plot_paper_fig09.m`
- `check_data.m`
- `data\`             ← frozen CSVs (read-only)
- `figures\`          ← yahan PDF/PNG banegi
- `helpers\`

---

## 2. MATLAB R2020a — pehle yeh 3 lines

Command Window:

```matlab
cd('D:\Research\Communicated Papers\FEM\FEM4\PAPER_V9_FIGURES')
addpath(genpath(pwd))
check_data
```

Agar `All frozen CSVs found` aaye, tab Figure 1:

```matlab
plot_paper_fig01
```

**Abhi `plot_paper_fig02` … `09` ya `generate_all_paper_figures` mat chalana.**

---

## 3. Output kahan dikhega

1. MATLAB figure window khulegi (inspect yahi karo)
2. Files:

```
figures\Fig01_model.pdf
figures\Fig01_model.png
```

Figure 1 = 2 panels  
**(a)** cantilever + BCs (`L=2 µm`, `h=100 nm`, `F=1 nN`, `φ=0`, `Dᵢnᵢ=0`)  
**(b)** 36-DOF BFS element

Andar “Figure 1” title nahi hoga — caption manuscript mein hai.

---

## 4. Setting kaise badlein (phir dubara run)

| Kya badalna hai | Kaunsi file | Kahan |
|---|---|---|
| Font, line width, marker, PNG dpi (sab figures) | `FIGURE_SETTINGS.m` | upar ke numbers |
| Is figure ka size / panel position / annotation size | `plot_paper_fig01.m` | upar `SETTINGS` block |
| Data / physics numbers | **mat chhedna** | CSV frozen hai |

Edit save karo, phir Command Window mein sirf:

```matlab
plot_paper_fig01
```

Wahi window refresh ho jayegi + PDF/PNG overwrite.

---

## 5. Mujhe kya likhna hai

Figure 1 dekhne ke baad yahan likho:

- `Fig 1 OK`  
  **ya**
- kya change chahiye (example: “panel (b) bada karo”, “font 12”, “arrow mota”)

Tab Figure 2.

---

## Figure list (abhi 02–09 mat chalao)

| Command | File | Panels |
|---|---|---|
| `plot_paper_fig01` | Fig01_model | 2 — model |
| `plot_paper_fig02` | Fig02_fields | 4 — u, v, φ |
| `plot_paper_fig03` | Fig03_validation | 3 — rates / IEEE / actuator |
| `plot_paper_fig04` | Fig04_lambda | 2 — Λ |
| `plot_paper_fig05` | Fig05_slenderness | 3 — η_EM |
| `plot_paper_fig06` | Fig06_energy | 4 — energy |
| `plot_paper_fig07` | Fig07_hcrit | 2 — h_crit |
| `plot_paper_fig08` | Fig08_boundary | 2 — BCs |
| `plot_paper_fig09` | Fig09_conditioning | 2 — κ |
