function S = FIGURE_SETTINGS()
% FIGURE_SETTINGS  Global look for all 9 paper figures.
%
% Edit THIS file for fonts / line width / export. Then re-run
%   plot_paper_fig01
% (or whichever figure you are inspecting).
%
% Per-figure layout (panel size, view angle, ylim) is in
%   plot_paper_fig0k.m
% at the top SETTINGS block.
%
% Do not put CSV numbers here. Data stay frozen.
% ABSOLUTE RULE: no visible figure text above 14 pt.

S = struct();

% --- fonts (Times; keep <= 14) ---
S.fontName    = 'Times New Roman';
S.tickFont    = 10;     % axis tick numbers
S.labelFont   = 11;     % x/y/z labels  (tickFont * multiplier)
S.legendFont  = 9;      % legend
S.panelFont   = 11;     % (a) (b) (c)
S.annoFont    = 10;     % small math annotations
S.cbFont      = 9;      % colorbar
S.interpreter = 'latex'; % set 'tex' only if LaTeX labels fail

% --- lines / markers ---
S.lineWidth   = 1.7;
S.axesLine    = 0.9;
S.markerSize  = 6.5;

% --- page ---
S.figWidth    = 7.16;   % inches, IEEE two-column
S.figColor    = [1 1 1];

% --- export ---
S.exportRes   = 300;    % PNG dpi
S.closeAfter  = false;  % keep the MATLAB window open so you can inspect

% --- data (leave empty = auto-find paper_v9/data) ---
% Example if you move the CSVs:
% S.dataDir = 'D:\Research\Communicated Papers\FEM\FEM4\PAPER_V9_FIGURES\data';
S.dataDir     = '';
end
