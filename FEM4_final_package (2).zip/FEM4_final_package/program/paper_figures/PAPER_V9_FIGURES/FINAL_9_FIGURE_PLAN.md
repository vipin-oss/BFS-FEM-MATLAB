# Final 9-figure plan

Authoritative physics: linear plane-strain piezoelectric–flexoelectric
BFS FEM, Mindlin Form-II SGE, quasi-static. No thermal field, no
geometric nonlinearity, no dynamics.

Diagnostic \(\mu_T\) reactivation is **supplementary**, not Figure 10.

## Story

model → fields → validation → \(\Lambda\) → slenderness → energy
→ \(h_{\mathrm{crit}}\) → BCs → conditioning

## Figures

### Figure 1 — Model (`plot_paper_fig01`)
| Panel | Type | Quantity | Why |
|---|---|---|---|
| (a) | schematic | \(L\), \(h\), \(F\), \(\phi=0\), \(D_in_i=0\) | what is solved |
| (b) | schematic | 36-DOF BFS | how it is discretised |

No CSV.

### Figure 2 — Coupled fields (`plot_paper_fig02`)
| Panel | Type | Quantity | Data |
|---|---|---|---|
| (a) | 2-D field, diverging | \(u\) | `field_export.csv` 60×12 |
| (b) | 2-D field, sequential | \(v\) | same |
| (c) | 2-D field, sequential | \(\phi\) | same |
| (d) | 3-D surface | \(\phi(x,y)\) | same nodal values |

\(|\mathbf D|\) is **not** plotted (slope/twist DOFs not exported).

### Figure 3 — Validation (`plot_paper_fig03`)
| Panel | Type | Quantity | Data |
|---|---|---|---|
| (a) | log–log | \(e\) vs \(h\), slopes 4/3/2 | quoted norms (master Part XI) |
| (b) | markers | \(k_{31}\), \(E_{\mathrm{open}}\) / IEEE | `tier2_benchmark.csv` |
| (c) | markers | \(\lvert w_{\mathrm{tip}}\rvert\) analytic vs FEM | `actuator_response.csv` |

IEEE is a **standard**, not a competing paper. Shekarchizadeh is named
in the caption, not on the axes.

### Figure 4 — \(\Lambda\) (`plot_paper_fig04`)
| Panel | Type | Quantity | Data |
|---|---|---|---|
| (a) | semilog | \(\max\lvert\phi\rvert(\Lambda)\) | `lambda_study.csv` (10 \(\mu_0\)) |
| (b) | log–log | \(\max\lvert\phi\rvert/\mu_0\) | same sweep |

Only **one** independent parameter (\(\mu_0\)). No second family exists.
A 3-D \(\Lambda\) surface is not drawn.

### Figure 5 — Slenderness (`plot_paper_fig05`)
| Panel | Type | Quantity | Data |
|---|---|---|---|
| (a) | multi-curve log–log | \(\eta_{\mathrm{EM}}(L/h)\) at \(N_y=8,12,16\) | aspect + brackets + high-\(N_y\) |
| (b) | multi-curve | \(\eta_{\mathrm{EM}}(N_y)\) at \(L/h=20,40,60\) | same |
| (c) | 3-D scatter | actual \((L/h,N_y,\eta_{\mathrm{EM}})\) | same; **no interpolant** |

Source-reported \(2.79\times10^{-5}(L/h)^{1.94}\) is dashed and labelled
as such.

### Figure 6 — Energy (`plot_paper_fig06`)
| Panel | Type | Quantity | Data |
|---|---|---|---|
| (a) | 4 curves | \(U_{\mathrm{mech}},W_{\mathrm{qs}},U_{\mathrm{coup}},U_{\mathrm{elec}}\) | `aspect_ratio_study.csv` |
| (b) | 1 curve | \(U_{\mathrm{elec}}/U_{\mathrm{mech}}\) | same |
| (c) | 3 curves | \(U_{\mathrm{elas}},U_{\mathrm{grad}},U_{\mathrm{elec}}\) vs \(N_y\) | `ETAEM_ELEMENT_ENERGY_LOCALIZATION.csv` |
| (d) | 3-D surface | \(\log_{10}U_{\mathrm{elec}}(x,y)\) | `forensic/elem_Lh40_Ny16.csv` |

### Figure 7 — \(h_{\mathrm{crit}}\) (`plot_paper_fig07`)
| Panel | Type | Quantity | Data |
|---|---|---|---|
| (a) | log–log | four roots + two power laws | `hcrit_study.csv` |
| (b) | residual | independent-fit residual (%) | same coefficients |

Fit values are those stored in the CSV (\(A=24.20\), \(p=0.8998\)).

### Figure 8 — Boundary conditions (`plot_paper_fig08`)
| Panel | Type | Quantity | Data |
|---|---|---|---|
| (a) | 3 markers | \(v_{\mathrm{tip}}\) + Euler–Bernoulli line | `boundary_condition_study.csv` |
| (b) | 3 markers | \(\max\lvert\phi\rvert\) | same |

Discrete BCs: full clamp; \(u=v=0\); \(u=v=u_{,x}=0\). No bars.

### Figure 9 — Conditioning (`plot_paper_fig09`)
| Panel | Type | Quantity | Data |
|---|---|---|---|
| (a) | 4 curves | \(\kappa(N_x)\) for A/B/C/D | `conditioning_reconciliation.csv` |
| (b) | 4 curves | \(\kappa\) vs strategy, one curve per \(N_x\) | same |

Manuscript `tab:cond` table. Not the true-geometry \(10^9\) table.
No 3-D bars.

## Supplementary (not generated here)

- Diagnostic \(\mu_T\) (`ASPECT_RATIO_TENSOR_CAUSALITY.csv`)
- True-geometry conditioning
- Forensic through-thickness profiles

## Rejected

- Polar plots (no angular constitutive parameter)
- Interpolated \(\eta_{\mathrm{EM}}(L/h,N_y)\) surface (sparse grid)
- Invented \(\lvert\mathbf D\rvert\)
- Thermal / nonlinear / modal-\(n\) content
