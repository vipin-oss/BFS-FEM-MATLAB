# Nine main paper figures — MATLAB R2020a

Frozen-CSV plotting layer for

> A Conforming \(C^1\) Bogner–Fox–Schmit Finite Element Formulation for
> Coupled Piezoelectric–Flexoelectric Continuum Media with Mindlin Form-II
> Strain-Gradient Elasticity

**Does not call the FEM solver. Does not change any number.**

Start here: `0_START_HERE.md`

Old scripts in `SCI_PAPER_FIGURES/matlab/` and `FIGURES_REFINED/` were
**not deleted**.

## First review (one figure at a time)

```matlab
cd('D:\Research\Communicated Papers\FEM\FEM4\PAPER_V9_FIGURES')
addpath(genpath(pwd))
check_data
plot_paper_fig01
```

Then inspect the window and `figures\Fig01_model.pdf`.
Edit `FIGURE_SETTINGS.m` (global) or the `SETTINGS` block in
`plot_paper_fig01.m` (this figure) and re-run the same command.

Do not start with `generate_all_paper_figures`.

## Data

Bundled in `./data/` (copies of the production CSVs). Read-only.
If you move them, set `S.dataDir` in `FIGURE_SETTINGS.m`.

## What you may edit

| File | Changes |
|---|---|
| `FIGURE_SETTINGS.m` | fonts, line/marker, export dpi |
| `plot_paper_fig0k.m` SETTINGS block | size, panel positions, view, ylim, legend location |
| `helpers/okabe.m`, `seq_map.m`, `diverging_map.m` | colours |

Do **not** edit CSV values, solver files, or `main (3).tex`.

## Documents

| File | Content |
|---|---|
| `0_START_HERE.md` | Hindi/English 1-by-1 run guide |
| `FINAL_9_FIGURE_PLAN.md` | scientific story and panel list |
| `reports/FINAL_FIGURE_SCIENTIFIC_AUDIT.md` | panel-by-panel audit |
| `reports/FIGURE_MAPPING.md` | Figure → quantity → CSV → manuscript section |

## MATLAB R2020a

- `subplot` / `axes` (no `tiledlayout` required)
- `exportgraphics` with `print` fallback
- no `string` arrays, no `arguments`, no `dictionary`
- Times New Roman, **maximum 14 pt**
- LaTeX interpreter on labels (set `S.interpreter = 'tex'` if it fails)
