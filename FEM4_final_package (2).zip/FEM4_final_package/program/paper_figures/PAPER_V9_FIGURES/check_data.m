function check_data()
% CHECK_DATA  Confirm frozen CSVs are visible. Run this once after unzip.
root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'helpers'));
addpath(root);
setup_paper();
d = data_dir();
need = { ...
    'field_export.csv', ...
    'tier2_benchmark.csv', ...
    'actuator_response.csv', ...
    'lambda_study.csv', ...
    'aspect_ratio_study.csv', ...
    'ASPECT_RATIO_FINAL_CONVERGENCE.csv', ...
    'ETAEM_HIGH_SLENDERNESS_MESH_STUDY.csv', ...
    'ETAEM_ELEMENT_ENERGY_LOCALIZATION.csv', ...
    'hcrit_study.csv', ...
    'boundary_condition_study.csv', ...
    'conditioning_reconciliation.csv'};
need2 = {'forensic/elem_Lh40_Ny16.csv'};
ok = true;
fprintf('data_dir =\n  %s\n\n', d);
for i = 1:numel(need)
    f = fullfile(d, need{i});
    if exist(f, 'file') == 2
        fprintf('  OK      %s\n', need{i});
    else
        fprintf('  MISSING %s\n', need{i});
        ok = false;
    end
end
for i = 1:numel(need2)
    f = fullfile(d, need2{i});
    if exist(f, 'file') == 2
        fprintf('  OK      %s\n', need2{i});
    else
        fprintf('  MISSING %s\n', need2{i});
        ok = false;
    end
end
fprintf('\n');
if ok
    fprintf('All frozen CSVs found.\nNext:  plot_paper_fig01\n');
else
    error('check_data:missing', ...
        'Copy the data folder next to these .m files, or set FIGURE_SETTINGS.dataDir');
end
end
