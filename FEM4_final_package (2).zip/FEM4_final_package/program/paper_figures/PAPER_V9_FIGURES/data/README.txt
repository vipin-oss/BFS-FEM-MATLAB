Frozen production CSVs. The figure layer only reads these files.
Do not edit values. Do not replace with interpolated data.
