PDF and PNG from plot_paper_fig01 ... plot_paper_fig09 land here.
Do not put source CSVs in this folder.
