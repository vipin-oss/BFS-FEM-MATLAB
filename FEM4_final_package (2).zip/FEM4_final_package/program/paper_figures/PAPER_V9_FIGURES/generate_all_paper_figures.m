function generate_all_paper_figures()
% GENERATE_ALL_PAPER_FIGURES  Build the 9 main SCI figures (MATLAB R2020a).
%
% First review: do NOT start here. Run one figure at a time:
%   plot_paper_fig01
%   ...
%   plot_paper_fig09
%
% Reads frozen CSVs. Writes PDF+PNG to ./figures/.
% Does not call the FEM solver. Does not modify any numerical result.
root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'helpers'));
addpath(root);
setup_paper();
fprintf('Nine main paper figures from frozen CSVs (R2020a)\n');
plot_paper_fig01();
plot_paper_fig02();
plot_paper_fig03();
plot_paper_fig04();
plot_paper_fig05();
plot_paper_fig06();
plot_paper_fig07();
plot_paper_fig08();
plot_paper_fig09();
fprintf('done. Output: %s\n', fullfile(root, 'figures'));
end
