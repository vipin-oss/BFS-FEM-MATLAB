function d = data_dir()
% DATA_DIR  Frozen CSVs. Never written by the figure layer.
% Search order:
%   1) FIGURE_SETTINGS.dataDir  (if you set it)
%   2) PAPER_V9_FIGURES/data    (bundled with this zip)
%   3) SCI_PAPER_FIGURES/data
%   4) MATLAB_COMPLETE_PROGRAM/output
%   5) FIGURES_REFINED/data
%   6) ./data next to pwd
here = fileparts(mfilename('fullpath'));
root = fileparts(here);

override = '';
if exist('FIGURE_SETTINGS', 'file') == 2
    S = FIGURE_SETTINGS();
    if isfield(S, 'dataDir') && ~isempty(S.dataDir)
        override = S.dataDir;
    end
end

cands = {};
if ~isempty(override), cands{end+1} = override; end %#ok<AGROW>
cands{end+1} = fullfile(root, 'data');
cands{end+1} = fullfile(root, '..', 'data');
cands{end+1} = fullfile(root, '..', 'MATLAB_COMPLETE_PROGRAM', 'output');
cands{end+1} = fullfile(root, '..', '..', 'MATLAB_COMPLETE_PROGRAM', 'output');
cands{end+1} = fullfile(root, '..', 'FIGURES_REFINED', 'data');
cands{end+1} = fullfile(pwd, 'data');

marker = 'field_export.csv';
for i = 1:numel(cands)
    if exist(fullfile(cands{i}, marker), 'file') == 2
        d = cands{i};
        return
    end
end

error('data_dir:notFound', [ ...
    'Frozen CSVs not found (looked for field_export.csv).\n' ...
    'Copy the data folder next to the .m files, or set\n' ...
    '  S.dataDir  inside FIGURE_SETTINGS.m']);
end
