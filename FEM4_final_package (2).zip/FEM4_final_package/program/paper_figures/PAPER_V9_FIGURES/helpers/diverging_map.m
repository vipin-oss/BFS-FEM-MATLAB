function cmap = diverging_map(n)
% DIVERGING_MAP  Blue-white-red, zero-centred. R2020a (no toolbox).
if nargin < 1, n = 256; end
ctrl = [0.03 0.27 0.58; 0.40 0.65 0.85; 0.97 0.97 0.97; ...
        0.90 0.45 0.32; 0.64 0.06 0.08];
xi = linspace(0, 1, size(ctrl,1));
xq = linspace(0, 1, n);
cmap = [interp1(xi, ctrl(:,1), xq)', ...
        interp1(xi, ctrl(:,2), xq)', ...
        interp1(xi, ctrl(:,3), xq)'];
end
