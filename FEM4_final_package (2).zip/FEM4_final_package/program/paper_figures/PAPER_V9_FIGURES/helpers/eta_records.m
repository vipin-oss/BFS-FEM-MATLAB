function [recLh, recNy, recEta, P] = eta_records()
% ETA_RECORDS  Assemble existing (L/h, Ny, eta_EM) triples. No fill-in.
% rec* are column vectors of the same length. P is aspect_ratio_study.
P = load_csv(fullfile(data_dir(), 'aspect_ratio_study.csv'));
B = load_csv(fullfile(data_dir(), 'ASPECT_RATIO_FINAL_CONVERGENCE.csv'));
S = load_csv(fullfile(data_dir(), 'ETAEM_HIGH_SLENDERNESS_MESH_STUDY.csv'));
% Use a simple key table
Lh = []; Ny = []; Eta = [];
for i = 1:size(P,1)
    Lh(end+1,1) = P(i,1); %#ok<AGROW>
    Ny(end+1,1) = 12;     %#ok<AGROW>
    Eta(end+1,1) = P(i,12); %#ok<AGROW>
end
for i = 1:size(B,1)
    nyi = B(i,5);
    if abs(nyi-12) > 0.1
        Lh(end+1,1) = B(i,1); %#ok<AGROW>
        Ny(end+1,1) = nyi;    %#ok<AGROW>
        Eta(end+1,1) = B(i,7); %#ok<AGROW>
    end
end
for i = 1:size(S,1)
    if size(S,2) >= 16 && isfinite(S(i,16))
        % overwrite if same (Lh,Ny)
        found = false;
        for k = 1:numel(Lh)
            if abs(Lh(k)-S(i,1))<1e-8 && abs(Ny(k)-S(i,5))<1e-8
                Eta(k) = S(i,16); found = true; break;
            end
        end
        if ~found
            Lh(end+1,1) = S(i,1); %#ok<AGROW>
            Ny(end+1,1) = S(i,5); %#ok<AGROW>
            Eta(end+1,1) = S(i,16); %#ok<AGROW>
        end
    end
end
recLh = Lh; recNy = Ny; recEta = Eta;
end
