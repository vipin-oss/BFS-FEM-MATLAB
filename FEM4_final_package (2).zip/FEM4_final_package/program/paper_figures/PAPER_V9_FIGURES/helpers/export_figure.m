function export_figure(fig, name)
% EXPORT_FIGURE  Write PDF+PNG into ./figures. R2020a-safe.
% Leaves the figure window open unless FIGURE_SETTINGS.closeAfter = true.
here = fileparts(mfilename('fullpath'));
outdir = fullfile(here, '..', 'figures');
if exist(outdir, 'dir') ~= 7, mkdir(outdir); end
pdf = fullfile(outdir, [name '.pdf']);
png = fullfile(outdir, [name '.png']);
res = 300;
if exist('FIGURE_SETTINGS', 'file') == 2
    S = FIGURE_SETTINGS();
    if isfield(S, 'exportRes') && ~isempty(S.exportRes)
        res = S.exportRes;
    end
end
if exist('exportgraphics', 'file') == 2
    exportgraphics(fig, pdf, 'ContentType', 'vector', 'BackgroundColor', 'white');
    exportgraphics(fig, png, 'Resolution', res, 'BackgroundColor', 'white');
else
    set(fig, 'PaperPositionMode', 'auto');
    print(fig, pdf, '-dpdf', '-painters');
    print(fig, png, '-dpng', ['-r' num2str(res)]);
end
fprintf('  wrote %s\n', fullfile(outdir, name));
if exist('FIGURE_SETTINGS', 'file') == 2
    S = FIGURE_SETTINGS();
    if isfield(S, 'closeAfter') && S.closeAfter
        close(fig);
    end
end
end
