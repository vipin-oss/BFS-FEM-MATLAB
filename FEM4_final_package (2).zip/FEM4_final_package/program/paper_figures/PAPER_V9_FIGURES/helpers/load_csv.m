function A = load_csv(fname)
% LOAD_CSV  Numeric CSV reader. Non-numeric cells become NaN.
% Works on MATLAB R2020a (no detectImportOptions required).
fid = fopen(fname, 'r');
if fid < 0, error('load_csv:cannotOpen', 'cannot open %s', fname); end
C = textscan(fid, '%s', 'Delimiter', '\n', 'Whitespace', '');
fclose(fid);
lines = C{1};
if isempty(lines), A = []; return; end
% drop header
rows = {};
for k = 2:numel(lines)
    tok = strsplit(strtrim(lines{k}), ',');
    if isempty(tok) || all(cellfun(@isempty, tok)), continue; end
    v = nan(1, numel(tok));
    anyfin = false;
    for j = 1:numel(tok)
        x = str2double(tok{j});
        if ~isnan(x), v(j) = x; anyfin = true; end
    end
    if anyfin, rows{end+1} = v; end %#ok<AGROW>
end
if isempty(rows), A = []; return; end
w = max(cellfun(@numel, rows));
A = nan(numel(rows), w);
for i = 1:numel(rows)
    A(i, 1:numel(rows{i})) = rows{i};
end
end
