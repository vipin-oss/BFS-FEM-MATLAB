function [X, Y, U, V, P] = load_fields()
% LOAD_FIELDS  Mesh 60 x 12 nodal fields from field_export.csv.
% Columns: x_um, y_nm, u_nm, v_nm, phi_V. Reshape Fortran order.
D = load_csv(fullfile(data_dir(), 'field_export.csv'));
Ny = 12; Nx = 60;
X = reshape(D(:,1), Ny+1, Nx+1) / 2.0;          % x/L
Y = reshape(D(:,2), Ny+1, Nx+1) / 100.0;        % y/h
U = reshape(D(:,3), Ny+1, Nx+1) * 1e-9;         % m
V = reshape(D(:,4), Ny+1, Nx+1) * 1e-9;         % m
P = reshape(D(:,5), Ny+1, Nx+1);                % V
end
