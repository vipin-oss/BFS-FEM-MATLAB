function c = okabe(i)
% OKABE  Okabe-Ito colourblind-safe palette (1-based, cycles).
p = [ 0.000 0.000 0.000;   % 1 black
      0.902 0.624 0.000;   % 2 orange
      0.337 0.706 0.914;   % 3 sky
      0.000 0.620 0.451;   % 4 green
      0.941 0.894 0.259;   % 5 yellow
      0.000 0.447 0.698;   % 6 blue
      0.835 0.369 0.000;   % 7 vermillion
      0.800 0.475 0.655 ]; % 8 purple
c = p(mod(i-1, size(p,1)) + 1, :);
end
