function panel_label(ax, letter)
% PANEL_LABEL  (a), (b), ...  Not a figure title. Max 14 pt.
fs = 11;
if exist('FIGURE_SETTINGS', 'file') == 2
    S = FIGURE_SETTINGS();
    if isfield(S, 'panelFont'), fs = S.panelFont; end
end
text(ax, 0.03, 0.96, ['(' letter ')'], 'Units', 'normalized', ...
    'FontName', 'Times New Roman', 'FontSize', fs, 'FontWeight', 'bold', ...
    'Interpreter', 'tex', 'VerticalAlignment', 'top', ...
    'HorizontalAlignment', 'left', 'BackgroundColor', 'w', 'Margin', 1);
end
