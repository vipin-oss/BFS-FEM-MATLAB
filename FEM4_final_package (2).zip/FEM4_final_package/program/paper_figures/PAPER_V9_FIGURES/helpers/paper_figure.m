function fig = paper_figure(tag, figW, figH)
% PAPER_FIGURE  Reuse the same window when you re-run a figure after edits.
fig = findall(0, 'Type', 'figure', 'Tag', tag);
if ~isempty(fig)
    if numel(fig) > 1
        close(fig(2:end));
        fig = fig(1);
    end
    figure(fig);
    clf(fig);
    set(fig, 'Color', 'w', 'Units', 'inches', ...
        'Position', [1 1 figW figH], 'Name', tag, 'NumberTitle', 'off', ...
        'Tag', tag);
else
    fig = figure('Color', 'w', 'Units', 'inches', ...
        'Position', [1 1 figW figH], 'Tag', tag, ...
        'Name', tag, 'NumberTitle', 'off');
end
end
