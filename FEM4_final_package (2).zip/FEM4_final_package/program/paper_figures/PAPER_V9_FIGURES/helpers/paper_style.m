function paper_style()
% PAPER_STYLE  SCI defaults from FIGURE_SETTINGS. MATLAB R2020a. Max 14 pt.
if exist('FIGURE_SETTINGS', 'file') == 2
    S = FIGURE_SETTINGS();
else
    S = struct('fontName', 'Times New Roman', 'tickFont', 10, ...
        'labelFont', 11, 'legendFont', 9, 'lineWidth', 1.7, ...
        'axesLine', 0.9, 'markerSize', 6.5, 'interpreter', 'latex', ...
        'figColor', [1 1 1]);
end
if ~isfield(S, 'figColor'),     S.figColor = [1 1 1]; end
if ~isfield(S, 'interpreter'),  S.interpreter = 'latex'; end
if ~isfield(S, 'axesLine'),     S.axesLine = 0.9; end
mult = S.labelFont / max(S.tickFont, 1);
set(groot, 'defaultFigureColor', S.figColor);
set(groot, 'defaultAxesFontName', S.fontName);
set(groot, 'defaultTextFontName', S.fontName);
set(groot, 'defaultAxesFontSize', S.tickFont);
set(groot, 'defaultAxesLabelFontSizeMultiplier', mult);
set(groot, 'defaultAxesTitleFontSizeMultiplier', 1.0);
set(groot, 'defaultAxesLineWidth', S.axesLine);
set(groot, 'defaultAxesTickDir', 'in');
set(groot, 'defaultAxesBox', 'on');
set(groot, 'defaultLineLineWidth', S.lineWidth);
set(groot, 'defaultLineMarkerSize', S.markerSize);
set(groot, 'defaultLegendBox', 'on');
set(groot, 'defaultLegendFontSize', S.legendFont);
set(groot, 'defaultLegendInterpreter', S.interpreter);
set(groot, 'defaultTextInterpreter', S.interpreter);
set(groot, 'defaultAxesTickLabelInterpreter', S.interpreter);
end
