function cmap = seq_map(n)
% SEQ_MAP  Restrained cream-teal-navy sequential map. R2020a.
if nargin < 1, n = 256; end
ctrl = [0.99 0.97 0.88; 0.70 0.85 0.70; 0.20 0.58 0.62; 0.10 0.18 0.42];
xi = linspace(0, 1, size(ctrl,1));
xq = linspace(0, 1, n);
cmap = [interp1(xi, ctrl(:,1), xq)', ...
        interp1(xi, ctrl(:,2), xq)', ...
        interp1(xi, ctrl(:,3), xq)'];
end
