function setup_paper()
% SETUP_PAPER  Put helpers + paper_v9 root on the path, apply style.
here = fileparts(mfilename('fullpath'));   % .../helpers
root = fileparts(here);                    % .../paper_v9 (or PAPER_V9_FIGURES)
addpath(here);
addpath(root);
paper_style();
end
