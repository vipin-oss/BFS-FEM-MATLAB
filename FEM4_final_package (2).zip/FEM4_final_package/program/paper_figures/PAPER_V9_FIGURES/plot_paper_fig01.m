function plot_paper_fig01()
% PLOT_PAPER_FIG01  Geometry and BFS element (2 panels).
%
% RUN (after cd to this folder + addpath(genpath(pwd))):
%   plot_paper_fig01
%
% EDIT look:
%   FIGURE_SETTINGS.m          -> fonts, line width (all figures)
%   SETTINGS block below       -> this figure only
% Do not change L, h, F numbers: they are the frozen baseline.

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'helpers'));
addpath(root);
setup_paper();

%% ===== SETTINGS (look / layout only) =====
figW    = 7.16;                 % inches
figH    = 3.10;
posA    = [0.04 0.10 0.50 0.84];
posB    = [0.56 0.08 0.42 0.86];
fsAnno  = 10;
fsPanel = 11;
beamRGB = [0.89 0.93 0.96];
elemRGB = [0.96 0.96 0.94];
%% ========================================

fig = paper_figure('Fig01_model', figW, figH);

% ---- (a) cantilever ----
ax = axes('Parent', fig, 'Position', posA);
hold(ax, 'on'); axis(ax, 'equal'); axis(ax, 'off');
L = 2.40; h = 0.52; x0 = 0.38; y0 = 0.58;
fill(ax, [x0 x0+L x0+L x0], [y0 y0 y0+h y0+h], beamRGB, ...
    'EdgeColor', 'k', 'LineWidth', 1.15);
for yy = linspace(y0, y0+h, 8)
    plot(ax, [x0-0.16 x0], [yy-0.09 yy], 'k-', 'LineWidth', 0.55);
end
plot(ax, [x0 x0], [y0 y0+h], 'k-', 'LineWidth', 2.0);
plot(ax, [x0-0.06 x0+0.06], [y0-0.08 y0-0.08], 'k-', 'LineWidth', 1.0);
plot(ax, [x0-0.04 x0+0.04], [y0-0.12 y0-0.12], 'k-', 'LineWidth', 1.0);
plot(ax, [x0-0.02 x0+0.02], [y0-0.16 y0-0.16], 'k-', 'LineWidth', 1.0);
text(ax, x0+0.16, y0-0.14, '$\phi=0$', 'Interpreter', 'latex', 'FontSize', fsAnno);
quiver(ax, x0+L, y0+h/2+0.02, 0, -0.38, 0, 'Color', okabe(7), ...
    'LineWidth', 1.6, 'MaxHeadSize', 0.55);
text(ax, x0+L+0.08, y0+h/2-0.12, '$F=1\,\mathrm{nN}$', ...
    'Interpreter', 'latex', 'FontSize', fsAnno, 'Color', okabe(7));
plot(ax, [x0 x0+L], [y0-0.30 y0-0.30], 'k-', 'LineWidth', 0.8);
text(ax, x0+L/2, y0-0.44, '$L=2\,\mu\mathrm{m}$', 'Interpreter', 'latex', ...
    'FontSize', fsAnno, 'HorizontalAlignment', 'center');
text(ax, x0+L+0.28, y0+h/2, '$h=100\,\mathrm{nm}$', 'Interpreter', 'latex', ...
    'FontSize', fsAnno, 'Rotation', 90, 'HorizontalAlignment', 'center');
plot(ax, [x0+0.22 x0+L-0.18], [y0+h+0.10 y0+h+0.10], '--', ...
    'Color', okabe(6), 'LineWidth', 0.9);
text(ax, x0+L/2, y0+h+0.22, '$D_i n_i=0$', 'Interpreter', 'latex', ...
    'FontSize', fsAnno, 'HorizontalAlignment', 'center', 'Color', okabe(6));
text(ax, x0+L/2, y0+h/2, 'BaTiO$_3$', 'Interpreter', 'latex', ...
    'FontSize', 11, 'HorizontalAlignment', 'center');
text(ax, 0.02, 0.96, '(a)', 'Units', 'normalized', 'FontName', 'Times New Roman', ...
    'FontSize', fsPanel, 'FontWeight', 'bold', 'Interpreter', 'tex');
axis(ax, [-0.12 3.15 0.00 1.55]);

% ---- (b) BFS ----
axb = axes('Parent', fig, 'Position', posB);
hold(axb, 'on'); axis(axb, 'equal'); axis(axb, 'off');
ex0 = 0.30; ey0 = 0.38; ew = 1.52; eh = 1.05;
fill(axb, [ex0 ex0+ew ex0+ew ex0], [ey0 ey0 ey0+eh ey0+eh], ...
    elemRGB, 'EdgeColor', 'k', 'LineWidth', 1.15);
pts = [ex0 ey0; ex0+ew ey0; ex0+ew ey0+eh; ex0 ey0+eh];
labs = {'1','2','3','4'};
for k = 1:4
    plot(axb, pts(k,1), pts(k,2), 'o', 'MarkerSize', 9, ...
        'MarkerFaceColor', okabe(6), 'MarkerEdgeColor', 'k');
    text(axb, pts(k,1), pts(k,2), labs{k}, 'Color', 'w', 'FontSize', 8, ...
        'FontWeight', 'bold', 'HorizontalAlignment', 'center', 'Interpreter', 'tex');
end
text(axb, ex0+ew/2, ey0+eh/2, '$36$ DOF', 'Interpreter', 'latex', ...
    'FontSize', 11, 'HorizontalAlignment', 'center');
text(axb, ex0+ew/2, ey0-0.16, '$(\xi,\eta)\in[-1,1]^2$', ...
    'Interpreter', 'latex', 'FontSize', 9, 'HorizontalAlignment', 'center');
text(axb, ex0+ew/2, ey0+eh+0.26, ...
    {'$[u,u_{,x},u_{,y},u_{,xy}]$', '$[v,v_{,x},v_{,y},v_{,xy}]$', '$\phi$'}, ...
    'Interpreter', 'latex', 'FontSize', 9, 'HorizontalAlignment', 'center', ...
    'BackgroundColor', 'w', 'EdgeColor', okabe(6));
text(axb, 0.02, 0.96, '(b)', 'Units', 'normalized', 'FontName', 'Times New Roman', ...
    'FontSize', fsPanel, 'FontWeight', 'bold', 'Interpreter', 'tex');
axis(axb, [0.05 2.15 0.05 1.95]);
export_figure(fig, 'Fig01_model');
end
