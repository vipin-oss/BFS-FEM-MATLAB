function plot_paper_fig02()
% PLOT_PAPER_FIG02  Coupled fields u, v, phi + 3-D phi. 4 panels.
%
% RUN:  plot_paper_fig02
% EDIT: SETTINGS below, or FIGURE_SETTINGS.m
% DATA: field_export.csv  (60 x 12). Do not invent |D|.

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'helpers'));
addpath(root);
setup_paper();
[X, Y, U, V, P] = load_fields();

%% ===== SETTINGS (look / layout only) =====
figW   = 7.16;
figH   = 5.80;
posA   = [0.07 0.56 0.32 0.36];
posB   = [0.56 0.56 0.32 0.36];
posC   = [0.07 0.10 0.32 0.36];
posD   = [0.54 0.08 0.40 0.40];
az     = -52;     % 3-D camera
el     = 22;
%% ========================================

fig = paper_figure('Fig02_fields', figW, figH);

ax = axes('Parent', fig, 'Position', posA);
field2d(ax, X, Y, U*1e17, diverging_map(256), true, '$u$ ($10^{-17}\,\mathrm{m}$)');
panel_label(ax, 'a');

ax = axes('Parent', fig, 'Position', posB);
field2d(ax, X, Y, V*1e16, seq_map(256), false, '$v$ ($10^{-16}\,\mathrm{m}$)');
panel_label(ax, 'b');

ax = axes('Parent', fig, 'Position', posC);
field2d(ax, X, Y, P*1e10, seq_map(256), false, '$\phi$ ($10^{-10}\,\mathrm{V}$)');
hold(ax, 'on'); plot(ax, 0, 0, 'k^', 'MarkerSize', 5);
panel_label(ax, 'c');

ax = axes('Parent', fig, 'Position', posD);
surf(ax, X, Y, P*1e10, 'EdgeColor', 'none', 'FaceColor', 'interp');
colormap(ax, seq_map(256));
xlabel(ax, '$x/L$', 'Interpreter', 'latex', 'FontSize', 10);
ylabel(ax, '$y/h$', 'Interpreter', 'latex', 'FontSize', 10);
zlabel(ax, '$\phi$ ($10^{-10}\,\mathrm{V}$)', 'Interpreter', 'latex', 'FontSize', 10);
view(ax, az, el);
cb = colorbar(ax); set(cb, 'FontSize', 9);
set(ax, 'FontName', 'Times New Roman', 'FontSize', 9, 'Box', 'on');
text(ax, 0.03, 0.96, '(d)', 'Units', 'normalized', 'FontName', 'Times New Roman', ...
    'FontSize', 11, 'FontWeight', 'bold', 'Interpreter', 'tex', ...
    'BackgroundColor', 'w', 'Margin', 1);
export_figure(fig, 'Fig02_fields');
end

function field2d(ax, X, Y, Z, cmap, sym, clab)
if sym
    a = max(abs(Z(:))); caxis(ax, [-a a]);
else
    caxis(ax, [min(Z(:)) max(Z(:))]);
end
pcolor(ax, X, Y, Z); shading(ax, 'interp'); colormap(ax, cmap);
hold(ax, 'on');
plot(ax, [0 1 1 0 0], [0 0 1 1 0], 'k-', 'LineWidth', 0.35);
xlabel(ax, '$x/L$', 'Interpreter', 'latex');
ylabel(ax, '$y/h$', 'Interpreter', 'latex');
xlim(ax, [0 1]); ylim(ax, [0 1]);
set(ax, 'XTick', [0 0.5 1], 'YTick', [0 0.5 1], 'TickDir', 'in', 'Box', 'on');
cb = colorbar(ax); set(get(cb, 'Label'), 'String', clab, ...
    'Interpreter', 'latex', 'FontSize', 9);
set(ax, 'FontName', 'Times New Roman', 'FontSize', 10);
end
