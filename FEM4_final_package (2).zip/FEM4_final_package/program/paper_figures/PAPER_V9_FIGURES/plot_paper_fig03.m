function plot_paper_fig03()
% PLOT_PAPER_FIG03  Validation: rates, PZT constants, actuator. 3 panels.
%
% RUN:  plot_paper_fig03
% EDIT: SETTINGS below, or FIGURE_SETTINGS.m
% DATA: quoted norms (frozen); tier2_benchmark.csv; actuator_response.csv
% IEEE = IEEE Std 176 PZT-5H handbook values, not a paper name.
% Do not plot 307.37 pm (other model / geometry).

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'helpers'));
addpath(root);
setup_paper();
T2 = load_csv(fullfile(data_dir(), 'tier2_benchmark.csv'));
A  = load_csv(fullfile(data_dir(), 'actuator_response.csv'));

%% ===== SETTINGS (look / layout only) =====
figW = 7.16;
figH = 2.90;
legLocA = 'southeast';
legLocB = 'southeast';
%% ========================================

fig = paper_figure('Fig03_validation', figW, figH);

% (a) quoted-norm rates, two meshes only
ax = subplot(1, 3, 1);
hh = [62.5 31.25];
eL2 = [4.7610e-6, 2.9760e-7];
eH1 = [4.2180e-5, 5.2860e-6];
eG  = [1.6290e-3, 4.0740e-4];
% No continuous O(h^p) reference curves: the caption and the text state
% that with two meshes a reference slope would be an illustration, not
% additional data. Only the two reported points per norm and the chord
% between them are drawn.
loglog(ax, hh, eL2, 'o-', 'Color', okabe(6), 'MarkerFaceColor', okabe(6), ...
    'DisplayName', '$L^2$'); hold(ax, 'on');
loglog(ax, hh, eH1, 's-', 'Color', okabe(7), 'MarkerFaceColor', okabe(7), ...
    'DisplayName', '$H^1$');
loglog(ax, hh, eG, 'd-', 'Color', okabe(4), 'MarkerFaceColor', okabe(4), ...
    'DisplayName', '$G$');
xlim(ax, [28 74]); set(ax, 'XTick', [31.25 62.5], 'XMinorTick', 'off');
xlabel(ax, '$h$ ($\mu\mathrm{m}$)', 'Interpreter', 'latex');
ylabel(ax, '$e$', 'Interpreter', 'latex');
legend(ax, 'Interpreter', 'latex', 'Location', legLocA, 'FontSize', 8);
panel_label(ax, 'a');

% (b) computed / IEEE
ax = subplot(1, 3, 2);
k31r = T2(1,2)/0.39;
Eor  = T2(1,4)/71.4;
plot(ax, [1 1], [-0.4 1.4], '-', 'Color', [0.8 0.8 0.8], ...
    'HandleVisibility', 'off'); hold(ax, 'on');
plot(ax, [k31r Eor], [1 0], 'o', 'Color', okabe(6), ...
    'MarkerFaceColor', okabe(6), 'DisplayName', 'computed');
plot(ax, [1 1], [1 0], 's', 'Color', [0.4 0.4 0.4], ...
    'MarkerFaceColor', 'w', 'LineWidth', 1.0, 'DisplayName', 'IEEE');
set(ax, 'YTick', [1 0], 'YTickLabel', {'$k_{31}$', '$E_{\mathrm{open}}$'});
xlabel(ax, 'value / IEEE', 'Interpreter', 'latex');
xlim(ax, [0.96 1.04]); ylim(ax, [-0.5 1.5]);
legend(ax, 'Location', legLocB, 'FontSize', 8);
panel_label(ax, 'b');

% (c) actuator
ax = subplot(1, 3, 3);
wana = abs(A(1,3))*1e9; wfem = abs(A(1,2))*1e9;
plot(ax, [0 wana], [1 1], '-', 'Color', okabe(4), 'LineWidth', 1.6); hold(ax, 'on');
plot(ax, wana, 1, 'o', 'Color', okabe(4), 'MarkerFaceColor', okabe(4));
plot(ax, [0 wfem], [0 0], '-', 'Color', okabe(6), 'LineWidth', 1.6);
plot(ax, wfem, 0, 'o', 'Color', okabe(6), 'MarkerFaceColor', okabe(6));
text(ax, wana+3, 1.15, sprintf('%.2f', wana), 'FontSize', 9);
text(ax, wfem+3, 0.15, sprintf('%.2f', wfem), 'FontSize', 9);
set(ax, 'YTick', [1 0], 'YTickLabel', {'analytic', 'BFS'});
xlabel(ax, '$|w_{\mathrm{tip}}|$ (nm)', 'Interpreter', 'latex');
xlim(ax, [0 140]); ylim(ax, [-0.55 1.55]);   % widened: analytical bar is now 109.2 nm
panel_label(ax, 'c');
export_figure(fig, 'Fig03_validation');
end
