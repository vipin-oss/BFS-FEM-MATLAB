function plot_paper_fig05()
% PLOT_PAPER_FIG05  Slenderness. Actual (L/h, Ny) only. 3 panels.
%
% RUN:  plot_paper_fig05
% EDIT: SETTINGS below, or FIGURE_SETTINGS.m
% DATA: existing (L/h, Ny) triples only. No interpolated surface.

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'helpers'));
addpath(root);
setup_paper();
[recLh, recNy, recEta, P] = eta_records();
Lh12 = P(:,1); eta12 = P(:,12);

%% ===== SETTINGS (look / layout only) =====
figW   = 7.16;
figH   = 3.00;
az     = -60;     % 3-D camera for (c)
el     = 20;
legA   = 'northeast';
legB   = 'northwest';
%% ========================================

fig = paper_figure('Fig05_slenderness', figW, figH);

ax = subplot(1, 3, 1);
loglog(ax, Lh12, eta12, 'o-', 'Color', okabe(6), 'MarkerFaceColor', okabe(6), ...
    'DisplayName', '$N_y=12$');
hold(ax, 'on');
nyList = [8 16];
nyCol  = [8 4];
nyMk   = {'s', 'd'};
nyLab  = {'$N_y=8$', '$N_y=16$'};
for t = 1:2
    msk = abs(recNy - nyList(t)) < 1e-8;
    [xx, ix] = sort(recLh(msk));
    yy = recEta(msk); yy = yy(ix);
    if isempty(xx), continue; end
    loglog(ax, xx, yy, ['-' nyMk{t}], 'Color', okabe(nyCol(t)), ...
        'MarkerFaceColor', okabe(nyCol(t)), 'DisplayName', nyLab{t});
end
ih = Lh12 >= 20;
pf = polyfit(log(Lh12(ih)), log(eta12(ih)), 1);
xf = linspace(20, 60, 40);
loglog(ax, xf, exp(pf(2))*xf.^pf(1), ':', 'Color', [0.45 0.45 0.45], ...
    'LineWidth', 1.15, 'DisplayName', sprintf('$p=%.2f$', pf(1)));
loglog(ax, [10 60], [2.79e-5*10^1.94, 2.79e-5*60^1.94], '--', ...
    'Color', okabe(7), 'LineWidth', 1.3, 'DisplayName', '$+1.94$');
xlabel(ax, '$L/h$', 'Interpreter', 'latex');
ylabel(ax, '$\eta_{\mathrm{EM}}$', 'Interpreter', 'latex');
set(ax, 'XTick', [5 10 20 60], 'XMinorTick', 'off');
legend(ax, 'Interpreter', 'latex', 'Location', legA, 'FontSize', 7);
panel_label(ax, 'a');

ax = subplot(1, 3, 2); hold(ax, 'on');
LhV = [20 40 60]; colI = [6 7 4]; mks = {'o','s','d'};
for i = 1:3
    msk = abs(recLh - LhV(i)) < 1e-8;
    [ny, ix] = sort(recNy(msk)); et = recEta(msk); et = et(ix);
    plot(ax, ny, et*1e3, ['-' mks{i}], 'Color', okabe(colI(i)), ...
        'MarkerFaceColor', okabe(colI(i)), ...
        'DisplayName', sprintf('$L/h=%d$', LhV(i)));
end
xlabel(ax, '$N_y$', 'Interpreter', 'latex');
ylabel(ax, '$\eta_{\mathrm{EM}}\times 10^{3}$', 'Interpreter', 'latex');
set(ax, 'XTick', [8 12 16 24 32]);
legend(ax, 'Interpreter', 'latex', 'Location', legB, 'FontSize', 8);
panel_label(ax, 'b');

ax = subplot(1, 3, 3);
plot3(ax, recLh, recNy, recEta*1e3, 'o', 'Color', okabe(6), ...
    'MarkerFaceColor', okabe(6), 'MarkerSize', 5); hold(ax, 'on');
plot3(ax, Lh12, 12*ones(size(Lh12)), eta12*1e3, '-', 'Color', okabe(6));
msk = abs(recLh-40)<1e-8;
[ny, ix] = sort(recNy(msk)); et = recEta(msk); et = et(ix);
plot3(ax, 40*ones(size(ny)), ny, et*1e3, '-', 'Color', okabe(7));
xlabel(ax, '$L/h$', 'Interpreter', 'latex', 'FontSize', 9);
ylabel(ax, '$N_y$', 'Interpreter', 'latex', 'FontSize', 9);
zlabel(ax, '$\eta_{\mathrm{EM}}\times 10^{3}$', 'Interpreter', 'latex', 'FontSize', 9);
view(ax, az, el); grid(ax, 'on');
text(ax, 0.03, 0.96, '(c)', 'Units', 'normalized', 'FontName', 'Times New Roman', ...
    'FontSize', 11, 'FontWeight', 'bold', 'Interpreter', 'tex', ...
    'BackgroundColor', 'w', 'Margin', 1);
export_figure(fig, 'Fig05_slenderness');
end
