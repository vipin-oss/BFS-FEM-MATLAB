function plot_paper_fig06()
% PLOT_PAPER_FIG06  Energy partition and U_elec topography. 4 panels.
%
% RUN:  plot_paper_fig06
% EDIT: SETTINGS below, or FIGURE_SETTINGS.m
% DATA: aspect_ratio_study.csv, ETAEM_ELEMENT_ENERGY_LOCALIZATION.csv,
%       forensic/elem_Lh40_Ny16.csv

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'helpers'));
addpath(root);
setup_paper();
P = load_csv(fullfile(data_dir(), 'aspect_ratio_study.csv'));
Loc = load_csv(fullfile(data_dir(), 'ETAEM_ELEMENT_ENERGY_LOCALIZATION.csv'));
Lh = P(:,1); Um = P(:,7); Ue = P(:,8); Uc = P(:,9); Wqs = P(:,11);
E = dlmread(fullfile(data_dir(), 'forensic', 'elem_Lh40_Ny16.csv'));
nx_e = 120; ny_e = 16;
Umap = zeros(ny_e, nx_e);
for i = 1:size(E,1)
    Umap(E(i,2), E(i,1)) = E(i,3);
end
[XC, YC] = meshgrid(((1:nx_e)-0.5)/nx_e, ((1:ny_e)-0.5)/ny_e);

%% ===== SETTINGS (look / layout only) =====
figW = 7.16;
figH = 5.55;
posA = [0.10 0.56 0.36 0.36];
posB = [0.58 0.56 0.36 0.36];
posC = [0.10 0.10 0.36 0.34];
posD = [0.56 0.08 0.40 0.38];
az   = -52;
el   = 22;
legA = 'southeast';
legC = 'east';
%% ========================================

fig = paper_figure('Fig06_energy', figW, figH);
ax = axes('Parent', fig, 'Position', posA);
loglog(ax, Lh, Um, 'o-', 'Color', okabe(6), 'MarkerFaceColor', 'w', 'LineWidth', 1.6);
hold(ax, 'on');
loglog(ax, Lh, Wqs, 'k--', 'LineWidth', 1.2);
loglog(ax, Lh, Uc, 'd-', 'Color', okabe(4), 'MarkerFaceColor', okabe(4));
loglog(ax, Lh, Ue, '^-', 'Color', okabe(7), 'MarkerFaceColor', okabe(7));
xlabel(ax, '$L/h$', 'Interpreter', 'latex');
ylabel(ax, 'energy (J)', 'Interpreter', 'latex');
set(ax, 'XTick', [5 10 20 60], 'XMinorTick', 'off');
legend(ax, {'$U_{\mathrm{mech}}$', '$W_{\mathrm{qs}}$', '$U_{\mathrm{coup}}$', '$U_{\mathrm{elec}}$'}, ...
    'Interpreter', 'latex', 'Location', legA, 'FontSize', 8);
panel_label(ax, 'a');

ax = axes('Parent', fig, 'Position', posB);
loglog(ax, Lh, Ue./Um, 's-', 'Color', okabe(7), 'MarkerFaceColor', okabe(7));
xlabel(ax, '$L/h$', 'Interpreter', 'latex');
ylabel(ax, '$U_{\mathrm{elec}}/U_{\mathrm{mech}}$', 'Interpreter', 'latex');
set(ax, 'XTick', [5 10 20 60], 'XMinorTick', 'off');
panel_label(ax, 'b');

ax = axes('Parent', fig, 'Position', posC);
semilogy(ax, Loc(:,2), Loc(:,6), 'o-', 'Color', okabe(6), 'MarkerFaceColor', okabe(6));
hold(ax, 'on');
semilogy(ax, Loc(:,2), Loc(:,5), 's-', 'Color', okabe(2), 'MarkerFaceColor', okabe(2));
semilogy(ax, Loc(:,2), Loc(:,4), '^-', 'Color', okabe(7), 'MarkerFaceColor', okabe(7));
xlabel(ax, '$N_y$', 'Interpreter', 'latex');
ylabel(ax, 'energy (J)', 'Interpreter', 'latex');
set(ax, 'XTick', [8 12 16 24 32]);
legend(ax, {'$U_{\mathrm{elas}}$', '$U_{\mathrm{grad}}$', '$U_{\mathrm{elec}}$'}, ...
    'Interpreter', 'latex', 'Location', legC, 'FontSize', 8);
panel_label(ax, 'c');

ax = axes('Parent', fig, 'Position', posD);
surf(ax, XC, YC, log10(Umap), 'EdgeColor', 'none', 'FaceColor', 'interp');
colormap(ax, seq_map(256));
xlabel(ax, '$x/L$', 'Interpreter', 'latex', 'FontSize', 9);
ylabel(ax, '$y/h$', 'Interpreter', 'latex', 'FontSize', 9);
zlabel(ax, '$\log_{10}U_{\mathrm{elec}}$', 'Interpreter', 'latex', 'FontSize', 9);
view(ax, az, el);
cb = colorbar(ax); set(cb, 'FontSize', 8);
text(ax, 0.03, 0.96, '(d)', 'Units', 'normalized', 'FontName', 'Times New Roman', ...
    'FontSize', 11, 'FontWeight', 'bold', 'Interpreter', 'tex', ...
    'BackgroundColor', 'w', 'Margin', 1);
export_figure(fig, 'Fig06_energy');
end
