function plot_paper_fig07()
% PLOT_PAPER_FIG07  Critical thickness. 2 panels.
%
% RUN:  plot_paper_fig07
% EDIT: SETTINGS below, or FIGURE_SETTINGS.m
% DATA: hcrit_study.csv  (A, p taken from the CSV, not re-tuned)

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'helpers'));
addpath(root);
setup_paper();
D = load_csv(fullfile(data_dir(), 'hcrit_study.csv'));
ell = D(:,1); hc = D(:,2);
A = D(1,3); p = D(1,4); R2 = D(1,5); Ap = D(1,6); pp = D(1,7);
ellr = logspace(log10(0.20), log10(1.15), 80);

%% ===== SETTINGS (look / layout only) =====
figW   = 7.16;
figH   = 3.00;
yRes   = 2.2;     % residual axis +/- this (%)
%% ========================================

fig = paper_figure('Fig07_hcrit', figW, figH);

ax = subplot(1, 2, 1);
loglog(ax, ellr, A*ellr.^p, '-', 'Color', okabe(6), 'LineWidth', 1.8); hold(ax, 'on');
loglog(ax, ellr, Ap*ellr.^pp, '--', 'Color', okabe(7), 'LineWidth', 1.4);
loglog(ax, ell, hc, 'o', 'Color', okabe(6), 'MarkerFaceColor', okabe(6), ...
    'MarkerSize', 7, 'HandleVisibility', 'off');
xlabel(ax, '$\ell$ ($\mu\mathrm{m}$)', 'Interpreter', 'latex');
ylabel(ax, '$h_{\mathrm{crit}}$ ($\mu\mathrm{m}$)', 'Interpreter', 'latex');
set(ax, 'XTick', [0.25 0.5 0.75 1.0], 'YTick', [6 10 20 30], ...
    'XMinorTick', 'off', 'YMinorTick', 'off');
legend(ax, {sprintf('$A=%.2f$, $p=%.4f$', A, p), ...
            sprintf('$A=%.2f$, $p=%.2f$', Ap, pp)}, ...
    'Interpreter', 'latex', 'Location', 'southeast', 'FontSize', 8);
text(ax, 0.96, 0.08, sprintf('$R^2=%.5f$', R2), 'Units', 'normalized', ...
    'Interpreter', 'latex', 'FontSize', 9, 'HorizontalAlignment', 'right');
panel_label(ax, 'a');

ax = subplot(1, 2, 2);
resid = 100*(hc - A*ell.^p) ./ (A*ell.^p);
plot(ax, ell, resid, 's-', 'Color', okabe(7), 'MarkerFaceColor', okabe(7));
hold(ax, 'on'); plot(ax, [0.2 1.1], [0 0], 'k-', 'LineWidth', 0.7);
xlabel(ax, '$\ell$ ($\mu\mathrm{m}$)', 'Interpreter', 'latex');
ylabel(ax, 'residual (\%)', 'Interpreter', 'latex');
ylim(ax, [-yRes yRes]); set(ax, 'XTick', [0.25 0.5 0.75 1.0]);
panel_label(ax, 'b');
export_figure(fig, 'Fig07_hcrit');
end
