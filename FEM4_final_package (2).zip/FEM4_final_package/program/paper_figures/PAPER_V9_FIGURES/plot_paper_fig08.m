function plot_paper_fig08()
% PLOT_PAPER_FIG08  Three discrete BCs. Markers, not bars. 2 panels.
%
% RUN:  plot_paper_fig08
% EDIT: SETTINGS below, or FIGURE_SETTINGS.m
% DATA: boundary_condition_study.csv

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'helpers'));
addpath(root);
setup_paper();
D = load_csv(fullfile(data_dir(), 'boundary_condition_study.csv'));
vtip = D(:,2); phi = D(:,3);
xs = 0:2;
names = {'full', '$u=v=0$', '$+u_{,x}$'};
vEB = 2.912e-16;   % Euler-Bernoulli reference FL^3/(3*Etilde*I) with the
                   % plane-strain BENDING modulus Etilde = E/(1-nu^2) = 109.89 GPa
                   % (= C11 - C12^2/C11). The former value 2.377e-16 used the full
                   % plane-strain stiffness C11 and was WRONG for beam bending.

%% ===== SETTINGS (look / layout only) =====
figW = 7.16;
figH = 3.00;
yMax = 3.45;
%% ========================================

fig = paper_figure('Fig08_boundary', figW, figH);

ax = subplot(1, 2, 1);
plot(ax, xs, vtip*1e16, 'o-', 'Color', okabe(6), 'MarkerFaceColor', okabe(6));
hold(ax, 'on');
plot(ax, [-0.4 2.4], [vEB vEB]*1e16, '--', 'Color', okabe(7), 'LineWidth', 1.15);
set(ax, 'XTick', xs, 'XTickLabel', names, 'TickLabelInterpreter', 'latex');
ylabel(ax, '$v_{\mathrm{tip}}$ ($10^{-16}\,\mathrm{m}$)', 'Interpreter', 'latex');
ylim(ax, [0 yMax]); xlim(ax, [-0.35 2.35]);
panel_label(ax, 'a');

ax = subplot(1, 2, 2);
plot(ax, xs, phi*1e10, 's-', 'Color', okabe(7), 'MarkerFaceColor', okabe(7));
set(ax, 'XTick', xs, 'XTickLabel', names, 'TickLabelInterpreter', 'latex');
ylabel(ax, '$\max|\phi|$ ($10^{-10}\,\mathrm{V}$)', 'Interpreter', 'latex');
ylim(ax, [0 yMax]); xlim(ax, [-0.35 2.35]);
panel_label(ax, 'b');
export_figure(fig, 'Fig08_boundary');
end
