function plot_paper_fig09()
% PLOT_PAPER_FIG09  Conditioning. Reconciliation table (manuscript tab:cond).
% 2 panels. No 3-D bars.
%
% RUN:  plot_paper_fig09
% EDIT: SETTINGS below, or FIGURE_SETTINGS.m
% DATA: conditioning_reconciliation.csv
%       (not CONDITIONING_TRUE_GEOMETRY_RESULTS.csv)

root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'helpers'));
addpath(root);
setup_paper();
D = load_csv(fullfile(data_dir(), 'conditioning_reconciliation.csv'));
Nx = D(:,1); K = D(:,2:5);
labs = {'A', 'B', 'C', 'D'};
cols = [1 2 4 6];
mks  = {'o','s','d','^'};
lss  = {'-','--','-.','-'};

%% ===== SETTINGS (look / layout only) =====
figW = 7.16;
figH = 3.05;
legA = 'east';
legB = 'northeast';
%% ========================================

fig = paper_figure('Fig09_conditioning', figW, figH);

ax = subplot(1, 2, 1);
for j = 1:4
    semilogy(ax, Nx, K(:,j), [lss{j} mks{j}], 'Color', okabe(cols(j)), ...
        'MarkerFaceColor', okabe(cols(j)), 'DisplayName', labs{j});
    hold(ax, 'on');
end
xlabel(ax, '$N_x$', 'Interpreter', 'latex');
ylabel(ax, '$\kappa$', 'Interpreter', 'latex');
set(ax, 'XTick', [4 8 16 32]);
legend(ax, 'Location', legA, 'FontSize', 8);
panel_label(ax, 'a');

ax = subplot(1, 2, 2);
xs = 0:3;
nxc = [3 6 7 1];
nxm = {'o','s','d','^'};
for i = 1:numel(Nx)
    semilogy(ax, xs, K(i,:), ['-' nxm{i}], 'Color', okabe(nxc(i)), ...
        'MarkerFaceColor', okabe(nxc(i)), ...
        'DisplayName', sprintf('$N_x=%d$', Nx(i)));
    hold(ax, 'on');
end
set(ax, 'XTick', xs, 'XTickLabel', {'A','B','C','D'});
xlabel(ax, 'scaling', 'Interpreter', 'latex');
ylabel(ax, '$\kappa$', 'Interpreter', 'latex');
xlim(ax, [-0.3 3.3]);
legend(ax, 'Interpreter', 'latex', 'Location', legB, 'FontSize', 8);
panel_label(ax, 'b');
export_figure(fig, 'Fig09_conditioning');
end
