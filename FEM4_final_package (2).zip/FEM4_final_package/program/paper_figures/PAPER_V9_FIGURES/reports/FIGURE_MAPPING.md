# Figure → panel → quantity → data → manuscript

| Fig | Panel | Quantity | Source | Manuscript | Purpose |
|---|---|---|---|---|---|
| 1 | a | geometry, BCs | frozen baseline \(L=2\,\mu\mathrm{m}\), \(h=100\,\mathrm{nm}\), \(F=1\,\mathrm{nN}\) | `fig:schematic` §problem | what is solved |
| 1 | b | 36-DOF BFS | formulation | `fig:schematic` | discrete unknown |
| 2 | a | \(u(x,y)\) | `field_export.csv` | `fig:fields` | axial bending |
| 2 | b | \(v(x,y)\) | same | `fig:fields` | transverse deflection |
| 2 | c | \(\phi(x,y)\) | same | `fig:fields` | potential (peak at clamp) |
| 2 | d | \(\phi(x,y)\) 3-D | same nodes | `fig:fields` | same field, spatial form |
| 3 | a | \(e(h)\) \(L^2,H^1,G\) | quoted norms 24×8 / 48×16 | `fig:convergence` | optimal rates |
| 3 | b | \(k_{31}\), \(E_{\mathrm{open}}\) | `tier2_benchmark.csv` vs IEEE 0.39 / 71.4 | validation text | constitutive check |
| 3 | c | \(\lvert w_{\mathrm{tip}}\rvert\) | `actuator_response.csv` | validation text | 89.14 vs 91.15 nm |
| 4 | a | \(\max\lvert\phi\rvert(\Lambda)\) | `lambda_study.csv` | `fig:lambda` | rise–peak–fall |
| 4 | b | \(\max\lvert\phi\rvert/\mu_0\) | same | `fig:lambda` | converse stiffening |
| 5 | a | \(\eta_{\mathrm{EM}}(L/h)\) | `aspect_ratio_study.csv` + brackets + high-\(N_y\) | `fig:eta` | slenderness trend |
| 5 | b | \(\eta_{\mathrm{EM}}(N_y)\) | same | `fig:eta` | mesh honesty |
| 5 | c | \((L/h,N_y,\eta_{\mathrm{EM}})\) | same triples only | `fig:eta` | two-parameter view |
| 6 | a | four energies | `aspect_ratio_study.csv` | energy text | \(W_{\mathrm{qs}}\approx U_{\mathrm{mech}}\) |
| 6 | b | \(U_{\mathrm{elec}}/U_{\mathrm{mech}}\) | same | energy text | why \(\eta_{\mathrm{EM}}\) falls |
| 6 | c | \(U_{\mathrm{elas}},U_{\mathrm{grad}},U_{\mathrm{elec}}(N_y)\) | `ETAEM_ELEMENT_ENERGY_LOCALIZATION.csv` | energy text | \(U_{\mathrm{elec}}\) not converged at \(L/h=40\) |
| 6 | d | \(\log_{10}U_{\mathrm{elec}}\) | `forensic/elem_Lh40_Ny16.csv` | energy text | clamp-layer localisation |
| 7 | a | \(h_{\mathrm{crit}}(\ell)\) | `hcrit_study.csv` | `fig:hcrit` | power law |
| 7 | b | residual (%) | same \(A,p\) | `fig:hcrit` | fit quality |
| 8 | a | \(v_{\mathrm{tip}}\) | `boundary_condition_study.csv` | `fig:bc` | mechanical near-invariance |
| 8 | b | \(\max\lvert\phi\rvert\) | same | `fig:bc` | electrical sensitivity |
| 9 | a | \(\kappa(N_x)\) A–D | `conditioning_reconciliation.csv` | `fig:cond` | scaling mandatory |
| 9 | b | \(\kappa\) vs A–D by \(N_x\) | same | `fig:cond` | A≈B, C then D |

IEEE = IEEE Std 176-type PZT-5H constants, **not** a paper title.
Shekarchizadeh et al. is cited in the **caption** of Fig. 3a, not drawn on the axes.
