# Scientific figure audit — nine main figures

Frozen data. Solver and manuscript not modified.

## Panel-by-panel

**Fig. 1** Both panels earn their place. Schematic only; no invented mesh picture.

**Fig. 2** Four views of one solve (60×12). (d) is the same \(\phi\) as (c), not a new calculation. \(|\mathbf D|\) omitted (not exported). Peak of \(\phi\) is at the **clamped root**, not the free end.

**Fig. 3** (a) uses **two** quoted-norm meshes only; theoretical slopes are references, not extra data. (b) IEEE is a handbook standard. (c) 307.37 pm literature value is **not** plotted (different model/geometry).

**Fig. 4** One sweep (\(\mu_0\)). Two complementary observables. No second parameter family exists. 3-D surface **not** drawn.

**Fig. 5** Multi-curve uses only existing \((L/h,N_y)\). \(N_y=24,32\) appear only at \(L/h=40\) in (b)/(c). (c) is a scatter of those points plus the two existing polylines; no interpolating surface. Source \(+1.94\) is dashed.

**Fig. 6** Energy identities \(U_{\mathrm{coup}}=2U_{\mathrm{elec}}\) and \(W_{\mathrm{qs}}=U_{\mathrm{mech}}+U_{\mathrm{elec}}\) hold in the CSV. (c) shows \(U_{\mathrm{elas}}\) stable and \(U_{\mathrm{elec}}\) growing with \(N_y\) at \(L/h=40\) (not a production prediction of a converged \(\eta_{\mathrm{EM}}\)). (d) is element-wise \(U_{\mathrm{elec}}\) at one mesh.

**Fig. 7** Four source-reported roots. Independent fit taken from the CSV, not re-tuned for appearance.

**Fig. 8** Three discrete BCs. “Pinned” = displacement-only, not Mindlin simple support. Mechanical variation \(\sim 7\%\); electrical \((\max-\min)/\min\approx 41\%\). Axis starts at 0 (no zoom exaggeration).

**Fig. 9** Reconciliation table matching manuscript `tab:cond`. A≈B (electro almost useless), C recovers most, D combined. No 3-D bars.

## Visual audit (candidate scripts)

Cannot execute MATLAB in this sandbox. Scripts follow the last inspected Python polish:

- no in-figure “Figure N” titles
- (a)(b)(c) only
- Times / ≤14 pt
- no jet
- signed \(u\) diverging; \(\phi,v\) sequential
- no DIAGNOSTIC stamp on a main figure

You must run each `plot_paper_fig0k` in R2020a and check clipping/LaTeX.

## Integrity

| Item | Status |
|---|---|
| `fem/solve_system.m` | not edited by this layer |
| constitutive / BC / assembly | not edited |
| CSVs in `data/` | read-only |
| manuscript `.tex` | not edited |
| old `matlab/` and `FIGURES_REFINED/` | not deleted |

## Not plotted (data absent)

| Desired | Why not |
|---|---|
| \(\lvert\mathbf D\rvert\) | slope/twist DOFs not in `field_export.csv` |
| \(\phi(x,y)\) at several \(\Lambda\) | only one field dump |
| \(\eta_{\mathrm{EM}}(L/h,N_y)\) dense surface | sparse triples only |
| \(\Lambda\) family vs \(h\) or material | only \(\mu_0\) swept |
| Polar maps | no orientation angle in this model |
| Sensor \(V(h)\) table | source-reported, not reconstructible |

## Strongest / optional

**Strongest:** Fig. 2, 5, 6, 8, 9.

**Optional / SI:** diagnostic \(\mu_T\) (`ASPECT_RATIO_TENSOR_CAUSALITY.csv`); Fig. 5c if the 3-D scatter reads poorly on your screen; Fig. 7b (residual) if the editor wants a single-panel \(h_{\mathrm{crit}}\).
