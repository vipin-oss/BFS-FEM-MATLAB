#!/usr/bin/env python3
"""Regenerate the two paper figures affected by the B1/B2 reference-modulus fix.

Fig03_validation_R3 : panel (a) two reported meshes + chord only (caption says
                      no continuous O(h^p) guides), panel (b) PZT-5H vs IEEE,
                      panel (c) actuator with the CORRECTED analytical
                      corner-moment value 109.2 nm (E_bend = E/(1-nu^2)).
Fig08_boundary_R3   : three root conditions with the CORRECTED Euler-Bernoulli
                      line 2.912e-16 m (E_bend = E/(1-nu^2) = 109.89 GPa).

Style follows PAPER_V9_FIGURES (Times/serif, Okabe-Ito palette, boxed axes,
ticks in, bold panel labels, 7.16 x 2.90 / 7.16 x 3.00 in).
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

# ---------------- style ----------------
plt.rcParams.update({
    "font.family": "serif",
    "mathtext.fontset": "stix",
    "font.size": 10,
    "axes.labelsize": 11,
    "axes.linewidth": 0.9,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "lines.linewidth": 1.7,
    "lines.markersize": 6.5,
    "legend.fontsize": 8,
    "legend.frameon": True,
    "ps.fonttype": 42,
})
OK = {  # Okabe-Ito palette (as in helpers/okabe.m)
    4: "#009E73",   # green
    6: "#0072B2",   # blue
    7: "#D55E00",   # vermillion
}

def panel_label(ax, letter):
    ax.text(0.03, 0.96, "(" + letter + ")", transform=ax.transAxes,
            fontsize=11, fontweight="bold", va="top", ha="left",
            bbox=dict(facecolor="w", edgecolor="none", pad=1))

# ================= Fig 03 : validation =================
fig, axes = plt.subplots(1, 3, figsize=(7.16, 2.90))

# (a) quoted-norm rates: two meshes, chord only
ax = axes[0]
hh = np.array([62.5, 31.25])
eL2 = np.array([4.7610e-6, 2.9760e-7])
eH1 = np.array([4.2180e-5, 5.2860e-6])
eG  = np.array([1.6290e-3, 4.0740e-4])
ax.loglog(hh, eL2, "o-", color=OK[6], markerfacecolor=OK[6], label="$L^2$")
ax.loglog(hh, eH1, "s-", color=OK[7], markerfacecolor=OK[7], label="$H^1$")
ax.loglog(hh, eG,  "d-", color=OK[4], markerfacecolor=OK[4], label="$G$")
ax.set_xlim(28, 74)
ax.set_xticks([31.25, 62.5])
ax.set_xticklabels(["31.25", "62.5"])
ax.minorticks_off()
ax.set_xlabel("$h$ ($\\mu\\mathrm{m}$)")
ax.set_ylabel("$e$")
ax.legend(loc="lower left")
panel_label(ax, "a")

# (b) computed / IEEE
ax = axes[1]
k31r = 0.3887 / 0.39
Eor  = 71.38 / 71.4
ax.axvline(1.0, color="0.8", lw=0.9)
ax.plot([k31r, Eor], [1, 0], "o", color=OK[6], markerfacecolor=OK[6],
        label="computed")
ax.plot([1, 1], [1, 0], "s", color="0.4", markerfacecolor="w",
        markeredgewidth=1.0, label="IEEE")
ax.set_yticks([1, 0])
ax.set_yticklabels(["$k_{31}$", "$E_{\\mathrm{open}}$"])
ax.set_xlabel("value / IEEE")
ax.set_xlim(0.96, 1.04)
ax.set_ylim(-0.5, 1.5)
ax.legend(loc="lower right")
panel_label(ax, "b")

# (c) actuator: corrected analytical corner-moment value
ax = axes[2]
E_bend = 100e9 / (1 - 0.30**2)          # 109.89 GPa
wana = 5.0e-7 * (2e-6)**2 / (2 * E_bend * (100e-9) ** 3 / 12) * 1e9   # nm
wfem = 91.15474475827  # nm
ax.plot([0, wana], [1, 1], "-", color=OK[4])
ax.plot(wana, 1, "o", color=OK[4], markerfacecolor=OK[4])
ax.plot([0, wfem], [0, 0], "-", color=OK[6])
ax.plot(wfem, 0, "o", color=OK[6], markerfacecolor=OK[6])
ax.text(wana + 3, 1.15, "%.2f" % wana, fontsize=9)
ax.text(wfem + 3, 0.15, "%.2f" % wfem, fontsize=9)
ax.set_yticks([1, 0])
ax.set_yticklabels(["analytic", "BFS"])
ax.set_xlabel("$|w_{\\mathrm{tip}}|$ (nm)")
ax.set_xlim(0, 140)
ax.set_ylim(-0.55, 1.55)
panel_label(ax, "c")

fig.tight_layout(pad=0.6)
fig.savefig("/home/user/repo/complete4/FEM4/Fig03_validation_R3.eps")
fig.savefig("/home/user/repo/complete4/FEM4/Fig03_validation_R3.png", dpi=300)
plt.close(fig)

# ================= Fig 08 : boundary conditions =================
fig, axes = plt.subplots(1, 2, figsize=(7.16, 3.00))
xs = np.arange(3)
names = ["full", "$u=v=0$", "$+u_{,x}$"]
vtip = np.array([2.689037094876e-16, 2.874200456806e-16, 2.730398974681e-16])
phi  = np.array([2.958519039015e-10, 2.104396256000e-10, 2.139563518759e-10])
vEB  = 1e-9 * (2e-6) ** 3 / (3 * E_bend * (100e-9) ** 3 / 12)   # 2.912e-16 m

ax = axes[0]
ax.plot(xs, vtip * 1e16, "o-", color=OK[6], markerfacecolor=OK[6])
ax.axhline(vEB * 1e16, ls="--", color=OK[7], lw=1.15)
ax.set_xticks(xs); ax.set_xticklabels(names)
ax.set_ylabel("$v_{\\mathrm{tip}}$ ($10^{-16}\\,\\mathrm{m}$)")
ax.set_ylim(0, 3.45); ax.set_xlim(-0.35, 2.35)
panel_label(ax, "a")

ax = axes[1]
ax.plot(xs, phi * 1e10, "s-", color=OK[7], markerfacecolor=OK[7])
ax.set_xticks(xs); ax.set_xticklabels(names)
ax.set_ylabel("$\\max|\\phi|$ ($10^{-10}\\,\\mathrm{V}$)")
ax.set_ylim(0, 3.45); ax.set_xlim(-0.35, 2.35)
panel_label(ax, "b")

fig.tight_layout(pad=0.6)
fig.savefig("/home/user/repo/complete4/FEM4/Fig08_boundary_R3.eps")
fig.savefig("/home/user/repo/complete4/FEM4/Fig08_boundary_R3.png", dpi=300)
plt.close(fig)

print("wrote Fig03_validation_R3.(eps|png), Fig08_boundary_R3.(eps|png)")
print("  actuator analytical (corrected) = %.2f nm ; FEM = %.2f nm" % (wana, wfem))
print("  EB line (corrected) = %.4e m" % vEB)
