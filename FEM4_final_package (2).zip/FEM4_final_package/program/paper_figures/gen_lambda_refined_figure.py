#!/usr/bin/env python3
"""Regenerate Figure 5 (Fig04_lambda_R3): lambda figure-of-merit sweep with
through-thickness refinement (final submission-readiness patch).

Panel (a): max|phi| vs Lambda on the baseline 16x2 mesh and on the refined
           32x4 and 60x12 meshes (refined sweep = lambda_study_refined.m,
           same 10-point mu0 grid, same BCs/load/scaling/observable).
Panel (b): normalized max|phi|/mu0 vs Lambda, same three meshes.

The rise-maximum-fall (self-stiffening) shape is robust to refinement; the
peak magnitude and location shift with resolution (manuscript Section 5.2).
The refined 60x12 curve is drawn as the primary calculation, the 16x2
baseline is kept for comparison.

Style follows PAPER_V9_FIGURES (Times/serif, Okabe-Ito palette, boxed axes,
ticks in, bold panel labels, 7.16 x 3.05 in) - identical to the previous
single-curve version of this figure.

DATA (do not edit by hand):
  lambda_study.csv          : baseline 16x2 sweep (shipped, lambda_study.m)
  lambda_study_refined.csv  : refined 32x4 + 60x12 sweep (lambda_study_refined.m)
"""
import csv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

# ---------------- style (as gen_fixed_figures.py / PAPER_V9) ----------------
plt.rcParams.update({
    "font.family": "serif",
    "mathtext.fontset": "stix",
    "font.size": 10,
    "axes.labelsize": 11,
    "axes.linewidth": 0.9,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "lines.linewidth": 1.7,
    "lines.markersize": 6.5,
    "legend.fontsize": 8,
    "legend.frameon": True,
    "ps.fonttype": 42,
})
OK = {  # Okabe-Ito palette (as in helpers/okabe.m)
    2: "#E69F00",   # orange
    4: "#009E73",   # green
    6: "#0072B2",   # blue
    7: "#D55E00",   # vermillion
}

def panel_label(ax, letter):
    ax.text(0.03, 0.96, "(" + letter + ")", transform=ax.transAxes,
            fontsize=11, fontweight="bold", va="top", ha="left",
            bbox=dict(facecolor="w", edgecolor="none", pad=1))

# ---------------- data ----------------
def read_csv(path):
    with open(path) as f:
        rows = [r for r in csv.reader(f) if r and not r[0].startswith("#")]
    hdr, body = rows[0], np.array([[float(x) for x in r] for r in rows[1:]])
    return {h.strip().split()[0]: body[:, i] for i, h in enumerate(hdr)}

D0 = read_csv("/home/user/repo/complete4/BFS_PROGRAM/MATLAB_COMPLETE_PROGRAM/output/lambda_study.csv")
DR = read_csv("/home/user/repo/complete4/BFS_PROGRAM/MATLAB_COMPLETE_PROGRAM/output/lambda_study_refined.csv")

Lam  = D0["Lambda"];  V16 = D0["max_phi"];            mu0 = D0["mu0"]
V32  = DR["max_phi_32x4"]; V60 = DR["max_phi_60x12"]
assert np.allclose(Lam, DR["Lambda"]), "Lambda grids differ"
assert np.allclose(mu0,  DR["mu0"]),   "mu0 grids differ"

i16 = int(np.argmax(V16)); i32 = int(np.argmax(V32)); i60 = int(np.argmax(V60))
Lam0 = 1.051665346011e-2   # production Lambda (mu0 = 1e-6), not a fitted parameter

# ---------------- figure ----------------
fig, axes = plt.subplots(1, 2, figsize=(7.16, 3.05))

ax = axes[0]
ax.semilogx(Lam, V16 * 1e10, "--o", color=OK[7], markerfacecolor="w",
            markeredgewidth=1.2, label="$16\\times2$ (baseline)")
ax.semilogx(Lam, V32 * 1e10, "--^", color=OK[4], markerfacecolor="w",
            markeredgewidth=1.2, label="$32\\times4$")
ax.semilogx(Lam, V60 * 1e10, "-o", color=OK[6], markerfacecolor=OK[6],
            label="$60\\times12$ (refined)")
ax.plot(Lam[i60], V60[i60] * 1e10, "o", markersize=10,
        markerfacecolor="none", markeredgecolor="0.15", markeredgewidth=1.4)
ax.axvline(Lam[i60], ls=":", color="0.35", lw=1.0)
ax.axvline(Lam0, ls="-.", color="0.45", lw=1.0)
ax.set_xlabel("$\\Lambda=\\sqrt{D_0\\kappa_0}/\\mu_0$")
ax.set_ylabel("$\\max|\\phi|$ ($10^{-10}\\,\\mathrm{V}$)")
ax.set_ylim(0, 0.5 * np.ceil(2.0 * 1.10 * max(V16.max(), V32.max(), V60.max()) * 1e10))
ax.legend(loc="upper right")
panel_label(ax, "a")

ax = axes[1]
ax.loglog(Lam, V16 / mu0, "--s", color=OK[7], markerfacecolor="w",
          markeredgewidth=1.2, label="$16\\times2$ (baseline)")
ax.loglog(Lam, V32 / mu0, "--^", color=OK[4], markerfacecolor="w",
          markeredgewidth=1.2, label="$32\\times4$")
ax.loglog(Lam, V60 / mu0, "-o", color=OK[6], markerfacecolor=OK[6],
          label="$60\\times12$ (refined)")
ax.axvline(Lam[i60], ls=":", color="0.35", lw=1.0)
ax.axvline(Lam0, ls="-.", color="0.45", lw=1.0)
ax.set_xlabel("$\\Lambda$")
ax.set_ylabel("$\\max|\\phi|/\\mu_0$ ($\\mathrm{V}\\cdot\\mathrm{m}/\\mathrm{C}$)")
ax.legend(loc="lower right")
panel_label(ax, "b")

fig.tight_layout(pad=0.6)
fig.savefig("/home/user/repo/complete4/FEM4/Fig04_lambda_R3.eps")
fig.savefig("/home/user/repo/complete4/FEM4/Fig04_lambda_R3.png", dpi=300)
plt.close(fig)

print("wrote Fig04_lambda_R3.(eps|png)")
print("  16x2 peak : %.4e V at Lambda = %.4e (mu0 = %.2e)" % (V16[i16], Lam[i16], mu0[i16]))
print("  32x4 peak : %.4e V at Lambda = %.4e (mu0 = %.2e)" % (V32[i32], Lam[i32], mu0[i32]))
print("  60x12 peak: %.4e V at Lambda = %.4e (mu0 = %.2e)" % (V60[i60], Lam[i60], mu0[i60]))
print("  peak change 16x2 -> 60x12: %+.1f%% ; peak Lambda ratio: %.2f"
      % (100 * (V60[i60] / V16[i16] - 1), Lam[i60] / Lam[i16]))
print("  at Lam0 (mu0=1e-6 grid nbr 9.03e-7): 16x2 %.4e | 32x4 %.4e | 60x12 %.4e"
      % (V16[i16], V32[i16], V60[i16]))
