#!/usr/bin/env python3
"""Fig10_meshconv: mesh-convergence figure for the final manuscript.

Panel (a): simple-shear benchmark (Shekarchizadeh) point value convergence.
  |u_h - u*| vs element size h on meshes 12x4, 24x8, 48x16 (log-log),
  u* = Richardson-extrapolated free-edge displacement = 1.698780e-9 m,
  successive-difference rate p = 1.82.
  Data: MATLAB_COMPLETE_PROGRAM/output/convergence_study.csv
Panel (b): coupled sensor cantilever (L/h = 20): tip deflection vs DOFs for
  three refinement paths + the 60x12 study mesh + the Euler-Bernoulli
  reference FL^3/(3*Etilde*I) = 2.912e-16 m.
  Data: PAPER_V9_FIGURES/data/ASPECT_RATIO_MESH_CONVERGENCE.csv
Style: Times/serif, Okabe-Ito palette, boxed axes, bold panel labels.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({
    "font.family": "serif", "mathtext.fontset": "stix", "font.size": 10,
    "axes.labelsize": 11, "axes.linewidth": 0.9, "xtick.direction": "in",
    "ytick.direction": "in", "lines.linewidth": 1.7, "lines.markersize": 6.5,
    "legend.fontsize": 9, "legend.frameon": True, "ps.fonttype": 42,
})
BLUE, VERM, GREEN, GREY = "#0072B2", "#D55E00", "#009E73", "0.45"

def panel_label(ax, letter):
    ax.text(0.03, 0.96, "(" + letter + ")", transform=ax.transAxes,
            fontsize=11, fontweight="bold", va="top", ha="left",
            bbox=dict(facecolor="w", edgecolor="none", pad=1))

fig, axes = plt.subplots(1, 2, figsize=(7.16, 3.05))

# ---------------- panel (a): benchmark point value ----------------
u = np.array([1.697504726489e-09, 1.698419739120e-09, 1.698678138247e-09])
ustar = u[2] + (u[2] - u[1]) ** 2 / ((u[1] - u[0]) - (u[2] - u[1]))
h = np.array([125.0, 62.5, 31.25])          # element size (um), L=1.5 mm
p = np.log(abs(u[0] - u[1]) / abs(u[1] - u[2])) / np.log(2)
ax = axes[0]
ax.loglog(h, np.abs(u - ustar), "o-", color=BLUE, markerfacecolor=BLUE,
          label=r"computed $|u_h - u^*|$")
guide = np.abs(u - ustar)[0] * (h / h[0]) ** p
ax.loglog(h, guide, "--", color=GREY, lw=1.2,
          label=r"guide, $p = %.2f$" % p)
ax.set_xlabel(r"$h$ ($\mu\mathrm{m}$)")
ax.set_ylabel(r"$|u_h - u^*|$ (m)")
ax.legend(loc="upper left")
ax.text(0.97, 0.05, r"$u^* = 1.6988\times10^{-9}$ m", transform=ax.transAxes,
        ha="right", va="bottom", fontsize=9)
panel_label(ax, "a")

# ---------------- panel (b): coupled cantilever ----------------
# (DOFs, v_tip[m]) from ASPECT_RATIO_MESH_CONVERGENCE.csv (L/h = 20)
combined = [(102, 2.5183e-16), (352, 2.6890e-16), (1311, 2.7708e-16), (5158, 2.8013e-16)]
nx_only  = [(352, 2.6890e-16), (649, 2.7202e-16), (1273, 2.7312e-16), (1897, 2.7337e-16)]
ny_only  = [(352, 2.6890e-16), (671, 2.7370e-16), (1309, 2.7514e-16), (1947, 2.7528e-16)]
study    = (6903, 2.8020e-16)   # 60 x 12
vEB = 2.912e-16

ax = axes[1]
for data, c, m, lab in [(combined, BLUE, "o", r"combined $8{\times}1\to64{\times}8$"),
                        (nx_only, GREEN, "s", r"$N_x$-refinement, $N_y=2$"),
                        (ny_only, VERM, "D", r"$N_y$-refinement, $N_x=16$")]:
    d = np.array(data)
    ax.semilogx(d[:, 0], d[:, 1] * 1e16, m + "-", color=c, markerfacecolor=c,
                label=lab, markersize=5.5)
ax.semilogx([study[0]], [study[1] * 1e16], "o", markersize=9,
            markerfacecolor="none", markeredgecolor="k", markeredgewidth=1.3)
ax.annotate(r"$60\times12$ study mesh", xy=(study[0], study[1] * 1e16),
            xytext=(0.96, 0.02), textcoords="axes fraction", ha="right",
            va="bottom", fontsize=9,
            arrowprops=dict(arrowstyle="-", color="0.3", lw=0.8))
ax.axhline(vEB * 1e16, ls="-.", color=GREY, lw=1.2)
ax.text(0.97, 0.955, r"Euler--Bernoulli $FL^3/(3\tilde{E}I)=2.912$",
        transform=ax.transAxes, ha="right", va="top", fontsize=9)
ax.set_xlabel(r"degrees of freedom $N_{\mathrm{dof}}$")
ax.set_ylabel(r"$v_{\mathrm{tip}}$ ($10^{-16}\,\mathrm{m}$)")
ax.set_ylim(2.40, 3.02)
ax.legend(loc="lower right", fontsize=8)
panel_label(ax, "b")

fig.tight_layout(pad=0.6)
out = "/home/user/repo/complete4/FEM4/Fig10_meshconv"
fig.savefig(out + ".eps")
fig.savefig(out + ".png", dpi=300)
print("wrote Fig10_meshconv.(eps|png)")
print("  u* = %.6e m, successive-difference rate p = %.3f" % (ustar, p))
