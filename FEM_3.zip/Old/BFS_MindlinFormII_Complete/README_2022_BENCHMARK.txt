Isolated 2022 benchmark suite
===============================

These files are separate from the normal solver and reuse only the frozen
BFS element residual/tangent/assembly kernels.

Entry point:
  validate2022BenchmarkExact

Required MATLAB path setup:
  addpath('benchmark2022')

Benchmark-only files:
  initializeProblem2022.m
  buildBoundaryConditions2022.m
  buildPeriodicConstraints2022.m
  buildBenchmarkLoads2022.m
  solveLoadStep2022.m
  newtonRaphsonSolver2022.m
  runAnalysis2022.m
  analyticalSolution2022.m
  validate2022BenchmarkExact.m

The original normal-solver modules are not overwritten by this suite.
