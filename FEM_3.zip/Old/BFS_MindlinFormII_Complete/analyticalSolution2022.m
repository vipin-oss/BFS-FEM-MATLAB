function out = analyticalSolution2022(y, paper, caseName)
%ANALYTICALSOLUTION2022 Analytical ux(y) profiles of 2022 paper Cases 1/2.
%
% The semi-analytical ansatz is uy=0 and ux=ux(y).  From
% c2*u''-(c5+c6+c7)*u''''=0, r=sqrt(c2/(c5+c6+c7)).

caseName = lower(char(caseName));
assert(any(strcmp(caseName, {'case1', 'case2'})), ...
    'analyticalSolution2022:caseName must be case1 or case2.');

kappa = paper.c5 + paper.c6 + paper.c7;
assert(kappa > 0, ...
    'analyticalSolution2022:c5+c6+c7 must be positive.');

r = sqrt(paper.mu/kappa);
H = paper.H;
z = H*r;

switch caseName
    case 'case1'
        den = sinh(z) - z*cosh(z);
        q1 = 0;
        q4 = 0;
        q3 = paper.uhat/den;
        q2 = -q3*r*cosh(z);

    case 'case2'
        % ux(0)=0, ux,y(0)=0, mxy(H)=kappa*ux,yy(H)=0,
        % tx(H)=that.  Because kappa*r^2=mu, the traction condition
        % reduces exactly to mu*q2=that.
        q2 = paper.that/paper.mu;
        q3 = -q2/r;
        q4 = -q3*tanh(z);
        q1 = -q4;
end

ux = q1 + q2*y + q3*sinh(r*y) + q4*cosh(r*y);
duxdy = q2 + q3*r*cosh(r*y) + q4*r*sinh(r*y);
d2uxdy2 = q3*r^2*sinh(r*y) + q4*r^2*cosh(r*y);

out = struct('ux', ux, 'uy', zeros(size(y)), ...
             'ux_y', duxdy, 'ux_yy', d2uxdy2, ...
             'r', r, 'q', [q1, q2, q3, q4]);

end
