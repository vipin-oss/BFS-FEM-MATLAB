function [Kr, Rr, fr, Rxn, bcOut] = applyDirichletBC(K, R, D, dof, loadFactor)
%APPLYDIRICHLETBC Strong Dirichlet elimination for one Newton system.
%
%   [Kr,Rr,fr,Rxn,bcOut] = applyDirichletBC(K,R,D,dof,loadFactor)
%
% With prescribed essential increment
%   fr = loadFactor*essVals - D(E),
% the free equilibrium equation is
%   K_FF*dD_F = -(R_F + K_FE*fr).
%
% Therefore this function returns the reduced residual
%   Rr = R_F + K_FE*fr,
% so callers must solve Kr*dD_F = -Rr.

if nargin < 5 || isempty(loadFactor)
    loadFactor = 1;
end

assert(isnumeric(loadFactor) && isreal(loadFactor) && isfinite(loadFactor) && ...
       isscalar(loadFactor), ...
    'applyDirichletBC:loadFactor must be a real finite scalar.');

assert(isstruct(dof) && isfield(dof, 'nDOF') && ...
       isfield(dof, 'freeDOF') && isfield(dof, 'essDOF') && ...
       isfield(dof, 'essVals'), ...
    'applyDirichletBC:dof must contain nDOF, freeDOF, essDOF, and essVals.');

nDOF = dof.nDOF;
D = D(:);
R = R(:);
F = dof.freeDOF(:);
E = dof.essDOF(:);
nF = numel(F);
nE = numel(E);

assert(isequal(size(K), [nDOF, nDOF]), ...
    'applyDirichletBC:K must be nDOF x nDOF.');
assert(isnumeric(R) && isreal(R) && all(isfinite(R)) && numel(R) == nDOF, ...
    'applyDirichletBC:R must be a real finite nDOF-vector.');
assert(isnumeric(D) && isreal(D) && all(isfinite(D)) && numel(D) == nDOF, ...
    'applyDirichletBC:D must be a real finite nDOF-vector.');
assert(numel(F) + numel(E) == nDOF && isempty(intersect(F, E)), ...
    'applyDirichletBC:freeDOF and essDOF must be a disjoint full partition.');
assert(isnumeric(dof.essVals) && isreal(dof.essVals) && ...
       all(isfinite(dof.essVals(:))) && numel(dof.essVals) == nE, ...
    'applyDirichletBC:essVals must be a real finite nEss-vector.');

essValsScaled = loadFactor*dof.essVals(:);
fr = essValsScaled - D(E);

if nF == 0
    Kr = sparse(0, 0);
    Rr = zeros(0, 1);
else
    Kr = K(F, F);
    if ~issparse(Kr)
        Kr = sparse(Kr);
    end
    Kr = 0.5*(Kr + Kr.');

    if nE == 0
        Rr = R(F);
    else
        Rr = R(F) + K(F, E)*fr;
    end
end

% Reaction recovery after a Newton correction.  At convergence, where
% fr and dDfree vanish, this returns the constrained residual R(E).
if nE > 0
    KEF = K(E, F);
    KEE = K(E, E);
    RE = R(E);
    Rxn = struct();
    Rxn.essDOF = E;
    Rxn.essVals = essValsScaled;
    Rxn.compute = @(dDfree) RE + KEF*dDfree(:) + KEE*fr;
else
    Rxn = struct();
    Rxn.essDOF = zeros(0, 1);
    Rxn.essVals = zeros(0, 1);
    Rxn.compute = @(dDfree) zeros(0, 1);
end

bcOut = struct('nFree', nF, 'nEss', nE, 'loadFactor', loadFactor);

% Output contracts.
assert(isequal(size(Kr), [nF, nF]), ...
    'applyDirichletBC:Kr must be nFree x nFree.');
assert(isequal(size(Rr), [nF, 1]), ...
    'applyDirichletBC:Rr must be nFree x 1.');
assert(isequal(size(fr), [nE, 1]), ...
    'applyDirichletBC:fr must be nEss x 1.');

end
