function R = assembleGlobalResidual(D, mat, mesh, dof, gauss)
%ASSEMBLEGLOBALRESIDUAL Assemble the global internal-force residual.
%
%   R = assembleGlobalResidual(D, mat, mesh, dof, gauss)
%
% Frozen Section 7:
%   R_int(D) = A_e r_int^e(d^e)
%
% External force and inertia contributions are not included in this
% internal-residual assembly routine.

persistent SELFTEST_ACTIVE SELFTEST_DONE

if isempty(SELFTEST_ACTIVE)
    SELFTEST_ACTIVE = false;
end
if isempty(SELFTEST_DONE)
    SELFTEST_DONE = false;
end

% The self-test is executed only once by an outermost invocation.
runSelfTest = ~SELFTEST_ACTIVE && ~SELFTEST_DONE;
if runSelfTest
    SELFTEST_ACTIVE = true;
end

try
    % ------------------------------------------------------------------
    % Input validation.
    % ------------------------------------------------------------------
    assert(isstruct(dof) && isfield(dof, 'nDOF') && isfield(dof, 'elemDOF'), ...
        ['assembleGlobalResidual:dof must contain nDOF and elemDOF ' ...
         '(call buildDOFMap first).']);

    assert(isstruct(mesh) && isfield(mesh, 'nElem') && isfield(mesh, 'elemGeom'), ...
        'assembleGlobalResidual:mesh must contain nElem and elemGeom.');

    assert(isstruct(gauss), ...
        'assembleGlobalResidual:gauss must be a gaussQuadrature struct.');

    Ne = mesh.nElem;
    nDOF = dof.nDOF;

    assert(isnumeric(nDOF) && isreal(nDOF) && isfinite(nDOF) && ...
           isscalar(nDOF) && nDOF > 0 && nDOF == round(nDOF), ...
        'assembleGlobalResidual:dof.nDOF must be a positive integer.');

    assert(isnumeric(D) && isreal(D) && all(isfinite(D(:))) && ...
           numel(D) == nDOF, ...
        'assembleGlobalResidual:D must be a real finite nDOF-vector.');

    assert(isequal(size(dof.elemDOF), [Ne, 32]), ...
        'assembleGlobalResidual:dof.elemDOF must be N_e x 32.');

    assert(numel(mesh.elemGeom) == Ne, ...
        'assembleGlobalResidual:mesh.elemGeom must have N_e entries.');

    D = D(:);

    % ------------------------------------------------------------------
    % Scatter-add element internal residuals.
    % ------------------------------------------------------------------
    R = zeros(nDOF, 1);

    for e = 1:Ne
        edofs = dof.elemDOF(e, :);

        assert(isnumeric(edofs) && all(isfinite(edofs)) && ...
               all(edofs == round(edofs)) && ...
               all(edofs >= 1 & edofs <= nDOF) && ...
               numel(unique(edofs)) == 32, ...
            'assembleGlobalResidual:invalid element DOF map at element %d.', e);

        de = D(edofs);
        eg = mesh.elemGeom(e);

        % Accept a geometry wrapper containing Xcorners when supplied by
        % a mesh builder; otherwise pass the element geometry unchanged.
        if isstruct(eg) && ~isfield(eg, 'x0') && isfield(eg, 'Xcorners')
            eg = eg.Xcorners;
        end

        re = computeElementResidual(eg, mat, gauss, de);

        assert(isnumeric(re) && isreal(re) && all(isfinite(re(:))) && ...
               numel(re) == 32, ...
            ['assembleGlobalResidual:computeElementResidual must return ' ...
             'a real finite 32-vector at element %d.'], e);

        R(edofs) = R(edofs) + re(:);
    end

    % ------------------------------------------------------------------
    % One-time non-recursive module verification.
    % ------------------------------------------------------------------
    if runSelfTest
        runResidualSelfTest();
        SELFTEST_DONE = true;
    end

catch ME
    if runSelfTest
        SELFTEST_ACTIVE = false;
    end
    rethrow(ME);
end

if runSelfTest
    SELFTEST_ACTIVE = false;
end

end

% =====================================================================
% Local self-test helpers.  These are file-level local functions, not
% misplaced nested functions inside an executable IF block.
% =====================================================================
function runResidualSelfTest()

tol = 1e-12;

% Preserve the caller random state after deterministic test vectors.
rngState = rng;
rngCleanup = onCleanup(@() rng(rngState)); %#ok<NASGU>

EY = 100;
nu = 0.3;
matt = buildMaterialStruct(EY, nu, 1, 1, 1, 1, 1, 0);
matt.thickness = 1;
gt = gaussQuadrature(3);

% ------------------------------------------------------------------
% Single-element assembly/direct-element equivalence.
% ------------------------------------------------------------------
mesh1 = buildResidualTestMesh(1, 1, 1.0, 1.0);
dof1 = buildDOFMap(mesh1);

rng(21);
D1 = 0.01*randn(dof1.nDOF, 1);

R1g = assembleGlobalResidual(D1, matt, mesh1, dof1, gt);
ed1 = dof1.elemDOF(1, :);
R1e = computeElementResidual(mesh1.elemGeom(1), matt, gt, D1(ed1));

assert(isequal(size(R1g), [dof1.nDOF, 1]), ...
    'assembleGlobalResidual:self-test residual dimension mismatch.');

assert(norm(R1g(ed1) - R1e(:)) < tol*(1 + norm(R1e)), ...
    'assembleGlobalResidual:self-test single-element residual mismatch.');

% ------------------------------------------------------------------
% Multi-element scatter assembly and rigid-translation checks.
% ------------------------------------------------------------------
allMeshes = {buildResidualTestMesh(2, 1, 1.0, 1.0), ...
             buildResidualTestMesh(3, 2, 1.0, 0.5)};

for mi = 1:numel(allMeshes)
    m = allMeshes{mi};
    dm = buildDOFMap(m);

    rng(20 + mi);
    Dm = 0.02*randn(dm.nDOF, 1);

    Rg = assembleGlobalResidual(Dm, matt, m, dm, gt);
    Rdir = zeros(dm.nDOF, 1);

    for e = 1:m.nElem
        ed = dm.elemDOF(e, :);
        re = computeElementResidual(m.elemGeom(e), matt, gt, Dm(ed));
        Rdir(ed) = Rdir(ed) + re(:);
    end

    assert(norm(Rg - Rdir) < tol*(1 + norm(Rdir)), ...
        ['assembleGlobalResidual:self-test scatter mismatch for ' ...
         '%dx%d mesh.'], m.Ne1, m.Ne2);

    % A constant displacement field has F=I, E=0, and G=0.
    Dtrans = zeros(dm.nDOF, 1);
    for n = 1:m.nNodes
        Dtrans(dm.ID(1, 1, n)) = 0.5;
        Dtrans(dm.ID(1, 2, n)) = -0.3;
    end

    Rt = assembleGlobalResidual(Dtrans, matt, m, dm, gt);
    assert(norm(Rt) < 1e-10, ...
        ['assembleGlobalResidual:self-test nonzero residual under rigid ' ...
         'translation for %dx%d mesh.'], m.Ne1, m.Ne2);

    % A perturbation at a node belonging to one element may contribute
    % only to that element's assembled row set.
    ownership = zeros(m.nNodes, 1);
    for e = 1:m.nElem
        for a = 1:4
            ownership(m.connect(e, a)) = ownership(m.connect(e, a)) + 1;
        end
    end

    cornerNode = find(ownership == 1, 1, 'first');
    assert(~isempty(cornerNode), ...
        'assembleGlobalResidual:self-test could not find a one-element corner node.');

    vCorner = zeros(dm.nDOF, 1);
    vCorner(dm.ID(1, 1, cornerNode)) = 1;

    ep = 1e-6;
    dc = (assembleGlobalResidual(ep*vCorner, matt, m, dm, gt) - ...
          assembleGlobalResidual(-ep*vCorner, matt, m, dm, gt))/(2*ep);

    nz = find(abs(dc) > 1e-10);
    ownElem = find(arrayfun(@(e) any(m.connect(e, :) == cornerNode), ...
                             1:m.nElem));

    assert(isscalar(ownElem), ...
        'assembleGlobalResidual:self-test corner node must belong to one element.');

    assert(all(ismember(nz, dm.elemDOF(ownElem, :))), ...
        ['assembleGlobalResidual:self-test corner perturbation leaked ' ...
         'outside its owning element.']);
end

fprintf('assembleGlobalResidual self-test OK.\n');

end

function m = buildResidualTestMesh(Ne1, Ne2, h1e, h2e)

nNodes = (Ne1 + 1)*(Ne2 + 1);
nElem = Ne1*Ne2;

X = zeros(nNodes, 2);
for i2 = 0:Ne2
    for i1 = 0:Ne1
        nd = i2*(Ne1 + 1) + i1 + 1;
        X(nd, :) = [i1*h1e, i2*h2e];
    end
end

connect = zeros(nElem, 4);
elemGeom = repmat(struct('x0', 0, 'y0', 0, 'h1', h1e, 'h2', h2e), ...
                  nElem, 1);

e = 0;
for i2 = 0:Ne2-1
    for i1 = 0:Ne1-1
        e = e + 1;

        ndSW = i2*(Ne1 + 1) + i1 + 1;
        ndSE = ndSW + 1;
        ndNE = (i2 + 1)*(Ne1 + 1) + i1 + 2;
        ndNW = ndNE - 1;

        connect(e, :) = [ndSW, ndSE, ndNE, ndNW];
        elemGeom(e).x0 = i1*h1e;
        elemGeom(e).y0 = i2*h2e;
    end
end

m = struct();
m.nNodes = nNodes;
m.nElem = nElem;
m.Ne1 = Ne1;
m.Ne2 = Ne2;
m.X = X;
m.connect = connect;
m.L1 = Ne1*h1e;
m.L2 = Ne2*h2e;
m.h1 = h1e;
m.h2 = h2e;
m.elemGeom = elemGeom;
m.thickness = 1;

end
