function KT = assembleGlobalTangent(D, mat, mesh, dof, gauss)
%ASSEMBLEGLOBALTANGENT Assemble the global consistent tangent matrix.
%
%   KT = assembleGlobalTangent(D, mat, mesh, dof, gauss)
%
% Frozen Section 7:
%   KT(D) = A_e K_T^e(d^e),
%   K_T^e = K_mat,cl^e + K_geo,cl^e + K_mat,gr^e + K_geo,gr^e.

persistent SELFTEST_ACTIVE SELFTEST_DONE

if isempty(SELFTEST_ACTIVE)
    SELFTEST_ACTIVE = false;
end
if isempty(SELFTEST_DONE)
    SELFTEST_DONE = false;
end

runSelfTest = ~SELFTEST_ACTIVE && ~SELFTEST_DONE;
if runSelfTest
    SELFTEST_ACTIVE = true;
end

try
    % ------------------------------------------------------------------
    % Input validation.
    % ------------------------------------------------------------------
    assert(isstruct(dof) && isfield(dof, 'nDOF') && isfield(dof, 'elemDOF'), ...
        ['assembleGlobalTangent:dof must contain nDOF and elemDOF ' ...
         '(call buildDOFMap first).']);

    assert(isstruct(mesh) && isfield(mesh, 'nElem') && isfield(mesh, 'elemGeom'), ...
        'assembleGlobalTangent:mesh must contain nElem and elemGeom.');

    assert(isstruct(gauss), ...
        'assembleGlobalTangent:gauss must be a gaussQuadrature struct.');

    Ne = mesh.nElem;
    nDOF = dof.nDOF;

    assert(isnumeric(nDOF) && isreal(nDOF) && isfinite(nDOF) && ...
           isscalar(nDOF) && nDOF > 0 && nDOF == round(nDOF), ...
        'assembleGlobalTangent:dof.nDOF must be a positive integer.');

    assert(isnumeric(D) && isreal(D) && all(isfinite(D(:))) && ...
           numel(D) == nDOF, ...
        'assembleGlobalTangent:D must be a real finite nDOF-vector.');

    assert(isequal(size(dof.elemDOF), [Ne, 32]), ...
        'assembleGlobalTangent:dof.elemDOF must be N_e x 32.');

    assert(numel(mesh.elemGeom) == Ne, ...
        'assembleGlobalTangent:mesh.elemGeom must have N_e entries.');

    D = D(:);

    % ------------------------------------------------------------------
    % Sparse triplet scatter assembly.  MATLAB stores ke(:) columnwise,
    % so rows repeat once per local column and cols repeat per local row.
    % ------------------------------------------------------------------
    nEntries = Ne*32*32;
    II = zeros(nEntries, 1);
    JJ = zeros(nEntries, 1);
    VV = zeros(nEntries, 1);
    idx = 0;

    for e = 1:Ne
        edofs = dof.elemDOF(e, :);

        assert(isnumeric(edofs) && all(isfinite(edofs)) && ...
               all(edofs == round(edofs)) && ...
               all(edofs >= 1 & edofs <= nDOF) && ...
               numel(unique(edofs)) == 32, ...
            'assembleGlobalTangent:invalid element DOF map at element %d.', e);

        de = D(edofs);
        eg = mesh.elemGeom(e);

        if isstruct(eg) && ~isfield(eg, 'x0') && isfield(eg, 'Xcorners')
            eg = eg.Xcorners;
        end

        ke = computeElementTangent(eg, mat, gauss, de);

        assert(isnumeric(ke) && isreal(ke) && all(isfinite(ke(:))) && ...
               isequal(size(ke), [32, 32]), ...
            ['assembleGlobalTangent:computeElementTangent must return ' ...
             'a real finite 32x32 matrix at element %d.'], e);

        edofsColumn = edofs(:);
        range = idx + (1:1024);

        II(range) = repmat(edofsColumn, 32, 1);
        JJ(range) = repelem(edofsColumn, 32);
        VV(range) = ke(:);

        idx = idx + 1024;
    end

    KT = sparse(II, JJ, VV, nDOF, nDOF, nEntries);

    % The frozen hyperelastic tangent is symmetric.  This operation only
    % removes floating-point-level asymmetric round-off after assembly.
    KT = 0.5*(KT + KT.');

    % ------------------------------------------------------------------
    % One-time non-recursive self-test.
    % ------------------------------------------------------------------
    if runSelfTest
        runTangentSelfTest();
        SELFTEST_DONE = true;
    end

catch ME
    if runSelfTest
        SELFTEST_ACTIVE = false;
    end
    rethrow(ME);
end

if runSelfTest
    SELFTEST_ACTIVE = false;
end

end

% =====================================================================
% Local self-test helpers.  They are defined after the main function,
% not inside an executable IF block.
% =====================================================================
function runTangentSelfTest()

tol = 1e-12;
rngState = rng;
rngCleanup = onCleanup(@() rng(rngState)); %#ok<NASGU>

EY = 100;
nu = 0.3;
matt = buildMaterialStruct(EY, nu, 1, 1, 1, 1, 1, 0);
matt.thickness = 1;
gt = gaussQuadrature(3);

% Single-element global-to-element consistency.
m1 = buildTangentTestMesh(1, 1, 1.0, 1.0);
d1 = buildDOFMap(m1);
rng(31);
D1 = 0.01*randn(d1.nDOF, 1);

K1g = assembleGlobalTangent(D1, matt, m1, d1, gt);
ed1 = d1.elemDOF(1, :);
K1e = computeElementTangent(m1.elemGeom(1), matt, gt, D1(ed1));

assert(isequal(size(K1g), [d1.nDOF, d1.nDOF]) && issparse(K1g), ...
    'assembleGlobalTangent:self-test global tangent shape/sparsity failed.');

assert(norm(full(K1g(ed1, ed1)) - K1e, 'fro') < ...
       tol*(1 + norm(K1e, 'fro')), ...
    'assembleGlobalTangent:self-test single-element assembly mismatch.');

assert(norm(K1g - K1g.', 'fro') < 1e-10*(1 + norm(K1g, 'fro')), ...
    'assembleGlobalTangent:self-test tangent is not symmetric.');

% Multi-element sparse assembly and finite-difference consistency.
allMeshes = {buildTangentTestMesh(2, 1, 1.0, 1.0), ...
             buildTangentTestMesh(3, 2, 1.0, 0.5)};
maxFDError = 0;

for mi = 1:numel(allMeshes)
    m = allMeshes{mi};
    dm = buildDOFMap(m);

    rng(40 + mi);
    Dm = 0.02*randn(dm.nDOF, 1);
    Kg = assembleGlobalTangent(Dm, matt, m, dm, gt);

    % Direct triplet reconstruction using the same frozen element tangent.
    I = zeros(m.nElem*1024, 1);
    J = zeros(m.nElem*1024, 1);
    V = zeros(m.nElem*1024, 1);
    p = 0;
    for e = 1:m.nElem
        ed = dm.elemDOF(e, :);
        ke = computeElementTangent(m.elemGeom(e), matt, gt, Dm(ed));
        range = p + (1:1024);
        I(range) = repmat(ed(:), 32, 1);
        J(range) = repelem(ed(:), 32);
        V(range) = ke(:);
        p = p + 1024;
    end

    Kdirect = sparse(I, J, V, dm.nDOF, dm.nDOF);
    Kdirect = 0.5*(Kdirect + Kdirect.');

    assert(norm(Kg - Kdirect, 'fro') < tol*(1 + norm(Kdirect, 'fro')), ...
        'assembleGlobalTangent:self-test multi-element assembly mismatch.');

    % Rigid translation is a null mode at the undeformed stress-free state.
    K0 = assembleGlobalTangent(zeros(dm.nDOF, 1), matt, m, dm, gt);
    dTranslation = zeros(dm.nDOF, 1);
    for n = 1:m.nNodes
        dTranslation(dm.ID(1, 1, n)) = 1;
        dTranslation(dm.ID(1, 2, n)) = 1;
    end

    assert(norm(K0*dTranslation) < 1e-10*(1 + norm(K0, 'fro')), ...
        'assembleGlobalTangent:self-test rigid-translation null mode failed.');

    % Consistent-tangent check against the internal residual.
    ep = 1e-6;
    maxFDHere = 0;
    for trial = 1:3
        v = randn(dm.nDOF, 1);
        v = v/norm(v);

        Rp = assembleGlobalResidual(Dm + ep*v, matt, m, dm, gt);
        Rm = assembleGlobalResidual(Dm - ep*v, matt, m, dm, gt);
        Kfdv = (Rp - Rm)/(2*ep);
        Kanv = Kg*v;

        maxFDHere = max(maxFDHere, ...
            norm(Kanv - Kfdv)/max(norm(Kfdv), eps));
    end

    assert(maxFDHere < 1e-4, ...
        'assembleGlobalTangent:self-test finite-difference consistency failed (%g).', maxFDHere);

    maxFDError = max(maxFDError, maxFDHere);
end

fprintf('assembleGlobalTangent self-test OK (max FD rel err = %.3e).\n', maxFDError);

end

function m = buildTangentTestMesh(Ne1, Ne2, h1e, h2e)

nNodes = (Ne1 + 1)*(Ne2 + 1);
nElem = Ne1*Ne2;

X = zeros(nNodes, 2);
for i2 = 0:Ne2
    for i1 = 0:Ne1
        nd = i2*(Ne1 + 1) + i1 + 1;
        X(nd, :) = [i1*h1e, i2*h2e];
    end
end

connect = zeros(nElem, 4);
elemGeom = repmat(struct('x0', 0, 'y0', 0, 'h1', h1e, 'h2', h2e), ...
                  nElem, 1);

e = 0;
for i2 = 0:Ne2-1
    for i1 = 0:Ne1-1
        e = e + 1;

        ndSW = i2*(Ne1 + 1) + i1 + 1;
        ndSE = ndSW + 1;
        ndNE = (i2 + 1)*(Ne1 + 1) + i1 + 2;
        ndNW = ndNE - 1;

        connect(e, :) = [ndSW, ndSE, ndNE, ndNW];
        elemGeom(e).x0 = i1*h1e;
        elemGeom(e).y0 = i2*h2e;
    end
end

m = struct();
m.nNodes = nNodes;
m.nElem = nElem;
m.Ne1 = Ne1;
m.Ne2 = Ne2;
m.X = X;
m.connect = connect;
m.L1 = Ne1*h1e;
m.L2 = Ne2*h2e;
m.h1 = h1e;
m.h2 = h2e;
m.elemGeom = elemGeom;
m.thickness = 1;

end
