function dN = bfsShapeFunctionDerivatives(xi, eta, h1, h2)
%BFSSHAPEFUNCTIONDERIVATIVES BFS shape functions and parent derivatives.
%
%   dN = bfsShapeFunctionDerivatives(xi, eta, h1, h2)
%
% Frozen Section 6 BFS layout:
%   Per component and node: [u_i, u_i,1, u_i,2, u_i,12].
%   The returned fields are 2x32 arrays.  Row 1 has its nonzero scalar
%   BFS block in columns 1:16; row 2 has it in columns 17:32.
%
% The fields contain parent-coordinate derivatives.  Material derivatives
% are obtained by the affine factors 2/h1 and 2/h2 in the element kernel.

persistent SELFTEST_ACTIVE SELFTEST_DONE

if isempty(SELFTEST_ACTIVE)
    SELFTEST_ACTIVE = false;
end
if isempty(SELFTEST_DONE)
    SELFTEST_DONE = false;
end

validateBFSInputs(xi, eta, h1, h2);

dN = bfsDerivativeCore(xi, eta, h1, h2);

% One-time non-recursive checks.  The test uses bfsDerivativeCore directly
% and therefore cannot call this public function recursively.
runSelfTest = ~SELFTEST_ACTIVE && ~SELFTEST_DONE;
if runSelfTest
    SELFTEST_ACTIVE = true;
    try
        runBFSDerivativeSelfTest(xi, eta, h1, h2);
        SELFTEST_DONE = true;
    catch ME
        SELFTEST_ACTIVE = false;
        rethrow(ME);
    end
    SELFTEST_ACTIVE = false;
end

end

% =====================================================================
% Core basis construction.
% =====================================================================
function dN = bfsDerivativeCore(xi, eta, h1, h2)

[Hxi, dHxi, d2Hxi] = hermite1D(xi);
[Heta, dHeta, d2Heta] = hermite1D(eta);

s1 = h1/2;
s2 = h2/2;
s12 = s1*s2;

nodeXi = [-1, 1, 1, -1];
nodeEta = [-1, -1, 1, 1];

N0one = zeros(1, 16);
dNdxione = zeros(1, 16);
dNdetaone = zeros(1, 16);
d2Ndxi2one = zeros(1, 16);
d2Ndeta2one = zeros(1, 16);
d2Ndxidetaone = zeros(1, 16);

col = 0;
for a = 1:4
    if nodeXi(a) == -1
        iVal = 1;
        iDer = 2;
    else
        iVal = 3;
        iDer = 4;
    end

    if nodeEta(a) == -1
        jVal = 1;
        jDer = 2;
    else
        jVal = 3;
        jDer = 4;
    end

    HxV = Hxi(iVal);     dHxV = dHxi(iVal);     d2HxV = d2Hxi(iVal);
    HxD = Hxi(iDer);     dHxD = dHxi(iDer);     d2HxD = d2Hxi(iDer);
    HeV = Heta(jVal);    dHeV = dHeta(jVal);    d2HeV = d2Heta(jVal);
    HeD = Heta(jDer);    dHeD = dHeta(jDer);    d2HeD = d2Heta(jDer);

    % Local DOF 1: displacement value.
    col = col + 1;
    N0one(col) = HxV*HeV;
    dNdxione(col) = dHxV*HeV;
    dNdetaone(col) = HxV*dHeV;
    d2Ndxi2one(col) = d2HxV*HeV;
    d2Ndeta2one(col) = HxV*d2HeV;
    d2Ndxidetaone(col) = dHxV*dHeV;

    % Local DOF 2: physical derivative u_i,1.
    col = col + 1;
    N0one(col) = s1*HxD*HeV;
    dNdxione(col) = s1*dHxD*HeV;
    dNdetaone(col) = s1*HxD*dHeV;
    d2Ndxi2one(col) = s1*d2HxD*HeV;
    d2Ndeta2one(col) = s1*HxD*d2HeV;
    d2Ndxidetaone(col) = s1*dHxD*dHeV;

    % Local DOF 3: physical derivative u_i,2.
    col = col + 1;
    N0one(col) = s2*HxV*HeD;
    dNdxione(col) = s2*dHxV*HeD;
    dNdetaone(col) = s2*HxV*dHeD;
    d2Ndxi2one(col) = s2*d2HxV*HeD;
    d2Ndeta2one(col) = s2*HxV*d2HeD;
    d2Ndxidetaone(col) = s2*dHxV*dHeD;

    % Local DOF 4: physical mixed derivative u_i,12.
    col = col + 1;
    N0one(col) = s12*HxD*HeD;
    dNdxione(col) = s12*dHxD*HeD;
    dNdetaone(col) = s12*HxD*dHeD;
    d2Ndxi2one(col) = s12*d2HxD*HeD;
    d2Ndeta2one(col) = s12*HxD*d2HeD;
    d2Ndxidetaone(col) = s12*dHxD*dHeD;
end

% Component-specific 32-column layout required by the element routines.
dN = struct();
dN.N0 = zeros(2, 32);
dN.dNdxi = zeros(2, 32);
dN.dNdeta = zeros(2, 32);
dN.d2Ndxi2 = zeros(2, 32);
dN.d2Ndeta2 = zeros(2, 32);
dN.d2Ndxideta = zeros(2, 32);

dN.N0(1, 1:16) = N0one;
dN.dNdxi(1, 1:16) = dNdxione;
dN.dNdeta(1, 1:16) = dNdetaone;
dN.d2Ndxi2(1, 1:16) = d2Ndxi2one;
dN.d2Ndeta2(1, 1:16) = d2Ndeta2one;
dN.d2Ndxideta(1, 1:16) = d2Ndxidetaone;

dN.N0(2, 17:32) = N0one;
dN.dNdxi(2, 17:32) = dNdxione;
dN.dNdeta(2, 17:32) = dNdetaone;
dN.d2Ndxi2(2, 17:32) = d2Ndxi2one;
dN.d2Ndeta2(2, 17:32) = d2Ndeta2one;
dN.d2Ndxideta(2, 17:32) = d2Ndxidetaone;

end

% =====================================================================
% Validation and non-recursive self-test.
% =====================================================================
function validateBFSInputs(xi, eta, h1, h2)

assert(isnumeric(xi) && isreal(xi) && isfinite(xi) && isscalar(xi), ...
    'bfsShapeFunctionDerivatives:xi must be a real finite scalar.');

assert(isnumeric(eta) && isreal(eta) && isfinite(eta) && isscalar(eta), ...
    'bfsShapeFunctionDerivatives:eta must be a real finite scalar.');

assert(isnumeric(h1) && isreal(h1) && isfinite(h1) && isscalar(h1) && h1 > 0, ...
    'bfsShapeFunctionDerivatives:h1 must be a positive scalar.');

assert(isnumeric(h2) && isreal(h2) && isfinite(h2) && isscalar(h2) && h2 > 0, ...
    'bfsShapeFunctionDerivatives:h2 must be a positive scalar.');

assert(xi >= -1 - 1e-12 && xi <= 1 + 1e-12, ...
    'bfsShapeFunctionDerivatives:xi is outside [-1,1].');

assert(eta >= -1 - 1e-12 && eta <= 1 + 1e-12, ...
    'bfsShapeFunctionDerivatives:eta is outside [-1,1].');

end

function runBFSDerivativeSelfTest(xi, eta, h1, h2)

tol = 1e-11;
dN = bfsDerivativeCore(xi, eta, h1, h2);

assert(isequal(size(dN.N0), [2, 32]), ...
    'bfsShapeFunctionDerivatives:N0 must be 2x32.');
assert(isequal(size(dN.dNdxi), [2, 32]), ...
    'bfsShapeFunctionDerivatives:dNdxi must be 2x32.');
assert(isequal(size(dN.dNdeta), [2, 32]), ...
    'bfsShapeFunctionDerivatives:dNdeta must be 2x32.');
assert(isequal(size(dN.d2Ndxi2), [2, 32]), ...
    'bfsShapeFunctionDerivatives:d2Ndxi2 must be 2x32.');
assert(isequal(size(dN.d2Ndeta2), [2, 32]), ...
    'bfsShapeFunctionDerivatives:d2Ndeta2 must be 2x32.');
assert(isequal(size(dN.d2Ndxideta), [2, 32]), ...
    'bfsShapeFunctionDerivatives:d2Ndxideta must be 2x32.');

% The active scalar blocks for u1 and u2 must be identical.
assert(max(abs(dN.N0(1, 1:16) - dN.N0(2, 17:32))) < tol, ...
    'bfsShapeFunctionDerivatives:u1/u2 value blocks disagree.');
assert(max(abs(dN.dNdxi(1, 1:16) - dN.dNdxi(2, 17:32))) < tol, ...
    'bfsShapeFunctionDerivatives:u1/u2 xi-derivative blocks disagree.');

% Partition of unity for displacement-value basis functions.
assert(abs(sum(dN.N0(1, [1, 5, 9, 13])) - 1) < tol, ...
    'bfsShapeFunctionDerivatives:u1 value basis fails partition of unity.');
assert(abs(sum(dN.N0(2, [17, 21, 25, 29])) - 1) < tol, ...
    'bfsShapeFunctionDerivatives:u2 value basis fails partition of unity.');

% Nodal interpolation and physical derivative interpolation at all nodes.
nodes = [-1, -1; 1, -1; 1, 1; -1, 1];
for a = 1:4
    dNode = bfsDerivativeCore(nodes(a, 1), nodes(a, 2), h1, h2);
    col0 = (a - 1)*4 + 1;

    expectedValue = zeros(1, 16);
    expectedValue(col0) = 1;

    expectedDx = zeros(1, 16);
    expectedDx(col0 + 1) = 1;

    expectedDy = zeros(1, 16);
    expectedDy(col0 + 2) = 1;

    expectedDxy = zeros(1, 16);
    expectedDxy(col0 + 3) = 1;

    assert(max(abs(dNode.N0(1, 1:16) - expectedValue)) < tol, ...
        'bfsShapeFunctionDerivatives:nodal value interpolation failed.');
    assert(max(abs((2/h1)*dNode.dNdxi(1, 1:16) - expectedDx)) < tol, ...
        'bfsShapeFunctionDerivatives:nodal X1-derivative interpolation failed.');
    assert(max(abs((2/h2)*dNode.dNdeta(1, 1:16) - expectedDy)) < tol, ...
        'bfsShapeFunctionDerivatives:nodal X2-derivative interpolation failed.');
    assert(max(abs((4/(h1*h2))*dNode.d2Ndxideta(1, 1:16) - expectedDxy)) < tol, ...
        'bfsShapeFunctionDerivatives:nodal mixed-derivative interpolation failed.');
end

% Linear completeness at the requested parent point for u=X1 and u=X2
% on a rectangle whose lower-left corner is (0,0).
nodeXY = [0, 0; h1, 0; h1, h2; 0, h2];
dofX1 = zeros(16, 1);
dofX2 = zeros(16, 1);
for a = 1:4
    base = (a - 1)*4;
    dofX1(base + 1) = nodeXY(a, 1);
    dofX1(base + 2) = 1;
    dofX2(base + 1) = nodeXY(a, 2);
    dofX2(base + 3) = 1;
end

x1 = h1*(xi + 1)/2;
x2 = h2*(eta + 1)/2;
assert(abs(dN.N0(1, 1:16)*dofX1 - x1) < tol, ...
    'bfsShapeFunctionDerivatives:linear X1 patch test failed.');
assert(abs(dN.N0(1, 1:16)*dofX2 - x2) < tol, ...
    'bfsShapeFunctionDerivatives:linear X2 patch test failed.');
assert(abs((2/h1)*dN.dNdxi(1, 1:16)*dofX1 - 1) < tol, ...
    'bfsShapeFunctionDerivatives:linear X1 derivative test failed.');
assert(abs((2/h2)*dN.dNdeta(1, 1:16)*dofX2 - 1) < tol, ...
    'bfsShapeFunctionDerivatives:linear X2 derivative test failed.');

end

function [H, dH, d2H] = hermite1D(t)

% Order: [value@-1, derivative@-1, value@+1, derivative@+1].
H = zeros(4, 1);
dH = zeros(4, 1);
d2H = zeros(4, 1);

H(1) = (2 - 3*t + t^3)/4;
H(2) = (1 - t - t^2 + t^3)/4;
H(3) = (2 + 3*t - t^3)/4;
H(4) = (-1 - t + t^2 + t^3)/4;

dH(1) = (-3 + 3*t^2)/4;
dH(2) = (-1 - 2*t + 3*t^2)/4;
dH(3) = (3 - 3*t^2)/4;
dH(4) = (-1 + 2*t + 3*t^2)/4;

d2H(1) = 6*t/4;
d2H(2) = (-2 + 6*t)/4;
d2H(3) = -6*t/4;
d2H(4) = (2 + 6*t)/4;

end
