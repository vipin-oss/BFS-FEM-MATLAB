function N = bfsShapeFunctions(xi, eta, h1, h2)
%BFSSHAPEFUNCTIONS  Bogner--Fox--Schmit (BFS) C^1 bicubic-Hermite
%                   shape functions on the biunit parent square.
%
%   N = BFSSHAPEFUNCTIONS(xi, eta, h1, h2)
%
% ----------------------------------------------------------------------
% Element description (frozen Sec. 6)
% ----------------------------------------------------------------------
% The BFS element is the rectangular, C^1-conforming, tensor-product
% bicubic Hermite element of Bogner, Fox & Schmit (1965).  It has 4
% corner nodes and 4 DOFs per node per in-plane displacement component
% (u_i, u_{i,1}, u_{i,2}, u_{i,12}), giving 16 DOFs per component
% and 32 DOFs total for the two-component (u1, u2) plane-strain
% problem (eqs. s6:DOF1--s6:d_elem).
%
% Parent element (biunit square):
%     xi in [-1, 1], eta in [-1, 1].
% Local node numbering (counter-clockwise, south-west origin):
%     node 1 = (-1, -1)   lower-left
%     node 2 = ( 1, -1)   lower-right
%     node 3 = ( 1,  1)   upper-right
%     node 4 = (-1,  1)   upper-left
%
% Parent <-> physical mapping (axis-aligned rectangle of side lengths
% h1 in x1, h2 in x2, with lower-left corner (x1_0, x2_0)):
%     x1 = x1_0 + (h1/2)*(xi + 1),     x2 = x2_0 + (h2/2)*(eta + 1),
%     dx1/dxi = h1/2,   dx2/deta = h2/2,   dx1/deta = dx2/dxi = 0.
% The chain rule therefore gives
%     d/dxi  = (h1/2) d/dx1,     d/deta = (h2/2) d/dx2,
% and for the mixed partial
%     d^2/dxi deta = (h1 h2 / 4) d^2/dx1 dx2.
%
% ----------------------------------------------------------------------
% 1D Hermite basis on [-1,1] (eqs. s6:H1--s6:H2)
% ----------------------------------------------------------------------
% For a parent coordinate t in [-1,1], the four cubic Hermite
% polynomials associated with, respectively,
%     H^{(1)}_{-} : value   at t = -1
%     H^{(2)}_{-} : t-deriv at t = -1
%     H^{(1)}_{+} : value   at t = +1
%     H^{(2)}_{+} : t-deriv at t = +1
% are:
%     H01(t) = (2 - 3 t + t^3)/4,    H02(t) = (1 - t - t^2 + t^3)/4,
%     H11(t) = (2 + 3 t - t^3)/4,    H12(t) = (-1 - t + t^2 + t^3)/4.
% They satisfy the standard interpolation / Kronecker-delta properties
%     H01(-1)=1, H01(1)=0;  H02(-1)=0, H02'(−1)=1;
%     H11(-1)=0, H11(1)=1;  H12(1) =0, H12'(1) =1;
% and the partition-of-unity H01(t)+H11(t) = 1 for all t.
%
% ----------------------------------------------------------------------
% 2D tensor-product construction (eqs. s6:N1--s6:N4)
% ----------------------------------------------------------------------
% For corner node a with xi-coordinate s_a in {-1,+1} and eta-
% coordinate t_a in {-1,+1}, let
%     Hxi_a(xi)  = value-shape  in xi at s_a        (H01 or H11)
%     Gxi_a(xi)  = xi-deriv shape in xi at s_a      (H02 or H12)
%     Heta_a(eta)= value-shape  in eta at t_a
%     Geta_a(eta)= eta-deriv shape in eta at t_a.
% The four BFS shape functions attached to node a (per component) are
%     N_a^{(1)}(xi,eta) = Hxi_a(xi) Heta_a(eta),
%     N_a^{(2)}(xi,eta) = (h1/2)  * Gxi_a(xi) Heta_a(eta),
%     N_a^{(3)}(xi,eta) = (h2/2)  * Hxi_a(xi) Geta_a(eta),
%     N_a^{(4)}(xi,eta) = (h1 h2/4) * Gxi_a(xi) Geta_a(eta).
% The h1/h2 factors are the chain-rule scaling from parent to physical
% derivatives (dx1/dxi = h1/2, dx2/deta = h2/2).  With these factors
% built in, interpolation
%     u_h(xi,eta) = sum_a sum_{alpha=1}^4  N_a^{(alpha)}(xi,eta) * d_{a,alpha}
% is in terms of the PHYSICAL-DERIVATIVE DOFs
%     d_{a,1} = u,     d_{a,2} = du/dx1,
%     d_{a,3} = du/dx2, d_{a,4} = d^2u/dx1 dx2,
% and the parent-to-physical chain rule applied to the returned
% parent derivatives recovers the physical derivatives exactly at
% nodes: at node b,
%     N_a^{(1)}(node_b)                                  = delta_{ab},
%     (2/h1)  dN_a^{(2)}/dxi   (node_b) = du/dx1(node_b)= delta_{ab},
%     (2/h2)  dN_a^{(3)}/deta  (node_b) = du/dx2(node_b)= delta_{ab},
%     (4/h1h2) d^2N_a^{(4)}/dxi deta(node_b)=d^2u/dx1dx2= delta_{ab},
% with all other entries zero (Kronecker-delta interpolation).
%
% ----------------------------------------------------------------------
% DOF ordering (matches eq. s6:d_elem)
% ----------------------------------------------------------------------
% The returned shape-function matrix N is 4 x 16.
% Column ordering for one displacement component (16 columns), which
% is identical for u1 and u2 (the element has 32 DOFs total):
%   columns  1.. 4 : node 1 DOFs 1..4   [u, u_{,1}, u_{,2}, u_{,12}]
%   columns  5.. 8 : node 2 DOFs 1..4
%   columns  9..12 : node 3 DOFs 1..4
%   columns 13..16 : node 4 DOFs 1..4
% The second displacement component (u2) uses the identical set of 16
% shape functions, giving the 32-element element-DOF vector
%   d^e = [u1 DOFs (16); u2 DOFs (16)]
% when columns of N are duplicated by the caller (see
% bfsShapeFunctionDerivatives for the duplicated 32-column format
% used in the B-matrix construction).  Here N is returned as 4 x 16
% for one component; both components share the same shape functions
% because the BFS interpolation is scalar-valued per component.
%
% The first row gives N (function value); the remaining three rows are
% included for API uniformity with bfsShapeFunctionDerivatives and
% hold dN/dxi, dN/deta, d2N/dxi deta at the requested point.  Only
% the first row is used for function-value interpolation; callers
% that need derivatives should use bfsShapeFunctionDerivatives.
%
% Inputs:
%   xi, eta    Parent coordinates, both in [-1,1]              (scalar)
%   h1, h2     Physical element side lengths (x1 and x2)       (scalar > 0)
%
% Output:
%   N          4 x 16 array, for one displacement component:
%              N(1,:) = N_a^{(\alpha)}(xi,eta)        [function values]
%              N(2,:) = d N_a^{(\alpha)} / d xi
%              N(3,:) = d N_a^{(\alpha)} / d eta
%              N(4,:) = d^2 N_a^{(\alpha)} / d xi d eta
%              Columns ordered by (node, local-DOF) as above.
%
% Equation mapping (frozen Sections 1--9):
%   eqs. (s6:H1)--(s6:H2)   : 1D Hermite basis on [-1,1]
%   eqs. (s6:N1)--(s6:N4)   : tensor-product BFS shape functions
%   eqs. (s6:DOF1)--(s6:d_elem) : DOF / column ordering
%
% See also BFSSHAPEFUNCTIONDERIVATIVES.

% ======================================================================
% Input validation
% ======================================================================
assert(isscalar(xi)  && isnumeric(xi),  'bfsShapeFunctions:xi must be a scalar.');
assert(isscalar(eta) && isnumeric(eta), 'bfsShapeFunctions:eta must be a scalar.');
assert(isscalar(h1)  && h1 > 0,         'bfsShapeFunctions:h1 must be positive scalar.');
assert(isscalar(h2)  && h2 > 0,         'bfsShapeFunctions:h2 must be positive scalar.');
assert(xi  >= -1 - 1e-12 && xi  <= 1 + 1e-12, 'bfsShapeFunctions:xi outside [-1,1].');
assert(eta >= -1 - 1e-12 && eta <= 1 + 1e-12, 'bfsShapeFunctions:eta outside [-1,1].');

% ======================================================================
% 1D Hermite basis and first derivatives in xi, eta.
%   Order at each endpoint: [value at -1, t-derivative at -1,
%                            value at +1, t-derivative at +1].
% ======================================================================
[Hxi,  dHxi ] = hermite1D(xi);
[Heta, dHeta] = hermite1D(eta);

% h1/h2 scaling factors from parent -> physical derivatives.
s1 = h1/2;
s2 = h2/2;
s12 = s1*s2;                  % h1 h2 / 4

% ======================================================================
% Node convention: 4 nodes x 4 local DOFs = 16 columns.
%   For each node a in {1,2,3,4} index:
%     is = 1 or 3 selects whether the xi endpoint is -1 (index 1) or
%          +1 (index 3) for the VALUE shape H01/H11;
%     the xi derivative shape is the NEXT index (2 or 4).
%     Same for eta (js / js+1).
% Node coordinates (xi_end, eta_end):
%   node 1: (-1,-1); node 2: (+1,-1); node 3: (+1,+1); node 4: (-1,+1).
% ======================================================================
nodeXi  = [-1,  1,  1, -1];   % xi-end  +/-1 per node
nodeEta = [-1, -1,  1,  1];   % eta-end +/-1 per node

% Endpoint index lookups (avoiding toolboxes / containers for maximum
% portability).  For endpoint s in {-1,+1}, iV(s) returns the index of
% the value Hermite (H01 or H11) in the 4-vector Hxi/Heta and iD(s)
% returns the index of the derivative Hermite (H02 or H12).
iV = @(s) (s == -1)*1 + (s == 1)*3;
iD = @(s) (s == -1)*2 + (s == 1)*4;

N = zeros(4, 16);
col = 0;
for a = 1:4
    sxi = nodeXi(a);
    seta = nodeEta(a);
    ixi = iV(sxi);   jxi = iD(sxi);
    iet = iV(seta);  jet = iD(seta);

    % Local DOF 1: value shape = Hxi_val * Heta_val
    col = col + 1;
    N(1,col) = Hxi(ixi)*Heta(iet);
    N(2,col) = dHxi(ixi)*Heta(iet);
    N(3,col) = Hxi(ixi)*dHeta(iet);
    N(4,col) = dHxi(ixi)*dHeta(iet);

    % Local DOF 2: xi-derivative shape = s1 * Hxi_der * Heta_val
    col = col + 1;
    N(1,col) = s1 * Hxi(jxi)*Heta(iet);
    N(2,col) = s1 * dHxi(jxi)*Heta(iet);
    N(3,col) = s1 * Hxi(jxi)*dHeta(iet);
    N(4,col) = s1 * dHxi(jxi)*dHeta(iet);

    % Local DOF 3: eta-derivative shape = s2 * Hxi_val * Heta_der
    col = col + 1;
    N(1,col) = s2 * Hxi(ixi)*Heta(jet);
    N(2,col) = s2 * dHxi(ixi)*Heta(jet);
    N(3,col) = s2 * Hxi(ixi)*dHeta(jet);
    N(4,col) = s2 * dHxi(ixi)*dHeta(jet);

    % Local DOF 4: mixed-derivative shape = s12 * Hxi_der * Heta_der
    col = col + 1;
    N(1,col) = s12 * Hxi(jxi)*Heta(jet);
    N(2,col) = s12 * dHxi(jxi)*Heta(jet);
    N(3,col) = s12 * Hxi(jxi)*dHeta(jet);
    N(4,col) = s12 * dHxi(jxi)*dHeta(jet);
end

% ======================================================================
% Internal verification
% ======================================================================
% (i) Dimensions.
assert(isequal(size(N), [4, 16]), ...
    'bfsShapeFunctions:N must be 4x16 (one component, 4 nodes x 4 DOFs).');

% (ii) Partition of unity: sum of the four N_a^{(1)} shapes (DOF 1 of
%      each node, i.e. the value-interpolating functions) must be 1.
pu = N(1,1) + N(1,5) + N(1,9) + N(1,13);
assert(abs(pu - 1) < 1e-12, 'bfsShapeFunctions:partition of unity failed.');

% (iii) Nodal Kronecker-delta property in physical-derivative form.
%       At each of the four parent nodes, the 16 entries of N must
%       satisfy (after the parent-to-physical chain-rule scaling)
%           N(1, col0)   = 1,
%           (2/h1)  N(2, col0+1) = 1,
%           (2/h2)  N(3, col0+2) = 1,
%           (4/(h1h2)) N(4, col0+3) = 1,
%       with every other entry zero.
nodeXiN  = [-1, 1, 1,-1];
nodeEtaN = [-1,-1, 1, 1];
for a = 1:4
    Nn = bfsShapeFunctions(nodeXiN(a), nodeEtaN(a), h1, h2);
    col0 = (a-1)*4 + 1;
    expected = zeros(1,16);
    expected(col0)   = 1;
    assert(max(abs(Nn(1,:) - expected)) < 1e-12, ...
        'bfsShapeFunctions:nodal value Kronecker failed.');
    expectedDx = zeros(1,16); expectedDx(col0+1) = 1;
    assert(max(abs((2/h1)*Nn(2,:) - expectedDx)) < 1e-12, ...
        'bfsShapeFunctions:nodal dxi (physical) Kronecker failed.');
    expectedDe = zeros(1,16); expectedDe(col0+2) = 1;
    assert(max(abs((2/h2)*Nn(3,:) - expectedDe)) < 1e-12, ...
        'bfsShapeFunctions:nodal deta (physical) Kronecker failed.');
    expectedDm = zeros(1,16); expectedDm(col0+3) = 1;
    assert(max(abs((4/(h1*h2))*Nn(4,:) - expectedDm)) < 1e-12, ...
        'bfsShapeFunctions:nodal mixed-deriv (physical) Kronecker failed.');
end

% (iv) One-component polynomial completeness spot check.  Using the
%      full 4x16 single-component matrix (N, dN/dxi, dN/deta, d2N/dxi
%      deta) on a [-1,1]^2 physical patch, verify that the 10
%      bicubic monomials {1, x, y, x^2, xy, y^2, x^3, x^2y, xy^2,
%      y^3} are reproduced EXACTLY at the element centre (xi=0,
%      eta=0) when all four nodal DOFs (u, u_{,1}, u_{,2}, u_{,12})
%      are set from the exact polynomial values.  This confirms that
%      the single-component shape matrix is consistent with the
%      two-component struct returned by bfsShapeFunctionDerivatives.
h1c = 2; h2c = 2; x0c = -1; y0c = -1;
s1c = h1c/2; s2c = h2c/2; s12c = s1c*s2c;
cPtsC = [x0c y0c; x0c+h1c y0c; x0c+h1c y0c+h2c; x0c y0c+h2c];
monoU  = {@(x,y)ones(size(x)), @(x,y)x, @(x,y)y, @(x,y)x.*x, ...
          @(x,y)x.*y, @(x,y)y.*y, @(x,y)x.^3, @(x,y)x.*x.*y, ...
          @(x,y)x.*y.*y, @(x,y)y.^3};
monoUx = {@(x,y)0*x, @(x,y)0*x+1, @(x,y)0*x, @(x,y)2*x, ...
          @(x,y)y, @(x,y)0*x, @(x,y)3*x.*x, @(x,y)2*x.*y, ...
          @(x,y)y.*y, @(x,y)0*x};
monoUy = {@(x,y)0*x, @(x,y)0*x, @(x,y)0*x+1, @(x,y)0*x, ...
          @(x,y)x, @(x,y)2*y, @(x,y)0*x, @(x,y)x.*x, ...
          @(x,y)2*x.*y, @(x,y)3*y.*y};
monoUxy= {@(x,y)0*x, @(x,y)0*x, @(x,y)0*x, @(x,y)0*x, ...
          @(x,y)0*x+1, @(x,y)0*x, @(x,y)0*x, @(x,y)2*x, ...
          @(x,y)2*y, @(x,y)0*x};
xiS = 0; etaS = 0;
Nc = bfsShapeFunctions(xiS, etaS, h1c, h2c);
xs = x0c + s1c*(xiS+1); ys = y0c + s2c*(etaS+1);
for m = 1:numel(monoU)
    dofm = zeros(1,16);
    for a = 1:4
        xc = cPtsC(a,1); yc = cPtsC(a,2);
        dofm((a-1)*4+1) = monoU{m}(xc,yc);
        dofm((a-1)*4+2) = monoUx{m}(xc,yc);
        dofm((a-1)*4+3) = monoUy{m}(xc,yc);
        dofm((a-1)*4+4) = monoUxy{m}(xc,yc);
    end
    uh   = Nc(1,:)*dofm.';
    uxh  = (1/s1c )*Nc(2,:)*dofm.';
    uyh  = (1/s2c )*Nc(3,:)*dofm.';
    uxyh = (1/s12c)*Nc(4,:)*dofm.';
    assert(abs(uh - monoU{m}(xs,ys)) < 1e-12, ...
        'bfsShapeFunctions:value interpolation spot-check failed on monomial %d.', m);
    assert(abs(uxh - monoUx{m}(xs,ys)) < 1e-12, ...
        'bfsShapeFunctions:u_{,1} interpolation spot-check failed on monomial %d.', m);
    assert(abs(uyh - monoUy{m}(xs,ys)) < 1e-12, ...
        'bfsShapeFunctions:u_{,2} interpolation spot-check failed on monomial %d.', m);
    assert(abs(uxyh - monoUxy{m}(xs,ys)) < 1e-12, ...
        'bfsShapeFunctions:u_{,12} interpolation spot-check failed on monomial %d.', m);
end

% ======================================================================
% Local 1D Hermite evaluator (self-contained).
%   Returns the four basis values and their first derivatives at t.
%   Order: [H01, H02, H11, H12] = [value@-1, deriv@-1, value@+1, deriv@+1].
% ======================================================================
    function [H, dH] = hermite1D(t)
        H  = zeros(4,1);
        dH = zeros(4,1);
        H(1)  = (2 - 3*t + t^3)/4;            % H01
        H(2)  = (1 - t - t^2 + t^3)/4;        % H02 (xi-derivative at -1)
        H(3)  = (2 + 3*t - t^3)/4;            % H11
        H(4)  = (-1 - t + t^2 + t^3)/4;       % H12 (xi-derivative at +1)
        dH(1) = (-3 + 3*t^2)/4;
        dH(2) = (-1 - 2*t + 3*t^2)/4;
        dH(3) = ( 3 - 3*t^2)/4;
        dH(4) = (-1 + 2*t + 3*t^2)/4;
    end

end
