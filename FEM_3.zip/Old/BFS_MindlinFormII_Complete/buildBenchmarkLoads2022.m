function Fext = buildBenchmarkLoads2022(mesh, dof, gauss, caseName, that, thickness)
%BUILDBENCHMARKLOADS2022 Reference external load for 2022 benchmark.
%
% Case 1 is displacement controlled and has no applied traction.
% Case 2 applies the paper's constant top-edge traction t_x = that.
% Zero double traction is natural and therefore contributes no load vector.

caseName = lower(char(caseName));
assert(any(strcmp(caseName, {'case1', 'case2'})), ...
    'buildBenchmarkLoads2022:caseName must be case1 or case2.');
assert(isnumeric(that) && isreal(that) && isfinite(that) && isscalar(that), ...
    'buildBenchmarkLoads2022:that must be a real finite scalar.');
assert(isnumeric(thickness) && isreal(thickness) && isfinite(thickness) && ...
       isscalar(thickness) && thickness > 0, ...
    'buildBenchmarkLoads2022:thickness must be positive.');

Fext = zeros(dof.nDOF, 1);
if strcmp(caseName, 'case1')
    return;
end

% Case 2: integrate t_x*N_a over all top boundary element edges.
tol = 1e-10*max(1, max(abs(mesh.X(:))));
yTop = max(mesh.X(:, 2));

for e = 1:mesh.nElem
    eg = mesh.elemGeom(e);
    if abs((eg.y0 + eg.h2) - yTop) > tol
        continue;
    end

    edofsU1 = dof.elemDOF(e, 1:16);
    edgeJacobian = eg.h1/2;

    for g = 1:gauss.ng
        xi = gauss.xi1D(g);
        w = gauss.w1D(g);

        dN = bfsShapeFunctionDerivatives(xi, 1, eg.h1, eg.h2);
        Ntop = dN.N0(1, 1:16);

        Fext(edofsU1) = Fext(edofsU1) + ...
            (thickness*edgeJacobian*w*that)*Ntop.';
    end
end

end
