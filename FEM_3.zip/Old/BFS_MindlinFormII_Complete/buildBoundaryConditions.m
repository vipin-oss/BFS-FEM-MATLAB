function [bc, dof] = buildBoundaryConditions(mesh, dof, bcSpecs)
%BUILDBOUNDARYCONDITIONS Build essential BFS boundary conditions.
%
%   [bc, dof] = buildBoundaryConditions(mesh, dof, bcSpecs)
%
% Frozen Sections 4 and 6:
%   Essential data are displacement u_i and normal slope du_i/dN.
%   BFS local DOFs are [u_i, u_i,1, u_i,2, u_i,12], ld=1:4.
%   Global DOFs are provided by buildDOFMap through dof.ID(ld,comp,node).

persistent SELFTEST_ACTIVE

if isempty(SELFTEST_ACTIVE)
    SELFTEST_ACTIVE = false;
end

% Only the outermost call executes the self-test.  Nested calls made by
% that self-test construct BCs normally and must not reset this guard.
runSelfTest = ~SELFTEST_ACTIVE;
if runSelfTest
    SELFTEST_ACTIVE = true;
end

try
    % ------------------------------------------------------------------
    % Input validation.
    % ------------------------------------------------------------------
    assert(isstruct(mesh) && isfield(mesh, 'X') && isfield(mesh, 'nNodes'), ...
        'buildBoundaryConditions:mesh must contain X and nNodes.');

    assert(isstruct(dof) && isfield(dof, 'nDOF') && isfield(dof, 'ID'), ...
        ['buildBoundaryConditions:dof must contain nDOF and ID ' ...
         '(call buildDOFMap first).']);

    X = mesh.X;
    Nn = mesh.nNodes;
    nDOF = dof.nDOF;

    assert(isequal(size(X), [Nn, 2]), ...
        'buildBoundaryConditions:mesh.X must be N_n x 2.');

    assert(isequal(size(dof.ID), [4, 2, Nn]) && nDOF == 8*Nn, ...
        'buildBoundaryConditions:dof is incompatible with the 2D BFS DOF map.');

    if isfield(mesh, 'h1') && isfield(mesh, 'h2')
        tol = 1e-10*min(mesh.h1, mesh.h2);
    else
        tol = 1e-10*max(1, max(abs(X(:))));
    end
    tol = max(tol, 1e-12);

    X1min = min(X(:, 1));
    X1max = max(X(:, 1));
    X2min = min(X(:, 2));
    X2max = max(X(:, 2));

    % ------------------------------------------------------------------
    % Normalize input specifications into one consistent struct array.
    % This avoids assignment between structs with different field sets.
    % ------------------------------------------------------------------
    specs = normalizeBCSpecs(bcSpecs);

    % ------------------------------------------------------------------
    % Resolve specifications into essential global-DOF constraints.
    % ------------------------------------------------------------------
    essSet = false(nDOF, 1);
    essVal = zeros(nDOF, 1);

    entryTemplate = struct('edge', '', 'comp', 0, 'dofType', '', ...
                           'node', 0, 'gDOF', 0, 'value', 0, ...
                           'physVal', 0);
    essList = repmat(entryTemplate, 0, 1);
    nEss = 0;

    edgeCodes = {'x0', 'x1', 'y0', 'y1'};

    for kk = 1:numel(specs)
        spec = specs(kk);

        edge = lower(spec.edge);
        comp = spec.comp;
        dtype = lower(spec.dofType);
        val = spec.value;

        assert(any(strcmp(edge, edgeCodes)), ...
            'buildBoundaryConditions:edge must be x0/x1/y0/y1.');

        assert(isnumeric(comp) && isreal(comp) && isfinite(comp) && ...
               isscalar(comp) && (comp == 1 || comp == 2), ...
            'buildBoundaryConditions:comp must be 1 or 2.');

        if strcmp(dtype, 'all')
            assert(isnumeric(val) && isreal(val) && isfinite(val) && ...
                   isscalar(val) && val == 0, ...
                ['buildBoundaryConditions:dofType=''all'' requires ' ...
                 'homogeneous value 0.']);
            subdofs = {'u', 'dudn'};
        else
            assert(any(strcmp(dtype, {'u', 'dudn'})), ...
                ['buildBoundaryConditions:dofType must be ''u'', ' ...
                 '''dudN'', or ''all''.']);
            subdofs = {dtype};
        end

        for sd = 1:numel(subdofs)
            dt = subdofs{sd};

            switch edge
                case 'x0'
                    onEdge = abs(X(:, 1) - X1min) < tol;
                    if strcmp(dt, 'u')
                        ld = 1;
                        sgn = 1;
                    else
                        ld = 2;
                        sgn = -1;
                    end

                case 'x1'
                    onEdge = abs(X(:, 1) - X1max) < tol;
                    if strcmp(dt, 'u')
                        ld = 1;
                        sgn = 1;
                    else
                        ld = 2;
                        sgn = 1;
                    end

                case 'y0'
                    onEdge = abs(X(:, 2) - X2min) < tol;
                    if strcmp(dt, 'u')
                        ld = 1;
                        sgn = 1;
                    else
                        ld = 3;
                        sgn = -1;
                    end

                case 'y1'
                    onEdge = abs(X(:, 2) - X2max) < tol;
                    if strcmp(dt, 'u')
                        ld = 1;
                        sgn = 1;
                    else
                        ld = 3;
                        sgn = 1;
                    end
            end

            edgeNodes = find(onEdge);
            assert(~isempty(edgeNodes), ...
                'buildBoundaryConditions:no nodes found on edge "%s".', edge);

            for ni = 1:numel(edgeNodes)
                nd = edgeNodes(ni);
                gid = dof.ID(ld, comp, nd);

                v = evaluateBCValue(val, ni, numel(edgeNodes), X(nd, 1), X(nd, 2), kk);
                pv = sgn*v;

                if essSet(gid)
                    assert(abs(essVal(gid) - pv) <= ...
                           1e-10*max(1, abs(pv) + abs(essVal(gid))), ...
                        ['buildBoundaryConditions:DOF %d has conflicting ' ...
                         'prescribed values (%g and %g).'], ...
                        gid, essVal(gid), pv);
                else
                    essSet(gid) = true;
                    essVal(gid) = pv;
                    nEss = nEss + 1;

                    ent = entryTemplate;
                    ent.edge = edge;
                    ent.comp = comp;
                    ent.dofType = dt;
                    ent.node = nd;
                    ent.gDOF = gid;
                    ent.value = v;
                    ent.physVal = pv;
                    essList(nEss, 1) = ent;
                end
            end
        end
    end

    % ------------------------------------------------------------------
    % Partition global DOFs.
    % ------------------------------------------------------------------
    essD = find(essSet);
    freeD = setdiff((1:nDOF).', essD, 'sorted');

    dof.freeDOF = freeD(:);
    dof.essDOF = essD(:);
    dof.essVals = essVal(essD);

    bc = struct();
    bc.essential = essList;
    bc.nEss = nEss;
    bc.nFree = numel(freeD);
    bc.edgeCodes = edgeCodes;

    % ------------------------------------------------------------------
    % Internal self-test: outer call only.
    % ------------------------------------------------------------------
    if runSelfTest
        verifyBoundaryConditions(mesh, dof, nDOF);
    end

catch ME
    if runSelfTest
        SELFTEST_ACTIVE = false;
    end
    rethrow(ME);
end

if runSelfTest
    SELFTEST_ACTIVE = false;
end

end

% =====================================================================
% Local helpers.
% =====================================================================
function specs = normalizeBCSpecs(bcSpecs)

specTemplate = struct('edge', '', 'comp', 0, 'dofType', '', 'value', 0);

if nargin < 1 || isempty(bcSpecs)
    specs = repmat(specTemplate, 0, 1);
    return;
end

if iscell(bcSpecs)
    raw = bcSpecs(:);
elseif isstruct(bcSpecs)
    raw = cell(numel(bcSpecs), 1);
    for kk = 1:numel(bcSpecs)
        raw{kk} = bcSpecs(kk);
    end
else
    error(['buildBoundaryConditions:bcSpecs must be a struct array or ' ...
           'a cell array of structs/cell specifications.']);
end

specs = repmat(specTemplate, numel(raw), 1);

for kk = 1:numel(raw)
    s = raw{kk};

    if iscell(s)
        assert(numel(s) >= 3 && numel(s) <= 4, ...
            ['buildBoundaryConditions:cell BC specification %d must be ' ...
             '{edge,comp,dofType[,value]}.'], kk);

        edge = s{1};
        comp = s{2};
        dofType = s{3};
        if numel(s) == 4
            value = s{4};
        else
            value = 0;
        end

    elseif isstruct(s)
        assert(isfield(s, 'edge') && isfield(s, 'comp') && isfield(s, 'dofType'), ...
            ['buildBoundaryConditions:bcSpecs(%d) must contain ' ...
             'edge, comp, and dofType.'], kk);

        edge = s.edge;
        comp = s.comp;
        dofType = s.dofType;
        if isfield(s, 'value') && ~isempty(s.value)
            value = s.value;
        else
            value = 0;
        end

    else
        error('buildBoundaryConditions:bcSpecs(%d) is not a valid specification.', kk);
    end

    specs(kk).edge = normalizeText(edge, 'edge');
    specs(kk).comp = comp;
    specs(kk).dofType = normalizeText(dofType, 'dofType');
    specs(kk).value = value;
end

end

function v = evaluateBCValue(val, ni, nEdgeNodes, X1, X2, kk)

if isa(val, 'function_handle')
    v = val(X1, X2);

elseif isnumeric(val) && isreal(val) && all(isfinite(val(:)))
    if isscalar(val)
        v = val;
    elseif isvector(val) && numel(val) == nEdgeNodes
        v = val(ni);
    else
        error(['buildBoundaryConditions:value for bc(%d) must be a scalar, ' ...
               'function handle, or nEdgeNodes-vector.'], kk);
    end

else
    error('buildBoundaryConditions:value must be real finite numeric data or a function handle.');
end

assert(isnumeric(v) && isreal(v) && isfinite(v) && isscalar(v), ...
    'buildBoundaryConditions:prescribed value must evaluate to a real finite scalar.');

end

function text = normalizeText(value, fieldName)

if ischar(value)
    text = value;
elseif exist('isstring', 'builtin') && isstring(value) && isscalar(value)
    text = char(value);
else
    error('buildBoundaryConditions:%s must be a character vector or scalar string.', fieldName);
end

end

function verifyBoundaryConditions(~, dof, nDOF)

TOL = 1e-12;

assert(numel(dof.freeDOF) + numel(dof.essDOF) == nDOF, ...
    'buildBoundaryConditions:free and essential DOFs do not cover nDOF.');

assert(isempty(intersect(dof.freeDOF, dof.essDOF)), ...
    'buildBoundaryConditions:free and essential DOFs are not disjoint.');

assert(isequal(union(dof.freeDOF, dof.essDOF), (1:nDOF).'), ...
    'buildBoundaryConditions:free and essential DOFs do not cover 1:nDOF.');

m1 = struct();
m1.L1 = 1; m1.L2 = 1; m1.h1 = 1; m1.h2 = 1;
m1.nNodes = 4; m1.nElem = 1;
m1.X = [0, 0; 1, 0; 1, 1; 0, 1];
m1.connect = [1, 2, 3, 4];

% buildDOFMap has its own recursion-safe self-test guard.
df1 = buildDOFMap(m1);

specTemplate = struct('edge', '', 'comp', 0, 'dofType', '', 'value', 0);
edgeList = {'x0', 'x1', 'y0', 'y1'};
sp = repmat(specTemplate, 4, 1);
for k = 1:4
    sp(k).edge = edgeList{k};
    sp(k).comp = 1;
    sp(k).dofType = 'all';
    sp(k).value = 0;
end

[b1, df1] = buildBoundaryConditions(m1, df1, sp);
assert(b1.nEss == 12, ...
    'buildBoundaryConditions:self-test expected 12 clamped u1 DOFs.');
assert(numel(df1.freeDOF) == 20, ...
    'buildBoundaryConditions:self-test expected 20 free DOFs.');
assert(norm(df1.essVals) == 0, ...
    'buildBoundaryConditions:self-test homogeneous values are not zero.');

for qq = 1:b1.nEss
    [ld, ~] = localDOF(df1, b1.essential(qq).gDOF);
    assert(ld ~= 4, ...
        'buildBoundaryConditions:self-test mixed derivative was constrained.');
end

sU = struct('edge', 'x0', 'comp', 1, 'dofType', 'u', 'value', 0.7);
df2 = buildDOFMap(m1);
[b2, df2] = buildBoundaryConditions(m1, df2, sU);
assert(b2.nEss == 2, ...
    'buildBoundaryConditions:self-test expected two x0 displacement DOFs.');
assert(all(abs(df2.essVals - 0.7) < TOL), ...
    'buildBoundaryConditions:self-test nonhomogeneous displacement mismatch.');

sN = struct('edge', 'y1', 'comp', 2, 'dofType', 'dudN', 'value', 0.1);
df3 = buildDOFMap(m1);
[b3, df3] = buildBoundaryConditions(m1, df3, sN);
assert(b3.nEss == 2, ...
    'buildBoundaryConditions:self-test expected two y1 normal-slope DOFs.');
assert(all(abs(df3.essVals - 0.1) < TOL), ...
    'buildBoundaryConditions:self-test y1 normal-slope value mismatch.');
for qq = 1:b3.nEss
    [ld, comp] = localDOF(df3, b3.essential(qq).gDOF);
    assert(ld == 3 && comp == 2, ...
        'buildBoundaryConditions:self-test y1 dudN must constrain u2,2.');
end

sa = struct('edge', 'x0', 'comp', 1, 'dofType', 'u', 'value', 0.5);
sb = struct('edge', 'x0', 'comp', 1, 'dofType', 'u', 'value', 0.5);
df4 = buildDOFMap(m1);
buildBoundaryConditions(m1, df4, [sa, sb]);

sc = struct('edge', 'x0', 'comp', 1, 'dofType', 'u', 'value', 0.5);
sd = struct('edge', 'x0', 'comp', 1, 'dofType', 'u', 'value', 0.6);
df5 = buildDOFMap(m1);
conflictCaught = false;
try
    buildBoundaryConditions(m1, df5, [sc, sd]);
catch ME
    conflictCaught = contains(ME.message, 'conflicting');
end
assert(conflictCaught, ...
    'buildBoundaryConditions:self-test conflicting constraints must fail.');

sFn = struct('edge', 'x0', 'comp', 1, 'dofType', 'u', ...
             'value', @(X1, X2) X2);
df6 = buildDOFMap(m1);
[b6, df6] = buildBoundaryConditions(m1, df6, sFn);
assert(b6.nEss == 2, ...
    'buildBoundaryConditions:self-test function-handle BC expected two DOFs.');
for qq = 1:b6.nEss
    nd = b6.essential(qq).node;
    ii = find(df6.essDOF == b6.essential(qq).gDOF, 1);
    assert(abs(df6.essVals(ii) - m1.X(nd, 2)) < TOL, ...
        'buildBoundaryConditions:self-test function-handle value mismatch.');
end

fprintf('buildBoundaryConditions self-test OK.\n');

end

function [ld, comp, node] = localDOF(dof, gidx)

[idxLD, idxComp, idxNode] = ind2sub(size(dof.ID), find(dof.ID == gidx, 1));
assert(~isempty(idxLD), ...
    'buildBoundaryConditions:localDOF could not find the requested global DOF.');

ld = idxLD;
comp = idxComp;
node = idxNode;

end
