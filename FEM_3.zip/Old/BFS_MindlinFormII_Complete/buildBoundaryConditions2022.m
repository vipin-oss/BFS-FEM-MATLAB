function constraints = buildBoundaryConditions2022(mesh, dof, caseName, prescribed)
%BUILDBOUNDARYCONDITIONS2022 Compatibility entry point for the isolated
% 2022 benchmark suite.  It creates periodic/MPC and benchmark-specific
% essential constraints without changing buildBoundaryConditions.m.

constraints = buildPeriodicConstraints2022(mesh, dof, caseName, prescribed);

end
