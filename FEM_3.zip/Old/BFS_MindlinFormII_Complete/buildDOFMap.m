function dof = buildDOFMap(mesh)
%BUILDDOFMAP Build global BFS DOF numbering and element-to-global map.
%
%   dof = buildDOFMap(mesh)
%
% Frozen Section 6 convention:
%   Each 2D BFS node carries, for each component i=1,2,
%   [u_i, u_i,1, u_i,2, u_i,12].
%   Hence nDOF = 8*nNodes.
%
% Global component-block ordering:
%   ID(ld,1,n) = 4*(n-1) + ld
%   ID(ld,2,n) = 4*nNodes + 4*(n-1) + ld
%
% Element ordering (Section 6, eq. s6:d_elem):
%   cols  1:16  : component u1, local nodes 1:4, DOFs [u,u,1,u,2,u,12]
%   cols 17:32  : component u2, local nodes 1:4, DOFs [u,u,1,u,2,u,12]

persistent SELFTEST_ACTIVE

if isempty(SELFTEST_ACTIVE)
    SELFTEST_ACTIVE = false;
end

% Only the outermost invocation owns and executes the self-test.
% Recursive invocation used by the one-element test only builds its map.
runSelfTest = ~SELFTEST_ACTIVE;

if runSelfTest
    SELFTEST_ACTIVE = true;
end

try
    % ------------------------------------------------------------------
    % Input validation.
    % ------------------------------------------------------------------
    assert(isstruct(mesh), 'buildDOFMap:mesh must be a struct.');

    assert(isfield(mesh, 'nNodes') && isfield(mesh, 'nElem') && ...
           isfield(mesh, 'connect'), ...
        'buildDOFMap:mesh must contain nNodes, nElem, and connect.');

    Nn = mesh.nNodes;
    Ne = mesh.nElem;

    assert(isnumeric(Nn) && isreal(Nn) && isfinite(Nn) && ...
           isscalar(Nn) && Nn > 0 && Nn == round(Nn), ...
        'buildDOFMap:mesh.nNodes must be a positive integer.');

    assert(isnumeric(Ne) && isreal(Ne) && isfinite(Ne) && ...
           isscalar(Ne) && Ne > 0 && Ne == round(Ne), ...
        'buildDOFMap:mesh.nElem must be a positive integer.');

    assert(isnumeric(mesh.connect) && isreal(mesh.connect) && ...
           all(isfinite(mesh.connect(:))) && ...
           isequal(size(mesh.connect), [Ne, 4]), ...
        'buildDOFMap:mesh.connect must be a finite N_e x 4 numeric array.');

    conn = mesh.connect;

    assert(all(conn(:) >= 1 & conn(:) <= Nn & conn(:) == round(conn(:))), ...
        'buildDOFMap:mesh.connect must contain integer node indices in [1,N_n].');

    % ------------------------------------------------------------------
    % Global DOF map ID(local-DOF, component, node).
    % ------------------------------------------------------------------
    ID = zeros(4, 2, Nn);

    for n = 1:Nn
        ID(:, 1, n) = 4*(n - 1) + (1:4).';
        ID(:, 2, n) = 4*Nn + 4*(n - 1) + (1:4).';
    end

    nDOF = 8*Nn;

    % ------------------------------------------------------------------
    % Element-to-global DOF map.
    % ------------------------------------------------------------------
    elemDOF = zeros(Ne, 32);

    for e = 1:Ne
        for a = 1:4
            nd = conn(e, a);

            elemDOF(e, 4*(a - 1) + (1:4)) = ID(:, 1, nd).';
            elemDOF(e, 16 + 4*(a - 1) + (1:4)) = ID(:, 2, nd).';
        end
    end

    % ------------------------------------------------------------------
    % Pack output.
    % ------------------------------------------------------------------
    dof = struct();
    dof.nDOF = nDOF;
    dof.ID = ID;
    dof.elemDOF = elemDOF;
    dof.freeDOF = [];
    dof.essDOF = [];
    dof.essVals = [];

    % ------------------------------------------------------------------
    % Internal verification is executed only by the outermost call.
    % The inner one-element call therefore cannot recursively re-enter
    % this verification block.
    % ------------------------------------------------------------------
    if runSelfTest
        verifyDOFMap(dof, conn, Nn, Ne);

        meshOne = struct('nNodes', 4, 'nElem', 1, ...
                         'connect', [1, 2, 3, 4]);
        dofOne = buildDOFMap(meshOne);

        assert(isequal(dofOne.elemDOF(1, :), 1:32), ...
            ['buildDOFMap:single-element CCW mesh [1 2 3 4] must ' ...
             'yield elemDOF = 1:32.']);

        assert(dofOne.nDOF == 32, ...
            'buildDOFMap:single-element mesh must have nDOF = 32.');
    end

catch ME
    % Only the outer owner resets the guard.
    if runSelfTest
        SELFTEST_ACTIVE = false;
    end
    rethrow(ME);
end

% Only the outer owner resets the guard.  An inner call must not reset it.
if runSelfTest
    SELFTEST_ACTIVE = false;
end

end

% =====================================================================
% Local verification helper.
% =====================================================================
function verifyDOFMap(dof, conn, Nn, Ne)

assert(isequal(size(dof.ID), [4, 2, Nn]), ...
    'buildDOFMap:ID must be 4 x 2 x N_n.');

assert(isequal(size(dof.elemDOF), [Ne, 32]), ...
    'buildDOFMap:elemDOF must be N_e x 32.');

assert(isscalar(dof.nDOF) && dof.nDOF == 8*Nn, ...
    'buildDOFMap:nDOF must equal 8*N_n.');

allIdx = dof.ID(:);

assert(all(allIdx >= 1) && all(allIdx <= dof.nDOF), ...
    'buildDOFMap:ID contains out-of-range entries.');

assert(numel(unique(allIdx)) == dof.nDOF, ...
    'buildDOFMap:ID is not a bijection onto 1..nDOF.');

for e = 1:Ne
    eDofs = dof.elemDOF(e, :);

    assert(numel(unique(eDofs)) == 32, ...
        'buildDOFMap:element %d has repeated DOFs in elemDOF.', e);

    allowed = dof.ID(:, :, conn(e, :));
    allowed = allowed(:);

    assert(all(ismember(eDofs(:), allowed)), ...
        ['buildDOFMap:element %d elemDOF references DOFs outside ' ...
         'its four corner nodes.'], e);

    for a = 1:4
        nd = conn(e, a);

        assert(isequal(eDofs(4*(a - 1) + (1:4)), dof.ID(:, 1, nd).'), ...
            'buildDOFMap:u1 block mismatch at element %d local node %d.', e, a);

        assert(isequal(eDofs(16 + 4*(a - 1) + (1:4)), dof.ID(:, 2, nd).'), ...
            'buildDOFMap:u2 block mismatch at element %d local node %d.', e, a);
    end
end

assert(all(dof.elemDOF(:) >= 1) && all(dof.elemDOF(:) <= dof.nDOF), ...
    'buildDOFMap:elemDOF contains out-of-range indices.');

assert(dof.ID(1, 1, 1) == 1 && dof.ID(2, 1, 1) == 2 && ...
       dof.ID(3, 1, 1) == 3 && dof.ID(4, 1, 1) == 4, ...
    ['buildDOFMap:u1 node-1 DOFs must follow ' ...
     '[u,u1,u2,u12] = [1,2,3,4].']);

assert(dof.ID(1, 2, 1) == 4*Nn + 1 && ...
       dof.ID(4, 2, 1) == 4*Nn + 4, ...
    'buildDOFMap:u2 node-1 DOFs must start at 4*N_n+1.');

end
