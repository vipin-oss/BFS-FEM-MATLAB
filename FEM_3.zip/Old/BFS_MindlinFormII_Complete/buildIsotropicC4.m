function C4 = buildIsotropicC4(lambda, mu)
%BUILDISOTROPICC4  Isotropic 4th-order elasticity tensor in plane strain.
%
%   C4 = BUILDISOTROPICC4(lambda, mu)
%
%   Returns the in-plane sub-block of the classical isotropic
%   4th-order elasticity tensor
%
%       C_{abcd} = lambda * delta_{ab} * delta_{cd}
%                + mu    * (delta_{ac}*delta_{bd}
%                         + delta_{ad}*delta_{bc})
%
%   corresponding to eq. (sec2_isotropic_C_tensor) of Sec. 2.
%
%   The tensor is stored as a 2 x 2 x 2 x 2 MATLAB array indexed over
%   the in-plane coordinates (a,b,c,d) in {1,2}.  Using the 3D Lame
%   constants directly in this 2D sub-block is the correct
%   plane-strain Saint-Venant--Kirchhoff implementation (assumption A8).
%
%   Inputs:
%     lambda    First Lame constant                            [Pa]
%     mu        Shear modulus                                 [Pa]
%
%   Output:
%     C4        2 x 2 x 2 x 2 array satisfying the minor symmetries
%               C_{abcd}=C_{bacd}=C_{abdc} and the major symmetry
%               C_{abcd}=C_{cdab}.
%
%   Equation mapping (frozen Sections 1--9):
%     C4  <-  eq. (sec2_isotropic_C_tensor); used by
%             elemStiffnessMatClassical.m via S = C:E.

assert(isscalar(lambda) && isfinite(lambda), ...
    'buildIsotropicC4: lambda must be a finite scalar.');

assert(isscalar(mu) && isfinite(mu) && mu > 0, ...
    'buildIsotropicC4: mu must be a positive finite scalar.');

% Kronecker delta in the in-plane indices.
delta = eye(2);

% Directly assemble C4 from the isotropic closed form.  The double
% loop is small (2^4 = 16 entries) and keeps the mapping to the
% frozen tensor formula transparent.
C4 = zeros(2,2,2,2);

for a = 1:2
    for b = 1:2
        for c = 1:2
            for d = 1:2
                C4(a,b,c,d) = lambda * delta(a,b)*delta(c,d) ...
                           + mu    *(delta(a,c)*delta(b,d) ...
                                   + delta(a,d)*delta(b,c));
            end
        end
    end
end

% ----------------------------------------------------------------------
% Internal symmetry verification (minor + major).
% ----------------------------------------------------------------------
tol = 1e-12;
for a = 1:2
    for b = 1:2
        for c = 1:2
            for d = 1:2
                v = C4(a,b,c,d);
                assert(abs(v - C4(b,a,c,d)) < tol*max(1,abs(v)), ...
                    'buildIsotropicC4:fails (a,b) minor symmetry.');
                assert(abs(v - C4(a,b,d,c)) < tol*max(1,abs(v)), ...
                    'buildIsotropicC4:fails (c,d) minor symmetry.');
                assert(abs(v - C4(c,d,a,b)) < tol*max(1,abs(v)), ...
                    'buildIsotropicC4:fails major symmetry.');
            end
        end
    end
end

end
