function D6 = buildIsotropicD6(a1, a2, a3, a4, a5)
%BUILDISOTROPICD6  Plane-strain isotropic 6th-order Mindlin Form-II
%                  gradient modulus tensor D_{IJK PQR}.
%
%   D6 = BUILDISOTROPICD6(a1, a2, a3, a4, a5)
%
% ----------------------------------------------------------------------
% Physical role
% ----------------------------------------------------------------------
% The sixth-order tensor D is the Hessian of the Mindlin Form-II
% gradient-elastic energy density
%
%   psi_g = a1 * G_{Abb} G_{Acc}                                       (T1)
%         + a2 * G_{AAc} G_{cBB}                                       (T2)
%         + a3 * G_{AAc} G_{BBc}                                       (T3)
%         + a4 * G_{ABC} G_{ABC}                                       (T4)
%         + a5 * G_{ABC} G_{CBA}                                       (T5)
%
% with respect to the (symmetric) Green--Lagrange strain gradient
% G_{IJK} = E_{IJ,K} = (1/2)(F^T F - I)_{IJ,K}, in the sense
%
%   psi_g = (1/2) D_{IJK PQR} G_{IJK} G_{PQR},
%
% and the gradient double-stress is
%
%   Sigma_{IJK} = d psi_g / d G_{IJK} = D_{IJK PQR} G_{PQR}.
%
% The five isotropic parameters a1..a5 have units [Pa m^2] and control
% distinct isotropic gradient stiffening modes:
%   a1  --- squared trace of the vector-gradient-of-dilatation
%           (G_{Abb} = (tr G_{\cdot b b})_A: "dilatational gradient
%           coupling");
%   a2  --- cross coupling between the two vectorial traces
%           G_{AAc} ~ (div u)_{,c}  and G_{cBB} ~ G_{cBB};
%   a3  --- squared trace-like vector  G_{AAc}
%           ("stretch-gradient coupling");
%   a4  --- full squared Frobenius norm of G (analogue of the
%           classical shear term mu |E|^2 in the gradient sector);
%   a5  --- "swap" invariant coupling the first and last index of G
%           (genuine Form-II cross term; vanishes when Form-I
%           simplifications are imposed).
% The internal length scale is derived from these constants as
%   ell = sqrt( bar_a / mu ),  bar_a = (a1+...+a5)/5
% (see computeLengthScale.m).
%
% ----------------------------------------------------------------------
% Dimensions, index ordering, and storage convention
% ----------------------------------------------------------------------
% The formulation is plane strain (assumption A8).  All six indices of
% D_{IJK PQR} run over the in-plane coordinates {1,2}.  The tensor is
% stored as a 6-dimensional MATLAB array
%
%   D6(I, J, K, P, Q, R)  <->  D_{I J K P Q R}
%
% with index triplets (I,J,K) and (P,Q,R) corresponding to the two
% contracted strain-gradient tensors G_{IJK} and G_{PQR}.  The middle
% index K (resp. R) is the partial-derivative index in G = grad_0 E.
%
% ----------------------------------------------------------------------
% Required symmetries (frozen Sec. 2, eq. sec2_D_symmetries)
% ----------------------------------------------------------------------
%   * Minor symmetry in (I,J):  D_{IJK PQR} = D_{JIK PQR}
%     (inherited from G_{IJK}=G_{JIK} because E_{IJ}=E_{JI});
%   * Minor symmetry in (P,Q):  D_{IJK PQR} = D_{IJK QPR}
%     (same reason on the second factor);
%   * Major symmetry:           D_{IJK PQR} = D_{PQR IJK}
%     (hyperelasticity: D = d psi_g /d G d G is a Hessian and hence
%     symmetric as a bilinear form).
% These are enforced analytically, not by numerical filtering.
%
% ----------------------------------------------------------------------
% Construction
% ----------------------------------------------------------------------
% The tensor is assembled from outer products of Kronecker deltas
% obtained by twice differentiating each of the five invariants (T1)-
% (T5) with respect to G (treating the components G_{IJK} as
% independent on the full tensor space), then projected onto the
% (I,J)- and (P,Q)-symmetric subspace by the (1/4) four-term
% symmetriser, and finally major-symmetrised by the (1/2) two-term
% symmetriser.  The resulting D6 acts identically to the analytic
% Hessian on symmetric G, is fully symmetric, and reproduces psi_g
% exactly via (1/2) D6 : G : G.
%
% Equation mapping (frozen Sections 1--9):
%   psi_g, invariants             -- eq. (sec2_gradient_energy_invariants)
%   D Hessian of psi_g            -- eq. (sec2_complete_energy_tensor)
%   D minor + major symmetries    -- eq. (sec2_D_symmetries)
%   Sigma = D6 : G                -- used in sec4 / s7:K_mat_gr
%   (1/2) D6 : G : G              -- energy round-trip verification
%
% 2022 benchmark compatibility: with the 2D kinematics of Sec. 2 (A8)
% and the same five constants a1..a5 used by Torabi--Niiranen (2022)
% for the small-strain Mindlin Form-II benchmark, this routine returns
% the in-plane sub-block of the exact isotropic sixth-order tensor,
% guaranteeing exact recovery of the small-strain benchmark in the
% infinitesimal-displacement limit (Sec. 7, eq. s7:K_2022).
%
% See also BUILDMATERIALSTRUCT, BUILDISOTROPICC4, COMPUTELENGTHSCALE.

% ======================================================================
% 1. Input validation
% ======================================================================
assert(isscalar(a1) && isnumeric(a1) && isfinite(a1), ...
    'buildIsotropicD6:a1 must be a finite numeric scalar.');
assert(isscalar(a2) && isnumeric(a2) && isfinite(a2), ...
    'buildIsotropicD6:a2 must be a finite numeric scalar.');
assert(isscalar(a3) && isnumeric(a3) && isfinite(a3), ...
    'buildIsotropicD6:a3 must be a finite numeric scalar.');
assert(isscalar(a4) && isnumeric(a4) && isfinite(a4), ...
    'buildIsotropicD6:a4 must be a finite numeric scalar.');
assert(isscalar(a5) && isnumeric(a5) && isfinite(a5), ...
    'buildIsotropicD6:a5 must be a finite numeric scalar.');
% ======================================================================
% 2. Kronecker-delta table in the in-plane indices {1,2}.
% ======================================================================
delta = eye(2);                          % delta(i,j) = 1 iff i==j

% ======================================================================
% 3. Assemble the raw (un-symmetrised) Hessian contributions one
%    invariant at a time.  Each Tm is a 2x2x2x2x2x2 array; they are
%    kept separate so the mapping to (T1)-(T5) is explicit.
%
% Per the second variation of each invariant on the full tensor space,
% the raw (pre-projection) contributions are:
%   T1:  2 a1  * delta_{JK} delta_{QR} delta_{IP}
%   T2:    a2  * (delta_{IJ} delta_{KP} delta_{QR}
%               + delta_{JK} delta_{PQ} delta_{IR})         [two cross
%               contributions, verified by symbolic Hessian]
%   T3:  2 a3  * delta_{IJ} delta_{PQ} delta_{KR}
%   T4:  2 a4  * delta_{IP} delta_{JQ} delta_{KR}
%   T5:  2 a5  * delta_{KP} delta_{JQ} delta_{IR}
% The factor 2 comes from d^2/dG^2 of the quadratic invariants.
% ======================================================================

T1 = zeros(2,2,2,2,2,2);
T2 = zeros(2,2,2,2,2,2);
T3 = zeros(2,2,2,2,2,2);
T4 = zeros(2,2,2,2,2,2);
T5 = zeros(2,2,2,2,2,2);

for I = 1:2
    for J = 1:2
        for K = 1:2
            for P = 1:2
                for Q = 1:2
                    for R = 1:2
                        T1(I,J,K,P,Q,R) = 2*a1 * delta(J,K)*delta(Q,R)*delta(I,P);

                        T2(I,J,K,P,Q,R) = a2*( delta(I,J)*delta(K,P)*delta(Q,R) ...
                                             + delta(J,K)*delta(P,Q)*delta(I,R));

                        T3(I,J,K,P,Q,R) = 2*a3 * delta(I,J)*delta(P,Q)*delta(K,R);

                        T4(I,J,K,P,Q,R) = 2*a4 * delta(I,P)*delta(J,Q)*delta(K,R);

                        T5(I,J,K,P,Q,R) = 2*a5 * delta(K,P)*delta(J,Q)*delta(I,R);
                    end
                end
            end
        end
    end
end

% Total raw Hessian (additive superposition of the five invariants).
Draw = T1 + T2 + T3 + T4 + T5;

% ======================================================================
% 4. Enforce the two minor symmetries analytically.
%
% Because G satisfies G_{IJK}=G_{JIK} (and G_{PQR}=G_{QPR}) exactly at
% every point in the discretisation, the action of D on any admissible
% G is invariant under swapping I<->J or P<->Q.  The unique projector
% onto the minor-symmetric subspace is the four-term average
%
%   S_min[D]_{IJKPQR} = (1/4) [ D_{IJKPQR}
%                             + D_{JIKPQR}
%                             + D_{IJKQPR}
%                             + D_{JIKQPR} ].
%
% After this projection, S_min[D] satisfies BOTH minor symmetries
% exactly, while leaving the quadratic form unchanged on any G that
% already satisfies G_{IJK}=G_{JIK}.
% ======================================================================
Dmin = zeros(2,2,2,2,2,2);
for I = 1:2
    for J = 1:2
        for K = 1:2
            for P = 1:2
                for Q = 1:2
                    for R = 1:2
                        Dmin(I,J,K,P,Q,R) = 0.25 * ( ...
                              Draw(I,J,K,P,Q,R) ...
                            + Draw(J,I,K,P,Q,R) ...
                            + Draw(I,J,K,Q,P,R) ...
                            + Draw(J,I,K,Q,P,R) );
                    end
                end
            end
        end
    end
end

% ======================================================================
% 5. Enforce major symmetry D_{IJKPQR}=D_{PQRIJK} analytically.
%
% Hyperelasticity requires that D be symmetric as a bilinear form.
% The exact projector is
%
%   S_maj[D]_{IJKPQR} = (1/2) [ D_{IJKPQR} + D_{PQRIJK} ].
%
% This preserves both minor symmetries (if the input already satisfies
% them, the output does too) and leaves psi_g unchanged because
% swapping the two triplets merely relabels the dummy indices of the
% double contraction with G (both G's live in the same symmetric
% subspace).
% ======================================================================
D6 = zeros(2,2,2,2,2,2);
for I = 1:2
    for J = 1:2
        for K = 1:2
            for P = 1:2
                for Q = 1:2
                    for R = 1:2
                        D6(I,J,K,P,Q,R) = 0.5 * ( ...
                              Dmin(I,J,K,P,Q,R) ...
                            + Dmin(P,Q,R,I,J,K) );
                    end
                end
            end
        end
    end
end

% ======================================================================
% 6. Internal consistency checks.
% ======================================================================

% 6a. Output dimensions.
assert(ndims(D6) == 6 && isequal(size(D6), [2 2 2 2 2 2]), ...
    'buildIsotropicD6:D6 must be a 2x2x2x2x2x2 array in plane strain.');

% 6b. Symmetry checks.
tol = 1e-12;
for I = 1:2
    for J = 1:2
        for K = 1:2
            for P = 1:2
                for Q = 1:2
                    for R = 1:2
                        v = D6(I,J,K,P,Q,R);
                        scl = max(1.0, abs(v));
                        assert(abs(v - D6(J,I,K,P,Q,R)) < tol*scl, ...
                            'buildIsotropicD6:fails minor (I,J) symmetry.');
                        assert(abs(v - D6(I,J,K,Q,P,R)) < tol*scl, ...
                            'buildIsotropicD6:fails minor (P,Q) symmetry.');
                        assert(abs(v - D6(P,Q,R,I,J,K)) < tol*scl, ...
                            'buildIsotropicD6:fails major symmetry.');
                    end
                end
            end
        end
    end
end

% 6c. Projection idempotence: re-applying the projectors must be a
%     no-op (confirms D6 already lies in the symmetric subspace).
Dcheck = D6;  % alias
for I = 1:2
    for J = 1:2
        for K = 1:2
            for P = 1:2
                for Q = 1:2
                    for R = 1:2
                        v  = Dcheck(I,J,K,P,Q,R);
                        vm = 0.25*(Dcheck(I,J,K,P,Q,R) + Dcheck(J,I,K,P,Q,R) ...
                                 + Dcheck(I,J,K,Q,P,R) + Dcheck(J,I,K,Q,P,R));
                        assert(abs(v - vm) < tol*max(1,abs(v)), ...
                            'buildIsotropicD6:minor projector not idempotent.');
                        vM = 0.5*(Dcheck(I,J,K,P,Q,R) + Dcheck(P,Q,R,I,J,K));
                        assert(abs(v - vM) < tol*max(1,abs(v)), ...
                            'buildIsotropicD6:major projector not idempotent.');
                    end
                end
            end
        end
    end
end

% 6d. Energy round-trip on a random symmetric G.
%     Build a G that satisfies G_{IJK}=G_{JIK}, compute psi_g both from
%     the five invariants and from (1/2) D6:G:G and check equality.
oldRng = rng;
rng(1);
G = zeros(2,2,2);
for I = 1:2
    for J = I:2
        G(I,J,:) = randn(1,2);
        G(J,I,:) = G(I,J,:);
    end
end

w1   = traceABB(G);               % G_{I b b}
w2   = traceAAB(G);               % G_{a a K}
vbb  = w1;               % G_{K B B} (c->K index)
Gsq  = 0;
Gprm = 0;
for I = 1:2
    for J = 1:2
        for K = 1:2
            Gsq  = Gsq  + G(I,J,K)*G(I,J,K);
            Gprm = Gprm + G(I,J,K)*G(K,J,I);
        end
    end
end
psiInv = a1 * dot(w1,w1) ...
       + a2 * dot(w2,vbb) ...
       + a3 * dot(w2,w2) ...
       + a4 * Gsq ...
       + a5 * Gprm;

psiD = 0;
for I = 1:2
    for J = 1:2
        for K = 1:2
            for P = 1:2
                for Q = 1:2
                    for R = 1:2
                        psiD = psiD + 0.5*D6(I,J,K,P,Q,R)*G(I,J,K)*G(P,Q,R);
                    end
                end
            end
        end
    end
end
assert(abs(psiD - psiInv) < 1e-10*(1 + abs(psiInv)), ...
    ['buildIsotropicD6:invariant round-trip failed; ' ...
     '(1/2) D6:G:G does not reproduce the a1..a5 energy form.']);

% 6e. Sigma = D6:G symmetry check:  Sigma_{IJK} = Sigma_{JIK}  for any
%     admissible (symmetric) G.
Sigma = zeros(2,2,2);
for I = 1:2
    for J = 1:2
        for K = 1:2
            s = 0;
            for P = 1:2
                for Q = 1:2
                    for R = 1:2
                        s = s + D6(I,J,K,P,Q,R)*G(P,Q,R);
                    end
                end
            end
            Sigma(I,J,K) = s;
        end
    end
end
for I = 1:2
    for J = 1:2
        for K = 1:2
            assert(abs(Sigma(I,J,K) - Sigma(J,I,K)) < tol*max(1,abs(Sigma(I,J,K))), ...
                'buildIsotropicD6: Sigma = D6:G fails Sigma_{IJK}=Sigma_{JIK}.');
        end
    end
end

% 6f. Multi-sample energy round-trip (more than one random G) for
%     statistical robustness without relying on a single sample.
for trial = 1:4
    Gt = zeros(2,2,2);
    for I = 1:2
        for J = I:2
            Gt(I,J,:) = randn(1,2);
            Gt(J,I,:) = Gt(I,J,:);
        end
    end
    w1t  = traceABB(Gt);
    w2t  = traceAAB(Gt);
    vbt  = w1t;
    Gsqt = sum(Gt(:).^2);
    Gprmt = 0;
    for I = 1:2
        for J = 1:2
            for K = 1:2
                Gprmt = Gprmt + Gt(I,J,K)*Gt(K,J,I);
            end
        end
    end
    pI = a1*dot(w1t,w1t) + a2*dot(w2t,vbt) + a3*dot(w2t,w2t) ...
        + a4*Gsqt + a5*Gprmt;
    pD = 0;
    for I = 1:2
        for J = 1:2
            for K = 1:2
                for P = 1:2
                    for Q = 1:2
                        for R = 1:2
                            pD = pD + 0.5*D6(I,J,K,P,Q,R)*Gt(I,J,K)*Gt(P,Q,R);
                        end
                    end
                end
            end
        end
    end
    assert(abs(pD-pI) < 1e-10*(1+abs(pI)), ...
        'buildIsotropicD6:multi-trial invariant round-trip failed.');
end

% ======================================================================
% Local helpers (self-contained so buildIsotropicD6.m is independently
% callable during unit testing; duplicates of identically-named
% helpers in buildMaterialStruct.m are intentional per the no-globals,
% no-shared-helpers policy of the project architecture).
%
%   traceABB(G) -> v(I) = sum_b G_{I,b,b}   (vector over first index)
%   traceAAB(G) -> w(K) = sum_a G_{a,a,K}   (vector over last  index)
% ======================================================================

    function v = traceABB(G)
        v = zeros(2,1);
        for II = 1:2
            s = 0;
            for BB = 1:2
                s = s + G(II,BB,BB);
            end
            v(II) = s;
        end
    end

    function w = traceAAB(G)
        w = zeros(2,1);
        for KK = 1:2
            s = 0;
            for AA = 1:2
                s = s + G(AA,AA,KK);
            end
            w(KK) = s;
        end
    end

rng(oldRng);

end
