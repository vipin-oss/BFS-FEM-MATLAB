function mat = buildMaterialStruct(E, nu, a1, a2, a3, a4, a5, rho0, model, planeStrain)
%BUILDMATERIALSTRUCT  Construct the material property structure.
%
%   mat = BUILDMATERIALSTRUCT(E, nu, a1, a2, a3, a4, a5, rho0)
%   mat = BUILDMATERIALSTRUCT(E, nu, a1, a2, a3, a4, a5, rho0, model, planeStrain)
%
%   Assembles the material structure consumed by every downstream module
%   (mesh generation, element integration, constitutive update, solver):
%     * classical isotropic Saint-Venant--Kirchhoff part (Sec. 2,
%       eqs. (sec2_isotropic_C_tensor)--(sec2_svk_energy));
%     * complete five-parameter isotropic Mindlin Form-II gradient
%       part (Sec. 2, eqs. (sec2_D_symmetries),
%       (sec2_gradient_energy_invariants));
%     * internal length scale (Sec. 8, eq. (s8:length_scale)).
%
%   The routine is plane-strain by default, consistent with assumption
%   A8 of Sec. 2; C4 and D6 are returned as in-plane sub-blocks indexed
%   1,2.  The 3D Lame constants are used without modification (no
%   plane-stress substitution), which is the correct SVK plane-strain
%   formulation.
%
%   Inputs  (all SI):
%     E           Young's modulus                                   [Pa]
%     nu          Poisson's ratio                                   [-]
%     a1..a5      Five isotropic Mindlin Form-II gradient           [Pa m^2]
%                 constants (eq. sec2_gradient_energy_invariants)
%     rho0        Reference mass density                            [kg m^-3]
%     model       (optional) constitutive model string; defaults to
%                 'SVK_MindlinFormII'
%     planeStrain (optional) logical; defaults to true
%
%   Output:
%     mat         struct with fields
%                   E, nu, lambda, mu, a1..a5, C4, D6, ell, rho0,
%                   model, planeStrain
%
%   Equation mapping (frozen Sections 1--9):
%     lambda, mu                <- sec2_isotropic_C_tensor
%     C4_{ABCD}                 <- sec2_isotropic_C_tensor
%     D6_{ABCPQR}               <- sec2_D_symmetries,
%                                  sec2_gradient_energy_invariants
%     ell = sqrt(bar_a / mu)    <- s8:length_scale
%
%   This routine performs no element-level or pointwise constitutive
%   update; that is the responsibility of constitutive/*.m.

% ----------------------------------------------------------------------
% Handle optional arguments and defaults.
% ----------------------------------------------------------------------
if nargin <  9 || isempty(model),       model       = 'SVK_MindlinFormII'; end
if nargin < 10 || isempty(planeStrain), planeStrain = true;               end

% ----------------------------------------------------------------------
% Input validation (physical admissibility).
% ----------------------------------------------------------------------
validateScalarPositive(E,    'E');
validateScalar(nu,           'nu',  @(x) x > -1 && x < 0.5,   'in (-1, 0.5)');
validateScalarNonNeg(rho0,   'rho0');
validateScalar(a1,'a1');
validateScalar(a2,'a2');
validateScalar(a3,'a3');
validateScalar(a4,'a4');
validateScalar(a5,'a5');

assert(islogical(planeStrain), ...
    'buildMaterialStruct:planeStrain must be logical.');
assert(planeStrain, ...
    'buildMaterialStruct:plane-stress (A9) reserved for future work.');

% ----------------------------------------------------------------------
% Lame constants (plane strain uses the 3D Lame constants directly).
% ----------------------------------------------------------------------
lambda = E * nu  / ((1 + nu) * (1 - 2*nu));
mu     = E / (2 * (1 + nu));
assert(mu > 0 && (3*lambda + 2*mu) > 0, ...
    'buildMaterialStruct:Material stability conditions violated.');

% ----------------------------------------------------------------------
% Fourth-order isotropic elasticity tensor C4
%   C_{abcd} = lambda delta_{ab} delta_{cd} + mu (delta_{ac}delta_{bd}
%                                                   + delta_{ad}delta_{bc})
% 2x2x2x2 in plane strain.
% ----------------------------------------------------------------------
C4 = buildIsotropicC4(lambda, mu);

% ----------------------------------------------------------------------
% Sixth-order isotropic gradient modulus tensor D6 from a1..a5.
% ----------------------------------------------------------------------
D6 = buildIsotropicD6(a1, a2, a3, a4, a5);
assert(isequal(size(C4),[2 2 2 2]), ...
    'buildMaterialStruct: C4 has incorrect dimensions.');

assert(isequal(size(D6),[2 2 2 2 2 2]), ...
    'buildMaterialStruct: D6 has incorrect dimensions.');

% ----------------------------------------------------------------------
% Internal length scale ell = sqrt(bar_a/mu).
% ----------------------------------------------------------------------
ell = computeLengthScale(a1, a2, a3, a4, a5, mu);

% ----------------------------------------------------------------------
% Pack the material structure.
% ----------------------------------------------------------------------
mat.E           = E;
mat.nu          = nu;
mat.lambda      = lambda;
mat.mu          = mu;
mat.a1          = a1;
mat.a2          = a2;
mat.a3          = a3;
mat.a4          = a4;
mat.a5          = a5;
mat.C4          = C4;
mat.D6          = D6;
mat.ell         = ell;
mat.rho0        = rho0;
mat.model       = model;
mat.planeStrain = planeStrain;

% ----------------------------------------------------------------------
% Internal verification.
%   (ii)  C4 minor/major symmetries.
%   (iii) D6 minor(IJ), minor(PQ), major symmetries.
%   (iv)  Energy round-trip: (1/2) D6:G:G must reproduce the
%         a1..a5 invariant form on a random symmetric G.
% ----------------------------------------------------------------------
tol = 1e-12;

% C4 symmetries
for aa = 1:2
    for bb = 1:2
        for cc = 1:2
            for dd = 1:2
                v = C4(aa,bb,cc,dd);
                assert(abs(v - C4(bb,aa,cc,dd)) < tol*max(1,abs(v)), ...
                    'buildMaterialStruct:C4 fails minor(a,b) symmetry.');
                assert(abs(v - C4(aa,bb,dd,cc)) < tol*max(1,abs(v)), ...
                    'buildMaterialStruct:C4 fails minor(c,d) symmetry.');
                assert(abs(v - C4(cc,dd,aa,bb)) < tol*max(1,abs(v)), ...
                    'buildMaterialStruct:C4 fails major symmetry.');
            end
        end
    end
end

% D6 symmetries
for aa = 1:2
    for bb = 1:2
        for cc = 1:2
            for pp = 1:2
                for qq = 1:2
                    for rr = 1:2
                        v = D6(aa,bb,cc,pp,qq,rr);
                        assert(abs(v - D6(bb,aa,cc,pp,qq,rr)) < tol*max(1,abs(v)), ...
                            'buildMaterialStruct:D6 fails minor(a,b) symmetry.');
                        assert(abs(v - D6(aa,bb,cc,qq,pp,rr)) < tol*max(1,abs(v)), ...
                            'buildMaterialStruct:D6 fails minor(p,q) symmetry.');
                        assert(abs(v - D6(pp,qq,rr,aa,bb,cc)) < tol*max(1,abs(v)), ...
                            'buildMaterialStruct:D6 fails major symmetry.');
                    end
                end
            end
        end
    end
end

% Energy round-trip: build a random symmetric G (G_{abc}=G_{bac}).
oldRng = rng;

try
    rng(0);
    
    G = zeros(2,2,2);
for aa = 1:2
    for bb = aa:2
        for cc = 1:2
            vv = randn;
            G(aa,bb,cc) = vv;
            G(bb,aa,cc) = vv;
        end
    end
end

% psi_g from a1..a5 invariants (Sec. 2, eq. sec2_gradient_energy_invariants).
w1 = traceABB(G);                                            % G_{abb}
w2 = traceAAB(G);                                            % G_{aac}
vbb = traceABB(G);                                           % G_{cbb}
GSq = 0;
GPrm = 0;
for aa = 1:2
    for bb = 1:2
        for cc = 1:2
            GSq  = GSq  + G(aa,bb,cc)*G(aa,bb,cc);
            GPrm = GPrm + G(aa,bb,cc)*G(cc,bb,aa);
        end
    end
end
psiInv = a1*sum(w1(:).*w1(:)) ...
       + a2*(w2(:).'*vbb(:)) ...
       + a3*sum(w2(:).*w2(:)) ...
       + a4*GSq ...
       + a5*GPrm;

% psi_g from (1/2) D6 : G : G.
psiD = 0;
for aa = 1:2
    for bb = 1:2
        for cc = 1:2
            for pp = 1:2
                for qq = 1:2
                    for rr = 1:2
                        psiD = psiD + 0.5*D6(aa,bb,cc,pp,qq,rr)*G(aa,bb,cc)*G(pp,qq,rr);
                    end
                end
            end
        end
    end
end
assert(abs(psiD - psiInv) < 1e-10*(1 + abs(psiInv)), ...
    ['buildMaterialStruct:D6 invariant round-trip failed; ' ...
     'D6 does not reproduce the a1..a5 energy form.']);
rng(oldRng);

catch ME
    rng(oldRng);
    rethrow(ME);
end

end

% ----------------------------------------------------------------------
% Local validation helpers.
% ----------------------------------------------------------------------
function validateScalar(v, name, cond, condStr)
    if nargin < 3
        cond = @(x) true;
        condStr = 'scalar';
    end
    assert(isscalar(v) && cond(v), ...
        'buildMaterialStruct:%s must be %s.', name, condStr);
end
function validateScalarPositive(v, name)
    assert(isscalar(v) && v > 0, ...
        'buildMaterialStruct:%s must be a positive scalar.', name);
end
function validateScalarNonNeg(v, name)
    assert(isscalar(v) && v >= 0, ...
        'buildMaterialStruct:%s must be a non-negative scalar.', name);
end

% ----------------------------------------------------------------------
% Local trace helpers for the invariant round-trip (self-contained).
%   traceABB(G) -> v(a) = G_{a,b,b}
%   traceAAB(G) -> w(c) = G_{a,a,c}
% ----------------------------------------------------------------------
function v = traceABB(G)
    v = zeros(2,1);
    for aa = 1:2
        s = 0;
        for bb = 1:2
            s = s + G(aa,bb,bb);
        end
        v(aa) = s;
    end
end
function w = traceAAB(G)
    w = zeros(2,1);
    for cc = 1:2
        s = 0;
        for aa = 1:2
            s = s + G(aa,aa,cc);
        end
        w(cc) = s;
    end
end
