function constraints = buildPeriodicConstraints2022(mesh, dof, caseName, prescribed)
%BUILDPERIODICCONSTRAINTS2022 Benchmark-only periodic/MPC constraints.
%
% Builds D = T*q + lambda*Dbar for the 2022 simple-shear benchmark.
% Left/right matching BFS DOFs are tied periodically; benchmark-specific
% prescribed values are imposed through Dbar.  No frozen continuum or
% element formulation is altered.
%
% Inputs
%   mesh.X, dof.ID : structured rectangular BFS mesh/DOF map
%   caseName       : 'case1' or 'case2'
%   prescribed     : struct with fields uhat (Case 1) and H
%
% Output
%   constraints.T      nDOF x nIndependent sparse transformation
%   constraints.Dbar  nDOF x 1 unit-load prescribed vector
%   constraints.nq     number of independent unknowns

caseName = lower(char(caseName));
assert(any(strcmp(caseName, {'case1', 'case2'})), ...
    'buildPeriodicConstraints2022:caseName must be case1 or case2.');
assert(isfield(prescribed, 'H') && prescribed.H > 0, ...
    'buildPeriodicConstraints2022:prescribed.H must be positive.');
if strcmp(caseName, 'case1')
    assert(isfield(prescribed, 'uhat'), ...
        'buildPeriodicConstraints2022:Case 1 requires prescribed.uhat.');
end

nDOF = dof.nDOF;
X = mesh.X;
tol = 1e-10*max(1, max(abs(X(:))));
xMin = min(X(:, 1));
xMax = max(X(:, 1));
yMin = min(X(:, 2));
yMax = max(X(:, 2));

leftNodes = find(abs(X(:, 1) - xMin) <= tol);
rightNodes = find(abs(X(:, 1) - xMax) <= tol);
[~, leftOrder] = sort(X(leftNodes, 2));
[~, rightOrder] = sort(X(rightNodes, 2));
leftNodes = leftNodes(leftOrder);
rightNodes = rightNodes(rightOrder);

assert(numel(leftNodes) == numel(rightNodes) && ...
       max(abs(X(leftNodes, 2) - X(rightNodes, 2))) <= tol, ...
    'buildPeriodicConstraints2022:left/right nodes cannot be paired periodically.');

% Union-find parent array: each periodic DOF pair becomes one equivalence
% class.  All eight BFS DOFs at corresponding left/right nodes are tied.
parent = 1:nDOF;
for p = 1:numel(leftNodes)
    for comp = 1:2
        for ld = 1:4
            gLeft = dof.ID(ld, comp, leftNodes(p));
            gRight = dof.ID(ld, comp, rightNodes(p));
            parent = unionDOF(parent, gLeft, gRight);
        end
    end
end

for g = 1:nDOF
    [parent, ~] = findRoot(parent, g);
end

% fixedValue(root) is the unit-load prescribed value.  NaN means the
% periodic equivalence class remains independent.
fixedValue = nan(nDOF, 1);

% The semi-analytical benchmark uses uy=0.  Constrain all u2 BFS DOFs so
% that the compatible C1 interpolation has uy identically zero.
for node = 1:mesh.nNodes
    for ld = 1:4
        [parent, root] = findRoot(parent, dof.ID(ld, 2, node));
        fixedValue = assignFixedValue(fixedValue, root, 0);
    end
end

bottomNodes = find(abs(X(:, 2) - yMin) <= tol);
topNodes = find(abs(X(:, 2) - yMax) <= tol);

% Case 1: ux(0)=0, ux(H)=uhat, ux,y(H)=0, mxy(0)=0 natural.
% Case 2: ux(0)=0, ux,y(0)=0, tx(H)=that natural, mxy(H)=0 natural.
for k = 1:numel(bottomNodes)
    node = bottomNodes(k);
    [parent, rootU] = findRoot(parent, dof.ID(1, 1, node));
    fixedValue = assignFixedValue(fixedValue, rootU, 0);

    if strcmp(caseName, 'case2')
        % u_x,y=0 at y=0.  Stored DOF is u_x,2, whose value is zero
        % regardless of outward-normal sign.
        [parent, rootSlope] = findRoot(parent, dof.ID(3, 1, node));
        fixedValue = assignFixedValue(fixedValue, rootSlope, 0);
    end
end

if strcmp(caseName, 'case1')
    for k = 1:numel(topNodes)
        node = topNodes(k);
        [parent, rootU] = findRoot(parent, dof.ID(1, 1, node));
        fixedValue = assignFixedValue(fixedValue, rootU, prescribed.uhat);

        [parent, rootSlope] = findRoot(parent, dof.ID(3, 1, node));
        fixedValue = assignFixedValue(fixedValue, rootSlope, 0);
    end
end

% Re-compress after all lookups and transfer fixed values to roots.
for g = 1:nDOF
    [parent, root] = findRoot(parent, g);
    parent(g) = root;
end

rootFixed = nan(nDOF, 1);
for g = 1:nDOF
    root = parent(g);
    if ~isnan(fixedValue(root))
        rootFixed(root) = fixedValue(root);
    end
end

freeRoots = unique(parent(isnan(rootFixed(parent))));
rootToColumn = zeros(nDOF, 1);
rootToColumn(freeRoots) = 1:numel(freeRoots);

rows = [];
cols = [];
vals = [];
Dbar = zeros(nDOF, 1);

for g = 1:nDOF
    root = parent(g);
    if isnan(rootFixed(root))
        rows(end + 1, 1) = g; %#ok<AGROW>
        cols(end + 1, 1) = rootToColumn(root); %#ok<AGROW>
        vals(end + 1, 1) = 1; %#ok<AGROW>
    else
        Dbar(g) = rootFixed(root);
    end
end

T = sparse(rows, cols, vals, nDOF, numel(freeRoots));

constraints = struct();
constraints.T = T;
constraints.Dbar = Dbar;
constraints.nq = size(T, 2);
constraints.parent = parent(:);
constraints.leftNodes = leftNodes(:);
constraints.rightNodes = rightNodes(:);
constraints.caseName = caseName;
constraints.H = prescribed.H;
constraints.nFixedFull = nnz(~isnan(rootFixed(parent)));

end

function parent = unionDOF(parent, a, b)
[parent, ra] = findRoot(parent, a);
[parent, rb] = findRoot(parent, b);
if ra ~= rb
    parent(rb) = ra;
end
end

function [parent, root] = findRoot(parent, g)
root = g;
while parent(root) ~= root
    root = parent(root);
end
while parent(g) ~= g
    next = parent(g);
    parent(g) = root;
    g = next;
end
end

function fixedValue = assignFixedValue(fixedValue, root, value)
tol = 1e-12;
if isnan(fixedValue(root))
    fixedValue(root) = value;
else
    assert(abs(fixedValue(root) - value) <= tol*max(1, abs(value)), ...
        'buildPeriodicConstraints2022:conflicting prescribed values in one MPC class.');
end
end
