function kin = computeDeformationGradient(gradU)
%COMPUTEDEFORMATIONGRADIENT Total-Lagrangian plane-strain kinematics.
%
%   kin = computeDeformationGradient(gradU)
%
% Frozen kinematics:
%   F = I + Grad_0(u),  C = F^T*F,  J = det(F) > 0.

persistent SELFTEST_ACTIVE SELFTEST_DONE

if isempty(SELFTEST_ACTIVE)
    SELFTEST_ACTIVE = false;
end
if isempty(SELFTEST_DONE)
    SELFTEST_DONE = false;
end

assert(isnumeric(gradU) && isreal(gradU) && all(isfinite(gradU(:))) && ...
       isequal(size(gradU), [2, 2]), ...
    'computeDeformationGradient:gradU must be a real finite 2x2 matrix.');

kin = deformationGradientCore(gradU);

% One-time non-recursive verification.  The test calls the core directly,
% so every public invocation always returns a fully assigned output.
runSelfTest = ~SELFTEST_ACTIVE && ~SELFTEST_DONE;
if runSelfTest
    SELFTEST_ACTIVE = true;
    try
        runDeformationGradientSelfTest();
        SELFTEST_DONE = true;
    catch ME
        SELFTEST_ACTIVE = false;
        rethrow(ME);
    end
    SELFTEST_ACTIVE = false;
end

end

% =====================================================================
% Kinematic core.
% =====================================================================
function kin = deformationGradientCore(gradU)

F = eye(2) + gradU;
C = F.'*F;
detF = F(1, 1)*F(2, 2) - F(1, 2)*F(2, 1);

% Assumption A1: orientation-preserving, invertible motion.
assert(isfinite(detF) && detF > 0, ...
    'computeDeformationGradient:detF must be positive (element inversion detected).');

invF = [F(2, 2), -F(1, 2); ...
        -F(2, 1), F(1, 1)]/detF;

kin = struct();
kin.F = F;
kin.C = C;
kin.detF = detF;
kin.invF = invF;

end

% =====================================================================
% Non-recursive verification.
% =====================================================================
function runDeformationGradientSelfTest()

tol = 1e-12;

kin0 = deformationGradientCore(zeros(2, 2));
assert(norm(kin0.F - eye(2), 'fro') < tol, ...
    'computeDeformationGradient:self-test F is not I at the reference state.');
assert(norm(kin0.C - eye(2), 'fro') < tol, ...
    'computeDeformationGradient:self-test C is not I at the reference state.');
assert(abs(kin0.detF - 1) < tol, ...
    'computeDeformationGradient:self-test detF is not one at the reference state.');
assert(norm(kin0.invF - eye(2), 'fro') < tol, ...
    'computeDeformationGradient:self-test invF is not I at the reference state.');

for theta = [0, pi/6, -pi/4, pi/3]
    Q = [cos(theta), -sin(theta); sin(theta), cos(theta)];
    kinR = deformationGradientCore(Q - eye(2));

    assert(norm(kinR.C - eye(2), 'fro') < 1e-12, ...
        'computeDeformationGradient:self-test C is not objective under rigid rotation.');
    assert(abs(kinR.detF - 1) < 1e-12, ...
        'computeDeformationGradient:self-test detF is not one under rigid rotation.');
end

lam1 = 1.3;
lam2 = 0.8;
kinS = deformationGradientCore(diag([lam1 - 1, lam2 - 1]));
assert(norm(kinS.F - diag([lam1, lam2]), 'fro') < tol, ...
    'computeDeformationGradient:self-test homogeneous-stretch F mismatch.');
assert(norm(kinS.C - diag([lam1^2, lam2^2]), 'fro') < tol, ...
    'computeDeformationGradient:self-test homogeneous-stretch C mismatch.');
assert(abs(kinS.detF - lam1*lam2) < tol, ...
    'computeDeformationGradient:self-test homogeneous-stretch determinant mismatch.');

end
