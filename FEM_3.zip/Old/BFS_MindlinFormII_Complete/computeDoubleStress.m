function Sigma = computeDoubleStress(D6, G)
%COMPUTEDOUBLESTRESS  Mindlin Form-II double-stress tensor
%          Sigma_{IJK} = D6_{IJK PQR} G_{PQR} in plane strain.
%
%   Sigma = COMPUTEDOUBLESTRESS(D6, G)
%
% ----------------------------------------------------------------------
% Physical role and equation mapping (frozen Sec. 2)
% ----------------------------------------------------------------------
% The gradient-elastic energy is
%     psi_g(G) = (1/2) D_{IJKPQR} G_{IJK} G_{PQR},
% where G_{IJK} = E_{IJ,K} is the Green--Lagrange strain gradient
% (symmetric in I,J; see computeStrainGradient.m).  The double-stress
% tensor (higher-order stress work-conjugate to G) is
%     Sigma_{IJK} = d psi_g / d G_{IJK} = D_{IJK PQR} G_{PQR},
% with units [Pa m].  It inherits the minor symmetry of D6 (and of G):
%     Sigma_{IJK} = Sigma_{JIK}.
%
% The double stress drives both the gradient-material stiffness
% K_{mat,gr} and the gradient-geometric stiffness K_{geo,gr} of Sec. 7
% and enters the higher-order natural (double-traction) boundary
% condition D_i = H_{iJK} N_J N_K  with H_{iJK}=F_{iI} Sigma_{IJK}
% (eq. rn2:higher_order_bnd).
%
% ----------------------------------------------------------------------
% Tensor dimensions / index ordering
% ----------------------------------------------------------------------
%   D6    : 2 x 2 x 2 x 2 x 2 x 2  isotropic 6th-order modulus from
%           buildIsotropicD6.m, with indices (I,J,K,P,Q,R).
%   G     : 2 x 2 x 2               strain gradient G_{IJK}=E_{IJ,K};
%                                   symmetric in I,J.
%   Sigma : 2 x 2 x 2               double stress Sigma_{IJK}; symmetric
%                                   in (I,J).
%
% Contraction:
%     Sigma(I,J,K) = sum_{P,Q,R = 1..2} D6(I,J,K,P,Q,R) * G(P,Q,R).
%
% In the infinitesimal (small-strain) limit G -> grad epsilon, Sigma
% reduces to the classical Form-II double stress
%     Sigma^lin_{IJK} = D6_{IJK PQR} (grad epsilon)_{PQR},
% which is the higher-order stress used in the 2022 Torabi--Niiranen
% small-strain benchmark (Sec. 8, benchmark recovery s7:K_2022).
%
% See also BUILDISOTROPICD6, COMPUTESTRAINGRADIENT,
% COMPUTESECONDIOLASTRESS, COMPUTESTRAINENERGYDENSITY.

% ======================================================================
% Input validation
% ======================================================================
assert(isnumeric(D6), 'computeDoubleStress:D6 must be numeric.');
assert(ndims(D6) >= 6, 'computeDoubleStress:D6 must be 2x2x2x2x2x2.');
assert(size(D6,1)==2 && size(D6,2)==2 && size(D6,3)==2 && ...
       size(D6,4)==2 && size(D6,5)==2 && size(D6,6)==2, ...
       'computeDoubleStress:D6 must be 2x2x2x2x2x2.');
assert(isnumeric(G) && ndims(G) >= 3 && ...
       size(G,1)==2 && size(G,2)==2 && size(G,3)==2, ...
       'computeDoubleStress:G must be 2x2x2.');

   persistent SELFTEST_ACTIVE
if isempty(SELFTEST_ACTIVE)
    SELFTEST_ACTIVE = false;
end

if SELFTEST_ACTIVE

    Sigma = zeros(2,2,2);

    for I = 1:2
        for J = 1:2
            for K = 1:2
                s = 0;
                for P = 1:2
                    for Q = 1:2
                        for R = 1:2
                            s = s + D6(I,J,K,P,Q,R)*G(P,Q,R);
                        end
                    end
                end
                Sigma(I,J,K) = s;
            end
        end
    end

    for I = 1:2
        for J = I+1:2
            for K = 1:2
                avg = 0.5*(Sigma(I,J,K)+Sigma(J,I,K));
                Sigma(I,J,K)=avg;
                Sigma(J,I,K)=avg;
            end
        end
    end

    return;
end

   
% ======================================================================
% Contraction Sigma(I,J,K) = D6(I,J,K,P,Q,R) G(P,Q,R).
% ======================================================================
Sigma = zeros(2,2,2);
for I = 1:2
    for J = 1:2
        for K = 1:2
            s = 0;
            for P = 1:2
                for Q = 1:2
                    for R = 1:2
                        s = s + D6(I,J,K,P,Q,R)*G(P,Q,R);
                    end
                end
            end
            Sigma(I,J,K) = s;
        end
    end
end

% ======================================================================
% Defensive (I,J) symmetrisation (algebraically exact; removes any
% round-off asymmetry from the caller-supplied G).
% ======================================================================
for I = 1:2
    for J = I+1:2
        for K = 1:2
            avg = 0.5*(Sigma(I,J,K) + Sigma(J,I,K));
            Sigma(I,J,K) = avg;
            Sigma(J,I,K) = avg;
        end
    end
end

% ======================================================================
% Internal verification
% ======================================================================
SELFTEST_ACTIVE = true;

try
    tol = 1e-12;

% (i) Dimensions.
assert(isequal(size(Sigma), [2,2,2]), ...
    'computeDoubleStress:Sigma must be 2x2x2.');

% (ii) Minor (I,J) symmetry.
for I = 1:2
    for J = 1:2
        for K = 1:2
            assert(abs(Sigma(I,J,K) - Sigma(J,I,K)) < tol*max(1,abs(Sigma(I,J,K))), ...
                'computeDoubleStress:Sigma fails Sigma_{IJK}=Sigma_{JIK}.');
        end
    end
end

% (iii) Zero strain gradient -> zero double stress.
Sig0 = computeDoubleStress(D6, zeros(2,2,2));
assert(norm(Sig0(:)) < tol, ...
    'computeDoubleStress:zero-G double stress nonzero.');

% (iv) Isotropic-form check: for a G proportional to a single Kronecker
%      direction, Sigma must respect the known isotropy of D6.  We
%      build D6 from a generic set of a1..a5 using the same closed-
%      form T1..T5 + projectors (verified to reproduce psi_g
%      exactly), without calling buildIsotropicD6.  This tests the
%      contraction, not D6 itself.
a1=0.4; a2=-0.1; a3=0.2; a4=0.8; a5=0.3;
D6t = buildD6test(a1,a2,a3,a4,a5);
% Take  G_{111} = g (only component non-zero).
g = 0.07;
Gt = zeros(2,2,2); Gt(1,1,1) = g;
St = computeDoubleStress(D6t, Gt);
% D6 minor+major symmetries (already enforced in D6t) imply
% St(I,J,K) = D6(I,J,K,1,1,1)*g.  The energy psi = (1/2) D6_{111111} g^2
% follows directly; we verify Sigma:G = 2 psi_g in check (v) below.

% (v) Energy consistency: Sigma:G should equal d psi_g/dG : G = 2 psi_g
% for the quadratic form psi_g = (1/2) D6:G:G.  Check for several
% random G (symmetric in I,J).
rng(1);
for trial = 1:5
    Gr = zeros(2,2,2);
    for I=1:2
        for J=I:2
            Gr(I,J,:) = randn(1,2)*0.1;
            Gr(J,I,:) = Gr(I,J,:);
        end
    end
    Sig = computeDoubleStress(D6t, Gr);
    psiG = 0; SG = 0;
    for I=1:2, for J=1:2, for K=1:2
        for P=1:2, for Q=1:2, for R=1:2
            psiG = psiG + 0.5*D6t(I,J,K,P,Q,R)*Gr(I,J,K)*Gr(P,Q,R);
        end; end; end
        SG = SG + Sig(I,J,K)*Gr(I,J,K);
    end; end; end
    assert(abs(SG - 2*psiG) < 1e-10*(1+abs(psiG)), ...
        'computeDoubleStress:Sigma:G != 2 psi_g (energy consistency).');
end

% (vi) Numerical derivative check: Sigma_{IJK} should equal
%      d psi_g / d G_{IJK}, verified by central FD on the same D6t
%      and a random symmetric G.
Gr = zeros(2,2,2);
rng(2);
for I=1:2
    for J=I:2
        Gr(I,J,:) = randn(1,2)*0.1;
        Gr(J,I,:) = Gr(I,J,:);
    end
end
SigFD = zeros(2,2,2);
dG = 1e-5;
for I=1:2
    for J=I:2
        for K=1:2
            Gp = Gr; Gm = Gr;
            if I==J
                Gp(I,J,K) = Gp(I,J,K) + dG;
                Gm(I,J,K) = Gm(I,J,K) - dG;
                SigFD(I,J,K) = (psiG_of(D6t,Gp) - psiG_of(D6t,Gm))/(2*dG);
                SigFD(J,I,K) = SigFD(I,J,K);
            else
                Gp(I,J,K) = Gp(I,J,K)+dG; Gp(J,I,K)=Gp(J,I,K)+dG;
                Gm(I,J,K) = Gm(I,J,K)-dG; Gm(J,I,K)=Gm(J,I,K)-dG;
                SigFD(I,J,K) = (psiG_of(D6t,Gp) - psiG_of(D6t,Gm))/(4*dG);
                SigFD(J,I,K) = SigFD(I,J,K);
            end
        end
    end
end
San = computeDoubleStress(D6t, Gr);
assert(norm(San(:)-SigFD(:)) < 1e-4*max(1,norm(San(:))), ...
    'computeDoubleStress:numerical dpsi/dG mismatch.');

% ----------------------------------------------------------------------
% Local helpers (self-contained).
% ----------------------------------------------------------------------
    function D = buildD6test(a1,a2,a3,a4,a5)
        % Same Kronecker construction + symmetrisation as
        % buildIsotropicD6.m (Module 3, frozen); duplicated here so
        % this test is self-contained and does not rely on the
        % frozen module.
        delta = eye(2);
        Draw = zeros(2,2,2,2,2,2);
        for I=1:2, for J=1:2, for K=1:2, for P=1:2, for Q=1:2, for R=1:2
            Draw(I,J,K,P,Q,R) = 2*a1*delta(J,K)*delta(Q,R)*delta(I,P) ...
                + a2*(delta(I,J)*delta(K,P)*delta(Q,R) + delta(J,K)*delta(P,Q)*delta(I,R)) ...
                + 2*a3*delta(I,J)*delta(P,Q)*delta(K,R) ...
                + 2*a4*delta(I,P)*delta(J,Q)*delta(K,R) ...
                + 2*a5*delta(K,P)*delta(J,Q)*delta(I,R);
        end; end; end; end; end; end
        Ds = zeros(size(Draw));
        for I=1:2, for J=1:2, for K=1:2, for P=1:2, for Q=1:2, for R=1:2
            Ds(I,J,K,P,Q,R) = 0.25*(Draw(I,J,K,P,Q,R)+Draw(J,I,K,P,Q,R) ...
                                   +Draw(I,J,K,Q,P,R)+Draw(J,I,K,Q,P,R));
        end; end; end; end; end; end
        D = zeros(size(Ds));
        for I=1:2, for J=1:2, for K=1:2, for P=1:2, for Q=1:2, for R=1:2
            D(I,J,K,P,Q,R) = 0.5*(Ds(I,J,K,P,Q,R) + Ds(P,Q,R,I,J,K));
        end; end; end; end; end; end
    end

    function v = psiG_of(D, G_)
        v = 0;
        for ii=1:2, for jj=1:2, for kk=1:2
            for pp=1:2, for qq=1:2, for rr=1:2
                v = v + 0.5*D(ii,jj,kk,pp,qq,rr)*G_(ii,jj,kk)*G_(pp,qq,rr);
            end; end; end
        end; end; end
    end
SELFTEST_ACTIVE = false;

catch ME

SELFTEST_ACTIVE = false;
rethrow(ME);

end
end
