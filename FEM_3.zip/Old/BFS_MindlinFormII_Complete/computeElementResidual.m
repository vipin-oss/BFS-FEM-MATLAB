function R = computeElementResidual(elemGeom, mat, gauss, de)
%COMPUTEELEMENTRESIDUAL Internal residual of one 32-DOF 2D BFS element.
%
%   R = computeElementResidual(elemGeom, mat, gauss, de)
%
% Frozen formulation:
%   r_int^e = integral_Omega0e [S_IJ deltaE_IJ
%                              + Sigma_IJK deltaG_IJK] dV0
%           = integral_Omega0e [P_iJ delta u_i,J
%                              + Sigma_IJK deltaG_IJK] dV0.
%
% Kinematics are Total-Lagrangian and plane strain:
%   F = I + Grad(u), E = 1/2(F^T F-I), G_IJK = E_IJ,K.

persistent SELFTEST_ACTIVE SELFTEST_DONE

if isempty(SELFTEST_ACTIVE)
    SELFTEST_ACTIVE = false;
end
if isempty(SELFTEST_DONE)
    SELFTEST_DONE = false;
end

runSelfTest = ~SELFTEST_ACTIVE && ~SELFTEST_DONE;
if runSelfTest
    SELFTEST_ACTIVE = true;
end

try
    validateElementResidualInputs(elemGeom, mat, gauss, de);

    R = elementResidualCore(elemGeom, mat, gauss, de);

    % The local checks call the core directly, never this public function.
    % Therefore they cannot recursively re-enter this routine.
    if runSelfTest
        runElementResidualSelfTest(elemGeom, mat, gauss);
        SELFTEST_DONE = true;
    end

catch ME
    if runSelfTest
        SELFTEST_ACTIVE = false;
    end
    rethrow(ME);
end

if runSelfTest
    SELFTEST_ACTIVE = false;
end

end

% =====================================================================
% Element residual core.
% =====================================================================
function R = elementResidualCore(elemGeom, mat, gauss, de)

Jmap = computeJacobian(elemGeom);
h1 = Jmap.h1;
h2 = Jmap.h2;
detJ = Jmap.detJ;

% Parent-to-material derivative factors for the affine rectangle map.
dXi1 = 2/h1;
dXi2 = 2/h2;
dXi11 = dXi1*dXi1;
dXi22 = dXi2*dXi2;
dXi12 = dXi1*dXi2;

if isfield(mat, 'thickness')
    thickness = mat.thickness;
else
    thickness = 1;
end

C4 = mat.C4;
D6 = mat.D6;
d = de(:);
R = zeros(32, 1);

for gp = 1:gauss.nGP
    xi = gauss.xi(gp);
    eta = gauss.eta(gp);
    dV = thickness*detJ*gauss.w(gp);

    dN = bfsShapeFunctionDerivatives(xi, eta, h1, h2);

    % For component p, columns are its local 16 BFS DOFs.  The supplied
    % BFS derivative convention is retained: row 1/cols 1:16 for u1 and
    % row 2/cols 17:32 for u2.
    N1 = zeros(2, 16);
    N2 = zeros(2, 16);
    N11 = zeros(2, 16);
    N22 = zeros(2, 16);
    N12 = zeros(2, 16);

    N1(1, :) = dXi1*dN.dNdxi(1, 1:16);
    N2(1, :) = dXi2*dN.dNdeta(1, 1:16);
    N11(1, :) = dXi11*dN.d2Ndxi2(1, 1:16);
    N22(1, :) = dXi22*dN.d2Ndeta2(1, 1:16);
    N12(1, :) = dXi12*dN.d2Ndxideta(1, 1:16);

    N1(2, :) = dXi1*dN.dNdxi(2, 17:32);
    N2(2, :) = dXi2*dN.dNdeta(2, 17:32);
    N11(2, :) = dXi11*dN.d2Ndxi2(2, 17:32);
    N22(2, :) = dXi22*dN.d2Ndeta2(2, 17:32);
    N12(2, :) = dXi12*dN.d2Ndxideta(2, 17:32);

    % Grad(u) and Grad(Grad(u)); H(i,I,K)=u_i,I,K.
    gradU = zeros(2, 2);
    H = zeros(2, 2, 2);

    for p = 1:2
        block = (p - 1)*16 + (1:16);

        gradU(p, 1) = N1(p, :)*d(block);
        gradU(p, 2) = N2(p, :)*d(block);

        H(p, 1, 1) = N11(p, :)*d(block);
        H(p, 2, 2) = N22(p, :)*d(block);
        H(p, 1, 2) = N12(p, :)*d(block);
        H(p, 2, 1) = H(p, 1, 2);
    end

    % Frozen finite-strain kinematics.
    F = eye(2) + gradU;
    E = 0.5*(F.'*F - eye(2));
    E = 0.5*(E + E.');

    % S_IJ = C_IJKL E_KL.
    S = zeros(2, 2);
    for I = 1:2
        for J = 1:2
            for K = 1:2
                for L = 1:2
                    S(I, J) = S(I, J) + C4(I, J, K, L)*E(K, L);
                end
            end
        end
    end
    S = 0.5*(S + S.');

    % G_IJK = 1/2(F_mI,K F_mJ + F_mI F_mJ,K).
    G = zeros(2, 2, 2);
    for I = 1:2
        for J = 1:2
            for K = 1:2
                for m = 1:2
                    G(I, J, K) = G(I, J, K) + 0.5*( ...
                        H(m, I, K)*F(m, J) + F(m, I)*H(m, J, K));
                end
            end
        end
    end

    % Sigma_IJK = D_IJKPQR G_PQR.
    Sigma = zeros(2, 2, 2);
    for I = 1:2
        for J = 1:2
            for K = 1:2
                for P = 1:2
                    for Q = 1:2
                        for RR = 1:2
                            Sigma(I, J, K) = Sigma(I, J, K) + ...
                                D6(I, J, K, P, Q, RR)*G(P, Q, RR);
                        end
                    end
                end
            end
        end
    end

    % Residual coefficient for every displacement component and local
    % scalar BFS basis function.  deltaE and deltaG are the exact
    % directional derivatives of the frozen E and G kinematics.
    for p = 1:2
        for a = 1:16
            gradN = [N1(p, a), N2(p, a)];
            hessN = [N11(p, a), N12(p, a); ...
                     N12(p, a), N22(p, a)];

            rEntry = 0;

            for I = 1:2
                for J = 1:2
                    deltaE = 0.5*(F(p, I)*gradN(J) + ...
                                   F(p, J)*gradN(I));
                    rEntry = rEntry + S(I, J)*deltaE;
                end
            end

            for I = 1:2
                for J = 1:2
                    for K = 1:2
                        deltaG = 0.5*( ...
                            H(p, I, K)*gradN(J) + F(p, I)*hessN(J, K) + ...
                            H(p, J, K)*gradN(I) + F(p, J)*hessN(I, K));

                        rEntry = rEntry + Sigma(I, J, K)*deltaG;
                    end
                end
            end

            R((p - 1)*16 + a) = R((p - 1)*16 + a) + dV*rEntry;
        end
    end
end

end

% =====================================================================
% Validation and non-recursive self-test.
% =====================================================================
function validateElementResidualInputs(elemGeom, mat, gauss, de)

assert(isnumeric(de) && isreal(de) && all(isfinite(de(:))) && ...
       numel(de) == 32, ...
    'computeElementResidual:de must be a real finite 32-vector.');

assert(isstruct(gauss) && isfield(gauss, 'xi') && isfield(gauss, 'eta') && ...
       isfield(gauss, 'w') && isfield(gauss, 'nGP'), ...
    'computeElementResidual:gauss must be a gaussQuadrature struct.');

assert(isscalar(gauss.nGP) && gauss.nGP > 0 && ...
       numel(gauss.xi) == gauss.nGP && numel(gauss.eta) == gauss.nGP && ...
       numel(gauss.w) == gauss.nGP, ...
    'computeElementResidual:inconsistent gauss quadrature fields.');

assert(isstruct(mat) && isfield(mat, 'C4') && isfield(mat, 'D6'), ...
    'computeElementResidual:mat must contain C4 and D6.');

assert(isequal(size(mat.C4), [2, 2, 2, 2]), ...
    'computeElementResidual:mat.C4 must be 2x2x2x2.');

assert(isequal(size(mat.D6), [2, 2, 2, 2, 2, 2]), ...
    'computeElementResidual:mat.D6 must be 2x2x2x2x2x2.');

if isfield(mat, 'thickness')
    assert(isnumeric(mat.thickness) && isreal(mat.thickness) && ...
           isfinite(mat.thickness) && isscalar(mat.thickness) && ...
           mat.thickness > 0, ...
        'computeElementResidual:mat.thickness must be a positive scalar.');
end

% Force geometry validation through the established mapping utility.
Jmap = computeJacobian(elemGeom);
assert(isstruct(Jmap) && isfield(Jmap, 'h1') && isfield(Jmap, 'h2') && ...
       isfield(Jmap, 'detJ') && Jmap.h1 > 0 && Jmap.h2 > 0 && ...
       Jmap.detJ > 0, ...
    'computeElementResidual:invalid rectangular element geometry.');

end

function runElementResidualSelfTest(elemGeom, mat, gauss)

tol = 1e-10;

% Undeformed state: F=I, E=0, G=0, S=0, Sigma=0.
R0 = elementResidualCore(elemGeom, mat, gauss, zeros(32, 1));
assert(isequal(size(R0), [32, 1]) && norm(R0) < tol, ...
    'computeElementResidual:self-test residual is nonzero at the reference state.');

% Rigid translation: values are constant and all derivative DOFs vanish.
dTrans = zeros(32, 1);
for a = 1:4
    dTrans(4*(a - 1) + 1) = 0.35;
    dTrans(16 + 4*(a - 1) + 1) = -0.17;
end

Rt = elementResidualCore(elemGeom, mat, gauss, dTrans);
assert(norm(Rt) < tol, ...
    'computeElementResidual:self-test residual is nonzero under rigid translation.');

end
