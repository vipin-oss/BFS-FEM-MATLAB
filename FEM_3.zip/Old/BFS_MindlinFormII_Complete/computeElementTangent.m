function KT = computeElementTangent(elemGeom, mat, gauss, de)
%COMPUTEELEMENTTANGENT Consistent 32x32 BFS element tangent.
%
%   KT = computeElementTangent(elemGeom, mat, gauss, de)
%
% Frozen Section 7 decomposition:
%   K_T^e = K_mat,cl^e + K_geo,cl^e + K_mat,gr^e + K_geo,gr^e.
%
% This implementation differentiates the frozen internal virtual work
%   S_IJ deltaE_IJ + Sigma_IJK deltaG_IJK
% analytically, retaining all material and geometric terms.

persistent SELFTEST_ACTIVE SELFTEST_DONE

if isempty(SELFTEST_ACTIVE)
    SELFTEST_ACTIVE = false;
end
if isempty(SELFTEST_DONE)
    SELFTEST_DONE = false;
end

runSelfTest = ~SELFTEST_ACTIVE && ~SELFTEST_DONE;
if runSelfTest
    SELFTEST_ACTIVE = true;
end

try
    validateElementTangentInputs(elemGeom, mat, gauss, de);

    KT = elementTangentCore(elemGeom, mat, gauss, de);

    % The test uses the core for tangent states, so it cannot recurse.
    if runSelfTest
        runElementTangentSelfTest(elemGeom, mat, gauss);
        SELFTEST_DONE = true;
    end

catch ME
    if runSelfTest
        SELFTEST_ACTIVE = false;
    end
    rethrow(ME);
end

if runSelfTest
    SELFTEST_ACTIVE = false;
end

end

% =====================================================================
% Consistent tangent core.
% =====================================================================
function KT = elementTangentCore(elemGeom, mat, gauss, de)

Jmap = computeJacobian(elemGeom);
h1 = Jmap.h1;
h2 = Jmap.h2;
detJ = Jmap.detJ;

if isfield(mat, 'thickness')
    thickness = mat.thickness;
else
    thickness = 1;
end

C4 = mat.C4;
D6 = mat.D6;
d = de(:);

scale1 = 2/h1;
scale2 = 2/h2;
scale11 = scale1*scale1;
scale22 = scale2*scale2;
scale12 = scale1*scale2;

% Component associated with each local element DOF.
component = [ones(1, 16), 2*ones(1, 16)];
KT = zeros(32, 32);

for gp = 1:gauss.nGP
    xi = gauss.xi(gp);
    eta = gauss.eta(gp);
    dV = thickness*detJ*gauss.w(gp);

    dN = bfsShapeFunctionDerivatives(xi, eta, h1, h2);

    % gradN(I,a)=N^a_,I and hessN(I,K,a)=N^a_,IK.
    gradN = zeros(2, 32);
    hessN = zeros(2, 2, 32);

    gradN(1, 1:16) = scale1*dN.dNdxi(1, 1:16);
    gradN(2, 1:16) = scale2*dN.dNdeta(1, 1:16);
    hessN(1, 1, 1:16) = scale11*dN.d2Ndxi2(1, 1:16);
    hessN(2, 2, 1:16) = scale22*dN.d2Ndeta2(1, 1:16);
    hessN(1, 2, 1:16) = scale12*dN.d2Ndxideta(1, 1:16);
    hessN(2, 1, 1:16) = hessN(1, 2, 1:16);

    gradN(1, 17:32) = scale1*dN.dNdxi(2, 17:32);
    gradN(2, 17:32) = scale2*dN.dNdeta(2, 17:32);
    hessN(1, 1, 17:32) = scale11*dN.d2Ndxi2(2, 17:32);
    hessN(2, 2, 17:32) = scale22*dN.d2Ndeta2(2, 17:32);
    hessN(1, 2, 17:32) = scale12*dN.d2Ndxideta(2, 17:32);
    hessN(2, 1, 17:32) = hessN(1, 2, 17:32);

    % Current kinematics: gradU(p,I) and H(p,I,K)=u_p,I,K.
    gradU = zeros(2, 2);
    H = zeros(2, 2, 2);

    for p = 1:2
        cols = (p - 1)*16 + (1:16);
        for I = 1:2
            gradU(p, I) = gradN(I, cols)*d(cols);
            for K = 1:2
                H(p, I, K) = reshape(hessN(I, K, cols), 1, 16)*d(cols);
            end
        end
    end

    F = eye(2) + gradU;
    E = 0.5*(F.'*F - eye(2));
    E = 0.5*(E + E.');

    % S_IJ=C_IJKL E_KL.
    S = zeros(2, 2);
    for I = 1:2
        for J = 1:2
            for K = 1:2
                for L = 1:2
                    S(I, J) = S(I, J) + C4(I, J, K, L)*E(K, L);
                end
            end
        end
    end
    S = 0.5*(S + S.');

    % G_IJK=1/2(F_mI,K F_mJ + F_mI F_mJ,K).
    G = zeros(2, 2, 2);
    for I = 1:2
        for J = 1:2
            for K = 1:2
                for m = 1:2
                    G(I, J, K) = G(I, J, K) + 0.5*( ...
                        H(m, I, K)*F(m, J) + F(m, I)*H(m, J, K));
                end
            end
        end
    end

    % Sigma_IJK=D_IJKPQR G_PQR.
    Sigma = zeros(2, 2, 2);
    for I = 1:2
        for J = 1:2
            for K = 1:2
                for P = 1:2
                    for Q = 1:2
                        for RR = 1:2
                            Sigma(I, J, K) = Sigma(I, J, K) + ...
                                D6(I, J, K, P, Q, RR)*G(P, Q, RR);
                        end
                    end
                end
            end
        end
    end

    % B_E(I,J,a)=partial E_IJ/partial d_a and
    % B_G(I,J,K,a)=partial G_IJK/partial d_a.
    BE = zeros(2, 2, 32);
    BG = zeros(2, 2, 2, 32);

    for a = 1:32
        p = component(a);

        for I = 1:2
            for J = 1:2
                BE(I, J, a) = 0.5*(F(p, I)*gradN(J, a) + ...
                                    F(p, J)*gradN(I, a));
            end
        end

        for I = 1:2
            for J = 1:2
                for K = 1:2
                    BG(I, J, K, a) = 0.5*( ...
                        H(p, I, K)*gradN(J, a) + F(p, I)*hessN(J, K, a) + ...
                        H(p, J, K)*gradN(I, a) + F(p, J)*hessN(I, K, a));
                end
            end
        end
    end

    % Four frozen tangent contributions.
    for a = 1:32
        p = component(a);

        for b = 1:32
            q = component(b);

            kMatCl = 0;
            kGeoCl = 0;
            kMatGr = 0;
            kGeoGr = 0;

            % Classical material: B_E(a) : C : B_E(b).
            for I = 1:2
                for J = 1:2
                    for K = 1:2
                        for L = 1:2
                            kMatCl = kMatCl + BE(I, J, a)*C4(I, J, K, L)*BE(K, L, b);
                        end
                    end
                end
            end

            % Classical geometric: S : delta^2 E(a,b).
            if p == q
                for I = 1:2
                    for J = 1:2
                        delta2E = 0.5*(gradN(I, b)*gradN(J, a) + ...
                                       gradN(I, a)*gradN(J, b));
                        kGeoCl = kGeoCl + S(I, J)*delta2E;
                    end
                end
            end

            % Gradient material: B_G(a) : D : B_G(b).
            for I = 1:2
                for J = 1:2
                    for K = 1:2
                        for P = 1:2
                            for Q = 1:2
                                for RR = 1:2
                                    kMatGr = kMatGr + BG(I, J, K, a)* ...
                                        D6(I, J, K, P, Q, RR)*BG(P, Q, RR, b);
                                end
                            end
                        end
                    end
                end
            end

            % Gradient geometric: Sigma : delta^2 G(a,b).
            if p == q
                for I = 1:2
                    for J = 1:2
                        for K = 1:2
                            delta2G = 0.5*( ...
                                hessN(I, K, b)*gradN(J, a) + ...
                                gradN(I, b)*hessN(J, K, a) + ...
                                hessN(J, K, b)*gradN(I, a) + ...
                                gradN(J, b)*hessN(I, K, a));

                            kGeoGr = kGeoGr + Sigma(I, J, K)*delta2G;
                        end
                    end
                end
            end

            KT(a, b) = KT(a, b) + dV*(kMatCl + kGeoCl + kMatGr + kGeoGr);
        end
    end
end

% Hyperelastic tangent symmetry; only floating-point asymmetry is removed.
KT = 0.5*(KT + KT.');

end

% =====================================================================
% Validation and non-recursive self-test.
% =====================================================================
function validateElementTangentInputs(elemGeom, mat, gauss, de)

assert(isnumeric(de) && isreal(de) && all(isfinite(de(:))) && ...
       numel(de) == 32, ...
    'computeElementTangent:de must be a real finite 32-vector.');

assert(isstruct(gauss) && isfield(gauss, 'xi') && isfield(gauss, 'eta') && ...
       isfield(gauss, 'w') && isfield(gauss, 'nGP'), ...
    'computeElementTangent:gauss must be a gaussQuadrature struct.');

assert(isscalar(gauss.nGP) && gauss.nGP > 0 && ...
       numel(gauss.xi) == gauss.nGP && numel(gauss.eta) == gauss.nGP && ...
       numel(gauss.w) == gauss.nGP, ...
    'computeElementTangent:inconsistent gauss quadrature fields.');

assert(isstruct(mat) && isfield(mat, 'C4') && isfield(mat, 'D6'), ...
    'computeElementTangent:mat must contain C4 and D6.');

assert(isequal(size(mat.C4), [2, 2, 2, 2]), ...
    'computeElementTangent:mat.C4 must be 2x2x2x2.');
assert(isequal(size(mat.D6), [2, 2, 2, 2, 2, 2]), ...
    'computeElementTangent:mat.D6 must be 2x2x2x2x2x2.');

if isfield(mat, 'thickness')
    assert(isnumeric(mat.thickness) && isreal(mat.thickness) && ...
           isfinite(mat.thickness) && isscalar(mat.thickness) && ...
           mat.thickness > 0, ...
        'computeElementTangent:mat.thickness must be a positive scalar.');
end

Jmap = computeJacobian(elemGeom);
assert(isstruct(Jmap) && isfield(Jmap, 'h1') && isfield(Jmap, 'h2') && ...
       isfield(Jmap, 'detJ') && Jmap.h1 > 0 && Jmap.h2 > 0 && ...
       Jmap.detJ > 0, ...
    'computeElementTangent:invalid rectangular element geometry.');

end

function runElementTangentSelfTest(elemGeom, mat, gauss)

rngState = rng;
rngCleanup = onCleanup(@() rng(rngState)); %#ok<NASGU>

tol = 1e-10;
K0 = elementTangentCore(elemGeom, mat, gauss, zeros(32, 1));

assert(isequal(size(K0), [32, 32]), ...
    'computeElementTangent:self-test tangent dimension mismatch.');
assert(norm(K0 - K0.', 'fro') < tol*(1 + norm(K0, 'fro')), ...
    'computeElementTangent:self-test tangent is not symmetric.');

% Rigid translation at the stress-free reference state is a null mode.
dTranslation = zeros(32, 1);
for a = 1:4
    dTranslation(4*(a - 1) + 1) = 1;
    dTranslation(16 + 4*(a - 1) + 1) = 1;
end
assert(norm(K0*dTranslation) < tol*(1 + norm(K0, 'fro')), ...
    'computeElementTangent:self-test rigid-translation null mode failed.');

% Finite-difference consistency with the frozen element residual.
rng(13);
dTest = 0.02*randn(32, 1);
Ktest = elementTangentCore(elemGeom, mat, gauss, dTest);
epsFD = 1e-6;
maxRelErr = 0;

for trial = 1:3
    v = randn(32, 1);
    v = v/norm(v);

    Rp = computeElementResidual(elemGeom, mat, gauss, dTest + epsFD*v);
    Rm = computeElementResidual(elemGeom, mat, gauss, dTest - epsFD*v);
    Kfdv = (Rp - Rm)/(2*epsFD);

    maxRelErr = max(maxRelErr, ...
        norm(Ktest*v - Kfdv)/max(norm(Kfdv), eps));
end

assert(maxRelErr < 1e-4, ...
    ['computeElementTangent:self-test finite-difference consistency ' ...
     'failed (relative error %g).'], maxRelErr);

fprintf('computeElementTangent self-test OK (max FD rel err = %.3e).\n', maxRelErr);

end
