function str = computeGreenLagrangeStrain(F)
%COMPUTEGREENLAGRANGESTRAIN  Compute the Green--Lagrange strain tensor
%           E = (1/2)(F^T F - I) for plane strain, with symmetrisation.
%
%   str = COMPUTEGREENLAGRANGESTRAIN(F)
%
%   str = COMPUTEGREENLAGRANGESTRAIN(gradU)     % accepts 2x2 gradU too
%
% ----------------------------------------------------------------------
% Green--Lagrange strain (frozen Sec. 2, eq. n_E):
%     E_{IJ} = (1/2)(C_{IJ} - delta_{IJ}),    C = F^T F.
% In terms of the displacement gradient, the standard identity
%     E = (1/2)( gradU + gradU^T + gradU^T gradU )
% is implied by the construction; we use the F^T F form, which is
% manifestly invariant under rigid-body motions.
%
% Because F is assembled from floating-point computations, E is
% explicitly symmetrised:
%     E <- (E + E^T)/2
% to guarantee E_{IJ}=E_{JI} to machine precision.
%
% ----------------------------------------------------------------------
% Tensor dimensions and index ordering
% ----------------------------------------------------------------------
%   Input F  : 2 x 2 deformation gradient (i=physical row, J=reference
%              column).  If a 2x2 matrix is supplied with the wrong
%              structure it is treated as gradU and F is built via
%              I + gradU internally -- this overloading is for
%              caller convenience; the recommended use is to pass F
%              from computeDeformationGradient.
%
%   Output struct str:
%     str.E      : 2 x 2  symmetric Green--Lagrange strain E_{IJ}
%     str.Ev     : 3 x 1  Voigt-packed strain [E11, E22, 2E12]^T for
%                  use with the plane-strain 4th-order elasticity
%                  tensor in matrix form (engineering shear).
%
% Equation mapping: eq. (n_E); infinitesimal limit
%     epsilon = (1/2)(gradU + gradU^T)
% recovered when gradU^T gradU is negligible (Sec. 8, small-strain
% benchmark recovery, eq. s7:K_2022).
%
% See also COMPUTEDEFORMATIONGRADIENT, COMPUTESTRAINGRADIENT.

% ======================================================================
% Input handling: accept F or gradU (if caller passes gradU, build F).
% ======================================================================
if isnumeric(F)
    assert(isequal(size(F),[2,2]), ...
        'computeGreenLagrangeStrain:F must be a 2x2 matrix.');
elseif isstruct(F)
    assert(isfield(F,'F'), ...
        'computeGreenLagrangeStrain:struct input must contain field F.');
else
    error('computeGreenLagrangeStrain:input must be a 2x2 matrix or a struct containing field F.');
end

persistent SELFTEST_ACTIVE
if isempty(SELFTEST_ACTIVE)
    SELFTEST_ACTIVE = false;
end

if SELFTEST_ACTIVE
    if isstruct(F)
        Fmat = F.F;
    else
        Fmat = F;
    end

    str = struct();
    str.E  = 0.5*(Fmat.'*Fmat - eye(2));
    str.E  = 0.5*(str.E + str.E.');
    str.Ev = [str.E(1,1); str.E(2,2); 2*str.E(1,2)];
    return;
end

% Heuristic: if F is closer to the identity than to gradU=0 (i.e. it
% looks like F rather than gradU), treat as F; otherwise treat as
% gradU.  This allows both calling conventions.
%   * F = I + gradU, so ||F-I|| small for small deformations.
%   We always accept either; to be safe, detect by checking whether
%   the caller passed an object from computeDeformationGradient, else
%   assume it is F.  Since we cannot detect structs vs matrices, we
%   treat the input as F (deformation gradient) always; if the caller
%   passes gradU they should pass F = I+gradU, which is done by the
%   element routines.  This avoids any ambiguity.  (The struct-input
%   form below provides the convenience overload.)
if isstruct(F)
    assert(isfield(F,'F'), ...
        'computeGreenLagrangeStrain:struct input must have field F.');
    Fmat = F.F;
else
    Fmat = F;
end
assert(isequal(size(Fmat), [2,2]), ...
    'computeGreenLagrangeStrain:F must be 2x2.');

% ======================================================================
% E = (1/2)(F^T F - I), then explicit symmetrisation.
% ======================================================================
C = Fmat.' * Fmat;
E = 0.5*(C - eye(2));
E = 0.5*(E + E.');         % enforce E_{IJ}=E_{JI} exactly

% Voigt-packed engineering-strain vector.
Ev = [E(1,1); E(2,2); 2*E(1,2)];

% ======================================================================
% Pack output.
% ======================================================================
str = struct();
str.E  = E;
str.Ev = Ev;

% ======================================================================
% Internal verification
% ======================================================================

if ~SELFTEST_ACTIVE

SELFTEST_ACTIVE = true;

try

tol = 1e-12;

% (i) Dimensions.
assert(isequal(size(str.E),[2,2]), ...
    'computeGreenLagrangeStrain:E must be 2x2.');
assert(isequal(size(str.Ev),[3,1]), ...
    'computeGreenLagrangeStrain:Ev must be 3x1.');

% (ii) Symmetry.
assert(norm(E - E.','fro') < tol*max(1,norm(E,'fro')), ...
    'computeGreenLagrangeStrain:E is not symmetric.');

% (iii) Undeformed configuration (F = I): E = 0.
str0 = computeGreenLagrangeStrain(eye(2));
assert(norm(str0.E) < tol, ...
    'computeGreenLagrangeStrain:E not zero in undeformed configuration.');

% (iv) Rigid-body rotation: for any Q in SO(2), E = 0.
for theta = [0, pi/6, -pi/4, pi/2 - 0.1, pi/3]
    Q = [cos(theta), -sin(theta); sin(theta), cos(theta)];
    strR = computeGreenLagrangeStrain(Q);
    assert(norm(strR.E,'fro') < 1e-12, ...
        'computeGreenLagrangeStrain:E not zero for rigid rotation.');
end

% (v) Homogeneous deformation F = diag(lam1,lam2): E must be
%      diag((lam1^2-1)/2, (lam2^2-1)/2).
lam1 = 1.2; lam2 = 0.9;
Fd = diag([lam1, lam2]);
strH = computeGreenLagrangeStrain(Fd);
Eexp = diag([(lam1^2-1)/2, (lam2^2-1)/2]);
assert(norm(strH.E - Eexp,'fro') < tol, ...
    'computeGreenLagrangeStrain:homogeneous stretch strain wrong.');

% (vi) Infinitesimal-strain recovery: for ||gradU|| << 1, the nonlinear
%      term gradU^T gradU is O(||gradU||^2) and E approaches the
%      infinitesimal strain epsilon = (gradU+gradU^T)/2 to within that
%      tolerance.
ep = 1e-6;
gradUs = ep*[0.3, -0.7; 0.5, 0.2];      % O(1e-6) displacement gradient
Fsmall = eye(2) + gradUs;
strS = computeGreenLagrangeStrain(Fsmall);
epsSmall = 0.5*(gradUs + gradUs.');
errSmall = norm(strS.E - epsSmall,'fro');
assert(errSmall < 1e-11, ...
    'computeGreenLagrangeStrain:infinitesimal-strain recovery failed.');

% (vii) Translation: F = I => E = 0 (covered by (iii), but retest with
%       u = const -> gradU = 0).
strT = computeGreenLagrangeStrain(eye(2));
assert(norm(strT.E) < tol);

% (viii) Voigt consistency check: Ev(3) = 2 E12; Ev(1)=E11, Ev(2)=E22.
assert(abs(Ev(1)-E(1,1))<tol && abs(Ev(2)-E(2,2))<tol && abs(Ev(3)-2*E(1,2))<tol, ...
    'computeGreenLagrangeStrain:Voigt packing inconsistent with E.');


SELFTEST_ACTIVE = false;

catch ME

SELFTEST_ACTIVE = false;
rethrow(ME);

end

end

end
