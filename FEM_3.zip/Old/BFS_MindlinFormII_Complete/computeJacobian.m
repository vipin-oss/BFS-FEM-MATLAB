function Jmap = computeJacobian(elemGeom)
%COMPUTEJACOBIAN  Jacobian of the parent-to-physical affine mapping
%                 for a rectangular BFS element.
%
%   Jmap = COMPUTEJACOBIAN(elemGeom)
%
% ----------------------------------------------------------------------
% Parent and physical coordinate systems (frozen Sec. 6)
% ----------------------------------------------------------------------
% Parent:  (xi, eta) in [-1,1]^2  (biunit square).
% Physical (reference configuration):
%          X1 in [X1_0, X1_0 + h1],  X2 in [X2_0, X2_0 + h2]
% for an axis-aligned rectangular element with lower-left corner
% (X1_0, X2_0) and side lengths h1, h2.
%
% The affine parent -> physical map used throughout Secs. 6-7 is
%     X1(xi,eta) = X1_0 + (h1/2)*(xi + 1),
%     X2(xi,eta) = X2_0 + (h2/2)*(eta + 1).
%
% Because the map is affine and axis-aligned, the Jacobian matrix
%     J_{iM} = d X_i / d xi_M        (i = 1,2;  M = xi=1, eta=2)
% is constant over the element and diagonal:
%         / h1/2   0   \
%     J = |              |.
%         \  0    h2/2  /
% The Jacobian determinant is
%     detJ = h1 h2 / 4,
% and the inverse (used in the chain rule for shape-function
% derivatives) is
%         / 2/h1   0   \
%    J^{-1} = |           |.
%         \  0    2/h2  /
% Physical-derivative conversion follows from  d/dX_i = J^{-T}_{iM} d/dxi_M:
%     d/dX1 = (2/h1) d/dxi,     d/dX2 = (2/h2) d/deta.
%
% ----------------------------------------------------------------------
% Input
% ----------------------------------------------------------------------
%   elemGeom : Either
%               (a) a struct with scalar fields
%                     .x0, .y0       lower-left corner (physical)
%                     .h1, .h2       side lengths (> 0)
%                   (as produced by mesh/computeElementGeometry.m per
%                   the project architecture), or
%               (b) a 4 x 2 matrix of corner nodal coordinates in
%                   counter-clockwise order, with rows
%                     [X1_0,    X2_0   ]   lower-left
%                     [X1_0+h1, X2_0   ]   lower-right
%                     [X1_0+h1, X2_0+h2]   upper-right
%                     [X1_0,    X2_0+h2]   upper-left
%                   (as returned by mesh/getElementCornerCoords.m).
%               In case (b) the rectangle axis-alignment is verified.
%
% ----------------------------------------------------------------------
% Output Jmap (struct)
% ----------------------------------------------------------------------
%   Jmap.J       (2x2) Jacobian matrix dX_i / dxi_M
%   Jmap.invJ    (2x2) inverse Jacobian dxi_M / dX_i
%   Jmap.detJ    (scalar) determinant (= h1 h2 / 4)
%   Jmap.h1,
%   Jmap.h2     side lengths (positive)
%   Jmap.x0,
%   Jmap.y0     lower-left corner
%   Jmap.xi_to_x1,
%   Jmap.eta_to_x2 : chain-rule scalars = 2/h1, 2/h2, such that
%                       d/dX1 = xi_to_x1 * d/dxi,
%                       d/dX2 = eta_to_x2 * d/deta.
%   Jmap.isAffine  logical, always true for the BFS rectangle
%                  (kept for forward-compatibility with distorted
%                  generalisations that may produce non-constant J).
%
% Equation mapping: s7:gauss_volume (detJ weight in integral);
% chain-rule conversion used throughout s6:u_interp--s6:G_h.
%
% See also GAUSSQUADRATURE, MAPPARENTTOPHYSICAL.

% ======================================================================
% Unpack elemGeom: accept struct or 4x2 corner matrix.
% ======================================================================
if isstruct(elemGeom)
    assert(isfield(elemGeom,'x0') && isfield(elemGeom,'y0') ...
        && isfield(elemGeom,'h1') && isfield(elemGeom,'h2'), ...
        'computeJacobian:elemGeom struct must contain x0,y0,h1,h2.');
    x0 = elemGeom.x0;  y0 = elemGeom.y0;
    h1 = elemGeom.h1;  h2 = elemGeom.h2;
elseif isnumeric(elemGeom) && isequal(size(elemGeom), [4,2])
    X = elemGeom;
    % Counter-clockwise corners: LL, LR, UR, UL.
    xLL = X(1,1); yLL = X(1,2);
    xLR = X(2,1); yLR = X(2,2);
    xUR = X(3,1); yUR = X(3,2);
    xUL = X(4,1); yUL = X(4,2);
    % Verify axis-aligned rectangle (BFS restriction, assumption A8).
    tolR = 1e-12;
    assert(abs(yLR - yLL) < tolR*(1+abs(yLL)+abs(yLR)), ...
        'computeJacobian:bottom edge is not horizontal (yLL ~= yLR).');
    assert(abs(yUR - yUL) < tolR*(1+abs(yUR)+abs(yUL)), ...
        'computeJacobian:top edge is not horizontal.');
    assert(abs(xUL - xLL) < tolR*(1+abs(xUL)+abs(xLL)), ...
        'computeJacobian:left edge is not vertical.');
    assert(abs(xUR - xLR) < tolR*(1+abs(xUR)+abs(xLR)), ...
        'computeJacobian:right edge is not vertical.');
    assert(abs(xLR - xLL - (xUR - xUL)) < tolR, ...
        'computeJacobian:top/bottom h1 differ.');
    assert(abs(yUL - yLL - (yUR - yLR)) < tolR, ...
        'computeJacobian:left/right h2 differ.');
    h1 = xLR - xLL;
    h2 = yUL - yLL;
    x0 = xLL;
    y0 = yLL;
else
    error(['computeJacobian:elemGeom must be a struct with fields ' ...
           'x0,y0,h1,h2 or a 4x2 corner-coordinate matrix.']);
end

% ======================================================================
% Validate geometry.
% ======================================================================
assert(isscalar(h1) && isscalar(h2) && h1 > 0 && h2 > 0, ...
    'computeJacobian:h1 and h2 must be positive scalars.');
assert(isscalar(x0) && isscalar(y0), ...
    'computeJacobian:x0 and y0 must be scalars.');

% ======================================================================
% Assemble the affine Jacobian for the axis-aligned rectangle.
% ======================================================================
J    = diag([h1/2, h2/2]);
detJ = (h1/2)*(h2/2);            % = h1*h2/4
invJ = diag([2/h1, 2/h2]);

% ======================================================================
% Pack output.
% ======================================================================
Jmap = struct();
Jmap.J        = J;
Jmap.invJ     = invJ;
Jmap.detJ     = detJ;
Jmap.h1       = h1;
Jmap.h2       = h2;
Jmap.x0       = x0;
Jmap.y0       = y0;
Jmap.xi_to_x1 = 2/h1;
Jmap.eta_to_x2 = 2/h2;
Jmap.isAffine = true;

% ======================================================================
% Internal verification.
% ======================================================================
tol = 1e-12;

% (i) Dimensions.
assert(isequal(size(Jmap.J),[2,2]) && isequal(size(Jmap.invJ),[2,2]), ...
    'computeJacobian:J and invJ must be 2x2.');
assert(isscalar(Jmap.detJ), 'computeJacobian:detJ must be scalar.');

% (ii) Determinant positive (orientation preservation).
assert(Jmap.detJ > 0, ...
    'computeJacobian:detJ must be positive (orientation preserved).');
assert(Jmap.h1 > 0 && Jmap.h2 > 0, ...
    'computeJacobian:h1,h2 must be positive.');

% (iii) J * invJ = I (analytic construction, but re-verify for safety).
assert(norm(Jmap.J*Jmap.invJ - eye(2)) < tol, ...
    'computeJacobian:J * invJ is not identity.');

% (iv) Consistency of detJ with h1,h2.
assert(abs(Jmap.detJ - h1*h2/4) < tol, ...
    'computeJacobian:detJ inconsistent with h1,h2.');

% (v) Chain-rule scalars equal the diagonal entries of invJ.
assert(abs(Jmap.xi_to_x1  - Jmap.invJ(1,1)) < tol && ...
       abs(Jmap.eta_to_x2 - Jmap.invJ(2,2)) < tol, ...
    'computeJacobian:chain-rule scalars inconsistent with invJ.');
assert(abs(Jmap.invJ(1,2)) < tol && abs(Jmap.invJ(2,1)) < tol, ...
    'computeJacobian:invJ must be diagonal for BFS rectangle.');

% (vi) Exact mapping of the four corner parent nodes to physical
%      corners (uses mapParentToPhysical-like formula here to avoid a
%      circular dependency; the dedicated routine checks the same).
xi_c  = [-1, 1, 1,-1];
eta_c = [-1,-1, 1, 1];
phys_corners = [x0,    y0;
               x0+h1, y0;
               x0+h1, y0+h2;
               x0,    y0+h2];
for k = 1:4
    X1 = x0 + (h1/2)*(xi_c(k)+1);
    X2 = y0 + (h2/2)*(eta_c(k)+1);
    assert(abs(X1 - phys_corners(k,1)) < tol && abs(X2 - phys_corners(k,2)) < tol, ...
        'computeJacobian:affine map does not place corner node %d correctly.', k);
end

% (vii) Metric consistency: integration of the parent-to-physical area
%       element over the parent square must equal the physical area
%       h1*h2.
areaParent = 4;                  % [-1,1]^2 area
areaPhys   = Jmap.detJ * areaParent;
assert(abs(areaPhys - h1*h2) < tol, ...
    'computeJacobian:detJ * parent_area does not equal h1*h2.');

end
