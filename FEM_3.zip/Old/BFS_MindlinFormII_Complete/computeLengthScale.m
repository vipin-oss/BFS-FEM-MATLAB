function ell = computeLengthScale(a1, a2, a3, a4, a5, mu)
%COMPUTELENGTHSCALE  Internal length scale from gradient constants.
%
%   ell = COMPUTELENGTHSCALE(a1, a2, a3, a4, a5, mu)
%
%   Returns the internal length scale
%
%       ell = sqrt( bar_a / mu ),   bar_a = (1/5)*(a1 + a2 + a3 + a4 + a5)
%
%   of Sec. 8, eq. (s8:length_scale).  This is the normalised length
%   scale used throughout the numerical experiments of Section~9 (Study~3,
%   in particular).  It is a diagnostic scalar derived from the five
%   gradient constants and the classical shear modulus; it is not an
%   independent constitutive parameter.
%
%   The factor of 1/5 is retained exactly as specified by eq. (s8:length_scale);
%   alternative reduced-model scalings (e.g. one-parameter
%   simplifications) are to be introduced as post-processing, not here.
%
%   Inputs:
%     a1..a5     Five isotropic Mindlin Form-II gradient           [Pa m^2]
%                constants.
%     mu         Shear modulus                                     [Pa]
%
%   Output:
%     ell        Internal length scale                              [m]
%
%   Equation mapping (frozen Sections 1--9):
%     ell <- eq. (s8:length_scale).
%
%   The routine returns a non-negative length; if all a_i are zero
%   (classical SVK limit), ell = 0 as expected.

% --- Input validation ----------------------------------------------
assert(nargin == 6, 'computeLengthScale:requires six inputs (a1..a5,mu).');
assert(isscalar(a1), 'computeLengthScale:a1 must be scalar.');
assert(isscalar(a2), 'computeLengthScale:a2 must be scalar.');
assert(isscalar(a3), 'computeLengthScale:a3 must be scalar.');
assert(isscalar(a4), 'computeLengthScale:a4 must be scalar.');
assert(isscalar(a5), 'computeLengthScale:a5 must be scalar.');

assert(isscalar(mu) && isfinite(mu) && mu > 0, ...
    'computeLengthScale:mu must be a positive finite scalar.');


% --- Compute length scale (Sec. 8, eq. s8:length_scale) -----------
bar_a = (a1 + a2 + a3 + a4 + a5) / 5;

% Guard against negative bar_a (non-physical input) so that the
% function does not return a complex length.  The admissibility of
% a1..a5 (positive-definiteness of D6 on the symmetric-G subspace)
% is checked at the assembly/post-processing level, not here; we
% only guard the sqrt.
if bar_a <= 0
    ell = 0;
else
    ell = sqrt(bar_a / mu);
end

assert(ell >= 0 && isfinite(ell), ...
    'computeLengthScale:ell must be real and non-negative.');

end
