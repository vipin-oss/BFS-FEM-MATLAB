function S = computeSecondPiolaStress(C4, E)
%COMPUTESECONDIOLASTRESS  Second Piola--Kirchhoff stress for the
%          Saint-Venant--Kirchhoff part of the BFS Mindlin Form-II
%          model, in plane strain.
%
%   S = COMPUTESECONDIOLASTRESS(C4, E)
%
% ----------------------------------------------------------------------
% Physical role and equation mapping (frozen Sec. 2)
% ----------------------------------------------------------------------
% The classical Saint-Venant--Kirchhoff strain energy is
%     psi_c(E) = (1/2) C_{IJKL} E_{IJ} E_{KL},
% with the isotropic plane-strain elasticity tensor
%     C_{IJKL} = lambda delta_{IJ} delta_{KL}
%              + mu (delta_{IK} delta_{JL} + delta_{IL} delta_{JK})
% (buildIsotropicC4.m).  The second Piola--Kirchhoff stress is the
% conjugate stress to E,
%     S_{IJ} = d psi_c / d E_{IJ} = C_{IJKL} E_{KL},
% and has units [Pa].  It inherits the minor and major symmetries of
% C4 and the symmetry E_{IJ}=E_{JI}, giving
%     S_{IJ} = S_{JI}.
%
% ----------------------------------------------------------------------
% Tensor dimensions / index ordering
% ----------------------------------------------------------------------
%   C4 : 2 x 2 x 2 x 2   classical modulus, plane-strain sub-block,
%                        with indices (I,J,K,L); returned by
%                        buildIsotropicC4.
%   E  : 2 x 2           symmetric Green--Lagrange strain (from
%                        computeGreenLagrangeStrain).
%   S  : 2 x 2           Second Piola--Kirchhoff stress, symmetric.
%
% Contraction convention:
%     S(I,J) = sum_{K=1..2} sum_{L=1..2} C4(I,J,K,L) * E(K,L).
%
% The second-Piola stress enters the weak form via the first
% Piola--Kirchhoff traction (P = F S), which drives the material
% tangent parts K_{mat,cl} and K_{geo,cl} of Sec. 7.
%
% In the infinitesimal (small-strain) limit E -> epsilon, S reduces
% to the classical Cauchy stress sigma = C : epsilon, which is the
% stress measure used in the 2022 Torabi--Niiranen small-strain
% benchmark (Sec. 8, benchmark recovery s7:K_2022).
%
% See also BUILDISOTROPICC4, COMPUTEGREENLAGRANGESTRAIN,
% COMPUTEDOUBLESTRESS, COMPUTESTRAINENERGYDENSITY.

% ======================================================================
% Input validation
% ======================================================================
assert(isnumeric(C4) && ndims(C4) >= 4 && ...
    size(C4,1)==2 && size(C4,2)==2 && size(C4,3)==2 && size(C4,4)==2, ...
    'computeSecondPiolaStress:C4 must be a 2x2x2x2 tensor.');
assert(isnumeric(E) && isequal(size(E),[2,2]), ...
    'computeSecondPiolaStress:E must be 2x2.');

persistent SELFTEST_ACTIVE
if isempty(SELFTEST_ACTIVE)
    SELFTEST_ACTIVE = false;
end

if SELFTEST_ACTIVE
    S = zeros(2,2);

    for I = 1:2
        for J = 1:2
            s = 0;
            for K = 1:2
                for L = 1:2
                    s = s + C4(I,J,K,L)*E(K,L);
                end
            end
            S(I,J) = s;
        end
    end

    S = 0.5*(S + S.');
    return;
end

% ======================================================================
% Contraction S(I,J) = C4(I,J,K,L) E(K,L), indices summed in {1,2}.
% ======================================================================
S = zeros(2,2);
for I = 1:2
    for J = 1:2
        s = 0;
        for K = 1:2
            for L = 1:2
                s = s + C4(I,J,K,L)*E(K,L);
            end
        end
        S(I,J) = s;
    end
end

% ======================================================================
% Defensive symmetrisation (algebraically exact; removes any round-off
% asymmetry from the caller-provided E or C4).
% ======================================================================
S = 0.5*(S + S.');

% ======================================================================
% Internal verification
% ======================================================================
SELFTEST_ACTIVE = true;

try

    tol = 1e-12;

% (i) Dimensions.
assert(isequal(size(S), [2,2]), 'computeSecondPiolaStress:S must be 2x2.');

% (ii) Symmetry.
assert(norm(S - S.', 'fro') < tol*max(1, norm(S,'fro')), ...
    'computeSecondPiolaStress:S is not symmetric.');

% (iii) Zero strain -> zero stress.
S0 = computeSecondPiolaStress(C4, zeros(2,2));
assert(norm(S0,'fro') < tol, 'computeSecondPiolaStress:zero-strain stress nonzero.');

% (iv) Uniaxial strain E_{11}=eps (others zero): S must equal
%      S_{11} = (lambda+2 mu) * eps, S_{22} = lambda * eps, S_{12}=0.
%      This is read directly from the isotropic tensor.
%      We build a generic C4 from a known lambda, mu using the same
%      formula as buildIsotropicC4 (without calling that file to keep
%      the check self-contained).
lam_test = 1.0;  mu_test = 0.6;
C4t = zeros(2,2,2,2);
delta = eye(2);
for I=1:2, for J=1:2, for K=1:2, for L=1:2
    C4t(I,J,K,L) = lam_test*delta(I,J)*delta(K,L) ...
                 + mu_test*(delta(I,K)*delta(J,L) + delta(I,L)*delta(J,K));
end; end; end; end
eps_t = 0.05;
Euni = zeros(2,2); Euni(1,1) = eps_t;
Suni = computeSecondPiolaStress(C4t, Euni);
assert(abs(Suni(1,1) - (lam_test+2*mu_test)*eps_t) < tol, ...
    'computeSecondPiolaStress:S11 wrong for uniaxial strain.');
assert(abs(Suni(2,2) - lam_test*eps_t) < tol, ...
    'computeSecondPiolaStress:S22 wrong for uniaxial strain.');
assert(abs(Suni(1,2)) < tol, 'computeSecondPiolaStress:S12 nonzero for uniaxial strain.');

% (v) Pure shear E_{12} = E_{21} = gam/2 (engineering-shear gam):
%     S_{12} = S_{21} = mu * gam.
gam = 0.02;
Eshear = zeros(2,2); Eshear(1,2) = gam/2; Eshear(2,1) = gam/2;
Sshear = computeSecondPiolaStress(C4t, Eshear);
assert(abs(Sshear(1,2) - mu_test*gam) < tol, ...
    'computeSecondPiolaStress:S12 wrong for pure shear.');
assert(abs(Sshear(1,2) - Sshear(2,1)) < tol);
assert(abs(Sshear(1,1))<tol && abs(Sshear(2,2))<tol, ...
    'computeSecondPiolaStress:diagonal stresses nonzero for pure shear.');

% (vi) Energy consistency: S = d psi_c / d E.  We verify this numerically
%      via a central finite difference on a random symmetric E, using
%      psi_c = (1/2) C4 : E : E (evaluated inline).  The perturbation
%      preserves E-symmetry (for off-diagonal entries both E_{IJ} and
%      E_{JI} are incremented), giving factors 2 dE for the diagonal
%      entries and 4 dE for off-diagonal entries in the central
%      difference.
rng(0);
Er = symmRand2();
Snum = zeros(2,2);
dE = 1e-6;
for I=1:2
    for J=I:2
        Ep = Er; Em = Er;
        if I == J
            Ep(I,J) = Ep(I,J) + dE;
            Em(I,J) = Em(I,J) - dE;
            Snum(I,J) = (psiC4(C4t,Ep) - psiC4(C4t,Em))/(2*dE);
        else
            Ep(I,J) = Ep(I,J) + dE;  Ep(J,I) = Ep(J,I) + dE;
            Em(I,J) = Em(I,J) - dE;  Em(J,I) = Em(J,I) - dE;
            Snum(I,J) = (psiC4(C4t,Ep) - psiC4(C4t,Em))/(4*dE);
            Snum(J,I) = Snum(I,J);
        end
    end
end
San = computeSecondPiolaStress(C4t, Er);
assert(norm(San - Snum, 'fro') < 1e-5*max(1,norm(San,'fro')), ...
    'computeSecondPiolaStress:numerical dpsi/dE mismatch.');

    function A = symmRand2()
        M = randn(2,2)*0.2;
        A = 0.5*(M + M.');
    end
    function v = psiC4(C, E_)
        v = 0;
        for ii=1:2, for jj=1:2, for kk=1:2, for ll=1:2
            v = v + 0.5*C(ii,jj,kk,ll)*E_(ii,jj)*E_(kk,ll);
        end; end; end; end
    end
SELFTEST_ACTIVE = false;

catch ME

SELFTEST_ACTIVE = false;
rethrow(ME);

end
end
