function psi = computeStrainEnergyDensity(C4, D6, E, G)
%COMPUTESTRAINENERGYDENSITY  Total strain-energy density for the
%           Saint-Venant--Kirchhoff + Mindlin Form-II gradient model
%           (plane strain).
%
%   psi = COMPUTESTRAINENERGYDENSITY(C4, D6, E, G)
%
% ----------------------------------------------------------------------
% Energy density (frozen Sec. 2, eqs. sec2_complete_energy_tensor and
% sec2_gradient_energy_invariants):
%
%   psi(E,G) = psi_c(E) + psi_g(G),
%
% with
%   psi_c = (1/2) C_{IJKL} E_{IJ} E_{KL}                              (SVK)
%   psi_g = (1/2) D_{IJKPQR} G_{IJK} G_{PQR}               (Form-II)
%
% and G_{IJK}=E_{IJ,K}.  The isotropic C4 (buildIsotropicC4) and D6
% (buildIsotropicD6) enforce all required symmetries, and psi is a
% scalar with units [Pa].
%
% For small deformations the energy reduces to the classical
% quadratic form used in the 2022 Torabi--Niiranen small-strain
% benchmark (Sec. 8, s7:K_2022); for the homogeneous (G = 0)
% classical case psi reduces to (lambda/2)(tr E)^2 + mu E:E.
%
% ----------------------------------------------------------------------
% Tensor dimensions / index ordering
% ----------------------------------------------------------------------
%   C4 : 2 x 2 x 2 x 2
%   D6 : 2 x 2 x 2 x 2 x 2 x 2
%   E  : 2 x 2           (symmetric)
%   G  : 2 x 2 x 2       (symmetric in (I,J))
%
% Output struct psi:
%   psi.classical  scalar       psi_c
%   psi.gradient   scalar       psi_g
%   psi.total      scalar       psi_c + psi_g
%
% Energy is strictly positive for non-zero (E,G) when the moduli are
% positive-definite (lambda+mu>0, mu>0, and the five D6 eigenvalues
% positive).  The routine does not assert material stability; it only
% checks that the energy real-numbers and matches S:E/2 and Sigma:G/2.
%
% See also COMPUTESECONDIOLASTRESS, COMPUTEDOUBLESTRESS,
% BUILDISOTROPICC4, BUILDISOTROPICD6.

% ======================================================================
% Input validation
% ======================================================================
assert(isnumeric(C4) && ndims(C4)>=4 && ...
    size(C4,1)==2 && size(C4,2)==2 && size(C4,3)==2 && size(C4,4)==2, ...
    'computeStrainEnergyDensity:C4 must be 2x2x2x2.');
assert(isnumeric(D6) && ndims(D6)>=6 && ...
    size(D6,1)==2 && size(D6,2)==2 && size(D6,3)==2 && ...
    size(D6,4)==2 && size(D6,5)==2 && size(D6,6)==2, ...
    'computeStrainEnergyDensity:D6 must be 2x2x2x2x2x2.');
assert(isnumeric(E) && isequal(size(E),[2,2]), ...
    'computeStrainEnergyDensity:E must be 2x2.');
assert(isnumeric(G) && ndims(G)>=3 && size(G,1)==2 && size(G,2)==2 && size(G,3)==2, ...
    'computeStrainEnergyDensity:G must be 2x2x2.');

persistent SELFTEST_ACTIVE
if isempty(SELFTEST_ACTIVE)
    SELFTEST_ACTIVE = false;
end

if SELFTEST_ACTIVE

    % Classical energy
    psi_c = 0;
    for I=1:2, for J=1:2, for K=1:2, for L=1:2
        psi_c = psi_c + 0.5*C4(I,J,K,L)*E(I,J)*E(K,L);
    end; end; end; end

    % Gradient energy
    psi_g = 0;
    for I=1:2, for J=1:2, for K=1:2
        for P=1:2, for Q=1:2, for R=1:2
            psi_g = psi_g + 0.5*D6(I,J,K,P,Q,R)*G(I,J,K)*G(P,Q,R);
        end; end; end
    end; end; end

    psi = struct();
    psi.classical = psi_c;
    psi.gradient  = psi_g;
    psi.total     = psi_c + psi_g;

    return;
end


% ======================================================================
% psi_c = (1/2) C4 : E : E  = (1/2) C_{IJKL} E_{IJ} E_{KL}.
% ======================================================================
psi_c = 0;
for I=1:2, for J=1:2, for K=1:2, for L=1:2
    psi_c = psi_c + 0.5*C4(I,J,K,L)*E(I,J)*E(K,L);
end; end; end; end

% ======================================================================
% psi_g = (1/2) D6 : G : G = (1/2) D_{IJKPQR} G_{IJK} G_{PQR}.
% ======================================================================
psi_g = 0;
for I=1:2, for J=1:2, for K=1:2
    for P=1:2, for Q=1:2, for R=1:2
        psi_g = psi_g + 0.5*D6(I,J,K,P,Q,R)*G(I,J,K)*G(P,Q,R);
    end; end; end
end; end; end

% ======================================================================
% Pack output.
% ======================================================================
psi = struct();
psi.classical = psi_c;
psi.gradient  = psi_g;
psi.total     = psi_c + psi_g;

% ======================================================================
% Internal verification
% ======================================================================
SELFTEST_ACTIVE = true;

try
    tol = 1e-12;

% (i) Output scalars and type sanity.
assert(isscalar(psi.classical) && isscalar(psi.gradient) && isscalar(psi.total), ...
    'computeStrainEnergyDensity:energy fields must be scalar.');
assert(isnumeric(psi.total), 'computeStrainEnergyDensity:psi.total must be numeric.');

% (ii) Undeformed state: E = 0, G = 0 -> psi = 0.
psi0 = computeStrainEnergyDensity(C4, D6, zeros(2,2), zeros(2,2,2));
assert(abs(psi0.classical) < tol && abs(psi0.gradient) < tol && abs(psi0.total) < tol, ...
    'computeStrainEnergyDensity:undeformed energy nonzero.');

% (iii) Rigid-body motion: any Q in SO(2) gives F=Q, E=0, G=0 -> psi=0.
for theta = [0, pi/6, -pi/4, pi/3]
    Q = [cos(theta), -sin(theta); sin(theta), cos(theta)];
    % For linear displacement giving F=Q: u = (Q-I)X, so gradU = Q-I,
    % E=0, G=0; energy is zero.
    psiR = computeStrainEnergyDensity(C4, D6, zeros(2,2), zeros(2,2,2));
    assert(abs(psiR.total) < tol, ...
        'computeStrainEnergyDensity:energy nonzero for rigid motion.');
end

% (iv) Classical-isotropy consistency: for the isotropic C4 (we build a
%      test one) and a symmetric E, psi_c must equal
%      (lambda/2)(tr E)^2 + mu E:E.
lam_t = 1.0; mu_t = 0.6;
delta = eye(2);
C4t = zeros(2,2,2,2);
for I=1:2, for J=1:2, for K=1:2, for L=1:2
    C4t(I,J,K,L) = lam_t*delta(I,J)*delta(K,L) ...
                 + mu_t*(delta(I,K)*delta(J,L) + delta(I,L)*delta(J,K));
end; end; end; end
% Use a simple D6 proxy (any is okay; here the production D6 from the
% input is not used in the classical test).
D6dummy = zeros(2,2,2,2,2,2);
D6dummy(1,1,1,1,1,1) = 1;  % non-symmetric but unused since G=0 for classical-only test

rng(3);
Etest = randn(2,2)*0.1; Etest = 0.5*(Etest+Etest.');
trE = Etest(1,1)+Etest(2,2);
EdotE = sum(Etest(:).*Etest(:));
psiIso = computeStrainEnergyDensity(C4t, D6dummy, Etest, zeros(2,2,2));
psiExpected = 0.5*lam_t*trE^2 + mu_t*EdotE;
assert(abs(psiIso.classical - psiExpected) < 1e-10*(1+abs(psiExpected)), ...
    'computeStrainEnergyDensity:classical isotropic form mismatch.');

% (v) Energy / stress consistency: for any E and G we must have
%        psi_c = (1/2) S : E,     psi_g = (1/2) Sigma : G,
%     because S = C4:E and Sigma = D6:G.  We check this by recomputing
%     S and Sigma inline using explicit contractions (no dependency on
%     the stress files; self-contained).
% Classical:
S_c = zeros(2,2);
for I=1:2, for J=1:2
    for K=1:2, for L=1:2
        S_c(I,J) = S_c(I,J) + C4(I,J,K,L)*E(K,L);
    end; end
end; end
S_c = 0.5*(S_c + S_c.');
SE = 0;
for I=1:2, for J=1:2
    SE = SE + S_c(I,J)*E(I,J);
end; end
assert(abs(psi_c - 0.5*SE) < 1e-10*(1+abs(psi_c)), ...
    'computeStrainEnergyDensity:psi_c != (1/2) S:E.');

% Gradient:
Sig = zeros(2,2,2);
for I=1:2, for J=1:2, for K=1:2
    for P=1:2, for Q=1:2, for R=1:2
        Sig(I,J,K) = Sig(I,J,K) + D6(I,J,K,P,Q,R)*G(P,Q,R);
    end; end; end
end; end; end
for I=1:2
    for J=I+1:2
        for K=1:2
            a = 0.5*(Sig(I,J,K)+Sig(J,I,K)); Sig(I,J,K)=a; Sig(J,I,K)=a;
        end
    end
end
SG = 0;
for I=1:2, for J=1:2, for K=1:2
    SG = SG + Sig(I,J,K)*G(I,J,K);
end; end; end
assert(abs(psi_g - 0.5*SG) < 1e-10*(1+abs(psi_g)), ...
    'computeStrainEnergyDensity:psi_g != (1/2) Sigma:G.');

% (vi) Homogeneous classical deformation (G=0) gives psi_g = 0.
psi_h = computeStrainEnergyDensity(C4t, D6dummy, Etest, zeros(2,2,2));
assert(abs(psi_h.gradient) < tol, ...
    'computeStrainEnergyDensity:psi_g nonzero for G=0.');

% (vii) Energy positivity: for the canonical positive isotropic moduli
% used in buildIsotropicC4/D6 (lam+mu>0, mu>0, a_i chosen so that the
% quadratic form is positive) the energy must be nonnegative for E=0,
% random G and vice-versa, within numerical tolerance.  We use the
% actual D6 passed in (by the caller) to verify this.
Ezero = zeros(2,2); Gzero = zeros(2,2,2);
rng(5);
Ernd = randn(2,2)*0.1; Ernd = 0.5*(Ernd+Ernd.');
Grnd = zeros(2,2,2);
for I=1:2, for J=I:2
    Grnd(I,J,:) = randn(1,2)*0.05; Grnd(J,I,:) = Grnd(I,J,:);
end; end
psiE = computeStrainEnergyDensity(C4, D6, Ernd, Gzero);
psiG = computeStrainEnergyDensity(C4, D6, Ezero, Grnd);
% We only check that the energies are finite; strong positivity
% depends on the moduli supplied (the caller is responsible for
% stable material parameters).
assert(isfinite(psiE.total) && isfinite(psiG.total), ...
    'computeStrainEnergyDensity:energy is not finite for random input.');

SELFTEST_ACTIVE = false;

catch ME

SELFTEST_ACTIVE = false;
rethrow(ME);

end

end
