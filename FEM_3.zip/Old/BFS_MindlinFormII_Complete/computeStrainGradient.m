function G = computeStrainGradient(gradU, gradGradU)
%COMPUTESTRAINGRADIENT  Evaluate the Green--Lagrange strain-gradient
%        tensor G_{IJK} = dE_{IJ}/dX_K (plane strain) from the first
%        and second displacement gradients.
%
%   G = COMPUTESTRAINGRADIENT(gradU, gradGradU)
%
% ----------------------------------------------------------------------
% Physical and mathematical context (frozen Sec. 2; eq. n_Gcompu)
% ----------------------------------------------------------------------
% In the Total-Lagrangian plane-strain formulation, the Green--
% Lagrange strain is
%     E_{IJ} = (1/2)(u_{I,J} + u_{J,I} + u_{k,I} u_{k,J}),   k in {1,2}.
% The strain-gradient tensor is its reference-coordinate gradient,
%     G_{IJK} = ∂E_{IJ}/∂X_K
%             = (1/2)[ u_{I,JK} + u_{J,IK}
%                    + u_{k,IK} u_{k,J} + u_{k,I} u_{k,JK} ],
% where repeated k is summed over the two in-plane coordinates.
% This tensor inherits the minor symmetry G_{IJK} = G_{JIK} from E,
% but is not symmetric in J,K or I,K in general when the geometric
% nonlinearity (u_{,I} u_{,J}) is active.  It is the tensor that is
% contracted with the 6th-order isotropic modulus D6 to produce the
% double stress Sigma = D6 : G (constitutive/computeSigma.m).
%
% The input gradGradU contains the second physical derivatives of
% the displacement field:
%     gradGradU(i, J, K) = ∂^2 u_i / ∂X_J ∂X_K.
% It is symmetric in J,K (because partial derivatives commute on the
% C^1 BFS interpolated displacement field), but the routine does not
% require that; it uses the supplied values directly.
%
% ----------------------------------------------------------------------
% Tensor dimensions and index ordering
% ----------------------------------------------------------------------
%   gradU     : 2 x 2          gradU(i,J)   = ∂u_i/∂X_J
%   gradGradU : 2 x 2 x 2      gradGradU(i,J,K) = ∂²u_i/∂X_J∂X_K
%   G         : 2 x 2 x 2      G(I,J,K)     = ∂E_{IJ}/∂X_K
%
% After assembly the result is symmetrised over (I,J) to guarantee
% G_{IJK} = G_{JIK} to machine precision, regardless of any rounding
% asymmetry in gradGradU.
%
% Equation mapping:
%   eq. (n_GcompF) : G in terms of F and Grad F
%   eq. (n_Gcompu) : G in terms of u_{,I} and u_{,IK} (used here)
%   eq. (sec2_D_symmetries) : G_{IJK}=G_{JIK} minor symmetry
%
% The infinitesimal (small-strain) limit,
%     G^{lin}_{IJK} = (1/2)(u_{I,JK} + u_{J,IK}),
% is obtained exactly whenever the geometric products u_{k,I} u_{k,JK}
% and u_{k,IK} u_{k,J} are negligible; this is the strain gradient
% used in the Torabi--Niiranen (2022) small-strain Form-II benchmark
% (Sec. 8, recovery of eq. s7:K_2022).
%
% See also COMPUTEDEFORMATIONGRADIENT, COMPUTEGREENLAGRANGESTRAIN.

% ======================================================================
% Input validation
% ======================================================================
assert(isnumeric(gradU) && isequal(size(gradU), [2,2]), ...
    'computeStrainGradient:gradU must be a 2x2 matrix.');
assert(isnumeric(gradGradU) && ndims(gradGradU) >= 2, ...
    'computeStrainGradient:gradGradU must be a 2x2x2 array.');
% Allow 2x2x2 or higher-dim trailing 1.
assert(size(gradGradU,1)==2 && size(gradGradU,2)==2 && size(gradGradU,3)==2, ...
    'computeStrainGradient:gradGradU must be 2x2x2.');
persistent SELFTEST_ACTIVE
if isempty(SELFTEST_ACTIVE)
    SELFTEST_ACTIVE = false;
end

if SELFTEST_ACTIVE

    G = zeros(2,2,2);

    for I = 1:2
        for J = 1:2
            for K = 1:2
                s = 0.5*( gradGradU(I,J,K) + gradGradU(J,I,K) );
                for k = 1:2
                    s = s + 0.5*( gradGradU(k,I,K)*gradU(k,J) ...
                                + gradU(k,I)*gradGradU(k,J,K) );
                end
                G(I,J,K) = s;
            end
        end
    end

    for I = 1:2
        for J = I+1:2
            for K = 1:2
                avg = 0.5*(G(I,J,K)+G(J,I,K));
                G(I,J,K)=avg;
                G(J,I,K)=avg;
            end
        end
    end

    return;
end


% ======================================================================
% Assemble G_{IJK} = 1/2 ( u_{I,JK} + u_{J,IK}
%                           + u_{k,IK} u_{k,J} + u_{k,I} u_{k,JK} ).
% ======================================================================
G = zeros(2,2,2);
for I = 1:2
    for J = 1:2
        for K = 1:2
            s = 0.5*( gradGradU(I,J,K) + gradGradU(J,I,K) );
            for k = 1:2
                s = s + 0.5*( gradGradU(k,I,K)*gradU(k,J) ...
                            + gradU(k,I)*gradGradU(k,J,K) );
            end
            G(I,J,K) = s;
        end
    end
end

% ======================================================================
% Exact (I,J) symmetrisation to remove any round-off asymmetry.
% (The construction above is already algebraically symmetric in I,J;
%  the averaging is a defensive machine-precision projection.)
% ======================================================================
for I = 1:2
    for J = I+1:2
        for K = 1:2
            avg = 0.5*(G(I,J,K) + G(J,I,K));
            G(I,J,K) = avg;
            G(J,I,K) = avg;
        end
    end
end

% ======================================================================
% Internal verification
% ======================================================================
SELFTEST_ACTIVE = true;

try

tol = 1e-12;
% (i) Dimensions.
assert(isequal(size(G), [2,2,2]), ...
    'computeStrainGradient:G must be 2x2x2.');

% (ii) Minor (I,J) symmetry.
for I = 1:2
    for J = 1:2
        for K = 1:2
            assert(abs(G(I,J,K) - G(J,I,K)) < tol*max(1,abs(G(I,J,K))), ...
                'computeStrainGradient:fails G_{IJK}=G_{JIK} symmetry.');
        end
    end
end

% (iii) Undeformed configuration: gradU = 0, gradGradU = 0 -> G = 0.
G0 = computeStrainGradient(zeros(2,2), zeros(2,2,2));
assert(norm(G0(:)) < tol, ...
    'computeStrainGradient:G must be zero in undeformed configuration.');

% (iv) Rigid-body translation (constant u => all derivatives zero):
%      covered by (iii); check constant field explicitly.
Gt = computeStrainGradient(zeros(2,2), zeros(2,2,2));
assert(norm(Gt(:)) < tol);

% (v) Homogeneous / constant-strain deformation (gradU = const,
%      gradGradU = 0): G must vanish because E is constant.
for trial = 1:5
    gu = randn(2,2)*0.5;            % arbitrary constant displacement gradient
    Gc = computeStrainGradient(gu, zeros(2,2,2));
    assert(norm(Gc(:)) < tol, ...
        'computeStrainGradient:G must vanish for homogeneous deformation.');
end

% (vi) Rigid-body rotation (Q orthogonal, F=Q => E=0 => G=0):
%      u_i = (Q_{iJ}-δ_{iJ}) X_J is linear, so gradGradU = 0, hence
%      G = 0 by the same argument as (v).  Verify for several angles.
for theta = [0, pi/6, -pi/4, pi/3]
    Q = [cos(theta), -sin(theta); sin(theta), cos(theta)];
    Grot = computeStrainGradient(Q - eye(2), zeros(2,2,2));
    assert(norm(Grot(:)) < 1e-12, ...
        'computeStrainGradient:G must vanish for rigid-body rotation.');
end

% (vii) Infinitesimal-strain limit: when gradU = epsilon*h (small),
%       the nonlinear (geometric) terms are O(eps^2) and G must
%       reduce to the classical small-strain gradient
%       G_lin = (1/2)(u_{I,JK}+u_{J,IK}) to within O(eps).
ep = 1e-5;
rng(42);
h  = randn(2,2);
hh = randn(2,2,2);              % second derivatives O(1)
gu = ep*h;
Gl = computeStrainGradient(gu, hh);
% Linearised G:
Glin = zeros(2,2,2);
for I=1:2
    for J=1:2
        for K=1:2
            Glin(I,J,K) = 0.5*(hh(I,J,K)+hh(J,I,K));
        end
    end
end
% Symmetrise Glin.
for I=1:2
    for J=I+1:2
        for K=1:2
            a = 0.5*(Glin(I,J,K)+Glin(J,I,K)); Glin(I,J,K)=a; Glin(J,I,K)=a;
        end
    end
end
err = max(abs(Gl(:)-Glin(:)));
assert(err < 10*ep, ...   % allow O(ep) because the nonlinear terms are O(ep)
    'computeStrainGradient:infinitesimal-limit recovery failed.');

% (viii) Uniaxial quadratic displacement test: for u1 = alpha X1^2, u2=0,
%       the field is not infinitesimal.  Compute analytical G and compare.
%       u_{1,1}=2 alpha X1; u_{1,11}=2 alpha; all other derivatives 0.
%       Then E_{11}=0.5*(2u_{1,1}+u_{1,1}^2)=2 alpha X1 + 2 alpha^2 X1^2
%       E_{12}=E_{21}=0.5*(u_{1,2}+u_{2,1}+u_{1,1}u_{1,2}+...) = 0 (u_{1,2}=0)
%       E_{22}=0.
%       G_{111} = dE_{11}/dX1 = 2 alpha + 4 alpha^2 X1; all other G=0.
alpha = 0.3;
x1 = 0.7;
gu_test = zeros(2,2); gu_test(1,1) = 2*alpha*x1;
hhu = zeros(2,2,2);    hhu(1,1,1) = 2*alpha;
G_uniax = computeStrainGradient(gu_test, hhu);
G_expect = zeros(2,2,2);
G_expect(1,1,1) = 2*alpha + 4*alpha^2*x1;
assert(max(abs(G_uniax(:)-G_expect(:))) < tol, ...
    'computeStrainGradient:analytical uniaxial-quadratic test failed.');
% Also G_{111} = G_{111} (symmetry trivial here), and G(2,2,*) = 0.
assert(abs(G_uniax(2,2,1))+abs(G_uniax(1,2,1))+abs(G_uniax(1,2,2)) < tol);

% (ix) Pure-bending style check: u1 = -a X2^2, u2 = 0.
%       u_{1,2} = -2a X2; u_{1,22} = -2a; others zero.
%       E_{11} = 0.5*(2u_{1,1}+u_{k,1}^2) = 0 (u_{1,1}=0)
%       E_{22} = 0.5*(2u_{2,2}+u_{k,2}^2) = 0.5*(0 + u_{1,2}^2)= 2 a^2 X2^2
%       E_{12} = 0.5*(u_{1,2}+u_{2,1}+u_{k,1}u_{k,2}) = 0.5*u_{1,2} = -a X2
%       G_{222} = dE_{22}/dX2 = 4 a^2 X2
%       G_{122} = G_{212} = dE_{12}/dX2 = -a
a_ = 0.2; x2 = 0.6;
gu_b = zeros(2,2); gu_b(1,2) = -2*a_*x2;
hhu_b = zeros(2,2,2); hhu_b(1,2,2) = -2*a_;
G_b = computeStrainGradient(gu_b, hhu_b);
Ge_b = zeros(2,2,2);
Ge_b(2,2,2) = 4*a_^2*x2;
Ge_b(1,2,2) = -a_;  Ge_b(2,1,2) = -a_;
assert(max(abs(G_b(:)-Ge_b(:))) < tol, ...
    'computeStrainGradient:analytical bending test failed.');
SELFTEST_ACTIVE = false;

catch ME

SELFTEST_ACTIVE = false;
rethrow(ME);

end

end
