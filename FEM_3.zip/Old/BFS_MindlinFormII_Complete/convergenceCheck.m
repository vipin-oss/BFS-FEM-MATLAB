function [conv, norms, diagnostics] = convergenceCheck(R, dD, dD0, R0, opts)
%CONVERGENCECHECK  Evaluate the three-norm Newton convergence criteria for
%                  the BFS Mindlin Form-II nonlinear solver.
%
%   [conv, norms, diag] = CONVERGENCECHECK(R, dD, dD0, R0)
%   [conv, norms, diag] = CONVERGENCECHECK(R, dD, dD0, R0, opts)
%
% ----------------------------------------------------------------------
% Convergence criteria (frozen Sec. 9; default tolerances 1e-8)
% ----------------------------------------------------------------------
% At each Newton iteration k we compute three scalar measures:
%
%   eta_R(k) = || R(k) ||_2  / ( || R(0) ||_2  + RTOL_ABS )            (residual)
%   eta_D(k) = ||dD(k)||_2   / ( ||dD(0)||_2   + DTOL_ABS )            (increment)
%   eta_E(k) = | dD(k)' R(k) | / ( |dD(0)' R(0)| + ETOL_ABS )          (energy)
%
% Convergence is declared when ALL three criteria fall below their
% respective tolerances simultaneously.  For the very first iteration
% of a new load step (k=0, i.e. immediately after initial prediction),
% dD0 is the dD from the initial residual R0; in subsequent steps
% dD0 and R0 remain the reference norms from iteration 0 of the
% current load step.
%
% Absolute tolerances are added to avoid spurious convergence /
% division-by-zero on problems with zero external load or zero
% displacement increment.
%
% Divergence detection: if any norm exceeds opts.divergenceTol times
% its reference, or if NaN/Inf appears, conv = -1 (diverged).
%
% ----------------------------------------------------------------------
% Inputs
% ----------------------------------------------------------------------
%   R       : nDOF x 1 current residual vector  (R_int - R_ext sign:
%             Newton solves K*dD = -R).
%   dD      : nDOF x 1 current Newton increment.
%   dD0     : nDOF x 1 Newton increment from iteration 0 of the current
%             load step (reference for relative increment/energy).
%   R0      : nDOF x 1 residual from iteration 0 of the current load
%             step (reference for relative residual).
%   opts    : (optional) struct of tolerance/control parameters:
%               .tolR       residual  tol (default 1e-8)
%               .tolD       increment tol (default 1e-8)
%               .tolE       energy    tol (default 1e-8)
%               .tolR_abs   absolute residual floor   (default 1e-12)
%               .tolD_abs   absolute increment floor  (default 1e-12)
%               .tolE_abs   absolute energy floor     (default 1e-12)
%               .divergenceTol  factor for divergence detection
%                               (default 1e6; set inf to disable).
%
% Outputs
%   conv    : convergence flag
%               1  converged (all three criteria satisfied)
%               0  not yet converged (keep iterating)
%              -1  diverged  (NaN/Inf or blow-up)
%   norms   : struct with scalar norms
%               .nR, .nD, .nE        current absolute L2 values
%               .nR0, .nD0, .nE0     reference (iter-0) values
%               .etaR, .etaD, .etaE  relative measures
%   diag    : struct with per-criterion booleans
%               .residualOK, .incrementOK, .energyOK
%               .diverged, .reason (string)
%
% Equation mapping: standard three-norm Newton convergence monitors
% used in nonlinear solid mechanics (Crisfield, Wriggers), compatible
% with frozen Sec. 9 N-R specification (tol=tolD=tolE=1e-8, kMax=20).
%
% See also NEWTONRAPHSONSOLVER, SOLVELOADSTEP.

% ======================================================================
% Default tolerances (frozen Sec. 9)
% ======================================================================
if nargin < 5 || isempty(opts); opts = struct(); end
if ~isfield(opts,'tolR'); opts.tolR = 1e-8; end
if ~isfield(opts,'tolD'); opts.tolD = 1e-8; end
if ~isfield(opts,'tolE'); opts.tolE = 1e-8; end
if ~isfield(opts,'tolR_abs'); opts.tolR_abs = 1e-12; end
if ~isfield(opts,'tolD_abs'); opts.tolD_abs = 1e-12; end
if ~isfield(opts,'tolE_abs'); opts.tolE_abs = 1e-12; end
if ~isfield(opts,'divergenceTol'); opts.divergenceTol = 1e6; end

% ======================================================================
% Input validation
% ======================================================================
R  = R(:);   dD = dD(:);
R0 = R0(:);  dD0 = dD0(:);
nDOF = length(R);
assert(length(dD)==nDOF && length(R0)==nDOF && length(dD0)==nDOF, ...
    'convergenceCheck:R, dD, R0, dD0 must have matching length.');
assert(isnumeric(opts.tolR) && isnumeric(opts.tolD) && isnumeric(opts.tolE), ...
    'convergenceCheck:tolR/tolD/tolE must be numeric.');
assert(opts.tolR>0 && opts.tolD>0 && opts.tolE>0, ...
    'convergenceCheck:tolerances must be positive.');

% ======================================================================
% Compute scalar norms
% ======================================================================
nR   = norm(R,2);
nD   = norm(dD,2);
nE   = abs(dD(:).'*R(:));
nR0  = norm(R0,2);
nD0  = norm(dD0,2);
nE0  = abs(dD0(:).'*R0(:));

% Relative measures (with absolute safety floors).
etaR = nR / (nR0 + opts.tolR_abs);
etaD = nD / (nD0 + opts.tolD_abs);
etaE = nE / (nE0 + opts.tolE_abs);

% ======================================================================
% Divergence check (NaN/Inf or catastrophic blow-up)
% ======================================================================
reason = '';
diverged = false;
if ~isfinite(nR) || ~isfinite(nD) || ~isfinite(nE)
    diverged = true;
    reason   = 'NaN/Inf detected in norms.';
elseif isfinite(opts.divergenceTol) && ...
       (etaR > opts.divergenceTol || etaD > opts.divergenceTol || etaE > opts.divergenceTol)
    diverged = true;
    reason   = sprintf('Norms exceeded divergence factor (%g).', opts.divergenceTol);
end

residualOK  = etaR <= opts.tolR;
incrementOK = etaD <= opts.tolD;
energyOK    = etaE <= opts.tolE;

if diverged
    conv = -1;
elseif residualOK && incrementOK && energyOK
    conv = 1;
    reason = 'All three criteria satisfied.';
else
    conv = 0;
    parts = {};
    if ~residualOK;  parts{end+1} = 'residual'; end
    if ~incrementOK; parts{end+1} = 'increment'; end
    if ~energyOK;    parts{end+1} = 'energy'; end
    reason = ['Not yet converged on: ' strjoin(parts,', ') '.'];
end

% ======================================================================
% Pack outputs
% ======================================================================
norms = struct('nR',nR,'nD',nD,'nE',nE, ...
               'nR0',nR0,'nD0',nD0,'nE0',nE0, ...
               'etaR',etaR,'etaD',etaD,'etaE',etaE);
diagnostics = struct('residualOK',residualOK, ...
                     'incrementOK',incrementOK, ...
                     'energyOK',energyOK, ...
                     'diverged',diverged, ...
                     'reason',reason);
end
