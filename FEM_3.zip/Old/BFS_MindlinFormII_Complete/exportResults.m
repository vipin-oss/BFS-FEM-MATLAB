function status = exportResults(pp, varargin)
%EXPORTRESULTS  Export post-processed Module-13/14 results to disk in
%               MAT / CSV / TXT and publication-quality figure formats.
%
%   status = EXPORTRESULTS(pp)
%   status = EXPORTRESULTS(pp, 'Name',Value,...)
%
% ----------------------------------------------------------------------
% Exports
% ----------------------------------------------------------------------
%   - pp struct (and its .hist/.gp subfields) to a .mat file.
%   - Nodal scalar fields to CSV (one column per field).
%   - Element strain energies to CSV.
%   - Load--displacement / iteration history to CSV.
%   - Reactions at essential DOFs to CSV.
%   - Summary TXT file with diagnostics (Wtotal, ||R||, nIter,
%     lambda, field extrema).
%   - Currently-open figures to PNG/PDF/EPS (configurable).
%
% Options (defaults in parentheses):
%   outdir       output directory                       ('results')
%   baseName     base filename prefix                   ('bfs_mindlin')
%   saveMAT      export .mat                            (true)
%   saveCSV      export .csv                            (true)
%   saveTXT      export summary .txt                    (true)
%   saveFigures  export currently-open figures          (true)
%   figFormats   cell in {'png','pdf','eps'}            ({'png','pdf'})
%   figDPI       raster DPI for png                     (300)
%   nodalFields  cell of pp.nodal field names to write  (all scalars)
%
% Output:
%   status       struct with .files (cell of written paths), .ok, .outdir.
%
% See also POSTPROCESSRESULTS, PLOTRESULTS.

ip = inputParser;
addParameter(ip,'outdir','results',@ischar);
addParameter(ip,'baseName','bfs_mindlin',@ischar);
addParameter(ip,'saveMAT',true,@(x) islogical(x)||x==0||x==1);
addParameter(ip,'saveCSV',true,@(x) islogical(x)||x==0||x==1);
addParameter(ip,'saveTXT',true,@(x) islogical(x)||x==0||x==1);
addParameter(ip,'saveFigures',true,@(x) islogical(x)||x==0||x==1);
addParameter(ip,'figFormats',{'png','pdf'},@(x) iscell(x)||ischar(x));
addParameter(ip,'figDPI',300,@(x) isnumeric(x)&&isscalar(x)&&x>0);
addParameter(ip,'nodalFields',{},@iscell);
parse(ip,varargin{:});
o = ip.Results;

if ischar(o.figFormats); o.figFormats = {o.figFormats}; end

assert(isstruct(pp) && isfield(pp,'nodal') && isfield(pp,'hist'), ...
    'exportResults:pp must be the struct returned by postProcessResults.');

[~,~,~] = mkdir(o.outdir);
files = {};
ok    = true;

% ======================================================================
% 1. MAT export (full pp struct).
% ======================================================================
if o.saveMAT
    try
        p = mkpath(o.outdir,o.baseName,pp.stepIndex,'.mat','');
        save(p,'pp','-v7');
        files{end+1} = p;
    catch ME
        ok = false;
        warning('exportResults:MAT export failed: %s', ME.message);
    end
end

% ======================================================================
% 2. CSV exports.
% ======================================================================
if o.saveCSV
    try
        nd = pp.nNodes;
        flds = o.nodalFields;
        if isempty(flds)
            f = fieldnames(pp.nodal);
            flds = {};
            for kk = 1:length(f)
                v = pp.nodal.(f{kk});
                if isnumeric(v) && isequal(size(v),[nd,1])
                    flds{end+1} = f{kk};
                end
            end
        end
        nC = 4 + length(flds);
        H  = [{'X1','X2','x1','x2'}, flds];
        M  = zeros(nd, nC);
        M(:,1) = pp.X(:,1); M(:,2) = pp.X(:,2);
        M(:,3) = pp.x(:,1); M(:,4) = pp.x(:,2);
        for kk=1:length(flds)
            v = pp.nodal.(flds{kk});
            assert(isequal(size(v),[nd,1]), ...
                'exportResults:nodal field %s wrong size.', flds{kk});
            M(:,4+kk) = v;
        end
        p = mkpath(o.outdir,o.baseName,pp.stepIndex,'.csv','nodal');
        writeCSV(p, H, M);
        files{end+1} = p;

        % Element energies.
        We = pp.W_e(:);
        eid = (1:length(We)).';
        p = mkpath(o.outdir,o.baseName,pp.stepIndex,'.csv','elementEnergy');
        writeCSV(p, {'elem','W_e'}, [eid, We]);
        files{end+1} = p;

        % Load / iteration history.
        lam = pp.hist.lambda(:);
        nIt = pp.hist.nIter(:);
        cvg = double(pp.hist.converged(:));
        p = mkpath(o.outdir,o.baseName,pp.stepIndex,'.csv','history');
        writeCSV(p, {'lambda','nIter','converged'}, [lam, nIt, cvg]);
        files{end+1} = p;

        % Reactions at essential DOFs.
        Rxn = pp.Rxn(:);
        nz = abs(Rxn) > 0;
        idx = find(nz);
        val = Rxn(nz);
        p = mkpath(o.outdir,o.baseName,pp.stepIndex,'.csv','reactions');
        writeCSV(p, {'dof','Rxn'}, [idx, val]);
        files{end+1} = p;
    catch ME
        ok = false;
        warning('exportResults:CSV export failed: %s', ME.message);
    end
end

% ======================================================================
% 3. Summary TXT.
% ======================================================================
if o.saveTXT
    try
        p = mkpath(o.outdir,o.baseName,pp.stepIndex,'.txt','summary');
        fid = fopen(p,'w');
        fprintf(fid,'BFS Mindlin Form-II FE -- analysis summary\n');
        fprintf(fid,'-----------------------------------------\n');
        fprintf(fid,'step index        : %d\n', pp.stepIndex);
        fprintf(fid,'load factor lambda: %g\n', pp.lambda);
        fprintf(fid,'mesh              : %d nodes, %d elements\n', pp.nNodes, pp.nElem);
        fprintf(fid,'total GP count    : %d\n', pp.nGP_total);
        fprintf(fid,'total strain energy W = %.10e\n', pp.Wtotal);
        fprintf(fid,'min/max nodal psi : [%g, %g]\n', min(pp.nodal.psi), max(pp.nodal.psi));
        fprintf(fid,'min/max E11       : [%g, %g]\n', min(pp.nodal.E11), max(pp.nodal.E11));
        fprintf(fid,'min/max S11       : [%g, %g]\n', min(pp.nodal.S11), max(pp.nodal.S11));
        fprintf(fid,'max |u1|           : %g\n', max(abs(pp.nodal.u1)));
        fprintf(fid,'max |u2|           : %g\n', max(abs(pp.nodal.u2)));
        fprintf(fid,'finalConv          : %d\n', double(pp.hist.finalConv));
        fprintf(fid,'total Newton iter  : %d\n', pp.hist.totalIter);
        fprintf(fid,'n load steps       : %d\n', pp.hist.nLam-1);
        fclose(fid);
        files{end+1} = p;
    catch ME
        ok = false;
        warning('exportResults:TXT export failed: %s', ME.message);
    end
end

% ======================================================================
% 4. Figure export (all currently-open figures).
% ======================================================================
if o.saveFigures
    try
        figs = findall(0,'Type','figure');
        for kk = 1:length(figs)
            fh = figs(kk);
            num = fh.Number;
            for ff = 1:length(o.figFormats)
                fmt = lower(o.figFormats{ff});
                switch fmt
                    case 'png'
                        p = mkpath(o.outdir,o.baseName,pp.stepIndex,'.png',sprintf('fig%d',num));
                        print(fh, p, '-dpng', ['-r',num2str(o.figDPI)]);
                    case 'eps'
                        p = mkpath(o.outdir,o.baseName,pp.stepIndex,'.eps',sprintf('fig%d',num));
                        print(fh, p, '-depsc2');
                    case 'pdf'
                        p = mkpath(o.outdir,o.baseName,pp.stepIndex,'.pdf',sprintf('fig%d',num));
                        print(fh, p, '-dpdf','-bestfit');
                    otherwise
                        warning('exportResults:unknown fig format ''%s''.',fmt);
                        continue;
                end
                files{end+1} = p;
            end
        end
    catch ME
        ok = false;
        warning('exportResults:figure export failed: %s', ME.message);
    end
end

status = struct('ok',ok,'files',{files},'outdir',o.outdir,'baseName',o.baseName);
end

% =========================================================================
% LOCAL SUBFUNCTIONS (non-nested)
% =========================================================================
function p = mkpath(outdir,baseName,stepIndex,ext,tag)
if nargin < 5 || isempty(tag)
    fname = sprintf('%s_step%d%s', baseName, stepIndex, ext);
else
    fname = sprintf('%s_%s_step%d%s', baseName, tag, stepIndex, ext);
end
p = fullfile(outdir, fname);
end

function writeCSV(path, headers, data)
fid = fopen(path,'w');
if fid < 0
    error('exportResults:cannot open %s for writing.',path);
end
fprintf(fid,'%s', headers{1});
for k=2:length(headers)
    fprintf(fid,',%s', headers{k});
end
fprintf(fid,'\n');
fmt = [repmat('%.15e,',1,size(data,2)-1) '%.15e\n'];
for r = 1:size(data,1)
    fprintf(fid,fmt,data(r,:));
end
fclose(fid);
end
