function gauss = gaussQuadrature(rule)
%GAUSSQUADRATURE Gauss-Legendre tensor-product quadrature on [-1,1]^2.
%
%   gauss = gaussQuadrature(rule)
%   gauss = gaussQuadrature()
%
% Frozen Section 7:
%   - 3x3 Gauss-Legendre quadrature is the adopted BFS volume rule.
%   - 3-point 1D data are also returned for edge integration.
%   - The 2x2 rule is retained only as a supported reduced/debug rule.

% ---------------------------------------------------------------------
% Default rule.
% ---------------------------------------------------------------------
if nargin < 1 || isempty(rule)
    rule = 'auto';
end

% ---------------------------------------------------------------------
% Parse the requested rule.
% ---------------------------------------------------------------------
if isnumeric(rule)
    assert(isreal(rule) && isfinite(rule) && isscalar(rule) && ...
           any(rule == [2, 3]), ...
        'gaussQuadrature:numeric rule must be the scalar 2 or 3.');

    ng = rule;
    ruleStr = sprintf('%dx%d', ng, ng);

elseif ischar(rule) || (exist('isstring', 'builtin') && isstring(rule))
    rule = char(rule);
    assert(isrow(rule), ...
        'gaussQuadrature:string rule must be a scalar character row.');

    switch lower(strtrim(rule))
        case {'2x2', '2'}
            ng = 2;
            ruleStr = '2x2';

        case {'3x3', '3'}
            ng = 3;
            ruleStr = '3x3';

        case 'auto'
            ng = 3;
            ruleStr = '3x3 (auto)';

        otherwise
            error('gaussQuadrature:unsupported rule "%s".', rule);
    end

else
    error(['gaussQuadrature:rule must be numeric 2/3 or string ' ...
           '''2x2''/''3x3''/''auto''.']);
end

% ---------------------------------------------------------------------
% Build the 1D Gauss-Legendre rule on [-1,1].
% ---------------------------------------------------------------------
switch ng
    case 2
        p = 1/sqrt(3);
        xi1D = [-p; p];
        w1D = [1; 1];

    case 3
        p = sqrt(3/5);
        xi1D = [-p; 0; p];
        w1D = [5/9; 8/9; 5/9];

    otherwise
        error('gaussQuadrature:internal error; ng = %d is unsupported.', ng);
end

% ---------------------------------------------------------------------
% Tensor-product 2D rule.  Index k=(i-1)*ng+j, with xi outer and eta
% inner, matches the documented Section 7 ordering.
% ---------------------------------------------------------------------
nGP = ng*ng;
W = w1D*w1D.';

xi = zeros(nGP, 1);
eta = zeros(nGP, 1);
w = zeros(nGP, 1);

k = 0;
for i = 1:ng
    for j = 1:ng
        k = k + 1;
        xi(k) = xi1D(i);
        eta(k) = xi1D(j);
        w(k) = w1D(i)*w1D(j);
    end
end

% ---------------------------------------------------------------------
% Pack output.
% ---------------------------------------------------------------------
gauss = struct();
gauss.ng = ng;
gauss.nGP = nGP;
gauss.xi1D = xi1D;
gauss.w1D = w1D;
gauss.xi = xi;
gauss.eta = eta;
gauss.w = w;
gauss.W = W;
gauss.rule = ruleStr;

% ---------------------------------------------------------------------
% Internal verification.
% ---------------------------------------------------------------------
tol = 1e-12;

assert(numel(gauss.xi1D) == ng && numel(gauss.w1D) == ng, ...
    'gaussQuadrature:1D rule has wrong length.');

assert(numel(gauss.xi) == nGP && numel(gauss.eta) == nGP && ...
       numel(gauss.w) == nGP, ...
    'gaussQuadrature:2D rule has wrong length.');

assert(isequal(size(gauss.W), [ng, ng]), ...
    'gaussQuadrature:W must be ng x ng.');

assert(all(gauss.xi1D >= -1 - tol) && all(gauss.xi1D <= 1 + tol), ...
    'gaussQuadrature:1D points outside [-1,1].');

assert(all(gauss.xi >= -1 - tol) && all(gauss.xi <= 1 + tol), ...
    'gaussQuadrature:xi points outside [-1,1].');

assert(all(gauss.eta >= -1 - tol) && all(gauss.eta <= 1 + tol), ...
    'gaussQuadrature:eta points outside [-1,1].');

assert(abs(sum(gauss.w1D) - 2) < 10*tol, ...
    'gaussQuadrature:1D weights do not sum to 2.');

assert(abs(sum(gauss.w) - 4) < 100*tol, ...
    'gaussQuadrature:2D weights do not sum to 4.');

for i = 1:ceil(ng/2)
    j = ng + 1 - i;
    assert(abs(xi1D(i) + xi1D(j)) < tol, ...
        'gaussQuadrature:1D points are not symmetric.');
    assert(abs(w1D(i) - w1D(j)) < tol, ...
        'gaussQuadrature:1D weights are not symmetric.');
end

% n-point Gauss-Legendre quadrature is exact through degree 2*n-1.
degMax = 2*ng - 1;
for d = 0:degMax
    if mod(d, 2) == 0
        exact = 2/(d + 1);
    else
        exact = 0;
    end

    Ig = sum(w1D.*(xi1D.^d));
    assert(abs(Ig - exact) < 1e-12*(1 + abs(exact)), ...
        'gaussQuadrature:1D rule fails exactness for degree %d.', d);
end

for dx = 0:2:degMax
    for dy = 0:2:degMax
        exact = (2/(dx + 1))*(2/(dy + 1));
        Ig = sum(gauss.w.*(gauss.xi.^dx).*(gauss.eta.^dy));

        assert(abs(Ig - exact) < 1e-12*(1 + abs(exact)), ...
            ['gaussQuadrature:2D rule fails exactness for ' ...
             'xi^%d eta^%d.'], dx, dy);
    end
end

end
