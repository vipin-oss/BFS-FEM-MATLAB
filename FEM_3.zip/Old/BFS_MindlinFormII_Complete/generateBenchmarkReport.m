function rpt = generateBenchmarkReport(bench, rep, varargin)
%GENERATEBENCHMARKREPORT  Compile the verification and 2022 benchmark
%                         results into a publication-ready struct and
%                         (optionally) produce summary figures and a
%                         plain-text report file.
%
%   rpt = GENERATEBENCHMARKREPORT(bench, rep)
%   rpt = GENERATEBENCHMARKREPORT(bench, rep, 'Name',Value,...)
%
% ----------------------------------------------------------------------
% Inputs
% ----------------------------------------------------------------------
%   bench   output of validate2022Benchmark
%   rep     output of runVerificationSuite
%
% Options (defaults):
%   outdir       output directory             ('results')
%   baseName     filename prefix              ('benchmark_report')
%   writeFiles   write .txt + figures         (true)
%   makeFigures  produce convergence figures  (true)
%   figFormats   export formats               ({'png','pdf'})
%   figDPI       PNG DPI                      (300)
%   title        report title                 (auto)
%
% Output rpt struct:
%   .title, .date, .opts
%   .passTable       formatted table of L2/H1/E errors per case/mesh
%   .rateTable       convergence-rate table
%   .summary         one-page text summary
%   .verification    pass/fail counts per level
%   .files           list of files written
%   .allPass         boolean
%
% See also VALIDATE2022BENCHMARK, RUNVERIFICATIONSUITE, EXPORTRESULTS,
%          PLOTRESULTS.

ip = inputParser;
addParameter(ip,'outdir','results',@ischar);
addParameter(ip,'baseName','benchmark_report',@ischar);
addParameter(ip,'writeFiles',true,@(x) islogical(x)||x==0||x==1);
addParameter(ip,'makeFigures',true,@(x) islogical(x)||x==0||x==1);
addParameter(ip,'figFormats',{'png','pdf'},@(x) iscell(x)||ischar(x));
addParameter(ip,'figDPI',300,@(x) isnumeric(x)&&isscalar(x)&&x>0);
addParameter(ip,'title',[],@(x) isempty(x)||ischar(x));
parse(ip,varargin{:});
o = ip.Results;
if ischar(o.figFormats); o.figFormats={o.figFormats}; end

if isempty(o.title)
    o.title = '2022 Torabi--Niiranen Mindlin Form-II benchmark verification (BFS C^1)';
end

files = {};
[~,~,~]=mkdir(o.outdir);

% ======================================================================
% Build per-case error and convergence tables.
% ======================================================================
cases = bench.cases;
nCases = length(cases);
NeList = bench.NeList;

% Pass/fail header.
pt = sprintf('%-12s','case');
pt = [pt sprintf('  %-6s','Ne')];
pt = [pt sprintf('  %-10s','L2') sprintf('  %-10s','H1') sprintf('  %-10s','E_rel') sprintf('  %s\n','pass')];
pt = [pt repmat('-',1,60) sprintf('\n')];
rt = sprintf('%-12s','case');
for mi=2:length(NeList); rt=[rt sprintf('  Ne %d->%d',NeList(mi-1),NeList(mi))]; end
rt = [rt sprintf('\n')];
rt = [rt repmat('-',1,40) sprintf('\n')];

for ci=1:nCases
    c=cases{ci};
    for mi=1:length(NeList)
        ptag='FAIL'; if c.L2err(mi)<bench.opts.tol && c.H1err(mi)<bench.opts.tol; ptag='PASS'; end
        pt=[pt sprintf('%-12s  %-6d  %-10.2e  %-10.2e  %-10.2e  %s\n',...
            c.name,c.NeList(mi),c.L2err(mi),c.H1err(mi),c.Erel(mi),ptag)]; %#ok<AGROW>
    end
    pt=[pt sprintf('\n')]; %#ok<AGROW>
    rL='';
    for mi=2:length(NeList)
        rL=[rL sprintf('  rL2=%.2f  rH1=%.2f',c.rateL2(mi),c.rateH1(mi))]; %#ok<AGROW>
    end
    rt=[rt sprintf('%-12s%s\n',c.name,rL)]; %#ok<AGROW>
end

% Verification per-level summary.
nLev=5; passCount=zeros(1,nLev); failCount=zeros(1,nLev);
for k=1:length(rep.level)
    lv = rep.level(k).level;
    if lv>=1 && lv<=nLev
        if rep.level(k).pass; passCount(lv)=passCount(lv)+1; else failCount(lv)=failCount(lv)+1; end
    end
end
vtab = sprintf('%-10s  %-6s  %-6s\n','Level','Pass','Fail');
vtab = [vtab repmat('-',1,28) sprintf('\n')];
for lv=1:nLev
    vtab = [vtab sprintf('%-10d  %-6d  %-6d\n',lv,passCount(lv),failCount(lv))]; %#ok<AGROW>
end

% ======================================================================
% One-page summary.
% ======================================================================
sm = sprintf('=========================================================\n');
sm=[sm sprintf('%s\n',o.title)];
sm=[sm sprintf('Generated : %s\n',datestr(now,31))];
sm=[sm sprintf('Material  : E=%g, nu=%g, a=[%g,%g,%g,%g,%g]\n',...
    bench.E,bench.nu,bench.opts.a1,bench.opts.a2,bench.opts.a3,bench.opts.a4,bench.opts.a5)];
sm=[sm sprintf('Domain    : L1=%g, L2=%g\n',bench.opts.L1,bench.opts.L2)];
sm=[sm sprintf('Meshes    : Ne in %s\n',mat2str(NeList))];
sm=[sm sprintf('Tolerance : %g\n',bench.opts.tol)];
sm=[sm sprintf('Cases     : %s\n',strjoin(cellfun(@(c)c.name,cases,'UniformOutput',false),', '))];
sm=[sm sprintf('All pass  : %d\n',double(bench.allPass && rep.allPass))];
sm=[sm sprintf('---------------------------------------------------------\n')];
sm=[sm pt];
sm=[sm sprintf('---------------------------------------------------------\n')];
sm=[sm sprintf('Convergence rates (L2/H1) between successive meshes:\n')];
sm=[sm rt];
sm=[sm sprintf('---------------------------------------------------------\n')];
sm=[sm sprintf('Verification suite summary:\n') vtab];
sm=[sm sprintf('Total     : %d/%d passed\n',rep.nPass,rep.nTests)];
sm=[sm sprintf('=========================================================\n')];

% ======================================================================
% Figures (convergence + verification bar chart).
% ======================================================================
if o.makeFigures
    % Figure 1: L2 error convergence vs 1/h (log-log).
    fh1=figure('Visible','off','Name','L2 convergence');
    loglog(0,0); hold on; ax=gca; ax.XScale='log'; ax.YScale='log';
    marks = {'o-','s-','^-','d-'};
    for ci=1:nCases
        c=cases{ci};
        h = bench.opts.L1./c.NeList;
        loglog(h,c.L2err,marks{mod(ci-1,length(marks))+1},'LineWidth',1.2,'MarkerSize',6);
    end
    legend(cellfun(@(c)c.name,cases,'UniformOutput',false),'Location','best');
    xlabel('h = L / N_e'); ylabel('||u - u_h||_{L^2}');
    title('L^2 displacement error'); grid on;

    % Figure 2: H1 error convergence.
    fh2=figure('Visible','off','Name','H1 convergence');
    hold on; ax=gca; ax.XScale='log'; ax.YScale='log';
    for ci=1:nCases
        c=cases{ci};
        h = bench.opts.L1./c.NeList;
        loglog(h,c.H1err,marks{mod(ci-1,length(marks))+1},'LineWidth',1.2,'MarkerSize',6);
    end
    legend(cellfun(@(c)c.name,cases,'UniformOutput',false),'Location','best');
    xlabel('h = L / N_e'); ylabel('||u - u_h||_{H^1}');
    title('H^1 displacement error'); grid on;

    % Figure 3: verification pass/fail bar chart per level.
    fh3=figure('Visible','off','Name','Verification');
    bar([passCount; failCount].','stacked');
    set(gca,'XTickLabel',arrayfun(@(i)sprintf('L%d',i),1:nLev,'UniformOutput',false));
    legend('Pass','Fail'); title(sprintf('Verification: %d/%d passed',rep.nPass,rep.nTests));
    ylabel('# tests');
end

% ======================================================================
% Write files.
% ======================================================================
if o.writeFiles
    txt = fullfile(o.outdir,[o.baseName '.txt']);
    fid = fopen(txt,'w');
    if fid<0; error('generateBenchmarkReport:cannot write %s.',txt); end
    fprintf(fid,'%s',sm);
    fclose(fid); files{end+1}=txt;

    % CSV table of errors.
    csv = fullfile(o.outdir,[o.baseName '_errors.csv']);
    fid=fopen(csv,'w');
    fprintf(fid,'case,Ne,L2,H1,Erel,pass\n');
    for ci=1:nCases
        c=cases{ci};
        for mi=1:length(c.NeList)
            fprintf(fid,'%s,%d,%.15e,%.15e,%.15e,%d\n',...
                c.name,c.NeList(mi),c.L2err(mi),c.H1err(mi),c.Erel(mi),double(c.pass));
        end
    end
    fclose(fid); files{end+1}=csv;

    % Figures.
    if o.makeFigures
        figs=[fh1 fh2 fh3];
        names={'L2conv','H1conv','verification'};
        for k=1:length(figs)
            for ff=1:length(o.figFormats)
                fmt=lower(o.figFormats{ff});
                pth=fullfile(o.outdir,sprintf('%s_%s.%s',o.baseName,names{k},fmt));
                switch fmt
                    case 'png'
                        print(figs{k},pth,'-dpng',['-r',num2str(o.figDPI)]);
                    case 'pdf'
                        print(figs{k},pth,'-dpdf','-bestfit');
                    case 'eps'
                        print(figs{k},pth,'-depsc2');
                end
                files{end+1}=pth;
            end
        end
    end
end

% ======================================================================
% Output struct.
% ======================================================================
rpt = struct();
rpt.title = o.title;
rpt.date  = datestr(now,31);
rpt.opts  = o;
rpt.passTable = pt;
rpt.rateTable = rt;
rpt.verificationTable = vtab;
rpt.summary = sm;
rpt.levels  = struct('pass',passCount,'fail',failCount);
rpt.nPass=rep.nPass; rpt.nFail=rep.nFail; rpt.nTests=rep.nTests;
rpt.allPass = bench.allPass && rep.allPass;
rpt.bench=bench; rpt.rep=rep;
rpt.files=files;
end
