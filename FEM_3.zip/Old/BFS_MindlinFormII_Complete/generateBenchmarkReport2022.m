function report = generateBenchmarkReport2022(bench2022)
%GENERATEBENCHMARKREPORT2022 Print and plot isolated 2022 benchmark data.
%
%   report = generateBenchmarkReport2022(bench2022)
%
% Input bench2022 is the struct saved from:
%   bench2022.case1 = benchAllEll;
%   bench2022.case2 = benchCase2AllEll;

assert(isstruct(bench2022) && isfield(bench2022, 'case1') && ...
       isfield(bench2022, 'case2'), ...
    'generateBenchmarkReport2022:bench2022 must contain case1 and case2.');

caseData = {bench2022.case1, bench2022.case2};
caseNames = {'Case 1: prescribed top displacement', ...
             'Case 2: prescribed top traction'};

fprintf('\n=========================================================\n');
fprintf('  2022 benchmark report: BFS Mindlin Form-II recovery\n');
fprintf('=========================================================\n');

allRows = struct('caseName', {}, 'ell', {}, 'NeY', {}, 'NeX', {}, ...
                 'nDOF', {}, 'L2', {}, 'H1', {}, 'G', {}, 'Rq', {}, ...
                 'rateL2', {}, 'rateH1', {}, 'converged', {});

for c = 1:2
    data = caseData{c};
    assert(isfield(data, 'results'), ...
        'generateBenchmarkReport2022:case data lacks results.');

    fprintf('\n%s\n', caseNames{c});
    fprintf(' ell       NeX x NeY    nDOF       L2-error      H1-error      G-error       Rq\n');
    fprintf('--------------------------------------------------------------------------------\n');

    for r = 1:numel(data.results)
        item = data.results{r};
        for k = 1:numel(item.NeYList)
            row = struct();
            row.caseName = item.caseName;
            row.ell = item.ell;
            row.NeY = item.NeYList(k);
            row.NeX = item.NeXList(k);
            row.nDOF = item.nDOF(k);
            row.L2 = item.L2err(k);
            row.H1 = item.H1err(k);
            row.G = item.Gerr(k);
            row.Rq = item.Rnorm(k);
            row.rateL2 = item.rateL2(k);
            row.rateH1 = item.rateH1(k);
            row.converged = item.converged(k);
            allRows(end + 1) = row; %#ok<AGROW>

            fprintf(' %-7g  %3d x %-3d  %-8d  %.3e  %.3e  %.3e  %.3e\n', ...
                row.ell, row.NeX, row.NeY, row.nDOF, ...
                row.L2, row.H1, row.G, row.Rq);
        end
    end
end

% Error-convergence plots: Case 1 and Case 2; L2/H1/G panels.
fig = figure('Name', '2022 benchmark convergence', 'Color', 'w');
tiledlayout(2, 3, 'Padding', 'compact', 'TileSpacing', 'compact');

metricNames = {'L2err', 'H1err', 'Gerr'};
yLabels = {'relative L2 error', 'relative H1 error', 'relative G error'};

for c = 1:2
    data = caseData{c};
    for m = 1:3
        nexttile((c - 1)*3 + m);
        hold on;
        grid on;
        box on;

        for r = 1:numel(data.results)
            item = data.results{r};
            loglog(item.NeYList, item.(metricNames{m}), '-o', ...
                'LineWidth', 1.25, 'MarkerSize', 5, ...
                'DisplayName', sprintf('ell = %g', item.ell));
        end

        xlabel('NeY');
        ylabel(yLabels{m});
        title(sprintf('Case %d', c));
        legend('Location', 'southwest');
    end
end

report = struct();
report.rows = allRows;
report.figure = fig;
report.case1Pass = bench2022.case1.allPass;
report.case2Pass = bench2022.case2.allPass;
report.allPass = report.case1Pass && report.case2Pass;

fprintf('\nOverall benchmark result: %s\n', ternary(report.allPass, 'PASS', 'FAIL'));

end

function out = ternary(condition, yesValue, noValue)
if condition
    out = yesValue;
else
    out = noValue;
end
end
