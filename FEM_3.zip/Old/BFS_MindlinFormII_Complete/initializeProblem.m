function prob = initializeProblem(varargin)
%INITIALIZEPROBLEM Build mesh, material, DOFs, BCs, quadrature and options.
%
%   prob = initializeProblem('Name', Value, ...)
%
% The returned structure is consumed by runAnalysis.  The mesh uses the
% frozen rectangular BFS ordering: local nodes [SW, SE, NE, NW].

p = inputParser;

% Geometry and mesh.
addParameter(p, 'L1', 1, @isFinitePositiveScalar);
addParameter(p, 'L2', 1, @isFinitePositiveScalar);
addParameter(p, 'thickness', 1, @isFinitePositiveScalar);
addParameter(p, 'Ne1', 4, @isPositiveInteger);
addParameter(p, 'Ne2', 4, @isPositiveInteger);

% Material.
addParameter(p, 'E', 100, @isFinitePositiveScalar);
addParameter(p, 'nu', 0.3, @(x) isFiniteScalar(x) && x > -1 && x < 0.5);
addParameter(p, 'a1', 0, @isFiniteScalar);
addParameter(p, 'a2', 0, @isFiniteScalar);
addParameter(p, 'a3', 0, @isFiniteScalar);
addParameter(p, 'a4', 0, @isFiniteScalar);
addParameter(p, 'a5', 0, @isFiniteScalar);
addParameter(p, 'rho0', 0, @(x) isFiniteScalar(x) && x >= 0);

% Boundary/load data.
addParameter(p, 'bcSpecs', [], @(x) isempty(x) || isstruct(x) || iscell(x));
addParameter(p, 'Fext', [], @(x) isempty(x) || (isnumeric(x) && isreal(x) && isvector(x)));

% Analysis and Newton controls.
addParameter(p, 'mode', 'nonlinear', @isMode);
addParameter(p, 'lambda0', 0, @isFiniteScalar);
addParameter(p, 'lambdaFinal', 1, @isFiniteScalar);
addParameter(p, 'nSteps', 10, @isPositiveInteger);
addParameter(p, 'dlambda0', [], @(x) isempty(x) || (isFiniteScalar(x) && x > 0));
addParameter(p, 'adaptive', [], @(x) isempty(x) || isLogicalScalar(x));
addParameter(p, 'alpha', 0.5, @(x) isFiniteScalar(x) && x > 0 && x < 1);
addParameter(p, 'beta', 1.2, @(x) isFiniteScalar(x) && x > 1);
addParameter(p, 'kTarget', 6, @isPositiveInteger);
addParameter(p, 'kMax', 20, @isPositiveInteger);
addParameter(p, 'tolR', 1e-8, @isFinitePositiveScalar);
addParameter(p, 'tolD', 1e-8, @isFinitePositiveScalar);
addParameter(p, 'tolE', 1e-8, @isFinitePositiveScalar);
addParameter(p, 'maxCutbacks', 10, @isNonnegativeInteger);
addParameter(p, 'verbose', false, @isLogicalScalar);

% Benchmark preset data.
addParameter(p, 'benchCase', 'uniaxial', @isBenchCase);
addParameter(p, 'benchStrain', 1e-3, @isFiniteScalar);
addParameter(p, 'benchMesh', [8, 8], @(x) isnumeric(x) && isreal(x) && numel(x) == 2);

parse(p, varargin{:});
o = p.Results;
o.mode = lower(char(o.mode));
o.benchCase = lower(char(o.benchCase));
o.verbose = logical(o.verbose);

assert(o.lambdaFinal >= o.lambda0, ...
    'initializeProblem:lambdaFinal must be greater than or equal to lambda0.');

% ---------------------------------------------------------------------
% Benchmark preset.
% ---------------------------------------------------------------------
if strcmp(o.mode, 'benchmark')
    assert(all(isfinite(o.benchMesh)) && all(o.benchMesh >= 1) && ...
           all(o.benchMesh == round(o.benchMesh)), ...
        'initializeProblem:benchMesh must contain positive integer sizes.');

    o.Ne1 = o.benchMesh(1);
    o.Ne2 = o.benchMesh(2);
    o.a1 = 0; o.a2 = 0; o.a3 = 0; o.a4 = 0; o.a5 = 0;
    o.adaptive = false;
    o.nSteps = 1;

    if isempty(o.bcSpecs)
        epsB = o.benchStrain;
        switch o.benchCase
            case 'uniaxial'
                o.bcSpecs = { ...
                    struct('edge', 'x0', 'comp', 1, 'dofType', 'all', 'value', 0), ...
                    struct('edge', 'x0', 'comp', 2, 'dofType', 'all', 'value', 0), ...
                    struct('edge', 'x1', 'comp', 1, 'dofType', 'u', 'value', epsB*o.L1), ...
                    struct('edge', 'x1', 'comp', 2, 'dofType', 'u', 'value', 0)};

            case 'bending'
                o.bcSpecs = { ...
                    struct('edge', 'x0', 'comp', 1, 'dofType', 'all', 'value', 0), ...
                    struct('edge', 'x0', 'comp', 2, 'dofType', 'all', 'value', 0), ...
                    struct('edge', 'x1', 'comp', 2, 'dofType', 'u', ...
                           'value', @(X1, X2) epsB*(X2/o.L2 - 0.5)*o.L2)};

            case 'pureshear'
                o.bcSpecs = { ...
                    struct('edge', 'x0', 'comp', 1, 'dofType', 'all', 'value', 0), ...
                    struct('edge', 'x0', 'comp', 2, 'dofType', 'all', 'value', 0), ...
                    struct('edge', 'y0', 'comp', 2, 'dofType', 'all', 'value', 0), ...
                    struct('edge', 'y1', 'comp', 2, 'dofType', 'all', 'value', 0), ...
                    struct('edge', 'x1', 'comp', 1, 'dofType', 'u', 'value', epsB*o.L1)};
        end
    end
end

% Default nonlinear demonstration BCs.
if isempty(o.bcSpecs)
    o.bcSpecs = { ...
        struct('edge', 'x0', 'comp', 1, 'dofType', 'all', 'value', 0), ...
        struct('edge', 'x0', 'comp', 2, 'dofType', 'all', 'value', 0), ...
        struct('edge', 'x1', 'comp', 1, 'dofType', 'u', 'value', 0.001*o.L1)};
end

if isempty(o.adaptive)
    o.adaptive = strcmp(o.mode, 'nonlinear');
else
    o.adaptive = logical(o.adaptive);
end

% ---------------------------------------------------------------------
% Frozen material, mesh, DOF map, quadrature and strong BC construction.
% ---------------------------------------------------------------------
mat = buildMaterialStruct(o.E, o.nu, o.a1, o.a2, o.a3, o.a4, o.a5, o.rho0);
mat.thickness = o.thickness;

mesh = localBuildRectMesh(o.Ne1, o.Ne2, o.L1/o.Ne1, o.L2/o.Ne2);
mesh.thickness = o.thickness;

dof = buildDOFMap(mesh);
gauss = gaussQuadrature(3);
[bc, dof] = buildBoundaryConditions(mesh, dof, o.bcSpecs);

D0 = zeros(dof.nDOF, 1);
D0 = updateEssentialDOFs(D0, dof, o.lambda0);

if isempty(o.Fext)
    Fext = zeros(dof.nDOF, 1);
else
    Fext = o.Fext(:);
    assert(numel(Fext) == dof.nDOF, ...
        'initializeProblem:Fext must be an nDOF-vector.');
end

% The implemented solver always uses the fully consistent finite-strain
% residual/tangent.  'linear' is a problem/verification label, not a
% forced one-iteration cutoff.
solver = struct();
solver.lambda0 = o.lambda0;
solver.lambdaFinal = o.lambdaFinal;
solver.nSteps = o.nSteps;
solver.dlambda0 = o.dlambda0;
solver.adaptive = o.adaptive;
solver.alpha = o.alpha;
solver.beta = o.beta;
solver.kTarget = o.kTarget;
solver.kMax = o.kMax;
solver.tolR = o.tolR;
solver.tolD = o.tolD;
solver.tolE = o.tolE;
solver.maxCutbacks = o.maxCutbacks;
solver.verbose = o.verbose;
solver.linearMode = false;

prob = struct();
prob.geom = struct('L1', o.L1, 'L2', o.L2, 'thickness', o.thickness);
prob.mesh = mesh;
prob.mat = mat;
prob.dof = dof;
prob.gauss = gauss;
prob.bc = bc;
prob.Fext = Fext;
prob.D0 = D0;
prob.solver = solver;
prob.mode = o.mode;
prob.info = struct('createdAt', datestr(now, 31), ...
                   'versionTag', 'BFS Mindlin Form-II', ...
                   'benchCase', o.benchCase);

assert(dof.nDOF == 8*mesh.nNodes, ...
    'initializeProblem:nDOF must equal 8*nNodes for the 2D BFS element.');
assert(numel(dof.freeDOF) + numel(dof.essDOF) == dof.nDOF, ...
    'initializeProblem:free/essential partition is incomplete.');
assert(norm(D0(dof.essDOF) - o.lambda0*dof.essVals, inf) < 1e-12, ...
    'initializeProblem:initial essential values are inconsistent.');

end

% =====================================================================
% Structured rectangular BFS mesh: nodes are lexicographic in X1/X2;
% element local corners are [SW, SE, NE, NW].
% =====================================================================
function mesh = localBuildRectMesh(Ne1, Ne2, h1, h2)

nNodes = (Ne1 + 1)*(Ne2 + 1);
nElem = Ne1*Ne2;
X = zeros(nNodes, 2);

for i2 = 0:Ne2
    for i1 = 0:Ne1
        nd = i2*(Ne1 + 1) + i1 + 1;
        X(nd, :) = [i1*h1, i2*h2];
    end
end

connect = zeros(nElem, 4);
elemGeom = repmat(struct('x0', 0, 'y0', 0, 'h1', h1, 'h2', h2), nElem, 1);

e = 0;
for i2 = 0:Ne2-1
    for i1 = 0:Ne1-1
        e = e + 1;
        ndSW = i2*(Ne1 + 1) + i1 + 1;
        ndSE = ndSW + 1;
        ndNE = (i2 + 1)*(Ne1 + 1) + i1 + 2;
        ndNW = ndNE - 1;

        connect(e, :) = [ndSW, ndSE, ndNE, ndNW];
        elemGeom(e).x0 = i1*h1;
        elemGeom(e).y0 = i2*h2;
    end
end

mesh = struct('nNodes', nNodes, 'nElem', nElem, ...
              'Ne1', Ne1, 'Ne2', Ne2, ...
              'X', X, 'connect', connect, ...
              'L1', Ne1*h1, 'L2', Ne2*h2, ...
              'h1', h1, 'h2', h2, ...
              'elemGeom', elemGeom);

end

function tf = isFiniteScalar(x)
tf = isnumeric(x) && isreal(x) && isfinite(x) && isscalar(x);
end

function tf = isFinitePositiveScalar(x)
tf = isFiniteScalar(x) && x > 0;
end

function tf = isPositiveInteger(x)
tf = isFiniteScalar(x) && x >= 1 && x == round(x);
end

function tf = isNonnegativeInteger(x)
tf = isFiniteScalar(x) && x >= 0 && x == round(x);
end

function tf = isLogicalScalar(x)
tf = (islogical(x) && isscalar(x)) || ...
     (isnumeric(x) && isreal(x) && isfinite(x) && isscalar(x) && ...
      (x == 0 || x == 1));
end

function tf = isMode(x)
if ischar(x)
    value = lower(x);
elseif exist('isstring', 'builtin') && isstring(x) && isscalar(x)
    value = lower(char(x));
else
    tf = false;
    return;
end
tf = any(strcmp(value, {'linear', 'nonlinear', 'benchmark'}));
end

function tf = isBenchCase(x)
if ischar(x)
    value = lower(x);
elseif exist('isstring', 'builtin') && isstring(x) && isscalar(x)
    value = lower(char(x));
else
    tf = false;
    return;
end
tf = any(strcmp(value, {'uniaxial', 'bending', 'pureshear'}));
end
