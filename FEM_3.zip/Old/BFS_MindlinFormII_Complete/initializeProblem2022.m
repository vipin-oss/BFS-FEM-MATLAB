function prob = initializeProblem2022(varargin)
%INITIALIZEPROBLEM2022 Build the isolated exact-2022 benchmark problem.
%
% Paper units are MPa and mm.  The finite-strain solver is operated with
% loadScale << 1 so that E->epsilon and Grad(E)->Grad(epsilon), while the
% analytical benchmark profile and all prescribed data are scaled by the
% same factor.

p = inputParser;
addParameter(p, 'caseName', 'case1', @isCaseName);
addParameter(p, 'E', 400, @(x) isPos(x));             % MPa
addParameter(p, 'nu', 0.49, @(x) isscalar(x) && x > -1 && x < 0.5);
addParameter(p, 'H', 0.5, @isPos);                     % mm
addParameter(p, 'L', [], @(x) isempty(x) || isPos(x)); % mm; default 3H
addParameter(p, 'ell', 0.1, @isPos);                   % mm
addParameter(p, 'uhat', 0.05, @isFinite);              % mm, Case 1
addParameter(p, 'that', 1.0, @isFinite);               % MPa, Case 2
addParameter(p, 'loadScale', 1e-5, @(x) isPos(x));
addParameter(p, 'NeX', 12, @isPositiveInteger);
addParameter(p, 'NeY', 8, @isPositiveInteger);
addParameter(p, 'nSteps', 10, @isPositiveInteger);
addParameter(p, 'kMax', 20, @isPositiveInteger);
addParameter(p, 'tolR', 1e-8, @isPos);
addParameter(p, 'tolD', 1e-8, @isPos);
addParameter(p, 'tolE', 1e-8, @isPos);
addParameter(p, 'divergenceTol', 1e6, @isPos);
addParameter(p, 'verbose', false, @isLogicalScalar);
parse(p, varargin{:});
o = p.Results;
o.caseName = lower(char(o.caseName));
o.verbose = logical(o.verbose);

if isempty(o.L)
    o.L = 3*o.H;
end

% Paper Eq. (41)--(42), followed by direct matching to the frozen
% five-invariant a1,...,a5 convention.
mu = o.E/(2*(1 + o.nu));
lam = o.E*o.nu/((1 + o.nu)*(1 - 2*o.nu));
c3 = o.ell^2*lam/12;
c4 = o.ell^2*lam/12;
c5 = o.ell^2*(7*mu + 3*lam)/120;
c6 = o.ell^2*(7*mu - 4*lam)/120;
c7 = c5;

% Frozen invariant ordering:
% a1=2*c5, a2=2*c3, a3=c4/2, a4=c6, a5=2*c7.
a1 = 2*c5;
a2 = 2*c3;
a3 = c4/2;
a4 = c6;
a5 = 2*c7;

mat = buildMaterialStruct(o.E, o.nu, a1, a2, a3, a4, a5, 0);
mat.thickness = 1;

mesh = buildMesh2022(o.NeX, o.NeY, o.L/o.NeX, o.H/o.NeY);
dof = buildDOFMap(mesh);
gauss = gaussQuadrature(3);

prescribed = struct('H', o.H, 'uhat', o.loadScale*o.uhat);
constraints = buildBoundaryConditions2022(mesh, dof, o.caseName, prescribed);
Fext = buildBenchmarkLoads2022(mesh, dof, gauss, o.caseName, ...
                               o.loadScale*o.that, mat.thickness);

solver = struct('lambda0', 0, 'lambdaFinal', 1, 'nSteps', o.nSteps, ...
                'kMax', o.kMax, 'tolR', o.tolR, 'tolD', o.tolD, ...
                'tolE', o.tolE, 'divergenceTol', o.divergenceTol, ...
                'verbose', o.verbose);

paper = struct('E', o.E, 'nu', o.nu, 'H', o.H, 'L', o.L, 'ell', o.ell, ...
               'uhat', o.loadScale*o.uhat, 'that', o.loadScale*o.that, ...
               'loadScale', o.loadScale, ...
               'lambda', lam, 'mu', mu, ...
               'c3', c3, 'c4', c4, 'c5', c5, 'c6', c6, 'c7', c7);

prob = struct('caseName', o.caseName, 'mesh', mesh, 'mat', mat, ...
              'dof', dof, 'gauss', gauss, 'constraints', constraints, ...
              'Fext', Fext, 'solver', solver, 'paper', paper, 'opts', o);

end

function mesh = buildMesh2022(NeX, NeY, hx, hy)
nNodes = (NeX + 1)*(NeY + 1);
nElem = NeX*NeY;
X = zeros(nNodes, 2);
for j = 0:NeY
    for i = 0:NeX
        node = j*(NeX + 1) + i + 1;
        X(node, :) = [i*hx, j*hy];
    end
end

connect = zeros(nElem, 4);
elemGeom = repmat(struct('x0', 0, 'y0', 0, 'h1', hx, 'h2', hy), nElem, 1);
e = 0;
for j = 0:NeY-1
    for i = 0:NeX-1
        e = e + 1;
        sw = j*(NeX + 1) + i + 1;
        se = sw + 1;
        ne = (j + 1)*(NeX + 1) + i + 2;
        nw = ne - 1;
        connect(e, :) = [sw, se, ne, nw];
        elemGeom(e).x0 = i*hx;
        elemGeom(e).y0 = j*hy;
    end
end

mesh = struct('nNodes', nNodes, 'nElem', nElem, 'Ne1', NeX, 'Ne2', NeY, ...
              'X', X, 'connect', connect, 'L1', NeX*hx, 'L2', NeY*hy, ...
              'h1', hx, 'h2', hy, 'elemGeom', elemGeom, 'thickness', 1);
end

function tf = isFinite(x)
tf = isnumeric(x) && isreal(x) && isfinite(x) && isscalar(x);
end
function tf = isPos(x)
tf = isFinite(x) && x > 0;
end
function tf = isPositiveInteger(x)
tf = isPos(x) && x == round(x);
end
function tf = isLogicalScalar(x)
tf = (islogical(x) && isscalar(x)) || ...
     (isnumeric(x) && isscalar(x) && (x == 0 || x == 1));
end
function tf = isCaseName(x)
if ischar(x)
    c = lower(x);
elseif exist('isstring', 'builtin') && isstring(x) && isscalar(x)
    c = lower(char(x));
else
    tf = false; return;
end
tf = any(strcmp(c, {'case1', 'case2'}));
end
