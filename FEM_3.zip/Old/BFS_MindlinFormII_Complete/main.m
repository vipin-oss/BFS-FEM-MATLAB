function varargout = main(varargin)
%MAIN  Top-level entry point for the BFS Mindlin Form-II geometrically
%      nonlinear C^1 finite-element solver.
%
%   sol = MAIN('Name',Value,...)        % run a custom analysis
%   sol = MAIN()                        % run with defaults (after self-tests)
%   sol = MAIN('mode','benchmark',...)  % run benchmark preset
%
% ----------------------------------------------------------------------
% Program workflow (frozen Sec. 9)
% ----------------------------------------------------------------------
%   1. (first call only, zero args, zero outputs) run internal self-tests.
%   2. Parse/forward problem-definition name-value pairs to
%      initializeProblem(), which builds mat, mesh, dof, gauss, D0, bc,
%      Fext, and solver options.
%   3. runAnalysis(prob) invokes newtonRaphsonSolver, collects histories,
%      computes final-state strain energy/residual norms, and returns a
%      self-contained sol object.
%   4. Echo a one-line summary and, when invoked with no outputs, place
%      sol in the base workspace.
%
% Module dependency graph (frozen Modules 2-12 + Module 13):
%
%     main --> initializeProblem --> buildMaterialStruct (M2)
%            |                     local_buildRectMesh  (canonical)
%            |                     buildDOFMap          (M10)
%            |                     gaussQuadrature      (M5)
%            |                     buildBoundaryConditions (M11)
%            |                     updateEssentialDOFs  (M11)
%            |
%            --> runAnalysis ----> assembleGlobalResidual (M10)
%                                  assembleGlobalTangent  (M10)
%                                  bfsShapeFunctionDerivatives (M4)
%                                  computeDeformationGradient (M6)
%                                  computeGreenLagrangeStrain (M6)
%                                  computeStrainGradient     (M6)
%                                  computeStrainEnergyDensity (M7)
%                                  newtonRaphsonSolver  (M12)
%                                     +-> solveLoadStep, convergenceCheck
%
% Example:
%   sol = main('L1',2,'L2',1,'Ne1',16,'Ne2',8,'E',1e3,'nu',0.0,...
%              'mode','nonlinear','adaptive',true,'verbose',true);
%
% See also INITIALIZEPROBLEM, RUNANALYSIS, NEWTONRAPHSONSOLVER.

% ======================================================================
% Recursion-guarded internal self-test (same pattern as Modules 9-12).
% Executed exactly once per MATLAB session when main is called with no
% input arguments and zero outputs (i.e. as a script).  After running,
% control returns to the caller so that the normal driver below is NOT
% also executed during the self-test invocation.
% ======================================================================
persistent SELFTEST_ACTIVE
if isempty(SELFTEST_ACTIVE); SELFTEST_ACTIVE = false; end
err_CAUGHT = [];
if nargin == 0 && nargout == 0 && ~SELFTEST_ACTIVE
    SELFTEST_ACTIVE = true;
    try
        runSelfTests();
    catch ME
        err_CAUGHT = ME;
    end
    SELFTEST_ACTIVE = false;
    if ~isempty(err_CAUGHT)
        rethrow(err_CAUGHT);
    end
    fprintf('main: self-tests passed. Run sol = main(...) for a custom analysis.\n');
    return;
end


% ======================================================================
% Normal driver path.
% ======================================================================
prob = initializeProblem(varargin{:});
sol  = runAnalysis(prob);

if nargout == 0
    fprintf(['main: mode=%s  mesh=%dx%d  nDOF=%d (free=%d, ess=%d)  ' ...
             'nSteps=%d  totalIter=%d  finalConv=%d  W=%g  ||R||=%g\n'],...
        sol.mode, sol.mesh.Ne1, sol.mesh.Ne2, sol.nDOF, sol.nFree, sol.nEss, ...
        length(sol.lambda)-1, sol.totalIter, double(sol.finalConv), ...
        sol.U.Wtotal, sol.U.Rnorm);
    try
        assignin('base','sol',sol);
    catch
        % Non-interactive; ignore.
    end
end

if nargout >= 1; varargout{1} = sol; end

% =========================================================================
% INTERNAL SELF-TEST
% =========================================================================
function runSelfTests()
TOL = 1e-9;
fprintf('main: running internal self-tests...\n');

% (a) Linear benchmark uniaxial: must converge in <=1 iter with
%     positive energy and small residual.
sol_a = main('mode','benchmark','benchCase','uniaxial','benchMesh',[4,4], ...
    'benchStrain',1e-3,'E',100,'nu',0.3,'verbose',false);
assert(sol_a.finalConv, '(a) linear benchmark failed to converge.');
assert(sol_a.nIter(end) <= 1, '(a) took %d iters (expected <=1).', sol_a.nIter(end));
assert(sol_a.U.Wtotal > 0, '(a) energy must be positive.');
assert(sol_a.U.Rnorm < 1e-6, '(a) ||R||=%g too large.', sol_a.U.Rnorm);
fprintf('  [ok] (a) linear benchmark uniaxial: W=%g, ||R||=%g\n', sol_a.U.Wtotal, sol_a.U.Rnorm);

% (b) Nonlinear adaptive on 2x2 mesh with 20% stretch: must reach
%     lambda=1 through the adaptive/cutback pathway.
sol_b = main('mode','nonlinear','L1',1,'L2',1,'Ne1',2,'Ne2',2, ...
    'E',100,'nu',0.3,'a1',0,'a2',0,'a3',0,'a4',0,'a5',0, ...
    'bcSpecs',{ ...
        struct('edge','x0','comp',1,'dofType','all','value',0), ...
        struct('edge','x0','comp',2,'dofType','all','value',0), ...
        struct('edge','x1','comp',1,'dofType','u','value',0.2) ...
    }, ...
    'lambda0',0,'lambdaFinal',1,'dlambda0',0.5,'adaptive',true, ...
    'alpha',0.5,'beta',1.5,'kTarget',3,'maxCutbacks',6,'kMax',20, ...
    'verbose',false);
assert(sol_b.finalConv, '(b) nonlinear adaptive failed.');
assert(abs(sol_b.lambda(end)-1) < TOL, '(b) final lambda ~= 1.');
assert(sol_b.U.Rnorm < 1e-4, '(b) ||R||=%g too large.', sol_b.U.Rnorm);
fprintf('  [ok] (b) nonlinear adaptive: nSteps=%d, totalIter=%d, ||R||=%g\n', ...
    length(sol_b.lambda)-1, sol_b.totalIter, sol_b.U.Rnorm);

% (c) Linear mode vs. one-shot linear solve (2x1 mesh, nu=0).
sol_c = main('mode','linear','Ne1',2,'Ne2',1,'E',100,'nu',0.0, ...
    'L1',2,'L2',1,'thickness',1, ...
    'bcSpecs',{ ...
        struct('edge','x0','comp',1,'dofType','all','value',0), ...
        struct('edge','x0','comp',2,'dofType','all','value',0), ...
        struct('edge','x1','comp',1,'dofType','u','value',0.01) ...
    }, ...
    'nSteps',1,'verbose',false);
assert(sol_c.finalConv, '(c) linear mode failed.');
assert(sol_c.U.Rnorm < 1e-7, '(c) ||R||=%g too large.', sol_c.U.Rnorm);
D0c = zeros(sol_c.dof.nDOF,1);
D0c = updateEssentialDOFs(D0c, sol_c.dof, 0);
K_lin = assembleGlobalTangent(D0c, sol_c.mat, sol_c.mesh, sol_c.dof, sol_c.gauss);
R_lin = assembleGlobalResidual(D0c, sol_c.mat, sol_c.mesh, sol_c.dof, sol_c.gauss);
[Kr, Rr, fr] = applyDirichletBC(K_lin, R_lin, D0c, sol_c.dof, 1); %#ok<ASGLU>
dF = Kr \ (-Rr);
D_oneshot = D0c;
D_oneshot(sol_c.dof.freeDOF) = D_oneshot(sol_c.dof.freeDOF) + dF;
D_oneshot(sol_c.dof.essDOF)  = sol_c.dof.essVals;
assert(norm(sol_c.D(:,end)-D_oneshot) < 1e-10*(1+norm(D_oneshot)), ...
    '(c) deviates from one-shot solve (%g).', norm(sol_c.D(:,end)-D_oneshot));
fprintf('  [ok] (c) linear mode matches one-shot linear solve.\n');

% (d) Fixed-step nonlinear: 5 uniform steps -> 6 snapshots at dlambda=0.2.
sol_d = main('mode','nonlinear','Ne1',2,'Ne2',2, ...
    'bcSpecs',{ ...
        struct('edge','x0','comp',1,'dofType','all','value',0), ...
        struct('edge','x0','comp',2,'dofType','all','value',0), ...
        struct('edge','x1','comp',1,'dofType','u','value',0.05) ...
    }, ...
    'adaptive',false,'nSteps',5,'dlambda0',0.2,'verbose',false);
assert(sol_d.finalConv, '(d) fixed-step nonlinear failed.');
assert(length(sol_d.lambda)==6, '(d) expected 6 snapshots, got %d.', length(sol_d.lambda));
assert(max(abs(diff(sol_d.lambda)-0.2)) < TOL, '(d) steps not uniform.');
assert(all(sol_d.converged), '(d) not all snapshots converged.');
fprintf('  [ok] (d) fixed-step nonlinear: 5 uniform steps, all converged.\n');

% (e) Output-shape invariants across all four runs.
for s = {sol_a,sol_b,sol_c,sol_d}
    s1 = s{1};
    assert(isequal(size(s1.D), [s1.nDOF,length(s1.lambda)]), 'sol.D shape mismatch.');
    assert(isequal(size(s1.Rxn),[s1.nDOF,length(s1.lambda)]),'sol.Rxn shape mismatch.');
    assert(s1.nDOF == 8*s1.mesh.nNodes, 'nDOF must equal 8*nNodes.');
    assert(s1.nFree+s1.nEss == s1.nDOF, 'free+ess ~= nDOF.');
end
fprintf('  [ok] (e) output shape invariants for all 4 runs.\n');

fprintf('main self-test OK.\n');
end
end
