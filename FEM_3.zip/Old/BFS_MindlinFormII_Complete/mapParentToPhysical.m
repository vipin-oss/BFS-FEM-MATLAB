function X = mapParentToPhysical(xi, eta, Jmap)
%MAPPARENTTOPHYSICAL  Map parent-coordinate point (xi,eta) to the
%                     physical reference coordinates (X1,X2) for a
%                     rectangular BFS element.
%
%   X = MAPPARENTTOPHYSICAL(xi, eta, Jmap)
%
%   X = MAPPARENTTOPHYSICAL(xi, eta, elemGeom)
%
% ----------------------------------------------------------------------
% Parent and physical coordinate systems (frozen Sec. 6)
% ----------------------------------------------------------------------
% Parent:  (xi, eta) in [-1,1]^2 (biunit square).
% Physical (reference configuration): axis-aligned rectangle
%     X1 in [X1_0, X1_0 + h1],   X2 in [X2_0, X2_0 + h2],
% with lower-left corner (X1_0, X2_0) and side lengths h1, h2.
%
% The affine parent -> reference map is
%     X1(xi,eta) = X1_0 + (h1/2)*(xi + 1),
%     X2(xi,eta) = X2_0 + (h2/2)*(eta + 1).
% This is the mapping used for the structured rectangular BFS mesh
% in every numerical study of Secs. 8-9.
%
% Because the BFS interpolation is Total-Lagrangian, all gradients
% (F, E, G) are taken with respect to these reference coordinates X;
% the deformed map x(X) is handled separately by the displacement
% field u_h (see element/computeCurrentConfiguration.m).
%
% ----------------------------------------------------------------------
% Inputs
% ----------------------------------------------------------------------
%   xi, eta   parent coordinates, scalars in [-1,1].
%   Jmap      either the Jacobian struct produced by computeJacobian.m
%             (fields x0,y0,h1,h2), or a raw elemGeom struct (fields
%             x0,y0,h1,h2), or a 4x2 corner matrix (counter-clockwise,
%             as accepted by computeJacobian.m).
%
% Output
%   X         2 x 1 column vector [X1; X2] of physical reference
%             coordinates.
%
% Equation mapping: Sec. 6 parent/physical mapping; used by every
% element-level routine that needs the reference position (e.g. body
% force evaluation, boundary-condition enforcement, post-processing).
%
% See also GAUSSQUADRATURE, COMPUTEJACOBIAN.

% ======================================================================
% Input validation.
% ======================================================================
assert(isscalar(xi)  && isnumeric(xi),  'mapParentToPhysical:xi must be scalar.');
assert(isscalar(eta) && isnumeric(eta), 'mapParentToPhysical:eta must be scalar.');
assert(xi  >= -1 - 1e-12 && xi  <= 1 + 1e-12, 'mapParentToPhysical:xi outside [-1,1].');
assert(eta >= -1 - 1e-12 && eta <= 1 + 1e-12, 'mapParentToPhysical:eta outside [-1,1].');

% ======================================================================
% Unpack geometry (accept Jmap struct, raw elemGeom struct, or 4x2).
% ======================================================================
if isstruct(Jmap)
    % Accept either a Jmap (from computeJacobian) or a raw elemGeom.
    if isfield(Jmap,'x0') && isfield(Jmap,'y0') ...
            && isfield(Jmap,'h1') && isfield(Jmap,'h2')
        x0 = Jmap.x0;  y0 = Jmap.y0;
        h1 = Jmap.h1;  h2 = Jmap.h2;
    else
        error(['mapParentToPhysical:geometry struct must contain ' ...
               'fields x0,y0,h1,h2.']);
    end
elseif isnumeric(Jmap) && isequal(size(Jmap),[4,2])
    cc = Jmap;
    x0 = cc(1,1);  y0 = cc(1,2);
    h1 = cc(2,1) - cc(1,1);
    h2 = cc(4,2) - cc(1,2);
    assert(h1 > 0 && h2 > 0, ...
        'mapParentToPhysical:h1,h2 derived from corners must be positive.');
else
    error(['mapParentToPhysical:third argument must be a Jmap/elemGeom ' ...
           'struct or a 4x2 corner-coordinate matrix.']);
end

assert(isscalar(x0) && isscalar(y0) && isscalar(h1) && isscalar(h2) ...
    && h1 > 0 && h2 > 0, ...
    'mapParentToPhysical:x0,y0,h1,h2 must be scalars with h1,h2 > 0.');

% ======================================================================
% Affine map.
% ======================================================================
X1 = x0 + (h1/2)*(xi  + 1);
X2 = y0 + (h2/2)*(eta + 1);
X  = [X1; X2];

% ======================================================================
% Internal verification.
% ======================================================================
tol = 1e-12;

% (i) Dimensions.
assert(isequal(size(X),[2,1]), 'mapParentToPhysical:X must be 2x1.');

% (ii) Image lies within the closed rectangle [x0, x0+h1] x [y0, y0+h2].
assert(X(1) >= x0 - tol && X(1) <= x0 + h1 + tol, ...
    'mapParentToPhysical:X1 outside element x-range.');
assert(X(2) >= y0 - tol && X(2) <= y0 + h2 + tol, ...
    'mapParentToPhysical:X2 outside element y-range.');

% (iii) Exact recovery of the four corners when fed (xi,eta) =
%      parent-corners.
xi_c  = [-1, 1, 1,-1];
eta_c = [-1,-1, 1, 1];
% Expected physical corners in CCW order:
Xc = [x0,    y0;
      x0+h1, y0;
      x0+h1, y0+h2;
      x0,    y0+h2];
for k = 1:4
    Xk = [ ...
    x0 + (h1/2)*(xi_c(k)+1); ...
    y0 + (h2/2)*(eta_c(k)+1)];
assert(norm(Xk - Xc(k,:).') < tol, ...
        'mapParentToPhysical:corner node %d not mapped correctly.', k);
end

% (iv) Bi-linearity / affine consistency: interpolation of a linear
%      field L(X) = c0 + c1*X1 + c2*X2 at the centre (0,0) is the
%      average of the four corner values.
x_c = (x0 + (x0+h1))/2;
y_c = (y0 + (y0+h2))/2;
Xcenter = [ ...
    x0 + h1/2; ...
    y0 + h2/2];
assert(abs(Xcenter(1) - x_c) < tol && abs(Xcenter(2) - y_c) < tol, ...
    'mapParentToPhysical:parent centre does not map to element centre.');

% (v) Edge midpoints:
%     bottom edge midpoint (xi=0, eta=-1) -> (x0+h1/2, y0)
Xbm = [ ...
    x0 + h1/2; ...
    y0];
assert(abs(Xbm(1) - (x0+h1/2)) < tol && abs(Xbm(2) - y0) < tol, ...
    'mapParentToPhysical:bottom-edge midpoint wrong.');
%     top edge midpoint (xi=0, eta=1) -> (x0+h1/2, y0+h2)
Xtm = [ ...
    x0 + h1/2; ...
    y0 + h2];
assert(abs(Xtm(1) - (x0+h1/2)) < tol && abs(Xtm(2) - (y0+h2)) < tol, ...
    'mapParentToPhysical:top-edge midpoint wrong.');
%     left  (xi=-1,eta=0) -> (x0,    y0+h2/2)
Xlm = [ ...
    x0; ...
    y0 + h2/2];
assert(abs(Xlm(1) - x0) < tol && abs(Xlm(2) - (y0+h2/2)) < tol, ...
    'mapParentToPhysical:left-edge midpoint wrong.');
%     right (xi= 1,eta=0) -> (x0+h1, y0+h2/2)
Xrm = [ ...
    x0 + h1; ...
    y0 + h2/2];
assert(abs(Xrm(1) - (x0+h1)) < tol && abs(Xrm(2) - (y0+h2/2)) < tol, ...
    'mapParentToPhysical:right-edge midpoint wrong.');

% (vi) Jacobian consistency: the directional derivative of the map
%      along xi must give (h1/2,0) and along eta (0,h2/2).  We verify
%      this via a finite-difference direction at the centre (internal
%      self-test; not used in FE assembly).
eps_fd = 1e-6;
Xp = [ ...
    x0 + (h1/2)*(eps_fd+1); ...
    y0 + h2/2];

Xm = [ ...
    x0 + (h1/2)*(-eps_fd+1); ...
    y0 + h2/2];
dX_dxi  = (Xp - Xm)/(2*eps_fd);
Xp = [ ...
    x0 + h1/2; ...
    y0 + (h2/2)*(eps_fd+1)];

Xm = [ ...
    x0 + h1/2; ...
    y0 + (h2/2)*(-eps_fd+1)];
dX_deta = (Xp - Xm)/(2*eps_fd);
assert(norm(dX_dxi  - [h1/2; 0])   < 1e-4, ...
    'mapParentToPhysical:numerical dX/dxi does not match Jacobian.');
assert(norm(dX_deta - [0;    h2/2]) < 1e-4, ...
    'mapParentToPhysical:numerical dX/deta does not match Jacobian.');

end
