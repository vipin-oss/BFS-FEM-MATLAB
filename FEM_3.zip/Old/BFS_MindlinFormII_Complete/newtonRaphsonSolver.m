function sol = newtonRaphsonSolver(mat, mesh, dof, gauss, Fext, varargin)
%NEWTONRAPHSONSOLVER Incremental Total-Lagrangian Newton--Raphson solver.
%
%   sol = newtonRaphsonSolver(mat, mesh, dof, gauss, Fext, ...
%                             'Name', Value, ...)
%
% Frozen Sections 7 and 9:
%   R_int(D) - lambda*F_ext = 0,
%   with strong essential boundary conditions and Newton updates supplied
%   by solveLoadStep.m.  Default solver controls are
%   tolR=tolD=tolE=1e-8, kMax=20, alpha=0.5, beta=1.2, kTarget=6.
%
% Verification is intentionally delegated to main.m, runVerificationSuite,
% and validate2022Benchmark.  This production solver does not recursively
% invoke itself through an internal test routine.

% ---------------------------------------------------------------------
% Options.
% ---------------------------------------------------------------------
p = inputParser;
addParameter(p, 'lambda0', 0, @isFiniteScalar);
addParameter(p, 'lambdaFinal', 1, @isFiniteScalar);
addParameter(p, 'nSteps', 10, @(x) isPositiveInteger(x));
addParameter(p, 'dlambda0', [], @(x) isempty(x) || (isFiniteScalar(x) && x > 0));
addParameter(p, 'dlambdaMin', 1e-8, @(x) isFiniteScalar(x) && x > 0);
addParameter(p, 'dlambdaMax', inf, @(x) isscalar(x) && isnumeric(x) && isreal(x) && x > 0);
addParameter(p, 'adaptive', true, @isLogicalScalar);
addParameter(p, 'alpha', 0.5, @(x) isFiniteScalar(x) && x > 0 && x < 1);
addParameter(p, 'beta', 1.2, @(x) isFiniteScalar(x) && x > 1);
addParameter(p, 'kTarget', 6, @isPositiveInteger);
addParameter(p, 'kMax', 20, @isPositiveInteger);
addParameter(p, 'tolR', 1e-8, @(x) isFiniteScalar(x) && x > 0);
addParameter(p, 'tolD', 1e-8, @(x) isFiniteScalar(x) && x > 0);
addParameter(p, 'tolE', 1e-8, @(x) isFiniteScalar(x) && x > 0);
addParameter(p, 'divergenceTol', 1e6, @(x) isFiniteScalar(x) && x > 0);
addParameter(p, 'maxCutbacks', 10, @(x) isNonnegativeInteger(x));
addParameter(p, 'verbose', false, @isLogicalScalar);
addParameter(p, 'D0', [], @(x) isempty(x) || (isnumeric(x) && isreal(x) && isvector(x)));
addParameter(p, 'linearMode', false, @isLogicalScalar);
parse(p, varargin{:});
o = p.Results;

o.adaptive = logical(o.adaptive);
o.verbose = logical(o.verbose);
o.linearMode = logical(o.linearMode);

% ---------------------------------------------------------------------
% Structural validation.
% ---------------------------------------------------------------------
assert(isstruct(dof) && isfield(dof, 'nDOF') && isfield(dof, 'elemDOF') && ...
       isfield(dof, 'freeDOF') && isfield(dof, 'essDOF') && isfield(dof, 'essVals'), ...
    ['newtonRaphsonSolver:dof must be a complete DOF map from ' ...
     'buildDOFMap/buildBoundaryConditions.']);

assert(isstruct(mesh) && isfield(mesh, 'nElem') && isfield(mesh, 'elemGeom'), ...
    'newtonRaphsonSolver:mesh must contain nElem and elemGeom.');

assert(isstruct(mat) && isstruct(gauss), ...
    'newtonRaphsonSolver:mat and gauss must be structs.');

nDOF = dof.nDOF;
assert(isPositiveInteger(nDOF), ...
    'newtonRaphsonSolver:dof.nDOF must be a positive integer.');

assert(o.lambdaFinal >= o.lambda0, ...
    'newtonRaphsonSolver:lambdaFinal must be greater than or equal to lambda0.');

Fext = Fext(:);
assert(isnumeric(Fext) && isreal(Fext) && all(isfinite(Fext)) && ...
       numel(Fext) == nDOF, ...
    'newtonRaphsonSolver:Fext must be a real finite nDOF-vector.');

if isempty(o.D0)
    D = zeros(nDOF, 1);
else
    D = o.D0(:);
    assert(numel(D) == nDOF && all(isfinite(D)), ...
        'newtonRaphsonSolver:D0 must be a real finite nDOF-vector.');
end

% Default increment follows the frozen fixed/adaptive load schedule.
if isempty(o.dlambda0)
    o.dlambda0 = (o.lambdaFinal - o.lambda0)/o.nSteps;
end

if o.lambdaFinal > o.lambda0
    assert(o.dlambda0 > 0, ...
        'newtonRaphsonSolver:dlambda0 must be positive for a nonzero load range.');
end

optsStep = struct( ...
    'kMax', o.kMax, ...
    'tolR', o.tolR, ...
    'tolD', o.tolD, ...
    'tolE', o.tolE, ...
    'divergenceTol', o.divergenceTol, ...
    'linsolver', 'backslash', ...
    'verbose', o.verbose);

% The implemented element residual/tangent is the frozen finite-strain
% SVK--Mindlin formulation.  A benchmark-labelled run still requires the
% normal Newton convergence process; it is not forcibly limited to one
% iteration unless a separate fully linear residual/tangent path exists.

% ---------------------------------------------------------------------
% History allocation.  The capacity covers nominal steps plus cutbacks.
% ---------------------------------------------------------------------
nCap = max(100, 10*o.nSteps + 10*o.maxCutbacks + 20);
D_hist = zeros(nDOF, nCap);
Rxn_hist = zeros(nDOF, nCap);
lam_hist = zeros(1, nCap);
conv_hist = false(1, nCap);
nIter_hist = zeros(1, nCap);
info_hist = cell(1, nCap);
dlambda_hist = zeros(1, nCap);
cutbacks_hist = zeros(1, nCap);

nStored = 0;
totalIter = 0;
lambda = o.lambda0;

% ---------------------------------------------------------------------
% Initial snapshot at lambda0.
% ---------------------------------------------------------------------
[D, ~] = updateEssentialDOFs(D, dof, lambda);
Rint0 = assembleGlobalResidual(D, mat, mesh, dof, gauss);
K0 = assembleGlobalTangent(D, mat, mesh, dof, gauss);
R0 = Rint0 - lambda*Fext;
Rxn0 = zeros(nDOF, 1);

if ~isempty(dof.essDOF)
    [~, ~, ~, reactionHandle] = applyDirichletBC(K0, R0, D, dof, lambda);
    Rxn0(dof.essDOF) = reactionHandle.compute(zeros(numel(dof.freeDOF), 1));
end

nStored = nStored + 1;
D_hist(:, nStored) = D;
Rxn_hist(:, nStored) = Rxn0;
lam_hist(nStored) = lambda;
conv_hist(nStored) = true;
nIter_hist(nStored) = 0;
info_hist{nStored} = struct('reason', 'Initial snapshot.', ...
                            'lambda', lambda, ...
                            'converged', true, ...
                            'diverged', false, ...
                            'nIter', 0);

if o.verbose
    fprintf(['[newtonRaphsonSolver] Starting at lambda=%.6g, ' ...
             'target=%.6g, adaptive=%d\n'], ...
        o.lambda0, o.lambdaFinal, double(o.adaptive));
end

% No loading is required when lambdaFinal=lambda0.
finalReached = abs(o.lambdaFinal - o.lambda0) <= eps(max(1, abs(o.lambdaFinal)));
maxStepsReached = false;
dlamba = o.dlambda0;
stepIdx = 0;

% ---------------------------------------------------------------------
% Incremental continuation / cutback loop.
% ---------------------------------------------------------------------
while ~finalReached && ~maxStepsReached
    stepIdx = stepIdx + 1;

    dlambda = min(dlamba, o.lambdaFinal - lambda);
    if dlambda <= 0
        break;
    end

    lambdaTry = lambda + dlambda;
    nCutbacks = 0;
    D_try = D;
    stepConverged = false;

    while true
        if o.verbose
            fprintf(['[newtonRaphsonSolver] Step %d, lambda=%.6g ' ...
                     '(dlambda=%.3g, cutback=%d)\n'], ...
                stepIdx, lambdaTry, dlambda, nCutbacks);
        end

        [D_try, Rxn_try, ~, stepOK, stepInfo] = solveLoadStep( ...
            D_try, mat, mesh, dof, gauss, Fext, lambdaTry, optsStep);

        if stepOK
            stepConverged = true;
            break;
        end

        nCutbacks = nCutbacks + 1;
        if nCutbacks > o.maxCutbacks
            break;
        end

        dlambda = dlambda*o.alpha;
        if dlambda < o.dlambdaMin
            break;
        end

        lambdaTry = lambda + dlambda;
        D_try = D;
    end

    % Grow histories if adaptive stepping exceeds the nominal capacity.
    if nStored + 1 > size(D_hist, 2)
        newCap = 2*size(D_hist, 2);
        D_hist(:, newCap) = 0;
        Rxn_hist(:, newCap) = 0;
        lam_hist(newCap) = 0;
        conv_hist(newCap) = false;
        nIter_hist(newCap) = 0;
        info_hist{newCap} = [];
        dlambda_hist(newCap) = 0;
        cutbacks_hist(newCap) = 0;
    end

    if ~stepConverged
        nStored = nStored + 1;
        D_hist(:, nStored) = D;
        Rxn_hist(:, nStored) = zeros(nDOF, 1);
        lam_hist(nStored) = lambdaTry;
        conv_hist(nStored) = false;
        nIter_hist(nStored) = -1;
        info_hist{nStored} = struct( ...
            'reason', 'Step failed after allowed cutbacks.', ...
            'lambda', lambdaTry, ...
            'converged', false, ...
            'diverged', true, ...
            'nIter', stepInfo.nIter);
        dlambda_hist(nStored) = dlambda;
        cutbacks_hist(nStored) = nCutbacks;

        if o.verbose
            fprintf(['[newtonRaphsonSolver] ABORT: step failed at ' ...
                     'lambda=%.6g after %d cutbacks.\n'], lambdaTry, nCutbacks);
        end
        break;
    end

    % Record accepted step.
    nStored = nStored + 1;
    D_hist(:, nStored) = D_try;
    Rxn_hist(:, nStored) = Rxn_try;
    lam_hist(nStored) = lambdaTry;
    conv_hist(nStored) = true;
    nIter_hist(nStored) = stepInfo.nIter;
    info_hist{nStored} = stepInfo;
    dlambda_hist(nStored) = dlambda;
    cutbacks_hist(nStored) = nCutbacks;

    totalIter = totalIter + stepInfo.nIter;
    D = D_try;
    lambda = lambdaTry;

    finalReached = abs(lambda - o.lambdaFinal) <= ...
        1e-14*max(1, abs(o.lambdaFinal));

    if finalReached
        continue;
    end

    if o.adaptive
        if stepInfo.nIter <= o.kTarget
            dlamba = min(dlambda*o.beta, o.dlambdaMax);
        elseif stepInfo.nIter >= o.kMax - 1
            dlamba = max(dlambda*o.alpha, o.dlambdaMin);
        else
            dlamba = dlambda;
        end
    else
        dlamba = o.dlambda0;
        if (nStored - 1) >= o.nSteps
            maxStepsReached = true;
        end
    end

    dlamba = min(max(dlamba, o.dlambdaMin), o.dlambdaMax);
end

% ---------------------------------------------------------------------
% Trim and return the documented solution object.
% ---------------------------------------------------------------------
keep = 1:nStored;

sol = struct();
sol.D = D_hist(:, keep);
sol.Rxn = Rxn_hist(:, keep);
sol.lambda = lam_hist(keep);
sol.converged = conv_hist(keep);
sol.nIter = nIter_hist(keep);
sol.stepInfo = info_hist(keep);
sol.dlambdaHist = dlambda_hist(keep);
sol.cutbacks = cutbacks_hist(keep);
sol.loadHist = struct('dlambda', dlambda_hist(keep), ...
                      'cutbacks', cutbacks_hist(keep));
sol.totalIter = totalIter;
sol.finalConv = finalReached && conv_hist(nStored);
sol.nDOF = nDOF;
sol.nFree = numel(dof.freeDOF);
sol.nEss = numel(dof.essDOF);
sol.opts = o;

if o.verbose
    fprintf(['[newtonRaphsonSolver] Done. lambda(end)=%.6g, ' ...
             'converged=%d, totalIter=%d\n'], ...
        sol.lambda(end), sol.finalConv, sol.totalIter);
end

end

% =====================================================================
% Local validation helpers.
% =====================================================================
function tf = isFiniteScalar(x)
tf = isnumeric(x) && isreal(x) && isfinite(x) && isscalar(x);
end

function tf = isPositiveInteger(x)
tf = isFiniteScalar(x) && x >= 1 && x == round(x);
end

function tf = isNonnegativeInteger(x)
tf = isFiniteScalar(x) && x >= 0 && x == round(x);
end

function tf = isLogicalScalar(x)
tf = (islogical(x) && isscalar(x)) || ...
     (isnumeric(x) && isreal(x) && isfinite(x) && isscalar(x) && ...
      (x == 0 || x == 1));
end
