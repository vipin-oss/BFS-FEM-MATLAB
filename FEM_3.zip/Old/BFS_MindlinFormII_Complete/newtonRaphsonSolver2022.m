function sol = newtonRaphsonSolver2022(prob)
%NEWTONRAPHSONSOLVER2022 Benchmark-only continuation with periodic MPCs.
%
% The frozen element residual/tangent are reused unchanged.  Only the
% benchmark constraint transformation and Case-2 traction vector differ.

mat = prob.mat;
mesh = prob.mesh;
dof = prob.dof;
gauss = prob.gauss;
constraints = prob.constraints;
Fext = prob.Fext;
o = prob.solver;

q = zeros(constraints.nq, 1);
lambda = o.lambda0;
dl = (o.lambdaFinal - o.lambda0)/o.nSteps;

nCap = max(2, o.nSteps + 1);
Dhist = zeros(dof.nDOF, nCap);
Rxnhist = zeros(dof.nDOF, nCap);
lambdaHist = zeros(1, nCap);
convHist = false(1, nCap);
nIterHist = zeros(1, nCap);
stepInfo = cell(1, nCap);

D = constraints.T*q + lambda*constraints.Dbar;
R0 = assembleGlobalResidual(D, mat, mesh, dof, gauss) - lambda*Fext;

nStored = 1;
Dhist(:, 1) = D;
Rxnhist(:, 1) = R0;
lambdaHist(1) = lambda;
convHist(1) = true;
nIterHist(1) = 0;
stepInfo{1} = struct('nIter', 0, 'converged', true, 'diverged', false, ...
                     'reason', 'Initial benchmark state.', 'lambda', lambda);

totalIter = 0;
finalConv = (o.lambdaFinal == o.lambda0);

opts = struct('kMax', o.kMax, 'tolR', o.tolR, 'tolD', o.tolD, ...
              'tolE', o.tolE, 'divergenceTol', o.divergenceTol, ...
              'verbose', o.verbose);

for step = 1:o.nSteps
    lambdaTry = min(o.lambdaFinal, lambda + dl);

    [qTry, Dtry, RxnTry, ~, ok, info] = solveLoadStep2022( ...
        q, constraints, mat, mesh, dof, gauss, Fext, lambdaTry, opts);

    nStored = nStored + 1;
    Dhist(:, nStored) = Dtry;
    Rxnhist(:, nStored) = RxnTry;
    lambdaHist(nStored) = lambdaTry;
    convHist(nStored) = ok;
    nIterHist(nStored) = info.nIter;
    stepInfo{nStored} = info;
    totalIter = totalIter + info.nIter;

    if ~ok
        break;
    end

    q = qTry;
    lambda = lambdaTry;
    if abs(lambda - o.lambdaFinal) <= 1e-14*max(1, abs(o.lambdaFinal))
        finalConv = true;
        break;
    end
end

keep = 1:nStored;
sol = struct();
sol.D = Dhist(:, keep);
sol.Rxn = Rxnhist(:, keep);
sol.lambda = lambdaHist(keep);
sol.converged = convHist(keep);
sol.nIter = nIterHist(keep);
sol.stepInfo = stepInfo(keep);
sol.totalIter = totalIter;
sol.finalConv = finalConv && convHist(nStored);
sol.nDOF = dof.nDOF;
sol.nIndependent = constraints.nq;
sol.constraints = constraints;

end
