function figs = plot2FiniteStrainMeshStudy(study)
%PLOT2FINITESTRAINMESHSTUDY SCI-style plots for Study 02.
%
%   figs = plot2FiniteStrainMeshStudy(study2full)
%
% Figure 3: mesh-reference errors, separated by load regime.
% Figure 4: mesh responses, separated by load regime.
% No automatic file export is performed and all legends are movable.

assert(isstruct(study) && isfield(study, 'results') && ...
       isfield(study, 'ellList') && isfield(study, 'loadCases'), ...
    'plot2FiniteStrainMeshStudy:invalid study struct.');

ellList = study.ellList(:).';
loadCases = study.loadCases;
colors = [0.0000 0.4470 0.7410; ...
          0.8500 0.3250 0.0980; ...
          0.4660 0.6740 0.1880];
markers = {'o', 's', '^'};
ellLabels = cell(1, numel(ellList));
for ie = 1:numel(ellList)
    ellLabels{ie} = ['$\ell/H=', num2str(ellList(ie)/study.opts.H, '%.2g'), '$'];
end

% =====================================================================
% Figure 3: numerical-reference error convergence.
% =====================================================================
figError = figure('Name', 'Fig03_FiniteStrainMeshErrors', ...
    'Color', 'w', 'Position', [100 100 1120 650]);
tlError = tiledlayout(figError, 2, 2, 'Padding', 'compact', 'TileSpacing', 'compact');

for il = 1:numel(loadCases)
    axTip = nexttile(tlError, 2*il - 1);
    axEnergy = nexttile(tlError, 2*il);
    hold(axTip, 'on'); hold(axEnergy, 'on');
    grid(axTip, 'on'); grid(axEnergy, 'on');
    box(axTip, 'on'); box(axEnergy, 'on');

    hTip = gobjects(1, numel(ellList));
    hEnergy = gobjects(1, numel(ellList));

    for ie = 1:numel(ellList)
        item = study.results{ie, il};
        hbar = 1./item.NeY;
        valid = 1:(numel(hbar) - 1); % omit zero-error overkill point
        color = colors(1 + mod(ie - 1, size(colors, 1)), :);
        marker = markers{1 + mod(ie - 1, numel(markers))};

        hTip(ie) = loglog(axTip, hbar(valid), max(item.tipError(valid), 1e-16), ...
            ['-' marker], 'Color', color, 'MarkerFaceColor', 'w', ...
            'LineWidth', 1.6, 'MarkerSize', 5);
        hEnergy(ie) = loglog(axEnergy, hbar(valid), max(item.energyError(valid), 1e-16), ...
            ['-' marker], 'Color', color, 'MarkerFaceColor', 'w', ...
            'LineWidth', 1.6, 'MarkerSize', 5);
    end

    lgdTip = legend(axTip, hTip, ellLabels, 'Interpreter', 'latex', ...
        'FontSize', 9, 'Box', 'on');
    lgdEnergy = legend(axEnergy, hEnergy, ellLabels, 'Interpreter', 'latex', ...
        'FontSize', 9, 'Box', 'on');

    xlabel(axTip, '$h/H$', 'Interpreter', 'latex');
    ylabel(axTip, '$|u_{\mathrm{tip}}-u_{\mathrm{tip}}^{\mathrm{ref}}|/|u_{\mathrm{tip}}^{\mathrm{ref}}|$', ...
        'Interpreter', 'latex');
    title(axTip, sprintf('(%c) %s load: tip error', ...
        char('a' + 2*(il - 1)), loadCases(il).name), ...
        'Interpreter', 'latex', 'FontWeight', 'normal');

    xlabel(axEnergy, '$h/H$', 'Interpreter', 'latex');
    ylabel(axEnergy, '$|\Pi-\Pi^{\mathrm{ref}}|/|\Pi^{\mathrm{ref}}|$', ...
        'Interpreter', 'latex');
    title(axEnergy, sprintf('(%c) %s load: energy error', ...
        char('b' + 2*(il - 1)), loadCases(il).name), ...
        'Interpreter', 'latex', 'FontWeight', 'normal');

    set(axTip, 'XDir', 'reverse');
    set(axEnergy, 'XDir', 'reverse');
end
applyJournalStyle(figError);

% =====================================================================
% Figure 4: response stabilization under refinement.
% Small and finite load data are separated to avoid scale masking.
% =====================================================================
figResponse = figure('Name', 'Fig04_FiniteStrainMeshResponses', ...
    'Color', 'w', 'Position', [120 120 1120 650]);
tlResponse = tiledlayout(figResponse, 2, 2, 'Padding', 'compact', 'TileSpacing', 'compact');

for il = 1:numel(loadCases)
    axU = nexttile(tlResponse, il);
    axW = nexttile(tlResponse, il + 2);
    hold(axU, 'on'); hold(axW, 'on');
    grid(axU, 'on'); grid(axW, 'on');
    box(axU, 'on'); box(axW, 'on');

    hU = gobjects(1, numel(ellList));
    hW = gobjects(1, numel(ellList));

    for ie = 1:numel(ellList)
        item = study.results{ie, il};
        hbar = 1./item.NeY;
        color = colors(1 + mod(ie - 1, size(colors, 1)), :);
        marker = markers{1 + mod(ie - 1, numel(markers))};

        hU(ie) = plot(axU, hbar, item.tipDisplacement/study.opts.H, ...
            ['-' marker], 'Color', color, 'MarkerFaceColor', 'w', ...
            'LineWidth', 1.6, 'MarkerSize', 5);

        % Each energy is normalized by its own finest-mesh reference.
        hW(ie) = plot(axW, hbar, item.energy/item.referenceEnergy, ...
            ['-' marker], 'Color', color, 'MarkerFaceColor', 'w', ...
            'LineWidth', 1.6, 'MarkerSize', 5);
    end

    lgdU = legend(axU, hU, ellLabels, 'Interpreter', 'latex', ...
        'FontSize', 9, 'Box', 'on', 'Location', 'southeast');
    lgdW = legend(axW, hW, ellLabels, 'Interpreter', 'latex', ...
        'FontSize', 9, 'Box', 'on', 'Location', 'southeast');

    xlabel(axU, '$h/H$', 'Interpreter', 'latex');
    ylabel(axU, '$u_{\mathrm{tip}}/H$', 'Interpreter', 'latex');
    title(axU, sprintf('(%c) %s load: tip response', ...
        char('a' + il - 1), loadCases(il).name), ...
        'Interpreter', 'latex', 'FontWeight', 'normal');

    xlabel(axW, '$h/H$', 'Interpreter', 'latex');
    ylabel(axW, '$\Pi_{\mathrm{int}}/\Pi_{\mathrm{int}}^{\mathrm{ref}}$', ...
        'Interpreter', 'latex');
    title(axW, sprintf('(%c) %s load: energy response', ...
        char('c' + il - 1), loadCases(il).name), ...
        'Interpreter', 'latex', 'FontWeight', 'normal');

    set(axU, 'XDir', 'reverse');
    set(axW, 'XDir', 'reverse');
end
applyJournalStyle(figResponse);

printStudyTable(study);
figs = struct('errors', figError, 'responses', figResponse);

end

function printStudyTable(study)
fprintf('\n=========================================================\n');
fprintf(' Study 02: finite-strain mesh-convergence summary\n');
fprintf('=========================================================\n');
for il = 1:numel(study.loadCases)
    for ie = 1:numel(study.ellList)
        item = study.results{ie, il};
        fprintf('load=%s, ell=%g\n', item.loadName, item.ell);
        fprintf(' NeXxNeY       tip/H        energy          tip err      energy err    iter\n');
        for k = 1:numel(item.NeY)
            fprintf(' %3dx%-3d  % .4e  % .4e  % .3e  % .3e  %d\n', ...
                item.NeX(k), item.NeY(k), ...
                item.tipDisplacement(k)/study.opts.H, item.energy(k), ...
                item.tipError(k), item.energyError(k), item.totalIterations(k));
        end
    end
end
end

function applyJournalStyle(fig)
axesList = findall(fig, 'Type', 'axes');
for k = 1:numel(axesList)
    set(axesList(k), 'FontName', 'Times New Roman', 'FontSize', 10, ...
        'LineWidth', 0.8, 'TickLabelInterpreter', 'latex', 'Layer', 'top');
end
end
