function fig = plot5GradientSensitivityHeatmap(study)
%PLOT5GRADIENTSENSITIVITYHEATMAP Colour heatmap for Study 05.
%
%   fig = plot5GradientSensitivityHeatmap(study5)
%
% Produces the main-paper Fig06 sensitivity heatmap.  No file is saved.

assert(isstruct(study) && isfield(study, 'sensitivity') && ...
       isfield(study, 'parameterNames') && isfield(study, 'responseNames'), ...
    'plot5GradientSensitivityHeatmap:invalid Study-5 result struct.');

S = study.sensitivity;
fig = figure('Name', 'Fig06_GradientSensitivity', ...
    'Color', 'w', 'Position', [100 100 900 560]);
ax = axes(fig);
imagesc(ax, S);
axis(ax, 'tight');

% Symmetric diverging colour scale.
cmax = max(abs(S(:)), [], 'omitnan');
if isempty(cmax) || cmax == 0
    cmax = 1;
end
caxis(ax, [-cmax, cmax]);
colormap(ax, blueWhiteRed(256));

xLabels = {'$K_{\mathrm{app}}$', '$u_{\mathrm{tip}}$', ...
           '$\Pi_{\mathrm{int}}$', '$\max|\mathcal{G}|$'};
yLabels = {'$a_1$', '$a_2$', '$a_3$', '$a_4$', '$a_5$'};

set(ax, 'YDir', 'normal', ...
    'XTick', 1:numel(study.responseNames), ...
    'YTick', 1:numel(study.parameterNames), ...
    'XTickLabel', xLabels, ...
    'YTickLabel', yLabels, ...
    'XTickLabelRotation', 0, ...
    'FontName', 'Times New Roman', 'FontSize', 12, ...
    'TickLabelInterpreter', 'latex', 'LineWidth', 0.8, 'Layer', 'top');

xlabel(ax, 'response quantity', 'Interpreter', 'latex');
ylabel(ax, 'perturbed gradient parameter', 'Interpreter', 'latex');

% Cell boundaries make each parameter/response combination explicit.
for x = 1.5:1:(size(S,2)-0.5)
    xline(ax, x, '-', 'Color', [0.75 0.75 0.75], 'LineWidth', 0.6);
end
for y = 1.5:1:(size(S,1)-0.5)
    yline(ax, y, '-', 'Color', [0.75 0.75 0.75], 'LineWidth', 0.6);
end
title(ax, 'Logarithmic one-at-a-time sensitivity', ...
    'Interpreter', 'latex', 'FontWeight', 'normal');

cb = colorbar(ax);
cb.TickLabelInterpreter = 'latex';
ylabel(cb, '$\partial\ln Q/\partial\ln a_i$', 'Interpreter', 'latex');

% Numeric labels make the heatmap quantitatively readable in print.
for i = 1:size(S, 1)
    for j = 1:size(S, 2)
        if isnan(S(i,j))
            label = 'NaN';
        else
            label = sprintf('%.2f', S(i,j));
        end
        if abs(S(i,j)) > 0.55*cmax
            textColor = 'w';
        else
            textColor = 'k';
        end
        text(ax, j, i, label, 'HorizontalAlignment', 'center', ...
            'FontName', 'Times New Roman', 'FontSize', 10, 'Color', textColor);
    end
end

end

function cmap = blueWhiteRed(n)
% Compact diverging colormap: blue -> white -> red.
if mod(n, 2) ~= 0
    n = n + 1;
end
n2 = n/2;
blue = [0.230 0.299 0.754];
white = [1 1 1];
red = [0.706 0.016 0.150];
cmap = [interp1([0 1], [blue; white], linspace(0,1,n2)); ...
        interp1([0 1], [white; red], linspace(0,1,n2))];
end
