function fig = plot6HigherOrderBCStudy(study)
%PLOT6HIGHERORDERBCSTUDY Colour contour comparison for Study 06.
%
%   fig = plot6HigherOrderBCStudy(study6)
%
% Creates Fig07_HigherOrderBCComparison using the finite-load solutions:
% clamped H|Grad(E)|, soft-support H|Grad(E)|, and their difference.

assert(isstruct(study) && isfield(study, 'results') && ...
       isfield(study, 'bcCases') && isfield(study, 'loadCases'), ...
    'plot6HigherOrderBCStudy:invalid Study-6 result struct.');

finiteIndex = find(strcmp({study.loadCases.name}, 'finite'), 1, 'first');
assert(~isempty(finiteIndex), ...
    'plot6HigherOrderBCStudy:finite load case not found.');

clampedIndex = find(strcmp({study.bcCases.name}, 'clamped'), 1, 'first');
softIndex = find(strcmp({study.bcCases.name}, 'soft'), 1, 'first');
assert(~isempty(clampedIndex) && ~isempty(softIndex), ...
    'plot6HigherOrderBCStudy:clamped/soft cases not found.');

clamped = study.results{clampedIndex, finiteIndex};
soft = study.results{softIndex, finiteIndex};
assert(clamped.converged && soft.converged, ...
    'plot6HigherOrderBCStudy:both finite-load cases must converge.');

Gclamped = elementGnorm(clamped.solution, study.opts.H);
Gsoft = elementGnorm(soft.solution, study.opts.H);
deltaG = Gsoft.values - Gclamped.values;

commonMax = max([Gclamped.values; Gsoft.values]);
deltaMax = max(abs(deltaG));
if deltaMax == 0
    deltaMax = 1;
end

fig = figure('Name', 'Fig07_HigherOrderBCComparison', ...
    'Color', 'w', 'Position', [100 100 1180 470]);
tl = tiledlayout(fig, 1, 3, 'Padding', 'compact', 'TileSpacing', 'compact');

ax1 = nexttile(tl, 1);
plotField(ax1, clamped.solution.mesh.connect, clamped.solution.mesh.X, ...
    deformedNodes(clamped.solution), Gclamped.values, [0 commonMax], ...
    parula(256), '$H|\mathcal{G}|$', '(a) Fully clamped');

ax2 = nexttile(tl, 2);
plotField(ax2, soft.solution.mesh.connect, soft.solution.mesh.X, ...
    deformedNodes(soft.solution), Gsoft.values, [0 commonMax], ...
    parula(256), '$H|\mathcal{G}|$', '(b) Soft support');

ax3 = nexttile(tl, 3);
plotField(ax3, soft.solution.mesh.connect, soft.solution.mesh.X, ...
    deformedNodes(soft.solution), deltaG, [-deltaMax deltaMax], ...
    blueWhiteRed(256), '$\Delta(H|\mathcal{G}|)$', '(c) Soft minus clamped');

applyStyle(fig);

end

function plotField(ax, faces, Xref, Xdef, values, limits, cmap, cbLabel, panelTitle)
hold(ax, 'on');
axis(ax, 'equal');
box(ax, 'on');
patch(ax, 'Faces', faces, 'Vertices', Xdef, ...
    'FaceVertexCData', values, 'FaceColor', 'flat', ...
    'EdgeColor', [0.30 0.30 0.30], 'LineWidth', 0.25);

% Retain the original equal-aspect display used for the selected figure.
colormap(ax, cmap);
caxis(ax, limits);
cb = colorbar(ax);
cb.TickLabelInterpreter = 'latex';
% The field name is already given in the panel title; omitting a second
% colorbar label avoids overlap with the axis labels in a compact layout.
xlabel(ax, '$x_1/H$', 'Interpreter', 'latex');
ylabel(ax, '$x_2/H$', 'Interpreter', 'latex');
title(ax, panelTitle, 'Interpreter', 'latex', 'FontWeight', 'normal');
end

function field = elementGnorm(sol, Hscale)
% Smooth display field sampled at element centres.  The study's reported
% max|G| values remain Gauss-point quantities; this centre sample is used
% only for a clean visual contour.
mesh = sol.mesh; dof = sol.dof; D = sol.D(:,end);
field.values = zeros(mesh.nElem,1);
for e = 1:mesh.nElem
    eg = mesh.elemGeom(e); de = D(dof.elemDOF(e,:));
    dN=bfsShapeFunctionDerivatives(0,0,eg.h1,eg.h2);
    s1=2/eg.h1; s2=2/eg.h2; s11=s1*s1; s22=s2*s2; s12=s1*s2;
    gradU=zeros(2,2); H=zeros(2,2,2);
    gradU(1,1)=s1*dN.dNdxi(1,1:16)*de(1:16); gradU(1,2)=s2*dN.dNdeta(1,1:16)*de(1:16);
    gradU(2,1)=s1*dN.dNdxi(2,17:32)*de(17:32); gradU(2,2)=s2*dN.dNdeta(2,17:32)*de(17:32);
    H(1,1,1)=s11*dN.d2Ndxi2(1,1:16)*de(1:16); H(1,2,2)=s22*dN.d2Ndeta2(1,1:16)*de(1:16);
    H(1,1,2)=s12*dN.d2Ndxideta(1,1:16)*de(1:16); H(1,2,1)=H(1,1,2);
    H(2,1,1)=s11*dN.d2Ndxi2(2,17:32)*de(17:32); H(2,2,2)=s22*dN.d2Ndeta2(2,17:32)*de(17:32);
    H(2,1,2)=s12*dN.d2Ndxideta(2,17:32)*de(17:32); H(2,2,1)=H(2,1,2);
    F=eye(2)+gradU; G=zeros(2,2,2);
    for I=1:2, for J=1:2, for K=1:2, for m=1:2
        G(I,J,K)=G(I,J,K)+0.5*(H(m,I,K)*F(m,J)+F(m,I)*H(m,J,K));
    end, end, end, end
    field.values(e)=Hscale*norm(G(:));
end
end

function Xdef = deformedNodes(sol)
mesh=sol.mesh; dof=sol.dof; D=sol.D(:,end); Xdef=mesh.X;
for n=1:mesh.nNodes
    Xdef(n,1)=Xdef(n,1)+D(dof.ID(1,1,n));
    Xdef(n,2)=Xdef(n,2)+D(dof.ID(1,2,n));
end
end

function cmap = blueWhiteRed(n)
if mod(n,2)~=0, n=n+1; end
n2=n/2; blue=[0.230 0.299 0.754]; white=[1 1 1]; red=[0.706 0.016 0.150];
cmap=[interp1([0 1],[blue;white],linspace(0,1,n2)); ...
      interp1([0 1],[white;red],linspace(0,1,n2))];
end

function applyStyle(fig)
axesList=findall(fig,'Type','axes');
for k=1:numel(axesList)
    set(axesList(k),'FontName','Times New Roman','FontSize',10, ...
        'LineWidth',0.8,'TickLabelInterpreter','latex','Layer','top');
end
end
