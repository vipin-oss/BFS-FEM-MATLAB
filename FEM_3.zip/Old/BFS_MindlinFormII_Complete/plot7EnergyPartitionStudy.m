function fig = plot7EnergyPartitionStudy(study)
%PLOT7ENERGYPARTITIONSTUDY Colour stacked-bar energy partition.
%
%   fig = plot7EnergyPartitionStudy(study7)
%
% Creates Fig08_EnergyPartition.  No automatic file export is performed.

assert(isstruct(study) && isfield(study, 'Wsvk') && isfield(study, 'Wgrad'), ...
    'plot7EnergyPartitionStudy:invalid Study-7 energy result struct.');

x = 1:numel(study.ellOverH);
Wref = study.Wtotal(1);
energyBars = [study.Wsvk(:)/Wref, study.Wgrad(:)/Wref];

fig = figure('Name', 'Fig08_EnergyPartition', ...
    'Color', 'w', 'Position', [100 100 880 560]);
ax = axes(fig);
h = bar(ax, x, energyBars, 'stacked', 'BarWidth', 0.62);
h(1).FaceColor = [0.10 0.45 0.75];
h(2).FaceColor = [0.90 0.35 0.10];
h(1).EdgeColor = [0.15 0.15 0.15];
h(2).EdgeColor = [0.15 0.15 0.15];

grid(ax, 'on'); box(ax, 'on');
set(ax, 'XTick', x, ...
    'XTickLabel', arrayfun(@(v) ['$\ell/H=' num2str(v,'%.2g') '$'], ...
        study.ellOverH, 'UniformOutput', false), ...
    'FontName', 'Times New Roman', 'FontSize', 11, ...
    'TickLabelInterpreter', 'latex', 'LineWidth', 0.8, 'Layer', 'top');

xlabel(ax, 'internal length scale', 'Interpreter', 'latex');
ylabel(ax, '$\Pi/\Pi^{\ell=0}_{\mathrm{int}}$', 'Interpreter', 'latex');
% No in-panel title: the publication caption carries the full description.
yline(ax, 1, 'k--', 'LineWidth', 0.8, 'HandleVisibility', 'off');
ylim(ax, [0 1.10]);
legend(ax, {'SVK energy', 'gradient energy'}, 'Interpreter', 'latex', ...
    'FontSize', 10, 'Box', 'on', 'Location', 'southoutside', ...
    'Orientation', 'horizontal');

% Annotate gradient-energy fraction above each stacked bar.
for i = 1:numel(x)
    if study.Wtotal(i) > 0
        frac = 100*study.gradientFraction(i);
        text(ax, x(i), sum(energyBars(i,:)) + 0.025, sprintf('%.1f%%',frac), ...
            'HorizontalAlignment', 'center', 'FontName', 'Times New Roman', ...
            'FontSize', 10);
    end
end

end
