function fig = plot7NonlinearResponseMap(study)
%PLOT7NONLINEARRESPONSEMAP Colour two-parameter map for Study 07.
%
%   fig = plot7NonlinearResponseMap(study7)
%
% Fig08 shows stiffness enhancement and gradient suppression across the
% combined load--length-scale domain.  No file is saved automatically.

assert(isstruct(study) && isfield(study, 'Kratio') && ...
       isfield(study, 'Gratio') && isfield(study, 'ellList'), ...
    'plot7NonlinearResponseMap:invalid Study-7 result struct.');

ellOverH = study.ellList/study.opts.H;
tractionOverE = study.tractionList/study.opts.E;

fig = figure('Name', 'Fig08_NonlinearResponseMap', ...
    'Color', 'w', 'Position', [100 100 1100 500]);
tl = tiledlayout(fig, 1, 2, 'Padding', 'compact', 'TileSpacing', 'compact');

axK = nexttile(tl,1);
plotMap(axK, ellOverH, tractionOverE, study.Kratio, ...
    '$K_{\mathrm{app}}/K_{\mathrm{app}}^{\ell=0}$', ...
    '(a) Gradient-induced stiffness map', false);

axG = nexttile(tl,2);
plotMap(axG, ellOverH, tractionOverE, study.Gratio, ...
    '$\max|\mathcal{G}|/\max|\mathcal{G}|_{\ell=0}$', ...
    '(b) Strain-gradient localization map', true);

end

function plotMap(ax, x, y, values, cbLabel, panelTitle, invertMap)
% imagesc expects rows=y/load levels and columns=x/length scales.
imagesc(ax, x, y, values);
set(ax, 'YDir', 'normal', 'FontName', 'Times New Roman', ...
    'FontSize', 11, 'TickLabelInterpreter', 'latex', ...
    'LineWidth', 0.8, 'Layer', 'top');
colormap(ax, parula(256));

xlabel(ax, '$\ell/H$', 'Interpreter', 'latex');
ylabel(ax, '$\bar{t}/E$', 'Interpreter', 'latex');
title(ax, panelTitle, 'Interpreter', 'latex', 'FontWeight', 'normal');

cb = colorbar(ax);
cb.TickLabelInterpreter = 'latex';
ylabel(cb, cbLabel, 'Interpreter', 'latex');

% Draw cell boundaries and print values for journal readability.
for i = 1:numel(x)
    for j = 1:numel(y)
        value = values(j,i);
        if isnan(value)
            label = 'NaN';
            textColor = 'k';
        else
            label = sprintf('%.3f', value);
            midValue = 0.5*(min(values(:),[],'omitnan') + max(values(:),[],'omitnan'));
            textColor = ternary(value > midValue, 'w', 'k');
        end
        text(ax, x(i), y(j), label, 'HorizontalAlignment', 'center', ...
            'FontName', 'Times New Roman', 'FontSize', 9, 'Color', textColor);
    end
end

% Set visibly separated cell boundaries for nonuniform physical axes.
if numel(x) > 1
    for i = 1:numel(x)-1
        xline(ax, 0.5*(x(i)+x(i+1)), '-', 'Color', [0.8 0.8 0.8], 'LineWidth', 0.6);
    end
end
if numel(y) > 1
    for j = 1:numel(y)-1
        yline(ax, 0.5*(y(j)+y(j+1)), '-', 'Color', [0.8 0.8 0.8], 'LineWidth', 0.6);
    end
end

end

function out = ternary(condition,a,b)
if condition, out=a; else, out=b; end
end
