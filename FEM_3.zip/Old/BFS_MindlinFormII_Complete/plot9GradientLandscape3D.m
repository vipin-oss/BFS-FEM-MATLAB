function fig = plot9GradientLandscape3D(study4)
%PLOT9GRADIENTLANDSCAPE3D Genuine 3D visualization of 2D gradient field.
%
%   fig = plot9GradientLandscape3D(study4)
%
% The x-y plane is the deformed 2D cantilever configuration.  The vertical
% coordinate and colour both represent H|Grad(E)|.  This is a 3D graphical
% rendering of actual 2D solver data; it is not a fictitious 3D material
% model or orientation-dependent characteristic-length surface.

assert(isstruct(study4) && isfield(study4, 'results') && ...
       isfield(study4, 'ellList'), ...
    'plot9GradientLandscape3D:Study-4 result struct required.');

classicalIndex = find(study4.ellList == 0, 1, 'first');
gradientIndex = numel(study4.ellList);
selected = [classicalIndex, gradientIndex];
land = cell(1, 2);
maxZ = 0;
for k = 1:2
    land{k} = nodalGradientLandscape(study4.results{selected(k)}.solution, study4.opts.H);
    maxZ = max(maxZ, max(land{k}.Z(:)));
end

fig = figure('Name', 'Fig09_GradientLandscape3D', ...
    'Color', 'w', 'Position', [100 100 1180 540]);
tl = tiledlayout(fig, 1, 2, 'Padding', 'compact', 'TileSpacing', 'compact');

for k = 1:2
    item = study4.results{selected(k)};
    ax = nexttile(tl, k);
    surf(ax, land{k}.X/study4.opts.H, land{k}.Y/study4.opts.H, land{k}.Z, ...
        land{k}.Z, 'EdgeColor', [0.25 0.25 0.25], 'LineWidth', 0.25);
    shading(ax, 'interp');
    colormap(ax, parula(256));
    caxis(ax, [0 maxZ]);
    cb = colorbar(ax);
    cb.TickLabelInterpreter = 'latex';
    ylabel(cb, '$H|\mathcal{G}|$', 'Interpreter', 'latex');
    xlabel(ax, '$x_1/H$', 'Interpreter', 'latex');
    ylabel(ax, '$x_2/H$', 'Interpreter', 'latex');
    zlabel(ax, '$H|\mathcal{G}|$', 'Interpreter', 'latex');
    title(ax, ['$\ell/H=' num2str(item.ellOverH, '%.2g') '$'], ...
        'Interpreter', 'latex', 'FontWeight', 'normal');
    view(ax, 42, 28);
    grid(ax, 'on'); box(ax, 'on');
    set(ax, 'FontName', 'Times New Roman', 'FontSize', 10, ...
        'TickLabelInterpreter', 'latex', 'LineWidth', 0.8, 'Layer', 'top');
end

end

% =====================================================================
% Convert Gauss-point finite strain-gradient values to a nodal landscape.
% =====================================================================
function land = nodalGradientLandscape(sol, Hscale)
mesh = sol.mesh; dof = sol.dof; gauss = sol.gauss; D = sol.D(:,end);
nodeSum = zeros(mesh.nNodes, 1);
nodeCount = zeros(mesh.nNodes, 1);

for e = 1:mesh.nElem
    eg = mesh.elemGeom(e); de = D(dof.elemDOF(e,:));
    s1=2/eg.h1; s2=2/eg.h2; s11=s1*s1; s22=s2*s2; s12=s1*s2;
    elementSum = 0;

    for gp=1:gauss.nGP
        dN=bfsShapeFunctionDerivatives(gauss.xi(gp),gauss.eta(gp),eg.h1,eg.h2);
        gradU=zeros(2,2); H=zeros(2,2,2);
        gradU(1,1)=s1*dN.dNdxi(1,1:16)*de(1:16); gradU(1,2)=s2*dN.dNdeta(1,1:16)*de(1:16);
        gradU(2,1)=s1*dN.dNdxi(2,17:32)*de(17:32); gradU(2,2)=s2*dN.dNdeta(2,17:32)*de(17:32);
        H(1,1,1)=s11*dN.d2Ndxi2(1,1:16)*de(1:16); H(1,2,2)=s22*dN.d2Ndeta2(1,1:16)*de(1:16);
        H(1,1,2)=s12*dN.d2Ndxideta(1,1:16)*de(1:16); H(1,2,1)=H(1,1,2);
        H(2,1,1)=s11*dN.d2Ndxi2(2,17:32)*de(17:32); H(2,2,2)=s22*dN.d2Ndeta2(2,17:32)*de(17:32);
        H(2,1,2)=s12*dN.d2Ndxideta(2,17:32)*de(17:32); H(2,2,1)=H(2,1,2);
        F=eye(2)+gradU; G=zeros(2,2,2);
        for I=1:2, for J=1:2, for K=1:2, for m=1:2
            G(I,J,K)=G(I,J,K)+0.5*(H(m,I,K)*F(m,J)+F(m,I)*H(m,J,K));
        end, end, end, end
        elementSum = elementSum + Hscale*norm(G(:));
    end

    elementValue = elementSum/gauss.nGP;
    nodes = mesh.connect(e,:);
    nodeSum(nodes) = nodeSum(nodes) + elementValue;
    nodeCount(nodes) = nodeCount(nodes) + 1;
end

nodeValue = nodeSum./max(nodeCount,1);
Xdef = mesh.X;
for n=1:mesh.nNodes
    Xdef(n,1)=Xdef(n,1)+D(dof.ID(1,1,n));
    Xdef(n,2)=Xdef(n,2)+D(dof.ID(1,2,n));
end

% Nodes are lexicographically numbered: X1 index varies fastest.
land.X = reshape(Xdef(:,1), mesh.Ne1+1, mesh.Ne2+1);
land.Y = reshape(Xdef(:,2), mesh.Ne1+1, mesh.Ne2+1);
land.Z = reshape(nodeValue, mesh.Ne1+1, mesh.Ne2+1);
end
