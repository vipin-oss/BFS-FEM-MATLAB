function fig = plotBenchmarkConvergenceSCI2022(bench2022)
%PLOTBENCHMARKCONVERGENCESCI2022 Journal-style dimensionless h-convergence.
%
%   fig = plotBenchmarkConvergenceSCI2022(bench2022)
%
% No figure is exported or saved.  The legend is positioned with
% Location='none' so that it can be moved manually in MATLAB.

assert(isstruct(bench2022) && isfield(bench2022, 'case1') && ...
       isfield(bench2022, 'case2'), ...
    'plotBenchmarkConvergenceSCI2022:bench2022 must contain case1 and case2.');

caseData = {bench2022.case1, bench2022.case2};
colors = [0.0000 0.4470 0.7410; ...
          0.8500 0.3250 0.0980; ...
          0.4660 0.6740 0.1880];
metrics = {'L2err', 'H1err', 'Gerr'};
ylabels = {'$e_{L^2}$', '$e_{H^1}$', '$e_G$'};
orders = [4, 3, 2];

fig = figure('Name', '2022 benchmark SCI convergence', 'Color', 'w', ...
    'Position', [100 100 1180 650]);
tl = tiledlayout(fig, 2, 3, 'Padding', 'compact', 'TileSpacing', 'compact');

for c = 1:2
    data = caseData{c};

    for m = 1:3
        ax = nexttile(tl, (c - 1)*3 + m);
        hold(ax, 'on'); grid(ax, 'on'); box(ax, 'on');
        hCurves = gobjects(1, numel(data.results));

        for r = 1:numel(data.results)
            item = data.results{r};
            hbar = 1./item.NeYList;
            hCurves(r) = loglog(ax, hbar, item.(metrics{m}), '-o', ...
                'Color', colors(1 + mod(r - 1, size(colors, 1)), :), ...
                'LineWidth', 1.6, 'MarkerFaceColor', 'w', 'MarkerSize', 5);
        end

        % Reference slope line, anchored to the finest ell=0.1 result.
        reference = data.results{1};
        hbar = 1./reference.NeYList;
        refCurve = reference.(metrics{m})(end)*(hbar/hbar(end)).^orders(m);
        loglog(ax, hbar, refCurve, 'k--', 'LineWidth', 1.0, ...
            'HandleVisibility', 'off');
        text(ax, 0.07, 0.11, sprintf('$O(h^{%d})$', orders(m)), ...
            'Units', 'normalized', 'Interpreter', 'latex', 'FontSize', 10);

        set(ax, 'XDir', 'reverse', 'FontName', 'Times New Roman', ...
            'FontSize', 10, 'LineWidth', 0.8, ...
            'TickLabelInterpreter', 'latex', 'Layer', 'top');
        xlabel(ax, '$h/H$', 'Interpreter', 'latex');
        ylabel(ax, ylabels{m}, 'Interpreter', 'latex');
        title(ax, sprintf('(%c) Case %d', char('a' + (c - 1)*3 + m - 1), c), ...
            'Interpreter', 'latex', 'FontWeight', 'normal');

        if m == 1
            labels = arrayfun(@(item) sprintf('$\\ell=%.1f\\,\\mathrm{mm}$', item.ell), ...
                [data.results{:}], 'UniformOutput', false);
            lgd = legend(ax, hCurves, labels, 'Interpreter', 'latex', ...
                'FontSize', 8, 'Box', 'on');
            % Do not assign a Position: the user may drag this legend.
            lgd.Location = 'none';
        end
    end
end

end
%%%{Step 1 — Command Window mein run karo
%MATLAB
%
%load(fullfile(tempdir, 'BFS2022Results', 'benchmark2022_results.mat'));
%Step 2 — Check karo variable aa gaya
%MATLAB

%bench2022
%Agar struct dikh jaye jisme:

%text

%case1
%case2
%fields hain, then Step 3 run karo.

%Step 3 — Convergence graph
%MATLAB

%figConv = plotBenchmarkConvergenceSCI2022(bench2022);
