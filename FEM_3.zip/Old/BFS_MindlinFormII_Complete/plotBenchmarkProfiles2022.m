function figs = plotBenchmarkProfilesSCI2022(varargin)
%PLOTBENCHMARKPROFILESSCI2022 Journal-style analytical/BFS profile plots.
%
%   figs = plotBenchmarkProfilesSCI2022('ellList',[0.1 0.2 0.3], ...
%       'NeY',16,'loadScale',1e-5)
%
% No figure is exported or saved.  The returned figure handles let the
% user position legends and save figures manually from MATLAB.

p = inputParser;
addParameter(p, 'ellList', [0.1 0.2 0.3], @(x) isnumeric(x) && isvector(x));
addParameter(p, 'NeY', 16, @(x) isnumeric(x) && isscalar(x) && x >= 1 && x == round(x));
addParameter(p, 'loadScale', 1e-5, @(x) isnumeric(x) && isscalar(x) && x > 0);
addParameter(p, 'nSamples', 241, @(x) isnumeric(x) && isscalar(x) && x >= 21 && x == round(x));
parse(p, varargin{:});
o = p.Results;
ellList = o.ellList(:).';

colors = [0.0000 0.4470 0.7410; ...
          0.8500 0.3250 0.0980; ...
          0.4660 0.6740 0.1880];
markers = {'o', 's', '^'};
caseNames = {'case1', 'case2'};
caseLabels = {'Case 1: prescribed displacement', 'Case 2: prescribed traction'};

figProfile = figure('Name', '2022 benchmark profiles', 'Color', 'w', ...
    'Position', [100 100 1180 430]);
tlProfile = tiledlayout(figProfile, 1, 2, 'Padding', 'compact', 'TileSpacing', 'compact');

figError = figure('Name', '2022 benchmark pointwise errors', 'Color', 'w', ...
    'Position', [120 120 1180 430]);
tlError = tiledlayout(figError, 1, 2, 'Padding', 'compact', 'TileSpacing', 'compact');

for c = 1:2
    profileAx = nexttile(tlProfile, c);
    hold(profileAx, 'on'); grid(profileAx, 'on'); box(profileAx, 'on');
    errorAx = nexttile(tlError, c);
    hold(errorAx, 'on'); grid(errorAx, 'on'); box(errorAx, 'on');

    hAna = gobjects(1, numel(ellList));
    hBFS = gobjects(1, numel(ellList));
    hErr = gobjects(1, numel(ellList));
    profileMax = 0;

    for li = 1:numel(ellList)
        ell = ellList(li);
        color = colors(1 + mod(li - 1, size(colors, 1)), :);
        marker = markers{1 + mod(li - 1, numel(markers))};

        prob = initializeProblem2022('caseName', caseNames{c}, ...
            'ell', ell, 'NeX', 3*o.NeY, 'NeY', o.NeY, ...
            'loadScale', o.loadScale, 'verbose', false);
        sol = runAnalysis2022(prob);
        assert(sol.finalConv, ...
            'plotBenchmarkProfilesSCI2022:benchmark solve did not converge.');

        y = linspace(0, prob.paper.H, o.nSamples).';
        [uxBFS, uxAnalytical] = localProfile(sol, y);
        ybar = y/prob.paper.H;

        % Dimensionless displacement reference.
        if c == 1
            uRef = abs(prob.paper.uhat);
            yLabel = '$\bar{u}_x=u_x/\widehat{u}$';
        else
            uRef = abs(prob.paper.H*prob.paper.that/prob.paper.mu);
            yLabel = '$\bar{u}_x=u_x/(H\widehat{t}/\mu)$';
        end
        uRef = max(uRef, eps);

        hAna(li) = plot(profileAx, ybar, uxAnalytical/uRef, '-', ...
            'Color', color, 'LineWidth', 1.8);

        markerStride = max(1, floor(o.nSamples/18));
        idx = 1:markerStride:o.nSamples;
        if idx(end) ~= o.nSamples
            idx(end + 1) = o.nSamples;
        end
        hBFS(li) = plot(profileAx, ybar(idx), uxBFS(idx)/uRef, marker, ...
            'Color', color, 'MarkerFaceColor', 'w', 'MarkerSize', 4.8, ...
            'LineStyle', 'none');
        profileMax = max(profileMax, max(abs([uxBFS; uxAnalytical]/uRef)));

        pointError = abs(uxBFS - uxAnalytical)/max(max(abs(uxAnalytical)), eps);
        hErr(li) = semilogy(errorAx, ybar, max(pointError, 1e-16), '-', ...
            'Color', color, 'LineWidth', 1.5);
    end

    % Explicit six-entry profile legend: every colour and symbol is named.
    labels = cell(1, 2*numel(ellList));
    handles = gobjects(1, 2*numel(ellList));
    for li = 1:numel(ellList)
        handles(2*li - 1) = hAna(li);
        handles(2*li) = hBFS(li);
        labels{2*li - 1} = sprintf('$\\mathrm{Analytical},\\ \\ell=%.1f\\,\\mathrm{mm}$', ellList(li));
        labels{2*li} = sprintf('$\\mathrm{BFS},\\ \\ell=%.1f\\,\\mathrm{mm}$', ellList(li));
    end

    lgdProfile = legend(profileAx, handles, labels, 'Interpreter', 'latex', ...
        'FontSize', 8, 'Box', 'on');
    lgdProfile.Location = 'none';   % user can drag it manually in MATLAB
    lgdProfile.Units = 'normalized';
    lgdProfile.Position = [0.54 0.53 0.42 0.33];

    lgdError = legend(errorAx, hErr, ...
        arrayfun(@(x) sprintf('$\\ell=%.1f\\,\\mathrm{mm}$', x), ellList, 'UniformOutput', false), ...
        'Interpreter', 'latex', 'FontSize', 8, 'Box', 'on');
    lgdError.Location = 'none';     % user can drag it manually in MATLAB
    lgdError.Units = 'normalized';
    lgdError.Position = [0.60 0.18 0.30 0.22];

    xlabel(profileAx, '$y/H$', 'Interpreter', 'latex');
    ylabel(profileAx, yLabel, 'Interpreter', 'latex');
    title(profileAx, sprintf('(%c) %s', char('a' + c - 1), caseLabels{c}), ...
        'Interpreter', 'latex', 'FontWeight', 'normal');
    xlim(profileAx, [0, 1]);
    ylim(profileAx, [0, 1.05*profileMax]);

    xlabel(errorAx, '$y/H$', 'Interpreter', 'latex');
    ylabel(errorAx, '$|u_x^h-u_x|/\max|u_x|$', 'Interpreter', 'latex');
    title(errorAx, sprintf('(%c) Pointwise profile error', char('c' + c - 1)), ...
        'Interpreter', 'latex', 'FontWeight', 'normal');
    xlim(errorAx, [0, 1]);
    set(errorAx, 'YScale', 'log');

    applyJournalAxisStyle(profileAx);
    applyJournalAxisStyle(errorAx);
end

figs = struct('profiles', figProfile, 'errors', figError);

end

function [uxBFS, uxExact] = localProfile(sol, y)
mesh = sol.mesh;
dof = sol.dof;
D = sol.D(:, end);
NeX = mesh.Ne1;
NeY = mesh.Ne2;
h1 = mesh.h1;
h2 = mesh.h2;
uxBFS = zeros(size(y));

% The problem is periodic in x.  Evaluate at the centre of the first
% element column to avoid sampling directly on a periodic boundary.
xi = 0;
for k = 1:numel(y)
    row = min(floor(y(k)/h2), NeY - 1);
    e = row*NeX + 1;
    eg = mesh.elemGeom(e);
    eta = 2*(y(k) - eg.y0)/h2 - 1;
    eta = max(-1, min(1, eta));
    dN = bfsShapeFunctionDerivatives(xi, eta, h1, h2);
    de = D(dof.elemDOF(e, :));
    uxBFS(k) = dN.N0(1, 1:16)*de(1:16);
end

exact = analyticalSolution2022(y, sol.paper, sol.caseName);
uxExact = exact.ux(:);
end

function applyJournalAxisStyle(ax)
set(ax, 'FontName', 'Times New Roman', 'FontSize', 10, ...
    'LineWidth', 0.8, 'TickLabelInterpreter', 'latex', ...
    'Layer', 'top');
end
