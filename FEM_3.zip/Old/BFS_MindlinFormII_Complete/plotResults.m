function figs = plotResults(pp, varargin)
%PLOTRESULTS  Generate publication-quality MATLAB figures from the post-
%             processed BFS Mindlin Form-II solution.
%
%   figs = PLOTRESULTS(pp)
%   figs = PLOTRESULTS(pp,'Name',Value,...)
%
% ----------------------------------------------------------------------
% Default figures produced
% ----------------------------------------------------------------------
%   Fig 1 : Undeformed + deformed mesh (with displacement amplification)
%   Fig 2 : Displacement u1 contour (nodal-averaged, on undeformed grid)
%   Fig 3 : Displacement u2 contour
%   Fig 4 : Green-Lagrange E11 contour
%   Fig 5 : Green-Lagrange E22 contour
%   Fig 6 : Green-Lagrange E12 (engineer-shear = 2E12) contour
%   Fig 7 : Second-Piola S11 contour
%   Fig 8 : Von Mises equivalent stress contour
%   Fig 9 : Strain-energy density psi contour
%   Fig 10: Newton iterations per load step (bar chart)
%   Fig 11: Load-displacement curve (mean u1 on x1-edge vs lambda;
%           requires the 'sol' name-value argument with the Module-13
%           solution object).
%
% Options:
%   makePlots     cell of plot keys (default = all 11 keys above)
%   amplification deformation amplification for mesh plot; default
%                 auto-scales to 20% of domain when displacement is
%                 tiny, otherwise uses 1.
%   sol           Module-13 solution struct (needed for load-disp plot)
%   visible       'on'|'off'                (default 'on')
%   cmap          colormap                  (parula(256))
%   fontsize      axis/label fontsize       (11)
%   linewidth     mesh line width           (1.0)
%   saveOnPlot    auto-export via exportResults? (false)
%   exportOpts    cell of name-value pairs for exportResults
%
% Output:
%   figs          struct with figure handles keyed by plot name.
%
% See also POSTPROCESSRESULTS, EXPORTRESULTS.

ip = inputParser;
allKeys = {'mesh','u1','u2','E11','E22','E12','S11','vm','psi',...
           'convergence','loaddisp'};
addParameter(ip,'makePlots',allKeys,@iscell);
addParameter(ip,'amplification',[],@(x) isempty(x)||(isnumeric(x)&&isscalar(x)));
addParameter(ip,'sol',[],@(x) isempty(x)||isstruct(x));
addParameter(ip,'visible','on',@(x) ismember(lower(x),{'on','off'}));
addParameter(ip,'cmap',parula(256),@isnumeric);
addParameter(ip,'fontsize',11,@(x) isnumeric(x)&&isscalar(x));
addParameter(ip,'linewidth',1.0,@(x) isnumeric(x)&&isscalar(x)&&x>0);
addParameter(ip,'saveOnPlot',false,@(x) islogical(x)||x==0||x==1);
addParameter(ip,'exportOpts',{},@iscell);
parse(ip,varargin{:});
o = ip.Results;

assert(isstruct(pp) && isfield(pp,'nodal'), ...
    'plotResults:pp must be the struct from postProcessResults.');

figs = struct();

X    = pp.X;
uN   = pp.uNodal;
conn = pp.connect;
nE   = pp.nElem;

Lx = max(X(:,1))-min(X(:,1));
Ly = max(X(:,2))-min(X(:,2));
L  = max(Lx,Ly);

% Auto amplification.
if isempty(o.amplification)
    umax = max(max(abs(uN)));
    if umax < 0.05*L
        o.amplification = max(1,(0.2*L)/max(umax,eps));
    else
        o.amplification = 1;
    end
end
xplt = X + o.amplification*uN;

    function fh = newFig(key,ti)
        fh = figure('Visible',o.visible,'Name',ti);
        colormap(o.cmap);
        ax = gca;
        set(ax,'FontSize',o.fontsize);
        figs.(key) = fh;
        axes(ax); %#ok<LAXES>
    end
    function drawMesh(xp,yp,clr,lw)
        hold on;
        for ee = 1:nE
            ii = conn(ee,:); ii = [ii ii(1)];
            plot(xp(ii),yp(ii),'-','Color',clr,'LineWidth',lw);
        end
    end
    function doContour(key,ti,vals)
        fh = newFig(key,ti); axis equal; hold on;
        C = vals(conn);                          % nE x 4
        px = X(conn,1); py = X(conn,2);          % nE x 4
        px = reshape(px',4,nE); py = reshape(py',4,nE);
        Cp = reshape(C',4,nE);
        patch(px,py,Cp,'EdgeColor','none');
        colorbar;
        drawMesh(X(:,1),X(:,2),0.4*[1 1 1],0.4);
        title(ti); xlabel('X_1'); ylabel('X_2');
    end

% ----- (1) Mesh: undeformed + deformed -----
if ismember('mesh',o.makePlots)
    fh = newFig('mesh','Undeformed & deformed mesh');
    axis equal; hold on;
    drawMesh(X(:,1),X(:,2),0.6*[1 1 1],o.linewidth);
    drawMesh(xplt(:,1),xplt(:,2),'k',o.linewidth);
    title(sprintf('Mesh (deformation amplification \\times %g)',o.amplification));
    xlabel('X_1'); ylabel('X_2');
end

% ----- (2)-(9) Contour plots -----
doContour('u1', 'Displacement u_1',                  pp.nodal.u1);
doContour('u2', 'Displacement u_2',                  pp.nodal.u2);
doContour('E11','Green--Lagrange E_{11}',            pp.nodal.E11);
doContour('E22','Green--Lagrange E_{22}',            pp.nodal.E22);
doContour('E12','Green--Lagrange E_{12}',            pp.nodal.E12);
doContour('S11','2nd Piola S_{11}',                  pp.nodal.S11);
doContour('vm', 'Von Mises equivalent stress',       pp.nodal.vmMises);
doContour('psi','Strain-energy density \\psi',       pp.nodal.psi);

% Strip unused auto-created figures when key was deselected.
created = fieldnames(figs);
for kk=1:length(created)
    if ~ismember(created{kk},o.makePlots)
        close(figs.(created{kk})); figs = rmfield(figs,created{kk});
    end
end

% ----- (10) Newton convergence (bar chart) -----
if ismember('convergence',o.makePlots)
    fh = newFig('convergence','Newton iterations per step');
    lam = pp.hist.lambda(:); nIt = pp.hist.nIter(:);
    if length(lam)==length(nIt) && ~isempty(lam)
        bar(lam,nIt,min(0.9,1/max(length(lam),1)));
        xlabel('\lambda'); ylabel('Newton iterations');
        title('Newton iterations per load step');
        grid on;
    end
end

% ----- (11) Load-displacement curve -----
if ismember('loaddisp',o.makePlots)
    fh = newFig('loaddisp','Load-displacement');
    haveSol = ~isempty(o.sol) && isfield(o.sol,'D') && isfield(o.sol,'lambda') ...
              && isfield(o.sol,'dof');
    if haveSol
        sol = o.sol;
        lam = sol.lambda(:);
        X1max = max(X(:,1));
        tol = 1e-10*max(max(abs(X))+1);
        onEdge = abs(X(:,1)-X1max) < tol;
        if any(onEdge)
            nds = find(onEdge);
            u1tip = zeros(size(lam));
            for k = 1:length(lam)
                u1tip(k) = mean(arrayfun(@(n) sol.D(sol.dof.ID(1,1,n),k), nds));
            end
            plot(u1tip,lam,'b-o','LineWidth',1.2,'MarkerSize',4);
            xlabel('u_1 (x_1 edge, average)'); ylabel('\lambda');
            title('Load-displacement response'); grid on;
        else
            text(0.5,0.5,'No x_1-edge nodes found','Units','normalized','HorizontalAlignment','center');
        end
    else
        text(0.1,0.5,'Load-disp plot requires the ''sol'' option.',...
            'Units','normalized');
    end
end

% Optional auto-export.
if o.saveOnPlot
    try
        exportResults(pp,'outdir','results',o.exportOpts{:});
    catch ME
        warning('plotResults:auto-export failed: %s',ME.message);
    end
end
end
