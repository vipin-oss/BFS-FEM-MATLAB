function pp = postProcessResults(sol, varargin)
%POSTPROCESSRESULTS  Compute derived fields for visualization / export
%                    from a Module-13 solution object.
%
%   pp = POSTPROCESSRESULTS(sol)
%   pp = POSTPROCESSRESULTS(sol, 'Name',Value,...)
%
% ----------------------------------------------------------------------
% Purpose
% ----------------------------------------------------------------------
% For a selected load step, evaluate the displacement, deformation
% gradient, Green-Lagrange strain, strain gradient, second-Piola
% stress, double-stress, and strain-energy density fields at each
% Gauss point and at each node (by bi-linear element-averaging the
% Gauss-point values onto corner nodes -- a standard super-convergent
% patch-recovery style projection suitable for visualisation).
%
% The routine uses ONLY frozen Module-4/6/7 APIs
% (bfsShapeFunctionDerivatives, computeDeformationGradient,
%  computeGreenLagrangeStrain, computeStrainGradient,
%  computeSecondPiolaStress, computeDoubleStress,
%  computeStrainEnergyDensity)
% and operates on the solution object returned by runAnalysis (Module 13).
% No element residual / tangent is recomputed.
%
% ----------------------------------------------------------------------
% Optional name-value inputs
% ----------------------------------------------------------------------
%   stepIndex  index into sol.lambda to post-process  (default: end)
%   nodalAveraging  'simple' | 'none'                 ('simple')
%
% Output struct pp:
%   .stepIndex, .lambda
%   .X              nNodes x 2     reference coordinates (copy)
%   .x              nNodes x 2     deformed coordinates at nodes
%   .uNodal         nNodes x 2     nodal displacement  [u1,u2]
%   .connect        nElem x 4      element connectivity (copy)
%   .gp             struct of per-Gauss-point arrays:
%       .xe_gp, .ue_gp           nGP_total x 2
%       .F                        (nGP_total x 2 x 2)
%       .E                        (nGP_total x 2 x 2)
%       .G                        (nGP_total x 2 x 2 x 2)
%       .S                        (nGP_total x 2 x 2)
%       .Sigma                    (nGP_total x 2 x 2 x 2)
%       .psi_c, .psi_g, .psi      (nGP_total x 1)
%       .elem, .xi, .eta          bookkeeping
%   .nodal          struct of nodal (averaged) scalar fields:
%       .E11,.E22,.E12, .S11,.S22,.S12, .vmMises, .psi, .psi_c, .psi_g
%       (G_ and Sigma_ nodal values stored in 2x2 and 2x2x2 arrays
%        at nNodes x 2 x 2 / nNodes x 2 x 2 x 2.)
%       .G, .Sigma
%   .W_e            nElem x 1  element strain energy (copied from sol.U)
%   .Wtotal         scalar
%   .Rxn            nDOF x 1   reaction copy
%   .nNodes, .nElem, .nGP_total
%   .hist           substruct with copy of load / iteration history
%                     (.lambda,.nIter,.converged,.dlambdaHist,.cutbacks,
%                      .totalIter,.finalConv)
%
% See also EXPORTRESULTS, PLOTRESULTS, RUNANALYSIS, MAIN.

% ======================================================================
% Parse optional inputs.
% ======================================================================
ip = inputParser;
addParameter(ip,'stepIndex',[],@(x) isempty(x)||(isnumeric(x)&&isscalar(x)&&x>=1));
addParameter(ip,'nodalAveraging','simple',@(s) ismember(lower(s),{'simple','none'}));
parse(ip,varargin{:});
o = ip.Results;

assert(isstruct(sol) && isfield(sol,'D') && isfield(sol,'mesh') && isfield(sol,'dof') ...
       && isfield(sol,'mat') && isfield(sol,'gauss') && isfield(sol,'lambda'), ...
    'postProcessResults:sol must be a solution object from runAnalysis.');

nLam = length(sol.lambda);
if isempty(o.stepIndex)
    sIdx = nLam;
else
    sIdx = round(o.stepIndex);
    assert(sIdx>=1 && sIdx<=nLam, 'postProcessResults:stepIndex out of range.');
end

mesh  = sol.mesh;
mat   = sol.mat;
dof   = sol.dof;
gauss = sol.gauss;
D     = sol.D(:,sIdx);
lam   = sol.lambda(sIdx);

nN = mesh.nNodes;
nE = mesh.nElem;
X  = mesh.X;
eg = mesh.elemGeom;

% ======================================================================
% Nodal displacement from the global DOF vector: each node has DOFs
% (ld=1..4, comp=1..2) so the value DOF (ld=1) gives u_i at the node
% exactly (Kronecker-delta property).
% ======================================================================
uNodal = zeros(nN,2);
for n = 1:nN
    uNodal(n,1) = D(dof.ID(1,1,n));
    uNodal(n,2) = D(dof.ID(1,2,n));
end
x = X + uNodal;

% ======================================================================
% Gauss-point field evaluation.
% Same parent-to-physical mapping used by frozen computeElementResidual.
% ======================================================================
xi1d = gauss.xi1d;
wi1d = gauss.w1d;
ng   = gauss.ng;
nGPperEl = ng*ng;
nGPtot   = nE*nGPperEl;

F_gp     = zeros(nGPtot,2,2);
E_gp     = zeros(nGPtot,2,2);
G_gp     = zeros(nGPtot,2,2,2);
S_gp     = zeros(nGPtot,2,2);
Sig_gp   = zeros(nGPtot,2,2,2);
psi_c_gp = zeros(nGPtot,1);
psi_g_gp = zeros(nGPtot,1);
psi_gp   = zeros(nGPtot,1);
xe_gp    = zeros(nGPtot,2);      % physical deformed coordinate at GP
ue_gp    = zeros(nGPtot,2);
gp_elem  = zeros(nGPtot,1);
gp_xi    = zeros(nGPtot,1);
gp_eta   = zeros(nGPtot,1);

% Accumulators for nodal averaging (simple element-patch average: sum
% GP values that belong to each element's 4 corner nodes, then divide
% by the number of contributing GPs).
accCount = zeros(nN,1);
accU1 = zeros(nN,1); accU2 = zeros(nN,1);           % displacement sanity
accE11 = zeros(nN,1); accE22 = zeros(nN,1); accE12 = zeros(nN,1);
accS11 = zeros(nN,1); accS22 = zeros(nN,1); accS12 = zeros(nN,1);
accPsi_c = zeros(nN,1); accPsi_g = zeros(nN,1); accPsi = zeros(nN,1);
accG  = zeros(nN,2,2,2);
accSig= zeros(nN,2,2,2);

igp = 0;
for e = 1:nE
    h1 = eg(e).h1; h2 = eg(e).h2;
    x0 = eg(e).x0; y0 = eg(e).y0;
    detJ = h1*h2/4;
    edofs = dof.elemDOF(e,:);
    de = D(edofs);

    xi1  = 2/h1;
    xi2  = 2/h2;
    xi11 = xi1*xi1;
    xi22 = xi2*xi2;
    xi12 = xi1*xi2;

    nodes = mesh.connect(e,:);   % [SW SE NE NW]

    for i = 1:ng
        for j = 1:ng
            igp = igp+1;
            xi_p  = xi1d(i);
            eta_p = xi1d(j);

            dN = bfsShapeFunctionDerivatives(xi_p, eta_p, h1, h2);
            N0_1    = dN.N0(1,1:16);
            dNxi_1  = dN.dNdxi(1,1:16);
            dNet_1  = dN.dNdeta(1,1:16);
            d2Nxi_1 = dN.d2Ndxi2(1,1:16);
            d2Net_1 = dN.d2Ndeta2(1,1:16);
            d2Nxe_1 = dN.d2Ndxideta(1,1:16);

            N0_2    = dN.N0(2,17:32);
            dNxi_2  = dN.dNdxi(2,17:32);
            dNet_2  = dN.dNdeta(2,17:32);
            d2Nxi_2 = dN.d2Ndxi2(2,17:32);
            d2Net_2 = dN.d2Ndeta2(2,17:32);
            d2Nxe_2 = dN.d2Ndxideta(2,17:32);

            u1 = N0_1*de(1:16);
            u2 = N0_2*de(17:32);

            gradU = zeros(2,2);
            gradU(1,1) = xi1*(dNxi_1*de(1:16));
            gradU(1,2) = xi2*(dNet_1*de(1:16));
            gradU(2,1) = xi1*(dNxi_2*de(17:32));
            gradU(2,2) = xi2*(dNet_2*de(17:32));

            gradGradU = zeros(2,2,2);
            gradGradU(1,1,1) = xi11*(d2Nxi_1*de(1:16));
            gradGradU(1,2,2) = xi22*(d2Net_1*de(1:16));
            gradGradU(1,1,2) = xi12*(d2Nxe_1*de(1:16));
            gradGradU(1,2,1) = gradGradU(1,1,2);
            gradGradU(2,1,1) = xi11*(d2Nxi_2*de(17:32));
            gradGradU(2,2,2) = xi22*(d2Net_2*de(17:32));
            gradGradU(2,1,2) = xi12*(d2Nxe_2*de(17:32));
            gradGradU(2,2,1) = gradGradU(2,1,2);

            kin = computeDeformationGradient(gradU);
            F   = kin.F;
            Est = computeGreenLagrangeStrain(F);
            E   = Est.E;
            G   = computeStrainGradient(gradU, gradGradU);
            S   = computeSecondPiolaStress(mat.C4, E);
            Sig = computeDoubleStress(mat.D6, G);
            psiS= computeStrainEnergyDensity(mat.C4, mat.D6, E, G);

            % Physical reference coordinate of the GP (parent->physical
            % using the bi-linear corner shape for the element DOMAIN,
            % not the BFS shape: linear geometry, bicubic field).
            Xgp = local_parentToPhysical(x0,y0,h1,h2,xi_p,eta_p);
            xgp = Xgp + [u1;u2];

            F_gp(igp,:,:)   = F;
            E_gp(igp,:,:)   = E;
            G_gp(igp,:,:,:) = G;
            S_gp(igp,:,:)   = S;
            Sig_gp(igp,:,:,:) = Sig;
            psi_c_gp(igp)   = psiS.classical;
            psi_g_gp(igp)   = psiS.gradient;
            psi_gp(igp)     = psiS.total;
            xe_gp(igp,:)    = xgp(:).';
            ue_gp(igp,:)    = [u1,u2];
            gp_elem(igp)    = e;
            gp_xi(igp)      = xi_p;
            gp_eta(igp)     = eta_p;

            % Accumulate onto 4 corner nodes using bi-linear parent
            % weights (the same bilinear shape as the geometry map).
            Nc = local_cornerWeights(xi_p,eta_p);    % 1x4 in node order SW,SE,NE,NW
            for k=1:4
                nd = nodes(k);
                w  = Nc(k);
                accCount(nd) = accCount(nd) + w;
                accE11(nd)   = accE11(nd) + w*E(1,1);
                accE22(nd)   = accE22(nd) + w*E(2,2);
                accE12(nd)   = accE12(nd) + w*0.5*(E(1,2)+E(2,1));
                accS11(nd)   = accS11(nd) + w*S(1,1);
                accS22(nd)   = accS22(nd) + w*S(2,2);
                accS12(nd)   = accS12(nd) + w*0.5*(S(1,2)+S(2,1));
                accPsi_c(nd) = accPsi_c(nd) + w*psiS.classical;
                accPsi_g(nd) = accPsi_g(nd) + w*psiS.gradient;
                accPsi(nd)   = accPsi(nd)  + w*psiS.total;
                for I=1:2
                    for J=1:2
                        for K=1:2
                            accG(nd,I,J,K)   = accG(nd,I,J,K)   + w*G(I,J,K);
                            accSig(nd,I,J,K) = accSig(nd,I,J,K) + w*Sig(I,J,K);
                        end
                    end
                end
            end
        end
    end
end

% ======================================================================
% Nodal averaging: divide by total weight at each node.
% ======================================================================
nodal = struct();
if strcmpi(o.nodalAveraging,'simple')
    nz = accCount > 0;
    invC = zeros(nN,1); invC(nz) = 1./accCount(nz);
    nodal.E11 = accE11.*invC;
    nodal.E22 = accE22.*invC;
    nodal.E12 = accE12.*invC;
    nodal.S11 = accS11.*invC;
    nodal.S22 = accS22.*invC;
    nodal.S12 = accS12.*invC;
    % Plane-strain von Mises:  sqrt(S11^2 - S11 S22 + S22^2 + 3 S12^2)
    nodal.vmMises = sqrt(nodal.S11.^2 - nodal.S11.*nodal.S22 + nodal.S22.^2 + 3*nodal.S12.^2);
    nodal.psi  = accPsi.*invC;
    nodal.psi_c= accPsi_c.*invC;
    nodal.psi_g= accPsi_g.*invC;
    nodal.G    = zeros(nN,2,2,2);
    nodal.Sigma= zeros(nN,2,2,2);
    for I=1:2
        for J=1:2
            for K=1:2
                nodal.G(:,I,J,K)     = accG(:,I,J,K).*invC;
                nodal.Sigma(:,I,J,K) = accSig(:,I,J,K).*invC;
            end
        end
    end
else
    % 'none': leave nodal arrays empty / filled with NaN.
    nodal.E11=nan(nN,1); nodal.E22=nan(nN,1); nodal.E12=nan(nN,1);
    nodal.S11=nan(nN,1); nodal.S22=nan(nN,1); nodal.S12=nan(nN,1);
    nodal.vmMises=nan(nN,1);
    nodal.psi=nan(nN,1); nodal.psi_c=nan(nN,1); nodal.psi_g=nan(nN,1);
    nodal.G=nan(nN,2,2,2); nodal.Sigma=nan(nN,2,2,2);
end
nodal.u1 = uNodal(:,1);
nodal.u2 = uNodal(:,2);
nodal.x  = x;
nodal.X  = X;

% ======================================================================
% Pack output.
% ======================================================================
pp = struct();
pp.stepIndex = sIdx;
pp.lambda    = lam;
pp.X         = X;
pp.x         = x;
pp.uNodal    = uNodal;
pp.connect   = mesh.connect;
pp.gp = struct(...
    'xe',xe_gp,'ue',ue_gp,...
    'F',F_gp,'E',E_gp,'G',G_gp,'S',S_gp,'Sigma',Sig_gp,...
    'psi_c',psi_c_gp,'psi_g',psi_g_gp,'psi',psi_gp,...
    'elem',gp_elem,'xi',gp_xi,'eta',gp_eta);
pp.nodal     = nodal;
pp.W_e       = sol.U.W_e;
pp.Wtotal    = sol.U.Wtotal;
pp.Rxn       = sol.Rxn(:,sIdx);
pp.nNodes    = nN; pp.nElem = nE; pp.nGP_total = nGPtot;
pp.hist      = struct('lambda',sol.lambda,'nIter',sol.nIter,...
                      'converged',sol.converged,'dlambdaHist',sol.dlambdaHist,...
                      'cutbacks',sol.cutbacks,'totalIter',sol.totalIter,...
                      'finalConv',sol.finalConv,'nLam',nLam);

% ======================================================================
% Field-dimension asserts.
% ======================================================================
assert(isequal(size(pp.X),[nN,2]),'postProcessResults:X size mismatch.');
assert(isequal(size(pp.x),[nN,2]),'postProcessResults:x size mismatch.');
assert(size(pp.gp.F,1)==nGPtot,'postProcessResults:GP field length mismatch.');
assert(pp.Wtotal >= -1e-10,'postProcessResults:Wtotal negative (W=%g).',pp.Wtotal);
end

% =========================================================================
% LOCAL SUBFUNCTIONS  (non-nested; no helper files)
% =========================================================================
function Xc = local_parentToPhysical(x0,y0,h1,h2,xi,eta)
% Map parent (xi,eta) to physical X on a bilinear rectangle (linear
% geometry, constant Jacobian diag(h1/2,h2/2)).
Xc = [x0 + (h1/2)*(xi+1); y0 + (h2/2)*(eta+1)];
end

function Nc = local_cornerWeights(xi,eta)
% Bilinear (Q1) corner weights on [-1,1]^2 in CCW order SW,SE,NE,NW.
Nc = 0.25*[(1-xi)*(1-eta); (1+xi)*(1-eta); (1+xi)*(1+eta); (1-xi)*(1+eta)];
Nc = Nc(:).';
end
