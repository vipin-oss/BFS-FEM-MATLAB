function figs = plot3LengthScaleStudy(study)
%PLOT3LENGTHSCALESTUDY SCI-style plots for Study 03.
%
%   figs = plot3LengthScaleStudy(study3)
%
% Fig04: main-paper length-scale effect figure.
% Fig04_Optional: supplementary response-ratio figure.
% No automatic file export is performed.

assert(isstruct(study) && isfield(study, 'results') && ...
       isfield(study, 'ellList') && isfield(study, 'loadCases'), ...
    'plot3LengthScaleStudy:invalid study struct.');

% Keep only length scales that converged for every requested load case.
validIndex = [];
for ie = 1:numel(study.ellList)
    isValid = true;
    for il = 1:numel(study.loadCases)
        isValid = isValid && study.results{ie, il}.converged;
    end
    if isValid
        validIndex(end + 1) = ie; %#ok<AGROW>
    end
end
assert(~isempty(validIndex), 'plot3LengthScaleStudy:no converged cases available.');

classicalIndex = find(study.ellList == 0, 1, 'first');
assert(~isempty(classicalIndex) && any(validIndex == classicalIndex), ...
    'plot3LengthScaleStudy:converged classical ell=0 reference is required.');

ellOverH = study.ellList(validIndex)/study.opts.H;
loadCases = study.loadCases;
colors = [0.0000 0.4470 0.7410; ...
          0.8500 0.3250 0.0980];
markers = {'o', 's'};

% =====================================================================
% Fig04: main size-effect result.
% =====================================================================
figMain = figure('Name', 'Fig04_LengthScaleEffect', 'Color', 'w', ...
    'Position', [100 100 1120 500]);
tlMain = tiledlayout(figMain, 1, 2, 'Padding', 'compact', 'TileSpacing', 'compact');

axK = nexttile(tlMain, 1);
axG = nexttile(tlMain, 2);
hold(axK, 'on'); hold(axG, 'on');
grid(axK, 'on'); grid(axG, 'on');
box(axK, 'on'); box(axG, 'on');

hK = gobjects(1, numel(loadCases));
hG = gobjects(1, numel(loadCases));
labels = cell(1, numel(loadCases));

for il = 1:numel(loadCases)
    KRatio = zeros(size(ellOverH));
    GRatio = zeros(size(ellOverH));
    refG = study.results{classicalIndex, il}.maxG;

    for ie = 1:numel(ellOverH)
        item = study.results{validIndex(ie), il};
        KRatio(ie) = item.stiffnessRatio;
        GRatio(ie) = item.maxG/max(refG, eps);
    end

    hK(il) = plot(axK, ellOverH, KRatio, ['-' markers{il}], ...
        'Color', colors(il, :), 'MarkerFaceColor', 'w', ...
        'LineWidth', 1.7, 'MarkerSize', 6);
    hG(il) = plot(axG, ellOverH, GRatio, ['-' markers{il}], ...
        'Color', colors(il, :), 'MarkerFaceColor', 'w', ...
        'LineWidth', 1.7, 'MarkerSize', 6);
    labels{il} = ['$\mathrm{' loadCases(il).name '\ load}$'];
end

xlabel(axK, '$\ell/H$', 'Interpreter', 'latex');
ylabel(axK, '$K_{\mathrm{app}}/K_{\mathrm{app}}^{\ell=0}$', 'Interpreter', 'latex');
title(axK, '(a) Apparent stiffness ratio', 'Interpreter', 'latex', 'FontWeight', 'normal');

xlabel(axG, '$\ell/H$', 'Interpreter', 'latex');
ylabel(axG, '$\max|\mathcal{G}|/\max|\mathcal{G}|_{\ell=0}$', 'Interpreter', 'latex');
title(axG, '(b) Maximum strain-gradient ratio', 'Interpreter', 'latex', 'FontWeight', 'normal');

% MATLAB versions without tiled-layout legends: attach the shared legend
% below the left axis so it remains outside the data region.
legend(axK, hK, labels, 'Interpreter', 'latex', 'FontSize', 9, ...
    'Box', 'on');
applyJournalStyle(figMain);

% =====================================================================
% Fig04 optional: response and energy ratios.
% =====================================================================
figOptional = figure('Name', 'Fig04_Optional_LengthScaleResponses', ...
    'Color', 'w', 'Position', [120 120 1120 500]);
tlOptional = tiledlayout(figOptional, 1, 2, 'Padding', 'compact', 'TileSpacing', 'compact');

axU = nexttile(tlOptional, 1);
axW = nexttile(tlOptional, 2);
hold(axU, 'on'); hold(axW, 'on');
grid(axU, 'on'); grid(axW, 'on');
box(axU, 'on'); box(axW, 'on');
hU = gobjects(1, numel(loadCases));

for il = 1:numel(loadCases)
    tipRatio = zeros(size(ellOverH));
    energyRatio = zeros(size(ellOverH));
    refEnergy = study.results{classicalIndex, il}.energy;

    for ie = 1:numel(ellOverH)
        item = study.results{validIndex(ie), il};
        tipRatio(ie) = item.tipRatio;
        energyRatio(ie) = item.energy/refEnergy;
    end

    hU(il) = plot(axU, ellOverH, tipRatio, ['-' markers{il}], ...
        'Color', colors(il, :), 'MarkerFaceColor', 'w', ...
        'LineWidth', 1.7, 'MarkerSize', 6);
    plot(axW, ellOverH, energyRatio, ['-' markers{il}], ...
        'Color', colors(il, :), 'MarkerFaceColor', 'w', ...
        'LineWidth', 1.7, 'MarkerSize', 6, 'HandleVisibility', 'off');
end

xlabel(axU, '$\ell/H$', 'Interpreter', 'latex');
ylabel(axU, '$u_{\mathrm{tip}}/u_{\mathrm{tip}}^{\ell=0}$', 'Interpreter', 'latex');
title(axU, '(a) Tip-displacement ratio', 'Interpreter', 'latex', 'FontWeight', 'normal');

xlabel(axW, '$\ell/H$', 'Interpreter', 'latex');
ylabel(axW, '$\Pi_{\mathrm{int}}/\Pi_{\mathrm{int}}^{\ell=0}$', 'Interpreter', 'latex');
title(axW, '(b) Energy ratio', 'Interpreter', 'latex', 'FontWeight', 'normal');

legend(axU, hU, labels, 'Interpreter', 'latex', 'FontSize', 9, ...
    'Box', 'on');
applyJournalStyle(figOptional);

printLengthScaleTable(study);
figs = struct('main', figMain, 'optional', figOptional);

end

function printLengthScaleTable(study)
fprintf('\n=========================================================\n');
fprintf(' Study 03: length-scale study summary\n');
fprintf('=========================================================\n');
fprintf(' ell/H      K/K0 small   K/K0 finite   maxG/G0 small   maxG/G0 finite\n');

classicalIndex = find(study.ellList == 0, 1, 'first');
smallG0 = study.results{classicalIndex, 1}.maxG;
finiteG0 = study.results{classicalIndex, 2}.maxG;

for ie = 1:numel(study.ellList)
    small = study.results{ie, 1};
    finite = study.results{ie, 2};
    if ~(small.converged && finite.converged)
        continue;
    end
    fprintf(' %6.3f     % .5f      % .5f        % .5f         % .5f\n', ...
        small.ellOverH, small.stiffnessRatio, finite.stiffnessRatio, ...
        small.maxG/max(smallG0, eps), finite.maxG/max(finiteG0, eps));
end
end

function applyJournalStyle(fig)
axesList = findall(fig, 'Type', 'axes');
for k = 1:numel(axesList)
    set(axesList(k), 'FontName', 'Times New Roman', 'FontSize', 10, ...
        'LineWidth', 0.8, 'TickLabelInterpreter', 'latex', 'Layer', 'top');
end
end
