function study = run4NonlinearLoadStudy(varargin)
%RUN4NONLINEARLOADSTUDY Section-9 Stage-4 nonlinear load--deflection study.
%
%   study = run4NonlinearLoadStudy('Name',Value,...)
%
% The driver uses the frozen normal solver only.  It records the complete
% load history needed for Fig05 (load--deflection), Fig06 (deformed mesh),
% and Fig07 (finite-strain contours).

p = inputParser;
addParameter(p, 'L', 4, @isPositiveScalar);
addParameter(p, 'H', 1, @isPositiveScalar);
addParameter(p, 'thickness', 1, @isPositiveScalar);
addParameter(p, 'E', 100, @isPositiveScalar);
addParameter(p, 'nu', 0.3, @(x) isFiniteScalar(x) && x > -1 && x < 0.5);
addParameter(p, 'ellList', [0 0.05 0.1], @(x) isnumeric(x) && isvector(x) && all(x >= 0));
addParameter(p, 'NeY', 8, @isPositiveInteger);
addParameter(p, 'tractionFinal', 0.25, @isPositiveScalar);
addParameter(p, 'nSteps', 20, @isPositiveInteger);
addParameter(p, 'kMax', 20, @isPositiveInteger);
addParameter(p, 'tolR', 1e-8, @isPositiveScalar);
addParameter(p, 'tolD', 1e-8, @isPositiveScalar);
addParameter(p, 'tolE', 1e-8, @isPositiveScalar);
addParameter(p, 'verbose', true, @isLogicalScalar);
parse(p, varargin{:});
o = p.Results;
o.verbose = logical(o.verbose);

ellList = o.ellList(:).';
assert(any(ellList == 0), ...
    'run4NonlinearLoadStudy:ellList must include ell=0 classical control.');

NeX = round((o.L/o.H)*o.NeY);
results = cell(1, numel(ellList));

if o.verbose
    fprintf('=========================================================\n');
    fprintf(' Stage 4: nonlinear cantilever load--deflection study\n');
    fprintf(' Mesh = %dx%d, traction final = %g, ell/H = %s\n', ...
        NeX, o.NeY, o.tractionFinal, mat2str(ellList/o.H));
    fprintf('=========================================================\n');
end

for ie = 1:numel(ellList)
    ell = ellList(ie);
    [a1, a2, a3, a4, a5] = gradientConstantsFromLength(o.E, o.nu, ell);

    bcSpecs = { ...
        struct('edge', 'x0', 'comp', 1, 'dofType', 'all', 'value', 0), ...
        struct('edge', 'x0', 'comp', 2, 'dofType', 'all', 'value', 0)};

    prob = initializeProblem( ...
        'mode', 'nonlinear', ...
        'L1', o.L, 'L2', o.H, 'thickness', o.thickness, ...
        'Ne1', NeX, 'Ne2', o.NeY, ...
        'E', o.E, 'nu', o.nu, ...
        'a1', a1, 'a2', a2, 'a3', a3, 'a4', a4, 'a5', a5, ...
        'bcSpecs', bcSpecs, ...
        'adaptive', true, 'nSteps', o.nSteps, 'kMax', o.kMax, ...
        'tolR', o.tolR, 'tolD', o.tolD, 'tolE', o.tolE, ...
        'verbose', false);

    prob.Fext = rightEdgeShearLoad(prob.mesh, prob.dof, prob.gauss, ...
        o.tractionFinal, o.thickness);
    sol = runAnalysis(prob);

    tipHistory = tipDisplacementHistory(sol, o.L, o.H);
    resultantForce = sol.lambda*(o.tractionFinal*o.H*o.thickness);
    deformedNodes = deformedNodeCoordinates(sol);

    results{ie} = struct( ...
        'ell', ell, 'ellOverH', ell/o.H, ...
        'converged', sol.finalConv, ...
        'lambda', sol.lambda, ...
        'resultantForce', resultantForce, ...
        'tipDisplacement', tipHistory, ...
        'totalIterations', sol.totalIter, ...
        'cutbacks', sum(sol.cutbacks), ...
        'solution', sol, ...
        'deformedNodes', deformedNodes, ...
        'finalTipOverH', tipHistory(end)/o.H, ...
        'finalEnergy', sol.U.Wtotal, ...
        'finalResidual', sol.U.Rnorm);

    if o.verbose
        fprintf('ell/H=%6.3f: conv=%d, final tip/H=% .4e, iter=%d, cut=%d\n', ...
            ell/o.H, sol.finalConv, tipHistory(end)/o.H, ...
            sol.totalIter, sum(sol.cutbacks));
    end
end

study = struct();
study.opts = o;
study.NeX = NeX;
study.NeY = o.NeY;
study.ellList = ellList;
study.results = results;
study.allConverged = all(cellfun(@(r) r.converged, results));

if o.verbose
    fprintf('\nStage-4 study complete. All converged = %d\n', study.allConverged);
end

end

% =====================================================================
% Local helpers.
% =====================================================================
function Fext = rightEdgeShearLoad(mesh, dof, gauss, traction, thickness)
Fext = zeros(dof.nDOF, 1);
tol = 1e-10*max(1, max(abs(mesh.X(:))));
xRight = max(mesh.X(:, 1));

for e = 1:mesh.nElem
    eg = mesh.elemGeom(e);
    if abs((eg.x0 + eg.h1) - xRight) > tol
        continue;
    end
    edofsU2 = dof.elemDOF(e, 17:32);
    edgeJacobian = eg.h2/2;
    for g = 1:gauss.ng
        eta = gauss.xi1D(g);
        w = gauss.w1D(g);
        dN = bfsShapeFunctionDerivatives(1, eta, eg.h1, eg.h2);
        Nedge = dN.N0(2, 17:32);
        Fext(edofsU2) = Fext(edofsU2) + thickness*edgeJacobian*w*traction*Nedge.';
    end
end
end

function history = tipDisplacementHistory(sol, L, H)
mesh = sol.mesh;
dof = sol.dof;
tol = 1e-10*max(1, max(abs(mesh.X(:))));
rightNodes = find(abs(mesh.X(:, 1) - L) <= tol);
[~, idx] = min(abs(mesh.X(rightNodes, 2) - H/2));
node = rightNodes(idx);
history = sol.D(dof.ID(1, 2, node), :);
end

function xDef = deformedNodeCoordinates(sol)
mesh = sol.mesh;
dof = sol.dof;
D = sol.D(:, end);
xDef = mesh.X;
for n = 1:mesh.nNodes
    xDef(n, 1) = xDef(n, 1) + D(dof.ID(1, 1, n));
    xDef(n, 2) = xDef(n, 2) + D(dof.ID(1, 2, n));
end
end

function [a1, a2, a3, a4, a5] = gradientConstantsFromLength(E, nu, ell)
if ell == 0
    a1 = 0; a2 = 0; a3 = 0; a4 = 0; a5 = 0;
    return;
end
mu = E/(2*(1 + nu));
lam = E*nu/((1 + nu)*(1 - 2*nu));
c3 = ell^2*lam/12;
c4 = ell^2*lam/12;
c5 = ell^2*(7*mu + 3*lam)/120;
c6 = ell^2*(7*mu - 4*lam)/120;
c7 = c5;
a1 = 2*c5; a2 = 2*c3; a3 = c4/2; a4 = c6; a5 = 2*c7;
end

function tf = isFiniteScalar(x)
tf = isnumeric(x) && isreal(x) && isfinite(x) && isscalar(x);
end
function tf = isPositiveScalar(x)
tf = isFiniteScalar(x) && x > 0;
end
function tf = isPositiveInteger(x)
tf = isPositiveScalar(x) && x == round(x);
end
function tf = isLogicalScalar(x)
tf = (islogical(x) && isscalar(x)) || ...
     (isnumeric(x) && isscalar(x) && (x == 0 || x == 1));
end
