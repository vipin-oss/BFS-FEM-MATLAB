function study = run5GradientSensitivityStudy(varargin)
%RUN5GRADIENTSENSITIVITYSTUDY Section-9 Study-5 parameter sensitivity.
%
%   study = run5GradientSensitivityStudy('Name',Value,...)
%
% A central logarithmic one-at-a-time sensitivity is evaluated at the
% nonlinear cantilever final load.  Only frozen solver modules are used.
%
%   S_ij = [ln(Q_j(a_i^+))-ln(Q_j(a_i^-))] / ln(f_+/f_-)
%
% Responses Q_j are apparent stiffness, tip displacement, strain energy,
% and maximum finite strain-gradient intensity.

p = inputParser;
addParameter(p, 'L', 4, @isPositiveScalar);
addParameter(p, 'H', 1, @isPositiveScalar);
addParameter(p, 'thickness', 1, @isPositiveScalar);
addParameter(p, 'E', 100, @isPositiveScalar);
addParameter(p, 'nu', 0.3, @(x) isFiniteScalar(x) && x > -1 && x < 0.5);
addParameter(p, 'ell', 0.1, @isPositiveScalar);
addParameter(p, 'NeY', 8, @isPositiveInteger);
addParameter(p, 'tractionFinal', 0.25, @isPositiveScalar);
addParameter(p, 'factorLow', 0.5, @(x) isPositiveScalar(x) && x < 1);
addParameter(p, 'factorHigh', 2.0, @(x) isPositiveScalar(x) && x > 1);
addParameter(p, 'nSteps', 20, @isPositiveInteger);
addParameter(p, 'kMax', 20, @isPositiveInteger);
addParameter(p, 'tolR', 1e-8, @isPositiveScalar);
addParameter(p, 'tolD', 1e-8, @isPositiveScalar);
addParameter(p, 'tolE', 1e-8, @isPositiveScalar);
addParameter(p, 'verbose', true, @isLogicalScalar);
parse(p, varargin{:});
o = p.Results;
o.verbose = logical(o.verbose);

NeX = round((o.L/o.H)*o.NeY);
aBase = gradientConstantsFromLength(o.E, o.nu, o.ell);

if o.verbose
    fprintf('=========================================================\n');
    fprintf(' Study 5: gradient-constant sensitivity study\n');
    fprintf(' Mesh = %dx%d, ell/H = %g, factors = [%g, %g]\n', ...
        NeX, o.NeY, o.ell/o.H, o.factorLow, o.factorHigh);
    fprintf('=========================================================\n');
end

baseline = solveCase(aBase, o, NeX);
assert(baseline.converged, 'run5GradientSensitivityStudy:baseline did not converge.');

names = {'a_1','a_2','a_3','a_4','a_5'};
minus = cell(1, 5);
plus = cell(1, 5);
responses = {'K_{app}','u_{tip}','Pi_{int}','max|G|'};
S = nan(5, 4);

for i = 1:5
    aMinus = aBase;
    aPlus = aBase;
    aMinus(i) = o.factorLow*aMinus(i);
    aPlus(i) = o.factorHigh*aPlus(i);

    minus{i} = solveCase(aMinus, o, NeX);
    plus{i} = solveCase(aPlus, o, NeX);

    if minus{i}.converged && plus{i}.converged
        qMinus = [minus{i}.apparentStiffness, abs(minus{i}.tipDisplacement), ...
                  abs(minus{i}.energy), abs(minus{i}.maxG)];
        qPlus = [plus{i}.apparentStiffness, abs(plus{i}.tipDisplacement), ...
                 abs(plus{i}.energy), abs(plus{i}.maxG)];
        S(i, :) = log(qPlus./qMinus)/log(o.factorHigh/o.factorLow);
    end

    if o.verbose
        fprintf('%s: conv[-]=%d, conv[+]=%d, S=[% .3f % .3f % .3f % .3f]\n', ...
            names{i}, minus{i}.converged, plus{i}.converged, S(i, :));
    end
end

study = struct();
study.opts = o;
study.NeX = NeX;
study.NeY = o.NeY;
study.aBase = aBase;
study.parameterNames = names;
study.responseNames = responses;
study.baseline = baseline;
study.minus = minus;
study.plus = plus;
study.sensitivity = S;
study.allConverged = all(cellfun(@(r) r.converged, minus)) && ...
                     all(cellfun(@(r) r.converged, plus));

if o.verbose
    fprintf('\nStudy-5 complete. All converged = %d\n', study.allConverged);
end

end

% =====================================================================
% Local solution and post-processing helpers.
% =====================================================================
function result = solveCase(a, o, NeX)

bcSpecs = { ...
    struct('edge', 'x0', 'comp', 1, 'dofType', 'all', 'value', 0), ...
    struct('edge', 'x0', 'comp', 2, 'dofType', 'all', 'value', 0)};

prob = initializeProblem( ...
    'mode', 'nonlinear', ...
    'L1', o.L, 'L2', o.H, 'thickness', o.thickness, ...
    'Ne1', NeX, 'Ne2', o.NeY, ...
    'E', o.E, 'nu', o.nu, ...
    'a1', a(1), 'a2', a(2), 'a3', a(3), 'a4', a(4), 'a5', a(5), ...
    'bcSpecs', bcSpecs, ...
    'adaptive', true, 'nSteps', o.nSteps, 'kMax', o.kMax, ...
    'tolR', o.tolR, 'tolD', o.tolD, 'tolE', o.tolE, ...
    'verbose', false);
prob.Fext = rightEdgeShearLoad(prob.mesh, prob.dof, prob.gauss, ...
    o.tractionFinal, o.thickness);
sol = runAnalysis(prob);

if sol.finalConv
    tip = tipDisplacement(sol, o.L, o.H);
    force = o.tractionFinal*o.H*o.thickness;
    Kapp = force/max(abs(tip), eps);
    maxG = maximumFiniteStrainGradient(sol);
else
    tip = nan; Kapp = nan; maxG = nan;
end

result = struct('converged', sol.finalConv, 'solution', sol, ...
    'tipDisplacement', tip, 'apparentStiffness', Kapp, ...
    'energy', sol.U.Wtotal, 'maxG', maxG, ...
    'iterations', sol.totalIter, 'cutbacks', sum(sol.cutbacks));
end

function Fext = rightEdgeShearLoad(mesh, dof, gauss, traction, thickness)
Fext = zeros(dof.nDOF, 1);
tol = 1e-10*max(1, max(abs(mesh.X(:))));
xRight = max(mesh.X(:, 1));
for e = 1:mesh.nElem
    eg = mesh.elemGeom(e);
    if abs((eg.x0 + eg.h1) - xRight) > tol
        continue;
    end
    edofsU2 = dof.elemDOF(e, 17:32);
    edgeJacobian = eg.h2/2;
    for g = 1:gauss.ng
        eta = gauss.xi1D(g);
        w = gauss.w1D(g);
        dN = bfsShapeFunctionDerivatives(1, eta, eg.h1, eg.h2);
        Fext(edofsU2) = Fext(edofsU2) + ...
            thickness*edgeJacobian*w*traction*dN.N0(2, 17:32).';
    end
end
end

function uTip = tipDisplacement(sol, L, H)
mesh = sol.mesh; dof = sol.dof;
tol = 1e-10*max(1, max(abs(mesh.X(:))));
rightNodes = find(abs(mesh.X(:, 1) - L) <= tol);
[~, id] = min(abs(mesh.X(rightNodes, 2) - H/2));
node = rightNodes(id);
uTip = sol.D(dof.ID(1, 2, node), end);
end

function maxG = maximumFiniteStrainGradient(sol)
mesh = sol.mesh; dof = sol.dof; gauss = sol.gauss; D = sol.D(:, end);
maxG = 0;
for e = 1:mesh.nElem
    eg = mesh.elemGeom(e); de = D(dof.elemDOF(e, :));
    s1 = 2/eg.h1; s2 = 2/eg.h2;
    s11 = s1*s1; s22 = s2*s2; s12 = s1*s2;
    for gp = 1:gauss.nGP
        dN = bfsShapeFunctionDerivatives(gauss.xi(gp), gauss.eta(gp), eg.h1, eg.h2);
        gradU = zeros(2,2); H = zeros(2,2,2);
        gradU(1,1) = s1*dN.dNdxi(1,1:16)*de(1:16);
        gradU(1,2) = s2*dN.dNdeta(1,1:16)*de(1:16);
        gradU(2,1) = s1*dN.dNdxi(2,17:32)*de(17:32);
        gradU(2,2) = s2*dN.dNdeta(2,17:32)*de(17:32);
        H(1,1,1) = s11*dN.d2Ndxi2(1,1:16)*de(1:16);
        H(1,2,2) = s22*dN.d2Ndeta2(1,1:16)*de(1:16);
        H(1,1,2) = s12*dN.d2Ndxideta(1,1:16)*de(1:16); H(1,2,1) = H(1,1,2);
        H(2,1,1) = s11*dN.d2Ndxi2(2,17:32)*de(17:32);
        H(2,2,2) = s22*dN.d2Ndeta2(2,17:32)*de(17:32);
        H(2,1,2) = s12*dN.d2Ndxideta(2,17:32)*de(17:32); H(2,2,1) = H(2,1,2);
        F = eye(2) + gradU; G = zeros(2,2,2);
        for I = 1:2
            for J = 1:2
                for K = 1:2
                    for m = 1:2
                        G(I,J,K) = G(I,J,K) + 0.5*(H(m,I,K)*F(m,J) + F(m,I)*H(m,J,K));
                    end
                end
            end
        end
        maxG = max(maxG, norm(G(:)));
    end
end
end

function a = gradientConstantsFromLength(E, nu, ell)
mu = E/(2*(1 + nu)); lam = E*nu/((1 + nu)*(1 - 2*nu));
c3 = ell^2*lam/12; c4 = ell^2*lam/12;
c5 = ell^2*(7*mu + 3*lam)/120; c6 = ell^2*(7*mu - 4*lam)/120; c7 = c5;
a = [2*c5, 2*c3, c4/2, c6, 2*c7];
end

function tf = isFiniteScalar(x)
tf = isnumeric(x) && isreal(x) && isfinite(x) && isscalar(x);
end
function tf = isPositiveScalar(x)
tf = isFiniteScalar(x) && x > 0;
end
function tf = isPositiveInteger(x)
tf = isPositiveScalar(x) && x == round(x);
end
function tf = isLogicalScalar(x)
tf = (islogical(x) && isscalar(x)) || ...
     (isnumeric(x) && isscalar(x) && (x == 0 || x == 1));
end
