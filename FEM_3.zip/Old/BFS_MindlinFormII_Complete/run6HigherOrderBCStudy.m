function study = run6HigherOrderBCStudy(varargin)
%RUN6HIGHERORDERBCSTUDY Section-9 Study-6 higher-order BC comparison.
%
%   study = run6HigherOrderBCStudy('Name',Value,...)
%
% Compares a fully clamped support (u=0, du/dN=0) against a soft support
% (u=0, free normal slope, zero natural double traction) using the frozen
% finite-strain BFS solver.

p = inputParser;
addParameter(p, 'L', 4, @isPositiveScalar);
addParameter(p, 'H', 1, @isPositiveScalar);
addParameter(p, 'thickness', 1, @isPositiveScalar);
addParameter(p, 'E', 100, @isPositiveScalar);
addParameter(p, 'nu', 0.3, @(x) isFiniteScalar(x) && x > -1 && x < 0.5);
addParameter(p, 'ell', 0.1, @isPositiveScalar);
addParameter(p, 'NeY', 8, @isPositiveInteger);
addParameter(p, 'tractionSmall', 1e-3, @isPositiveScalar);
addParameter(p, 'tractionFinite', 0.25, @isPositiveScalar);
addParameter(p, 'nSteps', 20, @isPositiveInteger);
addParameter(p, 'kMax', 20, @isPositiveInteger);
addParameter(p, 'tolR', 1e-8, @isPositiveScalar);
addParameter(p, 'tolD', 1e-8, @isPositiveScalar);
addParameter(p, 'tolE', 1e-8, @isPositiveScalar);
addParameter(p, 'verbose', true, @isLogicalScalar);
parse(p, varargin{:});
o = p.Results;
o.verbose = logical(o.verbose);

NeX = round((o.L/o.H)*o.NeY);
a = gradientConstantsFromLength(o.E, o.nu, o.ell);

bcCases = struct( ...
    'name', {'clamped', 'soft'}, ...
    'description', {'u=0, du/dN=0', 'u=0, dbar=0 natural'});
loadCases = struct('name', {'small', 'finite'}, ...
                   'traction', {o.tractionSmall, o.tractionFinite});
results = cell(numel(bcCases), numel(loadCases));

if o.verbose
    fprintf('=========================================================\n');
    fprintf(' Study 6: higher-order boundary-condition comparison\n');
    fprintf(' Mesh = %dx%d, ell/H = %g\n', NeX, o.NeY, o.ell/o.H);
    fprintf('=========================================================\n');
end

for ib = 1:numel(bcCases)
    if strcmp(bcCases(ib).name, 'clamped')
        bcSpecs = { ...
            struct('edge', 'x0', 'comp', 1, 'dofType', 'all', 'value', 0), ...
            struct('edge', 'x0', 'comp', 2, 'dofType', 'all', 'value', 0)};
    else
        % Only displacement is essential.  The free normal slope has its
        % conjugate natural datum equal to zero double traction.
        bcSpecs = { ...
            struct('edge', 'x0', 'comp', 1, 'dofType', 'u', 'value', 0), ...
            struct('edge', 'x0', 'comp', 2, 'dofType', 'u', 'value', 0)};
    end

    for il = 1:numel(loadCases)
        loadCase = loadCases(il);
        prob = initializeProblem( ...
            'mode', 'nonlinear', ...
            'L1', o.L, 'L2', o.H, 'thickness', o.thickness, ...
            'Ne1', NeX, 'Ne2', o.NeY, ...
            'E', o.E, 'nu', o.nu, ...
            'a1', a(1), 'a2', a(2), 'a3', a(3), 'a4', a(4), 'a5', a(5), ...
            'bcSpecs', bcSpecs, ...
            'adaptive', true, 'nSteps', o.nSteps, 'kMax', o.kMax, ...
            'tolR', o.tolR, 'tolD', o.tolD, 'tolE', o.tolE, ...
            'verbose', false);
        prob.Fext = rightEdgeShearLoad(prob.mesh, prob.dof, prob.gauss, ...
            loadCase.traction, o.thickness);
        sol = runAnalysis(prob);

        if sol.finalConv
            tip = tipDisplacement(sol, o.L, o.H);
            maxG = maximumFiniteStrainGradient(sol);
        else
            tip = nan;
            maxG = nan;
        end

        results{ib, il} = struct( ...
            'BCname', bcCases(ib).name, ...
            'BCdescription', bcCases(ib).description, ...
            'loadName', loadCase.name, ...
            'traction', loadCase.traction, ...
            'converged', sol.finalConv, ...
            'tipDisplacement', tip, ...
            'energy', sol.U.Wtotal, ...
            'maxG', maxG, ...
            'iterations', sol.totalIter, ...
            'cutbacks', sum(sol.cutbacks), ...
            'solution', sol);

        if o.verbose
            fprintf('%-8s, %-6s: conv=%d, tip=% .4e, max|G|=% .4e\n', ...
                bcCases(ib).name, loadCase.name, sol.finalConv, tip, maxG);
        end
    end
end

study = struct();
study.opts = o;
study.NeX = NeX;
study.NeY = o.NeY;
study.ell = o.ell;
study.bcCases = bcCases;
study.loadCases = loadCases;
study.results = results;
study.allConverged = all(cellfun(@(r) r.converged, results(:)));

if o.verbose
    fprintf('\nStage-6 study complete. All converged = %d\n', study.allConverged);
end

end

% =====================================================================
% Local helpers.
% =====================================================================
function Fext = rightEdgeShearLoad(mesh, dof, gauss, traction, thickness)
Fext = zeros(dof.nDOF, 1);
tol = 1e-10*max(1, max(abs(mesh.X(:))));
xRight = max(mesh.X(:,1));
for e = 1:mesh.nElem
    eg = mesh.elemGeom(e);
    if abs((eg.x0 + eg.h1) - xRight) > tol
        continue;
    end
    edofsU2 = dof.elemDOF(e,17:32);
    edgeJac = eg.h2/2;
    for g = 1:gauss.ng
        eta = gauss.xi1D(g);
        dN = bfsShapeFunctionDerivatives(1,eta,eg.h1,eg.h2);
        Fext(edofsU2) = Fext(edofsU2) + ...
            thickness*edgeJac*gauss.w1D(g)*traction*dN.N0(2,17:32).';
    end
end
end

function uTip = tipDisplacement(sol,L,H)
mesh = sol.mesh; dof = sol.dof;
tol = 1e-10*max(1,max(abs(mesh.X(:))));
rightNodes = find(abs(mesh.X(:,1)-L) <= tol);
[~,id] = min(abs(mesh.X(rightNodes,2)-H/2));
uTip = sol.D(dof.ID(1,2,rightNodes(id)),end);
end

function maxG = maximumFiniteStrainGradient(sol)
mesh=sol.mesh; dof=sol.dof; gauss=sol.gauss; D=sol.D(:,end);
maxG=0;
for e=1:mesh.nElem
    eg=mesh.elemGeom(e); de=D(dof.elemDOF(e,:));
    s1=2/eg.h1; s2=2/eg.h2; s11=s1*s1; s22=s2*s2; s12=s1*s2;
    for gp=1:gauss.nGP
        dN=bfsShapeFunctionDerivatives(gauss.xi(gp),gauss.eta(gp),eg.h1,eg.h2);
        gradU=zeros(2,2); H=zeros(2,2,2);
        gradU(1,1)=s1*dN.dNdxi(1,1:16)*de(1:16); gradU(1,2)=s2*dN.dNdeta(1,1:16)*de(1:16);
        gradU(2,1)=s1*dN.dNdxi(2,17:32)*de(17:32); gradU(2,2)=s2*dN.dNdeta(2,17:32)*de(17:32);
        H(1,1,1)=s11*dN.d2Ndxi2(1,1:16)*de(1:16); H(1,2,2)=s22*dN.d2Ndeta2(1,1:16)*de(1:16);
        H(1,1,2)=s12*dN.d2Ndxideta(1,1:16)*de(1:16); H(1,2,1)=H(1,1,2);
        H(2,1,1)=s11*dN.d2Ndxi2(2,17:32)*de(17:32); H(2,2,2)=s22*dN.d2Ndeta2(2,17:32)*de(17:32);
        H(2,1,2)=s12*dN.d2Ndxideta(2,17:32)*de(17:32); H(2,2,1)=H(2,1,2);
        F=eye(2)+gradU; G=zeros(2,2,2);
        for I=1:2, for J=1:2, for K=1:2, for m=1:2
            G(I,J,K)=G(I,J,K)+0.5*(H(m,I,K)*F(m,J)+F(m,I)*H(m,J,K));
        end, end, end, end
        maxG=max(maxG,norm(G(:)));
    end
end
end

function a = gradientConstantsFromLength(E,nu,ell)
mu=E/(2*(1+nu)); lam=E*nu/((1+nu)*(1-2*nu));
c3=ell^2*lam/12; c4=ell^2*lam/12;
c5=ell^2*(7*mu+3*lam)/120; c6=ell^2*(7*mu-4*lam)/120; c7=c5;
a=[2*c5,2*c3,c4/2,c6,2*c7];
end

function tf=isFiniteScalar(x)
tf=isnumeric(x)&&isreal(x)&&isfinite(x)&&isscalar(x);
end
function tf=isPositiveScalar(x)
tf=isFiniteScalar(x)&&x>0;
end
function tf=isPositiveInteger(x)
tf=isPositiveScalar(x)&&x==round(x);
end
function tf=isLogicalScalar(x)
tf=(islogical(x)&&isscalar(x)) || (isnumeric(x)&&isscalar(x)&&(x==0||x==1));
end
