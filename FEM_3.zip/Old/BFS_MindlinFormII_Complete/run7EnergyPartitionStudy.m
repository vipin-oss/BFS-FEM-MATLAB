function study = run7EnergyPartitionStudy(study4)
%RUN7ENERGYPARTITIONSTUDY Study-7 energetic mechanism analysis.
%
%   study = run7EnergyPartitionStudy(study4)
%
% Reuses the final nonlinear solutions from Study 4.  No nonlinear solve is
% repeated.  The stored energy is decomposed exactly according to the
% frozen free energy: Psi = Psi_SVK + Psi_g.

assert(isstruct(study4) && isfield(study4, 'results') && ...
       isfield(study4, 'ellList'), ...
    'run7EnergyPartitionStudy:Study-4 result struct required.');

nCases = numel(study4.ellList);
Wsvk = nan(1, nCases);
Wgrad = nan(1, nCases);
Wtotal = nan(1, nCases);
converged = false(1, nCases);

for i = 1:nCases
    item = study4.results{i};
    sol = item.solution;
    converged(i) = item.converged;
    if converged(i)
        [Wsvk(i), Wgrad(i)] = energyPartition(sol);
        Wtotal(i) = Wsvk(i) + Wgrad(i);
    end
end

study = struct();
study.ellList = study4.ellList;
study.ellOverH = study4.ellList/study4.opts.H;
study.Wsvk = Wsvk;
study.Wgrad = Wgrad;
study.Wtotal = Wtotal;
study.gradientFraction = Wgrad./Wtotal;
study.converged = converged;
study.allConverged = all(converged);
study.sourceStudy = 'Study 4 nonlinear cantilever final state';

fprintf('\n=========================================================\n');
fprintf(' Study 7: nonlinear energy partition\n');
fprintf('=========================================================\n');
for i = 1:nCases
    fprintf('ell/H=%6.3f: W_SVK=% .4e, W_g=% .4e, W_g/W=% .4f\n', ...
        study.ellOverH(i), Wsvk(i), Wgrad(i), study.gradientFraction(i));
end

end

% =====================================================================
% Frozen energy decomposition.
% =====================================================================
function [Wsvk, Wgrad] = energyPartition(sol)
mesh = sol.mesh;
dof = sol.dof;
gauss = sol.gauss;
mat = sol.mat;
D = sol.D(:,end);
thickness = 1;
if isfield(mat, 'thickness')
    thickness = mat.thickness;
end

Wsvk = 0;
Wgrad = 0;

for e = 1:mesh.nElem
    eg = mesh.elemGeom(e);
    de = D(dof.elemDOF(e,:));
    s1 = 2/eg.h1; s2 = 2/eg.h2;
    s11 = s1*s1; s22 = s2*s2; s12 = s1*s2;
    detJ = eg.h1*eg.h2/4;

    for gp = 1:gauss.nGP
        dN = bfsShapeFunctionDerivatives(gauss.xi(gp),gauss.eta(gp),eg.h1,eg.h2);
        gradU = zeros(2,2); H = zeros(2,2,2);
        gradU(1,1)=s1*dN.dNdxi(1,1:16)*de(1:16); gradU(1,2)=s2*dN.dNdeta(1,1:16)*de(1:16);
        gradU(2,1)=s1*dN.dNdxi(2,17:32)*de(17:32); gradU(2,2)=s2*dN.dNdeta(2,17:32)*de(17:32);
        H(1,1,1)=s11*dN.d2Ndxi2(1,1:16)*de(1:16); H(1,2,2)=s22*dN.d2Ndeta2(1,1:16)*de(1:16);
        H(1,1,2)=s12*dN.d2Ndxideta(1,1:16)*de(1:16); H(1,2,1)=H(1,1,2);
        H(2,1,1)=s11*dN.d2Ndxi2(2,17:32)*de(17:32); H(2,2,2)=s22*dN.d2Ndeta2(2,17:32)*de(17:32);
        H(2,1,2)=s12*dN.d2Ndxideta(2,17:32)*de(17:32); H(2,2,1)=H(2,1,2);

        F = eye(2) + gradU;
        E = 0.5*(F.'*F-eye(2));
        G = zeros(2,2,2);
        for I=1:2, for J=1:2, for K=1:2, for m=1:2
            G(I,J,K)=G(I,J,K)+0.5*(H(m,I,K)*F(m,J)+F(m,I)*H(m,J,K));
        end, end, end, end

        psiSVK = 0.5*mat.lambda*(trace(E))^2 + mat.mu*sum(E(:).^2);
        psiG = 0;
        for I=1:2, for J=1:2, for K=1:2, for P=1:2, for Q=1:2, for R=1:2
            psiG = psiG + 0.5*mat.D6(I,J,K,P,Q,R)*G(I,J,K)*G(P,Q,R);
        end, end, end, end, end, end

        dV = thickness*detJ*gauss.w(gp);
        Wsvk = Wsvk + psiSVK*dV;
        Wgrad = Wgrad + psiG*dV;
    end
end
end
