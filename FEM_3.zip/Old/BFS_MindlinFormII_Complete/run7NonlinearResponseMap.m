function study = run7NonlinearResponseMap(varargin)
%RUN7NONLINEARRESPONSEMAP Study-7 load--length-scale response map.
%
%   study = run7NonlinearResponseMap('Name',Value,...)
%
% Evaluates the coupled effect of normalized traction and internal length
% scale using the frozen finite-strain solver.  The stored result contains
% scalar response maps only, avoiding unnecessary storage of all solution
% histories.

p = inputParser;
addParameter(p, 'L', 4, @isPositiveScalar);
addParameter(p, 'H', 1, @isPositiveScalar);
addParameter(p, 'thickness', 1, @isPositiveScalar);
addParameter(p, 'E', 100, @isPositiveScalar);
addParameter(p, 'nu', 0.3, @(x) isFiniteScalar(x) && x > -1 && x < 0.5);
addParameter(p, 'ellList', [0 0.025 0.05 0.1], @(x) isnumeric(x) && isvector(x) && all(x >= 0));
addParameter(p, 'tractionList', [0.05 0.15 0.25 0.35], @(x) isnumeric(x) && isvector(x) && all(x > 0));
addParameter(p, 'NeY', 8, @isPositiveInteger);
addParameter(p, 'nSteps', 20, @isPositiveInteger);
addParameter(p, 'kMax', 20, @isPositiveInteger);
addParameter(p, 'tolR', 1e-8, @isPositiveScalar);
addParameter(p, 'tolD', 1e-8, @isPositiveScalar);
addParameter(p, 'tolE', 1e-8, @isPositiveScalar);
addParameter(p, 'verbose', true, @isLogicalScalar);
parse(p, varargin{:});
o = p.Results;
o.verbose = logical(o.verbose);

ellList = o.ellList(:).';
tractionList = o.tractionList(:).';
assert(any(ellList == 0), ...
    'run7NonlinearResponseMap:ellList must include ell=0 reference.');

NeX = round((o.L/o.H)*o.NeY);
nEll = numel(ellList);
nLoad = numel(tractionList);
Kapp = nan(nLoad, nEll);
tipU = nan(nLoad, nEll);
energy = nan(nLoad, nEll);
maxG = nan(nLoad, nEll);
iterations = nan(nLoad, nEll);
cutbacks = nan(nLoad, nEll);
converged = false(nLoad, nEll);

if o.verbose
    fprintf('=========================================================\n');
    fprintf(' Study 7: nonlinear load--length-scale response map\n');
    fprintf(' Mesh = %dx%d, ell/H = %s\n', NeX, o.NeY, mat2str(ellList/o.H));
    fprintf(' traction/E = %s\n', mat2str(tractionList/o.E));
    fprintf('=========================================================\n');
end

for il = 1:nLoad
    traction = tractionList(il);

    for ie = 1:nEll
        ell = ellList(ie);
        a = gradientConstantsFromLength(o.E, o.nu, ell);
        bcSpecs = { ...
            struct('edge', 'x0', 'comp', 1, 'dofType', 'all', 'value', 0), ...
            struct('edge', 'x0', 'comp', 2, 'dofType', 'all', 'value', 0)};

        prob = initializeProblem( ...
            'mode', 'nonlinear', ...
            'L1', o.L, 'L2', o.H, 'thickness', o.thickness, ...
            'Ne1', NeX, 'Ne2', o.NeY, ...
            'E', o.E, 'nu', o.nu, ...
            'a1', a(1), 'a2', a(2), 'a3', a(3), 'a4', a(4), 'a5', a(5), ...
            'bcSpecs', bcSpecs, ...
            'adaptive', true, 'nSteps', o.nSteps, 'kMax', o.kMax, ...
            'tolR', o.tolR, 'tolD', o.tolD, 'tolE', o.tolE, ...
            'verbose', false);
        prob.Fext = rightEdgeShearLoad(prob.mesh, prob.dof, prob.gauss, ...
            traction, o.thickness);
        sol = runAnalysis(prob);

        converged(il, ie) = sol.finalConv;
        iterations(il, ie) = sol.totalIter;
        cutbacks(il, ie) = sum(sol.cutbacks);

        if sol.finalConv
            tipU(il, ie) = tipDisplacement(sol, o.L, o.H);
            energy(il, ie) = sol.U.Wtotal;
            maxG(il, ie) = maximumFiniteStrainGradient(sol);
            force = traction*o.H*o.thickness;
            Kapp(il, ie) = force/max(abs(tipU(il, ie)), eps);
        end

        if o.verbose
            fprintf('t/E=%7.4f, ell/H=%6.3f: conv=%d, tip/H=% .4e, K=% .4e, G=% .4e\n', ...
                traction/o.E, ell/o.H, sol.finalConv, ...
                tipU(il,ie)/o.H, Kapp(il,ie), maxG(il,ie));
        end
    end
end

classicalIndex = find(ellList == 0, 1, 'first');
Kratio = Kapp./Kapp(:, classicalIndex);
Gratio = maxG./maxG(:, classicalIndex);
tipRatio = tipU./tipU(:, classicalIndex);

study = struct();
study.opts = o;
study.NeX = NeX;
study.NeY = o.NeY;
study.ellList = ellList;
study.tractionList = tractionList;
study.Kapp = Kapp;
study.tipU = tipU;
study.energy = energy;
study.maxG = maxG;
study.iterations = iterations;
study.cutbacks = cutbacks;
study.converged = converged;
study.Kratio = Kratio;
study.Gratio = Gratio;
study.tipRatio = tipRatio;
study.allConverged = all(converged(:));

if o.verbose
    fprintf('\nStage-7 study complete. All converged = %d\n', study.allConverged);
end

end

% =====================================================================
% Local helpers.
% =====================================================================
function Fext = rightEdgeShearLoad(mesh, dof, gauss, traction, thickness)
Fext = zeros(dof.nDOF, 1);
tol = 1e-10*max(1, max(abs(mesh.X(:))));
xRight = max(mesh.X(:,1));
for e = 1:mesh.nElem
    eg = mesh.elemGeom(e);
    if abs((eg.x0 + eg.h1) - xRight) > tol
        continue;
    end
    edofsU2 = dof.elemDOF(e,17:32);
    edgeJac = eg.h2/2;
    for g = 1:gauss.ng
        eta = gauss.xi1D(g);
        dN = bfsShapeFunctionDerivatives(1,eta,eg.h1,eg.h2);
        Fext(edofsU2) = Fext(edofsU2) + ...
            thickness*edgeJac*gauss.w1D(g)*traction*dN.N0(2,17:32).';
    end
end
end

function uTip = tipDisplacement(sol,L,H)
mesh=sol.mesh; dof=sol.dof;
tol=1e-10*max(1,max(abs(mesh.X(:))));
rightNodes=find(abs(mesh.X(:,1)-L)<=tol);
[~,id]=min(abs(mesh.X(rightNodes,2)-H/2));
uTip=sol.D(dof.ID(1,2,rightNodes(id)),end);
end

function maxG = maximumFiniteStrainGradient(sol)
mesh=sol.mesh; dof=sol.dof; gauss=sol.gauss; D=sol.D(:,end);
maxG=0;
for e=1:mesh.nElem
    eg=mesh.elemGeom(e); de=D(dof.elemDOF(e,:));
    s1=2/eg.h1; s2=2/eg.h2; s11=s1*s1; s22=s2*s2; s12=s1*s2;
    for gp=1:gauss.nGP
        dN=bfsShapeFunctionDerivatives(gauss.xi(gp),gauss.eta(gp),eg.h1,eg.h2);
        gradU=zeros(2,2); H=zeros(2,2,2);
        gradU(1,1)=s1*dN.dNdxi(1,1:16)*de(1:16); gradU(1,2)=s2*dN.dNdeta(1,1:16)*de(1:16);
        gradU(2,1)=s1*dN.dNdxi(2,17:32)*de(17:32); gradU(2,2)=s2*dN.dNdeta(2,17:32)*de(17:32);
        H(1,1,1)=s11*dN.d2Ndxi2(1,1:16)*de(1:16); H(1,2,2)=s22*dN.d2Ndeta2(1,1:16)*de(1:16);
        H(1,1,2)=s12*dN.d2Ndxideta(1,1:16)*de(1:16); H(1,2,1)=H(1,1,2);
        H(2,1,1)=s11*dN.d2Ndxi2(2,17:32)*de(17:32); H(2,2,2)=s22*dN.d2Ndeta2(2,17:32)*de(17:32);
        H(2,1,2)=s12*dN.d2Ndxideta(2,17:32)*de(17:32); H(2,2,1)=H(2,1,2);
        F=eye(2)+gradU; G=zeros(2,2,2);
        for I=1:2, for J=1:2, for K=1:2, for m=1:2
            G(I,J,K)=G(I,J,K)+0.5*(H(m,I,K)*F(m,J)+F(m,I)*H(m,J,K));
        end, end, end, end
        maxG=max(maxG,norm(G(:)));
    end
end
end

function a = gradientConstantsFromLength(E,nu,ell)
mu=E/(2*(1+nu)); lam=E*nu/((1+nu)*(1-2*nu));
c3=ell^2*lam/12; c4=ell^2*lam/12;
c5=ell^2*(7*mu+3*lam)/120; c6=ell^2*(7*mu-4*lam)/120; c7=c5;
a=[2*c5,2*c3,c4/2,c6,2*c7];
end

function tf=isFiniteScalar(x)
tf=isnumeric(x)&&isreal(x)&&isfinite(x)&&isscalar(x);
end
function tf=isPositiveScalar(x)
tf=isFiniteScalar(x)&&x>0;
end
function tf=isPositiveInteger(x)
tf=isPositiveScalar(x)&&x==round(x);
end
function tf=isLogicalScalar(x)
tf=(islogical(x)&&isscalar(x)) || (isnumeric(x)&&isscalar(x)&&(x==0||x==1));
end
