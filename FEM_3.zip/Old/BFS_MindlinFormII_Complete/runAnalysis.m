function sol = runAnalysis(prob)
%RUNANALYSIS Execute one frozen BFS Mindlin Form-II FE analysis.
%
%   sol = runAnalysis(prob)
%
% The problem is supplied by initializeProblem.  This module delegates
% solution to newtonRaphsonSolver and performs final-state post-processing
% with the same 3x3 parent-domain Gauss data and BFS kinematics used by
% the element residual/tangent modules.

% ---------------------------------------------------------------------
% Validate and unpack the initialized problem.
% ---------------------------------------------------------------------
assert(isstruct(prob) && isfield(prob, 'mesh') && isfield(prob, 'mat') && ...
       isfield(prob, 'dof') && isfield(prob, 'gauss') && ...
       isfield(prob, 'Fext') && isfield(prob, 'D0') && ...
       isfield(prob, 'solver'), ...
    'runAnalysis:prob must be a struct returned by initializeProblem.');

mesh = prob.mesh;
mat = prob.mat;
dof = prob.dof;
gauss = prob.gauss;
Fext = prob.Fext(:);
D0 = prob.D0(:);
sv = prob.solver;
nDOF = dof.nDOF;

assert(numel(Fext) == nDOF, 'runAnalysis:Fext length mismatch.');
assert(numel(D0) == nDOF, 'runAnalysis:D0 length mismatch.');
assert(isfield(gauss, 'ng') && isfield(gauss, 'xi1D') && isfield(gauss, 'w1D'), ...
    'runAnalysis:gauss must contain ng, xi1D, and w1D from gaussQuadrature.');

% ---------------------------------------------------------------------
% Frozen Newton--Raphson solve.
% ---------------------------------------------------------------------
nrSol = newtonRaphsonSolver(mat, mesh, dof, gauss, Fext, ...
    'lambda0', sv.lambda0, ...
    'lambdaFinal', sv.lambdaFinal, ...
    'nSteps', sv.nSteps, ...
    'dlambda0', sv.dlambda0, ...
    'dlambdaMin', 1e-8, ...
    'dlambdaMax', inf, ...
    'adaptive', sv.adaptive, ...
    'alpha', sv.alpha, ...
    'beta', sv.beta, ...
    'kTarget', sv.kTarget, ...
    'kMax', sv.kMax, ...
    'tolR', sv.tolR, ...
    'tolD', sv.tolD, ...
    'tolE', sv.tolE, ...
    'divergenceTol', 1e6, ...
    'maxCutbacks', sv.maxCutbacks, ...
    'verbose', sv.verbose, ...
    'D0', D0, ...
    'linearMode', sv.linearMode);

assert(nrSol.nDOF == nDOF, ...
    'runAnalysis:solver returned an inconsistent nDOF.');

% ---------------------------------------------------------------------
% Final-state energy and residual quantities.
% ---------------------------------------------------------------------
Dfinal = nrSol.D(:, end);
W_e = localStrainEnergyLoop(mesh, dof, gauss, mat, Dfinal);
Wtotal = sum(W_e);

Rfinal = assembleGlobalResidual(Dfinal, mat, mesh, dof, gauss) - ...
         nrSol.lambda(end)*Fext;

% The full residual contains reactions at essential DOFs.  The convergence
% residual is therefore the free-DOF residual only.
Rfree = Rfinal(dof.freeDOF);
Rnorm = norm(Rfree, 2);

% ---------------------------------------------------------------------
% Solution object.
% ---------------------------------------------------------------------
sol = struct();

if isfield(prob, 'geom')
    sol.geom = prob.geom;
else
    sol.geom = struct();
end
if isfield(prob, 'bc')
    sol.bc = prob.bc;
else
    sol.bc = struct();
end
if isfield(prob, 'mode')
    sol.mode = prob.mode;
else
    sol.mode = '';
end

sol.mesh = mesh;
sol.mat = mat;
sol.dof = dof;
sol.gauss = gauss;
sol.D = nrSol.D;
sol.Rxn = nrSol.Rxn;
sol.lambda = nrSol.lambda;
sol.nIter = nrSol.nIter;
sol.converged = nrSol.converged;
sol.stepInfo = nrSol.stepInfo;
sol.dlambdaHist = nrSol.dlambdaHist;
sol.cutbacks = nrSol.cutbacks;
if isfield(nrSol, 'loadHist')
    sol.loadHist = nrSol.loadHist;
end
sol.totalIter = nrSol.totalIter;
sol.finalConv = nrSol.finalConv;
sol.nDOF = nrSol.nDOF;
sol.nFree = nrSol.nFree;
sol.nEss = nrSol.nEss;
sol.U = struct('W_e', W_e, ...
               'Wtotal', Wtotal, ...
               'L2norm', norm(Dfinal, 2), ...
               'Rfinal', Rfinal, ...
               'Rfree', Rfree, ...
               'Rnorm', Rnorm);
sol.solverOpts = sv;
sol.info = struct('completedAt', datestr(now, 31), ...
                  'versionTag', 'BFS Mindlin Form-II', ...
                  'nStepsTaken', numel(sol.lambda) - 1);

% ---------------------------------------------------------------------
% Output consistency.
% ---------------------------------------------------------------------
assert(isequal(size(sol.D), [nDOF, numel(sol.lambda)]), ...
    'runAnalysis:sol.D shape mismatch.');
assert(isequal(size(sol.Rxn), [nDOF, numel(sol.lambda)]), ...
    'runAnalysis:sol.Rxn shape mismatch.');
assert(numel(sol.nIter) == numel(sol.lambda), ...
    'runAnalysis:sol.nIter length mismatch.');
assert(islogical(sol.converged), ...
    'runAnalysis:sol.converged must be logical.');
assert(Wtotal >= -1e-12, ...
    'runAnalysis:strain energy cannot be negative (W=%g).', Wtotal);

if sol.finalConv
    assert(Rnorm < 1e-3, ...
        ['runAnalysis:free-DOF residual norm %g exceeds the final ' ...
         'convergence threshold.'], Rnorm);
end

end

% =====================================================================
% Local post-processing: frozen strain-energy quadrature.
% =====================================================================
function W_e = localStrainEnergyLoop(mesh, dof, gauss, mat, D)

Ne = mesh.nElem;
W_e = zeros(Ne, 1);

if isfield(mat, 'thickness')
    thickness = mat.thickness;
else
    thickness = 1;
end

% Field names are case-sensitive and match gaussQuadrature.m exactly.
xi1D = gauss.xi1D;
w1D = gauss.w1D;
ng = gauss.ng;

for e = 1:Ne
    eg = mesh.elemGeom(e);
    edofs = dof.elemDOF(e, :);
    de = D(edofs);

    Jmap = computeJacobian(eg);
    h1 = Jmap.h1;
    h2 = Jmap.h2;
    detJ = Jmap.detJ;

    scale1 = 2/h1;
    scale2 = 2/h2;
    scale11 = scale1*scale1;
    scale22 = scale2*scale2;
    scale12 = scale1*scale2;

    We = 0;

    for i = 1:ng
        for j = 1:ng
            xi = xi1D(i);
            eta = xi1D(j);
            w = w1D(i)*w1D(j);

            dN = bfsShapeFunctionDerivatives(xi, eta, h1, h2);

            dNxi1 = dN.dNdxi(1, 1:16);
            dNeta1 = dN.dNdeta(1, 1:16);
            d2Nxi1 = dN.d2Ndxi2(1, 1:16);
            d2Neta1 = dN.d2Ndeta2(1, 1:16);
            d2Nxe1 = dN.d2Ndxideta(1, 1:16);

            dNxi2 = dN.dNdxi(2, 17:32);
            dNeta2 = dN.dNdeta(2, 17:32);
            d2Nxi2 = dN.d2Ndxi2(2, 17:32);
            d2Neta2 = dN.d2Ndeta2(2, 17:32);
            d2Nxe2 = dN.d2Ndxideta(2, 17:32);

            gradU = zeros(2, 2);
            gradU(1, 1) = scale1*(dNxi1*de(1:16));
            gradU(1, 2) = scale2*(dNeta1*de(1:16));
            gradU(2, 1) = scale1*(dNxi2*de(17:32));
            gradU(2, 2) = scale2*(dNeta2*de(17:32));

            gradGradU = zeros(2, 2, 2);
            gradGradU(1, 1, 1) = scale11*(d2Nxi1*de(1:16));
            gradGradU(1, 2, 2) = scale22*(d2Neta1*de(1:16));
            gradGradU(1, 1, 2) = scale12*(d2Nxe1*de(1:16));
            gradGradU(1, 2, 1) = gradGradU(1, 1, 2);
            gradGradU(2, 1, 1) = scale11*(d2Nxi2*de(17:32));
            gradGradU(2, 2, 2) = scale22*(d2Neta2*de(17:32));
            gradGradU(2, 1, 2) = scale12*(d2Nxe2*de(17:32));
            gradGradU(2, 2, 1) = gradGradU(2, 1, 2);

            Fdata = computeDeformationGradient(gradU);
            if isstruct(Fdata)
                F = Fdata.F;
            else
                F = Fdata;
            end

            Edata = computeGreenLagrangeStrain(F);
            if isstruct(Edata)
                E = Edata.E;
            else
                E = Edata;
            end

            Gdata = computeStrainGradient(gradU, gradGradU);
            if isstruct(Gdata)
                G = Gdata.G;
            else
                G = Gdata;
            end

            psiData = computeStrainEnergyDensity(mat.C4, mat.D6, E, G);
            if isstruct(psiData)
                psi = psiData.total;
            else
                psi = psiData;
            end

            We = We + w*psi*detJ*thickness;
        end
    end

    W_e(e) = We;
end

end
