function sol = runAnalysis2022(prob)
%RUNANALYSIS2022 Run one isolated 2022 benchmark case.

nr = newtonRaphsonSolver2022(prob);

sol = nr;
sol.caseName = prob.caseName;
sol.mesh = prob.mesh;
sol.mat = prob.mat;
sol.dof = prob.dof;
sol.gauss = prob.gauss;
sol.constraints = prob.constraints;
sol.paper = prob.paper;
sol.Fext = prob.Fext;

% Reduced residual at final state, used for benchmark solver verification.
Dfinal = sol.D(:, end);
Rfull = assembleGlobalResidual(Dfinal, prob.mat, prob.mesh, prob.dof, prob.gauss) - ...
        sol.lambda(end)*prob.Fext;
sol.Rfull = Rfull;
sol.Rreduced = prob.constraints.T.'*Rfull;
sol.Rnorm = norm(sol.Rreduced);

end
