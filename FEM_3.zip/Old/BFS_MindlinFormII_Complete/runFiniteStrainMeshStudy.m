function study = runFiniteStrainMeshStudy(varargin)
%RUNFINITESTRAINMESHSTUDY Section-9 Stage-2 nonlinear mesh study.
%
%   study = runFiniteStrainMeshStudy('Name',Value,...)
%
% This driver does not modify the frozen formulation.  It prepares a
% cantilever/end-shear problem, calls initializeProblem/runAnalysis, and
% compares coarse meshes against the finest-mesh numerical reference.
%
% Default study cases:
%   ell = 0       : classical finite-strain SVK control
%   ell = 0.1     : finite-strain Mindlin gradient case
%   small load    : near-linear cross-check
%   finite load   : moderate finite-deformation response

p = inputParser;
addParameter(p, 'L', 4, @isPositiveScalar);
addParameter(p, 'H', 1, @isPositiveScalar);
addParameter(p, 'thickness', 1, @isPositiveScalar);
addParameter(p, 'E', 100, @isPositiveScalar);
addParameter(p, 'nu', 0.3, @(x) isFiniteScalar(x) && x > -1 && x < 0.5);
addParameter(p, 'ellList', [0, 0.1], @(x) isnumeric(x) && isvector(x) && all(x >= 0));
addParameter(p, 'NeYList', [2, 4, 8], @(x) isnumeric(x) && isvector(x));
addParameter(p, 'tractionSmall', 1e-3, @isPositiveScalar);
addParameter(p, 'tractionFinite', 1e-1, @isPositiveScalar);
addParameter(p, 'nSteps', 10, @isPositiveInteger);
addParameter(p, 'kMax', 20, @isPositiveInteger);
addParameter(p, 'tolR', 1e-8, @isPositiveScalar);
addParameter(p, 'tolD', 1e-8, @isPositiveScalar);
addParameter(p, 'tolE', 1e-8, @isPositiveScalar);
addParameter(p, 'verbose', true, @isLogicalScalar);
parse(p, varargin{:});
o = p.Results;
o.verbose = logical(o.verbose);

NeYList = o.NeYList(:).';
assert(all(NeYList >= 1) && all(NeYList == round(NeYList)), ...
    'runFiniteStrainMeshStudy:NeYList must contain positive integers.');

loadCases = struct( ...
    'name', {'small', 'finite'}, ...
    'traction', {o.tractionSmall, o.tractionFinite});
ellList = o.ellList(:).';
results = cell(numel(ellList), numel(loadCases));

if o.verbose
    fprintf('=========================================================\n');
    fprintf(' Stage 2: finite-strain cantilever mesh-convergence study\n');
    fprintf(' L/H = %g, E = %g, nu = %g\n', o.L/o.H, o.E, o.nu);
    fprintf(' NeYList = %s, ellList = %s\n', mat2str(NeYList), mat2str(ellList));
    fprintf('=========================================================\n');
end

for ie = 1:numel(ellList)
    ell = ellList(ie);
    [a1, a2, a3, a4, a5] = gradientConstantsFromLength(o.E, o.nu, ell);

    for il = 1:numel(loadCases)
        loadCase = loadCases(il);
        nMesh = numel(NeYList);
        nDOF = zeros(1, nMesh);
        tipU = nan(1, nMesh);
        energy = nan(1, nMesh);
        nIter = nan(1, nMesh);
        cutbacks = nan(1, nMesh);
        converged = false(1, nMesh);
        finalResidual = nan(1, nMesh);

        if o.verbose
            fprintf('\nell=%g, load=%s, traction=%g\n', ell, loadCase.name, loadCase.traction);
        end

        for im = 1:nMesh
            NeY = NeYList(im);
            NeX = round((o.L/o.H)*NeY); % square BFS elements

            % Left edge fully clamped; vertical dead traction acts at x=L.
            bcSpecs = { ...
                struct('edge', 'x0', 'comp', 1, 'dofType', 'all', 'value', 0), ...
                struct('edge', 'x0', 'comp', 2, 'dofType', 'all', 'value', 0)};

            prob0 = initializeProblem( ...
                'mode', 'nonlinear', ...
                'L1', o.L, 'L2', o.H, 'thickness', o.thickness, ...
                'Ne1', NeX, 'Ne2', NeY, ...
                'E', o.E, 'nu', o.nu, ...
                'a1', a1, 'a2', a2, 'a3', a3, 'a4', a4, 'a5', a5, ...
                'bcSpecs', bcSpecs, ...
                'adaptive', true, 'nSteps', o.nSteps, ...
                'kMax', o.kMax, ...
                'tolR', o.tolR, 'tolD', o.tolD, 'tolE', o.tolE, ...
                'verbose', false);

            % External force is constructed on the right edge using the
            % frozen 3-point edge quadrature and current BFS shape data.
            prob0.Fext = rightEdgeShearLoad(prob0.mesh, prob0.dof, prob0.gauss, ...
                                             loadCase.traction, o.thickness);

            sol = runAnalysis(prob0);
            nDOF(im) = sol.nDOF;
            converged(im) = sol.finalConv;
            nIter(im) = sol.totalIter;
            cutbacks(im) = sum(sol.cutbacks);
            finalResidual(im) = sol.U.Rnorm;

            if sol.finalConv
                tipU(im) = tipDisplacement(sol, o.L, o.H);
                energy(im) = sol.U.Wtotal;
            end

            if o.verbose
                fprintf('  Ne=%dx%d, nDOF=%d, conv=%d, tip=% .4e, W=% .4e, iter=%d, cut=%d\n', ...
                    NeX, NeY, nDOF(im), converged(im), tipU(im), energy(im), ...
                    nIter(im), cutbacks(im));
            end
        end

        % Finest mesh is the numerical overkill reference for this case.
        refTip = tipU(end);
        refEnergy = energy(end);
        errTip = abs(tipU - refTip)/max(abs(refTip), eps);
        errEnergy = abs(energy - refEnergy)/max(abs(refEnergy), eps);
        rateTip = observedRates(errTip, NeYList);
        rateEnergy = observedRates(errEnergy, NeYList);

        results{ie, il} = struct( ...
            'ell', ell, 'loadName', loadCase.name, 'traction', loadCase.traction, ...
            'NeY', NeYList, 'NeX', round((o.L/o.H)*NeYList), ...
            'nDOF', nDOF, 'tipDisplacement', tipU, 'energy', energy, ...
            'totalIterations', nIter, 'cutbacks', cutbacks, ...
            'converged', converged, 'residual', finalResidual, ...
            'referenceTip', refTip, 'referenceEnergy', refEnergy, ...
            'tipError', errTip, 'energyError', errEnergy, ...
            'rateTip', rateTip, 'rateEnergy', rateEnergy);
    end
end

study = struct();
study.opts = o;
study.results = results;
study.loadCases = loadCases;
study.ellList = ellList;
study.NeYList = NeYList;
study.allConverged = all(cellfun(@(r) all(r.converged), results(:)));

if o.verbose
    fprintf('\nStage-2 study complete. All converged = %d\n', study.allConverged);
end

end

% =====================================================================
% Local helpers.
% =====================================================================
function Fext = rightEdgeShearLoad(mesh, dof, gauss, traction, thickness)

Fext = zeros(dof.nDOF, 1);
tol = 1e-10*max(1, max(abs(mesh.X(:))));
xRight = max(mesh.X(:, 1));

for e = 1:mesh.nElem
    eg = mesh.elemGeom(e);
    if abs((eg.x0 + eg.h1) - xRight) > tol
        continue;
    end

    % Vertical nominal traction acts on displacement component u2.
    edofsU2 = dof.elemDOF(e, 17:32);
    edgeJacobian = eg.h2/2;

    for g = 1:gauss.ng
        eta = gauss.xi1D(g);
        w = gauss.w1D(g);
        dN = bfsShapeFunctionDerivatives(1, eta, eg.h1, eg.h2);
        Nedge = dN.N0(2, 17:32);
        Fext(edofsU2) = Fext(edofsU2) + ...
            thickness*edgeJacobian*w*traction*Nedge.';
    end
end

end

function uTip = tipDisplacement(sol, L, H)

mesh = sol.mesh;
dof = sol.dof;
tol = 1e-10*max(1, max(abs(mesh.X(:))));
rightNodes = find(abs(mesh.X(:, 1) - L) <= tol);
[~, idx] = min(abs(mesh.X(rightNodes, 2) - H/2));
node = rightNodes(idx);
uTip = sol.D(dof.ID(1, 2, node), end);

end

function [a1, a2, a3, a4, a5] = gradientConstantsFromLength(E, nu, ell)

if ell == 0
    a1 = 0; a2 = 0; a3 = 0; a4 = 0; a5 = 0;
    return;
end

mu = E/(2*(1 + nu));
lam = E*nu/((1 + nu)*(1 - 2*nu));
c3 = ell^2*lam/12;
c4 = ell^2*lam/12;
c5 = ell^2*(7*mu + 3*lam)/120;
c6 = ell^2*(7*mu - 4*lam)/120;
c7 = c5;

% Direct matching to the frozen invariant ordering.
a1 = 2*c5;
a2 = 2*c3;
a3 = c4/2;
a4 = c6;
a5 = 2*c7;

end

function rates = observedRates(err, NeY)

rates = nan(size(err));
for i = 2:numel(err)
    if NeY(i) == 2*NeY(i - 1) && err(i - 1) > 0 && err(i) > 0
        rates(i) = log2(err(i - 1)/err(i));
    end
end
end

function tf = isFiniteScalar(x)
tf = isnumeric(x) && isreal(x) && isfinite(x) && isscalar(x);
end

function tf = isPositiveScalar(x)
tf = isFiniteScalar(x) && x > 0;
end

function tf = isPositiveInteger(x)
tf = isPositiveScalar(x) && x == round(x);
end

function tf = isLogicalScalar(x)
tf = (islogical(x) && isscalar(x)) || ...
     (isnumeric(x) && isscalar(x) && (x == 0 || x == 1));
end
