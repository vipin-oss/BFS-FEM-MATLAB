function result = runProject(mode)
%RUNPROJECT Master launcher for the BFS Mindlin Form-II project.
%
%   runProject
%   result = runProject('benchmark')
%   result = runProject('benchmarkplots')
%   result = runProject('stage2')
%   result = runProject('stage2plots')
%   result = runProject('stage3')
%   result = runProject('stage3plots')
%   result = runProject('stage4')
%   result = runProject('stage4plots')
%   result = runProject('stage5')
%   result = runProject('stage5plots')
%   result = runProject('stage6')
%   result = runProject('stage6plots')
%   result = runProject('stage7')
%   result = runProject('stage7plots')
%
% This is the high-level launcher used after a fresh MATLAB start.  It
% loads a saved study when available; otherwise it runs the study once and
% saves its result to disk for future sessions.

projectRoot = fileparts(mfilename('fullpath'));
benchmarkFolder = fullfile(projectRoot, 'benchmark2022');
if exist(benchmarkFolder, 'dir') == 7
    addpath(benchmarkFolder);
end
resultsFolder = projectResultsFolder(projectRoot);

if nargin < 1 || isempty(mode)
    choice = menu('BFS Mindlin Form-II Project', ...
        'Study 1: Run/load exact 2022 benchmark', ...
        'Study 1: Plot exact 2022 benchmark', ...
        'Study 2: Run/load finite-strain mesh study', ...
        'Study 2: Plot finite-strain mesh study', ...
        'Study 3: Run/load length-scale study', ...
        'Study 3: Plot length-scale study', ...
        'Study 4: Run/load nonlinear field study', ...
        'Study 4: Plot nonlinear fields', ...
        'Study 5: Run/load gradient sensitivity study', ...
        'Study 5: Plot gradient sensitivity', ...
        'Study 6: Run/load higher-order BC study', ...
        'Study 6: Plot higher-order BC comparison', ...
        'Study 7: Run/load nonlinear energy-partition study', ...
        'Study 7: Plot energy partition', ...
        'Show project guide');
    if choice == 0
        result = [];
        return;
    end
    modes = {'benchmark','benchmarkplots','stage2','stage2plots', ...
             'stage3','stage3plots','stage4','stage4plots', ...
             'stage5','stage5plots','stage6','stage6plots', ...
             'stage7','stage7plots','guide'};
    mode = modes{choice};
end

mode = lower(char(mode));
benchmarkFile = fullfile(resultsFolder, 'benchmark2022_results.mat');
stage2File = fullfile(resultsFolder, 'stage2_mesh_study.mat');
stage3File = fullfile(resultsFolder, 'stage3_length_scale_study.mat');
stage4File = fullfile(resultsFolder, 'stage4_nonlinear_field_study.mat');
stage5File = fullfile(resultsFolder, 'stage5_gradient_sensitivity_study.mat');
stage6File = fullfile(resultsFolder, 'stage6_higher_order_bc_study.mat');
stage7File = fullfile(resultsFolder, 'stage7_energy_partition_study.mat');

switch mode
    case {'benchmark','study1'}
        bench2022 = getBenchmark(benchmarkFile);
        assignin('base','bench2022',bench2022);
        result = bench2022;
        fprintf('Study 1 available in workspace as bench2022.\n');

    case {'benchmarkplots','study1plots','plot1'}
        bench2022 = getBenchmark(benchmarkFile);
        assignin('base','bench2022',bench2022);
        figs = plotBenchmarkProfilesSCI2022( ...
            'ellList',[0.1 0.2 0.3],'NeY',16,'loadScale',1e-5);
        figConv = plotBenchmarkConvergenceSCI2022(bench2022);
        result = struct('profiles',figs.profiles, ...
                        'profileErrors',figs.errors, ...
                        'convergence',figConv);
        fprintf(['Study 1 figures created. Save manually as:\n' ...
                 '  Fig01_BenchmarkProfiles.eps\n' ...
                 '  Fig02_BenchmarkConvergence.eps\n']);

    case {'stage2','study2'}
        study2full = getStage2(stage2File);
        assignin('base','study2full',study2full);
        result = study2full;
        fprintf('Study 2 available in workspace as study2full.\n');

    case {'stage2plots','study2plots','plot2'}
        study2full = getStage2(stage2File);
        assignin('base','study2full',study2full);
        result = plot2FiniteStrainMeshStudy(study2full);
        fprintf(['Study 2 figures created. Save manually as:\n' ...
                 '  Fig03_FiniteStrainMeshErrors.eps\n' ...
                 '  Fig03_Optional_FiniteStrainMeshResponses.eps\n']);

    case {'stage3','study3'}
        study3 = getStage3(stage3File);
        assignin('base','study3',study3);
        result = study3;
        fprintf('Study 3 available in workspace as study3.\n');

    case {'stage3plots','study3plots','plot3'}
        study3 = getStage3(stage3File);
        assignin('base','study3',study3);
        result = plot3LengthScaleStudy(study3);
        fprintf(['Study 3 figures created. Save manually as:\n' ...
                 '  Fig04_LengthScaleEffect.eps\n' ...
                 '  Fig04_Optional_LengthScaleResponses.eps\n']);

    case {'stage4','study4'}
        study4 = getStage4(stage4File);
        assignin('base','study4',study4);
        result = study4;
        fprintf('Study 4 available in workspace as study4.\n');

    case {'stage4plots','study4plots','plot4'}
        study4 = getStage4(stage4File);
        assignin('base','study4',study4);
        result = plot4NonlinearLoadStudy(study4);
        fprintf(['Study 4 figures created. Main paper figure:\n' ...
                 '  Fig05_FiniteStrainFields.eps\n']);

    case {'stage5','study5'}
        study5 = getStage5(stage5File);
        assignin('base','study5',study5);
        result = study5;
        fprintf('Study 5 available in workspace as study5.\n');

    case {'stage5plots','study5plots','plot5'}
        study5 = getStage5(stage5File);
        assignin('base','study5',study5);
        result = plot5GradientSensitivityHeatmap(study5);
        fprintf(['Study 5 figure created. Main paper figure:\n' ...
                 '  Fig06_GradientSensitivity.eps\n']);

    case {'stage6','study6'}
        study6 = getStage6(stage6File);
        assignin('base','study6',study6);
        result = study6;
        fprintf('Study 6 available in workspace as study6.\n');

    case {'stage6plots','study6plots','plot6'}
        study6 = getStage6(stage6File);
        assignin('base','study6',study6);
        result = plot6HigherOrderBCStudy(study6);
        fprintf(['Study 6 figure created. Main paper figure:\n' ...
                 '  Fig07_HigherOrderBCComparison.eps\n']);

    case {'stage7','study7'}
        study7Energy = getStage7(stage7File, stage4File);
        assignin('base','study7Energy',study7Energy);
        result = study7Energy;
        fprintf('Study 7 available in workspace as study7Energy.\n');

    case {'stage7plots','study7plots','plot7'}
        study7Energy = getStage7(stage7File, stage4File);
        assignin('base','study7Energy',study7Energy);
        result = plot7EnergyPartitionStudy(study7Energy);
        fprintf(['Study 7 figure created. Main paper figure:\n' ...
                 '  Fig08_EnergyPartition.eps\n']);

    case {'guide','help'}
        guideFile = fullfile(projectRoot,'PROJECT_RUN_GUIDE.md');
        if exist(guideFile,'file') == 2
            open(guideFile);
        else
            fprintf('Guide file not found: %s\n',guideFile);
        end
        result = [];

    otherwise
        error(['runProject:unknown mode. Use benchmark, benchmarkplots, ' ...
               'stage2, stage2plots, stage3, stage3plots, stage4, ' ...
               'stage4plots, stage5, stage5plots, stage6, stage6plots, ' ...
               'stage7, stage7plots, or guide.']);
end

fprintf('Project results folder: %s\n',resultsFolder);

end

function resultsFolder = projectResultsFolder(projectRoot)
resultsFolder = fullfile(projectRoot,'results');
if exist(resultsFolder,'dir') ~= 7
    [ok,~] = mkdir(resultsFolder);
else
    ok = true;
end
if ok
    testFile = fullfile(resultsFolder,'.write_test');
    fid = fopen(testFile,'w');
    if fid == -1
        ok = false;
    else
        fclose(fid);
        delete(testFile);
    end
end
if ~ok
    resultsFolder = fullfile(tempdir,'BFSMindlinResults');
    if exist(resultsFolder,'dir') ~= 7
        mkdir(resultsFolder);
    end
end
end

function bench2022 = getBenchmark(benchmarkFile)
if exist(benchmarkFile,'file') == 2
    S = load(benchmarkFile,'bench2022');
    bench2022 = S.bench2022;
    fprintf('Loaded saved Study 1 benchmark results.\n');
    return;
end
legacyFile = fullfile(tempdir,'BFS2022Results','benchmark2022_results.mat');
if exist(legacyFile,'file') == 2
    S = load(legacyFile,'bench2022');
    bench2022 = S.bench2022;
    save(benchmarkFile,'bench2022');
    fprintf('Imported previously saved Study 1 benchmark results.\n');
    return;
end
fprintf('Running Study 1 exact 2022 benchmark. This may take time.\n');
benchCase1 = validate2022BenchmarkExact( ...
    'cases',{'case1'},'ellList',[0.1 0.2 0.3], ...
    'NeYList',[4 8 16],'verbose',true);
benchCase2 = validate2022BenchmarkExact( ...
    'cases',{'case2'},'ellList',[0.1 0.2 0.3], ...
    'NeYList',[4 8 16],'verbose',true);
bench2022 = struct('case1',benchCase1,'case2',benchCase2);
save(benchmarkFile,'bench2022');
fprintf('Saved Study 1 benchmark results.\n');
end

function study2full = getStage2(stage2File)
if exist(stage2File,'file') == 2
    S = load(stage2File,'study2full');
    study2full = S.study2full;
    fprintf('Loaded saved Study 2 mesh-study results.\n');
    return;
end
if evalin('base','exist(''study2full'',''var'')') == 1
    study2full = evalin('base','study2full');
    save(stage2File,'study2full');
    fprintf('Saved existing workspace Study 2 results.\n');
    return;
end
fprintf('Running Study 2 finite-strain mesh study. This may take time.\n');
study2full = runFiniteStrainMeshStudy( ...
    'NeYList',[2 4 8 16],'ellList',[0 0.1],'verbose',true);
save(stage2File,'study2full');
fprintf('Saved Study 2 mesh-study results.\n');
end

function study3 = getStage3(stage3File)
if exist(stage3File,'file') == 2
    S = load(stage3File,'study3');
    study3 = S.study3;
    fprintf('Loaded saved Study 3 length-scale results.\n');
    return;
end
if evalin('base','exist(''study3'',''var'')') == 1
    study3 = evalin('base','study3');
    save(stage3File,'study3');
    fprintf('Saved existing workspace Study 3 results.\n');
    return;
end
fprintf('Running Study 3 compact length-scale study. This may take time.\n');
study3 = run3LengthScaleStudy;
save(stage3File,'study3');
fprintf('Saved Study 3 length-scale results.\n');
end

function study4 = getStage4(stage4File)
if exist(stage4File,'file') == 2
    S = load(stage4File,'study4');
    study4 = S.study4;
    fprintf('Loaded saved Study 4 nonlinear field results.\n');
    return;
end
if evalin('base','exist(''study4'',''var'')') == 1
    study4 = evalin('base','study4');
    save(stage4File,'study4');
    fprintf('Saved existing workspace Study 4 results.\n');
    return;
end
fprintf('Running Study 4 nonlinear field study. This may take time.\n');
study4 = run4NonlinearLoadStudy;
save(stage4File,'study4');
fprintf('Saved Study 4 nonlinear field results.\n');
end

function study5 = getStage5(stage5File)
if exist(stage5File,'file') == 2
    S = load(stage5File,'study5');
    study5 = S.study5;
    fprintf('Loaded saved Study 5 gradient-sensitivity results.\n');
    return;
end
if evalin('base','exist(''study5'',''var'')') == 1
    study5 = evalin('base','study5');
    save(stage5File,'study5');
    fprintf('Saved existing workspace Study 5 results.\n');
    return;
end
fprintf('Running Study 5 gradient-sensitivity study. This may take time.\n');
study5 = run5GradientSensitivityStudy;
save(stage5File,'study5');
fprintf('Saved Study 5 gradient-sensitivity results.\n');
end

function study6 = getStage6(stage6File)
if exist(stage6File,'file') == 2
    S = load(stage6File,'study6');
    study6 = S.study6;
    fprintf('Loaded saved Study 6 higher-order BC results.\n');
    return;
end
if evalin('base','exist(''study6'',''var'')') == 1
    study6 = evalin('base','study6');
    save(stage6File,'study6');
    fprintf('Saved existing workspace Study 6 results.\n');
    return;
end
fprintf('Running Study 6 higher-order BC study. This may take time.\n');
study6 = run6HigherOrderBCStudy;
save(stage6File,'study6');
fprintf('Saved Study 6 higher-order BC results.\n');
end

function study7Energy = getStage7(stage7File, stage4File)
if exist(stage7File,'file') == 2
    S = load(stage7File,'study7Energy');
    study7Energy = S.study7Energy;
    fprintf('Loaded saved Study 7 energy-partition results.\n');
    return;
end
if evalin('base','exist(''study7Energy'',''var'')') == 1
    study7Energy = evalin('base','study7Energy');
    save(stage7File,'study7Energy');
    fprintf('Saved existing workspace Study 7 energy-partition results.\n');
    return;
end
% Study 7 is a post-processing analysis of the saved nonlinear Study 4
% solution.  It does not repeat a nonlinear solver run.
study4 = getStage4(stage4File);
study7Energy = run7EnergyPartitionStudy(study4);
save(stage7File,'study7Energy');
fprintf('Saved Study 7 energy-partition results.\n');
end
