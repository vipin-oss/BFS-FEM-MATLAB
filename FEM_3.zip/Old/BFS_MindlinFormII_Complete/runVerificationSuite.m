function rep = runVerificationSuite(varargin)
%RUNVERIFICATIONSUITE  Five-level verification suite for the frozen BFS
%                      Mindlin Form-II FE codebase.
%
%   rep = RUNVERIFICATIONSUITE('Name',Value,...)
%
% ----------------------------------------------------------------------
% Verification levels
% ----------------------------------------------------------------------
%   L1 Code verification        : every module loads; interface/dimension
%                                 compatibility; no API mismatch;
%                                 symmetry of K/Kr; partition sizes.
%   L2 Mathematical verification: infinitesimal-strain recovery (GL->eps),
%                                 constitutive recovery (S=C4:E),
%                                 strain-gradient recovery (G->sym(grad^2 u)),
%                                 strong-form patch recovery,
%                                 boundary-condition recovery,
%                                 tangent symmetry (total tangent).
%   L3 2022 benchmark           : delegates to validate2022Benchmark for
%                                 uniaxial, shear, bending; records
%                                 displacement, strain, strain-gradient,
%                                 energy and convergence errors.
%   L4 Numerical verification   : rigid-body modes; patch test (exact
%                                 polynomial fields); mesh independence
%                                 on uniform refinement; Newton
%                                 convergence; FD tangent consistency;
%                                 energy consistency (W = 1/2 D'R_ext);
%                                 symmetry preservation.
%   L5 Regression               : PASS/FAIL summary over all checks.
%
% Options:
%   levels      vector of levels to run            (1:5)
%   verbose     print checks                       (true)
%   NeList      meshes for benchmark                ([2 4 8])
%   FDeps       finite-difference step              (1e-6)
%   tol         pass/fail tolerance                 (1e-8)
%
% Output rep struct:
%   .level(k)   test records: .level .name .pass .val .tol .detail
%   .summary    printable PASS/FAIL table
%   .allPass    logical
%   .nPass,.nFail,.nTests
%   .bench      validate2022Benchmark output (if L3 run)
%
% Uses only frozen Modules 2-14 and validate2022Benchmark.  No frozen
% file is modified.
%
% See also VALIDATE2022BENCHMARK, GENERATEBENCHMARKREPORT.

ip = inputParser;
addParameter(ip,'levels',1:5,@isnumeric);
addParameter(ip,'verbose',true,@(x) islogical(x)||x==0||x==1);
addParameter(ip,'NeList',[2 4 8],@isnumeric);
addParameter(ip,'FDeps',1e-6,@(x) isnumeric(x)&&isscalar(x)&&x>0);
addParameter(ip,'tol',1e-8,@(x) isnumeric(x)&&isscalar(x)&&x>0);
parse(ip,varargin{:});
o = ip.Results;

levels=o.levels; verbose=o.verbose; tol0=o.tol;
tests = struct('level',{},'name',{},'pass',{},'val',{},'tol',{},'detail',{});

    function rec(r)
        tests(end+1,1)=r;
        if verbose
            tag='FAIL'; if r.pass; tag='PASS'; end
            fprintf('  [%s] L%d %-40s  val=%.2e  tol=%.0e  %s\n',...
                tag,r.level,r.name,r.val,r.tol,r.detail);
        end
    end
    function chk(level,name,val,tol,detail)
        pass=(val<=tol);
        rec(struct('level',level,'name',name,'pass',pass,'val',double(val),...
            'tol',tol,'detail',detail));
    end
    function bool(level,name,c,detail)
        rec(struct('level',level,'name',name,'pass',logical(c),...
            'val',double(~logical(c)),'tol',0,'detail',detail));
    end

E=100; nu=0.3; L1=1; L2=1; Ne1=2; Ne2=2;
mat = buildMaterialStruct(E,nu,0,0,0,0,0,0); mat.thickness=1;
gauss = gaussQuadrature(3);
if verbose
    fprintf('=== Verification suite (levels %s) ===\n',mat2str(levels));
end

% ======================================================================
% LEVEL 1 : code / interface / dimension checks.
% ======================================================================
if ismember(1,levels)
    if verbose; fprintf('--- L1 code / API / dimensions ---\n'); end
    prob0 = initializeProblem('L1',L1,'L2',L2,'Ne1',Ne1,'Ne2',Ne2,...
        'E',E,'nu',nu,'mode','linear','nSteps',1,'verbose',false);
    nN=prob0.mesh.nNodes; nE=prob0.mesh.nElem; nDOF=prob0.dof.nDOF;

    bool(1,'buildMaterialStruct loads',isstruct(mat)&&isfield(mat,'C4'),'mat.C4 present');
    bool(1,'gaussQuadrature loads', isstruct(gauss)&&isfield(gauss,'xi1d'),'gauss.xi1d present');
    bool(1,'initializeProblem returns mesh',isstruct(prob0.mesh)&&isfield(prob0.mesh,'X'),'mesh.X present');
    bool(1,'nNodes=(Ne1+1)(Ne2+1)',nN==(Ne1+1)*(Ne2+1),'node count');
    bool(1,'nElem=Ne1*Ne2',nE==Ne1*Ne2,'elem count');
    bool(1,'nDOF=8*nNodes',nDOF==8*nN,'DOF count');
    bool(1,'free+ess=nDOF',length(prob0.dof.freeDOF)+length(prob0.dof.essDOF)==nDOF,'partition');
    bool(1,'buildDOFMap ID size',isequal(size(prob0.dof.ID),[4,2,nN]),'ID 4x2xnN');

    K = assembleGlobalTangent(prob0.D0,mat,prob0.mesh,prob0.dof,prob0.gauss);
    R = assembleGlobalResidual(prob0.D0,mat,prob0.mesh,prob0.dof,prob0.gauss);
    bool(1,'assembleGlobalTangent size',isequal(size(K),[nDOF,nDOF]),'K size');
    bool(1,'assembleGlobalResidual size',isequal(size(R(:)),[nDOF,1]),'R size');
    chk (1,'K symmetric',norm(K-K.','fro')/max(norm(K,'fro'),1e-12),1e-12,'K=K^T');
    bool(1,'gauss nGP=9',gauss.nGP==9,'3x3 rule');
    bool(1,'C4 2x2x2x2',isequal(size(mat.C4),[2,2,2,2]),'4th order');
    bool(1,'D6 2^6',isequal(size(mat.D6),[2,2,2,2,2,2]),'6th order');

    sol0 = runAnalysis(prob0);
    bool(1,'runAnalysis returns D',isequal(size(sol0.D),[nDOF,length(sol0.lambda)]),'sol.D size');
    bool(1,'runAnalysis returns Rxn',isequal(size(sol0.Rxn),[nDOF,length(sol0.lambda)]),'sol.Rxn size');
    pp0 = postProcessResults(sol0);
    bool(1,'postProcess nodal size',isequal(size(pp0.nodal.u1),[nN,1]),'nodal fields nNx1');
    bool(1,'postProcess G size',isequal(size(pp0.nodal.G),[nN,2,2,2]),'nodal.G nNx2x2x2');
end

% ======================================================================
% LEVEL 2 : mathematical verification.
% ======================================================================
if ismember(2,levels)
    if verbose; fprintf('--- L2 mathematical verification ---\n'); end
    prob1 = initializeProblem('L1',L1,'L2',L2,'Ne1',Ne1,'Ne2',Ne2,...
        'E',E,'nu',nu,'mode','linear','nSteps',1,'verbose',false);
    nDOF=prob1.dof.nDOF; D0=prob1.D0;
    K = assembleGlobalTangent(D0,mat,prob1.mesh,prob1.dof,prob1.gauss);
    R = assembleGlobalResidual(D0,mat,prob1.mesh,prob1.dof,prob1.gauss);
    % Rigid-body invariance.
    t=zeros(nDOF,1);
    for nd=1:prob1.mesh.nNodes
        t(prob1.dof.ID(1,1,nd))=0.5;
        t(prob1.dof.ID(1,2,nd))=-0.3;
    end
    chk(2,'rigid-body K*t=0',norm(K*t),1e-8,'K null space');
    chk(2,'rigid-body R=0',  norm(R),  1e-8,'R(t)=0');

    % Infinitesimal strain recovery.
    gu=1e-6*[1 2;3 4];
    kin=computeDeformationGradient(gu); F=kin.F;
    Es=computeGreenLagrangeStrain(F); E=Es.E;
    Elin=0.5*(gu+gu');
    chk(2,'GL -> lin strain',norm(E-Elin,'fro'),1e-9,'GL=sym(gradU) at small gu');

    % Strain-gradient recovery: for linear u = A*X, g2=0 => G=0; for u =
    % quadratic u1 = alp*X1^2, G_{111}=2*alp (no nonlinear terms when u,1 is
    % small so the nonlinear products vanish).
    alp=1e-6;
    gu_g=zeros(2,2); gu_g(1,1)=2*alp*0.5; % X1=0.5
    ggu=zeros(2,2,2); ggu(1,1,1)=2*alp;
    G = computeStrainGradient(gu_g,ggu);
    chk(2,'G recovery (G111=2alp)',abs(G(1,1,1)-2*alp),1e-12,'G111 exact');

    % Constitutive recovery.
    Et=rand(2,2)*0.001; Et=0.5*(Et+Et');
    S=computeSecondPiolaStress(mat.C4,Et);
    Str=mat.lambda*trace(Et)*eye(2)+2*mat.mu*Et;
    chk(2,'S=lam tr E I + 2mu E',norm(S-Str,'fro'),1e-12,'isotropic Hooke');

    % Double-stress isotropy (zero G -> zero Sigma).
    Sig = computeDoubleStress(mat.D6,zeros(2,2,2));
    chk(2,'Sigma(D6:0)=0',norm(Sig(:)),1e-12,'zero Sigma for zero G');

    % Boundary-condition recovery: Kr symmetric, essential DOFs exact.
    [Kr,Rr,fr,~]=applyDirichletBC(K,R,D0,prob1.dof,0);
    chk(2,'Kr symmetric',norm(Kr-Kr.','fro')/max(norm(Kr,'fro'),1e-12),1e-10,'reduced tangent');
    bool(2,'fr length',length(fr)==length(prob1.dof.essDOF),'essential increment size');

    % Total-tangent FD consistency against residual (already checked in
    % Module 10 self-tests but re-checked here as L2).
    ep=o.FDeps; v=randn(nDOF,1); v=v/norm(v);
    Rp=assembleGlobalResidual(D0+ep*v,mat,prob1.mesh,prob1.dof,prob1.gauss);
    Rm=assembleGlobalResidual(D0-ep*v,mat,prob1.mesh,prob1.dof,prob1.gauss);
    chk(2,'K=DR/DD (FD)',norm(K*v-(Rp-Rm)/(2*ep))/max(norm((Rp-Rm)/(2*ep)),1),1e-4,'tangent FD');

    sol1 = runAnalysis(prob1);
    chk(2,'linear residual',sol1.U.Rnorm,1e-7,'linear solve ||R||');
    bool(2,'W>0',sol1.U.Wtotal>0,'energy positive');
end

% ======================================================================
% LEVEL 3 : 2022 benchmark.
% ======================================================================
bench=[];
if ismember(3,levels)
    if verbose; fprintf('--- L3 2022 Torabi-Niiranen benchmark ---\n'); end
    bench = validate2022Benchmark('E',E,'nu',nu,'NeList',o.NeList,'tol',tol0,...
        'verbose',verbose);
    for ci=1:length(bench.cases)
        r=bench.cases{ci};
        chk(3,sprintf('bench/%s L2',r.name),r.L2err(end),tol0,'final-mesh L2');
        chk(3,sprintf('bench/%s H1',r.name),r.H1err(end),tol0,'final-mesh H1');
        chk(3,sprintf('bench/%s E',r.name), r.Eerr(end),1e-6, 'final-mesh strain');
        chk(3,sprintf('bench/%s energy',r.name),r.Enerr(end),1e-6,'energy rel err');
        % G error: for a_i=0 and homogeneous/bending cases G may not be
        % zero (G != 0 in bending); do not threshold, just record.
    end
end

% ======================================================================
% LEVEL 4 : numerical verification.
% ======================================================================
if ismember(4,levels)
    if verbose; fprintf('--- L4 numerical verification ---\n'); end
    % Two-step nonlinear (0->0.5->1) on small displacement.
    prob4 = initializeProblem('Ne1',2,'Ne2',2,'E',E,'nu',nu,...
        'mode','nonlinear','adaptive',false,'nSteps',2,...
        'verbose',false,...
        'bcSpecs',{struct('edge','x0','comp',1,'dofType','all','value',0),...
                   struct('edge','x0','comp',2,'dofType','all','value',0),...
                   struct('edge','x1','comp',1,'dofType','u','value',0.01)});
    sol4 = runAnalysis(prob4);
    bool(4,'nonlinear converged',sol4.finalConv,'2-step N-R');
    chk (4,'nonlinear residual',sol4.U.Rnorm,1e-4,'||R|| final');
    bool(4,'lambda monotonic',all(diff(sol4.lambda)>-1e-14),'lambda non-decreasing');

    % Patch test on 1x1, 2x2, 4x4: all three analytic cases must have
    % L2 error < 1e-10.
    cases={'uniaxial','shear','bending'};
    meshes=[1 2 4];
    for cc=1:length(cases)
        for mm=1:length(meshes)
            Ne=meshes(mm);
            pp4 = initializeProblem('Ne1',Ne,'Ne2',Ne,'E',E,'nu',nu,...
                'mode','linear','nSteps',1,'verbose',false,...
                'bcSpecs',local_patchBCs(cases{cc},E,nu));
            s4 = runAnalysis(pp4);
            % Compute L2 error by a single Gauss-loop.
            L2e = local_L2err(pp4.mesh,pp4.dof,s4.D(:,end),gauss,cases{cc},E,nu);
            chk(4,sprintf('patch/%s/Ne=%d',cases{cc},Ne),L2e,1e-9,'patch test L2');
        end
    end

    % Mesh independence: doubling mesh should not change W by more than
    % 1e-9 for the exact patch cases (use uniaxial).
    Ws=zeros(1,3);
    for mm=1:3
        Ne=meshes(mm);
        ppw = initializeProblem('Ne1',Ne,'Ne2',Ne,'E',E,'nu',nu,...
            'mode','linear','nSteps',1,'verbose',false,...
            'bcSpecs',local_patchBCs('uniaxial',E,nu));
        sw = runAnalysis(ppw); Ws(mm)=sw.U.Wtotal;
    end
    chk(4,'mesh-indep W',max(abs(Ws-Ws(end)))/abs(Ws(end)),1e-9,'W mesh independence');

    % Energy consistency: W = 0.5*Rxn'*D_ess (linear).
    ppw = initializeProblem('Ne1',2,'Ne2',2,'E',E,'nu',nu,'mode','linear',...
        'nSteps',1,'verbose',false,...
        'bcSpecs',local_patchBCs('uniaxial',E,nu));
    sw = runAnalysis(ppw);
    Work = 0.5*abs(sw.Rxn(:,end).'*sw.D(:,end));
    chk(4,'W=1/2 Rxn·D',abs(sw.U.Wtotal-Work)/abs(Work+eps),1e-6,'energy balance');

    % Newton convergence: solver must finish within kMax iters (Module 12 default).
    bool(4,'nIter within kMax',all(sw.nIter<=sw.solverOpts.kMax | isnan(sw.nIter)),'Newton iters bounded');

    % Reaction-free DOFs: Rxn must vanish on free DOFs.
    chk(4,'Rxn(free)=0',norm(sw.Rxn(sw.dof.freeDOF,end)),1e-8,'free-DOF reactions');

    % Symmetry preservation: symmetric problem (uniaxial) gives symmetric u2
    % field.  Use nodal u2: for uniaxial under x0-clamped u2_0 = -nu*eps*X2,
    % u2 must be antisymmetric about X2=L2/2? Actually u2 is linear in X2,
    % so check u2(0,X2)+u2(L1,X2) + nu*eps*X2 = 0 exactly.
    ppSym = postProcessResults(sw);
    X1max=max(ppSym.X(:,1));
    x0n = abs(ppSym.X(:,1)-0)<1e-10;
    x1n = abs(ppSym.X(:,1)-X1max)<1e-10;
    asym = max(ppSym.nodal.u2(x0n)) - min(ppSym.nodal.u2(x1n));
    chk(4,'symmetry u2(x0)+u2(x1)',abs(asym-1*0),1e-10,'u2 symmetry (linear contr.)');
end

% ======================================================================
% LEVEL 5 : regression summary.
% ======================================================================
if verbose && ismember(5,levels); fprintf('--- L5 regression summary ---\n'); end
nTests=length(tests); nFail=sum(~[tests.pass]); allPass=(nFail==0);

sm = sprintf('%-4s  %-40s  %-5s  %-10s  %-10s  %s\n',...
    'Lvl','Test','Pass','Value','Tol','Detail');
sm=[sm repmat('-',1,105) sprintf('\n')];
for k=1:nTests
    t=tests(k); tag='FAIL'; if t.pass; tag='PASS'; end
    sm=[sm sprintf('%-4d  %-40s  %-5s  %-10.2e  %-10.0e  %s\n',...
        t.level,t.name,tag,t.val,t.tol,t.detail)]; %#ok<AGROW>
end
sm=[sm sprintf('\n%d/%d tests passed. allPass=%d\n',nTests-nFail,nTests,double(allPass))];
if verbose; fprintf('%s',sm); end

rep=struct('level',tests,'summary',sm,'allPass',allPass,...
    'nPass',nTests-nFail,'nFail',nFail,'nTests',nTests,'bench',bench);
end

% =========================================================================
% LOCAL SUBFUNCTIONS (non-nested)
% =========================================================================
function bc = local_patchBCs(cname,E,nu)
lam=E*nu/((1+nu)*(1-2*nu)); %#ok<NASGU>
switch cname
    case 'uniaxial'
        bc = {struct('edge','x0','comp',1,'dofType','all','value',0),...
              struct('edge','x0','comp',2,'dofType','all','value',0),...
              struct('edge','x1','comp',1,'dofType','u','value',0.001),...
              struct('edge','x1','comp',2,'dofType','u','value',@(X1,X2)-nu*0.001*X2)};
    case 'shear'
        bc = {struct('edge','x0','comp',1,'dofType','all','value',0),...
              struct('edge','x0','comp',2,'dofType','all','value',0),...
              struct('edge','x1','comp',1,'dofType','u','value',@(X1,X2)0.001*X2),...
              struct('edge','x1','comp',2,'dofType','u','value',0)};
    case 'bending'
        kap=0.001;
        bc = {struct('edge','x0','comp',1,'dofType','all','value',0),...
              struct('edge','x0','comp',2,'dofType','all','value',0),...
              struct('edge','x1','comp',1,'dofType','u','value',@(X1,X2)-kap*1*X2),...
              struct('edge','x1','comp',2,'dofType','u','value',@(X1,X2)0.5*kap*(1+nu*X2.^2))};
end
end

function L2e = local_L2err(mesh,dof,D,gauss,cname,E,nu)
xi1d=gauss.xi1d; wi1d=gauss.w1d; ng=gauss.ng;
num=0; den=0;
for e=1:mesh.nElem
    eg=mesh.elemGeom(e); de=D(dof.elemDOF(e,:));
    h1=eg.h1; h2=eg.h2; detJ=h1*h2/4; xi1=2/h1; xi2=2/h2;
    for i=1:ng,for j=1:ng
        xp=xi1d(i); ep=xi1d(j); w=wi1d(i)*wi1d(j);
        dN=bfsShapeFunctionDerivatives(xp,ep,h1,h2);
        u1h=dN.N0(1,1:16)*de(1:16); u2h=dN.N0(2,17:32)*de(17:32);
        X1=eg.x0+(h1/2)*(xp+1); X2=eg.y0+(h2/2)*(ep+1);
        switch cname
            case 'uniaxial'
                u1e=0.001*X1; u2e=-nu*0.001*X2;
            case 'shear'
                u1e=0.001*X2; u2e=0;
            case 'bending'
                kap=0.001;
                u1e=-kap*X1*X2; u2e=0.5*kap*(X1*X1+nu*X2*X2);
        end
        num=num+w*((u1h-u1e)^2+(u2h-u2e)^2)*detJ;
        den=den+w*(u1e*u1e+u2e*u2e)*detJ;
    end;end
end
L2e=sqrt(num/max(den,eps));
end
