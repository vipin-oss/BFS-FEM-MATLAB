function [D, Rxn, hist, stepOK, stepInfo] = solveLoadStep(D0, mat, mesh, dof, gauss, Fext, lambda, opts)
%SOLVELOADSTEP Solve one fixed-load-factor Newton--Raphson step.
%
%   [D,Rxn,hist,stepOK,stepInfo] = solveLoadStep(...)
%
% Frozen equilibrium at load factor lambda:
%   R_int(D) - lambda*F_ext = 0.
%
% Essential DOFs are imposed strongly at lambda*dof.essVals.  Therefore
% Newton convergence is assessed on the reduced/free residual only;
% residual entries at essential DOFs are reactions and must not be used
% as a free-equilibrium convergence norm.

% ---------------------------------------------------------------------
% Default options.
% ---------------------------------------------------------------------
if nargin < 8 || isempty(opts)
    opts = struct();
end

opts = setDefault(opts, 'kMax', 20);
opts = setDefault(opts, 'tolR', 1e-8);
opts = setDefault(opts, 'tolD', 1e-8);
opts = setDefault(opts, 'tolE', 1e-8);
opts = setDefault(opts, 'tolR_abs', 1e-12);
opts = setDefault(opts, 'tolD_abs', 1e-12);
opts = setDefault(opts, 'tolE_abs', 1e-12);
opts = setDefault(opts, 'divergenceTol', 1e6);
opts = setDefault(opts, 'linsolver', 'backslash');
opts = setDefault(opts, 'verbose', false);

% ---------------------------------------------------------------------
% Validation.
% ---------------------------------------------------------------------
D0 = D0(:);
Fext = Fext(:);
nDOF = dof.nDOF;
free = dof.freeDOF(:);
ess = dof.essDOF(:);
nF = numel(free);

assert(isnumeric(lambda) && isreal(lambda) && isfinite(lambda) && isscalar(lambda), ...
    'solveLoadStep:lambda must be a real finite scalar.');
assert(isnumeric(D0) && isreal(D0) && all(isfinite(D0)) && numel(D0) == nDOF, ...
    'solveLoadStep:D0 must be a real finite nDOF-vector.');
assert(isnumeric(Fext) && isreal(Fext) && all(isfinite(Fext)) && numel(Fext) == nDOF, ...
    'solveLoadStep:Fext must be a real finite nDOF-vector.');
assert(isPositiveInteger(opts.kMax), ...
    'solveLoadStep:kMax must be a positive integer.');

cvOpts = struct('tolR', opts.tolR, ...
                'tolD', opts.tolD, ...
                'tolE', opts.tolE, ...
                'tolR_abs', opts.tolR_abs, ...
                'tolD_abs', opts.tolD_abs, ...
                'tolE_abs', opts.tolE_abs, ...
                'divergenceTol', opts.divergenceTol);

% ---------------------------------------------------------------------
% Initial current state at this load factor.
% ---------------------------------------------------------------------
D = updateEssentialDOFs(D0, dof, lambda);

[R, K, Kr, Rr] = assembleReducedSystem(D, mat, mesh, dof, gauss, Fext, lambda);

% Reactions at the constrained DOFs are retained separately.  The free
% residual Rr is the only equilibrium residual used by Newton convergence.
if nF == 0
    Rxn = reactionVector(R, dof);
    hist = initialiseHistory(1);
    hist.k(1) = 0;
    % There is no reduced/free equilibrium system when every DOF is essential.
    hist.nR(1) = 0; hist.nD(1) = 0; hist.nE(1) = 0;
    hist.nR0(1) = 0; hist.nD0(1) = 0; hist.nE0(1) = 0;
    hist.etaR(1) = 0; hist.etaD(1) = 0; hist.etaE(1) = 0;
    stepOK = true;
    stepInfo = struct('nIter', 0, 'converged', true, 'diverged', false, ...
                      'reason', 'No free DOFs: prescribed state accepted.', ...
                      'lambda', lambda);
    return;
end

% First correction at the initial residual.
dDfree = solveReducedSystem(Kr, -Rr, opts.linsolver);
Rr0 = Rr;
dDfree0 = dDfree;

[conv, norms, diagC] = convergenceCheck(Rr, dDfree, dDfree0, Rr0, cvOpts);
hist = initialiseHistory(opts.kMax + 1);
hist = storeNormHistory(hist, 1, 0, norms);

if opts.verbose
    printIteration(lambda, 0, norms);
end

% A zero free residual at the initial state is already equilibrated.
if conv == 1
    Rxn = reactionVector(R, dof);
    hist = trimHistory(hist, 1);
    stepOK = true;
    stepInfo = struct('nIter', 0, 'converged', true, 'diverged', false, ...
                      'reason', diagC.reason, 'lambda', lambda);
    return;
elseif conv == -1
    Rxn = zeros(nDOF, 1);
    hist = trimHistory(hist, 1);
    stepOK = false;
    stepInfo = struct('nIter', 0, 'converged', false, 'diverged', true, ...
                      'reason', diagC.reason, 'lambda', lambda);
    return;
end

% ---------------------------------------------------------------------
% Newton iterations.
% ---------------------------------------------------------------------
converged = false;
diverged = false;
reason = '';
Rcurrent = R;
Kcurrent = K;
rec = 1;

for k = 1:opts.kMax
    % Essential values are overwritten exactly by updateEssentialDOFs;
    % only the solved free increment is added to the current state.
    D = updateEssentialDOFs(D, dof, lambda, dDfree);

    [Rcurrent, Kcurrent, Kr, Rr] = ...
        assembleReducedSystem(D, mat, mesh, dof, gauss, Fext, lambda);

    % Compute the next correction from the current free residual.
    dDnext = solveReducedSystem(Kr, -Rr, opts.linsolver);

    [conv, norms, diagC] = convergenceCheck(Rr, dDnext, dDfree0, Rr0, cvOpts);

    rec = rec + 1;
    hist = storeNormHistory(hist, rec, k, norms);

    if opts.verbose
        printIteration(lambda, k, norms);
    end

    if conv == 1
        converged = true;
        reason = diagC.reason;
        break;
    elseif conv == -1
        diverged = true;
        reason = diagC.reason;
        break;
    end

    dDfree = dDnext;
end

hist = trimHistory(hist, rec);

if converged
    Rxn = reactionVector(Rcurrent, dof);
    stepOK = true;
    stepInfo = struct('nIter', k, 'converged', true, 'diverged', false, ...
                      'reason', reason, 'lambda', lambda);
elseif diverged
    Rxn = zeros(nDOF, 1);
    stepOK = false;
    stepInfo = struct('nIter', k, 'converged', false, 'diverged', true, ...
                      'reason', reason, 'lambda', lambda);
else
    Rxn = zeros(nDOF, 1);
    stepOK = false;
    stepInfo = struct('nIter', opts.kMax, 'converged', false, 'diverged', false, ...
                      'reason', sprintf('Reached kMax=%d without convergence.', opts.kMax), ...
                      'lambda', lambda);
end

end

% =====================================================================
% Local helpers.
% =====================================================================
function [R, K, Kr, Rr] = assembleReducedSystem(D, mat, mesh, dof, gauss, Fext, lambda)

Rint = assembleGlobalResidual(D, mat, mesh, dof, gauss);
R = Rint - lambda*Fext;
K = assembleGlobalTangent(D, mat, mesh, dof, gauss);

% applyDirichletBC supplies the frozen strong-Dirichlet reduced system.
% D already contains the current lambda-scaled essential values.
[Kr, Rr] = applyDirichletBC(K, R, D, dof, lambda);

end

function Rxn = reactionVector(R, dof)

% For R=R_int-lambda*Fext at an equilibrated state, constrained entries
% are the support reactions; free entries are zero by convergence.
Rxn = zeros(numel(R), 1);
Rxn(dof.essDOF) = R(dof.essDOF);

end

function dDfree = solveReducedSystem(Kr, rhs, method)

switch lower(char(method))
    case {'backslash', 'cg', 'symmlq'}
        % The frozen implementation uses sparse direct backslash.
        dDfree = Kr \ rhs;
    otherwise
        error('solveLoadStep:unknown linear solver "%s".', char(method));
end

end

function hist = initialiseHistory(n)

hist = struct('k', zeros(n, 1), ...
              'nR', zeros(n, 1), 'nD', zeros(n, 1), 'nE', zeros(n, 1), ...
              'nR0', zeros(n, 1), 'nD0', zeros(n, 1), 'nE0', zeros(n, 1), ...
              'etaR', zeros(n, 1), 'etaD', zeros(n, 1), 'etaE', zeros(n, 1));

end

function hist = storeNormHistory(hist, rec, k, norms)

hist.k(rec) = k;
hist.nR(rec) = norms.nR;
hist.nD(rec) = norms.nD;
hist.nE(rec) = norms.nE;
hist.nR0(rec) = norms.nR0;
hist.nD0(rec) = norms.nD0;
hist.nE0(rec) = norms.nE0;
hist.etaR(rec) = norms.etaR;
hist.etaD(rec) = norms.etaD;
hist.etaE(rec) = norms.etaE;

end

function hist = storeHistory(hist, rec, k, dD, dD0, R, R0, cvOpts)

[~, norms] = convergenceCheck(R, dD, dD0, R0, cvOpts);
hist = storeNormHistory(hist, rec, k, norms);

end

function hist = trimHistory(hist, nUsed)

fields = fieldnames(hist);
for i = 1:numel(fields)
    hist.(fields{i}) = hist.(fields{i})(1:nUsed);
end

end

function printIteration(lambda, k, norms)

fprintf(['  [solveLoadStep] lambda=% .4e  k=%2d  ||R_f||=% .3e  ' ...
         '||dD_f||=% .3e  |dD_f''R_f|=% .3e\n'], ...
    lambda, k, norms.nR, norms.nD, norms.nE);

end

function opts = setDefault(opts, fieldName, defaultValue)

if ~isfield(opts, fieldName) || isempty(opts.(fieldName))
    opts.(fieldName) = defaultValue;
end

end

function tf = isFiniteScalar(x)
tf = isnumeric(x) && isreal(x) && isfinite(x) && isscalar(x);
end

function tf = isPositiveInteger(x)
tf = isFiniteScalar(x) && x >= 1 && x == round(x);
end
