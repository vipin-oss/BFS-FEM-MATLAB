function [q, D, Rxn, hist, stepOK, stepInfo] = solveLoadStep2022( ...
    q0, constraints, mat, mesh, dof, gauss, Fext, lambda, opts)
%SOLVELOADSTEP2022 Newton step with periodic-MPC benchmark constraints.
%
% Uses the benchmark transformation D = T*q + lambda*Dbar and condenses
% the unchanged frozen full residual/tangent as r_q=T'*R and K_q=T'*K*T.

if nargin < 9 || isempty(opts)
    opts = struct();
end
opts = defaultOpt(opts, 'kMax', 20);
opts = defaultOpt(opts, 'tolR', 1e-8);
opts = defaultOpt(opts, 'tolD', 1e-8);
opts = defaultOpt(opts, 'tolE', 1e-8);
opts = defaultOpt(opts, 'tolR_abs', 1e-12);
opts = defaultOpt(opts, 'tolD_abs', 1e-12);
opts = defaultOpt(opts, 'tolE_abs', 1e-12);
opts = defaultOpt(opts, 'divergenceTol', 1e6);
opts = defaultOpt(opts, 'verbose', false);

T = constraints.T;
Dbar = constraints.Dbar;
q = q0(:);
assert(size(T, 1) == dof.nDOF && numel(Dbar) == dof.nDOF, ...
    'solveLoadStep2022:constraint dimensions are incompatible with dof.');
assert(numel(q) == size(T, 2), ...
    'solveLoadStep2022:q0 length mismatch.');

cvOpts = struct('tolR', opts.tolR, 'tolD', opts.tolD, 'tolE', opts.tolE, ...
                'tolR_abs', opts.tolR_abs, 'tolD_abs', opts.tolD_abs, ...
                'tolE_abs', opts.tolE_abs, 'divergenceTol', opts.divergenceTol);

[D, R, Kq, Rq] = reducedSystem2022(q, T, Dbar, lambda, mat, mesh, dof, gauss, Fext);
nq = numel(q);

if nq == 0
    Rxn = R;
    hist = blankHistory(1);
    stepOK = true;
    stepInfo = struct('nIter', 0, 'converged', true, 'diverged', false, ...
                      'reason', 'No independent benchmark DOFs.', 'lambda', lambda);
    return;
end

dq = Kq \ (-Rq);
Rq0 = Rq;
dq0 = dq;
[conv, norms, diagC] = convergenceCheck(Rq, dq, dq0, Rq0, cvOpts);
hist = blankHistory(opts.kMax + 1);
hist = putHistory(hist, 1, 0, norms);

if conv == 1
    Rxn = R;
    hist = trimHistory2022(hist, 1);
    stepOK = true;
    stepInfo = struct('nIter', 0, 'converged', true, 'diverged', false, ...
                      'reason', diagC.reason, 'lambda', lambda);
    return;
elseif conv == -1
    Rxn = zeros(dof.nDOF, 1);
    hist = trimHistory2022(hist, 1);
    stepOK = false;
    stepInfo = struct('nIter', 0, 'converged', false, 'diverged', true, ...
                      'reason', diagC.reason, 'lambda', lambda);
    return;
end

converged = false;
diverged = false;
reason = '';
rec = 1;

for k = 1:opts.kMax
    q = q + dq;
    [D, R, Kq, Rq] = reducedSystem2022(q, T, Dbar, lambda, mat, mesh, dof, gauss, Fext);
    dqNext = Kq \ (-Rq);

    [conv, norms, diagC] = convergenceCheck(Rq, dqNext, dq0, Rq0, cvOpts);
    rec = rec + 1;
    hist = putHistory(hist, rec, k, norms);

    if opts.verbose
        fprintf('  [solveLoadStep2022] lambda=%g k=%d ||Rq||=%g ||dq||=%g\n', ...
            lambda, k, norms.nR, norms.nD);
    end

    if conv == 1
        converged = true;
        reason = diagC.reason;
        break;
    elseif conv == -1
        diverged = true;
        reason = diagC.reason;
        break;
    end

    dq = dqNext;
end

hist = trimHistory2022(hist, rec);
if converged
    Rxn = R;
    stepOK = true;
    stepInfo = struct('nIter', k, 'converged', true, 'diverged', false, ...
                      'reason', reason, 'lambda', lambda);
elseif diverged
    Rxn = zeros(dof.nDOF, 1);
    stepOK = false;
    stepInfo = struct('nIter', k, 'converged', false, 'diverged', true, ...
                      'reason', reason, 'lambda', lambda);
else
    Rxn = zeros(dof.nDOF, 1);
    stepOK = false;
    stepInfo = struct('nIter', opts.kMax, 'converged', false, 'diverged', false, ...
        'reason', sprintf('Reached kMax=%d without convergence.', opts.kMax), ...
        'lambda', lambda);
end

end

function [D, R, Kq, Rq] = reducedSystem2022(q, T, Dbar, lambda, mat, mesh, dof, gauss, Fext)
D = T*q + lambda*Dbar;
R = assembleGlobalResidual(D, mat, mesh, dof, gauss) - lambda*Fext;
K = assembleGlobalTangent(D, mat, mesh, dof, gauss);
Rq = T.'*R;
Kq = T.'*K*T;
Kq = 0.5*(Kq + Kq.');
end

function opts = defaultOpt(opts, name, value)
if ~isfield(opts, name) || isempty(opts.(name))
    opts.(name) = value;
end
end

function hist = blankHistory(n)
hist = struct('k', zeros(n, 1), ...
              'nR', zeros(n, 1), 'nD', zeros(n, 1), 'nE', zeros(n, 1), ...
              'nR0', zeros(n, 1), 'nD0', zeros(n, 1), 'nE0', zeros(n, 1), ...
              'etaR', zeros(n, 1), 'etaD', zeros(n, 1), 'etaE', zeros(n, 1));
end

function hist = putHistory(hist, rec, k, norms)
hist.k(rec) = k;
hist.nR(rec) = norms.nR; hist.nD(rec) = norms.nD; hist.nE(rec) = norms.nE;
hist.nR0(rec) = norms.nR0; hist.nD0(rec) = norms.nD0; hist.nE0(rec) = norms.nE0;
hist.etaR(rec) = norms.etaR; hist.etaD(rec) = norms.etaD; hist.etaE(rec) = norms.etaE;
end

function hist = trimHistory2022(hist, n)
fields = fieldnames(hist);
for i = 1:numel(fields)
    hist.(fields{i}) = hist.(fields{i})(1:n);
end
end
