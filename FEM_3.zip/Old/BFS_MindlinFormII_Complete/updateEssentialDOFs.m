function [D, D_hist] = updateEssentialDOFs(D, dof, loadFactor, dDfree)
%UPDATEESSENTIALDOFS Update the global DOF vector after a Newton step.
%
%   D = updateEssentialDOFs(D, dof, loadFactor)
%   D = updateEssentialDOFs(D, dof, loadFactor, dDfree)
%
% Frozen Section 7 strong-Dirichlet update:
%   D(essDOF)  = loadFactor*essVals
%   D(freeDOF) = D(freeDOF) + dDfree

% ---------------------------------------------------------------------
% Input validation.
% ---------------------------------------------------------------------
assert(isstruct(dof) && isfield(dof, 'nDOF') && ...
       isfield(dof, 'freeDOF') && isfield(dof, 'essDOF') && ...
       isfield(dof, 'essVals'), ...
    ['updateEssentialDOFs:dof must contain nDOF, freeDOF, ' ...
     'essDOF, and essVals.']);

nDOF = dof.nDOF;
assert(isnumeric(nDOF) && isreal(nDOF) && isfinite(nDOF) && ...
       isscalar(nDOF) && nDOF >= 0 && nDOF == round(nDOF), ...
    'updateEssentialDOFs:dof.nDOF must be a non-negative integer.');

assert(isnumeric(D) && isreal(D) && all(isfinite(D(:))) && ...
       numel(D) == nDOF, ...
    'updateEssentialDOFs:D must be a real finite nDOF-vector.');

assert(isnumeric(loadFactor) && isreal(loadFactor) && ...
       isfinite(loadFactor) && isscalar(loadFactor), ...
    'updateEssentialDOFs:loadFactor must be a real finite scalar.');

D = D(:);
F = dof.freeDOF(:);
E = dof.essDOF(:);
nF = numel(F);
nE = numel(E);

assert(isnumeric(F) && isnumeric(E) && ...
       all(isfinite(F)) && all(isfinite(E)) && ...
       all(F == round(F)) && all(E == round(E)) && ...
       all(F >= 1 & F <= nDOF) && all(E >= 1 & E <= nDOF), ...
    'updateEssentialDOFs:freeDOF and essDOF must contain valid global indices.');

assert(numel(unique(F)) == nF && numel(unique(E)) == nE, ...
    'updateEssentialDOFs:freeDOF or essDOF contains duplicate indices.');

assert(isempty(intersect(F, E)), ...
    'updateEssentialDOFs:freeDOF and essDOF are not disjoint.');

assert(nF + nE == nDOF, ...
    'updateEssentialDOFs:freeDOF + essDOF must equal nDOF.');

assert(isnumeric(dof.essVals) && isreal(dof.essVals) && ...
       all(isfinite(dof.essVals(:))) && numel(dof.essVals) == nE, ...
    'updateEssentialDOFs:essVals must be a real finite nEss-vector.');

if nargin < 4 || isempty(dDfree)
    dDfree = zeros(nF, 1);
end

assert(isnumeric(dDfree) && isreal(dDfree) && ...
       all(isfinite(dDfree(:))) && numel(dDfree) == nF, ...
    'updateEssentialDOFs:dDfree must be a real finite nFree-vector.');

dDfree = dDfree(:);

% ---------------------------------------------------------------------
% Frozen strong enforcement and Newton free-DOF update.
% ---------------------------------------------------------------------
essValsScaled = loadFactor*dof.essVals(:);
essBefore = D(E);
freeBefore = D(F);

D(E) = essValsScaled;
D(F) = freeBefore + dDfree;

% ---------------------------------------------------------------------
% Diagnostics.
% ---------------------------------------------------------------------
D_hist = struct();
D_hist.essBefore = essBefore;
D_hist.essAfter = D(E);
D_hist.freeIncr = norm(dDfree);
D_hist.nFree = nF;
D_hist.nEss = nE;
D_hist.loadFactor = loadFactor;

% ---------------------------------------------------------------------
% Internal consistency checks.  The former implementation called this
% function again here, causing unbounded recursion.  These checks are
% deliberately non-recursive.
% ---------------------------------------------------------------------
tol = 1e-12;

assert(isequal(size(D), [nDOF, 1]), ...
    'updateEssentialDOFs:D must remain nDOF x 1.');

assert(norm(D(E) - essValsScaled) < tol*(1 + norm(essValsScaled)), ...
    'updateEssentialDOFs:essential DOFs were not set to prescribed values.');

if nF > 0
    assert(norm(D(F) - freeBefore - dDfree) < ...
           tol*(1 + norm(dDfree) + norm(freeBefore)), ...
        'updateEssentialDOFs:free-DOF update is inconsistent.');
else
    assert(isempty(dDfree), ...
        'updateEssentialDOFs:dDfree must be empty when nFree is zero.');
end

% Idempotence under a zero free increment is checked algebraically,
% without recursively calling updateEssentialDOFs.
Dzero = D;
Dzero(E) = essValsScaled;
assert(norm(Dzero - D) < tol*(1 + norm(D)), ...
    'updateEssentialDOFs:zero-increment update is not idempotent.');

end
