function bench = validate2022Benchmark(varargin)
%VALIDATE2022BENCHMARK Run the 2022 Mindlin Form-II recovery study.
%
%   bench = validate2022Benchmark('Name', Value, ...)
%
% The routine solves the selected infinitesimal-regime cases on a sequence
% of BFS meshes and computes displacement, gradient, strain, strain-
% gradient, and energy error measures with the frozen 3x3 Gauss rule.

ip = inputParser;
addParameter(ip, 'E', 100, @(x) isFinitePositiveScalar(x));
addParameter(ip, 'nu', 0.3, @(x) isFiniteScalar(x) && x > -1 && x < 0.5);
addParameter(ip, 'a1', 0, @isFiniteScalar);
addParameter(ip, 'a2', 0, @isFiniteScalar);
addParameter(ip, 'a3', 0, @isFiniteScalar);
addParameter(ip, 'a4', 0, @isFiniteScalar);
addParameter(ip, 'a5', 0, @isFiniteScalar);
addParameter(ip, 'L1', 1, @isFinitePositiveScalar);
addParameter(ip, 'L2', 1, @isFinitePositiveScalar);
addParameter(ip, 'NeList', [2, 4, 8, 16], @(x) isnumeric(x) && isvector(x));
addParameter(ip, 'cases', {'uniaxial', 'shear', 'bending'}, @iscell);
addParameter(ip, 'eps0', 1e-3, @isFiniteScalar);
addParameter(ip, 'gam0', 1e-3, @isFiniteScalar);
addParameter(ip, 'kap', 1e-3, @isFiniteScalar);
addParameter(ip, 'tol', 1e-8, @isFinitePositiveScalar);
addParameter(ip, 'verbose', true, @isLogicalScalar);
parse(ip, varargin{:});
o = ip.Results;
o.verbose = logical(o.verbose);

E = o.E;
nu = o.nu;
NeList = o.NeList(:).';
assert(all(isfinite(NeList)) && all(NeList >= 1) && all(NeList == round(NeList)), ...
    'validate2022Benchmark:NeList must contain positive integer mesh sizes.');

cases = o.cases;
nCases = numel(cases);
results = cell(1, nCases);
gauss3 = gaussQuadrature(3);

if o.verbose
    fprintf('=========================================================\n');
    fprintf(' 2022 Torabi--Niiranen Mindlin Form-II benchmark\n');
    fprintf(' E=%g, nu=%g, a=[%g,%g,%g,%g,%g]\n', ...
        E, nu, o.a1, o.a2, o.a3, o.a4, o.a5);
    fprintf(' NeList = %s\n', mat2str(NeList));
    fprintf('=========================================================\n');
end

for ci = 1:nCases
    cname = lower(char(cases{ci}));
    if o.verbose
        fprintf('Case: %s\n', cname);
    end

    nL = numel(NeList);
    L2err = zeros(1, nL);
    H1err = zeros(1, nL);
    Eerr = zeros(1, nL);
    Gerr = zeros(1, nL);
    Enerr = zeros(1, nL);
    Erel = zeros(1, nL);
    nDOFlist = zeros(1, nL);

    bc = localCaseBCs(cname, o);

    for mi = 1:nL
        Ne1 = NeList(mi);
        Ne2 = NeList(mi);

        prob = initializeProblem( ...
            'L1', o.L1, 'L2', o.L2, ...
            'Ne1', Ne1, 'Ne2', Ne2, ...
            'E', E, 'nu', nu, ...
            'a1', o.a1, 'a2', o.a2, 'a3', o.a3, ...
            'a4', o.a4, 'a5', o.a5, ...
            'bcSpecs', bc, ...
            'mode', 'linear', ...
            'adaptive', false, ...
            'nSteps', 1, ...
            'verbose', false);

        sol = runAnalysis(prob);
        assert(sol.finalConv, ...
            'validate2022Benchmark:solver did not converge for %s at Ne=%d.', cname, Ne1);

        D = sol.D(:, end);
        nDOFlist(mi) = sol.nDOF;

        [L2e, H1e, Ee, Ge, Ene, Ere] = ...
            localErrors(prob.mesh, prob.dof, D, gauss3, cname, o, prob.mat);

        L2err(mi) = L2e;
        H1err(mi) = H1e;
        Eerr(mi) = Ee;
        Gerr(mi) = Ge;
        Enerr(mi) = Ene;
        Erel(mi) = Ere;

        if o.verbose
            fprintf(['  Ne=%3dx%-3d nDOF=%4d  L2=%.2e H1=%.2e ' ...
                     'E=%.2e G=%.2e We=%.2e\n'], ...
                Ne1, Ne2, nDOFlist(mi), L2e, H1e, Ee, Ge, Ene);
        end
    end

    rateL2 = nan(1, nL);
    rateH1 = nan(1, nL);
    for mi = 2:nL
        if NeList(mi) == 2*NeList(mi - 1)
            if L2err(mi - 1) > 0 && L2err(mi) > 0
                rateL2(mi) = log2(L2err(mi - 1)/L2err(mi));
            end
            if H1err(mi - 1) > 0 && H1err(mi) > 0
                rateH1(mi) = log2(H1err(mi - 1)/H1err(mi));
            end
        end
    end

    pass = L2err(end) < o.tol && H1err(end) < o.tol;
    results{ci} = struct('name', cname, 'NeList', NeList, 'nDOF', nDOFlist, ...
        'L2err', L2err, 'H1err', H1err, 'Eerr', Eerr, 'Gerr', Gerr, ...
        'Enerr', Enerr, 'Erel', Erel, ...
        'rateL2', rateL2, 'rateH1', rateH1, 'pass', pass);

    if o.verbose
        if pass
            tag = 'PASS';
        else
            tag = 'FAIL';
        end
        fprintf('  -> %s [%s]\n', cname, tag);
    end
end

allPass = all(cellfun(@(r) r.pass, results));
summary = sprintf('%-18s', 'case');
for mi = 1:numel(NeList)
    summary = [summary, sprintf(' Ne=%-3d', NeList(mi))]; %#ok<AGROW>
end
summary = [summary, sprintf('  PASS\n')]; %#ok<AGROW>
summary = [summary, repmat('-', 1, 80), sprintf('\n')]; %#ok<AGROW>

for ci = 1:nCases
    r = results{ci};
    summary = [summary, sprintf('%-18s', r.name)]; %#ok<AGROW>
    for mi = 1:numel(NeList)
        summary = [summary, sprintf(' %.1e', r.L2err(mi))]; %#ok<AGROW>
    end
    summary = [summary, sprintf('  %d\n', r.pass)]; %#ok<AGROW>
end

bench = struct('cases', {results}, ...
               'NeList', NeList, ...
               'nDOFlist', results{end}.nDOF, ...
               'summary', summary, ...
               'allPass', allPass, ...
               'opts', o, ...
               'E', E, ...
               'nu', nu);

end

% =====================================================================
% Case data.
% =====================================================================
function bc = localCaseBCs(cname, o)

nu = o.nu;
L1 = o.L1;

switch cname
    case {'uniaxial', 'gradient_uniaxial'}
        eps0 = o.eps0;
        bc = { ...
            struct('edge', 'x0', 'comp', 1, 'dofType', 'all', 'value', 0), ...
            struct('edge', 'x0', 'comp', 2, 'dofType', 'all', 'value', 0), ...
            struct('edge', 'x1', 'comp', 1, 'dofType', 'u', 'value', eps0*L1), ...
            struct('edge', 'x1', 'comp', 2, 'dofType', 'u', ...
                   'value', @(X1, X2) -nu*eps0*X2)};

    case 'shear'
        gam = o.gam0;
        bc = { ...
            struct('edge', 'x0', 'comp', 1, 'dofType', 'all', 'value', 0), ...
            struct('edge', 'x0', 'comp', 2, 'dofType', 'all', 'value', 0), ...
            struct('edge', 'x1', 'comp', 1, 'dofType', 'u', ...
                   'value', @(X1, X2) gam*X2), ...
            struct('edge', 'x1', 'comp', 2, 'dofType', 'u', 'value', 0)};

    case 'bending'
        kap = o.kap;
        bc = { ...
            struct('edge', 'x0', 'comp', 1, 'dofType', 'all', 'value', 0), ...
            struct('edge', 'x0', 'comp', 2, 'dofType', 'all', 'value', 0), ...
            struct('edge', 'x1', 'comp', 1, 'dofType', 'u', ...
                   'value', @(X1, X2) -kap*L1*X2), ...
            struct('edge', 'x1', 'comp', 2, 'dofType', 'u', ...
                   'value', @(X1, X2) 0.5*kap*(L1^2 + nu*X2.^2))};

    otherwise
        error('validate2022Benchmark:unknown case "%s".', cname);
end

end

% =====================================================================
% Gauss-point error and energy evaluation.
% =====================================================================
function [L2, H1, Ee, Ge, Enerr, Erel] = localErrors(mesh, dof, D, gauss, cname, o, mat)

% Correct case-sensitive fields from gaussQuadrature.m.
xi1D = gauss.xi1D;
w1D = gauss.w1D;
ng = gauss.ng;

lam = mat.lambda;
mu = mat.mu;
if isfield(mat, 'thickness')
    thickness = mat.thickness;
else
    thickness = 1;
end

L2num = 0; L2den = 0;
H1num = 0; H1den = 0;
Enum = 0; Eden = 0;
Gnum = 0; Gden = 0;
Whnum = 0;

Wexact = localExactEnergy(cname, o, mat);

for e = 1:mesh.nElem
    eg = mesh.elemGeom(e);
    de = D(dof.elemDOF(e, :));

    Jmap = computeJacobian(eg);
    h1 = Jmap.h1;
    h2 = Jmap.h2;
    detJ = Jmap.detJ;

    scale1 = 2/h1;
    scale2 = 2/h2;
    scale11 = scale1*scale1;
    scale22 = scale2*scale2;
    scale12 = scale1*scale2;

    for i = 1:ng
        for j = 1:ng
            xi = xi1D(i);
            eta = xi1D(j);
            w = w1D(i)*w1D(j);

            dN = bfsShapeFunctionDerivatives(xi, eta, h1, h2);

            u1h = dN.N0(1, 1:16)*de(1:16);
            u2h = dN.N0(2, 17:32)*de(17:32);

            g11 = scale1*(dN.dNdxi(1, 1:16)*de(1:16));
            g12 = scale2*(dN.dNdeta(1, 1:16)*de(1:16));
            g21 = scale1*(dN.dNdxi(2, 17:32)*de(17:32));
            g22 = scale2*(dN.dNdeta(2, 17:32)*de(17:32));

            secondU = zeros(2, 2, 2);
            secondU(1, 1, 1) = scale11*(dN.d2Ndxi2(1, 1:16)*de(1:16));
            secondU(1, 2, 2) = scale22*(dN.d2Ndeta2(1, 1:16)*de(1:16));
            secondU(1, 1, 2) = scale12*(dN.d2Ndxideta(1, 1:16)*de(1:16));
            secondU(1, 2, 1) = secondU(1, 1, 2);
            secondU(2, 1, 1) = scale11*(dN.d2Ndxi2(2, 17:32)*de(17:32));
            secondU(2, 2, 2) = scale22*(dN.d2Ndeta2(2, 17:32)*de(17:32));
            secondU(2, 1, 2) = scale12*(dN.d2Ndxideta(2, 17:32)*de(17:32));
            secondU(2, 2, 1) = secondU(2, 1, 2);

            X1 = eg.x0 + h1*(xi + 1)/2;
            X2 = eg.y0 + h2*(eta + 1)/2;
            [u1e, u2e, ge11, ge12, ge21, ge22, exactSecondU] = ...
                localExact(cname, o, X1, X2);

            du1 = u1h - u1e;
            du2 = u2h - u2e;
            dg11 = g11 - ge11;
            dg12 = g12 - ge12;
            dg21 = g21 - ge21;
            dg22 = g22 - ge22;

            L2num = L2num + w*(du1^2 + du2^2)*detJ*thickness;
            L2den = L2den + w*(u1e^2 + u2e^2)*detJ*thickness;
            H1num = H1num + w*(du1^2 + du2^2 + ...
                dg11^2 + dg12^2 + dg21^2 + dg22^2)*detJ*thickness;
            H1den = H1den + w*(u1e^2 + u2e^2 + ...
                ge11^2 + ge12^2 + ge21^2 + ge22^2)*detJ*thickness;

            Eh11 = g11;
            Eh22 = g22;
            Eh12 = 0.5*(g12 + g21);
            Ee11 = ge11;
            Ee22 = ge22;
            Ee12 = 0.5*(ge12 + ge21);

            Enum = Enum + w*((Eh11 - Ee11)^2 + (Eh22 - Ee22)^2 + ...
                2*(Eh12 - Ee12)^2)*detJ*thickness;
            Eden = Eden + w*(Ee11^2 + Ee22^2 + 2*Ee12^2)*detJ*thickness;

            Gh = zeros(2, 2, 2);
            GeExact = zeros(2, 2, 2);
            for I = 1:2
                for J = 1:2
                    for K = 1:2
                        Gh(I, J, K) = 0.5*(secondU(I, J, K) + secondU(J, I, K));
                        GeExact(I, J, K) = 0.5*(exactSecondU(I, J, K) + exactSecondU(J, I, K));
                    end
                end
            end

            GnumLocal = sum((Gh(:) - GeExact(:)).^2);
            GdenLocal = sum(GeExact(:).^2);
            Gnum = Gnum + w*GnumLocal*detJ*thickness;
            Gden = Gden + w*GdenLocal*detJ*thickness;

            trh = Eh11 + Eh22;
            psiH = 0.5*lam*trh^2 + mu*(Eh11^2 + Eh22^2 + 2*Eh12^2);
            Whnum = Whnum + w*psiH*detJ*thickness;
        end
    end
end

L2 = sqrt(L2num/max(L2den, eps));
H1 = sqrt(H1num/max(H1den, eps));
Ee = sqrt(Enum/max(Eden, eps));
Ge = sqrt(Gnum/max(Gden, 1));

if Wexact > 0
    Enerr = abs(Whnum - Wexact)/abs(Wexact);
else
    Enerr = abs(Whnum);
end

Erel = Ee;

end

% =====================================================================
% Exact benchmark fields.
% =====================================================================
function [u1, u2, u1_1, u1_2, u2_1, u2_2, secondU] = localExact(cname, o, X1, X2)

nu = o.nu;
eps0 = o.eps0;
gam = o.gam0;
kap = o.kap;
secondU = zeros(2, 2, 2);

switch cname
    case {'uniaxial', 'gradient_uniaxial'}
        u1 = eps0*X1;
        u2 = -nu*eps0*X2;
        u1_1 = eps0; u1_2 = 0;
        u2_1 = 0; u2_2 = -nu*eps0;

    case 'shear'
        u1 = gam*X2;
        u2 = 0;
        u1_1 = 0; u1_2 = gam;
        u2_1 = 0; u2_2 = 0;

    case 'bending'
        u1 = -kap*X1*X2;
        u2 = 0.5*kap*(X1^2 + nu*X2^2);
        u1_1 = -kap*X2; u1_2 = -kap*X1;
        u2_1 = kap*X1; u2_2 = kap*nu*X2;
        secondU(1, 1, 2) = -kap;
        secondU(1, 2, 1) = -kap;
        secondU(2, 1, 1) = kap;
        secondU(2, 2, 2) = kap*nu;

    otherwise
        error('validate2022Benchmark:unknown exact field "%s".', cname);
end

end

function W = localExactEnergy(cname, o, mat)

L1 = o.L1;
L2 = o.L2;
lam = mat.lambda;
mu = mat.mu;
nu = o.nu;
if isfield(mat, 'thickness')
    thickness = mat.thickness;
else
    thickness = 1;
end

switch cname
    case {'uniaxial', 'gradient_uniaxial'}
        eps0 = o.eps0;
        psi = 0.5*lam*(eps0*(1 - nu))^2 + ...
              mu*(eps0^2 + (nu*eps0)^2);
        W = psi*L1*L2*thickness;

    case 'shear'
        E12 = 0.5*o.gam0;
        psi = mu*(2*E12^2);
        W = psi*L1*L2*thickness;

    case 'bending'
        kap = o.kap;
        integralX2Squared = L1*L2^3/3;
        W = (0.5*lam*(kap*(nu - 1))^2 + ...
             mu*(kap^2 + (nu*kap)^2))*integralX2Squared*thickness;

    otherwise
        W = 0;
end

end

function tf = isFiniteScalar(x)
tf = isnumeric(x) && isreal(x) && isfinite(x) && isscalar(x);
end

function tf = isFinitePositiveScalar(x)
tf = isFiniteScalar(x) && x > 0;
end

function tf = isLogicalScalar(x)
tf = (islogical(x) && isscalar(x)) || ...
     (isnumeric(x) && isreal(x) && isfinite(x) && isscalar(x) && ...
      (x == 0 || x == 1));
end
