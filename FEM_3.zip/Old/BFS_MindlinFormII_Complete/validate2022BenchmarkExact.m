function bench = validate2022BenchmarkExact(varargin)
%VALIDATE2022BENCHMARKEXACT Isolated recovery of the linked 2022 benchmark.
%
%   bench = validate2022BenchmarkExact('Name', Value, ...)
%
% Runs the paper's Case 1 (prescribed top displacement) and Case 2
% (prescribed top traction) using periodic left/right BFS constraints.
% Existing normal-solver files are not modified or called by this driver.

p = inputParser;
addParameter(p, 'cases', {'case1', 'case2'}, @iscell);
addParameter(p, 'NeYList', [4, 8, 16], @(x) isnumeric(x) && isvector(x));
addParameter(p, 'ellList', [0.1, 0.2, 0.3], @(x) isnumeric(x) && isvector(x));
addParameter(p, 'loadScale', 1e-5, @(x) isnumeric(x) && isscalar(x) && x > 0);
addParameter(p, 'tol', 1e-3, @(x) isnumeric(x) && isscalar(x) && x > 0);
addParameter(p, 'verbose', true, @(x) islogical(x) || (isnumeric(x) && isscalar(x)));
parse(p, varargin{:});
o = p.Results;
o.verbose = logical(o.verbose);

NeYList = o.NeYList(:).';
ellList = o.ellList(:).';
assert(all(NeYList >= 1) && all(NeYList == round(NeYList)), ...
    'validate2022BenchmarkExact:NeYList must contain positive integers.');

results = cell(numel(o.cases), numel(ellList));
allPass = true;

if o.verbose
    fprintf('=========================================================\n');
    fprintf(' Exact 2022 simple-shear strain-gradient benchmark\n');
    fprintf(' Periodic x-boundaries; finite-strain load scale = %g\n', o.loadScale);
    fprintf('=========================================================\n');
end

for ci = 1:numel(o.cases)
    caseName = lower(char(o.cases{ci}));

    for li = 1:numel(ellList)
        ell = ellList(li);
        L2 = zeros(1, numel(NeYList));
        H1 = zeros(1, numel(NeYList));
        G2 = zeros(1, numel(NeYList));
        Rn = zeros(1, numel(NeYList));
        ok = false(1, numel(NeYList));
        nDOF = zeros(1, numel(NeYList));

        for mi = 1:numel(NeYList)
            NeY = NeYList(mi);
            NeX = 3*NeY; % L/H=3, hence approximately square elements.

            prob = initializeProblem2022('caseName', caseName, ...
                'ell', ell, 'NeX', NeX, 'NeY', NeY, ...
                'loadScale', o.loadScale, 'verbose', false);
            sol = runAnalysis2022(prob);

            [L2(mi), H1(mi), G2(mi)] = localProfileErrors(sol);
            Rn(mi) = sol.Rnorm;
            ok(mi) = sol.finalConv;
            nDOF(mi) = sol.nDOF;

            if o.verbose
                fprintf('%s ell=%g Ne=%dx%d nDOF=%d L2=% .3e H1=% .3e G=% .3e Rq=% .3e conv=%d\n', ...
                    caseName, ell, NeX, NeY, nDOF(mi), L2(mi), H1(mi), G2(mi), Rn(mi), ok(mi));
            end
        end

        rateL2 = nan(1, numel(NeYList));
        rateH1 = nan(1, numel(NeYList));
        for mi = 2:numel(NeYList)
            if NeYList(mi) == 2*NeYList(mi - 1)
                rateL2(mi) = log2(L2(mi - 1)/L2(mi));
                rateH1(mi) = log2(H1(mi - 1)/H1(mi));
            end
        end

        pass = all(ok) && L2(end) < o.tol && H1(end) < o.tol;
        allPass = allPass && pass;
        results{ci, li} = struct('caseName', caseName, 'ell', ell, ...
            'NeYList', NeYList, 'NeXList', 3*NeYList, 'nDOF', nDOF, ...
            'L2err', L2, 'H1err', H1, 'Gerr', G2, 'Rnorm', Rn, ...
            'rateL2', rateL2, 'rateH1', rateH1, 'converged', ok, 'pass', pass);
    end
end

bench = struct('results', {results}, 'opts', o, 'allPass', allPass, ...
               'source', 'Shekarchizadeh--Abali--Bersani (2022), DOI 10.1177/10812865221114336');

end

function [L2, H1, G2] = localProfileErrors(sol)

mesh = sol.mesh;
dof = sol.dof;
gauss = sol.gauss;
D = sol.D(:, end);
paper = sol.paper;

numU = 0; denU = 0;
numH = 0; denH = 0;
numG = 0; denG = 0;

for e = 1:mesh.nElem
    eg = mesh.elemGeom(e);
    de = D(dof.elemDOF(e, :));
    detJ = eg.h1*eg.h2/4;
    s2 = 2/eg.h2;
    s22 = s2*s2;

    for i = 1:gauss.ng
        for j = 1:gauss.ng
            xi = gauss.xi1D(i);
            eta = gauss.xi1D(j);
            w = gauss.w1D(i)*gauss.w1D(j);
            y = eg.y0 + eg.h2*(eta + 1)/2;

            dN = bfsShapeFunctionDerivatives(xi, eta, eg.h1, eg.h2);
            uxH = dN.N0(1, 1:16)*de(1:16);
            uxYH = s2*(dN.dNdeta(1, 1:16)*de(1:16));
            uxYYH = s22*(dN.d2Ndeta2(1, 1:16)*de(1:16));

            exact = analyticalSolution2022(y, paper, sol.caseName);
            dv = w*detJ;

            numU = numU + dv*(uxH - exact.ux)^2;
            denU = denU + dv*exact.ux^2;
            numH = numH + dv*((uxH - exact.ux)^2 + (uxYH - exact.ux_y)^2);
            denH = denH + dv*(exact.ux^2 + exact.ux_y^2);
            numG = numG + dv*(uxYYH - exact.ux_yy)^2;
            denG = denG + dv*exact.ux_yy^2;
        end
    end
end

L2 = sqrt(numU/max(denU, eps));
H1 = sqrt(numH/max(denH, eps));
G2 = sqrt(numG/max(denG, eps));

end
