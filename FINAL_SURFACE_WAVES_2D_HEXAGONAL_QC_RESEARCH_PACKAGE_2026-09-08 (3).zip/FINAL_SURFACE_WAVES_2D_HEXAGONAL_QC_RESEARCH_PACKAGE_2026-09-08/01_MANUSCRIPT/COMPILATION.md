# Manuscript Compilation Instructions

## Prerequisites
- TeX Live 2022+ (or MacTeX / MikTeX)
- `pdflatex` or `xelatex`
- `bibtex`

## Compilation Commands
```bash
pdflatex -interaction=nonstopmode FINAL_MANUSCRIPT.tex
bibtex FINAL_MANUSCRIPT
pdflatex -interaction=nonstopmode FINAL_MANUSCRIPT.tex
pdflatex -interaction=nonstopmode FINAL_MANUSCRIPT.tex
```

## Figure References
All 11 vector PDF figures (`fig1.pdf` through `fig11.pdf`) are available in the current directory and `./figures/`.
