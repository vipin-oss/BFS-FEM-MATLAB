# Production Solver Module

Authoritative 2D Hexagonal Piezoelectric Thermoelastic Quasicrystal surface-wave solver.

## Modules:
- `solver/material.py`: Physical and nondimensional material parameters, scaling coefficients, and frozen baseline validation.
- `solver/matrix.py`: $10\times 10$ acoustic tensor pencil $M(\Omega^*, k^*, p)$ assembly for Models A (inertial), B (diffusive), and C (wave-telegraph).
- `solver/roots.py`: Decoupled and coupled polynomial depth eigenvalue solver (companion matrix and polynomial roots), root sorting, decaying half-space selection ($	ext{Im}(p) > 0$).
- `solver/boundary.py`: $5\times 5$ boundary condition secular determinant matrix $B(\Omega^*, k^*)$ assembly (mechanical traction, phason traction, electric displacement, thermal flux/isothermal).
- `solver/branch.py`: Determinant minimization, continuation tracking, verified seed selection, and branch tracking across frequency sweeps.
- `solver/residual.py`: Boundary residual evaluation $r(V^*) = \min_j \sigma_j(B(V^*))$.
- `solver/diagnostics.py`: Root count diagnostics ($n_{\text{ad}}=5$), grazing root checks, condition numbers, and polynomial degree validation.
- `solver/resolution.py`: Branch-point accuracy bounds and numerical floor evaluations ($u_V \le 1.13 \times 10^{-9}$, $\varepsilon_\Delta = 1.13 \times 10^{-8}$).
- `solver/record.py`: CSV/NPZ serialization routines.
