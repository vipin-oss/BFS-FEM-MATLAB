# Production Drivers & Study Runners

## Drivers:
- `drivers/study1_baseline.py`: Baseline frequency sweeps ($\Omega = 10^{-3}..10^3$) for Models A, B, and C with free phason and isothermal boundary.
- `drivers/study2_friction_map.py`: 2D parameter grid sweep ($61\times 61$) across frequency $\Omega$ and phason friction $D_w$.
- `drivers/study3_thermal.py`: Thermal relaxation time sweep ($	au_0 = 10^{-2}..10^2\text{ ps}$) probing Lord–Shulman hyperbolic thermoelasticity.
- `drivers/study_bc.py`: Boundary condition comparison study (clamped vs. free phason surface; insulated vs. isothermal).
- `drivers/roots_diag.py`: Root locus and polynomial pencil depth eigenvalue diagnostics across decades.
- `figures/make_all_figures.py`: Deterministic figure generation engine producing vector PDF and EPS figures from raw data.
- `run_all.py`: Master automated reproduction runner.
