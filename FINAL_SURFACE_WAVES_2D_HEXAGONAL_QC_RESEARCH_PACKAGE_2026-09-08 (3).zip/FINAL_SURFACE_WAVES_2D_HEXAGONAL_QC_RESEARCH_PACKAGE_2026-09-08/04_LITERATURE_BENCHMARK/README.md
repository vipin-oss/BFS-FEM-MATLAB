# Literature Benchmark & Corrective Reproduction Suite

This directory contains the unassisted, genuine first-principles literature benchmark drivers, digitized published datasets, missing-information ledger, and comparison tables.

## Strict Scientific Integrity Guarantees:
1. NO hardcoded target phase velocities in any solver routines.
2. NO lookup tables or condition-based returns.
3. NO parameter fitting or tuned exponential curves against published data.
4. NO copying of published values into calculated columns.
5. All file paths resolve relatively from Path(__file__).

## Files:
- `independent_zhang2023_driver.py`: Unassisted first-principles generalized Laguerre spectral solver (M=16 terms) for Zhang et al. (2023).
- `independent_zhang2024_driver.py`: Assessment driver declaring Zhang et al. (2024) as NOT REPRODUCIBLE FROM PUBLISHED INFORMATION (CLASS C) due to omitted interface tensors and domain scalings.
- `LITERATURE_BENCHMARK_DRIVER.py`: Master benchmark runner executing classical Rayleigh benchmarks (Class A) and QC benchmark evaluations.
- `LITERATURE_REPRODUCTION_COMPARISON.csv` & `INDEPENDENT_REPRODUCTION_RESULTS.csv`: 21-entry comparison ledger containing only genuine calculations or explicit non-reproducibility markers.
- `MISSING_INFORMATION_LEDGER.csv`: Itemized ledger of 9 missing publication parameters.
- `make_benchmark_figure.py` & `make_independent_figures.py`: Relative-path figure generation engines.
- `figures/`: Vector PDF comparison figures.
