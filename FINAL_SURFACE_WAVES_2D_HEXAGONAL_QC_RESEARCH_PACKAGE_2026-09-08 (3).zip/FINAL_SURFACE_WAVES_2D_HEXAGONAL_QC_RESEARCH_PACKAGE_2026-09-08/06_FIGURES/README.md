# Final Manuscript Figures & Figure Generation Scripts

Contains all 11 production vector PDF and EPS figures for the manuscript, generated strictly from raw data.

## Files:
- `output/fig1.pdf` through `output/fig11.pdf`: Publication-ready vector PDF figures.
- `output/Fig01.eps` through `output/Fig11.eps`: Publication-ready EPS figures.
- `make_all_figures.py`: Deterministic generation script.
- `style.py`: Standard publication styling, colormaps, typography, and line widths.
- `FIGURE_MANIFEST.md`: Caption mapping and figure metadata.
- `FIGURE_PROVENANCE.md`: Raw data to figure panel traceability ledger.
