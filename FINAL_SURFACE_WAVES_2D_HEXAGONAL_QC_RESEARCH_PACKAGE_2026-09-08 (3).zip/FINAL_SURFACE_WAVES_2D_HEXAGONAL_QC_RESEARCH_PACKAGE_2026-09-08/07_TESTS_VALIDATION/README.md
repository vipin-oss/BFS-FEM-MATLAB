# Validation Test Suite & Invariant Verification

Comprehensive validation suite enforcing mathematical invariants, physical limiting cases, and numerical accuracy.

## Test Matrix:
- `tests/V0/test_V0_integrity.py`: Code integrity, module structure, and class interface verification.
- `tests/V1/test_V1_two_path.py`: Two-path consistency check ($\Omega \to k^*$ vs. $k^* \to \Omega$).
- `tests/V2/test_V2_elastic_limit.py`: Classical Barnett–Lothe Rayleigh wave decoupled limit ($1.1 \times 10^{-11}$ error).
- `tests/V3/test_V3_model_limits.py`: Continuous model limit sweeps ($C\to A$ and $C\to B$ to parts-per-billion).
- `tests/V4/test_V4_symbolic.py`: Exact rational arithmetic symbolic verification ($\deg_p=10$, static determinant factorization).
- `tests/V5/test_V5_nondim.py`: Nondimensional scaling and arithmetic consistency.
- `verification/verify_invariants.py`: 22/22 science preservation invariant test engine.
- `validation_logs/`: Complete execution logs for all V0–V5 validation passes.
