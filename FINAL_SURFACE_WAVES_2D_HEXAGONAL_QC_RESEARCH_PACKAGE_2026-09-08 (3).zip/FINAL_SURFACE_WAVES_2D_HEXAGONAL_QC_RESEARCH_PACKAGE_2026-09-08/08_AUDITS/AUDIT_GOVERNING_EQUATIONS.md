# AUDIT_GOVERNING_EQUATIONS.md

## Forensic Scientific Audit: Phase 3 — Governing Equations and Dynamics

**Research Project:** Surface Waves in 2D Hexagonal Piezoelectric Thermoelastic Quasicrystals  
**Manuscript Baseline:** `manuscript/FINAL_MANUSCRIPT.tex` (Section 2.3, Table 1)  
**Solver Baseline:** `solver/matrix.py`, `solver/material.py`  
**Status:** GREEN (Fully Verified Independently)  

---

## 1. Equations of Motion in 2D Cartesian Coordinates $(x, z)$

### 1.1 Phonon Momentum Balance
In the absence of body forces, the momentum balance law is:
$$\rho \ddot{\mathbf{u}} = \nabla \cdot \boldsymbol{\sigma}$$

Expanding in sagittal coordinates $(x, z)$:
1. **$x$-direction momentum:**
$$\rho \frac{\partial^2 u_x}{\partial t^2} = \frac{\partial \sigma_{xx}}{\partial x} + \frac{\partial \sigma_{xz}}{\partial z}$$
Substituting constitutive equations:
$$\rho \ddot{u}_x = \left(C_{11}\frac{\partial^2 u_x}{\partial x^2} + C_{66}\frac{\partial^2 u_x}{\partial z^2}\right) + (C_{12}+C_{66})\frac{\partial^2 u_z}{\partial x \partial z} + \left(R_1\frac{\partial^2 w_x}{\partial x^2} + R_6\frac{\partial^2 w_x}{\partial z^2}\right) + (R_2+R_6)\frac{\partial^2 w_z}{\partial x \partial z} - \beta_1 \frac{\partial \theta}{\partial x}$$

2. **$z$-direction momentum:**
$$\rho \frac{\partial^2 u_z}{\partial t^2} = \frac{\partial \sigma_{xz}}{\partial x} + \frac{\partial \sigma_{zz}}{\partial z}$$
Substituting constitutive equations:
$$\rho \ddot{u}_z = (C_{12}+C_{66})\frac{\partial^2 u_x}{\partial x \partial z} + \left(C_{66}\frac{\partial^2 u_z}{\partial x^2} + C_{11}\frac{\partial^2 u_z}{\partial z^2}\right) + (R_2+R_6)\frac{\partial^2 w_x}{\partial x \partial z} + \left(R_6\frac{\partial^2 w_z}{\partial x^2} + R_1\frac{\partial^2 w_z}{\partial z^2}\right) - \beta_1 \frac{\partial \theta}{\partial z}$$

---

## 2. Phason Dynamics: The Three Models (A, B, C)

The generalized phason balance law is given by:
$$\mathcal{L}[\mathbf{w}] = \nabla \cdot \mathbf{H}$$

where the divergence components are:
$$(\nabla \cdot \mathbf{H})_x = \frac{\partial H_{xx}}{\partial x} + \frac{\partial H_{xz}}{\partial z} = \left(R_1\frac{\partial^2 u_x}{\partial x^2} + R_6\frac{\partial^2 u_x}{\partial z^2}\right) + (R_2+R_6)\frac{\partial^2 u_z}{\partial x \partial z} + \left(K_1\frac{\partial^2 w_x}{\partial x^2} + K_3\frac{\partial^2 w_x}{\partial z^2}\right) + (K_2+K_6)\frac{\partial^2 w_z}{\partial x \partial z}$$
$$(\nabla \cdot \mathbf{H})_z = \frac{\partial H_{zx}}{\partial x} + \frac{\partial H_{zz}}{\partial z} = (R_2+R_6)\frac{\partial^2 u_x}{\partial x \partial z} + \left(R_6\frac{\partial^2 u_z}{\partial x^2} + R_1\frac{\partial^2 u_z}{\partial z^2}\right) + (K_2+K_6)\frac{\partial^2 w_x}{\partial x \partial z} + \left(K_3\frac{\partial^2 w_z}{\partial x^2} + K_1\frac{\partial^2 w_z}{\partial z^2}\right)$$

### 2.1 Dynamic Operators & Harmonic Form
Under harmonic time dependence $e^{-\mathrm{i}\omega t}$ (where $\partial_t \to -\mathrm{i}\omega$ and $\partial_{tt} \to -\omega^2$):

| Model | Physical Regime | Balance Law | Harmonic Operator $\Lambda(\omega)$ | Literature Source |
|---|---|---|---|---|
| **Model A** | Elastodynamic (Inertial) | $\rho_w \ddot{\mathbf{w}} = \nabla \cdot \mathbf{H}$ | $\Lambda_A = -\rho_w \omega^2$ | Ding et al. (1993, 2000), Fan (2011) |
| **Model B** | Elasto-hydrodynamic (Diffusive) | $D_w \dot{\mathbf{w}} = \nabla \cdot \mathbf{H}$ | $\Lambda_B = -\mathrm{i}\omega D_w$ | Lubensky et al. (1985), Rochal & Lorman (2000) |
| **Model C** | Wave-Telegraph (Interpolating) | $\rho_w \ddot{\mathbf{w}} + D_w \dot{\mathbf{w}} = \nabla \cdot \mathbf{H}$ | $\Lambda_C = -\rho_w \omega^2 - \mathrm{i}\omega D_w$ | Agiasofitou & Lazar (2014) |

---

## 3. Literature Attribution & Taxonomy Verification

### 3.1 Agiasofitou & Lazar (2014) Mapping
In *International Journal of Solids and Structures* 51 (2014) 923–929, Agiasofitou and Lazar introduced the wave-telegraph equation for quasicrystal phason dynamics:
$$\tau \frac{\partial^2 w_i}{\partial t^2} + \frac{\partial w_i}{\partial t} = C_w \partial_j H_{ij}$$
Multiplying through by $D_w = 1/C_w$ and identifying $\rho_w = \tau D_w = \tau / C_w$:
$$\rho_w \ddot{\mathbf{w}} + D_w \dot{\mathbf{w}} = \nabla \cdot \mathbf{H}$$
This is mathematically identical to Model C.

### 3.2 Asymptotic Limits
1. **Zero-friction limit ($D_w \to 0$):**
   $$\lim_{D_w \to 0} \Lambda_C = -\rho_w \omega^2 = \Lambda_A \implies \text{Model C} \to \text{Model A}$$
2. **Zero-inertia limit ($\rho_w \to 0$):**
   $$\lim_{\rho_w \to 0} \Lambda_C = -\mathrm{i}\omega D_w = \Lambda_B \implies \text{Model C} \to \text{Model B}$$

---

## 4. Dimensional Consistency Analysis

| Quantity | Symbol | SI Unit | Dimensional Formula | Verified |
|---|---|---|---|---|
| Phason displacement | $w$ | $\text{m}$ | $[L]$ | PASS |
| Phason pseudo-stress | $H$ | $\text{Pa}$ | $[M L^{-1} T^{-2}]$ | PASS |
| Divergence of $H$ | $\nabla \cdot H$ | $\text{Pa/m} = \text{N/m}^3$ | $[M L^{-2} T^{-2}]$ | PASS |
| Phonon inertia term | $\rho \ddot{u}$ | $\text{kg/(m}^2\cdot\text{s}^2)$ | $[M L^{-2} T^{-2}]$ | PASS |
| Phason mass density | $\rho_w$ | $\text{kg/m}^3$ | $[M L^{-3}]$ | PASS |
| Phason friction | $D_w$ | $\text{kg/(m}^3\cdot\text{s})$ | $[M L^{-3} T^{-1}]$ | PASS |
| Phason mobility | $C_w = 1/D_w$ | $\text{m}^3\cdot\text{s/kg}$ | $[M^{-1} L^3 T]$ | PASS |
| Telegraph relaxation time | $\tau_{\text{tel}} = 2\rho_w / D_w$ | $\text{s}$ | $[T]$ | PASS |
| Crossover frequency | $\Omega_c = D_w / \rho_w$ | $\text{rad/s}$ | $[T^{-1}]$ | PASS |

---

## 5. Physical Discussion of Phason Inertia Assumptions

1. **Surrogate nature of $\rho_w$:** Because phason modes correspond to atomic rearrangement and tile flips rather than collective center-of-mass acoustic translations, an independent measurement of $\rho_w$ has not been reported in the experimental literature. The project transparently sets $\rho_w = \rho = 4180\text{ kg/m}^3$ as a declared surrogate computational baseline (Section 2.3 and Section 4).
2. **Crossover Scale:** With $D_w = 2.0833 \times 10^{18}\text{ kg/(m}^3\cdot\text{s)}$ (from Chellappan et al. 2015), the crossover frequency $\Omega_c = D_w/\rho_w \approx 4.984 \times 10^{14}\text{ rad/s}$ ($f_c \approx 79.32\text{ THz}$) lies deep in the optical/terahertz range. At standard ultrasound and hypersonic frequencies (GHz), phason dynamics in Model C is dominated by dissipative drag, converging smoothly to diffusive Model B.

---

## 6. Phase 3 Forensic Conclusion

The equations of motion for phonon momentum and phason dynamic models A, B, and C are derived from first principles, verified for exact dimensional homogeneity and sign consistency, and proven to correctly reflect the wave-telegraph continuum mechanics framework of Agiasofitou & Lazar (2014).
