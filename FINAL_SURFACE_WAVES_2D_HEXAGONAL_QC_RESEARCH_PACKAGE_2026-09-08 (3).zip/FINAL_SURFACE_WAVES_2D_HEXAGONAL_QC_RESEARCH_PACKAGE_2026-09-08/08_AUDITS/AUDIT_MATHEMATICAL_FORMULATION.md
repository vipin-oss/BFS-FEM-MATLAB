# AUDIT_MATHEMATICAL_FORMULATION.md

## Forensic Scientific Audit: Phase 2 — Mathematical Formulation

**Research Project:** Surface Waves in 2D Hexagonal Piezoelectric Thermoelastic Quasicrystals  
**Manuscript Baseline:** `manuscript/FINAL_MANUSCRIPT.tex` (Section 2, Eqs. 1–7)  
**Solver Baseline:** `solver/material.py`, `solver/matrix.py`  
**Status:** GREEN (Fully Verified Independently)  

---

## 1. Crystallographic Symmetry and Independent Invariants

### 1.1 Quasicrystal Classification
- **Class:** 2D Hexagonal Quasicrystal, Laue Class 10 (point groups $6mm$, $622$, $\bar{6}m2$, $6/mmm$).
- **Spatial Topology:** Quasiperiodic in the $x_1-x_2$ plane, periodic along the $x_3$ axis.
- **Configuration I (Studied Cut):** Sagittal wave propagation along $x \equiv x_1$, depth decay along $z \equiv x_2$, invariant along periodic axis $y \equiv x_3$ ($\partial/\partial y = 0, u_y = 0$).

### 1.2 Independent Material Constants Count
From linear elastic representation theory of 2D hexagonal quasicrystals (Ding et al. 2000, Fan 2011, Yang et al. 2014):
- **Phonon Elastic Tensor ($C_{ijkl}$):** $N_C = 5$ independent constants ($C_{11}, C_{12}, C_{13}, C_{33}, C_{44}$).
  - In the quasiperiodic isotropic basal plane, $C_{66} = \frac{1}{2}(C_{11} - C_{12})$.
- **Phason Elastic Tensor ($K_{ijkl}$):** $N_K = 4$ independent constants ($K_1, K_2, K_3, K_4$).
  - In the quasiperiodic basal plane, $K_6 = K_1 - K_2 - K_3$.
- **Phonon-Phason Coupling Tensor ($R_{ijkl}$):** $N_R = 4$ independent constants ($R_1, R_2, R_3, R_4$).
  - In the quasiperiodic basal plane, $R_6 = \frac{1}{2}(R_1 - R_2)$.

### 1.3 Exact Symmetry Relations
$$\boxed{C_{66} = \frac{C_{11} - C_{12}}{2}}$$
$$\boxed{K_6 = K_1 - K_2 - K_3}$$
$$\boxed{R_6 = \frac{R_1 - R_2}{2}}$$

Numerical verification from `params.json`:
- $C_{11} = 200\text{ GPa}, C_{12} = 100\text{ GPa} \implies C_{66} = \frac{200 - 100}{2} = 50\text{ GPa}$ ($C_{66}^* = 0.25$) — **VERIFIED**
- $K_1 = 50\text{ GPa}, K_2 = 20\text{ GPa}, K_3 = 20\text{ GPa} \implies K_6 = 50 - 20 - 20 = 10\text{ GPa}$ ($K_6^* = 0.05$) — **VERIFIED**
- $R_1 = 10\text{ GPa}, R_2 = 5\text{ GPa} \implies R_6 = \frac{10 - 5}{2} = 2.5\text{ GPa}$ ($R_6^* = 0.0125$) — **VERIFIED**

---

## 2. Independent Energy Density Reconstruction

The total Helmholtz free energy density $\mathcal{F}$ for 2D hexagonal QC in Configuration I is reconstructed as:
$$\mathcal{F} = \mathcal{F}_{\text{phonon}} + \mathcal{F}_{\text{phason}} + \mathcal{F}_{\text{coupling}} + \mathcal{F}_{\text{thermal}}$$

### 2.1 Explicit Components
1. **Phonon Strain Energy:**
$$\mathcal{F}_{\text{phonon}} = \frac{1}{2}C_{11}(\varepsilon_{xx}^2 + \varepsilon_{zz}^2) + C_{12}\varepsilon_{xx}\varepsilon_{zz} + 2C_{66}\varepsilon_{xz}^2$$
where $\varepsilon_{xx} = u_{x,x}$, $\varepsilon_{zz} = u_{z,z}$, and $\varepsilon_{xz} = \frac{1}{2}(u_{x,z} + u_{z,x})$.

2. **Phason Strain Energy:**
$$\mathcal{F}_{\text{phason}} = \frac{1}{2}K_1(w_{x,x}^2 + w_{z,z}^2) + K_2 w_{x,x}w_{z,z} + \frac{1}{2}K_3(w_{x,z}^2 + w_{z,x}^2) + K_6 w_{x,z}w_{z,x}$$
where $w_{x,x} = \partial_x w_x$, $w_{z,z} = \partial_z w_z$, $w_{x,z} = \partial_z w_x$, $w_{z,x} = \partial_x w_z$.

3. **Phonon-Phason Coupling Energy:**
$$\mathcal{F}_{\text{coupling}} = R_1(\varepsilon_{xx}w_{x,x} + \varepsilon_{zz}w_{z,z}) + R_2(\varepsilon_{xx}w_{z,z} + \varepsilon_{zz}w_{x,x}) + 2R_6\varepsilon_{xz}(w_{x,z} + w_{z,x})$$

4. **Thermoelastic Coupling Energy:**
$$\mathcal{F}_{\text{thermal}} = -\beta_1 \theta (\varepsilon_{xx} + \varepsilon_{zz}) - \frac{\rho c_e}{2 T_0}\theta^2$$

---

## 3. Derivation of Constitutive Equations

By variational thermodynamics, the generalized stresses are obtained by differentiation:
$$\sigma_{ij} = \frac{\partial \mathcal{F}}{\partial \varepsilon_{ij}}, \qquad H_{ij} = \frac{\partial \mathcal{F}}{\partial w_{i,j}}$$

### 3.1 Phonon Stresses (Manuscript Eqs. 1–3)
1. **Normal stress $\sigma_{xx}$:**
$$\sigma_{xx} = \frac{\partial \mathcal{F}}{\partial \varepsilon_{xx}} = C_{11}\varepsilon_{xx} + C_{12}\varepsilon_{zz} + R_1 w_{x,x} + R_2 w_{z,z} - \beta_1 \theta$$
*(Identical to Eq. 1 in FINAL_MANUSCRIPT.tex)* — **PASS**

2. **Normal stress $\sigma_{zz}$:**
$$\sigma_{zz} = \frac{\partial \mathcal{F}}{\partial \varepsilon_{zz}} = C_{12}\varepsilon_{xx} + C_{11}\varepsilon_{zz} + R_2 w_{x,x} + R_1 w_{z,z} - \beta_1 \theta$$
*(Identical to Eq. 2 in FINAL_MANUSCRIPT.tex)* — **PASS**

3. **Shear stress $\sigma_{xz}$:**
$$\sigma_{xz} = \frac{1}{2}\frac{\partial \mathcal{F}}{\partial \varepsilon_{xz}} = 2C_{66}\varepsilon_{xz} + R_6(w_{x,z} + w_{z,x}) = C_{66}(\partial_z u_x + \partial_x u_z) + R_6(\partial_z w_x + \partial_x w_z)$$
*(Identical to Eq. 3 in FINAL_MANUSCRIPT.tex)* — **PASS**

### 3.2 Phason Pseudo-Stresses (Manuscript Eqs. 4–7)
1. **Normal phason stress $H_{xx}$:**
$$H_{xx} = \frac{\partial \mathcal{F}}{\partial w_{x,x}} = R_1\varepsilon_{xx} + R_2\varepsilon_{zz} + K_1 w_{x,x} + K_2 w_{z,z}$$
*(Identical to Eq. 4 in FINAL_MANUSCRIPT.tex)* — **PASS**

2. **Normal phason stress $H_{zz}$:**
$$H_{zz} = \frac{\partial \mathcal{F}}{\partial w_{z,z}} = R_2\varepsilon_{xx} + R_1\varepsilon_{zz} + K_2 w_{x,x} + K_1 w_{z,z}$$
*(Identical to Eq. 5 in FINAL_MANUSCRIPT.tex)* — **PASS**

3. **Cross phason stress $H_{xz}$ ($w_{x,z} = \partial_z w_x$):**
$$H_{xz} = \frac{\partial \mathcal{F}}{\partial w_{x,z}} = 2R_6\varepsilon_{xz} + K_3 w_{x,z} + K_6 w_{z,x} = R_6(\partial_z u_x + \partial_x u_z) + K_3 \partial_z w_x + K_6 \partial_x w_z$$
*(Identical to Eq. 6 in FINAL_MANUSCRIPT.tex)* — **PASS**

4. **Cross phason stress $H_{zx}$ ($w_{z,x} = \partial_x w_z$):**
$$H_{zx} = \frac{\partial \mathcal{F}}{\partial w_{z,x}} = 2R_6\varepsilon_{xz} + K_6 w_{x,z} + K_3 w_{z,x} = R_6(\partial_z u_x + \partial_x u_z) + K_6 \partial_z w_x + K_3 \partial_x w_z$$
*(Identical to Eq. 7 in FINAL_MANUSCRIPT.tex)* — **PASS**

---

## 4. Forensic Investigation of Phason Stress Asymmetry ($H_{xz} \neq H_{zx}$)

### 4.1 Mathematical Difference
Subtracting Eq. (7) from Eq. (6):
$$H_{xz} - H_{zx} = (K_3 - K_6)(\partial_z w_x - \partial_x w_z)$$
Substituting $K_6 = K_1 - K_2 - K_3$:
$$H_{xz} - H_{zx} = (2K_3 - K_1 + K_2)(\partial_z w_x - \partial_x w_z)$$

### 4.2 Physical Justification
1. **Non-symmetric strain conjugate:** Phonon stress $\sigma_{ij}$ is conjugate to symmetric strain tensor $\varepsilon_{ij} = \frac{1}{2}(\partial_j u_i + \partial_i u_j)$, forcing $\sigma_{ij} = \sigma_{ji}$. In contrast, phason pseudo-stress $H_{ij}$ is conjugate to the general displacement gradient $w_{i,j} = \partial_j w_i$, which possesses no intrinsic rotational symmetry.
2. **Hexagonal symmetry representation:** In 2D hexagonal quasicrystals, phason rotations transform inversely compared to phonon rotations. The quadratic phason energy contains independent invariants for $(\partial_z w_x)^2 + (\partial_x w_z)^2$ (weighted by $K_3$) and $\partial_z w_x \partial_x w_z$ (weighted by $K_6$).
3. **Preservation in Solver:** In `solver/matrix.py`, the cross-derivatives entering the secular matrix $M(p,k,\omega)$ preserve $K_3$ and $K_6$ independently in $A_1(3,4) = -(K_2+K_6)k$ and $A_1(4,3) = -(K_2+K_6)k$, and $A_2(3,3) = K_3, A_0(4,4) = K_3 k^2$. Artificially setting $H_{xz} = H_{zx}$ or replacing $K_3$ and $K_6$ with their average would unphysically alter the bulk and surface wave dispersion.

---

## 5. Passivity of Piezoelectric Coupling in Configuration I

For point group $6mm$, the piezoelectric tensor in Voigt notation has non-zero entries $e_{15} = e_{24}$, $e_{31} = e_{32}$, and $e_{33}$ (where axis 3 is along the periodic direction $y$).
- Sagittal motion has $u_y = 0$, $w_y = 0$, and $\partial/\partial y = 0$.
- Shear strains $\varepsilon_{xy} = \varepsilon_{13} = 0$, $\varepsilon_{yz} = \varepsilon_{23} = 0$.
- In-plane electric displacements $D_x = D_1 = 2 e_{15}\varepsilon_{13} - \kappa_{11}\partial_x \phi = -\kappa_{11}\partial_x \phi$.
- $D_z = D_2 = 2 e_{15}\varepsilon_{23} - \kappa_{11}\partial_z \phi = -\kappa_{11}\partial_z \phi$.
- Gauss's law $\nabla \cdot \mathbf{D} = -\kappa_{11}(\partial_{xx} \phi + \partial_{zz}\phi) = 0 \implies \nabla^2 \phi = 0$.
Thus, the electric potential $\phi$ decouples completely from sagittal mechanical/thermal fields $(u_x, u_z, w_x, w_z, \theta)$ in Configuration I. The manuscript's statement that piezoelectricity is passive in this cut is mathematically exact and physically sound.

---

## 6. Dimensional and Unit Consistency Audit

| Quantity | Symbol | SI Units | Dimensions ($M, L, T, \Theta$) | Consistent? |
|---|---|---|---|---|
| Phonon displacement | $u_x, u_z$ | $\text{m}$ | $[L]$ | PASS |
| Phason displacement | $w_x, w_z$ | $\text{m}$ | $[L]$ | PASS |
| Phonon strain | $\varepsilon_{ij}$ | $-$ | $[1]$ | PASS |
| Phason gradient | $w_{i,j}$ | $-$ | $[1]$ | PASS |
| Phonon elastic stiffness | $C_{ijkl}$ | $\text{Pa} = \text{N/m}^2$ | $[M L^{-1} T^{-2}]$ | PASS |
| Phason elastic stiffness | $K_{ijkl}$ | $\text{Pa} = \text{N/m}^2$ | $[M L^{-1} T^{-2}]$ | PASS |
| Phonon-phason coupling | $R_{ijkl}$ | $\text{Pa} = \text{N/m}^2$ | $[M L^{-1} T^{-2}]$ | PASS |
| Temperature increment | $\theta$ | $\text{K}$ | $[\Theta]$ | PASS |
| Thermal stress coefficient | $\beta_1$ | $\text{Pa/K}$ | $[M L^{-1} T^{-2} \Theta^{-1}]$ | PASS |
| Phonon stress | $\sigma_{ij}$ | $\text{Pa}$ | $[M L^{-1} T^{-2}]$ | PASS |
| Phason pseudo-stress | $H_{ij}$ | $\text{Pa}$ | $[M L^{-1} T^{-2}]$ | PASS |
| Energy density | $\mathcal{F}$ | $\text{J/m}^3 = \text{Pa}$ | $[M L^{-1} T^{-2}]$ | PASS |

---

## 7. Traceability to Source Code

| Mathematical Term | Manuscript Eq. | Source Code File & Function | Implementation Status |
|---|---|---|---|
| $C_{66} = (C_{11}-C_{12})/2$ | Eq. (8) | `solver/material.py:derive_starred` | EXACT MATCH |
| $K_6 = K_1-K_2-K_3$ | Eq. (8) | `solver/material.py:derive_starred` | EXACT MATCH |
| $R_6 = (R_1-R_2)/2$ | Eq. (8) | `solver/material.py:derive_starred` | EXACT MATCH |
| $\sigma_{xx}, \sigma_{zz}, \sigma_{xz}$ | Eqs. (1–3) | `solver/matrix.py:assemble_M`, `solver/boundary.py` | EXACT MATCH |
| $H_{xx}, H_{zz}, H_{xz}, H_{zx}$ | Eqs. (4–7) | `solver/matrix.py:assemble_M`, `solver/boundary.py` | EXACT MATCH |
| $H_{xz} \neq H_{zx}$ asymmetry | Section 2.1 | `solver/matrix.py` ($A_0, A_1, A_2$) | EXACT MATCH |

---

## 8. Phase 2 Forensic Conclusion

Every constitutive equation, symmetry relation, and material constant in Section 2 of `FINAL_MANUSCRIPT.tex` is mathematically derived from the free energy density of 2D hexagonal quasicrystals, verified against foundational literature (Yang et al. 2014, Ding et al. 2000, Fan 2011), and proven to be implemented with exact dimensional, sign, and index fidelity in the Python solver.
