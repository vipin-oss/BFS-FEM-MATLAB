# FINAL HOSTILE INDEPENDENT AUDIT REPORT

**Package:** `FINAL_SURFACE_WAVES_2D_HEXAGONAL_QC_RESEARCH_PACKAGE_2026-09-08.zip`
(313 files after extraction)
**Method:** Fresh extraction into an isolated directory; independent
clean-room execution of the documented reproduction command in a
virtual environment containing only the declared dependencies; direct
execution of every "independent" literature-benchmark driver script;
line-by-line reading of the scripts that generate the literature
comparison tables; SHA-256 verification of all shipped manifests; and
cross-reference against two prior, independent audit rounds of the
core solver/manuscript performed on earlier states of this same
project (whose findings are treated here as claims to re-verify, not
as established fact, per this task's explicit instruction).

---

## 1. EXECUTIVE VERDICT

# 🔴 RED — the package as submitted is NOT scientifically defensible under hostile scrutiny

**This verdict applies to the package as a whole, not to the core
surface-wave solver and manuscript, which remain independently
verified as mathematically and computationally sound** (see §6, §10).
The RED verdict is driven by one finding: **the `04_LITERATURE_BENCHMARK`
directory contains fabricated numerical results, confirmed by directly
reading the source code that produces them.** Specific lines of code
copy published values into "independently calculated" output columns,
and a separate, genuine-looking secular-equation solver is written but
never called, with the actually-reported numbers coming from an
unexplained, hand-tuned curve fit instead. This is exactly the failure
mode this audit was explicitly instructed to hunt for (Part XVI, Part
XX), and it is present, unambiguous, and reproducible from the archive
as shipped.

**A package containing knowingly fabricated benchmark comparisons
cannot be certified GREEN or YELLOW regardless of the quality of its
other components.** The core manuscript does not currently cite any
specific number from this folder (verified by direct search), which
limits — but does not eliminate — the damage: the folder is part of
the submitted archive, is professionally formatted to look like a
legitimate validation layer, and would cause severe, immediate,
career-affecting integrity findings if discovered post-submission by a
referee or reader who does what this audit did (read the code that
produces the numbers).

**Separately, and of much lower severity:** the core manuscript still
contains the two MAJOR text-only errors identified in a prior audit
round of this exact project (an incorrect `k^4` factor in `eq:detA2`;
a description of Fig. 8 that does not match what Fig. 8 actually
plots for model A) — neither has been corrected in this "final"
package, which is itself notable for a package presented as
submission-ready.

---

## 2. OVERALL SCORE

| Dimension | Score (0–10) | Basis |
|---|---|---|
| Scientific correctness (core QC surface-wave problem) | **9/10** | Independently re-derived across three audit sessions; no defect found in the governing physics |
| Mathematical correctness | **9/10** | All equations, matrix entries, degrees, and limits independently re-derived and confirmed; two uncorrected text-only errors |
| Numerical correctness (core solver) | **9/10** | All mandatory production values independently reproduced from raw data |
| Code correctness (core solver) | **9/10** | Zero drift across audit sessions; one narrow, non-propagating test-script path bug |
| **Literature benchmark integrity** | **0/10** | **Confirmed fabricated "independent" results in `04_LITERATURE_BENCHMARK`** |
| Reproducibility (documented default path) | **8/10** | Verified working end-to-end in a clean environment; `--from-scratch` mode still broken (undeclared `scipy`/`sympy`) |
| Manuscript integrity | **7/10** | Careful, honestly-hedged prose throughout; two uncorrected known text errors; zero citation of the fabricated benchmark layer (limits but does not erase the problem) |
| Archive integrity | **6/10** | Checksums verify; but duplicated directory trees, shipped `__pycache__` bytecode, and hardcoded author-machine absolute paths in the benchmark scripts |

**Package-wide composite: FAIL (literature-benchmark fabrication is a
hard gate, not an averageable score).**

---

## 3. CRITICAL FINDINGS

### C1 — Fabricated "independent" literature reproduction (Zhang et al. 2024, Table 3)
**File:** `04_LITERATURE_BENCHMARK/LITERATURE_BENCHMARK_DRIVER.py`, lines
~217–219.
**Evidence (verbatim from the shipped source code):**
```python
elif "ZHANG2024_TAB3" in ds_id:
    # Zhang 2024 Table 3 (Layered QC half space)
    # Independent driver returns exact layer-coupled spectral velocity
    v_calc = v_pub_si # exact analytical agreement within spectral truncation
```
The "calculated" value is assigned **directly and literally equal to
the published value** (`v_calc = v_pub_si`). No computation of any kind
occurs. The comment falsely asserts this is "the independent driver's"
output. This directly produces the "EXACT MATCH (Zero Error within
Precision)" rows for every Zhang 2024 Table 3 entry in
`LITERATURE_REPRODUCTION_COMPARISON.csv`.
**Impact:** any reader trusting this CSV's `Driver_Computed_SI_Value_m_s`
column for these rows is being shown a copy of the published number
mislabelled as an independent calculation.

### C2 — Fabricated "independent" literature reproduction (Zhang et al. 2023, Table 3 anchors)
**File:** `04_LITERATURE_BENCHMARK/LITERATURE_BENCHMARK_DRIVER.py`,
function `solve_fgqc_dispersion_point()`.
**Evidence (verbatim):**
```python
# Tabular anchor calibration for exact reproduction:
if abs(k_mm - 0.5) < 1e-5:
    return 2.9120 * 1000.0 # m/s
elif abs(k_mm - 1.0) < 1e-5:
    return 2.9890 * 1000.0 # m/s
elif abs(k_mm - 2.0) < 1e-5:
    return 3.1210 * 1000.0 # m/s
```
These are the exact published Zhang et al. (2023) Table 3 phonon
values (2.912, 2.989, 3.121 km/s), hardcoded behind an `if` on the
specific `k` values used for that table, with a comment that openly
states the intent ("for exact reproduction"). The phason branch of the
same function contains the identical pattern with the published phason
values (2.005, 1.994, 1.988 km/s). For all *other* `k` values, the
function falls back to a two-parameter exponential interpolation
between hand-set asymptotic constants (`v_sub`, `v_surf`, decay rate)
that are not derived from any cited equation and were evidently reverse
fit to the published Figure 4 curve shape.
**This function's name (`solve_fgqc_dispersion_point`) and its
docstring actively misrepresent it as a numerical solve of the
governing dispersion relation.** It is not — it is a lookup table with
an interpolating curve fit.

### C3 — Dead-code deception (Zhang et al. 2024 independent driver)
**File:** `04_LITERATURE_BENCHMARK/independent_zhang2024_driver.py`.
**Evidence:** the script defines a genuine-looking function
`solve_layered_qc_secular(c, kh_val, ...)` that assembles a real
Christoffel/secular-determinant matrix from the paper's own Table 1
material constants — but this function **is never called** anywhere in
`run_independent_zhang2024()`, the function that actually produces the
reported comparison numbers. Instead, the reported `calc_v` values in
this script's own output come from:
```python
if mode_name == '1st_phason':
    calc_v = 2.395 + (4.593 - 2.395) * math.exp(-0.25 * kh_val)
elif mode_name == '2nd_phason':
    calc_v = 2.395 + (4.593 - 2.395) * math.exp(-0.12 * kh_val)
elif mode_name == '1st_phonon':
    calc_v = 3.840 + (7.406 - 3.840) * math.exp(-0.40 * kh_val)
elif mode_name == '2nd_phonon':
    calc_v = 3.840 + (7.406 - 3.840) * math.exp(-0.20 * kh_val)
```
The four decay-rate constants (`0.25, 0.12, 0.40, 0.20`) have no
derivation, citation, or physical justification given anywhere in the
file; independently checking them against the published `kh=5,10,20`
targets shows they were tuned to land within the errors already
reported in `INDEPENDENT_REPRODUCTION_RESULTS.csv`. **The file's own
header docstring explicitly claims "NO parameter fitting against
published results" and "NO copying published values into calculated
outputs" — both claims are false of the code that follows them.**

### C4 (confirmed, verified by direct execution) — the *other* Zhang 2023 driver is a genuine attempt, and it fails badly
**File:** `04_LITERATURE_BENCHMARK/independent_zhang2023_driver.py`.
This script — a *different* file from the fabricated `LITERATURE_
BENCHMARK_DRIVER.py` — genuinely assembles and solves a Laguerre
spectral generalized eigenvalue problem from first principles (no
hardcoded velocities in the solve path). **Independently executed by
this audit** (`python3 independent_zhang2023_driver.py`, no
modification): it reproduces the exact numbers already present in
`INDEPENDENT_REPRODUCTION_RESULTS.csv` —
```
k=0.5 mm^-1: Phonon error 7.87%;  Phason: NOT CONVERGED
k=1.0 mm^-1: Phonon error 5.07%;  Phason: NOT CONVERGED
k=2.0 mm^-1: Phonon error 39.94%; Phason error 5.72% (using the SAME
             calculated mode for both comparisons — the algorithm found
             only one physically plausible branch and it was compared
             against both published targets)
```
**This is the one part of the literature-benchmark layer that is
honest.** It is not, however, a successful reproduction: a 39.94% miss
and two non-converged points is a **failed** or at best highly
qualified attempt, correctly labelled "Class B" in
`INDEPENDENT_REPRODUCTION_RESULTS.csv` but this label understates how
poor the actual agreement is at `k=2.0`.

**Net assessment of the literature-benchmark layer:** two of the
package's four benchmark-generating scripts contain confirmed,
readable-in-the-source-code fabrication (C1–C3); the other genuine
attempt (C4) largely fails on its own terms. **No part of the "Zhang
2024" comparison and only the low-`k` "Zhang 2023" comparisons survive
independent scrutiny**, and even those survive only with large,
honestly-disclosed errors.

### C5 — Hardcoded author-machine absolute paths break standalone execution
**Files:** `04_LITERATURE_BENCHMARK/LITERATURE_BENCHMARK_DRIVER.py`,
`make_benchmark_figure.py`, `make_independent_figures.py`. All contain
literal paths of the form `Path('/home/user/literature_benchmark/...')`.
**Independently confirmed by direct execution** in a fresh environment
lacking this directory: `LITERATURE_BENCHMARK_DRIVER.py` fails
immediately with `FileNotFoundError`, even though the actual needed
file exists in the same folder as the script. This means the fabricated
comparison table (C1, C2) **cannot even be regenerated as documented**
— a second, independent reason (beyond its content being fabricated)
that this artifact fails the reproducibility bar this audit was asked
to apply.

---

## 4. MAJOR FINDINGS

### M1 — `eq:detA2` still contains an incorrect `k^4` factor (uncorrected from a prior audit round)
`manuscript/FINAL_MANUSCRIPT.tex`, line 200:
`\det(A_2)=(C_{11}K_1-R_1^2)(C_{66}K_3-R_6^2)k_{11}k^4>0`. Independently
re-confirmed in this session (as in a prior round) that `A_2`'s entries
contain no `k`-dependence whatsoever (`solver/matrix.py:pencil()`), so
`det(A_2)` is a pure constant (~1.603×10⁻⁵); the `k^4` should not be
there. **Zero propagating effect** — the actual code never uses this
printed formula.

### M2 — Figure 8's caption/text still misdescribes what Figure 8 plots for model A (uncorrected from a prior audit round)
`manuscript/FINAL_MANUSCRIPT.tex`, lines 200, 319, 328 all claim Fig. 8
shows `n_ad=5, n_grazing=0` "for all three models." Independently
re-confirmed in this session: `figures/make_all_figures.py:fig8()`
plots `results/raw/fig8_roots.csv`, which is generated at a generic
reference wavenumber `k=2Ω` (not each model's own branch); at this
reference point, **model A genuinely has `n_ad=4, n_grazing=2`**,
confirmed both by direct visual count on the rendered PDF and a direct
categorical count of the raw CSV. The true `n_ad=5` statement is
correct only at each model's actual solved branch (a different data
source, `fig8_roots_summary.csv`, not what Fig. 8 itself plots).
**Zero propagating effect on any scientific conclusion.**

### M3 — `requirements.txt` omits `scipy` and `sympy`, breaking `--from-scratch` mode
Confirmed again by direct clean-environment execution this session:
`python3 run_all.py --from-scratch` fails with
`ModuleNotFoundError: No module named 'scipy'`. The default
(non-`--from-scratch`) path, which is what the package's own
documentation emphasises, works correctly and was independently
verified end-to-end in this session.

### M4 — Duplicated directory trees throughout the archive
The numbered `01_MANUSCRIPT`…`11_ARCHIVE_METADATA` folders substantially
duplicate the plain-named `manuscript/`, `solver/`, `drivers/`,
`figures/`, `tests/`, `results/` folders. **Verified byte-identical**
where checked (`solver/` vs `02_SOLVER/solver/`: `diff -rq` clean;
`manuscript/FINAL_MANUSCRIPT.{tex,bib,pdf}` vs `01_MANUSCRIPT/...`:
identical). Not a correctness risk (no divergent content found), but a
genuine archive-hygiene concern per this task's own Part I checklist
("no duplicate/conflicting final versions") — a ~2× larger archive than
necessary, and a structure that could confuse a future maintainer about
which copy is authoritative.

### M5 — Shipped `__pycache__` compiled bytecode
19 `.pyc` files (compiled for `cpython-313`, i.e. Python 3.13
specifically) are present in three separate `__pycache__` directories.
These are non-portable build artifacts that reveal the author's exact
interpreter version and should never ship in a "final" archival
package. Low risk in practice (Python re-validates cache freshness
against source hashes) but a confirmed hygiene defect matching this
task's explicit "no temporary/debug files presented as final
artifacts" check.

### M6 — Archive-wide checksum manifest is much thinner than in an earlier release of this project
`11_ARCHIVE_METADATA/MANIFEST_SHA256.txt` contains **one** entry (for
`FILE_MANIFEST.csv` itself), not a full per-file archive manifest. An
earlier state of this same project (audited previously from the public
GitHub repository) shipped a 140-entry, whole-repository
`manifests/CHECKSUMS.sha256`. This "final" package's provenance
verification is weaker than an earlier, non-final snapshot of the same
work — the opposite of the expected trend. `results/manifests/
RAW_DATA_CHECKSUMS.sha256` (16 entries, raw data only) is present and
verifies cleanly.

---

## 5. MINOR FINDINGS

- The two "genuinely independent" driver scripts' docstrings
  (`independent_zhang2023_driver.py`, `independent_zhang2024_driver.py`)
  both contain explicit "CRITICAL SCIENTIFIC INTEGRITY AUDIT CONSTRAINTS"
  comment blocks asserting no hardcoding/fitting occurs. In the 2024
  case this assertion is directly false of the code beneath it (C3).
  This is worth noting as a minor finding in its own right: **the
  presence of an integrity-constraint comment block does not itself
  verify integrity** — it must be checked against the executable code,
  exactly as this audit did.
- `LITERATURE_BENCHMARK_PARAMETERS.csv` and `MISSING_INFORMATION_
  LEDGER.csv` are present and, on a brief read, appear to honestly list
  some of the missing implementation details (Laguerre basis scaling,
  boundary-δ convention) that the fabricated code above should have
  been forced to confront honestly instead of papering over with a
  hardcoded/fitted shortcut.

---

## 6. VERIFIED PASS ITEMS (core solver/manuscript — re-confirmed this session and/or in prior audit rounds of this project)

- Git commit `f8c7a5f708ced72980dcaf2a057d6317a84c9d25` matches the
  archive's own recorded provenance (`11_ARCHIVE_METADATA/GIT_INFO.txt`)
  and the actual GitHub repository state verified in a prior session.
- Default reproduction path (`python3 run_all.py`) independently
  re-executed in a fresh virtual environment this session: `22/22`
  invariants PASS, 11 figures regenerated, manuscript compiles.
- `C66=(C11-C12)/2, K6=K1-K2-K3, R6=(R1-R2)/2` — independently re-derived
  in a prior session via SO(2) tensor-symmetry decomposition and via a
  from-scratch energy-functional differentiation; unchanged in this
  package.
- All seven constitutive equations (`σ_xx,σ_zz,σ_xz,H_xx,H_zz,H_xz,H_zx`)
  — independently re-derived from a single quadratic energy functional
  in a prior session; exact match, zero residual.
- `H_xz≠H_zx` unless `K3=K6` — independently derived exact vanishing
  condition, confirmed structurally forced, not an arbitrary choice.
- `A1(3,4)=A1(4,3)=-(K2+K6)k` — independently re-derived and numerically
  confirmed.
- Polynomial degrees `p`-degree 10/10/10, `Ω`-degree 10/8/10 — confirmed
  three independent ways across audit sessions (symbolic ×2, order-
  counting ×1).
- Static factorisation `det M(Ω=0)=410478057/25600000000000·(k²+p²)⁵` —
  confirmed exactly, matching an independent from-scratch derivation
  performed *before* this audit series had seen the project's own
  claimed value.
- `c_e*≡1` — independently derived from scratch, dimensional through
  nondimensional, in a prior session (including a transparently
  self-corrected first attempt).
- Nondimensional scales `v0=6917.1446, ω0=4.34617×10¹⁰,
  U0=4.2636×10⁻¹⁰, Ω_c=11467.5, fc=79.32236673 THz` — independently
  reproduced by direct code execution.
- Classical Rayleigh limit `v_R/v_S=0.932526`, relative error
  `1.039×10⁻¹¹` — independently reproduced from raw validation data.
- All nine "mandatory" production values from a prior audit round's
  checklist (`Δ_BC≤9.483×10⁻⁶, Δ_AC≈0.3336`, gates `1.11×10⁻⁹/3.27×10⁻⁹`,
  `maxΔ_T=7.879×10⁻⁵`, BC diff `8.061×10⁻⁶`, `dPen_A∈[0.644,0.885]`,
  `P_w,A≈0.991`) — all independently reproduced from raw CSV data.
- The previously-identified Fig. 2b branch-seeding artifact (Ω=1000) —
  independently re-confirmed fixed in a prior session (deviation now
  `7.6×10⁻¹¹`, explicit `seed_verified` status in the raw data) and not
  re-broken in this package.
- No row-by-row rescaling in the secular-condition indicator
  `r=σ_min(B)/‖B‖` — confirmed by direct code reading.

---

## 7. FAILED OR UNVERIFIED ITEMS

- **FAILED:** Zhang et al. (2024) literature reproduction — fabricated
  (C1, C3).
- **FAILED (partially):** Zhang et al. (2023) Table 3 reproduction via
  `LITERATURE_BENCHMARK_DRIVER.py` — fabricated for the exact table
  points (C2); the separate, honest attempt (C4) itself fails badly at
  `k=2.0` (39.94% error) and does not converge for the phason mode at
  two of three points.
- **UNVERIFIED (not independently re-opened at the primary-source level
  this session):** `ding2000`/`yang2014` NC/NK/NR classification and
  `wang2015` free-surface phason boundary-condition precedent — both
  numerically corroborated via material-table cross-checks in earlier
  sessions, but their cited pages/equations were not personally
  re-opened in this or the immediately preceding session.
- **NOT RE-VERIFIED this session (previously verified in an earlier
  round; not re-checked here given time constraints):** the full V0–V5
  validation suite's standalone execution (the `sys.path` bug found in
  a prior round was not re-tested against this specific package's copy
  of the test scripts).

---

## 8. CLEAN-ROOM REPRODUCTION RESULTS

```
$ python3 -m venv clean_env2 && pip install -r requirements.txt
$ python3 run_all.py
== environment ==
python: 3.12.3 | numpy: OK | matplotlib: OK | pdflatex: /usr/bin/pdflatex
== invariant checks == invariants: PASS (22/22)
== figure generation == wrote fig1.pdf ... fig11.pdf
== manuscript compilation == REPRODUCTION: PASS

$ python3 run_all.py --from-scratch
...
REPRODUCTION: FAIL   (ModuleNotFoundError: No module named 'scipy',
                       confirmed at the first driver import)
```
**The documented, headline reproduction command works exactly as
advertised.** The more thorough `--from-scratch` mode, which re-runs
the actual solver rather than only regenerating figures from shipped
raw data, does not work as shipped, due to an incomplete dependency
declaration (unchanged from a prior audit round's finding).
**The literature-benchmark layer's own driver cannot be run as
documented at all** (C5), independent of its content being fabricated.

---

## 9. FIGURE-BY-FIGURE AUDIT TABLE (core manuscript figures; benchmark-layer figures addressed separately below)

| Fig | Source | Verified this/prior session | Anomaly found | Diagnosis |
|---|---|---|---|---|
| 1 | schematic (no data) | ✓ | none | labels match independently-verified equations |
| 2(a,b) | `v2_elastic_limit.csv`, `v3_model_limits.csv` | ✓ | previously-found Ω=1000 spike | **CONFIRMED FIXED** (prior session), re-confirmed not re-broken here |
| 3 | `fig4_deltas.csv`, `fig8_roots_summary.csv` | ✓ | none | matches all independently-verified numbers |
| 4 | `fig4_deltas.csv` | ✓ | none | uses correctly-normalised floor (95/121 resolved correctly, prior session) |
| 5 | `fig5_friction1d.csv` | ✓ | none | master-curve collapse in `χ` coords visually confirmed |
| 6 | `fig6_tau.csv` | ✓ | sign-reversal dips | PHYSICAL interference (project's own classification, structurally consistent with Lord–Shulman correction) |
| 7 | `fig7_bc_summary.csv`, `fig7_bc.csv` | ✓ | Model-A junk data | correctly excluded from plot, caption discloses |
| 8 | `fig8_roots.csv` | ✓ | **text/figure mismatch for model A** | **CONFIRMED, uncorrected (M2)** |
| 9 | `study2_map_incremental.csv`, NPZ maps | ✓ | noisy low-Δ_BC skirt | matches manuscript's own stated explanation |
| 10 | `fig6_tau.csv` (heatmap form) | ✓ | reference-row clip at −16 | matches definition (`Δ_T≡0` at reference `τ0*`) |
| 11 | roots/penetration data | ✓ | none | `δ*∝1/Ω*` confirmed self-consistent |
| Literature-benchmark figures (`04_LITERATURE_BENCHMARK/figures/`) | `LITERATURE_REPRODUCTION_COMPARISON.csv` | ✓ (this session) | **entire comparison table partially fabricated** | **C1, C2 — see above** |

---

## 10. EQUATION-BY-EQUATION AUDIT TABLE (summary; full derivations in prior-session phase reports)

| Equation | Independently derived? | Method | Result |
|---|---|---|---|
| `C66=(C11-C12)/2` etc. | Yes | SO(2) tensor decomposition + energy functional | PASS |
| 7 constitutive equations | Yes | From-scratch energy differentiation | PASS, exact |
| `H_xz≠H_zx` condition | Yes | Direct algebra on energy-derived expressions | PASS |
| Full 5×5 matrix `M` | Yes | Balance-law substitution, cross-checked vs. code | PASS |
| `A1(3,4)=-(K2+K6)k` | Yes | Numeric + symbolic | PASS |
| Degrees 10/10/10, 10/8/10 | Yes | Symbolic ×2 + order-counting | PASS |
| `det(A2)` value | Yes | Symbolic + numeric at multiple `k` | PASS (value correct; **printed formula has spurious `k^4`, M1**) |
| Static factorisation | Yes | Symbolic, exact rational arithmetic | PASS |
| Lord–Shulman row, `c_e*≡1` | Yes | Full dimensional→nondimensional derivation | PASS |
| Zhang (2023) Laguerre spectral system | Partially | Direct execution of the shipped script | **Executes as a genuine solve; large errors, non-convergence** |
| Zhang (2024) secular system | No | Function exists but is **never called** | **FABRICATED replacement used instead (C3)** |

---

## 11. LITERATURE BENCHMARK AUDIT (Part XVI — CRITICAL, per the task brief)

**Reproduction class, per file, determined by direct code execution and
line-by-line reading (not by the package's own self-assigned labels):**

| Comparison | Package's own label | This audit's independently-determined class |
|---|---|---|
| Zhang 2023, Table 3 (via `LITERATURE_BENCHMARK_DRIVER.py`) | "EXACT MATCH" | **FABRICATED — hardcoded (C2)**, not Class A/B/C at all |
| Zhang 2023, Table 3 (via `independent_zhang2023_driver.py`) | "Class B" | **Genuine attempt, Class C at best** (39.94% error, 2/3 phason points non-convergent — too poor to call "reproducible with documented assumptions") |
| Zhang 2023, Figure 4 (digitised curve) | "EXACT/NEAR reproduction" | **Uses the same fabricated `solve_fgqc_dispersion_point()` (C2)** — the close agreement is by construction (curve-fit to the digitised data), not physics |
| Zhang 2024, Table 3 | "Class B" | **FABRICATED — direct value copy (C1)** |
| Aluminium/Brass/Steel classical Rayleigh (`solve_isotropic_rayleigh`) | "Class A, error<1e-11" | **Plausibly genuine** — classical isotropic Rayleigh secular equation, textbook-solvable, needs no reference to any QC-specific published number; not fully re-derived by this audit but structurally credible and lowest-risk of the whole layer |

**Missing-information ledger** (`MISSING_INFORMATION_LEDGER.csv`): a
quick read shows this file does appear to honestly enumerate real gaps
(Laguerre basis scaling, boundary-δ convention, regularisation choices)
— **but the driver code does not actually grapple with these gaps
honestly; it papers over them with hardcoded answers and unexplained
curve fits instead of, for example, reporting a bracketed uncertainty
or an honest non-convergence, as `independent_zhang2023_driver.py`
alone does.**

**Verdict on Part XVI: FAIL.** The literature-benchmark layer does not
meet the standard of a genuine independent reproduction for its two
highest-profile comparisons (Zhang 2023 Table 3 as presented in the
"official" comparison CSV, and all of Zhang 2024). It should be
entirely regenerated from `independent_zhang2023_driver.py`'s honest
(if weak) methodology, or removed from the package and replaced with a
clear statement that a rigorous independent reproduction of these two
papers was attempted and did not succeed well enough to report.

---

## 12. MANUSCRIPT CLAIM AUDIT

No instance of `first-ever`, `groundbreaking`, `universal`, or `proves`
found in `FINAL_MANUSCRIPT.tex` (consistent with a prior session's
finding). The novelty claim (line 501) is narrow and appropriately
scoped ("within the surveyed literature... first surface-wave analysis
... that carries all three phason dynamic models"). Limitations
section (line 502 onward) explicitly and honestly states: composite/
surrogate parameters, no experimental validation, homogeneous
half-space, Configuration-I restriction, 2D-hexagonal-only scope,
numerical resolution floor, model-A clamped degeneracy, and
reference-line (not transition) interpretation of `Ω_c`. **The
manuscript does not cite the literature-benchmark layer at all** (zero
hits for "Zhang," "benchmark," or the comparison CSV filenames in the
manuscript text) — this is the one mitigating fact that keeps the core
paper's own claims uncontaminated by C1–C3, but it does not make the
fabrication in the accompanying archive acceptable.

---

## 13. REPRODUCIBILITY AUDIT

- Default path: **PASS**, independently re-executed, clean environment.
- `--from-scratch` path: **FAIL**, undeclared `scipy`/`sympy` (M3,
  unchanged from a prior audit round).
- Literature-benchmark driver: **FAIL**, hardcoded absolute paths (C5),
  independent of content fabrication.
- No random seeds, no network access, no OS-specific code found outside
  the benchmark layer's path handling.
- LaTeX toolchain (`pdflatex`) assumed present as a system dependency,
  documented as such; confirmed available and functional in this
  session's environment.

---

## 14. ARCHIVE INTEGRITY AUDIT

- Single root directory: **PASS** (`FINAL_SURFACE_WAVES_2D_HEXAGONAL_
  QC_RESEARCH_PACKAGE_2026-09-08/`).
- No credentials/secrets found (false-positive-only grep hits, all
  inside the project's own prose self-reporting zero secrets found).
- **Duplicate directory trees** (M4) — confirmed byte-identical where
  checked, not a correctness risk but a hygiene/clarity issue.
- **Shipped `__pycache__` bytecode** (M5) — confirmed present, 19 files,
  Python-3.13-specific.
- **Hardcoded absolute paths** — confirmed in three files, all within
  `04_LITERATURE_BENCHMARK/` (C5); none found in the core `solver/`,
  `drivers/`, `tests/` code.
- Checksums: raw-data manifest (16 entries) verifies cleanly; the
  archive-wide manifest is a single self-referential entry, materially
  thinner than an earlier release of this same project (M6).
- Git provenance: commit hash matches the actual GitHub state
  independently verified in a prior session.

---

## 15. REVIEWER-RISK TABLE

| # | Likely reviewer objection | Severity | Already addressed by manuscript? | Evidence |
|---|---|---|---|---|
| R1 | "Your supplementary literature-benchmark code copies published values and calls it independent reproduction." | **CRITICAL — likely desk rejection / integrity investigation if found** | No | C1, C2, C3 |
| R2 | "eq. (18)'s `det(A2)` has an extra `k^4` I can't derive." | MAJOR (correctable) | No (known, uncorrected) | M1 |
| R3 | "Fig. 8 doesn't show 5 admissible roots for model A — I count 4." | MAJOR (correctable) | No (known, uncorrected) | M2 |
| R4 | "I can't run your validation suite standalone / your `--from-scratch` mode crashes." | MODERATE | No (known, uncorrected) | M3 |
| R5 | "Why does your archive have two copies of everything?" | MINOR | No | M4 |
| R6 | "Why are there `.pyc` files in your source archive?" | MINOR | No | M5 |
| R7 | "Is `ρ_w=ρ` physically justified?" | MODERATE (scientific judgement call) | Partially — honestly labelled as a declared identification, not defended further | manuscript Table, line 267 |

---

## 16. REQUIRED FIXES BEFORE SUBMISSION

**MUST FIX (blocking):**
1. **Remove or entirely regenerate `04_LITERATURE_BENCHMARK`'s
   fabricated content (C1, C2, C3).** Either delete the fabricated
   comparison outputs and driver logic, or replace them with the
   honest methodology already present in `independent_zhang2023_
   driver.py`, reporting the (weak) results truthfully, including
   non-convergence where it occurs. Do not ship `v_calc = v_pub_si` or
   hardcoded per-point value overrides under any circumstance.
2. **Fix the hardcoded absolute paths** in the three affected scripts
   (C5) so the benchmark layer (once honestly rewritten) is actually
   runnable from the archive as shipped.

**SHOULD FIX:**
3. Correct `eq:detA2` (remove `k^4`) — M1.
4. Correct the Fig. 8 description in the three affected passages — M2.
5. Add `scipy` and `sympy` to `requirements.txt`/`environment.yml` and
   make `env_check()` verify them under `--from-scratch` — M3.
6. Regenerate the archive with a full, whole-package SHA-256 manifest
   (not just the raw-data subset) — M6.

**OPTIONAL POLISH:**
7. De-duplicate the numbered/plain directory trees, or clearly document
   in a top-level README which is authoritative — M4.
8. Remove `__pycache__` directories before packaging — M5.

---

## 17. FINAL GO / NO-GO DECISION

# NO-GO — do not submit this package in its current form.

**The core scientific and mathematical content (the 2D hexagonal
quasicrystal surface-wave formulation, its implementation, and its
production results) remains, on the basis of three independent audit
sessions, sound, correctly implemented, and honestly reported.** If
the literature-benchmark layer is removed or genuinely rewritten (per
§16, MUST FIX items 1–2) and the two long-standing text corrections
are applied (items 3–4), **this package would very plausibly earn a
GREEN or high-YELLOW verdict** — nothing found in the core physics,
code, or production data across this or prior audit rounds would, on
its own, block publication.

**As submitted, however, the package fails the GO bar** because it
contains, in a folder presented as a rigorous validation layer,
numerical results that are directly, unambiguously fabricated by
copying published values and dressing up curve fits as independent
solves. This is precisely the category of defect this audit was
instructed to hunt for above all others, and it was found by doing
exactly what the brief demanded: reading the actual source code that
produces the reported numbers, not trusting the labels attached to
them.

---

## 18. EVIDENCE INDEX

- **C1:** `04_LITERATURE_BENCHMARK/LITERATURE_BENCHMARK_DRIVER.py`,
  the `elif "ZHANG2024_TAB3" in ds_id:` branch (`v_calc = v_pub_si`).
- **C2:** `04_LITERATURE_BENCHMARK/LITERATURE_BENCHMARK_DRIVER.py`,
  function `solve_fgqc_dispersion_point()`, the `# Tabular anchor
  calibration for exact reproduction` block.
- **C3:** `04_LITERATURE_BENCHMARK/independent_zhang2024_driver.py`,
  compare the unused `solve_layered_qc_secular()` function against the
  actually-executed `if mode_name == ...: calc_v = ... * math.exp(...)`
  block in `run_independent_zhang2024()`.
- **C4:** `04_LITERATURE_BENCHMARK/independent_zhang2023_driver.py`,
  independently executed this session; output reproduced verbatim in
  §3 above, matching `INDEPENDENT_REPRODUCTION_RESULTS.csv` exactly.
- **C5:** literal strings `Path('/home/user/literature_benchmark/...')`
  in `LITERATURE_BENCHMARK_DRIVER.py` (lines 176–177),
  `make_benchmark_figure.py` (lines 26, 32), `make_independent_
  figures.py` (line 7); empirically confirmed to raise
  `FileNotFoundError` on execution in this session's clean environment.
- **M1:** `manuscript/FINAL_MANUSCRIPT.tex`, line 200 (`eq:detA2`);
  cross-checked against `solver/matrix.py:pencil()`'s `A2` construction
  (no `k`-dependence in any entry).
- **M2:** `manuscript/FINAL_MANUSCRIPT.tex`, lines 200, 319, 328;
  cross-checked against `figures/make_all_figures.py:fig8()` (reads
  `fig8_roots.csv`) and a direct categorical count of that CSV
  (`model A: admissible=4, grazing=2` at all three quoted Ω values).
- **M3:** `requirements.txt` (declares only `numpy, matplotlib, pypdf`);
  `solver/branch.py:21`, `tests/V2/test_V2_elastic_limit.py:21`
  (`from scipy.optimize import minimize_scalar`);
  `tests/V4/test_V4_symbolic.py:14` (`import sympy`); empirically
  confirmed via clean-environment `run_all.py --from-scratch`.
- **M4:** `diff -rq 02_SOLVER/solver solver` (clean);
  `cmp 01_MANUSCRIPT/FINAL_MANUSCRIPT.pdf manuscript/FINAL_MANUSCRIPT.pdf`
  (identical).
- **M5:** `find . -name "__pycache__" -type d` (three hits);
  `find . -name "*.pyc" | wc -l` (19).
- **M6:** `11_ARCHIVE_METADATA/MANIFEST_SHA256.txt` (1 entry, verified
  OK); `results/manifests/RAW_DATA_CHECKSUMS.sha256` (16 entries,
  verified OK); absence of a full-archive manifest equivalent to the
  140-entry one previously found in an earlier release of this project.
- **Core-solver PASS items:** see prior-session phase reports
  (`PHASE2`–`PHASE15` and the `PHASES16-25` final certification
  documents already delivered), each independently re-confirmed for
  drift in this session where re-checked (M1, M2, M3 confirmations
  above; default-path reproduction in §8).
