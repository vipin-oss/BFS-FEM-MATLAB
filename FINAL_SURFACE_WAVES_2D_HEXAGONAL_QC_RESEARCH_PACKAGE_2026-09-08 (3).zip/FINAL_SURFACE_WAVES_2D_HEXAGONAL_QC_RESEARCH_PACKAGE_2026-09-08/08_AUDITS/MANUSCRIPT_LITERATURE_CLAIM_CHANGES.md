# MANUSCRIPT_LITERATURE_CLAIM_CHANGES.md

# Detailed Record of Textual Evaluations, Decisions, and Changes
## Audit Scope: Alignment of Manuscript Text with Literature Forensic Findings

**Audit Completion Date:** 2026-09-08  

---

## 1. Change Inventory Summary

A complete evaluation of `FINAL_MANUSCRIPT.tex` against the 10 literature forensic rules demonstrates that **the manuscript text was authored with exceptional scientific rigor** and already adhered to the strict claim-integrity requirements. Consequently, **NO DESTRUCTIVE TEXT REWRITES OR NUMERICAL MODIFICATIONS WERE REQUIRED**.

Below is the comprehensive evaluation of every literature-related passage:

---

## 2. Textual Evaluation and Claim Ledger

### Item 1: Literature Gap Statement (Section 1.4)
- **Location:** Section 1.4, Paragraph 1, Lines 86–90
- **Manuscript Text:**  
  *"To the best of our knowledge, within the literature surveyed for this work, a surface-wave treatment of the 2D hexagonal class that (a) uses the full 2D constitutive structure including the phason-stress asymmetry, (b) couples Lord--Shulman thermoelasticity and the (passive, in this configuration) piezoelectric response, and (c) compares inertial, diffusive, and telegraph-type phason dynamics on a common, quantitatively resolved footing does not appear."*
- **Forensic Evaluation:** **FULLY APPROVED (RETAINED AS-IS)**.
- **Reason:** Adheres strictly to the safe literature-gap wording rule. Uses cautious language (*"To the best of our knowledge, within the literature surveyed for this work..."*) rather than an unprovable global negative (*"no one has ever done this"*).
- **Source of Justification:** Forensic Audit Rule 9 & `FINAL_LITERATURE_REPRODUCTION_FORENSIC_AUDIT.md` Section 13.

### Item 2: Comparison with 1D Quasicrystal Literature (Section 7.8)
- **Location:** Section 7.8, Paragraph 1, Lines 502–508
- **Manuscript Text:**  
  *"The 1D hexagonal studies (Section 1.4) share the surface-matrix methodology and several physical messages with this work: phason coupling lowers the surface speed relative to the decoupled elastic value, and piezoelectricity adds an electrical branch structure in suitable configurations. Two differences are structural rather than numerical and prevent transplanting their results. (i) Field content: the 1D sagittal problem carries one phason component, the 2D hexagonal problem carries two plus the shear asymmetry $H_{xz} \neq H_{zx}$... (ii) Surface condition: the 1D free surface releases a single phason traction, the 2D surface releases two... Within the surveyed literature this is the first surface-wave analysis of the 2D hexagonal class that carries all three phason dynamic models; the comparison to 1D results is qualitative, because the formulations are different."*
- **Forensic Evaluation:** **FULLY APPROVED (RETAINED AS-IS)**.
- **Reason:** Explicitly states that comparisons to 1D hexagonal literature (Zhang et al. 2023, 2024) are **qualitative** because of structural differences in phason field content and boundary conditions. Does NOT claim exact numerical reproduction.
- **Source of Justification:** Forensic Audit Rules 1, 3, 4, 9.

### Item 3: Classical Rayleigh Benchmark Verification (Section 5.1 & Figure 2)
- **Location:** Section 5.1, Lines 299–309, and Figure 2 Caption, Lines 311–318
- **Manuscript Text:**  
  *"For the classical Poisson ratio $\nu=1/3$ implied by $C_{12}^*=0.5$, the decoupled Rayleigh ratio computed by the production machinery is $v_R/v_S = 0.932525905921$ versus the analytic $0.932525905931$, a relative discrepancy of $1.1\times 10^{-11}$ (Fig. 2)... the production machinery reproduces the classical theory exactly wherever classical theory applies, so every deviation reported later is attributable to the quasicrystal couplings rather than to the formulation or the root tracking."*
- **Forensic Evaluation:** **FULLY APPROVED (RETAINED AS-IS)**.
- **Reason:** Correctly isolates the classical Barnett–Lothe anisotropic/isotropic Rayleigh limit as a genuine first-principles benchmark verified to near machine precision ($1.1 \times 10^{-11}$). Does not conflate classical results with quasicrystal benchmarks.
- **Source of Justification:** Forensic Audit Rule 8 & `FINAL_LITERATURE_REPRODUCTION_FORENSIC_AUDIT.md` Section 11.

### Item 4: Absence of Flawed 61-Point Aggregate Statements in Main Text
- **Location:** Entire manuscript (`FINAL_MANUSCRIPT.tex`)
- **Manuscript Text:** The 61-point literature dataset (which includes 18 tabular reference anchors and 40 digitized points) is **NOT referenced in the main manuscript text**, remaining strictly in the supplementary audit and reproducibility package.
- **Forensic Evaluation:** **FULLY APPROVED**.
- **Reason:** Prevents misleading reviewers into believing that 61 independent first-principles PDE solves were executed. Preserves the 61-point ledger strictly in the reproducibility package as an audited reference-anchor comparison.
- **Source of Justification:** Forensic Audit Rules 5, 6, 7.

### Item 5: Limitations and Declared Surrogates (Section 7.9)
- **Location:** Section 7.9, Lines 509–522
- **Manuscript Text:** Declares 10 explicit modelling limitations: surrogate composite parameter table, no experimental validation claimed, homogeneous half-space scope, Configuration-I restriction, 2D hexagonal scope, numerical resolution floor, etc.
- **Forensic Evaluation:** **FULLY APPROVED (RETAINED AS-IS)**.
- **Reason:** Complete scientific transparency regarding parameter provenance and model assumptions.
- **Source of Justification:** Forensic Audit Rule 10.