# CHANGELOG — ARENA_PACKAGE_v3 (relative to ARENA_PACKAGE_v2)

Scope of this delivery: code/figure fixes F14–F18, F21, F22 only, plus delivery
artifacts. Manuscript-text findings (F01–F04, F06, F07, F11, F12, F13, F19, F20)
are explicitly deferred to the separate manuscript-rewrite pass and are planned in
`MANUSCRIPT_REWRITE_BRIEF.md` (shipped in this package). No production number was
changed: every CSV/JSON under `python_program/results/` is byte-identical to v2
(`diff -rq` clean), including `mesh_convergence_B.csv` / `mesh_convergence_C.csv`.

## Files that differ from v2

| Path | Reason |
|---|---|
| `python_program/figures.py` | F14–F18 view fixes (`pad_top()` helper; fig01(b) ylim −0.55…14.6; fig02(a)/fig03(a,b)/fig09(b) headroom; fig04(a,c) z-label `labelpad`; fig07(c) xlim + legend to lower-right; fig09(a) ylim floor 1e-10 + exact-0 annotation; fig10(b) legend to lower-left, ell=0 annotation, green note reposition) and F22 (`raster_wrapped_eps()` + `finish(..., raster_eps=True)`), plus F15 hook `finish(..., eps_adjust=...)` swapping fig05's alpha=0.18 plane for a dashed outline in the EPS only (PostScript has no transparency; the v2 EPS rendered it as an opaque `0.385 setgray` sheet). F05 fix from v2 retained unchanged. |
| `python_program/paper2/fem_solver.py` | F21 cleanup: dead `resid = … if False else None` and the immediately-overwritten elementwise `U` assignment removed (single `U = g.T @ q`; third return value was always `None` and is unused by callers); `eta` → `eta_grad` rename in `recover_fields` (was shadowing the natural coordinate); duplicate `bfs_shape.bfs_shape()` call replaced by `Nv = N`. Behaviour-identical (see `PYTEST_OUTPUT_v3.txt`). |
| `python_program/figures/fig01_model_schematic.{png,eps}` | re-rendered: bottom flowchart box no longer clipped (F14). |
| `python_program/figures/fig02_mesh_convergence.{png,eps}` | re-rendered: top Case-E marker headroom (F14). |
| `python_program/figures/fig03_cases_and_decomposition.{png,eps}` | re-rendered: "+0.1932 V"/"+0.1909" labels no longer cut by top spine (F14). |
| `python_program/figures/fig04_solved_fields.{png,eps}` | re-rendered: z-label `labelpad` (F14); **EPS replaced by lossless raster-wrapped version, 3,496,642 B → 760,506 B (F22)**; embedded raster verified pixel-identical to the shipped PNG. |
| `python_program/figures/fig05_alpha_grid_3d.{png,eps}` | PNG pixel-identical to v2 (metadata-only byte difference); EPS: opaque grey alpha-sheet removed, dashed zero-plane outline added instead (F15). |
| `python_program/figures/fig06_alpha_grid_heatmap.{png,eps}` | re-rendered from unchanged panel code; PNG pixel-identical to v2. |
| `python_program/figures/fig07_sign_evidence.{png,eps}` | re-rendered: right-hand "a\|b" labels inside axes; legend off the "(c)" box (F14/F18). |
| `python_program/figures/fig08_p3_sensitivity.{png,eps}` | re-rendered from v2's already-fixed code (F05); PNG pixel-identical to v2. |
| `python_program/figures/fig09_verification_energy.{png,eps}` | re-rendered: five exact-zero checks now visible (ylim floor 1e-10 + annotation, F16); top energy marker headroom (F14). |
| `python_program/figures/fig10_validation.{png,eps}` | re-rendered: legend moved off the C11–C33 markers; ell=0 disclosure annotation; green note repositioned (F16/F18). |

## Files added in v3

| Path | Reason |
|---|---|
| `CHANGELOG.md` | this file (required delivery artifact). |
| `MANUSCRIPT_REWRITE_BRIEF.md` | claim → evidence → proposed-replacement plan for the deferred manuscript pass (sections A–E requested by the audit round-2 response). |
| `PYTEST_OUTPUT_v3.txt` | `python3 -m pytest tests/ -q` run on this tree after all changes: 17 passed. |
| `SHA256SUMS.txt` | SHA-256 manifest of every package file except the manifest itself; cited by the drafted availability paragraph. |

## Carried forward unchanged from v2

`README.md`; `manuscript/` (all 3 files); `complete_calculation/` (both files);
`python_program/results/` (all CSV/JSON, incl. `mesh_convergence_B.csv`,
`mesh_convergence_C.csv`); `python_program/tests/`; `python_program/run_production.py`;
`python_program/paper2/` except `fem_solver.py`; `python_program/reference_frozen/`;
`requirements.txt`; `traceability_note.md`.

## Byte-identity verification (v2 vs v3), stated explicitly

* `manuscript/`: SHA-256 of all 3 files identical —
  `PAPER5_FINAL_MANUSCRIPT.pdf` 3274f9b3e295f793…, `PAPER5_FINAL_MANUSCRIPT.tex`
  22de43678578d063…, `references.bib` 845ddf42cafccdea… (full digests in the
  comparison manifest; per-file table reproduced in `SHA256SUMS.txt`).
* `complete_calculation/`: SHA-256 of both files identical —
  `complete calculation.pdf` 000687eea4f53d7d…, `complete calculation.tex`
  9bb0eac65c63e590….
* `python_program/results/`: `diff -rq` clean (0 differing files).
* Test suite on the delivered tree: 17 passed (`PYTEST_OUTPUT_v3.txt`).
