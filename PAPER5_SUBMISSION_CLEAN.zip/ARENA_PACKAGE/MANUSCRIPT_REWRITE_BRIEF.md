# MANUSCRIPT REWRITE BRIEF (plan only — no manuscript file is modified in v3)

Companion to `CHANGELOG.md`. Authority order: `python_program/results/` (numbers) >
`complete_calculation/` (physics) > manuscript text. Line numbers refer to
`manuscript/PAPER5_FINAL_MANUSCRIPT.tex` as shipped in v2/v3 (585 lines, SHA-256
22de43678578d063…). Every replacement value below is taken from `results/` or from
Round-2 derivations that were independently re-verified (F08 joint-σ bounds, F09
observed orders/uncertainty band, F10 dielectric identity channels).

---

## A. Claim-by-claim change list

### F03 — Correction-1 magnitude ("5–14 %") — five locations
| # | Location (v2 tex) | Current text | Replacement |
|---|---|---|---|
| A1 | Abstract, L35–36 | "systematically under-predicts the thermoelastic forcing by 5--14\%" | "…under-predicts the thermoelastic forcing by 35.05 % (βxx) and 57.75 % (βzz) of the corrected value — equivalently, the correction raises β by +53.97 % (βxx) and +136.67 % (βzz) relative to the simplified reduction" |
| A2 | Intro contribution (i), L124–125 | "an earlier, simplified reduction under-predicts it" | keep, but attach the same two-denominator figures on first use |
| A3 | §2.2, L207–210 | "evaluates to β_PS=[6.7167, 4.1903, 0]×10⁶, a +14.4 % change in the xx component and a −5.2 % change in the zz component relative to the simplified reduction" | **The +14.4/−5.2 pair is the Correction-4 α update (corrected Eq. at record α vs production α), NOT the reduction fix.** Replace with: "…a +53.97 % (βxx) / +136.67 % (βzz) increase over the simplified reduction at the same (production) α; stated against the corrected value, the simplified reduction is low by 35.05 % / 57.75 %" |
| A4 | Discussion, L482–484 | "changes β_xx by +14.4 % and β_zz by −5.2 % relative to a simplified reduction" | same figures as A3, denominator stated |
| A5 | Conclusions item 2, L552–555 | "under-predicts the thermal forcing by $5$--$14$\%" | same figures as A1 |

**Convention note to paste verbatim wherever any of these appears:** naive β =
(4.362300, 1.770500)×10⁶, corrected β = (6.716700, 4.190300)×10⁶ Pa/K at production α;
(corrected−naive)/naive = +53.9715 % / +136.6733 %; (corrected−naive)/corrected =
+35.0529 % / +57.7477 %. The legacy "5–14 %" corresponds to neither: it is the
Correction-4 α change (+14.4 %/−5.2 % in `FINAL_FROZEN_THERMAL_VECTOR_AUDIT`).

### F04 — Table 2 (`tab:beta`, L211–225)
Current columns mix two different experiments: the "simplified" column (5.8692e6,
4.4216e6) is the *corrected* Eq. at record α. Rebuild as in §D below (genuine
simplified column at production α + both denominators), or relabel the existing table
as an α-sensitivity table. Recommended: rebuild.

### F01 — frozen-release digits quoted as reproducible — three locations
| # | Location | Current | Replacement (from `results/`, current authoritative run) |
|---|---|---|---|
| A6 | Tab. 1 `tab:results`, L370–372 | −3.43864724813821 / −1.49959799768594 / +0.193211761033805 | −3.438647248137982 / −1.4995979976791265 / +0.193211761047954 (`production_results.csv`) |
| A7 | Tab. 3 `tab:mesh` Case-D column, L399–403 | 5.2e-14 / 1.6e-12 / 2.9e-12 / ≈0 / −1.3e-11 % | −2.58e-14 / +1.24e-12 / +2.31e-12 / +3.33e-12 / −2.22e-11 % (`mesh_convergence_D.csv`) |
| A8 | §4.4, L417 | "affine in the scale factor to within 4×10⁻¹⁴ V" | "to within 5.7×10⁻¹⁵ V" (exact 5.662137425588298e-15, `p3_sensitivity.csv`); slope may cite −1.7003844944092572 V per unit scale |

### F12 — reproducibility wording, L380–382
"The high-precision values … are retained for reproducibility only" → condition it:
bitwise reproducible **within the pinned environment** (Python 3.13.14 / numpy 2.3.5 /
scipy 1.17.1 / matplotlib 3.10.9); cross-environment re-runs agree to ≤2.4×10⁻⁶
relative on derived residuals (BLAS/thread-order sensitive). Do not claim bit-identity
across environments.

### F02 — verification-suite over-claim — Abstract L~24–28 and Tab. 4
Abstract lists "controlled one-dimensional piezoelectric and piezoelectric–pyroelectric
benchmarks" and "electrode/charge boundary conditions"-style checks that
`results/verification_results.csv` does not contain. Replace the Abstract list with the
shipped suite's actual content (exact 1-D pyroelectric identity, four exact-zero null
checks, coupled-block reciprocity, discrete energy-stationarity identity, p3-affinity,
BFS partition-of-unity/linear-recovery) and rebuild Tab. 4 from the 13 shipped rows
(§D). Also fix L427–428 "Every check passed to at or near machine precision": the
enthalpy identity is 3.53×10⁻¹⁰ against a 1×10⁻⁷ tolerance — say "within stated
tolerances (tightest 1×10⁻¹² absolute; the variational enthalpy identity 3.5×10⁻¹⁰
against 1×10⁻⁷)". Same for Conclusions item 1 ("all satisfied to near-machine
precision").

### F19 — reciprocity digit and pass count (Tab. 4 + any prose)
Reciprocity is 1.2998703628133097×10⁻¹⁷ (write 1.3×10⁻¹⁷), not 1.5×10⁻¹⁷; the suite is
**11 PASS + 2 INFO**, not "13 checks, all pass".

### F07 — Case-E sign reversal must become a stated result
Discussion L470–474 describes Case E's sign qualitatively but never states that
Correction 1 *reverses* it. Insert after L487: at 48×24 with the legacy β, V_A =
−1.909285 V and V_E = −0.215422 V; with the corrected β, −1.500906 V and
**+0.192957 V** (ΔV = 0.4084 V in both cases; Case D unchanged to 0.000e+00). Use the
headline sentence drafted in §B.

### F08 — polarity-robustness statement (new sentence, §4.5 sensitivity)
Replace any grid-based polarity claim (README §4; manuscript currently silent) with the
80×40 joint propagation: SE(α₁)=1.6459207179×10⁻⁶ K⁻¹, SE(α₃)=3.2610834927×10⁻⁶ K⁻¹;
Case E joint ±1σ = [+0.062077252087, +0.324346270009] V (polarity robust); flip
requires ≈ −2σ on α₃ (α₃ −2σ alone: −0.018777520994 V; joint −2σ: −0.069057256874 V).
Case A joint ±2σ = [−1.761867015602, −1.237328979757] V, no flip. The single negative
3×3-grid point (α₁×0.5, α₃×1.5) = −0.0432 V lies at −6.6σ(α₁) and is **not** an
uncertainty envelope.

### F09 — discretization uncertainty instead of the stalled "p = 2.0"
The manuscript nowhere cites p=2.0 (good), but §4.3 should carry an honest band:
observed orders from the geometric subsequence (8→16→32→64) are 1.3546/1.3071 (A) and
1.4582/1.5262 (E); discretization uncertainty of the 80×40 values ±0.091 % (A) /
±0.146 % (E); extrapolator spread 0.174 % / 0.275 %. The `apparent_order_p = 2.0` and
`richardson_abs_error_V` columns in `production_results.csv`/`richardson_summary.csv`
are stale artifacts of a stalled `curve_fit` (returns its seed bit-exactly for
p0∈{2,3,4,6}); **flag for the code pass preceding the rewrite**: recompute those columns
with the geometric-subsequence estimator before any manuscript sentence cites them.

### F11 — mesh disclosure for the α-uncertainty analysis
`alpha_uncertainty.csv` was computed at 48×24 (nominal −1.500906019883 /
+0.192957382415 V) while headlines are 80×40 (0.087 % offset, negligible vs 7 % α
effect). Add to §4.5: state the mesh of each sensitivity artifact, or cite the new 80×40
joint-σ numbers from F08 (preferred — they exist now).

### F10 — κ provenance and the dielectric identity (Tab. 3 + footnote)
* Tab. 3 rows κ11/κ33 carry confidence "primary source, transcribed value" while the
  record ledger tags them RANGE (frozen record: YELLOW). Align labels with the ledger.
* Add footnote: ε^T − ε^S = e·C⁻¹·eᵀ gives e₁₅²/C₄₄ = 2165.5771 ε₀ (11-channel) and
  e₃·C_N⁻¹·e₃ = 76.4241 ε₀ (33-channel). Reading κ11 = 2200 ε₀ as clamped implies
  ε₁₁^T = 4365.6 ε₀ (~2× above literature); reading it as free implies ε₁₁^S = 34.42 ε₀
  (~3× below). The triple (e₁₅, C₄₄, κ11) is inconsistent under either reading; the
  least-damaging interpretation is κ11 = free ε₁₁^T mislabelled clamped. κ33 = 56 ε₀
  clamped ⇒ ε₃₃^T = 132.42 ε₀ (consistent).
* Add sensitivity sentence: re-solving with κ11ʳ = 34.42 ε₀ changes V_A by −0.500 % and
  V_E by −0.729 % (V_D exactly 0); κ33 sets V_D ∝ 1/κ33, so 56→66 ε₀ ⇒ −15.2 % — a
  RANGE-status input controlling a headline number needs a disclosed bound.

### F20 — Tab. 3 completeness
Add the two production-active parameters missing from Tab. 3: C₄₄ = 6.1×10¹⁰ Pa and
e₁₅ = 34.2 C/m² (Zgonik 1994; record status ACTIVE_A_E), and align every confidence
label with the record's status tags. Then L285–286 ("Table 3 lists every material
parameter used in the production calculations") becomes true.

### F13 — Limitations item 4 (B/C convergence), L530–534
Now that `mesh_convergence_B.csv`/`_C.csv` ship: replace "does not show mesh convergence
at any of the densities studied" with the measured statement in §E.

### F06 — missing data/code-availability statement
Add the paragraph drafted in §C as a new numbered section before Acknowledgments.

---

## B. Drafted headline sentence (Case-E sign reversal as central finding)

**Primary draft (Discussion, and echoed in Abstract):**
> "The central qualitative result of this work is that the polarity of the
> piezoelectric–thermal open-circuit voltage is a discriminator between constitutive
> reductions: with the legacy plane-strain thermal-stress vector the same specimen solves
> to V_E = −0.22 V, whereas the corrected vector — full three-dimensional
> thermal-expansion contraction before the plane-strain constraint — yields V_E =
> +0.19 V (+0.193211761047954 V on the converged 80×40 mesh), a sign reversal produced by
> a 0.4084 V rigid shift that simultaneously moves Case A from −1.909285 V to
> −1.500906 V. Any measurement of the sign of V_E therefore tests the reduction itself,
> independently of magnitude."

**Abstract-length variant:**
> "A central finding is that the corrected plane-strain thermal-stress vector reverses
> the sign of the piezoelectric–thermal open-circuit voltage (−0.22 V → +0.19 V), so the
> response polarity, not merely its magnitude, diagnoses the constitutive reduction."

---

## C. Drafted data/code-availability paragraph (F06)

> **Data and code availability.** All results reported here are generated by the
> self-contained analysis package ARENA_PACKAGE_v3 (repository:
> github.com/vipin-oss/BFS-FEM-MATLAB), which includes the solver (`python_program/`),
> the derived-data ledger (`python_program/results/`, 15 CSV/JSON files), the figure
> generator, the 17-test verification suite, and the symbolic derivation
> (`complete_calculation/`). The environment is pinned to Python 3.13.14, numpy 2.3.5,
> scipy 1.17.1 and matplotlib 3.10.9 (`requirements.txt`). Reproduction requires three
> commands from `python_program/`: `python3 run_production.py` (regenerates every CSV),
> `python3 figures.py` (regenerates all figures), `python3 -m pytest tests/ -q`
> (17 passed). The exact delivered state is fixed by the SHA-256 manifest
> `SHA256SUMS.txt` shipped in the package root (and by the zip digest recorded at
> deposit); runs are bitwise reproducible within the pinned environment, with
> cross-environment agreement to ≤2.4×10⁻⁶ relative on derived residuals. No
> experimental data were used; all inputs are literature values transcribed in
> `results/material_parameter_record.csv` with per-value provenance and status tags.

---

## D. Drafted corrected tables

### Table 2 (rebuild of `tab:beta`, per F04/F03)
| Component | Simplified reduction (Pa K⁻¹) | Correct reduction, Eq. β_PS (Pa K⁻¹) | Change vs simplified | Equivalent statement |
|---|---|---|---|---|
| β_xx | 4.3623×10⁶ | 6.7167×10⁶ | **+53.97 %** | simplified is 35.05 % below corrected |
| β_zz | 1.7705×10⁶ | 4.1903×10⁶ | **+136.67 %** | simplified is 57.75 % below corrected |

Footnote to add: "An earlier draft of this table showed (5.8692×10⁶, 4.4216×10⁶) as the
'simplified' column with changes +14.4 %/−5.2 %; those entries are the *correct*
reduction evaluated at the pre-Correction-4 (record) thermal-expansion coefficients, so
that percentage pair quantifies the α update, not the reduction fix."

### Table 4 (rebuild of `tab:verify` from `results/verification_results.csv`, per F02/F19)
| # | Check | Scope | Result | Status |
|---|---|---|---|---|
| 1 | BFS partition of unity | code verification | exact 0 | PASS |
| 2 | BFS exact linear-field recovery | code verification | 2.1×10⁻¹⁷ | PASS |
| 3 | Coupled-block reciprocity, K_φu = K_uφᵀ (rel. Frobenius) | variational consistency | 1.3×10⁻¹⁷ | PASS |
| 4 | Case D vs exact 1-D pyroelectric identity, 16×8 | analytical | 1.3×10⁻¹⁶ | PASS |
| 5 | Case D vs exact 1-D pyroelectric identity, 80×40 | analytical | 1.5×10⁻¹³ | PASS |
| 6 | Zero-temperature null | code verification | exact 0 | PASS |
| 7 | Zero-α null (Case E) | code verification | exact 0 | PASS |
| 8 | Zero-p null (Case D) | code verification | exact 0 | PASS |
| 9 | Zero-p: Case A ≡ Case E | code verification | exact 0 | PASS |
| 10 | p3-affinity at fixed K (max residual) | linearity | 5.7×10⁻¹⁵ V | PASS |
| 11 | Discrete stationary-potential / integrated-enthalpy identity | variational, final mesh | 3.5×10⁻¹⁰ (tol 1×10⁻⁷) | PASS |
| 12 | Superposition V_A ≠ V_D + V_E (−1.738262753729253 V) | informational | shared single solve | INFO |
| 13 | Analytic 1-D identity voltage (−3.4386472481385097 V) | informational | reference value | INFO |

Rows to **delete** (not produced by the released suite): "Electrode/charge boundary
conditions", "Uniform-temperature pyroelectric identity", "Controlled 1-D piezoelectric
benchmark", "Controlled 1-D piezoelectric–pyroelectric benchmark". Caption change:
"11 passed checks and 2 informational rows; all within stated tolerances."

---

## E. Case B/C Limitations rewrite (F13, now evidence-backed)

Replace Limitations item 4's convergence clause with:
> "Mesh studies of the flexoelectric-active configurations (Cases B and C, shipped as
> `mesh_convergence_B.csv` / `mesh_convergence_C.csv`) solve stably and converge
> monotonically at all six densities (8×4 … 80×40), but their final-step relative changes
> under the package convention (V_new−V_prev)/V_prev are −1.4976 % (B) and −2.1761 % (C),
> i.e. one to two orders above the 0.1 % criterion satisfied by the non-flexoelectric
> cases; the flexoelectric results are therefore reported as exploratory only, and no
> quantitative claim rests on them."

Conclusions item 7 may keep its current wording (it already withholds flexoelectric
conclusions) but should cite the shipped B/C CSVs as the evidence base.

---

## Execution order for the rewrite pass (not part of v3)

1. Code pass: regenerate `richardson_summary.csv`/`production_results.csv` order columns
   with the geometric-subsequence estimator (F09) so no table cites the stalled p=2.0.
2. Apply §A edits + §B headline + §C availability + §D tables + §E limitations.
3. Re-render nothing (figures already v3); recompile PDF; re-run the 17-test suite.
4. Diff-check every changed number against `results/` and this brief before submission.
