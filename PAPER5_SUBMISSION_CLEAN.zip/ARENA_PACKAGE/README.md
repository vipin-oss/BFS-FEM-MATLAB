# PAPER5 / FEM5 — Complete Package for Independent Audit

**Read only this file first.** This package is self-contained. Do not search for,
request, or assume any file outside this package. Every claim below is directly
traceable to a file inside it, and you are expected to verify — not just read — the
claims that matter to your audit, by running the code and cross-checking the
manuscript against `python_program/results/`.

---

## 0. What this project is

A plane-strain, coupled piezoelectric-pyroelectric (with an inactive flexoelectric
extension) finite-element model of a tetragonal BaTiO3 microcantilever under a steady
through-thickness temperature difference, with a grounded bottom electrode and a
floating open-circuit top electrode. Specimen: 10 um x 1 um, delta-T = 10 K. Target:
a journal manuscript for a Q1/IF>=6 SCI/SCIE venue.

---

## 1. Package contents

```
ARENA_PACKAGE/
|-- README.md                 <- this file
|-- SHA256SUMS.txt            <- manifest of every file in this package
|-- python_program/           <- the authoritative, currently-executable implementation
|-- manuscript/                <- the current draft journal manuscript (TEX + PDF + .bib)
`-- complete_calculation/      <- the master derivation record (TEX + PDF), background
                                  physics reference -- see authority order in Sec 2
```

### `python_program/`
```
run_production.py      - solves all cases, writes results/*.csv
figures.py              - reads results/*.csv only, writes figures/fig01..fig10 (PNG+EPS)
paper2/                 - materials.py, bfs_shape.py, fem_solver.py, cases.py,
                          corrections.py (four corrections applied to the original
                          derivation, each independently re-derived -- see
                          corrections.py docstrings)
tests/                  - pytest suite, 17 tests
results/                - all generated CSVs (production voltages, mesh convergence
                          for every case including the flexoelectric-active B/C,
                          p3-sensitivity, alpha 3x3 grid, joint-sigma alpha
                          uncertainty, verification suite, energy audit, material
                          parameter ledger, Richardson/observed-order summary)
figures/                - fig01-fig10 as .png (300 dpi) + .eps (vector), plus
                          captions.md / captions.tex (captions are NOT drawn inside
                          the images; they belong in the manuscript text)
reference_frozen/       - a historical (pre-Python) computational baseline, bundled
                          only so the acceptance cross-check in the test suite is
                          reproducible without any external file
traceability_note.md   - maps reported numbers/figure panels to the function/line
                          that produced them
requirements.txt        - exact pinned package versions
```

**Commands to reproduce everything from scratch** (deterministic -- no randomness
anywhere in this codebase; re-running gives bit-identical numbers within one
environment):
```bash
cd python_program
python3 run_production.py      # ~45 s -> results/*.csv, traceability_note.md
python3 figures.py             # ~10 s -> figures/fig01..fig10 (.png + .eps)
python3 -m pytest tests/ -v    # 17 passed
```

### `manuscript/`
```
PAPER5_FINAL_MANUSCRIPT.tex/.pdf   - current draft (18 pages, 10 figures embedded),
                                      built entirely from python_program/results/
references.bib                      - bibliography (compiles with the .tex; run
                                      pdflatex -> bibtex -> pdflatex -> pdflatex)
fig01..fig10_*.eps/.pdf/.png        - figure source files referenced by the .tex
                                      (pdflatex requires the .pdf versions; the .eps
                                      originals and fig04's .png are kept alongside
                                      for provenance/traceability back to
                                      python_program/figures/)
```
**Note on figure integration:** an earlier version of this package shipped the
manuscript as text-only (tables and equations, no embedded figures) despite the
figure architecture being fully built in `python_program/figures/`. This has been
corrected: all 10 figures are now embedded at their natural locations (model
schematic in Theory; production/mesh/sensitivity/verification figures in Results;
the three alpha-grid figures and the mandatory 4-panel validation figure in
Discussion), each cross-referenced from the text and individually verified to
render with real content (one figure, the 3D solved-fields plot, required using its
PNG instead of its EPS/PDF due to a Ghostscript conversion defect specific to that
figure's raster-wrapped EPS construction -- documented, not hidden).

### `complete_calculation/`
```
complete calculation.tex/.pdf   - the full, exhaustive derivation record (60 pages):
                                   every constitutive step, the BFS element
                                   construction, every element matrix, analytical
                                   benchmarks, material provenance discussion
```

---

## 2. Authority order -- which file wins if two disagree

1. **`python_program/`** is authoritative for every number. Verified against exact
   analytical identities and cross-checked against the historical baseline in
   `reference_frozen/` (agreement to 1e-10 to 1e-14 relative on every production case).
2. **`complete_calculation/`** is the physics/derivation reference -- it explains *why*
   an equation in `paper2/*.py` is written the way it is, but predates four
   corrections (Sec 3) now implemented in `python_program/` and is not numerically
   authoritative on its own.
3. **`manuscript/`** is intended to describe the `python_program/` numbers exactly.
   As of this package, it has been rewritten end-to-end from `results/` and passed
   one full independent line-by-line re-audit against the CSVs (see Sec 5). That does
   **not** mean it is guaranteed free of remaining errors -- it means the specific
   errors found in three prior audit rounds were fixed and re-verified. **Finding
   any further discrepancy between the manuscript and `results/` is exactly the kind
   of thing this audit should surface.**

---

## 3. The four corrections applied to the original derivation, in `python_program/paper2/corrections.py`

1. **Plane-strain thermal-stress vector.** The naive reduction (multiplying an
   already plane-strain-reduced stiffness by a 2-component thermal-expansion vector)
   omits the constrained transverse (yy) thermal expansion's contribution through the
   off-diagonal `C12`/`C13` terms. Correct form, re-derivable from the full 3D
   tetragonal contraction:
   ```
   beta_PS = [(C11+C12)*alpha1 + C13*alpha3,  2*C13*alpha1 + C33*alpha3,  0]
   ```
2. **Reciprocal flexoelectric coupling.** `Kuphi` includes the flexoelectric term on
   the mechanical side too (`Beta^T mu^T Bphi`), not only the electrical side, so that
   `Kphiu = Kuphi^T` exactly (forced by Hessian symmetry of the enthalpy).
3. **Electrical constitutive law uses total strain consistently**: `D = e*eps +
   mu*eta + kappa*E + p*theta` and `fphi = -integral(Bphi^T * p * theta)` -- no
   `e*eps_thermal` term in `fphi`, since the enthalpy's independent mechanical
   variable is total strain.
4. **Material inputs:** `alpha1=alpha2=+21.8e-6 K^-1`, `alpha3=-4.3e-6 K^-1`
   (Nakatani et al. 2016, direct OLS regression); `p3 (primary) = -3.41e-4
   C/(m^2 K)` (Eklund & Karttunen 2023 SI Table S3, directly tabulated, not
   back-calculated); `C11..C44, e15/e31/e33, kappa11/kappa33` unchanged (Zgonik et
   al. 1994); `mu`/`ell` (flexoelectric) not source-controlled, excluded from
   production output.

---

## 4. Current production numbers (from `python_program/results/production_results.csv`)

| Case | Mechanisms | Voltage (V), 80x40 mesh | Reported as |
|---|---|---:|---|
| D | pyroelectric only | -3.438647248138 | ~ -3.4 V |
| A | piezoelectric + pyroelectric | -1.499597997679 | ~ -1.5 V |
| E | piezoelectric + thermal (p=0) | +0.193211761048 | ~ +0.19 V |
| 0 | zero imposed temperature | 0.0 (exact) | 0 V |

**The central, headline finding of this work:** the plane-strain thermal-stress
correction (item 1, Sec 3) does not merely change magnitudes -- it **reverses the
sign** of Case E. With the pre-correction (naive) formula, Case E solves to
approximately **-0.22 V**; with the correction, **+0.193 V**. This is stated as the
headline finding in the manuscript's Abstract, Discussion, and Conclusions. A joint
propagation of the alpha-regression's own +/-1sigma/+/-2sigma uncertainty
(`results/alpha_uncertainty.csv`, computed at 80x40) shows this polarity is robust at
+/-1sigma and flips only beyond approximately -2sigma on the transverse coefficient
alone.

11 of 13 internal verification checks are pass/fail (all pass, tightest tolerance
1e-12 absolute); 2 are informational reference values
(`results/verification_results.csv`). **These are internal code/analytical
verifications, not an external experimental validation** -- no independent
full-device voltage measurement exists for this system, and the manuscript does not
claim otherwise.

---

## 5. Audit history -- what has already been checked (do not re-litigate without new evidence)

This package has been through three rounds of adversarial audit plus one full
independent line-by-line re-audit, each round verified by actually running the code
or recomputing the claim, not by trusting a prior report:

- **Round 1-2:** found and fixed genuine defects including a plane-strain-formula
  error, a flexoelectric-coupling asymmetry, a mixed-strain inconsistency in the
  electrical constitutive law, an incorrect pyroelectric-coefficient provenance, a
  `fig08` slope-calculation bug (used the wrong array index, giving half the true
  slope), a missing `mesh_convergence_B/C.csv`, a stalled `curve_fit`-based
  discretization-order estimate silently returning its own seed value, and a
  dielectric clamped/free inconsistency in kappa11.
- **Round 3 (manuscript rewrite):** rewrote the manuscript end-to-end from
  `results/`, correcting a mischaracterized percentage (an earlier draft attributed
  a change to the plane-strain formula fix that was actually caused by a separate
  thermal-expansion-coefficient update), adding the Case E sign-reversal as a stated
  finding, adding a Data and Code Availability section (previously entirely
  absent), and rebuilding the verification-suite table to match the actual 13-row
  CSV (four previously listed checks did not exist in the shipped code).
- **A further independent full-document re-audit** (after Round 3) found and fixed:
  a mesh-label typo (a nonexistent "48x40" mesh cited where "48x24" was meant), a
  sign-convention error in a kappa11-sensitivity statement (a percentage was
  reported with the wrong sign due to dividing by a negative baseline voltage --
  resolved by stating explicit before/after voltages instead of a signed
  percentage), and three tables that overflowed the page margin (fixed with
  `\resizebox`).

**What this means for you:** the specific errors above are resolved and
re-verified. It does not mean the manuscript is error-free -- only that these
specific, now-documented issues are closed. Treat every number as a claim to check
against `results/`, not as ground truth because it survived earlier rounds.

---

## 6. Genuinely open items (real, currently unresolved -- not bugs to silently fix)

1. `alpha3`'s regression has R^2 ~ 0.47 over 4 near-room-temperature points; the
   sign is well-supported, the magnitude is not tightly constrained. Disclosed in
   the manuscript's Limitations.
2. A secondary-pyroelectric cross-check (`2*e31*alpha1 + e33*alpha3` ~ -59 uC/m^2K
   using this project's own room-temperature tensors) has the opposite sign from
   Eklund & Karttunen's own DFT-computed secondary coefficient (+72 uC/m^2K),
   attributed to different tensor provenance (room-temperature experiment vs. 0 K
   DFT) and not forced to agree. Disclosed, not resolved.
3. `mu`/`ell` (flexoelectric) remain without a source-controlled tensor or physical
   length scale; Cases B/C converge monotonically but their final-step relative
   change (-1.50%, -2.18%) is one to two orders above the 0.1% criterion met by the
   production cases, and they are excluded from all quantitative claims.
4. `kappa11`/`kappa33` (dielectric constants) carry an unresolved clamped-vs-free
   classification ambiguity, quantified in the manuscript via the thermodynamic
   identity eps^T - eps^S = e.C^-1.e^T; a dedicated, phase- and frequency-matched
   measurement would resolve it.
5. The elastic/piezoelectric/dielectric tensors (Zgonik 1994), thermal-expansion
   coefficients (Nakatani 2016), and primary pyroelectric coefficient (Eklund &
   Karttunen 2023) come from three independent sources, not one temperature-matched
   experiment. Individually each is a primary, directly-traceable source; the
   combination has not been validated as a single internally consistent dataset.

---

## 7. Ground rules this project has followed (please keep following them)

- Never invent, round favorably, or silently adjust a material constant, equation,
  or numerical result to match a prior expectation or to "improve" agreement.
- Never present an internal consistency/verification check as external or
  experimental validation.
- When two sources or two versions of a number disagree, report the disagreement
  and its most likely cause; do not force agreement.
- Any equation-level correction must be presented as OLD / NEW / REASON, never
  applied silently.
- Sign conventions for percentage changes are a recurring source of error in this
  project (caught twice already -- see Sec 5) whenever the baseline value is
  negative; state explicit before/after values wherever this ambiguity could arise,
  and double-check the sign of any percentage you compute or report.
- If you find a genuine problem anywhere in this package, flag it explicitly with
  evidence (a computation you ran, a CSV row you checked) rather than asserting it.
