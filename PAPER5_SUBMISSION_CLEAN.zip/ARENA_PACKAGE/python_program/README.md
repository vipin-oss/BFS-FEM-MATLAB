# Paper-2: thermally driven open-circuit voltage in plane-strain BaTiO3
## Independent Python production program + 9(+1) publication figures

From-scratch **Python** reconstruction of the physics documented in
`complete calculation.pdf` (the *master calculation record*): a thermally
driven open-circuit-voltage finite-element model of a BaTiO3 4mm plane-strain
cantilever with piezoelectricity, pyroelectricity, flexoelectricity and
optional Mindlin strain-gradient elasticity.

This package is **not** a MATLAB transliteration and has **no** `.m` files.
The MATLAB frozen release given separately was used **only** as a numeric
acceptance test and as the Figure-10(c) historical comparator; its source was
not copied and its material file was not treated as authoritative.

---

## What the master record + audited corrections give, and what this program computes

**Master-record physics (source of truth, `complete calculation.pdf`):**

* Specimen M: L = 10 µm × h = 1 µm cantilever, plane strain in (x,z),
  poling along z (4mm tetragonal). Sec. 2.1-2.2.
* Linear Dirichlet temperature θ(z) = ΔT·z/h, ΔT = 10 K (mean θ̄ = 5 K).
  Sec. 2.4.
* Root clamp at x = 0 (8 BFS mechanical DOFs/node zeroed), bottom electrode
  φ = 0, top electrode a floating equipotential with zero net charge (weak
  / integrated statement), E = −∇φ. Sec. 2.5, Sec. 34.
* Electric-enthalpy constitutive framework and sign conventions.
  Sec. 5.1-5.6.  BFS 16-DOF C¹ elements for (u,w), bilinear Q4 φ,
  4×4 Gauss–Legendre quadrature. Sec. 12-16.
* Block system `[Kuu Kuphi; Kuphiᵀ −Kphiphi][qu;qphi] = [fu;fphi]`.
  Sec. 11.4, 16-17.

**Four audited corrections applied (each independently re-derived; see
`paper2/corrections.py` and `traceability_note.md`):**

1. Plane-strain thermal vector: `β_PS = [(C11+C12)α1 + C13α3,
   2·C13·α1 + C33·α3, 0]` (3D contraction first, then active-slot selection;
   the yy eigenstrain survives under total εyy = 0).
2. Reciprocal electromechanical coupling: flexo term included on both sides,
   `Kphiu = Kuphiᵀ` exactly (Hessian symmetry of one enthalpy potential).
3. `D = e:ε + κ:E + μ:η + p:θ` with total strain, so
   `fφ = −∫Bφᵀ p θ dA` (no `e·ε_th` term).
4. `α1 = α2 = +21.8e-6`, `α3 = −4.3e-6` 1/K (Nakatani et al. 2016) and
   primary `p3 = −3.41e-4 C/(m²K)` (Eklund & Karttunen 2023) supersede the
   record's legacy alpha pair and total-ceramic p3; all other record materials
   (C11–C44, e15/e31/e33, κ11/κ33, ε0) are used exactly as the record states.

**What this program computes:** genuine solves of that model — nominal
production voltages (Cases A, D, E, 0), a full h-refinement study with
Richardson extrapolation, a fixed-K pyroelectric affinity sweep, a 3×3
α1×α3 sensitivity grid with α3-OLS standard-error propagation into a voltage
range, a verification suite, solved-field recovery, energy/enthalpy audit,
and the 10 figures.  Flexo-active cases (B, C) are implemented and unit-tested
at matrix level but excluded from all quantitative production output (μ and ℓ
are not source-controlled for this material).

---

## Requirements

* Python **3.10+** — the source uses no 3.11-only syntax; it was developed
  and tested on **Python 3.13.14**.
* `numpy`, `scipy`, `matplotlib`, `pytest` — exact pinned versions in
  `requirements.txt`.

The pinned toolchain (`numpy 2.3.5`, `scipy 1.17.1`, `matplotlib 3.10.9`,
`pytest 9.0.3`) is the one exercised end-to-end here and requires
Python ≥ 3.11 in practice.  On a true Python 3.10 interpreter, install the
compatible floor versions instead (`numpy==1.26.4`, `scipy==1.12.0`,
`matplotlib==3.8.4`, `pytest==8.2.2`); the numerical results are identical
because no code path depends on version-specific behaviour.

```bash
python3 -m pip install -r requirements.txt      # tested toolchain (3.11+)
```

## Run commands (one command end-to-end)

```bash
# (1) compute everything: mesh studies, production voltages, verification,
#     p3 sweep, alpha grid, fields, energy audit, Part-3 acceptance vs the
#     frozen release, Part-5 traceability note.
python3 run_production.py

# (2) build all 10 figures (PDF + PNG) from the CSVs only.
python3 figures.py

# (3) run the pytest verification suite.
python3 -m pytest tests/ -v
```

Expected runtime: about 40 s for the full computation (Intel-class single
core) + a few seconds for the figures + ~8 s for pytest.  Largest mesh:
80×40 (29,889 full DOFs).

## Output file list

`run_production.py` writes to `results/`:

| file | contents |
|---|---|
| `production_results.csv` | nominal production voltages (80x40) for D, A, E, 0 + Richardson estimate |
| `mesh_convergence_{D,A,E}.csv` | six-level h-refinement tables |
| `richardson_summary.csv` | Richardson continuum estimates |
| `verification_results.csv` | internal verification suite (residuals vs tolerance) |
| `p3_sensitivity.csv` | p3-affinity sweep at fixed K |
| `alpha_grid_{A,E,D}.csv` | 3×3 α1×α3 solved grids |
| `alpha_uncertainty.csv` | α3-OLS SE → voltage-range propagation |
| `energy_audit_A.csv` | signed energy/enthalpy terms, Case A, 80x40 |
| `fields_caseA_48x24.csv` | solved φ, E, ε, σ, D, u, w at real (x,z) points |
| `material_parameter_record.csv` | code vs source values for Fig. 10b |
| `numeric_acceptance_vs_frozen.csv` | Part-3 acceptance against the frozen zip |
| `manifest.json` | machine-readable campaign record |

`figures.py` writes `figures/fig01_model_schematic … fig10_validation` as
**PNG + PDF**.  `traceability_note.md` and
`verification_test_output.txt` are written at the project root.

`reference_frozen/results/` contains the result CSVs of the frozen FEM5
release (SHA-256 of the source zip `496e777d…` recorded in
`traceability_note.md` and verified before any computation).  The acceptance
step reads them from this local folder so the whole package is
self-contained; they are this project's own prior corrected baseline, used
only as numeric acceptance targets and the Figure-10(c) comparator — never as
a physics authority.

## Validation-scope statement (plain)

The program is verified **internally** (analytical 1D pyro identity, BFS
recovery, reciprocity, null cases, p3-affinity, enthalpy self-consistency)
and checked for numerical agreement against this project's own prior frozen
release (relative agreement ≤ 1e-6 on every nominal voltage; observed ~1e-11).
It is a **parameter-provenance consistency check**, not an experimental
validation: no independent experimental full-device voltage measurement of
this system exists, and none is claimed anywhere in this deliverable.
