#!/usr/bin/env python3
"""figures.py - all 10 publication figures (9 required + mandatory validation
figure), reading ONLY from the CSVs written by run_production.py.

    python3 run_production.py     # must be run first (writes results/*.csv)
    python3 figures.py            # writes figures/fig01..fig10 (PDF + PNG)

Every caption states the CSV source(s) and the producing function.
"""
from __future__ import annotations

import csv
import os
import textwrap
import warnings

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt          # noqa: E402
from matplotlib.patches import Rectangle, FancyArrowPatch  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
FIG = os.path.join(HERE, "figures")
os.makedirs(FIG, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["DejaVu Serif", "cmr10", "Computer Modern Roman"],
    "mathtext.fontset": "cm",
    "axes.formatter.use_mathtext": True,
    "axes.unicode_minus": False,
    "font.size": 10,
    "axes.titlesize": 10,
    "axes.labelsize": 10,
    "legend.fontsize": 8.5,
    "xtick.labelsize": 8.5,
    "ytick.labelsize": 8.5,
    "figure.dpi": 110,
})

CASE_COLOR = {"A": "#1f77b4", "D": "#2ca02c", "E": "#d62728", "0": "#7f7f7f"}

# House figure style (matches the author's prior published figures, e.g. FEM4
# Fig. 3): panels carry ONLY a small boxed letter label inside the axes,
# top-left; all descriptive text moves to the combined caption below the
# figure via finish(). Diverging fields use "RdBu_r" (as in FEM4's panel a),
# sequential fields use "viridis" or "magma" (as in FEM4's panels b-d).
CMAP_DIVERGING = "RdBu_r"
CMAP_SEQUENTIAL = "viridis"
CMAP_SEQUENTIAL_ALT = "magma"


def panel_label(ax, letter, loc="upper left"):
    """Draw a small boxed panel letter, e.g. '(a)', inside the axes -
    matches the author's established figure style (boxed letter only, no
    in-panel descriptive title). Works for both 2D and 3D (Axes3D) axes."""
    positions = {
        "upper left": (0.04, 0.94, "left", "top"),
        "upper right": (0.96, 0.94, "right", "top"),
        "lower left": (0.04, 0.06, "left", "bottom"),
        "lower right": (0.96, 0.06, "right", "bottom"),
    }
    x, y, ha, va = positions[loc]
    text_fn = ax.text2D if hasattr(ax, "text2D") else ax.text
    text_fn(x, y, letter, transform=ax.transAxes, ha=ha, va=va,
            fontsize=10.5, fontweight="bold",
            bbox=dict(boxstyle="square,pad=0.28", facecolor="white",
                      edgecolor="black", linewidth=0.7))


def read_rows(name):
    with open(os.path.join(RES, name)) as f:
        return list(csv.DictReader(f))


def num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return float("nan")


CAPTIONS = {}   # collected here, written out once to captions.md/.tex at the end


def pad_top(ax, top=0.12, bot=0.04):
    """F14 fix: give value labels / top markers headroom so nothing is clipped
    by the top (or bottom) spine.  Pure view change; no data touched."""
    ylo, yhi = ax.get_ylim()
    rng = yhi - ylo
    ax.set_ylim(ylo - bot * rng, yhi + top * rng)


def raster_wrapped_eps(png_path, eps_path):
    """F22 fix: replace a bloated vector EPS with a thin EPS that embeds the
    figure's own 300 dpi PNG raster, pixel-for-pixel (lossless: zlib/Flate of
    the raw RGB samples, ASCII85-wrapped so the file stays text-safe).
    mplot3d writes one shaded polygon per grid cell and ignores `rasterized`,
    which is what made fig04's EPS ~3.5 MB; matplotlib's own imshow->EPS route
    is worse (~6.8 MB) because the PS backend hex-encodes raw samples.  This
    wrapper keeps the appearance identical to the shipped PNG."""
    import base64
    import zlib
    import matplotlib.image as mpimg
    rgb = mpimg.imread(png_path)
    if rgb.dtype != np.uint8:
        rgb = np.clip(np.round(rgb[..., :3] * 255.0), 0, 255).astype(np.uint8)
    else:
        rgb = rgb[..., :3]
    h_px, w_px = rgb.shape[0], rgb.shape[1]
    raw = rgb.tobytes()
    comp = zlib.compress(raw, 9)
    a85 = base64.a85encode(comp, adobe=False).decode("ascii")
    w_pt, h_pt = 72.0 * w_px / 300.0, 72.0 * h_px / 300.0
    NL = "\n"
    head = NL.join([
        "%!PS-Adobe-3.0 EPSF-3.0",
        f"%%BoundingBox: 0 0 {int(round(w_pt))} {int(round(h_pt))}",
        f"%%HiResBoundingBox: 0 0 {w_pt:.4f} {h_pt:.4f}",
        "%%LanguageLevel: 2",
        f"%%Title: {os.path.basename(eps_path)}",
        "%%Creator: paper2 figures.py raster-wrapped EPS (F22)",
        "%%Pages: 1",
        "%%EndComments",
        "gsave",
        f"{w_px} {h_px} 8 [{w_px} 0 0 -{h_px} 0 {h_px}]",
        "currentfile /ASCII85Decode filter /FlateDecode filter",
        "false 3 colorimage",
        "",
    ])
    tail = NL.join(["~>", "grestore", "showpage", "%%EOF", ""])
    with open(eps_path, "w") as f:
        f.write(head)
        for i in range(0, len(a85), 76):
            f.write(a85[i:i + 76] + NL)
        f.write(tail)
    return os.path.getsize(eps_path)


def finish(fig, path, caption, func, csvs, bottom=0.06, use_tight_layout=True,
           eps_adjust=None, raster_eps=False):
    """Save PNG + EPS only - no caption text is drawn inside the figure.
    The caption is instead stored in CAPTIONS (keyed by figure file name) and
    written out separately by write_captions_file() at the end of the run,
    for direct use in the LaTeX manuscript body (not inside the artwork).
    `bottom` reserves extra vertical room for figures whose panels have
    taller x-axis label stacks. Set `use_tight_layout=False` for figures
    with colorbars, where tight_layout's own automatic margins are
    unreliable (matplotlib warns explicitly); such figures must already
    have an explicit fig.subplots_adjust(...) call before finish() is
    invoked."""
    name = os.path.basename(path)
    CAPTIONS[name] = caption
    if use_tight_layout:
        fig.tight_layout(rect=(0, bottom, 1, 1))
    fig.savefig(path + ".png", dpi=300, bbox_inches="tight")
    if eps_adjust is not None:      # F15: transparency is lost in EPS, so let
        eps_adjust()                # the figure swap alpha for a solid tint
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")   # EPS: harmless transparency notice
        fig.savefig(path + ".eps", format="eps", bbox_inches="tight")
    plt.close(fig)
    if raster_eps:                  # F22: overwrite the vector EPS with a
        n = raster_wrapped_eps(path + ".png", path + ".eps")
        print(f"  {os.path.basename(path)}.eps raster-wrapped: {n} bytes")


def write_captions_file():
    """Write all collected captions to captions.md and a ready-to-paste
    LaTeX snippet (captions.tex), keyed by figure file name, for insertion
    into the manuscript text - never inside the figure artwork itself."""
    order = [f"fig{n:02d}" for n in range(1, 11)]
    with open(os.path.join(FIG, "captions.md"), "w") as f:
        f.write("# Figure captions (for the manuscript text, not the artwork)\n\n")
        for key in order:
            name = next((n for n in CAPTIONS if n.startswith(key)), None)
            if name:
                f.write(f"**{name}**\n\n{CAPTIONS[name]}\n\n")
    with open(os.path.join(FIG, "captions.tex"), "w") as f:
        for key in order:
            name = next((n for n in CAPTIONS if n.startswith(key)), None)
            if name:
                f.write(f"% --- {name} ---\n")
                f.write("\\begin{figure}[t]\n  \\centering\n")
                f.write(f"  \\includegraphics[width=\\linewidth]{{{name}.eps}}\n")
                f.write(f"  \\caption{{{CAPTIONS[name]}}}\n")
                f.write(f"  \\label{{fig:{name}}}\n\\end{{figure}}\n\n")


# ===========================================================================
def fig01_model_schematic():
    fig, axes = plt.subplots(1, 2, figsize=(13, 5.4),
                             gridspec_kw=dict(width_ratios=[1.15, 1]))
    ax = axes[0]
    ax.set_xlim(-1.6, 11.2)
    ax.set_ylim(-1.5, 5.0)
    # specimen
    ax.add_patch(Rectangle((1, 0.3), 8.5, 2.0, facecolor="#eef2f7",
                           edgecolor="black", lw=1.2, zorder=2))
    # clamp at root
    ax.add_patch(Rectangle((-0.15, -0.05), 1.0, 2.7, facecolor="#c9c9c9",
                           edgecolor="black", lw=1, hatch="///", zorder=1))
    ax.text(-0.9, 1.0, "fixed\nclamp\nx = 0", ha="center", fontsize=8)
    # poling arrow (kept short, well clear of the top-electrode label above it)
    ax.annotate("", xy=(5.5, 2.85), xytext=(5.5, 0.6),
                arrowprops=dict(arrowstyle="->", lw=2, color="crimson"))
    ax.text(5.8, 1.7, "poling P$_s$ || z", color="crimson", fontsize=8)
    # temperature gradient arrow
    ax.annotate("", xy=(9.6, 2.7), xytext=(9.6, 0.9),
                arrowprops=dict(arrowstyle="->", lw=2, color="#2a6f2a"))
    ax.text(9.9, 1.5, "θ(z)=ΔT z/h\nΔT = 10 K", color="#2a6f2a", fontsize=8)
    # electrodes
    ax.plot([1, 9.5], [0.3, 0.3], lw=5, color="black", zorder=3)
    ax.plot([1, 9.5], [2.3, 2.3], lw=5, color="black", zorder=3)
    ax.text(5.25, 0.08, "bottom electrode z=0 :  φ = 0 (ground)",
            ha="center", fontsize=8)
    ax.text(5.25, 3.5, "top electrode z=h : floating equipotential,\n"
            "∫ D_z dx = 0 (open circuit)", ha="center", fontsize=8)
    ax.annotate("", xy=(5.25, 2.42), xytext=(5.25, 3.15),
                arrowprops=dict(arrowstyle="-", lw=0.7, color="#555555"))
    ax.text(1.2, 1.1, "BaTiO$_3$ (tetragonal 4mm)", fontsize=9)
    ax.text(1.2, 1.55, "plane strain, per unit depth", fontsize=8)
    ax.text(9.5, 1.1, "free end", ha="right", fontsize=8)
    ax.annotate("", xy=(10.4, 1.3), xytext=(9.7, 1.3),
                arrowprops=dict(arrowstyle="->", color="black"))
    ax.set_xticks([]); ax.set_yticks([])
    panel_label(ax, "(a)")
    # (b) mechanism chain - single-column flow, generously spaced
    ax2 = axes[1]
    ax2.set_xlim(0, 10)
    ax2.set_ylim(-0.55, 14.6)   # F14: room for the last box (y=0.6, half-h 0.75)
    ax2.axis("off")
    boxes = [
        ("Prescribed temperature field $\\theta(z)$", (5, 13.6)),
        ("Anisotropic thermal expansion $\\to$\n"
         "plane-strain thermal stress $\\sigma_{th}=-\\beta_{PS}\\theta$", (5, 11.4)),
        ("Finite-element solve of $(u,w,\\phi)$:\nclamped cantilever, $C^1$ interpolation",
         (5, 9.0)),
        ("Mechanical deformation and\nreciprocal piezoelectric coupling", (5, 6.6)),
        ("Open-circuit constraint: $\\phi_{top}$ tied, net charge $Q=0$",
         (5, 4.4)),
        ("$V=\\langle\\phi\\rangle_{top}-\\langle\\phi\\rangle_{bottom}$",
         (5, 2.4)),
        ("Open-circuit voltage for the pyroelectric, piezoelectric,\n"
         "and combined cases (flexoelectric case excluded)", (5, 0.6)),
    ]
    for t, (x, y) in boxes:
        ax2.add_patch(Rectangle((x - 4.3, y - 0.75), 8.6, 1.5,
                                facecolor="#f7f4ea", edgecolor="black",
                                lw=0.9))
        ax2.text(x, y, t, ha="center", va="center", fontsize=8.0)
    for y1, y2 in [(12.85, 12.15), (10.65, 9.75), (8.25, 7.35),
                  (5.85, 5.15), (3.65, 3.15), (1.65, 1.35)]:
        ax2.annotate("", xy=(5, y2), xytext=(5, y1),
                     arrowprops=dict(arrowstyle="->", lw=1.1,
                                     color="#666666"))
    panel_label(ax2, "(b)", loc="upper right")
    finish(fig, os.path.join(FIG, "fig01_model_schematic"),
           "Figure 1: Model configuration and mechanism chain. (a) Specimen "
           r"geometry ($L=10\,\mu$m$\times h=1\,\mu$m, $E=-\nabla\phi$): clamped "
           "root, poling direction, prescribed thermal gradient, grounded bottom "
           "electrode, and open-circuit top electrode. (b) Mechanism chain from "
           "the prescribed temperature field through anisotropic thermal "
           "expansion and the plane-strain thermal stress to the resulting "
           "mechanical deformation, piezoelectric charge, and open-circuit "
           "voltage.",
           "fig01_model_schematic", [])


# ===========================================================================
def _mesh_rows(case):
    rows = read_rows(f"mesh_convergence_{case}.csv")
    x = np.array([num(r["ndof_full"]) for r in rows])
    y = np.array([num(r["voltage_V"]) for r in rows])
    names = [r["mesh"] for r in rows]
    relc = np.array([abs(num(r["relative_change_percent"]))
                     if r["relative_change_percent"] not in ("", None)
                     else np.nan for r in rows])
    rich = read_rows("richardson_summary.csv")
    vinf = next(float(r["richardson_voltage_V"]) for r in rich
                if r["case"] == case)
    rich_err = np.abs(y - vinf) / abs(vinf) * 100.0
    return dict(ndof=x, V=y, names=names, relc=relc, rich_err=rich_err,
                vinf=vinf)


def fig02_mesh_convergence():
    data = {c: _mesh_rows(c) for c in "DAE"}
    fig, axes = plt.subplots(1, 2, figsize=(12.5, 4.4))
    ax = axes[0]
    for c in "DAE":
        d = data[c]
        ax.semilogx(d["ndof"], d["V"], marker="o", ms=4, ls="-", lw=1.4,
                    color=CASE_COLOR[c], label=f"Case {c}")
    ax.set_xlabel("number of full DOFs (log)")
    ax.set_ylabel("open-circuit voltage  V  [V]")
    ax.axhline(0, color="grey", lw=0.7)
    pad_top(ax)                 # F14: keep the topmost Case-E marker inside
    ax.legend(frameon=False)
    panel_label(ax, "(a)")
    ax2 = axes[1]
    nlev = max(len(d["relc"]) for d in data.values())
    xpos = np.arange(nlev)
    for k, c in enumerate("DAE"):
        d = data[c]
        r = np.nan_to_num(d["relc"], nan=1e-14)
        off = (k - 1) * 0.12
        ax2.plot(xpos + off, r, marker="o", ms=5.5, ls="-", lw=1.0,
                 color=CASE_COLOR[c], alpha=0.85,
                 label=f"Case {c}: |final-step rel. change| [%]")
        ax2.plot(xpos + off, d["rich_err"], marker="D", ms=4.2,
                 ls="none", color=CASE_COLOR[c], alpha=1.0,
                 markerfacecolor="white", markeredgewidth=1.3)
    ax2.plot([], [], "D", color="k", ms=4.2, markerfacecolor="white",
             markeredgewidth=1.3, label="Richardson-based error "
             "est. |V−V$_{\\infty}$|/|V$_{\\infty}$| [%]")
    ax2.set_yscale("log")
    ax2.set_xticks(xpos)
    ax2.set_xticklabels(data["A"]["names"], rotation=45)
    ax2.set_ylim(1e-12, 1e3)
    ax2.set_ylabel("[%]  (log scale)")
    ax2.set_xlabel("mesh level")
    ax2.grid(True, which="major", axis="y", alpha=0.25)
    ax2.legend(frameon=False, fontsize=7.4, loc="upper right")
    panel_label(ax2, "(b)")
    finish(fig, os.path.join(FIG, "fig02_mesh_convergence"),
           "Figure 2: Mesh-convergence study for Cases D, A and E "
           "over six h-refinement levels (8x4 to 80x40). (a) Voltage vs. full "
           "DOF. (b) Final-step relative change (bars) and the "
           "Richardson-based per-level error estimate "
           r"$|V-V_{\infty}|/|V_{\infty}|$ (diamonds); the two are distinct "
           "convergence measures shown separately.",
           "fig02_mesh_convergence",
           ["mesh_convergence_D.csv", "mesh_convergence_A.csv",
            "mesh_convergence_E.csv", "richardson_summary.csv"])


# ===========================================================================
def fig03_cases():
    rows = read_rows("production_results.csv")
    fig, axes = plt.subplots(1, 2, figsize=(12.2, 4.4))
    ax = axes[0]
    cases = ["D", "A", "E", "0"]
    vals = [num(next(r["voltage_V"] for r in rows if r["case"] == c))
            for c in cases]
    xpos = np.arange(len(cases))
    for x, v, c in zip(xpos, vals, cases):
        ax.plot([x, x], [0, v], color=CASE_COLOR[c], lw=2.4, zorder=2)
        ax.plot(x, v, "o", ms=11, color=CASE_COLOR[c], zorder=3,
                markeredgecolor="k", markeredgewidth=0.6)
        ax.annotate(f"{v:+.4f} V", (x, v),
                    textcoords="offset points", xytext=(0, 9 if v >= 0 else -16),
                    ha="center", fontsize=8)
    ax.axhline(0, color="grey", lw=0.7)
    ax.set_ylabel("nominal voltage [V] (finest mesh 80x40)")
    ax.set_xlim(-0.6, len(cases) - 0.4)
    labels = ["D pyro only", "A piezo+pyro", "E piezo-thermal",
              "0 zero temp."]
    ax.set_xticks(xpos)
    ax.set_xticklabels(labels, fontsize=8)
    pad_top(ax)                 # F14: headroom for the +0.19 V value label
    panel_label(ax, "(a)")
    ax2 = axes[1]
    # mechanism decomposition using same-mesh solves (16x8 from p3 CSV)
    p3 = read_rows("p3_sensitivity.csv")
    vE = num(p3[0]["voltage_V"])            # p_scale = 0  -> Case E value
    vA = num(p3[2]["voltage_V"])            # p_scale = 1
    mA = read_rows("mesh_convergence_D.csv")
    vD = num(next(r["voltage_V"] for r in mA if r["mesh"] == "16x8"))
    cats = ["V_D\n(pyro)", "V_E\n(piezo-thermal)", "V_D + V_E",
            "V_A\n(piezo+pyro)\n(solved)"]
    vals2 = [vD, vE, vD + vE, vA]
    cols = ["#2ca02c", "#d62728", "#9467bd", "#1f77b4"]
    xpos2 = np.arange(len(cats))
    for x, v, col in zip(xpos2, vals2, cols):
        ax2.plot([x, x], [0, v], color=col, lw=2.4, zorder=2)
        ax2.plot(x, v, "o", ms=11, color=col, zorder=3,
                 markeredgecolor="k", markeredgewidth=0.6)
        ax2.annotate(f"{v:+.4f}", (x, v), textcoords="offset points",
                     xytext=(0, 9 if v >= 0 else -16), ha="center", fontsize=8)
    ax2.axhline(0, color="grey", lw=0.7)
    ax2.set_xlim(-0.6, len(cats) - 0.4)
    ax2.set_xticks(xpos2)
    ax2.set_xticklabels(cats)
    pad_top(ax2)                # F14: headroom for the +0.1909 value label
    ax2.annotate("V$_D$ + V$_E$ $\\neq$ V$_A$: the mechanisms\n"
                 "share one linear solve for $(u,\\phi)$.\n"
                 "Same 16x8 mesh for all four points\n"
                 "($V_E$ read from the $p{=}0$ sweep run).",
                 xy=(0.20, 0.60), xycoords="axes fraction", va="center",
                 ha="center", fontsize=7.3, color="#222222",
                 bbox=dict(facecolor="white", alpha=0.94, edgecolor="#999999",
                           boxstyle="round,pad=0.35"))
    ax2.set_ylabel("voltage [V] (16x8 mesh)")
    panel_label(ax2, "(b)")
    finish(fig, os.path.join(FIG, "fig03_cases_and_decomposition"),
           "Figure 3: Open-circuit voltages and mechanism decomposition. (a) "
           "Nominal open-circuit voltages at the converged 80x40 mesh for "
           "Cases D, A, E and the zero-temperature null. (b) Mechanism "
           "decomposition on a common 16x8 mesh, showing that these "
           "cases do not combine additively "
           r"($V_D+V_E\neq V_A$).",
           "fig03_cases_and_decomposition",
           ["production_results.csv", "mesh_convergence_D.csv",
            "p3_sensitivity.csv"])


# ===========================================================================
def _load_field_grid(fname):
    rows = read_rows(fname)
    x = np.array([num(r["x"]) for r in rows])
    z = np.array([num(r["z"]) for r in rows])
    xs = np.unique(np.round(x, 14))
    zs = np.unique(np.round(z, 14))
    nx, nz = len(xs), len(zs)
    X = xs.reshape(1, nx).repeat(nz, 0)
    Z = zs.reshape(nz, 1).repeat(nx, 1)
    keys = list(rows[0].keys())
    keys.remove("x"); keys.remove("z")
    out = {"X": X, "Z": Z}
    for k in keys:
        a = np.array([num(r[k]) for r in rows]).reshape(nz, nx)
        out[k] = a
    return out


def fig04_solved_fields():
    f = _load_field_grid("fields_caseA_48x24.csv")
    X, Z = f["X"] * 1e6, f["Z"] * 1e6          # micrometres
    # Downsample only for the two 3D surfaces: the raw field-recovery grid
    # (81x161 points) is far finer than needed for a smooth 3D surface and
    # produces an impractically large vector (EPS) file if plotted at full
    # resolution, since mplot3d draws one polygon per grid cell regardless
    # of the `rasterized` flag on some backends. The 2D pcolormesh panels
    # keep the full-resolution field.
    sl = (slice(None, None, 8), slice(None, None, 8))
    Xs, Zs = X[sl], Z[sl]
    fig = plt.figure(figsize=(12.5, 9.2))
    ax = fig.add_subplot(2, 2, 1, projection="3d")
    surf = ax.plot_surface(Xs, Zs, f["phi"][sl], cmap="coolwarm", linewidth=0,
                           antialiased=True, rasterized=True)
    ax.set_xlabel("x [µm]"); ax.set_ylabel("z [µm]"); ax.set_zlabel("φ [V]", labelpad=10)   # F14
    panel_label(ax, "(a)")
    ax2 = fig.add_subplot(2, 2, 2)
    extent = [X.min(), X.max(), Z.min(), Z.max()]
    pc = ax2.imshow(f["Ez"], cmap="RdBu_r", origin="lower", extent=extent,
                    aspect="auto", interpolation="bilinear")
    fig.colorbar(pc, ax=ax2, label="E$_z$ [V/m]")
    ax2.set_xlabel("x [µm]"); ax2.set_ylabel("z [µm]")
    panel_label(ax2, "(b)")
    ax3 = fig.add_subplot(2, 2, 3, projection="3d")
    surf3 = ax3.plot_surface(Xs, Zs, f["eps_xx"][sl], cmap="viridis", linewidth=0,
                             antialiased=True, rasterized=True)
    ax3.set_xlabel("x [µm]"); ax3.set_ylabel("z [µm]")
    ax3.set_zlabel("ε$_{xx}$ [-]", labelpad=14)   # F14: clear the z ticks
    panel_label(ax3, "(c)")
    ax4 = fig.add_subplot(2, 2, 4)
    mag = np.hypot(f["u"], f["w"])
    pc4 = ax4.imshow(mag * 1e9, cmap="magma", origin="lower", extent=extent,
                     aspect="auto", interpolation="bilinear")
    fig.colorbar(pc4, ax=ax4, label="|u| [nm]")
    ax4.set_xlabel("x [µm]"); ax4.set_ylabel("z [µm]")
    panel_label(ax4, "(d)")
    finish(fig, os.path.join(FIG, "fig04_solved_fields"),
           "Figure 4: Solved finite-element fields of Case A (48x24 mesh), "
           "evaluated at the actual nodal basis at physical (x,z) "
           "points. (a) Electric potential, 3D surface. (b) Vertical electric "
           "field, 2D contour. (c) Longitudinal strain "
           r"$\varepsilon_{xx}$, 3D surface. (d) Displacement magnitude "
           r"$|\mathbf{u}|$, 2D contour.",
           "fig04_solved_fields", ["fields_caseA_48x24.csv"],
           raster_eps=True)     # F22: compact, pixel-identical EPS


# ===========================================================================
def _alpha_data(case):
    rows = read_rows(f"alpha_grid_{case}.csv")
    a1 = np.array([num(r["alpha1_factor"]) for r in rows]) * 21.8e-6
    a3 = np.array([num(r["alpha3_factor"]) for r in rows]) * (-4.3e-6)
    V = np.array([num(r["voltage_V"]) for r in rows])
    return a1 * 1e6, a3 * 1e6, V    # ppm/K


def fig05_alpha_3d():
    fig = plt.figure(figsize=(12.5, 5.2))
    planes = []
    for k, code in enumerate(["E", "A"]):
        a1p, a3p, V = _alpha_data(code)
        ax = fig.add_subplot(1, 2, k + 1, projection="3d")
        ax.stem(a1p, a3p, V, linefmt="C0-", markerfmt="oC0",
                basefmt="k-", bottom=0)
        ax.set_xlabel("α$_1$ [ppm/K]"); ax.set_ylabel("α$_3$ [ppm/K]")
        ax.set_zlabel("V [V]", labelpad=12)
        panel_label(ax, f"({chr(97+k)})")
        Xg = np.array([[a1p.min(), a1p.max()], [a1p.min(), a1p.max()]])
        Yg = np.array([[a3p.min(), a3p.min()], [a3p.max(), a3p.max()]])
        planes.append((ax, Xg, Yg,
                       ax.plot_surface(Xg, Yg, np.zeros((2, 2)), alpha=0.18,
                                       color="grey")))

    def _eps_planes():
        """F15: PostScript has no transparency, so the alpha=0.18 plane would
        print as an OPAQUE grey sheet and occlude stems behind it.  For the
        EPS only, swap the sheet for its dashed outline: same zero-reference
        information, nothing occluded."""
        for ax_, Xg, Yg, pl in planes:
            pl.set_visible(False)
            xs = [Xg[0, 0], Xg[0, 1], Xg[1, 1], Xg[1, 0], Xg[0, 0]]
            ys = [Yg[0, 0], Yg[0, 1], Yg[1, 1], Yg[1, 0], Yg[0, 0]]
            ax_.plot(xs, ys, np.zeros(5), color="#777777", lw=1.0,
                     linestyle=(0, (4, 3)), zorder=1)

    finish(fig, os.path.join(FIG, "fig05_alpha_grid_3d"),
           "Figure 5: Thermal-expansion 3x3 grid rendered as discrete "
           "3D stems (one bar per solved point, mesh 48x24; no interpolation "
           "between points), with a "
           "zero-reference plane. (a) Case E (piezo-thermal only) takes both "
           "positive and negative values over the sampled grid. (b) Case A "
           "(piezo+pyro) remains negative at every sampled point but its "
           "magnitude is alpha sensitive.",
           "fig05_alpha_grid_3d", ["alpha_grid_E.csv", "alpha_grid_A.csv"],
           eps_adjust=_eps_planes)


def _heat_panel(ax, case):
    """pcolormesh heatmap of the 3x3 alpha grid with every solved voltage
    printed exactly at the real (alpha1_factor, alpha3_factor) location."""
    rows = read_rows(f"alpha_grid_{case}.csv")
    s1 = np.array([0.5, 1.0, 1.5])     # alpha1 scale factors (grid convention)
    s3 = np.array([0.5, 1.0, 1.5])     # alpha3 scale factors
    M = np.zeros((3, 3))
    for r in rows:
        i = int(np.argmin(np.abs(s3 - num(r["alpha3_factor"]))))
        j = int(np.argmin(np.abs(s1 - num(r["alpha1_factor"]))))
        M[i, j] = num(r["voltage_V"])
    edges = np.array([0.25, 0.75, 1.25, 1.75])   # cell edges around centers
    pc = ax.pcolormesh(edges, edges, M, cmap="coolwarm", shading="flat")
    mx = max(abs(M).max(), 1e-30)
    pc.set_clim(-mx, mx)                          # symmetric colour scale
    for i in range(3):
        for j in range(3):
            ax.text(s1[j], s3[i], f"{M[i, j]:+.4f}", ha="center",
                    va="center", fontsize=8, color="k")
    ax.set_xticks(s1); ax.set_yticks(s3)
    ax.set_xticklabels(["0.5", "1", "1.5"])
    ax.set_yticklabels(["0.5", "1", "1.5"])
    ax.set_xlabel("α$_1$ scale factor (x +21.8 ppm/K)")
    ax.set_ylabel("α$_3$ scale factor (x -4.3 ppm/K)")
    return pc


def fig06_alpha_heatmap():
    fig, axes = plt.subplots(1, 3, figsize=(15.5, 4.6),
                             gridspec_kw=dict(wspace=0.55))
    pc1 = _heat_panel(axes[0], "A")
    pc2 = _heat_panel(axes[1], "E")
    fig.colorbar(pc1, ax=axes[0], fraction=0.046, pad=0.04, label="V [V]")
    fig.colorbar(pc2, ax=axes[1], fraction=0.046, pad=0.04, label="V [V]")
    panel_label(axes[0], "(a)")
    panel_label(axes[1], "(b)")
    ax = axes[2]
    a1p, a3p, V = _alpha_data("D")
    ax.plot(np.arange(9), V, "o-", color=CASE_COLOR["D"])
    ax.axhspan(V.min() - 1e-9, V.max() + 1e-9, color=CASE_COLOR["D"],
               alpha=0.15)
    ax.set_xlabel("scenario index (9 alpha pairs)")
    ax.set_ylabel("V [V]")
    ax.set_ylim(V.min() - 0.05 * abs(V.min()), V.max() + 0.05 * abs(V.min()))
    panel_label(ax, "(c)")
    fig.subplots_adjust(left=0.045, right=0.985, top=0.97, bottom=0.30,
                        wspace=0.55)
    finish(fig, os.path.join(FIG, "fig06_alpha_grid_heatmap"),
           "Figure 6: Discrete 3x3 thermal-expansion grid, not a continuous "
           "response surface. "
           "(a) Case A: annotated heatmap, one-signed but magnitude sensitive. "
           "(b) Case E: annotated heatmap, spanning both signs. Every cell states "
           "the solved voltage at its true "
           r"$(\alpha_1,\alpha_3)$ grid location. (c) Case D across all nine "
           "sampled points, shown as a flat band confirming its independence of alpha.",
           "fig06_alpha_grid_heatmap", ["alpha_grid_A.csv", "alpha_grid_E.csv",
                                        "alpha_grid_D.csv"],
           use_tight_layout=False)


def fig07_sign_evidence():
    a1p, a3p, V = _alpha_data("E")
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.4))
    ax = axes[0]
    npos = int((V > 0).sum()); nneg = int((V < 0).sum()); nzero = int((V == 0).sum())
    counts = [npos, nneg, nzero]
    labels = [f"positive\n({npos}/9)", f"negative\n({nneg}/9)", f"zero\n({nzero}/9)"]
    colors = ["#1f77b4", "#d62728", "#999999"]
    keep = [i for i, c in enumerate(counts) if c > 0]
    wedges, _ = ax.pie([counts[i] for i in keep],
                       colors=[colors[i] for i in keep],
                       startangle=90, counterclock=False,
                       wedgeprops=dict(edgecolor="white", linewidth=1.5),
                       radius=1.0)
    for w, i in zip(wedges, keep):
        ang = (w.theta1 + w.theta2) / 2.0
        rx, ry = 0.68 * np.cos(np.radians(ang)), 0.68 * np.sin(np.radians(ang))
        ax.text(rx, ry, labels[i], ha="center", va="center", fontsize=9,
                color="white", fontweight="bold")
    ax.set_aspect("equal")
    panel_label(ax, "(a)")
    ax2 = axes[1]
    order = np.argsort(np.abs(V))
    ax2.stem(np.arange(9), V[order], linefmt="C0-", markerfmt="oC0",
             basefmt="k-")
    ax2.axhline(0, color="grey", lw=0.8)
    ax2.set_xticks(np.arange(9))
    ax2.set_xticklabels([f"{v:+.4f}" for v in V[order]], rotation=60,
                        fontsize=6.5)
    ax2.set_ylabel("V [V]")
    panel_label(ax2, "(b)")
    ax3 = axes[2]
    s1f = np.round(a1p / 21.8, 3)          # alpha1 scale factors of the grid
    s3f = np.round(a3p / (-4.3), 3)
    for i in range(len(V)):
        ax3.scatter(a1p[i], V[i], s=46, c="#999999", zorder=2)
        ax3.annotate(f"{s1f[i]:.1f}|{s3f[i]:.1f}", (a1p[i], V[i]),
                     textcoords="offset points", xytext=(7, 2), fontsize=6,
                     va="center")
    i_nom = int(np.argmin(np.abs(s1f - 1.0) + np.abs(s3f - 1.0)))
    ax3.scatter(a1p[i_nom], V[i_nom], s=140, facecolor="none",
                edgecolor="red", lw=2, zorder=3,
                label="nominal ($\\alpha_1$ x1.0, $\\alpha_3$ x1.0)")
    ax3.axhline(0, color="grey", lw=0.8)
    ax3.set_xlim(a1p.min() - 2.0, a1p.max() + 5.5)   # F14: room for the labels
    ax3.set_xlabel("α$_1$ [ppm/K] (9 solved grid points)")
    ax3.set_ylabel("V [V]")
    ax3.legend(frameon=False, loc="lower right", fontsize=7)   # F18: off "(c)"
    panel_label(ax3, "(c)")
    finish(fig, os.path.join(FIG, "fig07_sign_evidence"),
           "Figure 7: Sign of Case E over the discrete 3x3 grid. "
           "(a) Counts of positive/negative/zero outcomes among the nine "
           "sampled points. (b) The nine solved values sorted by "
           "magnitude, with a zero reference line. (c) The nominal alpha pair "
           "highlighted among the nine.",
           "fig07_sign_evidence", ["alpha_grid_E.csv"])


def fig08_p3():
    rows = read_rows("p3_sensitivity.csv")
    s = np.array([num(r["p_scale"]) for r in rows])
    V = np.array([num(r["voltage_V"]) for r in rows])
    pred = np.array([num(r["affine_prediction_from_p0_p1_V"]) for r in rows])
    res = np.array([num(r["affine_residual_V"]) for r in rows])
    # p_scale=1.0 is the third row (index 2), not index 1 (which is p_scale=0.5).
    # Using the true p=1 point makes the affine slope/intercept exact and
    # consistent with the reported "solved p=0 and p=1" claim (previously this
    # used index 1, giving half the correct slope).
    i1 = int(np.argmin(np.abs(s - 1.0)))
    slope = (V[i1] - V[0]) / (s[i1] - s[0])
    fig, axes = plt.subplots(1, 2, figsize=(12.2, 4.3))
    ax = axes[0]
    ss = np.linspace(0, 2, 50)
    ax.plot(ss, V[0] + slope * ss, "-", color="#d62728", lw=1.2,
            label=f"affine line through solved p=0 and p=1\n"
                  f"(slope {slope:.6f} V per unit p$_3$ scale)")
    ax.plot(s, V, "o", color=CASE_COLOR["A"], ms=6, label="solved points "
            "(Case A, fixed K, 16x8 mesh)")
    ax.set_xlabel("p$_3$ scale factor")
    ax.set_ylabel("open-circuit voltage [V]")
    ax.legend(frameon=False, fontsize=7.5)
    panel_label(ax, "(a)")
    ax2 = axes[1]
    ax2.plot(s, res * 1e15, "o-", color="#1f77b4")
    ax2.axhline(0, color="grey", lw=0.8)
    ax2.set_xlabel("p$_3$ scale factor")
    ax2.set_ylabel("affine residual [10$^{-15}$ V]")
    ax2.text(0.97, 0.94, f"max |residual| = {np.max(np.abs(res)):.2e} V "
             "(machine precision)", transform=ax2.transAxes, fontsize=8,
             ha="right", va="top")
    panel_label(ax2, "(b)")
    finish(fig, os.path.join(FIG, "fig08_p3_sensitivity"),
           "Figure 8: Pyroelectric-coefficient sensitivity at fixed stiffness "
           "(Case A, 16x8 mesh). (a) Solved voltages vs. "
           r"$p_3$ scale factor, with the affine line through the $p=0$ and "
           r"$p=1$ solutions. (b) Affine residual on a scaled axis, showing "
           "machine-precision affinity.",
           "fig08_p3_sensitivity", ["p3_sensitivity.csv"])


def fig09_verification_energy():
    rows = read_rows("verification_results.csv")
    names = [r["check"] for r in rows]
    vals = np.array([num(r["value"]) if r["check"] !=
                     "superposition_V_A_ne_V_D_plus_V_E" else np.nan
                     for r in rows])
    tols = np.array([num(r["tolerance"]) for r in rows])
    keep = ~np.isnan(vals) & np.isfinite(tols) & (tols > 0)
    ratio = np.maximum(np.abs(vals[keep]) / tols[keep], 1e-9)
    SHORT = {
        "BFS_partition_of_unity": "BFS partition of unity",
        "BFS_exact_linear_field_recovery": "BFS exact linear recovery",
        "Maxwell_reciprocity_coupled_matrix_relF": "Maxwell reciprocity (flexo)",
        "D_exact_1D_pyro_at_default_mesh_16x8": "Case D = 1D pyro (16x8)",
        "D_exact_1D_pyro_at_final_mesh_80x40": "Case D = 1D pyro (80x40)",
        "zero_temperature": "zero temperature null",
        "zero_alpha_Case_E": "zero alpha null (E)",
        "zero_p_Case_D": "zero pyroelectric null (D)",
        "zero_p_A_equals_E": "A(p=0) equals E",
        "p_affinity_fixed_K_maxres": "p3 affinity residual (fixed K)",
        "enthalpy_variational_consistency": "enthalpy consistency (80x40)",
    }
    fig = plt.figure(figsize=(15, 4.6))
    ax = fig.add_subplot(1, 3, 1)
    x = np.arange(keep.sum())
    ax.semilogy(x, ratio, "o", color="#1f77b4", ms=6,
                label="|residual| / tolerance")
    ax.axhline(1.0, color="#d62728", lw=1.2, ls="--")
    ax.set_xticks(x)
    ax.set_xticklabels([SHORT.get(n, n) for n in np.array(names)[keep]],
                       rotation=45, fontsize=6.2, ha="right")
    ax.set_ylabel("|residual| / tolerance (log scale)")
    ax.set_ylim(1e-10, 10)      # F16: make the exact-0 checks visible
    ax.annotate("exact-0 checks\n(floored at 1e-9)", xy=(0.02, 1.6e-9),
                xycoords=("axes fraction", "data"), fontsize=6.5,
                color="#444444", va="bottom")
    ax.legend(frameon=False, fontsize=7.5)
    ax.grid(True, which="both", alpha=0.2)
    panel_label(ax, "(a)")
    ax2 = fig.add_subplot(1, 3, 2)
    e = read_rows("energy_audit_A.csv")[0]
    terms = ["elastic_quadratic", "dielectric_enthalpy", "piezo_coupling",
             "pyroelectric_enthalpy", "thermoelastic_coupling",
             "strain_gradient", "flexo_coupling"]
    short = ["1/2 ε'Cε", "-1/2 E'κE", "-eε·E", "-pθ·E", "-βθ·ε",
             r"1/2 $\eta'A\eta$ ($\ell=0$)", "-μη·E"]
    vals2 = [num(e[t]) for t in terms]
    cols = ["#2ca02c", "#1f77b4", "#9467bd", "#d62728", "#ff7f0e",
            "#7f7f7f", "#7f7f7f"]
    xpos2 = np.arange(len(terms))
    for x, v, col in zip(xpos2, vals2, cols):
        ax2.plot([x, x], [0, v], color=col, lw=2.6, zorder=2)
        ax2.plot(x, v, "o", ms=10, color=col, zorder=3,
                 markeredgecolor="k", markeredgewidth=0.6)
    ax2.set_xticks(xpos2)
    ax2.set_xticklabels(short, rotation=30, fontsize=7.5)
    ax2.axhline(0, color="grey", lw=0.8)
    ax2.set_xlim(-0.5, len(terms) - 0.5)
    pad_top(ax2, top=0.10, bot=0.10)   # F14: symmetric headroom for markers
    ax2.set_ylabel("signed value [J/m per unit depth]")
    panel_label(ax2, "(b)")
    # (c) genuine 3D view of the same energy terms - replaces a text dashboard
    ax3 = fig.add_subplot(1, 3, 3, projection="3d")
    zs = np.array(vals2)
    for x, (z, col) in enumerate(zip(zs, cols)):
        ax3.plot([x, x], [0, 0], [0, z], color=col, lw=2.6)
        ax3.scatter([x], [0], [z], s=55, color=col, edgecolor="k",
                    linewidth=0.5, depthshade=False)
    ax3.plot(np.arange(len(terms)), np.zeros(len(terms)),
             np.zeros(len(terms)), color="grey", lw=1.0)
    ax3.set_xticks(xpos2)
    ax3.set_xticklabels([f"T{i+1}" for i in range(len(terms))], fontsize=7)
    ax3.set_zlabel("signed value [J/m]")
    ax3.set_yticks([])
    ax3.view_init(elev=18, azim=-60)
    panel_label(ax3, "(c)")
    fig.subplots_adjust(left=0.045, right=0.98, top=0.95, bottom=0.34,
                        wspace=0.32)
    finish(fig, os.path.join(FIG, "fig09_verification_energy"),
           "Figure 9: Verification and energy synthesis. (a) Internal "
           "verification residuals normalized by their tolerances (values "
           "below the dashed line at 1.0 indicate PASS). (b) Signed "
           "energy/enthalpy terms for Case A on the 80x40 mesh (T1-T7 label "
           "the same seven terms as panel b, left to right). (c) The same "
           "seven signed energy terms viewed as a 3D stem plot.",
           "fig09_verification_energy", ["verification_results.csv",
                                         "energy_audit_A.csv",
                                         "production_results.csv",
                                         "numeric_acceptance_vs_frozen.csv"],
           use_tight_layout=False)


# ===========================================================================
def fig10_validation():
    # ---- panel data ------------------------------------------------------
    prod = read_rows("production_results.csv")
    acc = read_rows("numeric_acceptance_vs_frozen.csv")
    matrows = read_rows("material_parameter_record.csv")
    ver = read_rows("verification_results.csv")
    # 1D exact and FEM (Case D)
    matD = next(r for r in prod if r["case"] == "D")
    v_fem = num(matD["voltage_V"])
    v_1d = num(next(r["value"] for r in ver
                    if r["check"] == "D_1D_identity_analytic_voltage_V"))
    e1d = abs(v_fem - v_1d) / abs(v_1d)
    # legacy master-record (pre-correction) values (record Sec. 19.9)
    legacy = {"D": -2.016801905066599, "A": -0.8948205842740348,
              "E": 0.4543473357396004}
    # frozen baseline at 80x40
    frozen = {r["item"].replace("nominal_voltage_case_", ""):
              num(r["frozen_zip_V"]) for r in acc
              if r["item"].startswith("nominal_voltage_case_")}
    py = {c: num(next(r["voltage_V"] for r in prod if r["case"] == c))
          for c in "DAE"}

    fig = plt.figure(figsize=(14.5, 11.5))
    gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.05],
                          hspace=0.62, wspace=0.32,
                          top=0.94, bottom=0.11, left=0.07, right=0.97)
    # (a)
    ax = fig.add_subplot(gs[0, 0])
    for x, v, col in zip([0, 1], [v_fem, v_1d], ["#1f77b4", "#2ca02c"]):
        ax.plot([x, x], [0, v], color=col, lw=3.0, zorder=2)
        ax.plot(x, v, "o", ms=15, color=col, zorder=3,
                markeredgecolor="k", markeredgewidth=0.7)
    ax.axhline(0, color="grey", lw=0.6)
    ax.set_xlim(-0.6, 1.6)
    ax.set_xticks([0, 1])
    ax.set_xticklabels([f"Case D FEM (80x40)\n{v_fem:+.6f} V",
                        f"exact 1D identity\n{v_1d:+.6f} V"], fontsize=9)
    ax.set_title("")
    ax.annotate(f"relative error = {e1d:.2e}  (< 1e-10)",
                xy=(0.5, 0.05), xycoords="axes fraction", ha="center",
                fontsize=9, color="#b00000",
                bbox=dict(facecolor="white", alpha=0.85, edgecolor="none", pad=1.5))
    ax.set_ylabel("voltage [V]")
    ax.set_ylim(-4.3, 0.15)
    panel_label(ax, "(a)")
    # (b) material parameter provenance
    ax = fig.add_subplot(gs[0, 1])
    params = [r["parameter"] for r in matrows]
    used = [abs(num(r["value_SI"])) for r in matrows]
    src = [abs(num(r["source_reported_SI"])) for r in matrows]
    xpos = np.arange(len(params))
    for i, (u, s) in enumerate(zip(used, src)):
        ax.scatter([i - 0.16, i + 0.16], [u, s], s=24,
                   color=["#1f77b4", "#d62728"], alpha=0.9, zorder=3)
    ax.set_yscale("log")
    ax.set_ylim(1e-9, 1e13)
    ax.set_xticks(xpos)
    ax.set_xticklabels(params, rotation=70, fontsize=6.5)
    ax.set_ylabel("|parameter value| [SI] (log)")
    ax.annotate("ell = 0 is exact zero (not plottable on a log axis);\n"
                "all 14 parameters compared in\nmaterial_parameter_record.csv "
                "(rel. diff 0.0)",
                xy=(0.98, 0.98), xycoords="axes fraction", ha="right",
                va="top", fontsize=6.5, color="#444444")   # F16 disclosure
    ax.plot([], [], "o", color="#1f77b4", label="value used by this code")
    ax.plot([], [], "o", color="#d62728", label="value reported by source")
    ax.annotate("relative difference = 0.0 for every parameter",
                xy=(0.66, 0.045), xycoords="axes fraction", ha="center",  # F18
                va="bottom", fontsize=8.5, color="#1a7a1a",
                bbox=dict(facecolor="white", alpha=0.85, edgecolor="none", pad=1.5))
    ax.legend(frameon=True, framealpha=0.9, loc="lower left",
              fontsize=7)   # F18: upper-left occluded the C11-C33 markers
    panel_label(ax, "(b)", loc="lower right")
    # (c) historical self-comparison - slope chart (legacy -> frozen -> python)
    ax = fig.add_subplot(gs[1, 0])
    cases = ["D", "A", "E"]
    xpos3 = [0, 1, 2]
    stage_labels = ["master record\nlegacy", "frozen FEM5\nrelease",
                    "this Python\nrun"]
    for c in cases:
        yvals = [legacy[c], frozen[c], py[c]]
        ax.plot(xpos3, yvals, "-", color=CASE_COLOR[c], lw=1.6, alpha=0.85,
                zorder=2)
        ax.plot(xpos3, yvals, "o", ms=10, color=CASE_COLOR[c], zorder=3,
                markeredgecolor="k", markeredgewidth=0.6)
        ax.annotate(f"Case {c}", (xpos3[-1], yvals[-1]),
                    textcoords="offset points", xytext=(10, 0),
                    va="center", fontsize=8.5, color=CASE_COLOR[c],
                    fontweight="bold")
    ax.axhline(0, color="grey", lw=0.7)
    ax.set_xlim(-0.3, 2.7)
    ax.set_xticks(xpos3)
    ax.set_xticklabels(stage_labels, fontsize=8)
    ax.set_ylabel("voltage [V]")
    ax.set_ylim(-4.3, 1.1)
    rel_err = {r["item"].replace("nominal_voltage_case_", ""):
               num(r["relative_error"]) for r in acc
               if r["item"].startswith("nominal_voltage_case_")}
    err_text = ("|this Python - frozen| / |frozen|:\n" +
                "\n".join(f"  Case {c}: {rel_err[c]:.1e}" for c in "DAE"))
    ax.text(0.98, 0.30, err_text, transform=ax.transAxes,
            va="top", ha="right", fontsize=6.8, family="monospace",
            bbox=dict(facecolor="white", alpha=0.92, edgecolor="#999999",
                      boxstyle="round,pad=0.35"))
    panel_label(ax, "(c)")
    # (d) explicit validation-scope statement
    ax = fig.add_subplot(gs[1, 1])
    ax.axis("off")
    panel_label(ax, "(d)")
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    checklist = [
        ("Internal code verification\n(panel a: 1D exact pyroelectric\n"
         "identity, rel. error < 1e-10)", True),
        ("Material-input fidelity to cited\nsources (panel b: relative\n"
         "difference = 0 for every parameter)", True),
        ("Consistency with this project's own\nprior corrected baseline "
         "(panel c:\nagreement better than 1e-6)", True),
        ("Independent experimental full-device\nvoltage measurement of "
         "this system", False),
    ]
    y0 = 8.3
    for text, ok in checklist:
        box_col = "#2ca02c" if ok else "#d62728"
        mark = "OK" if ok else "X"
        note = "PASS" if ok else "NOT CLAIMED"
        ax.add_patch(Rectangle((0.2, y0 - 0.75), 1.1, 1.5,
                               facecolor=box_col, edgecolor="k", lw=0.8))
        ax.text(0.75, y0, mark, ha="center", va="center", fontsize=15,
                color="white", fontweight="bold")
        ax.text(1.55, y0 + 0.30, text, ha="left", va="center", fontsize=8.0)
        ax.text(9.8, y0, note, ha="right", va="center", fontsize=8.2,
                color=box_col, fontweight="bold")
        y0 -= 2.15
    ax.plot([0.2, 9.8], [0.55, 0.55], color="#cccccc", lw=0.8)
    ax.text(0.2, 0.05, "This figure is an internal verification and "
            "parameter-provenance consistency check; it is not\n"
            "\u201cvalidation against literature\u201d and not an "
            "experimental validation of any device voltage.",
            ha="left", va="bottom", fontsize=7.4, style="italic",
            color="#333333")
    finish(fig, os.path.join(FIG, "fig10_validation"),
           "Figure 10: Internal verification and parameter-provenance "
           "consistency check (four mandatory panels). (a) Internal "
           "analytical benchmark of Case D against the exact 1D pyroelectric "
           "identity. (b) Material-parameter provenance: every code input "
           "exactly equals its cited source value. (c) Historical "
           "self-comparison with the frozen FEM5 release (prior internal "
           "computational baseline of this project, not an independent "
           "external publication), showing the effect of Corrections 1-4. "
           "(d) Explicit validation-scope statement.",
           "fig10_validation", ["verification_results.csv",
                                "production_results.csv",
                                "numeric_acceptance_vs_frozen.csv",
                                "material_parameter_record.csv"],
           use_tight_layout=False)


FUNCS = {
    "fig01": fig01_model_schematic,
    "fig02": fig02_mesh_convergence,
    "fig03": fig03_cases,
    "fig04": fig04_solved_fields,
    "fig05": fig05_alpha_3d,
    "fig06": fig06_alpha_heatmap,
    "fig07": fig07_sign_evidence,
    "fig08": fig08_p3,
    "fig09": fig09_verification_energy,
    "fig10": fig10_validation,
}


def main():
    if not os.path.isdir(RES) or not os.path.exists(
            os.path.join(RES, "production_results.csv")):
        raise SystemExit("results/ not found - run 'python3 run_production.py' "
                         "first")
    os.makedirs(FIG, exist_ok=True)
    for name, func in FUNCS.items():
        print(f"  figure {name} ...")
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            func()
    print("all figures written to", FIG)
    write_captions_file()
    print("captions written to", os.path.join(FIG, "captions.md"), "and .tex")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
