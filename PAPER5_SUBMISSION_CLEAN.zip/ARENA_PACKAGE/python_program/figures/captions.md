# Figure captions (for the manuscript text, not the artwork)

**fig01_model_schematic**

Figure 1: Model configuration and mechanism chain. (a) Specimen geometry ($L=10\,\mu$m$\times h=1\,\mu$m, $E=-\nabla\phi$): clamped root, poling direction, prescribed thermal gradient, grounded bottom electrode, and open-circuit top electrode. (b) Mechanism chain from the prescribed temperature field through anisotropic thermal expansion and the plane-strain thermal stress to the resulting mechanical deformation, piezoelectric charge, and open-circuit voltage.

**fig02_mesh_convergence**

Figure 2: Mesh-convergence study for Cases D, A and E over six h-refinement levels (8x4 to 80x40). (a) Voltage vs. full DOF. (b) Final-step relative change (bars) and the Richardson-based per-level error estimate $|V-V_{\infty}|/|V_{\infty}|$ (diamonds); the two are distinct convergence measures shown separately.

**fig03_cases_and_decomposition**

Figure 3: Open-circuit voltages and mechanism decomposition. (a) Nominal open-circuit voltages at the converged 80x40 mesh for Cases D, A, E and the zero-temperature null. (b) Mechanism decomposition on a common 16x8 mesh, showing that these cases do not combine additively ($V_D+V_E\neq V_A$).

**fig04_solved_fields**

Figure 4: Solved finite-element fields of Case A (48x24 mesh), evaluated at the actual nodal basis at physical (x,z) points. (a) Electric potential, 3D surface. (b) Vertical electric field, 2D contour. (c) Longitudinal strain $\varepsilon_{xx}$, 3D surface. (d) Displacement magnitude $|\mathbf{u}|$, 2D contour.

**fig05_alpha_grid_3d**

Figure 5: Thermal-expansion 3x3 grid rendered as discrete 3D stems (one bar per solved point, mesh 48x24; no interpolation between points), with a zero-reference plane. (a) Case E (piezo-thermal only) takes both positive and negative values over the sampled grid. (b) Case A (piezo+pyro) remains negative at every sampled point but its magnitude is alpha sensitive.

**fig06_alpha_grid_heatmap**

Figure 6: Discrete 3x3 thermal-expansion grid, not a continuous response surface. (a) Case A: annotated heatmap, one-signed but magnitude sensitive. (b) Case E: annotated heatmap, spanning both signs. Every cell states the solved voltage at its true $(\alpha_1,\alpha_3)$ grid location. (c) Case D across all nine sampled points, shown as a flat band confirming its independence of alpha.

**fig07_sign_evidence**

Figure 7: Sign of Case E over the discrete 3x3 grid. (a) Counts of positive/negative/zero outcomes among the nine sampled points. (b) The nine solved values sorted by magnitude, with a zero reference line. (c) The nominal alpha pair highlighted among the nine.

**fig08_p3_sensitivity**

Figure 8: Pyroelectric-coefficient sensitivity at fixed stiffness (Case A, 16x8 mesh). (a) Solved voltages vs. $p_3$ scale factor, with the affine line through the $p=0$ and $p=1$ solutions. (b) Affine residual on a scaled axis, showing machine-precision affinity.

**fig09_verification_energy**

Figure 9: Verification and energy synthesis. (a) Internal verification residuals normalized by their tolerances (values below the dashed line at 1.0 indicate PASS). (b) Signed energy/enthalpy terms for Case A on the 80x40 mesh (T1-T7 label the same seven terms as panel b, left to right). (c) The same seven signed energy terms viewed as a 3D stem plot.

**fig10_validation**

Figure 10: Internal verification and parameter-provenance consistency check (four mandatory panels). (a) Internal analytical benchmark of Case D against the exact 1D pyroelectric identity. (b) Material-parameter provenance: every code input exactly equals its cited source value. (c) Historical self-comparison with the frozen FEM5 release (prior internal computational baseline of this project, not an independent external publication), showing the effect of Corrections 1-4. (d) Explicit validation-scope statement.

