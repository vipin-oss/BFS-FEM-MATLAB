"""paper2py - independent from-scratch Python implementation of the
Paper-2 master calculation record (Thermally Driven Open-Circuit Voltage in
Plane-Strain BaTiO3, piezoelectricity + pyroelectricity + flexoelectricity +
optional Mindlin strain-gradient elasticity).

SOLE PHYSICS SOURCE OF TRUTH: 'complete calculation.pdf' (the master
calculation record).  Equation numbers cited in docstrings refer to that
document's section numbers.  The numeric acceptance baseline used ONLY for
cross-checking (Part 3 of the build brief) is
FEM5_FINAL_FROZEN_RELEASE.zip, whose SHA-256 was verified as
496e777d7c504918c246875c8cbff80d9d9f7c6f7e847087520e67a52f4f1e92.

Four audited corrections (verified independently here - see traceability note)
are applied: see paper2.corrections for the derivations.
"""

from . import materials, bfs_shape, corrections

__all__ = ["materials", "bfs_shape", "corrections"]

__version__ = "1.0.0"
