"""bfs_shape.py - Bogner-Fox-Schmit (tensor-product cubic Hermite) 16-DOF C1
element for each scalar mechanical field, bilinear Q4 potential basis, and the
4x4 Gauss-Legendre rule - exactly as prescribed by the master record.

Master-record references:
  Sec. 12.2  Eqs. 12.1-12.6  1-D Hermite basis and derivatives on [-1,1]
  Sec. 12.4  Eq. 12.7        physical element mapping
  Sec. 12.6  Eq. 12.12       16-function scalar BFS basis with physical
                             derivative DOFs [value, dx, dz, dxz]
  Sec. 15.1  Eq. 15.1-15.3   bilinear Q4 basis and Bphi
  Sec. 16.1  Eq. 16.1        4x4 Gauss-Legendre rule (abscissae/weights quoted
                             in Sec. 30.4)

Local corner order is [BL, BR, TR, TL] matching the record's element map
(Sec. 12.6 / Appendix C).  All functions are pure and unit-testable.
"""
from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------------------
# 1-D cubic Hermite basis on s in [-1, 1] (record Eqs. 12.1-12.6 / C.1-C.4)
# index: 0 = H00 (value @ -1), 1 = H10 (slope @ -1),
#        2 = H01 (value @ +1), 3 = H11 (slope @ +1)
# ---------------------------------------------------------------------------
def hermite_1d(s: float):
    """Return (H, dH, d2H), each length-4 arrays over [-1,1]."""
    H = np.array(
        [
            (2 - 3 * s + s**3) / 4.0,
            (1 - s - s**2 + s**3) / 4.0,
            (2 + 3 * s - s**3) / 4.0,
            (-1 - s + s**2 + s**3) / 4.0,
        ]
    )
    dH = np.array(
        [
            (-3 + 3 * s**2) / 4.0,
            (-1 - 2 * s + 3 * s**2) / 4.0,
            (3 - 3 * s**2) / 4.0,
            (-1 + 2 * s + 3 * s**2) / 4.0,
        ]
    )
    d2H = np.array(
        [
            1.5 * s,
            (-1 + 3 * s) / 2.0,
            -1.5 * s,
            (1 + 3 * s) / 2.0,
        ]
    )
    return H, dH, d2H


# corners (xi, eta) in local node order [BL, BR, TR, TL]
CORNERS_REF = np.array([(-1.0, -1.0), (1.0, -1.0), (1.0, 1.0), (-1.0, 1.0)])


def bfs_shape(xi: float, eta: float, hx: float, hz: float):
    """16-function scalar BFS basis and its physical derivatives.

    Returns (N, Nx, Nz, Nxx, Nzz, Nxz), each a length-16 array in local DOF
    order (4 DOFs per corner [value, dx, dz, dxz], corners BL,BR,TR,TL), with
    derivative DOFs storing PHYSICAL derivatives (Jx,Jz factors, Sec. 12.6).
    """
    Jx = hx / 2.0
    Jz = hz / 2.0
    Hx, dHx, d2Hx = hermite_1d(xi)
    Hz, dHz, d2Hz = hermite_1d(eta)

    N = np.zeros(16)
    Nx = np.zeros(16)
    Nz = np.zeros(16)
    Nxx = np.zeros(16)
    Nzz = np.zeros(16)
    Nxz = np.zeros(16)

    for a in range(4):
        xc = CORNERS_REF[a, 0]   # -1 or +1
        yc = CORNERS_REF[a, 1]
        ix_val = 0 if xc < 0.0 else 2
        iz_val = 0 if yc < 0.0 else 2
        ix_slp = ix_val + 1
        iz_slp = iz_val + 1

        ix = np.array([ix_val, ix_slp, ix_val, ix_slp])
        iz = np.array([iz_val, iz_val, iz_slp, iz_slp])
        scale = np.array([1.0, Jx, Jz, Jx * Jz])

        for b in range(4):
            q = 4 * a + b
            s = scale[b]
            N[q] = Hx[ix[b]] * Hz[iz[b]] * s
            Nx[q] = dHx[ix[b]] * Hz[iz[b]] * s / Jx
            Nz[q] = Hx[ix[b]] * dHz[iz[b]] * s / Jz
            Nxx[q] = d2Hx[ix[b]] * Hz[iz[b]] * s / (Jx**2)
            Nzz[q] = Hx[ix[b]] * d2Hz[iz[b]] * s / (Jz**2)
            Nxz[q] = dHx[ix[b]] * dHz[iz[b]] * s / (Jx * Jz)
    return N, Nx, Nz, Nxx, Nzz, Nxz


def bilinear_shape(xi: float, eta: float, hx: float, hz: float):
    """Q4 potential basis (record Sec. 15.1).  Returns (N, Bphi):
    N  length-4 shape values (order BL,BR,TR,TL)
    Bphi 2x4 with Bphi[0,:]=dN/dx, Bphi[1,:]=dN/dz (E = -Bphi qphi)."""
    Jx = hx / 2.0
    Jz = hz / 2.0
    N = 0.25 * np.array(
        [
            (1 - xi) * (1 - eta),
            (1 + xi) * (1 - eta),
            (1 + xi) * (1 + eta),
            (1 - xi) * (1 + eta),
        ]
    )
    dNxi = 0.25 * np.array(
        [-(1 - eta), (1 - eta), (1 + eta), -(1 + eta)]
    )
    dNeta = 0.25 * np.array(
        [-(1 - xi), -(1 + xi), (1 + xi), (1 - xi)]
    )
    Bphi = np.vstack([dNxi / Jx, dNeta / Jz])
    return N, Bphi


# ---------------------------------------------------------------------------
# Gauss-Legendre 4-point rule (record Sec. 30.4)
# ---------------------------------------------------------------------------
GAUSS_PTS = np.array(
    [-0.8611363115940526, -0.3399810435848563,
     0.3399810435848563, 0.8611363115940526]
)
GAUSS_WTS = np.array(
    [0.3478548451374539, 0.6521451548625461,
     0.6521451548625461, 0.3478548451374539]
)
QUADRATURE_ORDER = 4  # 4 x 4 rule, 16 integration points per element


def gauss_points_2d():
    """Yield (xi, eta, weight) over the 16-point tensor rule (Sec. 16.1)."""
    for i in range(4):
        for j in range(4):
            yield GAUSS_PTS[i], GAUSS_PTS[j], GAUSS_WTS[i] * GAUSS_WTS[j]
