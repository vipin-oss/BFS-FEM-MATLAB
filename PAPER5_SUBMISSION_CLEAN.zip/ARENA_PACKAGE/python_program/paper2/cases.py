"""cases.py - the master record's Specimen-M production case set (Sec. 19.2)
expressed as explicit mechanism on/off flags rather than copy-pasted solve
functions.

Case   physics                                   production   record location
A      piezo + pyro, no flexo                    YES          Sec. 19.5
B      piezo + pyro + flexo (mu != 0)            NO*          Sec. 19.6
C      flexo only (e=p=0, mu != 0)               NO*          Sec. 19.7
D      pyro only (exact-1D anchor)               YES          Sec. 19.3 / 18.2
E      piezo-thermal only                        YES          Sec. 19.4
0      zero imposed temperature increment        YES (null)   Sec. 19.8 / 24.1

* B and C are flexoelectric-active.  The master record itself marks mu and the
  Mindlin length ell as SENSITIVITY / MODEL CHOICE inputs that are NOT
  source-controlled for BaTiO3 (Sec. 26.1, Appendix L.17), so flexo-active
  cases are excluded from all quantitative production output (they are
  implemented, and unit-tested at matrix level only).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Case:
    name: str
    piezo: bool
    pyro: bool
    flexo: bool
    production: bool
    description: str
    mesh_ref: tuple            # record-reference mesh (Sec. 19.2)
    temperature_on: bool = True


_CASES = {
    "A": Case("A", True, True, False, True,
              "piezo + pyro (no flexo)", (24, 12)),
    "B": Case("B", True, True, True, False,
              "piezo + pyro + flexo - EXPLORATORY, not production", (16, 8)),
    "C": Case("C", False, False, True, False,
              "flexo only - EXPLORATORY, not production", (16, 8)),
    "D": Case("D", False, True, False, True,
              "pyro only (1D-exact anchor)", (16, 8)),
    "E": Case("E", True, False, False, True,
              "piezo-thermal only", (16, 8)),
    "0": Case("0", True, True, False, True,
              "zero imposed temperature (null)", (24, 12), temperature_on=False),
}

PRODUCTION_CASES = ["A", "D", "E", "0"]


def get_case(name: str) -> Case:
    name = name.upper()
    if name not in _CASES:
        raise KeyError(f"unknown case {name!r}; use {sorted(_CASES)}")
    return _CASES[name]


def all_cases():
    return list(_CASES.values())
