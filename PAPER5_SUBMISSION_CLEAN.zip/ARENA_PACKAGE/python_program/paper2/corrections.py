"""Independent re-derivation of the four audited corrections to the master
calculation record (build brief, 'KNOWN, ALREADY-AUDITED CORRECTIONS').

Each correction below was re-derived here from the electric enthalpy and the
boundary conditions stated in the master record, NOT accepted on assertion.
The master record is the only physics source; these notes reconcile the record
with thermodynamics/mechanics.

Electric enthalpy used in the record (master Sec. 5.1, Eq. 5.1), with E=-grad
phi (Eq. 2.6), engineering shear gamma_xz = 2*eps_xz (Sec. 4.2) and plane strain
(Sec. 7.1, eps_yy = gamma_xy = gamma_yz = 0, d/dy = 0):

    H = 1/2 C:eps:eps + 1/2 A:eta:eta - e:eps.E - 1/2 kappa:E:E
        - mu:eta.E - beta:eps*theta - p.E*theta - 1/2 c_v theta^2/T0
    with beta = C:alpha  (Eq. 5.1 term catalogue; Sec. 5.3 Eq. 5.8)

Constitutive response is the *derivative* of this single scalar potential
(Sec. 5.2, Eqs. 5.3-5.6):

    sigma   =  dH/deps        = C:eps - e'.E - beta*theta        (= C:(eps-eps_th) - e'.E, eps_th=alpha*theta)
    m       =  dH/d(eta)      = A:eta - mu'.E
    D       = -dH/dE          = e:eps + kappa:E + mu:eta + p*theta

--------------------------------------------------------------------------------
CORRECTION 1 - plane-strain thermal-stress vector beta_PS.

Master-record route (Eq. 6.4) forms  beta = C_reduced * [alpha1, alpha3, 0]
with the *already plane-strain-reduced* in-plane stiffness
C_reduced = [[C11,C13,0],[C13,C33,0],[0,0,C44]] (Sec. 30.1 / Eq. 7.10).  That
multiplies the yy-slot of the eigenstrain by nothing, because C_reduced has no
C12 column.  But plane strain only sets the TOTAL strain eps_yy = 0; it does
not set the yy *eigenstrain* alpha2*theta to zero.  Substituting eps_yy=0 into
the FULL 3D law (alpha_3d = [alpha1, alpha1, alpha3], alpha1=alpha2 for the
tetragonal 4mm basal plane):

    sigma_xx = C11*(eps_xx-aph1*th) + C12*(0-alpha1*th) + C13*(eps_zz-alpha3*th)
             = C11*eps_xx + C13*eps_zz - [(C11+C12)*alpha1 + C13*alpha3]*theta
    sigma_zz = C13*(eps_xx-alpha1*th) + C13*(0-alpha1*th) + C33*(eps_zz-alpha3*th)
             = C13*eps_xx + C33*eps_zz - [2*C13*alpha1 + C33*alpha3]*theta

The in-plane *stiffness* is unchanged (the C12*eps_yy and C12*alpha terms with
*zero total* eps_yy vanish from the stiffness but the eigenstrain survives in
the thermal stress).  Hence

    beta_PS = [ (C11+C12)*alpha1 + C13*alpha3 ;
                2*C13*alpha1  + C33*alpha3 ; 0 ]        <-- IMPLEMENTED

Implementing the wrong (record-literal) formula would omit the C12*alpha1 term
in sigma_xx and one C13*alpha1 term in sigma_zz.  beta_plane_strain() in
materials.py computes the full 3D contraction first and then selects the active
(xx,zz) components, which is the order required by the correction.

--------------------------------------------------------------------------------
CORRECTION 2 - reciprocal electromechanical coupling (Hessian symmetry).

H is one scalar potential in (eps, eta, E).  Mixed second derivatives of a
scalar potential commute, so the assembled electromechanical coupling blocks
MUST be exact transposes of one another:

    delta^2H/dE_l d(eps_ij)  = -e_ijl        ->  mechanical side   -sigma/ dE ... = e'? see below
    delta^2H/dE_l d(eta_ijk) = -mu_lijk      ->  flexo coupling

Mechanical residual (variation of H with respect to u) carries the terms
-dH/deps : deps/du  and  -dH/d(eta):d(eta)/du.  With E=-Bphi*qphi,
eps=Beps*qu, eta=Beta*qu the two coupling contributions are

    K_uu? -> no; K_uphi^piezo = int Beps' (e^T) Bphi      (from sigma = -e'.E, E=-Bphi qphi => +e'Bphi qphi)
    K_uphi^flex  = int Beta' (mu^T) Bphi

Electrical residual carries D = e:eps + mu:eta + ... through int Bphi^T D:

    K_phiu^piezo = int Bphi^T e Beps = (K_uphi^piezo)^T
    K_phiu^flex  = int Bphi^T mu Beta = (K_uphi^flex)^T

so the total block K_uphi = K_phiu^T (Hessian symmetry).  A flexoelectric term
placed only on the electrical side (as in the record's literal Eq. 11.7-11.8,
where only Kmu_phiu appears) would violate energy conservation.  fem_solver.py
assembles Kuphi = int(Beps' e' Bphi + Beta' mu' Bphi) and Kphiu = Kuphi', and
tests verify the assembled monolithic matrix is symmetric to machine precision
even when mu != 0.

--------------------------------------------------------------------------------
CORRECTION 3 - D uses TOTAL strain (e*eps), no e*eps_th inside f_phi.

From D = -dH/dE above, the derivative with respect to E of the -e:eps.E and
-mu:eta.E terms gives e:eps and mu:eta with the TOTAL strain eps and TOTAL
gradient eta - the mechanical variables of H (Sec. 5.1).  No eigenstrain
corrected combination e*(eps-eps_th) appears anywhere in D, because the thermal
eigenstrain only enters the *mechanical* term -beta:eps*theta (= -C:alpha:eps*theta).

Consequences in the discretised weak form (electrical row, Sec. 11.3):

    int Bphi^T D = 0  =>  (Kphiu_piezo + Kphiu_flex) qu - Kphiphi qphi = f_phi

    f_phi = -int Bphi^T p*theta dA      (NO +e*eps_th term)

The master record's literal Eq. 16.9 f_phi = int Bphi^T(e*eps_th - p*theta) is
therefore inconsistent with the record's own stated enthalpy (Eq. 5.1).  The
record's own pyro-load sign is retained: for theta>0 and p3<0 the load
f_phi = -int Bphi^T p theta produces V<0, matching the exact 1D pyro identity
(Sec. 18.2).  fem_solver.py implements f_phi exactly as above.

--------------------------------------------------------------------------------
CORRECTION 4 - material inputs superseding the record's own table (Sec. 26.1).

The record lists alpha1=1.57e-5, alpha3=6.2e-6 (legacy vendor pair) and
p3=-2.0e-4 C/m^2K (constant-stress / total ceramic coefficient).  Correction 4
replaces them with source-located values; all other record materials
(C11..C44, e15/e31/e33, kappa11/kappa33 from Zgonik et al. 1994, eps0 CODATA)
stay exactly as the record states.

    alpha1 = alpha2 = +21.8e-6 1/K,   alpha3 = -4.3e-6 1/K
        Nakatani et al., Acta Cryst. B 72 (2016) 151, Table 1 (p.153):
        tetragonal P4mm lattice a(T), c(T) at 298/303/323/343 K; direct OLS
        alpha = slope / mean(axis): a -> +21.757 ppm/K, c -> -4.344 ppm/K,
        rounded to +21.8 / -4.3 ppm/K.
        OLS standard error of the c-axis slope 1.3165e-5 A/K (fit R2 ~ 0.47),
        which divided by the mean c 4.03705 A gives
        SE(alpha3) ~ 3.26e-6 1/K; used for the alpha3 uncertainty propagation.

    p3 = -3.41e-4 C/(m^2 K)   (primary / fixed-strain coefficient)
        Eklund & Karttunen, J. Phys. Chem. C 127 (2023) 21806, SI Table S3
        (p. S8): p^(1) = -341 microC/(m^2 K) at 300 K, DFT-PBE0.  The enthalpy
        law D = e*eps + kappa*E + mu*eta + p*theta needs the primary
        fixed-strain coefficient because the strain-mediated secondary
        pyroelectric response is generated by the thermoelastic solve.

    mu (effective flexoelectric tensor) and ell (Mindlin length) are NOT
    source-controlled for this material (record Sec. 26.1 marks them
    SENSITIVITY / MODEL CHOICE).  The flexoelectric formulation is implemented
    for completeness (Correction 2) but flexo-active cases are excluded from
    quantitative production output.
"""

import numpy as np

# Full 3D normal-strain stiffness block (xx, yy, zz) at constant E - record
# Table 1 (Sec. 26.1) / Zgonik et al. 1994.  [Pa]
C3_NORMAL = np.array(
    [
        [2.22e11, 1.08e11, 1.11e11],
        [1.08e11, 2.22e11, 1.11e11],
        [1.11e11, 1.11e11, 1.51e11],
    ]
)

# frozen Nakatani 3D thermal expansion (alpha1 = alpha2) - Correction 4
ALPHA_3D = np.array([21.8e-6, 21.8e-6, -4.3e-6])

# c-axis OLS slope standard error (A/K) and mean axis lengths (A) from the
# Nakatani Table-1 audit (record provenance; see frozen baseline CSV).
C_AXIS_SLOPE_SE_A_PER_K = 1.31651571140789e-05
MEAN_C_A = 4.03705

# ---------------------------------------------------------------------------
# independent verification functions used by the pytest suite
# ---------------------------------------------------------------------------


def verify_correction1_beta_plane_strain() -> np.ndarray:
    """Return the active plane-strain thermal vector, selecting the (xx,zz)
    components of the FULL 3D contraction (not C_plane_strain*alpha_reduced)."""
    beta_3d = C3_NORMAL @ ALPHA_3D
    beta_ps = np.array([beta_3d[0], beta_3d[2], 0.0])
    # closed-form check per Correction 1
    expected = np.array(
        [
            (C3_NORMAL[0, 0] + C3_NORMAL[0, 1]) * ALPHA_3D[0]
            + C3_NORMAL[0, 2] * ALPHA_3D[2],
            2 * C3_NORMAL[2, 0] * ALPHA_3D[0] + C3_NORMAL[2, 2] * ALPHA_3D[2],
            0.0,
        ]
    )
    assert np.allclose(beta_ps, expected)
    return beta_ps


def verify_correction4_alpha3_se() -> float:
    """OLS standard error of alpha3 from the c-axis fit slope SE / mean c."""
    return C_AXIS_SLOPE_SE_A_PER_K / MEAN_C_A  # ~ 3.26e-6 1/K
