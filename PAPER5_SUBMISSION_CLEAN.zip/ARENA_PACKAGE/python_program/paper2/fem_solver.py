"""fem_solver.py - structured-mesh BFS/Q4 assembly, tied open-circuit electrode
constraint (exact congruence reduction, not a penalty), solve, and FE field
recovery at arbitrary (x,z).

Master-record references:
  Sec. 12-14     BFS basis (bfs_shape.py) and B_eps (3x32), B_eta (6x32)
  Sec. 15        bilinear B_phi
  Sec. 16        element matrices (Eqs. 16.2-16.9), 4x4 Gauss rule
  Sec. 17        global assembly / essential BCs / voltage (Eq. 17.1)
  Sec. 34.2      open-circuit top electrode = tied equipotential whose single
                 assembled residual is the total top charge (zero applied)
  Sec. 37        global DOF numbering [u,ux,uz,uxz,w,wx,wz,wxz,phi] per node,
                 nodes ordered bottom-to-top, x fastest
Block system (record Eq. 11.9, with corrections 1-3):
    [Kuu     Kuphi  ] [qu  ]   [fu  ]
    [Kuphi^T -Kpphi ] [qphi] = [fphi]
    Kuu  = int(Beps' C Beps + Beta' A_V Beta)
    Kuphi= int(Beps' e' Bphi + Beta' mu' Bphi)         (reciprocal, Corr. 2)
    Kpp  = int(Bphi' kappa Bphi)
    fu   = int(Beps' beta_PS theta)                    (beta per Corr. 1)
    fphi = -int(Bphi' p theta)                         (Corr. 3, no e*eps_th)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from . import bfs_shape
from .materials import Material


# ---------------------------------------------------------------------------
# mesh / numbering (record Sec. 37)
# ---------------------------------------------------------------------------
@dataclass
class Mesh:
    nex: int            # elements along x
    nez: int            # elements along z
    L: float
    h: float

    @property
    def nnode_x(self): return self.nex + 1
    @property
    def nnode_z(self): return self.nez + 1
    @property
    def nnode(self): return self.nnode_x * self.nnode_z
    @property
    def ndof(self): return 9 * self.nnode
    @property
    def hx(self): return self.L / self.nex
    @property
    def hz(self): return self.h / self.nez

    def node_xy(self, i, j):
        """x,y of global node at (x-index i, z-row j)."""
        return i * self.hx, j * self.hz

    def node_dofs(self, n):
        """9 global DOFs of node n, order [u,ux,uz,uxz,w,wx,wz,wxz,phi]."""
        return 9 * n + np.arange(9)

    def element_nodes(self, ex, ez):
        """4 global node ids [BL, BR, TR, TL] of element (ex, ez)."""
        w = self.nnode_x
        bl = ex + ez * w
        return np.array([bl, bl + 1, bl + w + 1, bl + w])

    def element_edofs(self, ex, ez):
        """36-length local->global dof vector: [u(16), w(16), phi(4)]."""
        nodes = self.element_nodes(ex, ez)
        out = np.zeros(36, dtype=int)
        u = np.zeros(16, dtype=int)
        w = np.zeros(16, dtype=int)
        phi = np.zeros(4, dtype=int)
        for a, nd in enumerate(nodes):
            base = 9 * nd
            local = 4 * a + np.arange(4)
            u[local] = base + np.arange(4)
            w[local] = base + np.arange(4, 8)
            phi[a] = base + 8
        out[:16] = u
        out[16:32] = w
        out[32:36] = phi
        return out


# ---------------------------------------------------------------------------
# strain operators from scalar BFS derivative arrays (record Sec. 13, 14)
# ---------------------------------------------------------------------------
def strain_operators(Nx, Nz, Nxx, Nzz, Nxz):
    """(Beps 3x32, Beta 6x32) per Sec. 13-14 engineering-shear convention."""
    Beps = np.zeros((3, 32))
    Beps[0, 0:16] = Nx          # eps_xx  = u_x
    Beps[1, 16:32] = Nz         # eps_zz  = w_z
    Beps[2, 0:16] = Nz          # gamma_xz = u_z + w_x
    Beps[2, 16:32] = Nx
    Beta = np.zeros((6, 32))
    Beta[0, 0:16] = Nxx         # eta1 = u_xx
    Beta[1, 0:16] = Nxz         # eta2 = u_xz
    Beta[2, 16:32] = Nxz        # eta3 = w_zx
    Beta[3, 16:32] = Nzz        # eta4 = w_zz
    Beta[4, 0:16] = Nxz         # eta5 = u_xz + w_xx  (gamma_xz,x)
    Beta[4, 16:32] = Nxx
    Beta[5, 0:16] = Nzz         # eta6 = u_zz + w_xz  (gamma_xz,z)
    Beta[5, 16:32] = Nxz
    return Beps, Beta


# ---------------------------------------------------------------------------
# global system object
# ---------------------------------------------------------------------------
@dataclass
class GlobalSystem:
    mesh: Mesh
    mat: Material
    K: sp.csc_matrix = None          # full (unconstrained) matrix
    F: np.ndarray = None             # full load vector
    # constraint data
    map_free: np.ndarray = None      # -1 = fixed/removed; else reduced index
    T: sp.csc_matrix = None          # T@q = U_full
    Kr: sp.csc_matrix = None         # T' K T
    Fr: np.ndarray = None
    n_reduced: int = 0
    _lu: Optional[object] = None     # cached factorization of equilibrated Kr
    _eq: Optional[np.ndarray] = None

    # element-quantity caches for post-processing
    _gp_xi: np.ndarray = field(default=None, repr=False)
    _gp_eta: np.ndarray = field(default=None, repr=False)
    _gp_w: np.ndarray = field(default=None, repr=False)


def assemble_system(mesh: Mesh, mat: Material) -> GlobalSystem:
    """Assemble the full unconstrained block system of record Eq. 11.9."""
    g = GlobalSystem(mesh=mesh, mat=mat)
    ndof = mesh.ndof
    hx, hz = mesh.hx, mesh.hz
    areaJ = hx * hz / 4.0

    # ---- element-constant stiffness blocks (uniform mesh + material) -------
    gpts = list(bfs_shape.gauss_points_2d())
    nGP = len(gpts)
    xi_a = np.array([p[0] for p in gpts])
    eta_a = np.array([p[1] for p in gpts])
    w_a = np.array([p[2] for p in gpts]) * areaJ
    g._gp_xi, g._gp_eta, g._gp_w = xi_a, eta_a, w_a

    Ke = np.zeros((36, 36))
    # precomputed per-gauss B matrices (independent of element position)
    Bg = []
    for (xi, eta, w) in gpts:
        _, Nx, Nz, Nxx, Nzz, Nxz = bfs_shape.bfs_shape(xi, eta, hx, hz)
        Beps, Beta = strain_operators(Nx, Nz, Nxx, Nzz, Nxz)
        _, Bphi = bfs_shape.bilinear_shape(xi, eta, hx, hz)
        Bg.append((Beps, Beta, Bphi))

    for w, (Beps, Beta, Bphi) in zip(w_a, Bg):
        Ke[0:32, 0:32] += w * (Beps.T @ mat.C_ps @ Beps
                               + Beta.T @ mat.A_V @ Beta)
        kup = Beps.T @ mat.e_mat.T @ Bphi          # piezo
        if mat.flexo:
            kup = kup + Beta.T @ mat.mu_V.T @ Bphi  # reciprocal flexo (Corr.2)
        Ke[0:32, 32:36] += w * kup
        Ke[32:36, 0:32] += w * kup.T
        Ke[32:36, 32:36] += w * (-Bphi.T @ mat.kappa @ Bphi)

    # ---- sparse scatter of the constant element stiffness ------------------
    nElem = mesh.nex * mesh.nez
    row = np.zeros(nElem * 36 * 36, dtype=np.int64)
    col = np.zeros_like(row)
    val = np.zeros(nElem * 36 * 36)
    F = np.zeros(ndof)
    edof_list = [mesh.element_edofs(ex, ez)
                 for ez in range(mesh.nez) for ex in range(mesh.nex)]

    pos = 0
    for e, edofs in enumerate(edof_list):
        r = np.repeat(edofs, 36)
        c = np.tile(edofs, 36)
        row[pos:pos + 1296] = r
        col[pos:pos + 1296] = c
        val[pos:pos + 1296] = Ke.ravel()
        pos += 1296
    K = sp.coo_matrix((val, (row, col)), shape=(ndof, ndof)).tocsc()

    # ---- thermal / pyroelectric loads (vary with element z-row) ------------
    beta = mat.beta_ps                # 3-vector Pa/K  (Correction 1)
    pvec = mat.p_vec                  # 2-vector C/(m^2 K)
    fu_row_cache = {}
    fp_row_cache = {}
    for ez in range(mesh.nez):
        z0 = ez * hz
        fu = np.zeros(32)
        fp = np.zeros(4)
        for k, (xi, eta, w) in enumerate(gpts):
            z = z0 + (eta + 1.0) * hz / 2.0
            theta = mat.theta_of_z(z)
            Beps, Beta, Bphi = Bg[k]
            wdA = w * areaJ          # full quadrature weight incl. |detJ|
            fu += wdA * (Beps.T @ beta) * theta
            fp += wdA * (Bphi.T @ pvec) * (-1.0) * theta
        fu_row_cache[ez] = fu
        fp_row_cache[ez] = fp

    for e, edofs in enumerate(edof_list):
        ez = e // mesh.nex
        F[edofs[0:32]] += fu_row_cache[ez]
        F[edofs[32:36]] += fp_row_cache[ez]

    g.K, g.F = K, F
    return g


def make_constraints(mesh: Mesh):
    """Return array 'm' length ndof: -1 removed, else reduced-column index.
    Clamp at the root x=0 fixes only the 8 mechanical DOFs of each root node
    (record Eq. 2.10); the root *potential* DOF is untouched.  Bottom phi is
    grounded (Eq. 2.11); top phi nodes are tied to one equipotential master
    carrying the zero-net-charge equation (Eqs. 2.12-2.13, Sec. 34.2)."""
    ndof = mesh.ndof
    m = np.full(ndof, -1, dtype=np.int64)
    count = 0
    top_phi_dofs = []
    for j in range(mesh.nnode_z):
        for i in range(mesh.nnode_x):
            n = i + j * mesh.nnode_x
            dofs = mesh.node_dofs(n)
            if i != 0:                     # free nodes (root clamps skip)
                for k in range(8):
                    m[dofs[k]] = count
                    count += 1
            if j == 0:                     # bottom electrode: phi grounded
                continue                   # phi stays removed (-1)
            if j == mesh.nez:              # top row: phi tied to master
                top_phi_dofs.append(dofs[8])
                continue
            m[dofs[8]] = count             # interior potential free
            count += 1
    master = count
    count += 1
    for d in top_phi_dofs:
        m[d] = master
    return m, count, np.array(top_phi_dofs, dtype=np.int64)


def build_constraint_transform(m: np.ndarray, n_red: int):
    rows = np.nonzero(m >= 0)[0]
    cols = m[rows]
    T = sp.coo_matrix((np.ones(len(rows)), (rows, cols)),
                      shape=(len(m), n_red)).tocsc()
    return T


def reduce_system(g: GlobalSystem, use_equilibration: bool = True):
    """Exact congruence reduction Kr = T'KT, Fr = T'F (Sec. 34.2)."""
    m, n_red, top_phi = make_constraints(g.mesh)
    T = build_constraint_transform(m, n_red)
    Kr = (T.T @ (g.K @ T)).tocsc()
    Fr = (T.T @ g.F)
    g.map_free, g.n_reduced, g.T, g.Kr, g.Fr = m, n_red, T, Kr, Fr
    # diagonal equilibration (improves conditioning; exact in exact arithmetic)
    d = np.abs(Kr.diagonal())
    if np.any(d <= 0):
        d[d <= 0] = 1.0
    eq = 1.0 / np.sqrt(d)
    if use_equilibration:
        E = sp.diags(eq)
        Keq = (E @ Kr @ E).tocsc()
        g._eq = eq
        g._lu = spla.splu(Keq)
    else:
        g._lu = spla.splu(Kr)
    return g


def solve_from_load(g: GlobalSystem, F_override: Optional[np.ndarray] = None):
    """Solve reduced system; F_override replaces g.F (e.g. p-scale sweep)."""
    F = g.F if F_override is None else F_override
    Fr = g.T.T @ F
    if g._eq is not None:
        Fr = g._eq * Fr
    y = g._lu.solve(Fr)
    if g._eq is not None:
        y = g._eq * y
    q = y
    # F21: single consistent reconstruction (the previous elementwise
    # assignment was dead code immediately overwritten); no dead residual.
    U = g.T @ q
    return U, q, None


def solve_case(mesh: Mesh, mat: Material, equilibrate: bool = True):
    """Full pipeline: assemble, reduce, solve.  Returns dict with all results
    needed by the production runner and post-processing."""
    g = assemble_system(mesh, mat)
    reduce_system(g, use_equilibration=equilibrate)
    U, q, _ = solve_from_load(g)
    return finalize(g, U)


def finalize(g: GlobalSystem, U: np.ndarray) -> dict:
    mesh = g.mesh
    # nodal potential grid (rows = z, cols = x), voltage = mean(top)-mean(bot)
    phi = np.zeros((mesh.nnode_z, mesh.nnode_x))
    for j in range(mesh.nnode_z):
        for i in range(mesh.nnode_x):
            phi[j, i] = U[mesh.node_dofs(i + j * mesh.nnode_x)[8]]
    voltage = float(np.mean(phi[-1, :]) - np.mean(phi[0, :]))
    q = g.T.T @ U
    r_raw = g.Kr @ q - g.T.T @ g.F
    reduced_residual = float(np.max(np.abs(r_raw)))
    if g._eq is not None:          # equilibrated-coordinate residual metric
        reduced_residual = float(np.max(np.abs(g._eq * r_raw)))
    # top charge residual on the *full* assembled residual
    full_res = g.K @ U - g.F
    top_phi = make_constraints(mesh)[2]
    top_charge = float(np.sum(full_res[top_phi]))
    return dict(
        system=g, U=U, q=q, phi=phi, voltage=voltage,
        reduced_residual=reduced_residual, top_charge_residual=top_charge,
        ndof_full=mesh.ndof, n_reduced=g.n_reduced,
    )


# ---------------------------------------------------------------------------
# field recovery at arbitrary physical points (Fig. 4 & Fig. 10 use)
# ---------------------------------------------------------------------------
def element_lookup(mesh: Mesh, x, z):
    """Return (ex, ez, xi, eta) for a physical point inside the domain."""
    hx, hz = mesh.hx, mesh.hz
    ex = min(mesh.nex - 1, max(0, int(np.floor(x / hx))))
    ez = min(mesh.nez - 1, max(0, int(np.floor(z / hz))))
    x0, z0 = ex * hx, ez * hz
    xi = 2.0 * (x - x0) / hx - 1.0
    eta = 2.0 * (z - z0) / hz - 1.0
    return ex, ez, xi, eta


def recover_fields(g: GlobalSystem, U: np.ndarray, xs: np.ndarray, zs: np.ndarray):
    """Evaluate FE fields at arrays of physical points (xs, zs), same shape.

    Returns dict with 2-D value arrays per field:
      phi(x,z), Ex(x,z), Ez(x,z), u, w, eps_xx, eps_zz, gamma_xz, sigma_xx,
      sigma_zz, sigma_xz, Dx, Dz  (true isoparametric evaluation of the
      solved FE solution at the requested points).
    """
    mesh = g.mesh
    mat = g.mat
    hx, hz = mesh.hx, mesh.hz
    shape = np.shape(xs)
    xs = np.asarray(xs).ravel()
    zs = np.asarray(zs).ravel()
    n = len(xs)
    phi_v = np.zeros(n); Ex_v = np.zeros(n); Ez_v = np.zeros(n)
    u_v = np.zeros(n); w_v = np.zeros(n)
    exx = np.zeros(n); ezz = np.zeros(n); gxz = np.zeros(n)
    sxx = np.zeros(n); szz = np.zeros(n); sxz = np.zeros(n)
    Dx = np.zeros(n); Dz = np.zeros(n)

    # unique element keys -> cache local qu,qw,qphi and edofs per element
    for idx in range(n):
        x, z = xs[idx], zs[idx]
        ex, ez, xi, eta = element_lookup(mesh, x, z)
        x0, z0 = ex * hx, ez * hz
        edofs = mesh.element_edofs(ex, ez)
        qu = U[edofs[0:32]]
        qphi = U[edofs[32:36]]
        N, Nx, Nz, Nxx, Nzz, Nxz = bfs_shape.bfs_shape(xi, eta, hx, hz)
        Nv = N                     # F21: value shapes already returned above
        Np, Bphi = bfs_shape.bilinear_shape(xi, eta, hx, hz)
        # displacement
        u = Nv[:16].T @ qu[:16]
        w = Nv[:16].T @ qu[16:32]
        # strain (engineering)
        Beps, Beta = strain_operators(Nx, Nz, Nxx, Nzz, Nxz)
        eps = Beps @ qu
        eta_grad = Beta @ qu      # F21: was shadowing the natural coord `eta`
        E = -Bphi @ qphi
        theta = mat.theta_of_z(z)
        # stress sigma = C(eps - alpha_ps*theta?) -- use eigenstrain form
        # sigma = C_ps*(eps - [alpha1,alpha3,0]*theta) ... but for plane strain
        # the eigenstrain entering the in-plane law is NOT the in-plane alpha
        # vector; see note below (stress recovered from sigma=C eps - beta_ps
        # theta using the corrected full-3D beta).  [record Sec. 5.3 Eq. 5.9
        # becomes sigma=C eps - beta theta under the full reduction.]
        sigma_mech = mat.C_ps @ eps - mat.beta_ps * theta
        sigma = sigma_mech - (mat.e_mat.T @ E)
        D = mat.e_mat @ eps + mat.kappa @ E + mat.p_vec * theta
        if mat.flexo:
            D = D + mat.mu_V @ eta_grad
            # higher-order couple stress does not affect D/E/phi recovery here
        phi_v[idx] = Np @ qphi
        Ex_v[idx], Ez_v[idx] = E
        u_v[idx], w_v[idx] = u, w
        exx[idx], ezz[idx], gxz[idx] = eps
        sxx[idx], szz[idx], sxz[idx] = sigma
        Dx[idx], Dz[idx] = D

    def _r(v): return v.reshape(shape)
    return dict(phi=_r(phi_v), Ex=_r(Ex_v), Ez=_r(Ez_v), u=_r(u_v), w=_r(w_v),
                eps_xx=_r(exx), eps_zz=_r(ezz), gamma_xz=_r(gxz),
                sigma_xx=_r(sxx), sigma_zz=_r(szz), sigma_xz=_r(sxz),
                Dx=_r(Dx), Dz=_r(Dz))


def recover_on_uniform_grid(g: GlobalSystem, U, nx=121, nz=61):
    """Recover fields on a uniform physical grid for plotting.  Points are
    mapped to their host element and evaluated with the actual FE basis, so
    every output value is a genuine evaluation of the solved field."""
    mesh = g.mesh
    xs = np.linspace(0.0, mesh.L, nx)
    zs = np.linspace(0.0, mesh.h, nz)
    X, Z = np.meshgrid(xs, zs)
    f = recover_fields(g, U, X, Z)
    f["X"] = X
    f["Z"] = Z
    return f


# ---------------------------------------------------------------------------
# energy / enthalpy post-processing (record Sec. 22, plus variational enthalpy
# consistency used by the verification suite)
# ---------------------------------------------------------------------------
def postprocess_enthalpy(g: GlobalSystem, U: np.ndarray) -> dict:
    """Integrate signed enthalpy density terms at the assembly Gauss points
    (per unit out-of-plane depth).  Definitions follow record Sec. 22.1-22.2
    with the corrected constitutive D = e eps + kappa E + mu eta + p theta:
      elastic_quadratic = 1/2 int eps' C eps
      strain_gradient   = 1/2 int eta' A_V eta            (0 for ell=0)
      dielectric_enthalpy = -1/2 int E' kappa E   (enthalpy form)
      dielectric_energy   = +1/2 int E' kappa E   (positive energy form)
      piezo_coupling    = -int (e eps).E           (enthalpy term)
      flexo_coupling    = -int (mu eta).E          (enthalpy term)
      thermoelastic_coupling = -int (beta_PS eps) theta   (enthalpy term)
      pyroelectric_enthalpy  = -int (p theta).E           (enthalpy term)
      (discrete stationary potential 1/2 U'KU - U'F is compared to the sum of
      these, the variational energy/enthalpy self-consistency check)
    """
    mesh, mat = g.mesh, g.mat
    hx, hz = mesh.hx, mesh.hz
    gpts = list(bfs_shape.gauss_points_2d())
    vals = dict(elastic_quadratic=0.0, strain_gradient=0.0,
                dielectric_enthalpy=0.0, dielectric_energy=0.0,
                piezo_coupling=0.0, flexo_coupling=0.0,
                thermoelastic_coupling=0.0, pyroelectric_enthalpy=0.0,
                thermal_full3d=0.0)
    for ez in range(mesh.nez):
        z0 = ez * hz
        for ex in range(mesh.nex):
            edofs = mesh.element_edofs(ex, ez)
            qu = U[edofs[0:32]]
            qphi = U[edofs[32:36]]
            for (xi, eta, wg) in gpts:
                _, Nx, Nz, Nxx, Nzz, Nxz = bfs_shape.bfs_shape(xi, eta, hx, hz)
                Beps, Beta = strain_operators(Nx, Nz, Nxx, Nzz, Nxz)
                _, Bphi = bfs_shape.bilinear_shape(xi, eta, hx, hz)
                z = z0 + (eta + 1.0) * hz / 2.0
                theta = mat.theta_of_z(z)
                eps = Beps @ qu
                eta = Beta @ qu
                E = -Bphi @ qphi
                dA = wg * hx * hz / 4.0
                vals["elastic_quadratic"] += 0.5 * eps @ mat.C_ps @ eps * dA
                vals["strain_gradient"] += 0.5 * eta @ mat.A_V @ eta * dA
                kE = 0.5 * E @ mat.kappa @ E * dA
                vals["dielectric_enthalpy"] -= kE
                vals["dielectric_energy"] += kE
                vals["piezo_coupling"] -= (mat.e_mat @ eps) @ E * dA
                if mat.flexo:
                    vals["flexo_coupling"] -= (mat.mu_V @ eta) @ E * dA
                vals["thermoelastic_coupling"] -= (mat.beta_ps @ eps) * theta * dA
                vals["pyroelectric_enthalpy"] -= (mat.p_vec * theta) @ E * dA
    # discrete stationary potential (record: enthalpy = 1/2 U'KU - U'F at sol.)
    K = g.K
    disc = 0.5 * float(U @ (K @ U)) - float(U @ g.F)
    vals["discrete_stationary_potential"] = disc
    integrated = (vals["elastic_quadratic"] + vals["strain_gradient"]
                  + vals["dielectric_enthalpy"] + vals["piezo_coupling"]
                  + vals["flexo_coupling"] + vals["thermoelastic_coupling"]
                  + vals["pyroelectric_enthalpy"])
    vals["integrated_enthalpy"] = integrated
    denom = max(1e-30, abs(disc), abs(integrated))
    vals["relative_consistency_error"] = abs(disc - integrated) / denom
    return vals
