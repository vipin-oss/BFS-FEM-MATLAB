"""materials.py - every constitutive / geometric constant used by the solve,
each with a docstring citing its exact source in the master calculation
record (section/table) or the audited Correction 4 literature.

Nothing material-dependent is hard-coded anywhere else in the package: all
assembly code reads a `Material` object returned by build_material().
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from . import corrections


@dataclass
class Material:
    """BaTiO3 4mm (tetragonal) plane-strain material + mechanism switches.

    Units are SI.  Per-unit-out-of-plane-depth convention throughout.
    """

    # ---- geometry / loading (record Sec. 2.1, Eq. 2.2 and Sec. 2.4, Eq. 2.8)
    L: float = 1.0e-5      # m  span x in [0,L]           (Specimen M)
    h: float = 1.0e-6      # m  thickness z in [0,h]      (Specimen M)
    theta_bottom: float = 0.0   # K  theta at z=0
    delta_T: float = 10.0       # K  theta(z)=theta_bottom+delta_T*z/h

    # ---- elastic stiffness, constant-E (record Table 1 Sec. 26.1; Appendix A
    #      Eq. A.1; provenance Zgonik et al. 1994 / Berlincourt & Jaffe 1958)
    C11: float = 2.22e11        # Pa
    C12: float = 1.08e11        # Pa  (yy normal block, used for beta only)
    C13: float = 1.11e11        # Pa
    C33: float = 1.51e11        # Pa
    C44: float = 6.10e10        # Pa  (multiplies engineering shear gamma_xz)

    # ---- piezoelectric stress constants (record Sec. 7.5 Eq. 7.16 /
    #      Appendix A Eq. A.2; Zgonik et al. 1994)
    e31: float = -0.7           # C/m^2
    e33: float = 6.7            # C/m^2
    e15: float = 34.2           # C/m^2

    # ---- dielectric, clamped-order relative permittivities (record Sec. 7.6
    #      Eqs. 7.19-7.22; Zgonik et al. 1994) and eps0 (CODATA, Eq. 7.19)
    kappa_r11: float = 2200.0
    kappa_r33: float = 56.0
    eps0: float = 8.854187817e-12   # F/m

    # ---- thermal expansion (Correction 4, supersedes record Sec. 26.1):
    #      Nakatani et al. 2016 Acta Cryst. B 72:151 Table 1, direct OLS,
    #      tetragonal single crystal 298-343 K
    alpha1: float = corrections.ALPHA_3D[0]   # 1/K  (= alpha2, basal plane)
    alpha3: float = corrections.ALPHA_3D[2]   # 1/K

    # ---- pyroelectric (Correction 4, supersedes record Sec. 26.1 /
    #      Appendix L.16): Eklund & Karttunen 2023 JPCC 127:21806 SI Table S3,
    #      direct p^(1) primary (fixed-strain) coefficient at 300 K
    p3: float = -3.41e-4        # C/(m^2 K)

    # ---- flexoelectric effective triple (record Sec. 8.4-8.9: mu11,mu12,mu44
    #      = 1e-6 C/m SENSITIVITY only - NOT source controlled; flexo-active
    #      cases are excluded from production output)
    mu_11: float = 1.0e-6       # C/m
    mu_12: float = 1.0e-6       # C/m
    mu_44: float = 1.0e-6       # C/m  (coefficient of d(gamma_xz); see 8.8)

    # ---- Mindlin strain-gradient length (record Sec. 9, MODEL CHOICE; the
    #      record default is ell = 0 so A_V = C44*ell^2*I6 = 0)
    ell: float = 0.0            # m

    # ---- mechanism switches (record Sec. 19.2 case table)
    piezo: bool = True
    pyro: bool = True
    flexo: bool = False
    thermal_on: bool = True     # mechanical thermal load (Case 0 turns it off)

    # ---- scales for the sensitivity runs (record Sec. 21.2 scale factors)
    p_scale: float = 1.0
    alpha_scale1: float = 1.0
    alpha_scale3: float = 1.0

    # derived (filled by __post_init__)
    C_ps: np.ndarray = field(default=None, repr=False)      # 3x3 in-plane
    C3_normal: np.ndarray = field(default=None, repr=False)  # 3x3 full normal
    e_mat: np.ndarray = field(default=None, repr=False)      # 2x3 Voigt
    kappa: np.ndarray = field(default=None, repr=False)      # 2x2
    beta_ps: np.ndarray = field(default=None, repr=False)    # 3-vector Pa/K
    mu_V: np.ndarray = field(default=None, repr=False)       # 2x6 C/m
    A_V: np.ndarray = field(default=None, repr=False)        # 6x6 N
    p_vec: np.ndarray = field(default=None, repr=False)      # 2-vector

    def __post_init__(self) -> None:
        if not self.thermal_on:
            # Case '0': the Dirichlet theta field is identically zero so the
            # load vectors vanish; alpha/p kept but multiplied by theta=0.
            pass
        # in-plane reduced stiffness [eps_xx, eps_zz, gamma_xz] -> stresses
        # (record Eq. 7.10 / Appendix A Eq. A.1).  In-plane block uses raw
        # C11/C13/C33 because plane strain sets eps_yy=0 (kinematically), it
        # does not statically condense sigma_yy.
        self.C_ps = np.array(
            [
                [self.C11, self.C13, 0.0],
                [self.C13, self.C33, 0.0],
                [0.0, 0.0, self.C44],
            ]
        )
        # full 3D normal block used by the (corrected) thermal reduction
        self.C3_normal = np.array(
            [
                [self.C11, self.C12, self.C13],
                [self.C12, self.C11, self.C13],
                [self.C13, self.C13, self.C33],
            ]
        )
        # piezoelectric Voigt map rows=(Dx,Dz), cols=(eps_xx,eps_zz,gamma_xz)
        # (record Sec. 7.5 Eq. 7.16)
        self.e_mat = np.array(
            [
                [0.0, 0.0, self.e15],
                [self.e31, self.e33, 0.0],
            ]
        )
        if not self.piezo:
            self.e_mat *= 0.0
        self.kappa = np.diag([self.kappa_r11, self.kappa_r33]) * self.eps0
        # full 3D alpha vector (alpha1 = alpha2)
        alpha_3d = np.array(
            [self.alpha_scale1 * self.alpha1,
             self.alpha_scale1 * self.alpha1,
             self.alpha_scale3 * self.alpha3]
        )
        # CORRECTION 1: 3D contraction first, then active (xx,zz) selection
        beta_3d = self.C3_normal @ alpha_3d
        self.beta_ps = np.array([beta_3d[0], beta_3d[2], 0.0])
        self.p_vec = np.array([0.0, self.p_scale * self.p3])
        if not self.pyro:
            self.p_vec *= 0.0
        # effective reduced flexo map D^mu = mu_V eta_V (record Sec. 8.6
        # Eq. 8.8): mu_V[0]=(eta1,eta3,eta6), mu_V[1]=(eta2,eta4,eta5)
        if self.flexo:
            self.mu_V = np.array(
                [
                    [self.mu_11, 0.0, self.mu_12, 0.0, 0.0, self.mu_44],
                    [0.0, self.mu_12, 0.0, self.mu_11, self.mu_44, 0.0],
                ]
            )
        else:
            self.mu_V = np.zeros((2, 6))
        # Mindlin A_V = C44*ell^2*I6 (record Sec. 9.2 Eq. 9.2)
        self.A_V = self.C44 * self.ell**2 * np.eye(6)

    # ---- scalar helpers ----------------------------------------------------
    @property
    def kappa33(self) -> float:
        return self.kappa_r33 * self.eps0

    @property
    def kappa11(self) -> float:
        return self.kappa_r11 * self.eps0

    def theta_of_z(self, z: float) -> float:
        """Prescribed Dirichlet linear temperature (record Eq. 2.8)."""
        if not self.thermal_on:
            return 0.0
        return self.theta_bottom + self.delta_T * z / self.h


#: case registry - record Sec. 19.2 (mesh columns per the case table: A=24x12,
#: B/C/D/E=16x8; the production campaign refines each to its own converged mesh)
CASE_SPECS = {
    "A": dict(piezo=True, pyro=True, flexo=False, production=True,
              description="piezo + pyro (no flexo)"),
    "B": dict(piezo=True, pyro=True, flexo=True, production=False,
              description="piezo + pyro + flexo (EXPLORATORY, not production)"),
    "C": dict(piezo=False, pyro=False, flexo=True, production=False,
              description="flexo only (EXPLORATORY, not production)"),
    "D": dict(piezo=False, pyro=True, flexo=False, production=True,
              description="pyro only (1D-exact anchor case)"),
    "E": dict(piezo=True, pyro=False, flexo=False, production=True,
              description="piezo-thermal only"),
    "0": dict(piezo=True, pyro=True, flexo=False, production=True,
              description="zero imposed temperature (null case)"),
}


def build_material(case: str = "A", **overrides) -> Material:
    """Build the Material for a named case (record Sec. 19.2)."""
    spec = CASE_SPECS[case.upper()]
    m = Material(**{k: v for k, v in spec.items() if k in
                    ("piezo", "pyro", "flexo")})
    if case.upper() == "0":
        m.thermal_on = False
        m.delta_T = 0.0
    for k, v in overrides.items():
        if not hasattr(m, k):
            raise ValueError(f"unknown material override '{k}'")
        setattr(m, k, v)
    # re-derive dependent blocks after any override
    m.__post_init__()
    return m


def beta_plane_strain(C3_normal: np.ndarray, alpha_3d: np.ndarray) -> np.ndarray:
    """Corrected plane-strain thermal vector (Correction 1): contract the FULL
    3D stiffness with the FULL 3D eigenstrain first, then select the active
    (xx, zz) rows for the eps_yy = 0 plane-strain problem."""
    beta_3d = C3_normal @ alpha_3d
    return np.array([beta_3d[0], beta_3d[2], 0.0])
