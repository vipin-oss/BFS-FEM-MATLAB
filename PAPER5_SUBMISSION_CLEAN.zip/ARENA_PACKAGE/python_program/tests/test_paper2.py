"""pytest suite for the Paper-2 production Python package.

Runnable with:  pytest -v
All tests are real, fail-loud checks (no print statements).
"""
import os
import sys

import numpy as np
import pytest

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE not in sys.path:
    sys.path.insert(0, BASE)

from paper2 import bfs_shape, corrections          # noqa: E402
from paper2 import fem_solver as fs                # noqa: E402
from paper2.materials import build_material        # noqa: E402


# ---------------------------------------------------------------------------
def solve_case(case, nex, nez, **over):
    mat = build_material(case, **over)
    mesh = fs.Mesh(nex=nex, nez=nez, L=mat.L, h=mat.h)
    return mat, mesh, fs.solve_case(mesh, mat)


# ---------------------------------------------------------------------------
# shape-function identities (record Sec. 12 / Appendix C)
# ---------------------------------------------------------------------------
def test_hermite_endpoint_identities():
    H, dH, d2H = bfs_shape.hermite_1d(-1.0)
    assert np.allclose(H, [1, 0, 0, 0])
    assert np.allclose(dH, [0, 1, 0, 0])
    H, dH, d2H = bfs_shape.hermite_1d(1.0)
    assert np.allclose(H, [0, 0, 1, 0])
    assert np.allclose(dH, [0, 0, 0, 1])


def test_bfs_partition_of_unity_and_kronecker():
    for xi in np.linspace(-1, 1, 7):
        for eta in np.linspace(-1, 1, 7):
            N, Nx, Nz, Nxx, Nzz, Nxz = bfs_shape.bfs_shape(xi, eta, 1e-6, 1e-7)
            pu = N[0] + N[4] + N[8] + N[12]
            assert abs(pu - 1.0) < 1e-13
    # Kronecker property: at corner (BL) value shape = 1, others 0
    N, *_ = bfs_shape.bfs_shape(-1.0, -1.0, 1e-6, 1e-7)
    assert abs(N[0] - 1.0) < 1e-14
    assert np.max(np.abs(N[[1, 2, 3, 4, 5, 6, 7]])) < 1e-14


def test_bilinear_basis():
    for xi in np.linspace(-1, 1, 5):
        for eta in np.linspace(-1, 1, 5):
            N, B = bfs_shape.bilinear_shape(xi, eta, 1e-6, 1e-7)
            assert abs(N.sum() - 1.0) < 1e-13
    N, B = bfs_shape.bilinear_shape(-1.0, -1.0, 1e-6, 1e-7)
    assert abs(N[0] - 1.0) < 1e-14


def test_gauss_rule_integrates_polynomials():
    I = 0.0
    for xi, eta, w in bfs_shape.gauss_points_2d():
        I += w * (1.0 + xi + eta + xi * eta + xi**2 * eta**3)
    assert abs(I - 4.0 * (1.0 + 0 + 0 + 0 + (1 / 3) * 0)) < 1e-14
    I = 0.0
    for xi, eta, w in bfs_shape.gauss_points_2d():
        I += w * xi**2 * eta**2
    assert abs(I - 4.0 * (1 / 3) * (1 / 3)) < 1e-14


# ---------------------------------------------------------------------------
# corrections
# ---------------------------------------------------------------------------
def test_correction1_beta_plane_strain_values():
    m = build_material("A")
    # hand closed form from Correction 1
    b1 = (m.C11 + m.C12) * m.alpha1 + m.C13 * m.alpha3
    b3 = 2 * m.C13 * m.alpha1 + m.C33 * m.alpha3
    assert np.allclose(m.beta_ps, [b1, b3, 0.0])
    # values used by the frozen baseline release (its thermal audit CSV)
    assert abs(m.beta_ps[0] - 6.7167e6) / 6.7167e6 < 1e-5
    assert abs(m.beta_ps[1] - 4.1903e6) / 4.1903e6 < 1e-5
    # the old record-literal formula (C_ps*[a1,a3,0]) is genuinely different
    old = m.C_ps @ np.array([m.alpha1, m.alpha3, 0.0])
    assert not np.allclose(old, m.beta_ps, rtol=1e-3)


def test_correction2_reciprocity_with_flexo():
    # with flexo ACTIVE the assembled block matrix must be symmetric
    for case in ["A", "B"]:
        mat = build_material(case)
        mesh = fs.Mesh(nex=8, nez=4, L=mat.L, h=mat.h)
        K = fs.assemble_system(mesh, mat).K.toarray()
        rel = np.linalg.norm(K - K.T) / np.linalg.norm(K)
        assert rel < 1e-12
    # and the flexo channel must actually be present in the coupling block
    KA = fs.assemble_system(fs.Mesh(nex=8, nez=4, L=1e-5, h=1e-6),
                            build_material("A")).K.toarray()
    KB = fs.assemble_system(fs.Mesh(nex=8, nez=4, L=1e-5, h=1e-6),
                            build_material("B")).K.toarray()
    assert np.linalg.norm(KB - KA) > 0.0


def test_correction3_no_e_eps_th_in_fphi():
    # Case E (piezo + thermal, p = 0 by mechanism flag): fphi must be exactly
    # zero (no e*eps_th term) while the mechanical thermal load is non-zero.
    mat = build_material("E")
    mesh = fs.Mesh(nex=8, nez=4, L=mat.L, h=mat.h)
    g = fs.assemble_system(mesh, mat)
    phi_dofs = np.arange(8, mesh.ndof, 9)
    assert np.max(np.abs(g.F[phi_dofs])) < 1e-20 * max(1.0,
                                                       np.max(np.abs(g.F)))
    assert np.max(np.abs(g.F[:8])) > 0.0


def test_correction4_material_values_supersede_record():
    m = build_material("A")
    assert abs(m.alpha1 - 21.8e-6) < 1e-20
    assert abs(m.alpha3 - (-4.3e-6)) < 1e-20
    assert abs(m.p3 - (-3.41e-4)) < 1e-20
    # not the legacy record pair
    assert abs(m.alpha1 - 1.57e-5) > 1e-8
    assert abs(m.alpha3 - 6.2e-6) > 1e-8
    assert abs(m.p3 - (-2.0e-4)) > 1e-8
    # other record constants unchanged
    assert abs(m.C11 - 2.22e11) < 1.0
    assert abs(m.e33 - 6.7) < 1e-12
    assert abs(m.kappa_r33 - 56.0) < 1e-12


# ---------------------------------------------------------------------------
# analytical / physical verifications
# ---------------------------------------------------------------------------
def test_pyroelectric_1d_identity():
    mat, _, res = solve_case("D", 16, 8)
    V1d = mat.p3 * 5.0 * mat.h / mat.kappa33      # theta_bar = 5 K (Sec.18.2)
    rel = abs(res["voltage"] - V1d) / abs(V1d)
    assert rel < 1e-10
    assert res["voltage"] < 0.0                  # p3<0, theta>0 -> V<0


def test_zero_temperature_null():
    _, _, res = solve_case("0", 16, 8)
    assert abs(res["voltage"]) < 1e-12


def test_zero_alpha_null():
    _, _, res = solve_case("E", 16, 8, alpha_scale1=0.0, alpha_scale3=0.0)
    assert abs(res["voltage"]) < 1e-12


def test_zero_p_null_and_A_equals_E():
    _, _, resD = solve_case("D", 16, 8, p_scale=0.0)
    assert abs(resD["voltage"]) < 1e-12
    _, _, resA = solve_case("A", 16, 8, p_scale=0.0)
    _, _, resE = solve_case("E", 16, 8)
    assert abs(resA["voltage"] - resE["voltage"]) < 1e-10


def test_p3_affinity_at_fixed_K():
    scales = [0.0, 0.5, 1.0, 1.5, 2.0]
    m0 = build_material("A", p_scale=0.0)
    m1 = build_material("A", p_scale=1.0)
    mesh = fs.Mesh(nex=16, nez=8, L=m0.L, h=m0.h)
    g = fs.assemble_system(mesh, m0)
    fs.reduce_system(g)
    F0 = g.F.copy()
    F1 = fs.assemble_system(mesh, m1).F.copy()
    Vs = {}
    for s in scales:
        U, q, _ = fs.solve_from_load(g, F_override=F0 + s * (F1 - F0))
        Vs[s] = fs.finalize(g, U)["voltage"]
    maxres = max(abs(Vs[s] - (Vs[0.0] + s * (Vs[1.0] - Vs[0.0])))
                 for s in scales)
    assert maxres < 1e-9


def test_energy_enthalpy_self_consistency():
    mat, mesh, res = solve_case("A", 32, 16)
    h = fs.postprocess_enthalpy(res["system"], res["U"])
    assert h["relative_consistency_error"] < 1e-6


def test_superposition_is_not_additive():
    # V_A != V_D + V_E on a single mesh (record Sec. G.3)
    vA = solve_case("A", 16, 8)[2]["voltage"]
    vD = solve_case("D", 16, 8)[2]["voltage"]
    vE = solve_case("E", 16, 8)[2]["voltage"]
    assert abs(vA - (vD + vE)) > 1e-3 * max(1.0, abs(vA))


# ---------------------------------------------------------------------------
# production values vs the frozen numeric acceptance baseline (Part 3)
# ---------------------------------------------------------------------------
def test_voltage_matches_frozen_baseline_80x40():
    frozen = {"D": -3.43864724813821,
              "A": -1.49959799768594,
              "E": 0.193211761033805}
    for case, ref in frozen.items():
        _, _, res = solve_case(case, 80, 40)
        rel = abs(res["voltage"] - ref) / abs(ref)
        assert rel < 1e-6, (case, rel)


def test_p3_slope_matches_frozen_baseline():
    frozen_slope = -1.70038449440932
    m0 = build_material("A", p_scale=0.0)
    m1 = build_material("A", p_scale=1.0)
    mesh = fs.Mesh(nex=16, nez=8, L=m0.L, h=m0.h)
    g = fs.assemble_system(mesh, m0)
    fs.reduce_system(g)
    U0, q, _ = fs.solve_from_load(g, F_override=g.F)
    F1 = fs.assemble_system(mesh, m1).F.copy()
    U1, q, _ = fs.solve_from_load(g, F_override=F1)
    v0 = fs.finalize(g, U0)["voltage"]
    v1 = fs.finalize(g, U1)["voltage"]
    assert abs((v1 - v0) - frozen_slope) / abs(frozen_slope) < 1e-6
