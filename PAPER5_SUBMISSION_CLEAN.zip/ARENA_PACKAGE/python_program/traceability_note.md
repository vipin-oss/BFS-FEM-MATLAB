# Part-5 traceability note - Paper-2 Python production program

Generated automatically by `run_production.py` on 2026-09-05T09:07:50 (runtime 44.9 s).

## 1. Sources of truth

- **Physics source of truth:** `complete calculation.pdf` (the master calculation record).  Every equation implemented carries its record section number in the docstrings of `paper2/materials.py`, `paper2/bfs_shape.py`, `paper2/fem_solver.py` and `paper2/corrections.py`.
- **Numeric acceptance baseline (Part 3, cross-check only):** `FEM5_FINAL_FROZEN_RELEASE.zip`, SHA-256 `496e777d7c504918c246875c8cbff80d9d9f7c6f7e847087520e67a52f4f1e92` (verified before any computation). A copy of its result CSVs is bundled at `reference_frozen/results/` so this package is self-contained. Its MATLAB source was not copied; its result CSVs were used only as acceptance targets and as the Figure-10(c) comparator.

## 2. The four corrections - independently re-derived

Each item was re-derived from the electric enthalpy (record Sec. 5.1, Eq. 5.1) and the record's boundary conditions (Sec. 2.4-2.5) and then implemented.  The full algebra is in `paper2/corrections.py` (functions corrections.py:verify_correction1_beta_plane_strain():160 and corrections.py:verify_correction4_alpha3_se():178) and in the code docstrings; each is also checked by a dedicated pytest test.

**Correction 1 - plane-strain thermal-stress vector.**  Substituting TOTAL eps_yy = 0 into the full 3D law sigma = C:(eps - alpha theta) gives sigma_xx = C11 eps_xx + C13 eps_zz - [(C11+C12) a1 + C13 a3] theta and sigma_zz = C13 eps_xx + C33 eps_zz - [2 C13 a1 + C33 a3] theta, so beta_PS = [(C11+C12)a1 + C13 a3, 2 C13 a1 + C33 a3, 0].  The yy *eigenstrain* survives even though total eps_yy = 0.  Implementation: materials.py:beta_plane_strain():205 (3D contraction first, then active-slot selection).  Test: `test_correction1_beta_plane_strain_values` shows the record's literal route C_PS*[a1,a3,0] differs.

**Correction 2 - reciprocal flexoelectric coupling.**  H is a single scalar potential, so its mixed second derivatives commute and the assembled block matrix must be symmetric with K_phiu = K_uphi'.  With flexo active the mechanical row carries int(Beta' mu' Bphi), the electrical row int(Bphi' mu Beta).  Test `test_correction2_reciprocity_with_flexo` verifies global symmetry to ~1e-15 relative with mu != 0.

**Correction 3 - D in terms of total strain.**  D = -dH/dE = e:eps + kappa:E + mu:eta + p:theta; hence the electrical load is f_phi = -int(Bphi' p theta) with no e*eps_th term.  Test `test_correction3_no_e_eps_th_in_fphi`: with piezo+thermal active and p = 0 the whole electrical load vector is exactly zero while the mechanical load is non-zero.

**Correction 4 - material inputs.**  alpha1 = alpha2 = +21.8e-6 and alpha3 = -4.3e-6 1/K (Nakatani et al. 2016, Acta Cryst. B 72:151, Table 1 OLS 298-343 K) and p3 = -3.41e-4 C/(m^2 K) (Eklund & Karttunen 2023, J. Phys. Chem. C 127:21806, SI Table S3 direct primary p^(1)) replace the record's legacy alpha pair and total-ceramic p3.  All other record materials (C11-C44, e15/e31/e33, kappa11/kappa33, eps0) are used as the record states them (test `test_correction4_material_values_supersede_record`; Figure 10b).

## 3. Number provenance (result CSV -> producing function)

| result | producing function (file:name:line) |
|---|---|
| mesh study (one case) | `run_production.py:run_mesh_study():66` |
| Richardson continuum estimate | `run_production.py:richardson_fit():87` |
| nominal + mesh + richardson campaign | `run_production.py:run_nominal_and_mesh():115` |
| p3-affinity sweep (fixed K) | `run_production.py:run_p3_sensitivity():160` |
| 3x3 alpha grid | `run_production.py:run_alpha_grid():196` |
| alpha3 SE -> voltage range | `run_production.py:run_alpha_uncertainty():216` |
| verification suite | `run_production.py:run_verification():241` |
| solved-field recovery CSV | `run_production.py:run_fields_csv():352` |
| energy/enthalpy audit | `run_production.py:run_energy_csv():370` |
| material parameter record | `run_production.py:run_material_record():387` |
| Part-3 acceptance vs frozen zip | `run_production.py:run_acceptance():472` |
| assembly / solve | `fem_solver.py:solve_case():297` |
| tied open-circuit constraint | `fem_solver.py:make_constraints():219` |
| field recovery | `fem_solver.py:recover_fields():344` |
| enthalpy postprocess | `fem_solver.py:postprocess_enthalpy():429` |
| beta_plane_strain (Correction 1) | `materials.py:beta_plane_strain():205` |
| correction verification fn 1 | `corrections.py:verify_correction1_beta_plane_strain():160` |
| correction verification fn 4 | `corrections.py:verify_correction4_alpha3_se():178` |

All CSVs written under `results/` are regenerated fresh by `run_production.py`: `alpha_grid_A.csv`, `alpha_grid_D.csv`, `alpha_grid_E.csv`, `alpha_uncertainty.csv`, `energy_audit_A.csv`, `fields_caseA_48x24.csv`, `material_parameter_record.csv`, `mesh_convergence_A.csv`, `mesh_convergence_B.csv`, `mesh_convergence_C.csv`, `mesh_convergence_D.csv`, `mesh_convergence_E.csv`, `numeric_acceptance_vs_frozen.csv`, `p3_sensitivity.csv`, `production_results.csv`, `richardson_summary.csv`, `verification_results.csv`.

## 4. Figure provenance (figures.py reads only the CSVs above)

| figure | producing function | CSV input(s) |
|---|---|---|
| `figures/fig01_model_schematic.png` / `.pdf` | `figures.py:fig01_model_schematic()` | none (diagram) |
| `figures/fig02_mesh_convergence.png` / `.pdf` | `figures.py:fig02_mesh_convergence()` | mesh_convergence_{D,A,E}.csv; richardson_summary.csv |
| `figures/fig03_cases_and_decomposition.png` / `.pdf` | `figures.py:fig03_cases()` | production_results.csv; mesh_convergence_D.csv; p3_sensitivity.csv |
| `figures/fig04_solved_fields.png` / `.pdf` | `figures.py:fig04_solved_fields()` | results/fields_caseA_48x24.csv |
| `figures/fig05_alpha_grid_3d.png` / `.pdf` | `figures.py:fig05_alpha_3d()` | alpha_grid_{E,A}.csv |
| `figures/fig06_alpha_grid_heatmap.png` / `.pdf` | `figures.py:fig06_alpha_heatmap()` | alpha_grid_{A,E,D}.csv |
| `figures/fig07_sign_evidence.png` / `.pdf` | `figures.py:fig07_sign_evidence()` | alpha_grid_E.csv |
| `figures/fig08_p3_sensitivity.png` / `.pdf` | `figures.py:fig08_p3()` | p3_sensitivity.csv |
| `figures/fig09_verification_energy.png` / `.pdf` | `figures.py:fig09_verification_energy()` | verification_results.csv; energy_audit_A.csv; production_results.csv |
| `figures/fig10_validation.png` / `.pdf` | `figures.py:fig10_validation()` | verification_results.csv; production_results.csv; numeric_acceptance_vs_frozen.csv; material_parameter_record.csv |

## 5. Verification suite (internal verification - never experimental validation)

No independent experimental full-device voltage exists for this system, and none is claimed anywhere in this deliverable (see Figure 10d).  Summary from `results/verification_results.csv`:

```
  BFS_partition_of_unity                                     value=         0.0  tol=       1e-12  PASS
  BFS_exact_linear_field_recovery                            value=2.0816681711721685e-17  tol=       1e-12  PASS
  Maxwell_reciprocity_coupled_matrix_relF                    value=1.2998703628133097e-17  tol=       1e-12  PASS
  D_exact_1D_pyro_at_default_mesh_16x8                       value=1.2914648633716864e-16  tol=       1e-10  PASS
  D_exact_1D_pyro_at_final_mesh_80x40                        value=1.5342602576855634e-13  tol=       1e-10  PASS
  zero_temperature                                           value=         0.0  tol=       1e-12  PASS
  zero_alpha_Case_E                                          value=         0.0  tol=       1e-12  PASS
  zero_p_Case_D                                              value=         0.0  tol=       1e-12  PASS
  zero_p_A_equals_E                                          value=         0.0  tol=       1e-10  PASS
  p_affinity_fixed_K_maxres                                  value=5.662137425588298e-15  tol=       1e-09  PASS
  enthalpy_variational_consistency                           value=3.5299347544878814e-10  tol=       1e-07  PASS
  superposition_V_A_ne_V_D_plus_V_E                          value=-1.738262753729253  tol=        None  INFO_nonadditive_shared_solve
  D_1D_identity_analytic_voltage_V                           value=-3.4386472481385097  tol=        None  INFO_analytic_value
```

## 6. Part-3 numeric acceptance vs frozen FEM5 release

| item | this Python | frozen zip | relative error | tolerance | status |
|---|---|---|---|---|---|
| nominal_voltage_case_D | -3.43864724814 | -3.43864724814 | 6.63e-14 | 1e-06 | PASS |
| nominal_voltage_case_A | -1.49959799768 | -1.49959799769 | 4.54e-12 | 1e-06 | PASS |
| nominal_voltage_case_E | 0.193211761048 | 0.193211761034 | 7.32e-11 | 1e-06 | PASS |
| 1D_pyro_identity_relative_error | 1.29146486337e-16 | 3.87439459012e-16 | 1.29e-16 | 1e-10 | PASS |
| p3_affine_slope | -1.70038449441 | -1.70038449441 | 3.70e-14 | 1e-06 | PASS |
| p3_affine_max_residual | 5.66213742559e-15 | 3.99680288865e-14 | 0.00e+00 | 1e-09 | PASS |

All items PASS.  Discrepancies beyond round-off were not observed; where they exist at all they are at the 1e-11 level (LU round-off) and are reported here explicitly rather than hidden.

## 7. Headline production numbers (finest mesh 80x40)

- Case D: V = -3.438647248 V on 80x40; Richardson estimate -3.43865 V; final-step relative change -2.22e-11%; converged True.
- Case A: V = -1.499597998 V on 80x40; Richardson estimate -1.50084 V; final-step relative change -0.0312%; converged True.
- Case E: V = 0.193211761 V on 80x40; Richardson estimate 0.192962 V; final-step relative change 0.0454%; converged True.
- Case 0: V = 0 V on 24x12; Richardson estimate 0 V; final-step relative change 0%; converged True.
- Case-D exact 1D analytic anchor (record Sec. 18.2): -3.438647248 V.
- p3-affine slope at fixed K (Case A, 16x8): -1.700384494 V per unit p3 scale; max affine residual 5.66e-15 V.
