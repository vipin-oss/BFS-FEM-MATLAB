"""
Branch classification and tracking utilities (rev.3 -- gated complex-plane
continuity tracking)
=========================================================================
This revision replaces the rev.2 "min-alpha within a fixed window, else hop"
heuristic with genuine sequential branch continuation in the complex Bloch
wavenumber plane, and fixes the root cause of the zig-zag / wrong-branch
line segments reported in the manuscript figures.

ROOT CAUSE (identified by direct inspection of the frozen production CSVs,
which are NOT modified by this module):

  Each frequency step of the production sweep (`run_phase3b_production.py`)
  already assigns a `branch_id` to the 5 tracked forward modes using a
  Hungarian (linear_sum_assignment) bijective matching between the previous
  step's 5 modes and the current step's 5 modes. Because the assignment is
  FORCED to be a complete bijection (5 <-> 5) at every step, whenever the
  physically continuing partner of a given branch temporarily leaves the
  "5 lowest-attenuation forward modes" set (e.g. a near-degenerate crossing,
  or a branch briefly becoming more evanescent than a neighbour), the
  Hungarian solver is forced to match it to an UNRELATED mode anyway --
  there is no "no match" option in a plain bijective assignment. This
  produces large (>1 rad), unphysical jumps in an otherwise smooth
  branch_id trajectory. Directly measured for S1_dpl: 495 consecutive
  frequency-step displacements in complex k-space, median 0.035 rad,
  90th percentile 0.087 rad, but with isolated outliers up to 8.5 rad --
  i.e. genuine mis-assignments, not gradual physical drift.

FIX (plotting/data-processing layer only -- the frozen numerical values in
the production CSVs, i.e. every (Omega, kr_a, ki_signed, alpha_a,
eigval, is_pass_band) tuple, are read verbatim and never altered):

  `retrack_branches()` re-derives branch identity from the SAME frozen
  per-Omega mode sets using a GATED sequential nearest-neighbour tracker:

    - Distance between a previous-step mode and a current-step mode is the
      true Euclidean distance in the complex Bloch-wavenumber plane,
      d = |Delta kr_a + i*Delta ki_signed|  (both real AND imaginary parts
      of the complex wavenumber, not a normalized/alpha-based surrogate).
    - A per-case ADAPTIVE gate is computed from the empirical distribution
      of small, in-window step sizes (median of the smallest per-step
      nearest-neighbour distances). Only matches with cost below
      max(GATE_FLOOR, GATE_SCALE * median_small_step) are accepted.
    - Matches are chosen by solving the assignment as a genuine minimum-cost
      BIPARTITE matching (Hungarian) but candidate edges above the gate are
      removed from the cost matrix (replaced by a large penalty) BEFORE
      solving, and any resulting assignment whose cost still exceeds the
      gate is REJECTED rather than accepted: the previous branch is marked
      TERMINATED (the line breaks) and the current-step mode starts a new
      branch id. This removes the "forced bijection" defect above while
      still preferring a globally-optimal matching among the gated
      candidates (not a greedy/first-found heuristic).
    - No mode is ever fabricated, discarded, or re-valued: every input row
      is preserved and re-emitted with a (possibly revised) `branch_id2`
      field plus a `_terminated_before` flag marking genuine breaks.

  `extract_acoustic_branch()` then simply follows the single branch_id2
  whose points are propagating (is_pass_band) most often across the sweep
  -- the physically fundamental least-attenuated acoustic branch -- through
  its full (possibly evanescent-continued) trajectory, breaking the plotted
  line only where `retrack_branches` recorded a genuine termination.

  `group_branches_for_dispersion()` exposes ALL re-tracked branches (not
  just the acoustic one) as a list of continuous polylines, each already
  split at genuine terminations, for the multi-branch dispersion diagrams.

Nothing in this module invents new numerical data, interpolates across a
gap, or applies any smoothing filter/spline. It only decides which already
-computed points belong to the same physical branch and where a plotted
line must stop.
"""

import math
from collections import defaultdict

import numpy as np
from scipy.optimize import linear_sum_assignment

# Same thresholds as the frozen production `is_pass_band` definition
ALPHA_PASS = 0.05
KR_MIN = 0.01
KR_MAX = math.pi - 0.01          # kr_a upper bound of the frozen pass-band rule

GATE_FLOOR = 0.30                # rad; absolute minimum acceptable gate
GATE_SCALE = 6.0                 # multiple of the local median small-step size

# PLOT-FILTERING policy (distinct from branch TRACKING above): a tracked
# segment of fewer than MIN_SEGMENT_LEN consecutive frequency samples
# cannot visually establish a "continuous branch" or a resolved trend --
# with only 1-2 points it is indistinguishable from an isolated numerical
# artifact (a mode grazing the propagating threshold for a single step, a
# near-degenerate evanescent solution picked arbitrarily by a global
# minimum-alpha tie-break, etc.). Such short fragments are DROPPED FROM THE
# RENDERED FIGURE ONLY -- every point remains untouched in the underlying
# per-case CSV / `branch_id2` grouping; this is a display decision, not a
# data deletion. Documented and applied identically by every dispersion
# and acoustic-branch plotting routine below, per the correction brief's
# explicit requirement that the same branch-selection/plot-filtering rule
# be used consistently across Figs. 3, 5, 6, 7, 9(a), 10 and 13.
MIN_SEGMENT_LEN = 3


def classify_mode(rec, alpha_pass=ALPHA_PASS, kr_min=KR_MIN, kr_max=None):
    """Return True if the record is a genuinely propagating Bloch mode."""
    kr = float(rec["kr_a_over_pi"])
    return (
        (kr > kr_min)
        and (float(rec["alpha_a"]) < alpha_pass)
        and (kr_max is None or kr < kr_max)
    )


def _complex_k(rec):
    return complex(float(rec["kr_a"]), float(rec["ki_signed"]))


def unique_propagating_k(rows_at_omega, alpha_pass=ALPHA_PASS, kr_min=KR_MIN, kr_max=None):
    """
    Given all records at ONE Omega step, return the single distinct complex
    Bloch wavenumber shared by every propagating (`classify_mode`-passing)
    row, if there is exactly one such distinct value (any number of
    degenerate rows -- e.g. a +/- polarization pair -- realizing the SAME
    value still counts as one), else None.

    Used by both `retrack_branches` and `extract_acoustic_branch` for the
    "unambiguous continuation" override: connecting two adjacent Omega
    steps that each have exactly one propagating solution is never a
    branch-SELECTION decision (there is no competing candidate at either
    step to confuse it with), so it is safe to bypass the normal
    crossing-protection distance gate for such a pair. See
    `retrack_branches`'s docstring for the concrete failure this fixes.
    """
    vals = []
    for r in rows_at_omega:
        if classify_mode(r, alpha_pass, kr_min, kr_max):
            k = _complex_k(r)
            if not any(abs(k - v) < 1e-6 for v in vals):
                vals.append(k)
    return vals[0] if len(vals) == 1 else None


def compute_adaptive_gate(records, gate_floor=GATE_FLOOR, gate_scale=GATE_SCALE):
    """Same adaptive-gate calibration used internally by retrack_branches,
    exposed so callers that need to judge a raw complex-k jump against 'is
    this a genuine continuation' (e.g. the evanescent-fallback extension in
    extract_acoustic_branch) use an identical, consistently-derived
    threshold rather than an arbitrary second number."""
    by_om = defaultdict(list)
    for r in records:
        by_om[float(r["Omega"])].append(r)
    omegas = sorted(by_om)
    calib_costs = []
    for i in range(len(omegas) - 1):
        cur = by_om[omegas[i]]
        nxt = by_om[omegas[i + 1]]
        for a in cur:
            ka = _complex_k(a)
            best = min(abs(_complex_k(b) - ka) for b in nxt)
            calib_costs.append(best)
    calib_costs.sort()
    if calib_costs:
        lower = calib_costs[: max(1, int(0.8 * len(calib_costs)))]
        median_small = float(np.median(lower))
    else:
        median_small = 0.05
    return max(gate_floor, gate_scale * median_small)


def retrack_branches(records, gate_floor=GATE_FLOOR, gate_scale=GATE_SCALE):
    """
    Re-derive continuous branch identity for one case's records using a
    gated, complex-plane sequential tracker with LINEAR EXTRAPOLATION
    prediction (rev.4).

    WHY rev.4 exists: rev.3 matched each active branch to the current-step
    mode nearest to its LAST accepted point only (a zero-order / "nearest
    neighbour" predictor). Direct inspection of the resulting curves (e.g.
    S1_cons, S3_d01) showed that this is exactly the classical failure mode
    of nearest-neighbour eigenvalue tracking through a near-degenerate
    crossing or a region where two branches run close and nearly parallel:
    when two candidate modes are both within the previous point's gate, the
    nearest one is not always the physically continuing one, so the
    tracker can silently hop onto the wrong sheet mid-sweep. The result is
    not a rejected/terminated match (which would correctly break the line)
    but a WRONGLY ACCEPTED match: a single `branch_id2` whose (kr_a,
    ki_signed) trajectory contains a sudden, non-physical reversal (e.g.
    kr rising smoothly for 10+ steps, then dropping sharply while Omega
    keeps increasing) with no genuine termination flagged -- drawn as one
    continuous line, this reads as exactly the "zig-zag / criss-crossing"
    artifact reported on visual inspection of Figs. 3 and 6.

    THE FIX: each active branch's next expected position is predicted by
    LINEAR EXTRAPOLATION from its last two accepted points (k_pred = 2*k1
    - k0), not simply "wherever it was last". Two branches that are
    instantaneously close in the complex-k plane but moving in different
    directions (the classic crossing/veering signature) separate rapidly
    under this prediction, so the correct continuation is picked even when
    the raw nearest-previous-point distance was ambiguous. A branch with
    fewer than two accepted points (i.e. only just started) falls back to
    its single last point (zero-order), which is the only option available
    and matches rev.3 behaviour at every branch's own start. This changes
    ONLY which already-computed row is judged to continue which branch;
    no `Omega`/`kr_a`/`ki_signed`/`alpha_a`/eigenvalue value is invented,
    recomputed, or altered.

    `records` must all belong to a single case_id. Returns a NEW list of
    shallow-copied dicts (inputs are never mutated) with an added
    integer field `branch_id2` and boolean field `_terminated_before`
    (True marks the first point of a new, disconnected branch segment).
    """
    by_om = defaultdict(list)
    for r in records:
        by_om[float(r["Omega"])].append(dict(r))
    omegas = sorted(by_om)
    if not omegas:
        return []

    # --- Pass 1: naive bijective step costs, to calibrate the adaptive gate ---
    calib_costs = []
    for i in range(len(omegas) - 1):
        cur = by_om[omegas[i]]
        nxt = by_om[omegas[i + 1]]
        for a in cur:
            ka = _complex_k(a)
            best = min(abs(_complex_k(b) - ka) for b in nxt)
            calib_costs.append(best)
    calib_costs.sort()
    if calib_costs:
        # robust "typical small step" estimate: median of the lower 80% of
        # costs (excludes the very jumps we are trying to detect)
        lower = calib_costs[: max(1, int(0.8 * len(calib_costs)))]
        median_small = float(np.median(lower))
    else:
        median_small = 0.05
    gate = max(gate_floor, gate_scale * median_small)

    # --- Unambiguous-continuation override (rev.5) -----------------------
    # CONCRETE FAILURE FOUND (S3_classical, Fig. 13): a genuinely propagating
    # branch emerging from a Bragg-gap edge can have a very low local group
    # velocity (large |d kr/d Omega|), so its own first few per-step
    # displacements exceed the case's globally-calibrated gate even though
    # there is only ONE candidate at each step -- a brand-new branch (0 or 1
    # accepted points) has no linear-extrapolation history yet, so it is
    # rejected by the same gate that correctly protects against wrong-branch
    # jumps at a genuine multi-candidate crossing. Directly verified for
    # S3_classical: the propagating window Omega in [0.7571, 0.8278] (5
    # samples, single degenerate propagating solution at every one of those
    # steps, kr_a descending 2.31 -> 1.84 -> 1.43 -> 1.01 -> 0.41) was split
    # into 5 separate one-point branches purely because each per-step
    # displacement (~0.4-0.6 rad) exceeds the case's gate (0.39 rad), NOT
    # because of any competing candidate.
    #
    # FIX: at a given step, if the immediately preceding Omega has EXACTLY
    # ONE distinct propagating (kr_a, ki_signed) value (irrespective of how
    # many degenerate rows realize it) and the current Omega also has
    # exactly one, connecting them is not a "branch selection" decision at
    # all -- there is no second candidate to confuse it with, so the gate's
    # entire purpose (protecting against an ambiguous multi-candidate match)
    # does not apply. Such a pair is allowed to connect even if its distance
    # exceeds the normal gate (capped at UNAMBIGUOUS_GATE_CAP * gate as a
    # sanity bound against a genuinely disparate accidental pairing).
    # A genuine physical gap (many consecutive Omega steps with ZERO
    # propagating candidates, e.g. the reported [0.4566, 0.7571] Bragg gap)
    # is untouched by this override: it only ever compares two IMMEDIATELY
    # ADJACENT Omega steps, and no propagating candidate exists at any of
    # the intervening steps inside a real gap, so the override never has
    # anything to connect across it.
    UNAMBIGUOUS_GATE_CAP = 3.0
    prop_unique_k = {om: unique_propagating_k(by_om[om]) for om in omegas}

    # --- Pass 2: gated sequential Hungarian tracking with linear-extrapolation
    # prediction (rev.4 -- see docstring for why nearest-previous-point alone
    # is insufficient at near-degenerate crossings) ---
    first_rows = sorted(by_om[omegas[0]], key=lambda r: (float(r["kr_a"]), float(r["alpha_a"])))
    next_id = 0
    for r in first_rows:
        r["branch_id2"] = next_id
        r["_terminated_before"] = True   # start of every branch is a "break" (nothing before it)
        next_id += 1
    # active[bid] = (last_row, prev_row_or_None) -- prev_row_or_None is the
    # second-most-recent accepted row for this branch, used for linear
    # extrapolation; None until the branch has >= 2 accepted points.
    active = {r["branch_id2"]: (r, None) for r in first_rows}
    out = list(first_rows)

    prev_om = omegas[0]
    for om in omegas[1:]:
        cur_rows = by_om[om]
        prev_ids = list(active.keys())
        N_prev = len(prev_ids)
        N_curr = len(cur_rows)
        cost = np.full((N_prev, N_curr), 1e6)
        pred_k = {}
        # unambiguous-continuation override eligibility for this transition
        # (see note above): only meaningful when comparing two immediately
        # adjacent Omega steps, which is exactly what this loop always does.
        prev_unique = prop_unique_k.get(prev_om)
        cur_unique = prop_unique_k.get(om)
        override_active = prev_unique is not None and cur_unique is not None
        for i, bid in enumerate(prev_ids):
            last, prev = active[bid]
            k_last = _complex_k(last)
            if prev is not None:
                k_pred = 2.0 * k_last - _complex_k(prev)   # linear extrapolation
            else:
                k_pred = k_last                             # zero-order fallback (branch just started)
            pred_k[bid] = k_pred
            last_is_unique_prop = (
                override_active and classify_mode(last) and abs(k_last - prev_unique) < 1e-6
            )
            for j, r in enumerate(cur_rows):
                d = abs(_complex_k(r) - k_pred)
                if d <= gate:
                    cost[i, j] = d
                elif (last_is_unique_prop and classify_mode(r)
                      and abs(_complex_k(r) - cur_unique) < 1e-6
                      and d <= UNAMBIGUOUS_GATE_CAP * gate):
                    # unambiguous continuation: no competing candidate at
                    # either step, so accept despite exceeding the normal
                    # (crossing-protection) gate.
                    cost[i, j] = d
        row_ind, col_ind = linear_sum_assignment(cost)

        matched_curr = set()
        kept_ids = set()
        for i, j in zip(row_ind, col_ind):
            if cost[i, j] < 1e6:  # within gate: genuine continuation
                bid = prev_ids[i]
                r = cur_rows[j]
                r["branch_id2"] = bid
                r["_terminated_before"] = False
                last, _prev = active[bid]
                active[bid] = (r, last)   # shift history: new last, old last becomes prev
                out.append(r)
                matched_curr.add(j)
                kept_ids.add(bid)
            # else: this previous branch found no acceptable partner this
            # step -- it is simply dropped from `active`; if it reappears
            # later it will start a fresh branch id (a genuine termination).

        for bid in prev_ids:
            if bid not in kept_ids:
                del active[bid]

        # Any current-step mode not matched to an existing branch starts a new one
        for j, r in enumerate(cur_rows):
            if j not in matched_curr:
                r["branch_id2"] = next_id
                r["_terminated_before"] = True
                active[next_id] = (r, None)
                out.append(r)
                next_id += 1

        prev_om = om

    return out


def predictive_step_cost(pts):
    """
    For one already-grouped, gap-free branch segment `pts` (sorted by
    Omega, e.g. one value of `group_branches_for_dispersion`'s output),
    return the list of per-step costs `retrack_branches` itself actually
    evaluated its gate against: the distance between each point and the
    LINEAR-EXTRAPOLATION prediction from the two preceding points (or,
    for the second point of the branch, the zero-order distance to the
    first point -- the only prediction available that early).

    This is the audit-facing counterpart of the tracker's internal
    acceptance test. Because rev.4 gates on distance-to-PREDICTED-point
    rather than raw point-to-point distance, a genuinely accelerating
    (but smoothly, correctly tracked) branch can have a raw consecutive-
    point jump larger than the gate while every one of these predictive
    costs stays within it -- checking predictive cost, not raw distance,
    is therefore the correct way to confirm "the tracker's own gate was
    never silently violated by a forced/incorrect match" for rev.4.
    """
    costs = []
    for i in range(1, len(pts)):
        k_i = _complex_k(pts[i])
        if i >= 2:
            k_pred = 2.0 * _complex_k(pts[i - 1]) - _complex_k(pts[i - 2])
        else:
            k_pred = _complex_k(pts[i - 1])
        costs.append(abs(k_i - k_pred))
    return costs


def step_is_gate_compliant(prev_row, cur_row, gate, prop_unique_prev, prop_unique_cur,
                            unambiguous_gate_cap=3.0, alpha_pass=ALPHA_PASS, kr_min=KR_MIN,
                            kr_max=None, predictive_cost=None):
    """
    Authoritative, audit-facing re-statement of exactly what `retrack_branches`
    (and `extract_acoustic_branch`'s fallback loop) actually accept as a
    genuine continuation between two ADJACENT Omega steps -- ANY of:

      (a) the raw distance is within `gate`;
      (b) `predictive_cost` (the distance to the linear-extrapolation
          prediction from the two preceding accepted points -- see
          `predictive_step_cost`; pass None if unavailable, e.g. the very
          first step of a branch) is within `gate` -- this is what lets a
          genuinely accelerating branch near a turning point/cutoff (large
          raw step, but well anticipated by its own recent trend) pass
          without loosening the gate for an ambiguous crossing;
      (c) the "unambiguous continuation" override: both rows are each the
          SOLE propagating solution at their own Omega (no competing
          candidate for the gate to protect against), and the raw distance
          is within `unambiguous_gate_cap * gate`.

    `prop_unique_prev`/`prop_unique_cur` are this Omega's
    `unique_propagating_k(...)` result (pass the already-computed value; a
    caller iterating many steps should compute it once per Omega, not once
    per pair, since `unique_propagating_k` needs all rows at that Omega).
    """
    d = abs(_complex_k(cur_row) - _complex_k(prev_row))
    if d <= gate:
        return True, d
    if predictive_cost is not None and predictive_cost <= gate:
        return True, d
    if (prop_unique_prev is not None and prop_unique_cur is not None
            and classify_mode(prev_row, alpha_pass, kr_min, kr_max)
            and classify_mode(cur_row, alpha_pass, kr_min, kr_max)
            and abs(_complex_k(prev_row) - prop_unique_prev) < 1e-6
            and abs(_complex_k(cur_row) - prop_unique_cur) < 1e-6
            and d <= unambiguous_gate_cap * gate):
        return True, d
    return False, d


def group_branches_for_dispersion(records):
    """
    Re-track `records` (one case_id) and return a dict branch_id2 -> list of
    points sorted by Omega, each list already representing one physically
    continuous, gap-free segment (a genuine termination simply ends that
    branch_id2's list; a NEW branch_id2 is used after the gap, so plotting
    each branch_id2 as its own polyline never draws a diagonal connector
    across a real discontinuity).
    """
    tracked = retrack_branches(records)
    by_branch = defaultdict(list)
    for r in tracked:
        by_branch[r["branch_id2"]].append(r)
    for bid in by_branch:
        by_branch[bid].sort(key=lambda r: float(r["Omega"]))
    return by_branch


def extract_acoustic_branch(records, alpha_pass=ALPHA_PASS, kr_min=KR_MIN,
                             kr_max=KR_MAX, continuity_window=None):
    """
    Rev.3 acoustic-branch extraction: identify the single re-tracked
    branch_id2 that is propagating (pass-band) most often across the sweep
    -- the fundamental least-attenuated acoustic branch -- and return its
    full trajectory (propagating AND evanescent-continued points) IN
    OMEGA ORDER, annotated with `_is_prop` and `_hopped` (True only at a
    genuine re-tracked termination, i.e. where the line must break).

    `continuity_window` is accepted for backward-compatible call signatures
    but is unused by rev.3 (continuity is now enforced by the gated
    complex-plane tracker itself, not by a fixed-width window on kr alone).
    """
    groups = group_branches_for_dispersion(records)
    for bid, pts in groups.items():
        for r in pts:
            r["_is_prop"] = classify_mode(r, alpha_pass, kr_min, kr_max)

    # Pick the branch with the most propagating points; break ties by
    # lowest mean alpha_a among its propagating points (the more
    # "acoustic-like" / less attenuated of the tied candidates).
    def score(pts):
        n_prop = sum(1 for r in pts if r["_is_prop"])
        mean_alpha = (
            float(np.mean([float(r["alpha_a"]) for r in pts if r["_is_prop"]]))
            if n_prop else float("inf")
        )
        return (n_prop, -mean_alpha)

    best_bid = max(groups, key=lambda b: score(groups[b]))
    core_pts = groups[best_bid]
    for i, r in enumerate(core_pts):
        r["_hopped"] = bool(r.get("_terminated_before", False)) and i > 0
    core_by_om = {float(r["Omega"]): r for r in core_pts}

    # Extend the clean, gated-tracked propagating "core" branch across any
    # Omega it does not cover (deep stop-band regions where many nearly
    # degenerate evanescent solutions make a single eigen-branch identity
    # ambiguous) using the physically appropriate evanescent continuation:
    # the least-attenuated mode overall at that Omega. This mirrors the
    # rev.2 stop-band fallback and is NOT a new numerical evaluation -- it
    # only selects among rows already present in the frozen production
    # CSV. It preserves the genuine attenuation spike inside a Bragg gap
    # instead of truncating the curve at the gap onset. These fallback
    # points are marked `_is_prop=False`, `_hopped=False` (a continuation,
    # never a break), matching the documented "evanescent continuation"
    # requirement for the attenuation figures.
    gate = compute_adaptive_gate(records)
    UNAMBIGUOUS_GATE_CAP = 3.0
    by_om_all = defaultdict(list)
    for r in records:
        by_om_all[float(r["Omega"])].append(dict(r))
    # Same "unambiguous continuation" override as `retrack_branches` (see
    # its docstring): a fallback pick that is the ONLY propagating solution
    # at its Omega, immediately following a previous accepted point that
    # was likewise the only propagating solution at ITS Omega, is not an
    # ambiguous branch-selection decision -- there is no competing
    # candidate at either step -- so it is not broken merely for exceeding
    # the normal distance gate. CONCRETE CASE FIXED: S3_classical's
    # Omega in [0.7571, 0.8278] propagating re-emergence (kr_a descending
    # 2.31 -> 1.84 -> 1.43 -> 1.01 -> 0.41, each step ~0.4-0.6 rad, exceeding
    # the case's 0.39 rad gate) is a single, genuinely continuous, low-
    # group-velocity branch, not five isolated points.
    prop_unique_k_all = {om: unique_propagating_k(by_om_all[om], alpha_pass, kr_min, kr_max)
                         for om in by_om_all}
    full = []
    prev_k = None
    prev_om_val = None
    prev_row = None
    for om in sorted(by_om_all):
        if om in core_by_om:
            row = core_by_om[om]
        else:
            fallback_rows = by_om_all[om]
            row = min(fallback_rows, key=lambda r: float(r["alpha_a"]))
            # BUGFIX (this pass): the fallback pick can itself genuinely
            # satisfy the propagating criterion (this happens whenever the
            # gated tracker's "core" branch selection missed a later,
            # separately-tracked propagating window -- see audit note on
            # S3_classical, which has THREE further short propagating
            # windows at Omega ~ [1.27,1.36], [1.60,1.68], [1.73,1.80] in
            # addition to its main low-frequency window). Unconditionally
            # marking every fallback pick "_is_prop=False" mislabels those
            # genuinely propagating points as evanescent. Classify honestly.
            row["_is_prop"] = classify_mode(row, alpha_pass, kr_min, kr_max)
            # A fallback pick close to the previous accepted point in
            # complex k-space is a genuine evanescent continuation; one
            # further than the same continuity gate used for the main
            # tracker is NOT the same physical solution branch any more --
            # break the line here rather than drawing a diagonal connector
            # (this is exactly the same rule applied to the multi-branch
            # dispersion plots, applied consistently to the single
            # acoustic-branch curve's evanescent-continuation segments) --
            # UNLESS the unambiguous-continuation override above applies.
            raw_d = abs(_complex_k(row) - prev_k) if prev_k is not None else None
            is_hop = bool(full) and (raw_d is not None) and (raw_d > gate)
            if is_hop:
                cur_unique = prop_unique_k_all.get(om)
                prev_unique = prop_unique_k_all.get(prev_om_val) if prev_om_val is not None else None
                if (cur_unique is not None and prev_unique is not None
                        and row["_is_prop"] and prev_row is not None
                        and classify_mode(prev_row, alpha_pass, kr_min, kr_max)
                        and abs(_complex_k(row) - cur_unique) < 1e-6
                        and abs(prev_k - prev_unique) < 1e-6
                        and raw_d <= UNAMBIGUOUS_GATE_CAP * gate):
                    is_hop = False
            row["_hopped"] = is_hop
        full.append(row)
        prev_k = _complex_k(row)
        prev_om_val = om
        prev_row = row

    _mark_display_flags(full, min_len=MIN_SEGMENT_LEN)
    return full


def _mark_display_flags(full, min_len=MIN_SEGMENT_LEN):
    """
    PLOT FILTERING for the single acoustic-branch curve (distinct from the
    tracking already done above): decide which points are actually part of
    "the continuously tracked acoustic branch" that Figs. 4/8/9(b)/13 claim
    to show, versus which are fallback picks from a broad, ill-defined,
    deep stop-band continuum that happen to survive the gate but do not
    represent a genuine, resolved physical continuation.

    Sets `_display=True/False` on every point of `full` IN PLACE (the
    field is additive; nothing already computed by `extract_acoustic_branch`
    is altered) using two rules, applied to the contiguous runs already
    delimited by `_hopped`:

      1. LENGTH: a run shorter than `min_len` samples is never displayed
         (same rationale as `plot_dispersion_branches`: 1-2 points cannot
         establish a resolved trend).
      2. EVANESCENT BRIDGING: a run containing no propagating point at all
         is displayed ONLY when it directly bridges two DISPLAYED
         propagating runs (i.e. is immediately preceded and followed, in
         the sequence of runs that survive rule 1, by a genuinely
         propagating run). This is the honest definition of "the
         physically appropriate evanescent continuation inside a Bragg
         gap" the correction brief asks for: it connects two resolved
         pass bands. A pure-evanescent run that dangles at either end of
         the sweep, or sits inside a broad multi-fragment stop-band
         continuum with no resolved propagating band on both sides (the
         classical-thermoelasticity limit's behaviour above Omega ~ 0.44,
         confirmed by direct inspection: dozens of sub-length-3 and
         isolated evanescent picks with attenuation up to O(1), not a
         narrow well-defined gap), is a numerically arbitrary "least
         attenuated of many near-degenerate options" and is NOT displayed
         -- the curve is left genuinely broken there instead, which is the
         scientifically honest representation when no single acoustic
         branch is actually resolved.

    A dropped point keeps every other field untouched (nothing is deleted
    from the data `extract_acoustic_branch` returns) -- only `_display`
    governs whether `plot_acoustic_branch` draws it.
    """
    runs = []
    start = 0
    for i in range(1, len(full)):
        if full[i].get("_hopped", False):
            runs.append((start, i - 1))
            start = i
    runs.append((start, len(full) - 1))

    run_info = []
    for (a, b) in runs:
        length = b - a + 1
        has_prop = any(full[k].get("_is_prop", False) for k in range(a, b + 1))
        long_enough = length >= min_len
        run_info.append({"a": a, "b": b, "len": length, "prop": has_prop, "long_enough": long_enough})

    # Rule 1: length filter (provisional keep/drop)
    for r in run_info:
        r["keep"] = r["long_enough"]

    # Rule 2: evanescent runs must bridge two KEPT propagating runs
    kept_idx = [i for i, r in enumerate(run_info) if r["keep"]]
    for pos, i in enumerate(kept_idx):
        r = run_info[i]
        if r["keep"] and not r["prop"]:
            prev_prop = pos > 0 and run_info[kept_idx[pos - 1]]["prop"]
            next_prop = pos < len(kept_idx) - 1 and run_info[kept_idx[pos + 1]]["prop"]
            if not (prev_prop and next_prop):
                r["keep"] = False

    for r in run_info:
        for k in range(r["a"], r["b"] + 1):
            full[k]["_display"] = r["keep"]


def _same_dispersion_curve(a, b, dup_tol):
    """Return whether two sampled (k_r, Omega) polylines coincide pointwise."""
    if len(a["xs"]) != len(b["xs"]):
        return False
    return all(abs(xa - xb) < dup_tol and abs(ya - yb) < dup_tol
               for xa, xb, ya, yb in zip(a["xs"], b["xs"], a["ys"], b["ys"]))


def _chain_dispersion_segments(records, alpha_pass=ALPHA_PASS, kr_min=KR_MIN,
                               min_len=MIN_SEGMENT_LEN, dup_tol=1e-3,
                               reconnect_kr_tol=0.03, reconnect_om_tol=None):
    """
    Return the exact rendered propagating sub-runs used by both plotting and
    branch labeling, grouped into physical-branch chains. A chain is built
    only after the existing minimum-length filter and exact-degeneracy
    deduplication; successive members are joined by the same facing-endpoint
    k_r tolerance and short Omega-gap criterion documented in
    `label_dispersion_branches`.

    Each returned segment contains sampled `xs`/`ys`; the list position in
    its chain drives presentation-only linestyle cycling and label suffixes.
    This shared helper is deliberately the sole implementation of the
    deduplication/reconnection rules, so annotations and plotted line styles
    cannot derive conflicting groupings.
    """
    groups = group_branches_for_dispersion(records)
    omegas_all = sorted({float(r["Omega"]) for pts in groups.values() for r in pts})
    if reconnect_om_tol is None:
        step = (omegas_all[1] - omegas_all[0]) if len(omegas_all) > 1 else 0.02
        # Preserve the established tolerance: span the measured narrow
        # Bragg gaps while remaining below the broad gaps between windows.
        reconnect_om_tol = 8.0 * step

    raw_segs = []
    for bid in sorted(groups):
        pts = groups[bid]
        xs = [float(r["kr_a_over_pi"]) for r in pts]
        ys = [float(r["Omega"]) for r in pts]
        is_prop = [classify_mode(r, alpha_pass, kr_min) for r in pts]
        i = 0
        while i < len(pts):
            j = i
            while j + 1 < len(pts) and is_prop[j + 1] == is_prop[i]:
                j += 1
            if j - i + 1 >= min_len and is_prop[i]:
                raw_segs.append({"xs": xs[i:j + 1], "ys": ys[i:j + 1]})
            i = j + 1

    unique_segs = []
    for seg in raw_segs:
        if not any(_same_dispersion_curve(seg, existing, dup_tol)
                   for existing in unique_segs):
            unique_segs.append(seg)
    unique_segs.sort(key=lambda seg: seg["ys"][0])

    chains = []
    for seg in unique_segs:
        for chain in chains:
            tail = chain[-1]
            om_gap = seg["ys"][0] - tail["ys"][-1]
            kr_gap = abs(seg["xs"][0] - tail["xs"][-1])
            if 0 <= om_gap <= reconnect_om_tol and kr_gap <= reconnect_kr_tol:
                chain.append(seg)
                break
        else:
            chains.append([seg])
    return chains


def _linestyle_for_dispersion_segment(xs, ys, chains, dup_tol=1e-3):
    """Look up a plotted segment's position in the shared physical chain."""
    styles = ("-", "--", "-.", ":")
    candidate = {"xs": xs, "ys": ys}
    for chain in chains:
        for member_idx, member in enumerate(chain):
            if _same_dispersion_curve(candidate, member, dup_tol):
                return styles[member_idx % len(styles)]
    # A segment absent from the shared, filtered chain must not be styled as
    # a reconnection. Solid is the conservative fallback for custom callers.
    return "-"


def plot_dispersion_branches(ax, records, prop_color, evan_color="0.75",
                              lw=2.0, evan_lw=1.0, label=None,
                              alpha_pass=ALPHA_PASS, kr_min=KR_MIN,
                              show_evanescent=False, min_len=MIN_SEGMENT_LEN,
                              diagnostics=None, dup_tol=1e-3,
                              reconnect_kr_tol=0.03, reconnect_om_tol=None):
    """
    Plot the re-tracked branch structure of `records` (one case_id) as
    continuous polylines, applying BOTH steps the correction brief
    distinguishes: (1) branch TRACKING (`group_branches_for_dispersion`,
    already gated/continuity-checked) and (2) PLOT FILTERING -- deciding
    which of the tracked segments actually belong in this figure:

      - A genuinely propagating sub-run (`classify_mode` True) of at least
        `min_len` consecutive points is drawn in `prop_color`. Its linestyle
        is determined by its position within the shared Bragg-gap-reconnection
        chain: solid for the first member, dashed for the second, dash-dot for
        the third, dotted for the fourth, then cycling. Distinct chains each
        restart at solid, so linestyle distinguishes continuation across a
        detected gap rather than assigning a different style to every branch.
      - An evanescent/complex-wavenumber sub-run is drawn (thin, faint
        `evan_color`) ONLY when `show_evanescent=True` -- i.e. only in a
        figure whose stated purpose is to classify/display evanescent
        structure (Figs. 3/1_baseline_dispersion). Figures whose caption
        and text only claim to compare "acoustic dispersion" across a
        parameter (Figs. 5, 6, 7, 9(a), 10) never render evanescent
        segments: they are not part of the stated comparison.
      - ANY segment shorter than `min_len` -- propagating or evanescent,
        including every isolated single point -- is DROPPED FROM THIS PLOT
        ONLY. A run of 1-2 samples cannot establish a resolved continuous
        trend and is visually indistinguishable from an isolated numerical
        artifact (e.g. a mode grazing the propagating threshold for a
        single frequency step). It is never deleted from the underlying
        `branch_id2` grouping or the frozen CSV -- this is a plot-filtering
        decision, not a data edit. No isolated point is ever drawn as a
        marker in this routine (the correction brief explicitly asks that
        an isolated/unmatched point NOT be plotted unless the scientific
        interpretation requires it, which none of these figures do).

    No diagonal connector is ever drawn between two different branch2
    segments, or across a dropped short segment: each surviving segment is
    plotted independently, so a genuine termination is a real gap in the
    figure, never bridged.

    If `diagnostics` (a list) is passed, one dict per raw tracked segment
    is appended, recording exactly what was kept/dropped and why -- the
    per-case audit trail requested in the correction brief.
    """
    groups = group_branches_for_dispersion(records)
    chains = _chain_dispersion_segments(
        records, alpha_pass=alpha_pass, kr_min=kr_min, min_len=min_len,
        dup_tol=dup_tol, reconnect_kr_tol=reconnect_kr_tol,
        reconnect_om_tol=reconnect_om_tol,
    )
    first_prop_plotted = False
    for bid in sorted(groups):
        pts = groups[bid]
        xs = [float(r["kr_a_over_pi"]) for r in pts]
        ys = [float(r["Omega"]) for r in pts]
        is_prop = [classify_mode(r, alpha_pass, kr_min) for r in pts]
        # Split this already-continuous branch further into propagating vs
        # evanescent sub-runs (a branch may fold from propagating into an
        # evanescent tail without a tracking termination -- e.g. approaching
        # a stop band) so line style switches honestly at that crossover.
        i = 0
        n = len(pts)
        while i < n:
            j = i
            while j + 1 < n and is_prop[j + 1] == is_prop[i]:
                j += 1
            seg_x, seg_y = xs[i:j + 1], ys[i:j + 1]
            prop_here = is_prop[i]
            seg_len = len(seg_x)
            kept = False
            reason = ""
            if seg_len >= min_len and prop_here:
                lbl = label if (label and not first_prop_plotted) else None
                line_style = _linestyle_for_dispersion_segment(seg_x, seg_y, chains)
                ax.plot(seg_x, seg_y, line_style, color=prop_color, lw=lw, label=lbl, zorder=3)
                first_prop_plotted = first_prop_plotted or bool(lbl)
                kept = True
                reason = ("propagating, len>=min_len: plotted as acoustic/optical branch "
                          f"(chain linestyle {line_style!r})")
            elif seg_len >= min_len and (not prop_here) and show_evanescent:
                ax.plot(seg_x, seg_y, "-", color=evan_color, lw=evan_lw, alpha=0.7, zorder=1)
                kept = True
                reason = "evanescent, len>=min_len, show_evanescent=True: plotted as reference"
            elif seg_len < min_len:
                reason = (f"dropped: segment length {seg_len} < MIN_SEGMENT_LEN={min_len} "
                          f"(isolated/unresolved, not a resolved trend)")
            else:
                reason = "dropped: evanescent segment, show_evanescent=False (outside this figure's stated comparison)"
            if diagnostics is not None:
                diagnostics.append({
                    "branch2": bid, "n_points": seg_len,
                    "omega_range": (pts[i]["Omega"], pts[j]["Omega"]),
                    "propagating": prop_here, "plotted": kept, "reason": reason,
                })
            i = j + 1


def label_dispersion_branches(ax, records, prefix="", start_n=1, alpha_pass=ALPHA_PASS,
                               kr_min=KR_MIN, min_len=MIN_SEGMENT_LEN, fontsize=8,
                               txtcolor="black", frac=0.5, offset=(9, 9),
                               dup_tol=1e-3, reconnect_kr_tol=0.03, reconnect_om_tol=None):
    """
    Presentation-only annotation layer for a multi-branch dispersion panel
    already drawn by `plot_dispersion_branches` on `ax`. Re-derives EXACTLY
    the same tracked segments and the same propagating/length/show rules
    `plot_dispersion_branches` uses to decide what is actually rendered (so
    a label can never point at a segment that was dropped from the plot).
    Its shared `_chain_dispersion_segments` helper is also used by the
    plotting function, ensuring that labels and the solid/dashed/dash-dot
    chain-member linestyles come from precisely the same grouping.
    No curve, point, color, or data value is added, removed, or moved by
    this function -- it only decides where to put small numbered reference
    tags on top of what is already drawn.

    Two honesty-preserving corrections are applied before numbering, both
    checked directly against the re-tracked data (never assumed):

      1. EXACT-DEGENERACY DEDUPLICATION: two tracked segments that overlap
         to within `dup_tol` in (k_r, Omega) at every sample are the same
         curve rendered twice (a genuine numerically-exact modal
         degeneracy -- e.g. two polarizations of the same acoustic branch
         that coincide for this geometry -- not a tracking artifact). Only
         the first is tagged; the exact duplicate is silently skipped so
         the reader never sees two overlapping circles for one visible
         line.
      2. BRAGG-GAP RECONNECTION: two segments, possibly from different
         internal tracked identities, that are adjacent in Omega with only
         a short intervening gap and whose facing endpoints are within
         `reconnect_kr_tol` of each other in k_r are the SAME physical
         branch reappearing on the far side of a real stop band (a genuine
         termination-then-restart at a Bragg gap, not two different
         branches). These are tagged with the same number and a letter
         suffix ("1", "1b", "1c", ...) instead of a new number, so the
         count of plain numbers reflects genuinely distinct dispersion
         relations rather than the tracker's internal bookkeeping.

    Returns the next unused label number.
    """
    chains = _chain_dispersion_segments(
        records, alpha_pass=alpha_pass, kr_min=kr_min, min_len=min_len,
        dup_tol=dup_tol, reconnect_kr_tol=reconnect_kr_tol,
        reconnect_om_tol=reconnect_om_tol,
    )

    # One number per physical chain; lettered sub-tags and plot linestyles
    # are both derived from this same shared chain/member ordering.
    n = start_n
    for chain in chains:
        for sub_idx, seg in enumerate(chain):
            xs, ys = seg["xs"], seg["ys"]
            k = int(round((len(xs) - 1) * frac))
            label_txt = f"{prefix}{n}" if sub_idx == 0 else f"{prefix}{n}{chr(ord('a') + sub_idx - 1)}"
            ax.annotate(
                label_txt, xy=(xs[k], ys[k]), xytext=offset,
                textcoords="offset points", fontsize=fontsize, color=txtcolor,
                fontweight="bold", ha="center", va="center",
                bbox=dict(boxstyle="circle,pad=0.15", fc="white", ec=txtcolor, lw=0.7, alpha=0.9),
                arrowprops=dict(arrowstyle="-", color=txtcolor, lw=0.6, alpha=0.8),
                zorder=5,
            )
        n += 1
    return n


def label_acoustic_branch(ax, pts, xkey, ykey, prefix="", start_n=1,
                           min_len=MIN_SEGMENT_LEN, fontsize=8, txtcolor="black",
                           frac=0.5, offset=(9, 9)):
    """
    Presentation-only annotation layer for the single already-extracted
    acoustic-branch trajectory `pts` (the same list `plot_acoustic_branch`
    draws), using that same function's own `_display`/`_hopped` decisions
    (via `_mark_display_flags`, already applied by `extract_acoustic_branch`)
    so a label is only ever placed on a segment that is actually rendered.
    Places one small numbered tag near the middle of each displayed
    contiguous segment. No data or curve is changed.
    """
    if not pts:
        return start_n
    xs = [float(r[xkey]) for r in pts]
    ys = [float(r[ykey]) for r in pts]
    n = start_n
    seg_start = 0
    boundaries = []
    for i in range(1, len(pts)):
        if pts[i].get("_hopped", False):
            boundaries.append((seg_start, i - 1))
            seg_start = i
    boundaries.append((seg_start, len(pts) - 1))
    for (i0, i1) in boundaries:
        length = i1 - i0 + 1
        kept = pts[i0].get("_display", length >= min_len)
        if not kept:
            continue
        k = i0 + int(round((i1 - i0) * frac))
        k = min(max(k, i0), i1)
        ax.annotate(
            f"{prefix}{n}", xy=(xs[k], ys[k]), xytext=offset,
            textcoords="offset points", fontsize=fontsize, color=txtcolor,
            fontweight="bold", ha="center", va="center",
            bbox=dict(boxstyle="circle,pad=0.15", fc="white", ec=txtcolor, lw=0.7, alpha=0.9),
            arrowprops=dict(arrowstyle="-", color=txtcolor, lw=0.6, alpha=0.8),
            zorder=5,
        )
        n += 1
    return n


def plot_acoustic_branch(ax, pts, xkey, ykey, semilog=False, floor=None,
                          label=None, min_len=MIN_SEGMENT_LEN,
                          diagnostics=None, **kwargs):
    """
    Plot the (single) `extract_acoustic_branch` trajectory `pts` as a
    genuinely continuous line, breaking the line at every point flagged
    `_hopped=True` (a real re-tracked discontinuity -- see
    `extract_acoustic_branch` / `retrack_branches`) instead of drawing a
    diagonal connector across it.

    PLOT FILTERING (distinct from the tracking already done to produce
    `pts`): `extract_acoustic_branch` already computed a `_display` flag
    per point via `_mark_display_flags` -- a run is displayed only if (a)
    it has at least `min_len` samples, and (b) if it is a purely
    evanescent run, it directly bridges two DISPLAYED propagating runs
    (the honest definition of "the physically appropriate evanescent
    continuation inside a Bragg gap"; a dangling or deep-stop-band-
    continuum evanescent fragment with no such bridge is not displayed).
    A `_display=False` point is DROPPED FROM THE RENDERED CURVE ONLY -- not
    deleted from `pts`/the underlying CSV -- and never drawn as a marker
    either. Every RETAINED point is still exactly the genuine extracted
    data; only a spurious connecting segment, or a filtered-out fragment,
    is omitted.

    If `diagnostics` (a list) is passed, one dict per segment (kept or
    dropped) is appended for the audit trail.
    """
    if not pts:
        return
    xs = [float(r[xkey]) for r in pts]
    ys_raw = [float(r[ykey]) for r in pts]
    ys = [max(y, floor) for y in ys_raw] if floor is not None else ys_raw
    plot_fn = ax.semilogy if semilog else ax.plot
    label_used = False

    def flush(i0, i1):
        """Plot or drop pts[i0:i1] (inclusive) as one segment."""
        nonlocal label_used
        n = i1 - i0 + 1
        # `_display` was already decided by `_mark_display_flags` for every
        # point in this (already-`_hopped`-delimited) run, so all points in
        # [i0, i1] share the same value; fall back to a plain length check
        # if `_display` is absent (e.g. `pts` built by a caller that did
        # not go through `extract_acoustic_branch`).
        kept = pts[i0].get("_display", n >= min_len)
        if kept:
            kw = dict(kwargs)
            if label and not label_used:
                kw["label"] = label
                label_used = True
            plot_fn(xs[i0:i1 + 1], ys[i0:i1 + 1], **kw)
        if diagnostics is not None:
            diagnostics.append({
                "n_points": n,
                "omega_range": (pts[i0]["Omega"], pts[i1]["Omega"]),
                "plotted": kept,
                "reason": ("kept: passes length + evanescent-bridging plot-filter rule" if kept
                           else f"dropped by plot-filter (see _mark_display_flags): "
                                f"length={n}, min_len={min_len}"),
            })

    seg_start = 0
    for i in range(1, len(xs)):
        if pts[i].get("_hopped", False):
            flush(seg_start, i - 1)
            seg_start = i
    flush(seg_start, len(xs) - 1)


def spike_runs(pts, threshold):
    """Contiguous [Omega_L, Omega_U, peak] runs along a branch where alpha > threshold."""
    runs = []
    in_run = False
    start = None
    peak = 0.0
    prev_om = None
    for p in pts:
        om = float(p["Omega"])
        if float(p["alpha_a"]) > threshold:
            if not in_run:
                in_run, start, peak = True, om, float(p["alpha_a"])
            else:
                peak = max(peak, float(p["alpha_a"]))
        else:
            if in_run:
                runs.append((round(start, 4), round(prev_om, 4), round(peak, 4)))
                in_run = False
        prev_om = om
    if in_run:
        runs.append((round(start, 4), round(prev_om, 4), round(peak, 4)))
    return runs
