#!/usr/bin/env python3
"""
Regenerates the audited and calibrated production figures corresponding to
manuscript Figures 4, 6, 8, 9, 11, 13 (script filenames fig2/4/6/7/9/10,
retained from earlier drafts; see README audit table for the fig-name ->
manuscript-number mapping) from the authoritative, FROZEN Phase 3B datasets
without rerunning the solver.

Branch-tracking revision (this pass): all per-branch curves are produced by
`branch_utils.extract_acoustic_branch` / `branch_utils.plot_dispersion_branches`
(rev.3, gated complex-plane continuity tracking -- see branch_utils.py for
the full root-cause analysis and fix description). No numerical value in
the frozen CSVs is read differently or altered; only which already-computed
points are judged to belong to the same physical branch, and where the
plotted line must genuinely break, has changed.

Internal "Figure N:" numbering has been removed from every plot title in
this script (see audit table) -- the official figure number is assigned
solely by the LaTeX \\caption/\\label in the manuscript, so it can never
drift out of sync with an internal hardcoded string again.
"""

import os
import sys
import csv
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from branch_utils import (extract_acoustic_branch, plot_dispersion_branches, plot_acoustic_branch,
                           label_dispersion_branches, label_acoustic_branch)
from figure_style import apply_journal_style

repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
# Phase-A: fall back to the packaged frozen datasets/figures when the full
# paper10 working tree is not present (self-contained package operation).
if os.path.isdir(os.path.join(repo_root, "paper10", "production", "results")):
    results_dir = os.path.join(repo_root, "paper10", "production", "results")
    figures_dir = os.path.join(repo_root, "paper10", "figures", "phase3b")
else:
    results_dir = os.path.join(repo_root, "04_PRODUCTION_DATA")
    figures_dir = os.path.join(repo_root, "02_FIGURES")
results_dir = os.path.normpath(os.path.abspath(results_dir))
figures_dir = os.path.normpath(os.path.abspath(figures_dir))


def main():
    apply_journal_style()

    # Load datasets
    with open(os.path.join(results_dir, "S1_results.csv")) as f:
        rec_s1 = list(csv.DictReader(f))
    with open(os.path.join(results_dir, "S3_results.csv")) as f:
        rec_s3 = list(csv.DictReader(f))
    with open(os.path.join(results_dir, "S5_results.csv")) as f:
        rec_s5 = list(csv.DictReader(f))
    with open(os.path.join(results_dir, "S6_results.csv")) as f:
        rec_s6 = list(csv.DictReader(f))

    # ------------------------------------------------------------------
    # manuscript Figure 4: Baseline Spatial Attenuation (Family S1)
    # ------------------------------------------------------------------
    #
    # The beta->0 conservative baseline is analytically exact-zero everywhere
    # outside the true Bragg gap (no dissipation mechanism whatsoever), so any
    # nonzero residual there is unambiguously numerical noise from the
    # structurally-singular 20x20 generalized eigenvalue pencil, not physics.
    # We floor ONLY that curve at CONS_FLOOR (comfortably below the real
    # Bragg-gap peak ~4.9, comfortably above all observed solver noise) and
    # leave the physically-dissipative DPL curve completely unmodified.
    # After the numerical-conditioning fix (equilibrated 20x20 pencil), the
    # true noise floor for this analytically exact-zero curve is ~1e-15
    # (genuine machine precision). A small display floor is still applied
    # purely so the log-scale curve renders as a flat line rather than a
    # jittery machine-epsilon scatter; it sits far below the real Bragg-gap
    # peak (~4.9) and far above the true floor.
    CONS_FLOOR = 1e-10
    fig, ax = plt.subplots(figsize=(7, 4.8))
    b_cons = extract_acoustic_branch([r for r in rec_s1 if r["case_id"] == "S1_cons"])
    b_dpl = extract_acoustic_branch([r for r in rec_s1 if r["case_id"] == "S1_dpl"])
    plot_acoustic_branch(ax, b_cons, "Omega", "alpha_a", semilog=True, floor=CONS_FLOOR,
                          color='b', ls='-', lw=2.0, label=r'Conservative Baseline ($\beta \to 0$)')
    plot_acoustic_branch(ax, b_dpl, "Omega", "alpha_a", semilog=True, floor=1e-8,
                          color='r', ls='--', lw=2.0, label='Active DPL Thermoelasticity')
    ax.set_xlabel(r'Normalized Frequency $\Omega = \omega a / (2\pi v_m)$')
    ax.set_ylabel(r'Spatial Attenuation Magnitude $\alpha a = |k_i a|$')
    ax.set_ylim(3e-11, 3e1)
    ax.grid(True, which="both", linestyle='--', alpha=0.6)
    ax.legend(loc='upper left', fontsize=9)
    ax.text(0.98, 0.03,
            r'Conservative curve floored at $10^{-10}$ purely for log-scale display'
            r' ($\beta \to 0$ gives exact-zero pass-band attenuation; the true'
            '\n' r'computed floor is machine precision, $\sim 10^{-15}$). DPL curve shown unmodified.',
            transform=ax.transAxes, fontsize=6.5, va='bottom', ha='right',
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.85, edgecolor='lightgray'))
    plt.tight_layout()
    plt.savefig(os.path.join(figures_dir, "fig2_baseline_attenuation.png"), dpi=300)
    plt.close()
    print("  ✓ manuscript Figure 4 (fig2_baseline_attenuation.png) regenerated.")

    # ------------------------------------------------------------------
    # manuscript Figure 6: Dipolar Gradient Length Sweep (Family S3)
    # *** THIS IS THE MOST IMPORTANT FIGURE FOR THIS CORRECTION PASS ***
    # ------------------------------------------------------------------
    # Previously rendered as unconnected scatter markers because the old
    # extract_acoustic_branch() heuristic hopped between unrelated modes too
    # often for a connected line to look sane. The rev.3 gated complex-plane
    # tracker (branch_utils.retrack_branches) eliminates that hopping (see
    # branch_utils.py docstring / README audit table for the measured
    # before/after jump statistics), so each branch is now drawn as a
    # genuine continuous line, broken only at a real re-tracked termination.
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.5), sharey=True)
    n1 = 1
    for cid, col, lbl in [("S3_d01", 'g', r'$d_1/a=0.1$'), ("S3_d05", 'b', r'$d_1/a=0.5$ (base)'), ("S3_d10", 'm', r'$d_1/a=1.0$')]:
        rows = [r for r in rec_s3 if r["case_id"] == cid]
        plot_dispersion_branches(ax1, rows, col, lw=2.0, label=lbl)
        n1 = label_dispersion_branches(ax1, rows, prefix="", start_n=n1, txtcolor=col, fontsize=7.5)
    ax1.set_title(r'(a) Micro-Inertia Variation ($d_1/a$)', fontsize=11)
    ax1.set_xlabel(r'$k_r a / \pi$')
    ax1.set_ylabel(r'Normalized Frequency $\Omega$')
    ax1.set_xlim([0.0, 1.0])
    ax1.grid(True, linestyle='--', alpha=0.6)
    ax1.legend(loc='lower right')

    n2 = 1
    for cid, col, lbl in [("S3_c01", 'c', r'$\sqrt{c_1}/a=0.1$'), ("S3_c05", 'b', r'$\sqrt{c_1}/a=0.5$ (base)'), ("S3_c08", 'r', r'$\sqrt{c_1}/a=0.8$')]:
        rows = [r for r in rec_s3 if r["case_id"] == cid]
        plot_dispersion_branches(ax2, rows, col, lw=2.0, label=lbl)
        n2 = label_dispersion_branches(ax2, rows, prefix="", start_n=n2, txtcolor=col, fontsize=7.5)
    ax2.set_title(r'(b) Micro-Stiffness Variation ($\sqrt{c_1}/a$)', fontsize=11)
    ax2.set_xlabel(r'$k_r a / \pi$')
    ax2.set_xlim([0.0, 1.0])
    ax2.grid(True, linestyle='--', alpha=0.6)
    ax2.legend(loc='lower right')

    plt.tight_layout()
    plt.savefig(os.path.join(figures_dir, "fig4_gradient_lengths.png"))
    plt.close()
    print("  ✓ manuscript Figure 6 (fig4_gradient_lengths.png) regenerated -- continuous tracked branches.")

    # ------------------------------------------------------------------
    # manuscript Figure 8: DPL Thermal-Lag Sweep (Family S5)
    # ------------------------------------------------------------------
    # All curves in this figure are genuinely active DPL cases (nonzero
    # thermoelastic coupling everywhere), so unlike Figure 4's conservative
    # limit they must NOT be floored at a level that could hide real reported
    # physics: the smallest reported pass-band mean in this sweep is
    # ~1.69e-5 (S5_tauq_1ps). ACTIVE_FLOOR is set two decades below that, so
    # every reported value stays exactly as computed and only the deepest,
    # clearly-spurious near-zero numerical nulls (down to ~1e-9, an artifact
    # of the same structurally-singular eigenvalue pencil discussed for
    # Figure 4) are suppressed for legibility. The curves are the rev.3
    # continuity-tracked acoustic branch -- their apparent sharpness (where
    # present) is the genuine Bragg-gap attenuation peak, not a tracking
    # artifact; peaks are neither broadened nor smoothed here.
    ACTIVE_FLOOR = 1e-7
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5), sharey=True)
    for cid, col, lbl in [("S5_tauq_1ps", 'g', r'$\tau_q = 1\ \mathrm{ps}$'),
                          ("S5_tauq_10ps", 'b', r'$\tau_q = 10\ \mathrm{ps}$ (base)'),
                          ("S5_tauq_1ns", 'r', r'$\tau_q = 1\ \mathrm{ns}$')]:
        c_pts = extract_acoustic_branch([r for r in rec_s5 if r["case_id"] == cid])
        plot_acoustic_branch(ax1, c_pts, "Omega", "alpha_a", semilog=True, floor=ACTIVE_FLOOR,
                              color=col, lw=2.0, label=lbl)
    ax1.set_title(r'(a) Heat Flux Relaxation Lag $\tau_q$', fontsize=11)
    ax1.set_xlabel(r'Normalized Frequency $\Omega$')
    ax1.set_ylabel(r'Spatial Attenuation Magnitude $\alpha a = |k_i a|$')
    ax1.set_ylim([5e-7, 1e1])
    ax1.grid(True, which="both", linestyle='--', alpha=0.6)
    ax1.legend(loc='lower right')

    for cid, col, lbl in [("S5_tauth_01ps", 'orange', r'$\tau_\theta = 0.1\ \mathrm{ps}$'),
                          ("S5_tauq_10ps", 'b', r'$\tau_\theta = 2.0\ \mathrm{ps}$ (base)'),
                          ("S5_tauth_100ps", 'purple', r'$\tau_\theta = 100\ \mathrm{ps}$')]:
        c_pts = extract_acoustic_branch([r for r in rec_s5 if r["case_id"] == cid])
        plot_acoustic_branch(ax2, c_pts, "Omega", "alpha_a", semilog=True, floor=ACTIVE_FLOOR,
                              color=col, lw=2.0, label=lbl)
    ax2.set_title(r'(b) Temperature Gradient Retardation Lag $\tau_\theta$', fontsize=11)
    ax2.set_xlabel(r'Normalized Frequency $\Omega$')
    ax2.grid(True, which="both", linestyle='--', alpha=0.6)
    ax2.legend(loc='upper left', fontsize=8)
    ax2.text(0.98, 0.02,
             r'Curves floored at $10^{-7}$ (below the smallest reported pass-band'
             '\nmean in this sweep, $1.43\\times10^{-6}$) to suppress residual solver-precision'
             '\nnulls; no reported value is affected.',
             transform=ax2.transAxes, fontsize=6.5, va='bottom', ha='right',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.85, edgecolor='lightgray'))

    plt.tight_layout()
    plt.savefig(os.path.join(figures_dir, "fig6_dpl_lags.png"))
    plt.close()
    print("  ✓ manuscript Figure 8 (fig6_dpl_lags.png) regenerated.")

    # ------------------------------------------------------------------
    # manuscript Figure 9: Thermoelastic Coupling Sweep (Family S6)
    # ------------------------------------------------------------------
    # S6_alpha00 is this sweep's own beta->0 conservative limit (same
    # geometry family as Figure 4's S1_cons), so it gets the identical
    # analytically-justified CONS_FLOOR treatment; the three genuinely active
    # curves (0.5/1.0/2.0 alpha_t) get the same ACTIVE_FLOOR used in Figure 8,
    # which sits two decades below their smallest reported mean. Panel (a)
    # now uses the rev.3 multi-branch continuous tracker (previously a
    # broken-segment workaround); panel (b) is the rev.3 tracked acoustic
    # branch's attenuation curve.
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.5))
    coup_cases = [("S6_alpha00", 'k', r'$\beta \to 0$ (Conservative)'),
                  ("S6_alpha05", 'g', r'$0.5 \alpha_{t,\mathrm{base}}$'),
                  ("S6_alpha10", 'b', r'$1.0 \alpha_{t,\mathrm{base}}$ (Active Baseline)'),
                  ("S6_alpha20", 'r', r'$2.0 \alpha_{t,\mathrm{base}}$ (Strong Coupling)')]
    n9 = 1
    for cid, col, lbl in coup_cases:
        s6_rows = [r for r in rec_s6 if r["case_id"] == cid]
        plot_dispersion_branches(ax1, s6_rows, col, lw=1.8, label=lbl)
        n9 = label_dispersion_branches(ax1, s6_rows, prefix="", start_n=n9, txtcolor=col, fontsize=7.5)
        c_pts = extract_acoustic_branch(s6_rows)
        floor = CONS_FLOOR if cid == "S6_alpha00" else ACTIVE_FLOOR
        plot_acoustic_branch(ax2, c_pts, "Omega", "alpha_a", semilog=True, floor=floor,
                              color=col, lw=1.8, label=lbl)

    ax1.set_title(r'(a) Dispersion Curve Modification', fontsize=11)
    ax1.set_xlabel(r'Real Bloch Wavenumber $k_r a / \pi$')
    ax1.set_ylabel(r'Normalized Frequency $\Omega$')
    ax1.set_xlim([0.0, 1.0])
    ax1.grid(True, linestyle='--', alpha=0.6)
    ax1.legend(loc='lower right', fontsize=7.5, framealpha=0.9)

    ax2.set_title(r'(b) Thermoelastic Attenuation Floor', fontsize=11)
    ax2.set_xlabel(r'Normalized Frequency $\Omega$')
    ax2.set_ylabel(r'Spatial Attenuation $\alpha a$')
    ax2.set_ylim([5e-7, 1e1])
    ax2.grid(True, which="both", linestyle='--', alpha=0.6)
    ax2.legend(loc='upper left', fontsize=8)
    ax2.text(0.98, 0.02,
             r'Conservative curve floored at $10^{-10}$ (exact-zero pass-band by construction);'
             '\nactive curves floored at $10^{-7}$ (below any reported mean). Neither floor'
             '\naffects a reported value.',
             transform=ax2.transAxes, fontsize=6, va='bottom', ha='right',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.85, edgecolor='lightgray'))

    plt.tight_layout()
    plt.savefig(os.path.join(figures_dir, "fig7_thermoelastic_coupling.png"))
    plt.close()
    print("  ✓ manuscript Figure 9 (fig7_thermoelastic_coupling.png) regenerated.")

    # ------------------------------------------------------------------
    # manuscript Figure 11: Band-Gap Summary Plot
    # ------------------------------------------------------------------
    # This is a PARAMETER-SUMMARY figure (3 discrete chi values, 3 discrete
    # eta values), not a dispersion curve, and is intentionally left as a
    # straight/piecewise representation of the actual production values --
    # per the correction brief, it must NOT be splined into a fictitious
    # smooth transition, since the manuscript explicitly describes
    # threshold-like gap-opening behaviour. No change from the previously
    # audited, already-corrected values (read directly from the frozen
    # PRODUCTION_BANDGAP_SUMMARY.csv-derived numbers used throughout the
    # manuscript); only the internal "Figure 9:" title string is removed.
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.5))
    chi_vals = [0.0, 0.5, 1.0]
    widths_chi = [0.0, 0.0, 0.0707]
    ax1.plot(chi_vals, widths_chi, 'bo-', lw=2, ms=6, label=r'Bragg Gap ($\eta=0.5$, DPL-active)')
    ax1.annotate('No gap for $\\chi < 1.0$', xy=(0.5, 0.0), xytext=(0.15, 0.12),
                 fontsize=8, color='navy',
                 arrowprops=dict(arrowstyle='->', color='navy', lw=1.0))
    ax1.set_xlabel(r'Material Contrast Parameter $\chi$')
    ax1.set_ylabel(r'Band-Gap Width $\Delta\Omega$')
    ax1.set_title('(a) Band-Gap Width vs Material Contrast', fontsize=11)
    ax1.set_ylim(0.0, 0.5)
    ax1.grid(True, linestyle='--', alpha=0.6)
    ax1.legend(loc='upper left', fontsize=8)

    eta_vals = [0.2, 0.5, 0.8]
    eta_widths = [0.4242, 0.0707, 0.1768]
    ax2.plot(eta_vals, eta_widths, 'rs-', lw=2, ms=6, label=r'Bragg Gap ($\chi=1.0$, DPL-active)')
    ax2.set_xlabel(r'Layer A Filling Fraction $\eta = a_1/a$')
    ax2.set_ylabel(r'Band-Gap Width $\Delta\Omega$')
    ax2.set_title(r'(b) Band-Gap Width vs Filling Fraction $\eta$ (at $\chi=1.0$)', fontsize=11)
    ax2.set_ylim(0.0, 0.5)
    ax2.grid(True, linestyle='--', alpha=0.6)
    ax2.legend(loc='upper right', fontsize=8)

    plt.tight_layout()
    plt.savefig(os.path.join(figures_dir, "fig9_bandgap_summary.png"))
    plt.close()
    print("  ✓ manuscript Figure 11 (fig9_bandgap_summary.png) regenerated (unchanged discrete values).")

    # ------------------------------------------------------------------
    # manuscript Figure 13: Compact Synthesis Map (Bragg vs Gradient vs DPL)
    # *** ALSO REQUIRED MAJOR CORRECTION ***
    # ------------------------------------------------------------------
    # All three mechanism curves now use the SAME rev.3 acoustic-branch
    # extraction criterion (branch_utils.extract_acoustic_branch), applied
    # consistently, removing the non-monotonic wiggle previously present in
    # the S1_cons ("Mechanism 1") curve near Omega ~ 0.95-1.05 (confirmed to
    # be a branch-identity artifact of the old min-alpha-in-window heuristic,
    # not a feature of the underlying production data).
    fig, ax = plt.subplots(figsize=(8, 5))
    c_s1_cons = extract_acoustic_branch([r for r in rec_s1 if r["case_id"] == "S1_cons"])
    c_s3_class = extract_acoustic_branch([r for r in rec_s3 if r["case_id"] == "S3_classical"])
    c_s1_dpl = extract_acoustic_branch([r for r in rec_s1 if r["case_id"] == "S1_dpl"])

    plot_acoustic_branch(ax, c_s1_cons, "kr_a_over_pi", "Omega", color='b', ls='-', lw=2.2,
                         label=r'Mechanism 1: Pure Bragg Scattering ($\beta \to 0$, Gradient Elastic)')
    plot_acoustic_branch(ax, c_s3_class, "kr_a_over_pi", "Omega", color='k', ls='--', lw=2.0,
                         label=r'Mechanism 2: Classical thermoelastic limit ($c, d \to 0$)')
    plot_acoustic_branch(ax, c_s1_dpl, "kr_a_over_pi", "Omega", color='r', ls='-.', lw=2.2,
                         label=r'Mechanism 3: Full Coupled DPL + Dipolar Gradient Metamaterial')
    # Window-numbering annotation on the Mechanism-2 (classical-limit)
    # curve only (presentation only, see branch_utils.label_acoustic_branch):
    # tags each of its 5 genuinely propagating windows "W1".."W5" in Omega
    # order, so the reader can see at a glance that the curve is 5
    # deliberately separated propagating windows of ONE physical case, not
    # a broken or unreliable tracking result. Mechanisms 1 and 3 are each a
    # single unbroken curve and are already identified by the legend, so
    # they are not additionally numbered.
    label_acoustic_branch(ax, c_s3_class, "kr_a_over_pi", "Omega", prefix="W", start_n=1,
                           txtcolor='k', fontsize=7.5, offset=(0, 11))

    ax.set_xlabel(r'Real Bloch Wavenumber $k_r a / \pi$', fontsize=11)
    ax.set_ylabel(r'Normalized Frequency $\Omega = \omega a / (2\pi v_m)$', fontsize=11)
    ax.set_xlim([0.0, 1.0])
    ax.grid(True, linestyle='--', alpha=0.6)
    ax.legend(loc='lower right', framealpha=0.95, fontsize=8.5)
    plt.tight_layout()
    plt.savefig(os.path.join(figures_dir, "fig10_synthesis_map.png"))
    plt.close()
    print("  ✓ manuscript Figure 13 (fig10_synthesis_map.png) regenerated -- wiggle eliminated.")


if __name__ == "__main__":
    main()
