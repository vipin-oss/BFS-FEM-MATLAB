#!/usr/bin/env python3
"""
Phase-A / rev.3 Figure Regeneration (dispersion diagrams)
==========================================================
Regenerates the multi-branch dispersion figures (fig1_baseline_dispersion =
manuscript Fig. 3, fig3_material_contrast = manuscript Fig. 5,
fig5_filling_fraction = manuscript Fig. 7, fig8_combined_interaction =
manuscript Fig. 10) from the FROZEN production datasets.

Revision history:
  rev.1/2 (Phase-A): each mode plotted as an individual point, colored by a
    per-row propagating/evanescent classification. This removed a specific
    earlier defect (evanescent zone-centre modes overplotted on propagating
    branches) but left every branch as a "point cloud" rather than a
    connected curve, which is not an acceptable presentation for a
    publication-quality dispersion diagram.
  rev.3 (this pass): each branch is re-tracked with
    `branch_utils.retrack_branches` (gated complex-plane nearest-neighbour
    continuity -- both the real AND imaginary parts of the Bloch
    wavenumber are used, with an adaptive per-case distance gate that
    rejects a match too large to be a genuine continuation) and drawn as a
    genuine continuous line via `branch_utils.plot_dispersion_branches`:
    solid colored line where the branch is propagating, thin faint grey
    line where it is evanescent/complex-wavenumber, and a small marker only
    for a point that re-tracking could not connect to anything (a
    genuinely isolated sample). No solver re-run is performed and no row of
    the frozen CSVs is altered; only which already-computed points are
    judged to be the same physical branch, and where the line must
    genuinely break, has changed.
"""

import os
import sys
import csv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from branch_utils import plot_dispersion_branches, label_dispersion_branches
from figure_style import apply_journal_style

HERE = os.path.abspath(os.path.dirname(__file__))
PKG = os.path.abspath(os.path.join(HERE, "..", ".."))
DATA = os.path.join(PKG, "04_PRODUCTION_DATA")
FIGS = os.path.join(PKG, "02_FIGURES")

apply_journal_style()
plt.rcParams.update({"legend.fontsize": 8})


def load(fname):
    with open(os.path.join(DATA, fname)) as f:
        return list(csv.DictReader(f))


def add_legend(ax, color):
    ax.plot([], [], "-", color=color, lw=2.0, label="propagating branch")
    ax.plot([], [], "-", color="0.75", lw=1.0, label="evanescent / complex-$k$")
    ax.legend(loc="upper left", fontsize=8, frameon=False)


def main():
    rec_s1 = load("S1_results.csv")
    rec_s2 = load("S2_results.csv")
    rec_s4 = load("S4_results.csv")
    rec_s7 = load("S7_results.csv")
    print("Frozen CSVs loaded.")

    # ---- Figure 1 (manuscript Fig. 3): baseline dispersion, S1 --------------
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.5), sharey=True)
    # This is the one figure whose caption/text explicitly claims to show
    # evanescent-mode classification, so (only here) evanescent segments
    # are rendered, in faint grey, subject to the same MIN_SEGMENT_LEN
    # filter as every other segment.
    plot_dispersion_branches(ax1, [r for r in rec_s1 if r["case_id"] == "S1_cons"], "b", lw=2.0, show_evanescent=True)
    plot_dispersion_branches(ax2, [r for r in rec_s1 if r["case_id"] == "S1_dpl"], "r", lw=2.0, show_evanescent=True)
    # Branch-numbering annotation (presentation only -- see branch_utils.
    # label_dispersion_branches docstring): one small numbered tag per
    # rendered propagating branch, so the reader can immediately see how
    # many genuine physical branches make up each panel (answers "why does
    # this look like 4 curves" -- it is 2 branches, each folding back at
    # the zone boundary into what looks like 2 line segments).
    label_dispersion_branches(ax1, [r for r in rec_s1 if r["case_id"] == "S1_cons"],
                               prefix="", start_n=1, txtcolor="b", fontsize=8)
    label_dispersion_branches(ax2, [r for r in rec_s1 if r["case_id"] == "S1_dpl"],
                               prefix="", start_n=1, txtcolor="r", fontsize=8)
    add_legend(ax1, "b")
    add_legend(ax2, "r")
    ax1.set_title(r"(a) Conservative Baseline ($\beta \to 0$)", fontsize=11)
    ax1.set_xlabel(r"Real Bloch Wavenumber $k_r a / \pi$")
    ax1.set_ylabel(r"Normalized Frequency $\Omega = \omega a / (2\pi v_m)$")
    ax1.set_xlim([0.0, 1.0])
    ax1.grid(True, linestyle="--", alpha=0.6)
    ax2.set_title("(b) Active DPL Thermoelastic Baseline", fontsize=11)
    ax2.set_xlabel(r"Real Bloch Wavenumber $k_r a / \pi$")
    ax2.set_xlim([0.0, 1.0])
    ax2.grid(True, linestyle="--", alpha=0.6)
    fig.suptitle("Baseline Bloch Dispersion across the First Brillouin Zone "
                 "(propagating vs. evanescent modes classified)", fontsize=12)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGS, "fig1_baseline_dispersion.png"))
    plt.close(fig)
    print("  saved fig1_baseline_dispersion.png")

    # ---- Figure 3 (manuscript Fig. 5): material contrast, S2 ----------------
    fig, axes = plt.subplots(1, 3, figsize=(12, 4), sharey=True)
    for (cid, title, ax) in [
        ("S2_chi00_cons", r"(a) Identical Layers ($\chi=0.0$)", axes[0]),
        ("S2_chi05_cons", r"(b) Intermediate Contrast ($\chi=0.5$)", axes[1]),
        ("S2_chi10_cons", r"(c) Full Contrast ($\chi=1.0$)", axes[2]),
    ]:
        plot_dispersion_branches(ax, [r for r in rec_s2 if r["case_id"] == cid], "k", lw=2.0)
        ax.set_title(title, fontsize=10)
        ax.set_xlabel(r"$k_r a / \pi$")
        ax.set_xlim([0.0, 1.0])
        ax.grid(True, linestyle="--", alpha=0.6)
    axes[0].set_ylabel(r"Normalized Frequency $\Omega$")
    fig.suptitle("Material Contrast Sweep — Emergence and Evolution of Bragg Band Gaps", fontsize=12)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGS, "fig3_material_contrast.png"))
    plt.close(fig)
    print("  saved fig3_material_contrast.png")

    # ---- Figure 5 (manuscript Fig. 7): filling fraction, S4 -----------------
    fig, axes = plt.subplots(1, 3, figsize=(12, 4), sharey=True)
    for (cid, title, ax) in [
        ("S4_eta02_cons", r"(a) Asymmetric Thin ($\eta=0.2$)", axes[0]),
        ("S4_eta05_cons", r"(b) Symmetric Baseline ($\eta=0.5$)", axes[1]),
        ("S4_eta08_cons", r"(c) Asymmetric Thick ($\eta=0.8$)", axes[2]),
    ]:
        plot_dispersion_branches(ax, [r for r in rec_s4 if r["case_id"] == cid], "b", lw=2.0)
        ax.set_title(title, fontsize=10)
        ax.set_xlabel(r"$k_r a / \pi$")
        ax.set_xlim([0.0, 1.0])
        ax.grid(True, linestyle="--", alpha=0.6)
    axes[0].set_ylabel(r"Normalized Frequency $\Omega$")
    fig.suptitle(r"Layer Thickness Ratio ($\eta = a_1/a$) Effect on Bragg Band-Edge Frequencies", fontsize=12)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGS, "fig5_filling_fraction.png"))
    plt.close(fig)
    print("  saved fig5_filling_fraction.png")

    # ---- Figure 8 (manuscript Fig. 10): factorial interaction, S7 -----------
    fig, axes = plt.subplots(2, 3, figsize=(13, 7.5), sharex=True, sharey=True)
    s7_cases = [
        ("S7_case1", "Case I: Pure Mechanical Bragg", "b"),
        ("S7_case2", "Case II: Active DPL Baseline", "r"),
        ("S7_case3", "Case III: Low Gradient + DPL", "g"),
        ("S7_case4", "Case IV: High Gradient + DPL", "m"),
        ("S7_case5", "Case V: Asymmetric Geometry + DPL", "orange"),
        ("S7_case6", "Case VI: High Thermal Lag + DPL", "purple"),
    ]
    for (cid, title, col), ax in zip(s7_cases, axes.flatten()):
        case_rows = [r for r in rec_s7 if r["case_id"] == cid]
        plot_dispersion_branches(ax, case_rows, col, lw=1.8)
        label_dispersion_branches(ax, case_rows, prefix="", start_n=1, txtcolor=col, fontsize=7.5)
        ax.set_title(title, fontsize=10)
        ax.set_xlim([0.0, 1.0])
        ax.grid(True, linestyle="--", alpha=0.6)
    axes[0, 0].set_ylabel(r"Normalized Frequency $\Omega$")
    axes[1, 0].set_ylabel(r"Normalized Frequency $\Omega$")
    for ax in axes[1, :]:
        ax.set_xlabel(r"Real Bloch Wavenumber $k_r a / \pi$")
    fig.suptitle("Combined Parameter Interaction — Factorial Comparison "
                 "(propagating vs. evanescent modes classified)", fontsize=12)
    fig.tight_layout()
    fig.savefig(os.path.join(FIGS, "fig8_combined_interaction.png"))
    plt.close(fig)
    print("  saved fig8_combined_interaction.png")


if __name__ == "__main__":
    main()
