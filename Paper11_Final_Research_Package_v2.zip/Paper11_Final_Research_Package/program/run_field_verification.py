"""
run_field_verification.py - Field-level and asymmetric boundary-condition
verification for Paper 11 (Guyer-Krumhansl heat-loss invariance).

This script exists to replace the qualitative claim of "zero residual
everywhere" with an honestly quantified one. It computes, independently
of run_validation.py and run_heatloss_study.py:

  1. The EXACT analytical difference (continuous Laplace domain, de Hoog
     inversion at 25-digit precision) between the Guyer-Krumhansl field at
     resonance (B = 1) and the classical Fourier field, at five spatial
     locations x in {0, 0.25, 0.5, 0.75, 1} and three asymmetric Biot pairs.
     This difference is the analytical content of Theorem 1 and is expected
     to vanish at (near-)machine precision.

  2. The discretization residual between the time-domain PDE solver and the
     same continuous Laplace solution, at the SAME interior points, evaluated
     on a mesh-refinement sequence Nx in {100, 200, 400, 800}. Interior grid
     points do not coincide with mesh nodes for finite Nx, so a point value
     is recovered by linear interpolation between the two nearest staggered
     cell centers. This residual is a discretization/interpolation artifact,
     NOT a violation of Theorem 1, and it must shrink under refinement. This
     is exactly the distinction the manuscript draws between "confirmed
     analytically to machine precision" (item 1) and "resolved numerically
     to a mesh-dependent tolerance" (item 2).

Outputs:
  - ../data/field_invariance_asymmetric.csv   (item 1)
  - ../data/interior_point_mesh_refinement.csv (item 2)
"""

import os
import sys
import numpy as np
import mpmath as mp
import pandas as pd
from scipy.integrate import solve_ivp

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

mp.mp.dps = 25


def transfer_function_field(x, s, tau_q, kappa2, Bi0, BiL, tau_Delta=0.04, pulse_type="raised_cosine"):
    """Closed-form Laplace-domain temperature at interior location x."""
    s = mp.mpc(s)
    m = mp.sqrt(s * (1.0 + tau_q * s) / (1.0 + kappa2 * s))
    mu = (1.0 + kappa2 * s) / (1.0 + tau_q * s)
    m_mu = m * mu
    Delta = (m_mu ** 2 + Bi0 * BiL) * mp.sinh(m) + m_mu * (Bi0 + BiL) * mp.cosh(m)

    if pulse_type == "raised_cosine":
        omega = 2.0 * mp.pi / tau_Delta
        q_s = (omega ** 2 / (s * (s ** 2 + omega ** 2))) * (1.0 - mp.exp(-s * tau_Delta))
    elif pulse_type == "square":
        q_s = (1.0 / s) * (1.0 - mp.exp(-s * tau_Delta))
    else:
        raise ValueError("Unknown pulse type")

    numerator = m_mu * mp.cosh(m * (1.0 - x)) + BiL * mp.sinh(m * (1.0 - x))
    return (numerator / (tau_Delta * Delta)) * q_s


def invert_field(x, t_array, tau_q, kappa2, Bi0, BiL, tau_Delta=0.04):
    return np.array([
        float(mp.invertlaplace(
            lambda s: transfer_function_field(x, s, tau_q, kappa2, Bi0, BiL, tau_Delta),
            t, method="dehoog", degree=20))
        for t in t_array
    ])


def solve_pde_full_field(Nx, tau_q, kappa2, Bi0, BiL, tau_Delta=0.04, t_eval=None):
    """Returns (t_eval, cell_centers, T_grid[Nx, Nt])."""
    if t_eval is None:
        t_eval = np.linspace(0.05, 1.0, 20)
    dx = 1.0 / Nx

    def q_pulse(t):
        if 0.0 < t <= tau_Delta:
            return 1.0 - np.cos(2.0 * np.pi * t / tau_Delta)
        return 0.0

    def rhs(t, y):
        T = y[:Nx]
        q_int = y[Nx:]
        T0 = 1.5 * T[0] - 0.5 * T[1]
        T1 = 1.5 * T[Nx - 1] - 0.5 * T[Nx - 2]
        q_front = q_pulse(t) - tau_Delta * Bi0 * T0
        q_rear = tau_Delta * BiL * T1
        q = np.empty(Nx + 1)
        q[0] = q_front
        q[1:Nx] = q_int
        q[Nx] = q_rear
        dTdt = -(q[1:] - q[:-1]) / (tau_Delta * dx)
        dTdx = (T[1:] - T[:-1]) / dx
        d2qdx2 = (q[2:] - 2.0 * q[1:Nx] + q[:-2]) / (dx ** 2)
        dqdt = (-q_int - tau_Delta * dTdx + kappa2 * d2qdx2) / tau_q
        return np.concatenate([dTdt, dqdt])

    y0 = np.zeros(2 * Nx - 1)
    sol = solve_ivp(rhs, (0.0, float(t_eval[-1])), y0, method="BDF",
                     t_eval=t_eval, rtol=1e-10, atol=1e-12)
    if not sol.success:
        raise RuntimeError(sol.message)
    T_grid = sol.y[:Nx, :]
    cell_centers = (np.arange(Nx) + 0.5) * dx
    return t_eval, cell_centers, T_grid


def interp_point(x_target, cell_centers, T_grid):
    """Linear interpolation onto x_target from staggered cell-center data,
    including one-sided second-order extrapolation to the two physical
    boundaries (consistent with the solver's own boundary closure)."""
    Nx = len(cell_centers)
    dx = cell_centers[1] - cell_centers[0]
    if x_target <= 0.0:
        return 1.5 * T_grid[0, :] - 0.5 * T_grid[1, :]
    if x_target >= 1.0:
        return 1.5 * T_grid[-1, :] - 0.5 * T_grid[-2, :]
    idx = np.clip(int(np.floor((x_target - cell_centers[0]) / dx)), 0, Nx - 2)
    x0, x1 = cell_centers[idx], cell_centers[idx + 1]
    w = (x_target - x0) / (x1 - x0)
    return (1.0 - w) * T_grid[idx, :] + w * T_grid[idx + 1, :]


def run_analytic_field_invariance():
    print("=" * 70)
    print("1. ANALYTICAL FIELD-LEVEL INVARIANCE (CONTINUOUS LAPLACE DOMAIN)")
    print("=" * 70)
    tau_q, kappa2 = 0.02, 0.02  # B = kappa2/(alpha0*tau_q) = 1 exactly
    asym_pairs = [(0.01, 0.10), (0.05, 0.20), (0.10, 0.50)]
    x_points = [0.0, 0.25, 0.50, 0.75, 1.0]
    t_test = np.array([0.10, 0.30, 0.60, 0.90])

    rows = []
    for Bi0, BiL in asym_pairs:
        for x in x_points:
            T_gk = invert_field(x, t_test, tau_q, kappa2, Bi0, BiL)
            T_fo = invert_field(x, t_test, 0.0, 0.0, Bi0, BiL)
            diff = np.max(np.abs(T_gk - T_fo))
            rows.append({"Bi0": Bi0, "BiL": BiL, "x": x,
                         "max_abs_diff_GK_minus_Fourier": diff})
            print(f"  Bi0={Bi0:.2f} BiL={BiL:.2f} x={x:.2f} | "
                  f"max|GK-Fourier| = {diff:.3e}")

    df = pd.DataFrame(rows)
    out = os.path.join(DATA_DIR, "field_invariance_asymmetric.csv")
    df.to_csv(out, index=False)
    print(f"  Saved: {out}\n")
    return df


def run_interior_point_mesh_refinement():
    print("=" * 70)
    print("2. INTERIOR-POINT PDE-vs-LAPLACE RESIDUAL UNDER MESH REFINEMENT")
    print("=" * 70)
    tau_q, kappa2 = 0.02, 0.02
    Bi0, BiL = 0.05, 0.20
    x_points = [0.0, 0.25, 0.50, 0.75, 1.0]
    t_test = np.array([0.10, 0.30, 0.60, 0.90])
    nx_list = [100, 200, 400, 800]

    T_lap = {x: invert_field(x, t_test, tau_q, kappa2, Bi0, BiL) for x in x_points}

    rows = []
    for Nx in nx_list:
        print(f"  Solving PDE at Nx = {Nx} ...", end=" ", flush=True)
        _, centers, T_grid = solve_pde_full_field(Nx, tau_q, kappa2, Bi0, BiL, t_eval=t_test)
        print("done.")
        for x in x_points:
            T_pde = interp_point(x, centers, T_grid)
            resid = np.max(np.abs(T_pde - T_lap[x]))
            rows.append({"Nx": Nx, "dx": 1.0 / Nx, "x": x,
                         "max_abs_residual_PDE_minus_Laplace": resid})
            print(f"    x = {x:.2f} | residual = {resid:.3e}")

    df = pd.DataFrame(rows)
    out = os.path.join(DATA_DIR, "interior_point_mesh_refinement.csv")
    df.to_csv(out, index=False)
    print(f"  Saved: {out}\n")

    # Observed order of convergence at the worst-case interior point (x=0.5)
    sub = df[df["x"] == 0.5].sort_values("Nx")
    errs = sub["max_abs_residual_PDE_minus_Laplace"].values
    orders = np.log2(errs[:-1] / errs[1:])
    print(f"  Observed convergence order at x=0.5 across refinements: "
          f"{np.round(orders, 3)}")
    return df


if __name__ == "__main__":
    run_analytic_field_invariance()
    run_interior_point_mesh_refinement()
    print("Field-level verification complete.")
