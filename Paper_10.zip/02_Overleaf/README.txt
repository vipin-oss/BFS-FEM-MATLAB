Paper 10 -- Overleaf-ready manuscript folder
=============================================

This folder is self-contained and directly uploadable to Overleaf (or any
local TeX Live install) as-is: no other folder in this package is required
to compile it.

Contents
--------
Paper10_Final.tex      Main LaTeX source (compile this file).
Paper10_Final.pdf      Reference copy of the already-compiled output, for
                        comparison against what you compile yourself.
references.bib         BibTeX bibliography database.
manifest_table.tex     \input by the main file: the Appendix Table A.1
                        (36-case manifest) longtable source.
elsarticle.cls         Elsevier article document class (bundled so no
elsarticle-num.bst     separate install is required).
figures/                All 13 manuscript figures (FigNN_description.png),
                        exactly matching the \includegraphics filenames used
                        in Paper10_Final.tex.

How to compile
---------------
Upload this entire folder to a new Overleaf project (or, locally):

    pdflatex Paper10_Final.tex
    bibtex   Paper10_Final
    pdflatex Paper10_Final.tex
    pdflatex Paper10_Final.tex

Verification performed before packaging
-----------------------------------------
This exact folder was compiled standalone, from a freshly extracted /
isolated copy containing nothing else, using the four-pass sequence above:
0 errors, 0 undefined references, 0 multiply-defined labels, 0 missing-figure
warnings, 0 "??" markers, 30 pages. The resulting PDF text (via pdftotext)
is byte-identical to Paper10_Final.pdf shipped in this folder and to the
copy in ../01_Manuscript/.

No absolute local file paths (e.g. C:\Users\..., /home/..., /tmp/...) and no
references to any file outside this folder are present anywhere in
Paper10_Final.tex.

Figures 8 and 12 are 3D renderings (a waterfall plot and a surface plot,
respectively) generated from the same frozen numerical data as the rest of
the figure set; see ../05_Figures_Source/README.md and
../03_Program/README.md for the generating scripts.
