# Paper 10 — Program (Source Code)

Source code used to generate the numerical results, tables, and figures reported in
*Dual-Phase-Lag (DPL) Thermoelastic Band-Gap Tuning and Acoustic Dissipation in 1D Periodic
Metamaterials with Dipolar Gradient Elasticity* (Vipin Gupta, Gurugram University).

This folder contains the actual scripts used to produce the reported results — nothing here
is a placeholder or a stand-in. Scripts that could not be located or verified against the
manuscript's reported numbers are not included, and this README does not claim reproducibility
for anything it does not actually contain.

## 1. Environment requirements

- Python 3.11 (developed and run under Python 3.11.2)
- Packages: see `requirements.txt` (numpy 2.4.6, scipy 1.17.1, matplotlib 3.11.2)

Install with:
```
pip install -r requirements.txt
```

## 2. Folder contents

```
transfer_matrix/
    coupled10.py      - 10-state coupled (in-plane) transfer-matrix / generalized
                         interface eigenvalue solver (the core solver used for all
                         S1-S7 production cases and the chi-eta supplementary grid)
    antiplane.py       - independent 4-state anti-plane shear reduction (Eq. 19 of the
                         manuscript; theoretically derived, NOT run in the production
                         campaign itself — see manuscript Section 3.4 / Limitations)
    parameters.py       - MaterialParameters dataclass and baseline Layer A / Layer B
                         parameter definitions (Table 2 of the manuscript)

production/
    run_pilot_sweep.py            - Phase 3A diagnostic pilot sweep (6 representative
                                     cases; numerical-stability/branch-continuity checks
                                     run before the full production sweeps)
    run_phase3b_production.py     - Phase 3B production runner: executes all 36 S1-S7
                                     production cases against
                                     ../04_Data/PHASE3_PARAMETER_MATRIX.json
                                     and writes S1_results.csv/json ... S7_results.csv/json,
                                     PRODUCTION_BANDGAP_SUMMARY.csv, and
                                     PRODUCTION_ATTENUATION_SUMMARY.csv (see 04_Data/)
    run_chi_eta_grid.py            - supplementary 2-D (chi, eta) grid sweep (121 DPL-active
                                     cases) used for Fig12_parameter_map.png; writes
                                     SUPP_CHI_ETA_GAP_SUMMARY.csv / SUPP_CHI_ETA_CASE_METRICS.csv
    branch_utils.py                 - shared branch-tracking / reconnection-chaining utilities
                                     used by every dispersion-diagram figure script
    figure_style.py                 - shared matplotlib style/rcParams used by the figure
                                     scripts, for visual consistency across figures
    make_phase0_figures.py          - generates:
                                         Fig01_unit_cell.png            (make_schematic)
                                         Fig02_validation.png            (make_pb_overlay)
                                         a 2D chi-eta heatmap (make_heatmap, from
                                         run_chi_eta_grid.py's output) -- kept for
                                         provenance/comparison but NO LONGER the manuscript's
                                         Fig12 (see make_3d_supplementary_figures.py below)
    regenerate_phaseA_figures.py    - generates the multi-branch dispersion figures:
                                         Fig03_baseline_dispersion.png
                                         Fig05_material_contrast.png
                                         Fig07_filling_fraction.png
                                         Fig10_combined_interaction.png
    regenerate_calibrated_figures.py - generates the remaining calibrated production figures:
                                         Fig04_baseline_attenuation.png
                                         Fig06_gradient_length_scales.png
                                         a 2D two-panel DPL-lags line plot -- kept for
                                         provenance/comparison but NO LONGER the manuscript's
                                         Fig08 (see make_3d_supplementary_figures.py below)
                                         Fig09_thermoelastic_coupling.png
                                         Fig11_gap_summary.png
                                         Fig13_scientific_synthesis.png
    make_3d_supplementary_figures.py - generates the manuscript's CURRENT Fig08 and Fig12
                                         (3D renderings of the same frozen data used by the
                                         2D scripts above). Raw script output filenames are
                                         renamed to the manuscript convention (as with the
                                         other figure scripts above; see Section 5):
                                         Fig_S2_dpl_lag_waterfall_3D.png -> Fig08_DPL_lags.png
                                                               (make_dpl_waterfall_3d;
                                                                reuses branch_utils.
                                                                extract_acoustic_branch
                                                                unchanged, so the 3D curves
                                                                cannot disagree with the 2D
                                                                version)
                                         Fig_S1_chi_eta_surface_3D.png -> Fig12_parameter_map.png
                                                               (make_chi_eta_surface_3d;
                                                                    same SUPP_CHI_ETA_*.csv
                                                                    inputs as the 2D heatmap)
    audit_branch_figures.py         - independent branch-tracking / plot-filtering audit for
                                       every dispersion-type figure (Figs. 3, 5, 6, 7, 9(a),
                                       10, 13); reports, per case, how many raw modal points,
                                       re-tracked branch segments, and displayed-vs-dropped
                                       segments there are, and checks that every rendered
                                       segment respects its case's own adaptive continuity gate

validation/
    run_benchmarks.py               - runs the Papargyri-Beskou et al. (2009) gradient
                                       dispersion benchmark and the classical acoustic
                                       elastic-limit check; writes
                                       benchmark_papargyri_beskou_results.csv/json (see
                                       06_Validation/)
    run_periodic_pilot.py           - runs the periodic conservative two-layer pilot
                                       (Li et al. 2016 classical Bragg-gap comparison);
                                       writes periodic_pilot_results.json
    validate_benchmark_acta.py       - standalone secular-determinant / classical-limit
                                       validation routine used during development of the
                                       benchmark checks above

utilities/
    test_coupled10.py, test_antiplane.py, test_parameters.py
                                     - unit tests for the solver modules

analytical/
    PHASE1_DERIVATION.md, PHASE1_SYMBOL_TABLE.md
                                     - hand-derivation notes and symbol table for the
                                       governing equations (Section 2 of the manuscript)
```

## 3. How to run the validation

```
cd validation
python3 run_benchmarks.py        # Papargyri-Beskou (2009) + classical elastic-limit checks
python3 run_periodic_pilot.py    # Li et al. (2016) classical Bragg-gap comparison
```
Outputs are written alongside the scripts by default; the copies used for the manuscript's
reported values are archived in `06_Validation/` of this package.

## 4. How to reproduce the production cases

```
cd production
python3 run_pilot_sweep.py         # optional diagnostic pilot (6 cases)
python3 run_phase3b_production.py  # full 36-case S1-S7 production campaign
python3 run_chi_eta_grid.py        # supplementary (chi, eta) grid (121 cases)
```
These scripts import the solver from `../transfer_matrix/`; run them from within the
`production/` directory (or add the package root to `PYTHONPATH`) so that import resolves.

## 5. How to regenerate the figures

```
cd production
python3 make_phase0_figures.py             # Fig01, Fig02, + a 2D chi-eta heatmap (superseded)
python3 regenerate_phaseA_figures.py       # Fig03, Fig05, Fig07, Fig10
python3 regenerate_calibrated_figures.py   # Fig04, Fig06, Fig09, Fig11, Fig13, + a 2D
                                            # DPL-lags plot (superseded)
python3 make_3d_supplementary_figures.py   # Fig08, Fig12 (current 3D versions)
python3 audit_branch_figures.py            # independent branch-tracking audit (all
                                            # dispersion-type figures)
```
Figure output paths are set inside each script (see the `FIG_DIR`/`figures_dir` variables at
the top of each file); the copies used in the manuscript are archived in `05_Figures_Source/`
and `02_Overleaf/figures/` of this package under the renamed `FigNN_*.png` convention.

## 6. Where generated CSV/JSON files are written

By default, each script writes into the production data directory it is configured for
(see the `OUT_DIR` / path variables near the top of each script). The exact files used for
the manuscript's reported numbers are archived, unmodified, in `04_Data/` of this package.

## 7. Which data files correspond to Table 3 and Appendix Table A.1

- **Table 3** (extracted Bragg band-gap summary): `04_Data/PRODUCTION_BANDGAP_SUMMARY.csv`
- **Appendix Table A.1** (complete 36-case manifest): the case-identifying columns of
  `04_Data/S1_results.csv` through `04_Data/S7_results.csv` (one row per family; see
  `04_Data/DATA_DICTIONARY.md` for column definitions)

## 8. Limitations

- The production campaign uses a native, uniform 100-point frequency grid
  (Omega in [0.05, 1.80], step approx. 0.0177); band-gap edges reported in Table 3 and
  Appendix Table A.1 are native-grid estimates, not sub-grid root-refined values.
- Four band-gap records are boundary-truncated at the frequency ceiling
  (Omega = 1.80): `S3_d10`, `S4_eta08_cons`, `S4_eta08_dpl`, `S7_case4`.
- Two Family S5 cases (`S5_tauq_1ps`, `S5_tauth_100ps`) fall outside the DPL
  thermodynamic admissibility condition tau_q >= tau_theta; they are retained as points
  in a formal mathematical parameter sweep (see manuscript Section 7, item 7), not as
  claims of thermodynamically admissible physical operating states.
- No independently published closed-form DPL/thermoelastic dispersion relation for a
  layered medium was identified; the coupled DPL thermoelastic channel is checked only
  by internal self-consistency diagnostics (manuscript Section 3.6), not against an
  external published benchmark. This is disclosed as an open limitation, not claimed as
  resolved.
- This package does not claim complete, one-command, push-button reproduction: running
  the scripts above reproduces the reported numerical campaign, but exact runtime and
  intermediate console output were not independently re-captured for every script in this
  package beyond the audit and validation scripts specifically re-run to verify this
  submission.
