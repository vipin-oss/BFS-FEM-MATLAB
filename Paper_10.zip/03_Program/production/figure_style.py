"""
Shared journal (Q1/SCI) presentation styling for every regenerated figure.

Renders all figure text (axis labels, tick numbers, titles, legends, and
the branch-numbering annotations added in this pass) through the actual
LaTeX engine (`matplotlib.rcParams["text.usetex"] = True`) using the
`mathptmx` package -- the standard Times/Times-New-Roman-metric-compatible
LaTeX font -- so figure typography visually matches the manuscript body
text, which is itself set in a Times-family font by the `elsarticle`
document class. This changes ONLY how text is rendered (font/typeface);
it touches no data, no curve, no color, and no numerical value in any
figure.

If the LaTeX toolchain (latex + dvipng + cm-super) is not available in a
given environment, this falls back to matplotlib's built-in serif/STIX
math font, which is visually close to Times but does not require a
system LaTeX install -- so figure regeneration never hard-fails for a
purely typographic reason.
"""

import shutil
import matplotlib


def apply_journal_style():
    have_latex = shutil.which("latex") is not None and shutil.which("dvipng") is not None
    if have_latex:
        matplotlib.rcParams["text.usetex"] = True
        matplotlib.rcParams["text.latex.preamble"] = r"\usepackage{mathptmx}\usepackage{amsmath}"
    else:
        matplotlib.rcParams["text.usetex"] = False
        matplotlib.rcParams["mathtext.fontset"] = "stix"
        matplotlib.rcParams["font.family"] = "STIXGeneral"
    matplotlib.rcParams["font.size"] = 10
    matplotlib.rcParams["axes.labelsize"] = 11
    matplotlib.rcParams["axes.titlesize"] = 11
    matplotlib.rcParams["xtick.labelsize"] = 10
    matplotlib.rcParams["ytick.labelsize"] = 10
    matplotlib.rcParams["legend.fontsize"] = 9
    matplotlib.rcParams["figure.dpi"] = 300
    return have_latex
