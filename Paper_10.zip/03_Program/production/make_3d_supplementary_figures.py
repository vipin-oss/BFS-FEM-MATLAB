#!/usr/bin/env python3
"""
Generates two SUPPLEMENTARY 3D visualizations requested in addition to the
existing audited manuscript figure set. Both are read-only re-renderings of
already-computed, FROZEN production data -- no new simulation is run, and no
number in the underlying CSVs is altered, re-derived, or refined.

  1. Fig_S1_chi_eta_surface_3D.png
     A 3D surface Delta-Omega(chi, eta) over the full 11x11 supplementary
     (chi, eta) grid. Delta-Omega is taken directly from
     SUPP_CHI_ETA_GAP_SUMMARY.csv wherever a gap was detected (all such rows
     have chi = 1.0, gap_index = 1, i.e. the single widest/only reported gap
     per (chi, eta) pair); everywhere else Delta-Omega = 0, which is read
     off SUPP_CHI_ETA_CASE_METRICS.csv's own n_gaps = 0 flag for that
     (chi, eta) pair (121 rows total), not assumed. This REPLACES the
     existing 2D heatmap (fig_chi_eta_heatmap.png, manuscript Fig.
     "fig_chi_eta_heatmap") in the manuscript -- same data, same 11x11 grid,
     no reinterpretation -- and reproduces that figure's two annotation
     layers so no information is lost in the switch to 3D:
       - boundary-truncated points (is_boundary_truncated = True in the
         same CSV) are marked with a black asterisk marker sitting on the
         surface at their true Delta-Omega height;
       - the same five frozen S2/S4 production anchor points used by
         `make_phase0_figures.make_heatmap` -- (chi, eta) =
         (0.0, 0.5), (0.5, 0.5), (1.0, 0.5), (1.0, 0.2), (1.0, 0.8) --
         are marked with open crimson circles at their true surface height.

  2. Fig_S2_dpl_lag_waterfall_3D.png
     A 3D "waterfall" rendering of the spatial attenuation alpha_a(Omega)
     for the same 5 Family S5 DPL time-lag cases already shown in the
     existing 2D manuscript figure "fig6_dpl_lags.png" (two side-by-side
     2D panels: (a) tau_q sweep, (b) tau_theta sweep, sharing the same
     tau_q=10ps/tau_theta=2ps baseline case), stacked along a single case
     axis instead. The acoustic branch for each case is extracted with the
     SAME `extract_acoustic_branch` function from `branch_utils.py` used
     by `regenerate_calibrated_figures.py` to build that 2D figure
     (identical ALPHA_PASS/KR_MIN/KR_MAX defaults, identical
     ACTIVE_FLOOR = 1e-7 convention), and the line-break logic mirrors
     `plot_acoustic_branch` (break the drawn line at every `_hopped=True`
     point; do not draw `_display=False` fragments) so the 3D curve is
     consistent with, and never contradicts, the already-audited 2D curve
     for the same case. `plot_acoustic_branch` itself draws on a 2-D Axes
     and cannot be called unmodified on a 3-D Axes (Axes3D.plot requires a
     z-array), so the segment-break/display-filter loop is reproduced here
     rather than the extraction logic, which is imported and reused
     unchanged. All 5 distinct case_ids from both original panels are
     present (the shared baseline case is drawn once, not duplicated), so
     no case is dropped in the switch to a single combined 3D panel.

Both figures REPLACE their corresponding 2D figure in the manuscript (see
CHANGELOG_3D_FIGURE_INTEGRATION.md for the exact manuscript edits); they are
written next to the existing production figures by this script, and this
script itself does not touch manuscript.tex.
"""

import os
import sys
import csv

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401  (registers 3d projection)
from mpl_toolkits.mplot3d.art3d import Line3DCollection, Poly3DCollection

sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from branch_utils import extract_acoustic_branch
from figure_style import apply_journal_style

repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if os.path.isdir(os.path.join(repo_root, "paper10", "production", "results")):
    results_dir = os.path.join(repo_root, "paper10", "production", "results")
    figures_dir = os.path.join(repo_root, "paper10", "figures", "phase3b")
else:
    results_dir = os.path.join(repo_root, "04_Data")
    figures_dir = os.path.join(repo_root, "02_FIGURES")

os.makedirs(figures_dir, exist_ok=True)
have_latex = apply_journal_style()


# ---------------------------------------------------------------------------
# Figure S1: 3D surface Delta-Omega(chi, eta)
# ---------------------------------------------------------------------------
def make_chi_eta_surface_3d():
    gap_path = os.path.join(results_dir, "SUPP_CHI_ETA_GAP_SUMMARY.csv")
    metrics_path = os.path.join(results_dir, "SUPP_CHI_ETA_CASE_METRICS.csv")

    with open(metrics_path) as f:
        metrics = list(csv.DictReader(f))
    with open(gap_path) as f:
        gaps = list(csv.DictReader(f))

    chis = sorted({round(float(r["chi"]), 6) for r in metrics})
    etas = sorted({round(float(r["eta"]), 6) for r in metrics})
    assert len(chis) == 11 and len(etas) == 11, (
        f"expected 11x11 grid, found {len(chis)}x{len(etas)} -- refusing to "
        f"guess at a different grid shape"
    )

    # n_gaps confirms, per (chi, eta), whether ANY gap exists (frozen data,
    # not assumed): 0 -> Delta-Omega = 0 everywhere at that point.
    n_gaps_by_pt = {
        (round(float(r["chi"]), 6), round(float(r["eta"]), 6)): int(r["n_gaps"])
        for r in metrics
    }
    # Where a gap does exist, take its actual reported width. If a (chi,
    # eta) pair ever has more than one gap_index, use the widest reported
    # gap (sum is not used -- this stays a direct read of one CSV column,
    # not a derived quantity).
    delta_omega_by_pt = {}
    for r in gaps:
        key = (round(float(r["chi"]), 6), round(float(r["eta"]), 6))
        dW = float(r["delta_Omega"])
        if key not in delta_omega_by_pt or dW > delta_omega_by_pt[key]:
            delta_omega_by_pt[key] = dW

    Z = np.zeros((len(etas), len(chis)))
    for i, eta in enumerate(etas):
        for j, chi in enumerate(chis):
            key = (chi, eta)
            if n_gaps_by_pt.get(key, 0) == 0:
                Z[i, j] = 0.0
            else:
                if key not in delta_omega_by_pt:
                    raise ValueError(
                        f"n_gaps>0 at chi={chi}, eta={eta} but no matching row "
                        f"in SUPP_CHI_ETA_GAP_SUMMARY.csv -- refusing to fabricate a value"
                    )
                Z[i, j] = delta_omega_by_pt[key]

    X, Y = np.meshgrid(chis, etas)

    # Boundary-truncated points: same frozen flag column as the 2D heatmap.
    truncated_pts = []
    for r in gaps:
        if r["is_boundary_truncated"].strip() == "True":
            key = (round(float(r["chi"]), 6), round(float(r["eta"]), 6))
            truncated_pts.append((key[0], key[1], delta_omega_by_pt[key]))

    # Same five frozen S2/S4 production anchor points as
    # `make_phase0_figures.make_heatmap` (hard-coded there for the same
    # reason: they are the specific cases reproduced exactly, not a
    # computed subset).
    anchor_xy = [(0.0, 0.5), (0.5, 0.5), (1.0, 0.5), (1.0, 0.2), (1.0, 0.8)]
    anchor_pts = []
    for (ac, ae) in anchor_xy:
        key = (round(ac, 6), round(ae, 6))
        z = 0.0 if n_gaps_by_pt.get(key, 0) == 0 else delta_omega_by_pt[key]
        anchor_pts.append((ac, ae, z))

    fig = plt.figure(figsize=(7.4, 5.8))
    ax = fig.add_subplot(111, projection="3d")
    surf = ax.plot_surface(X, Y, Z, cmap="viridis", linewidth=0.15,
                            edgecolor="k", antialiased=True, alpha=0.92)

    if truncated_pts:
        tx, ty, tz = zip(*truncated_pts)
        ax.scatter(tx, ty, [z + 0.006 for z in tz], marker="*", s=110,
                   color="black", depthshade=False,
                   label="boundary-truncated ($\\Omega=1.80$ ceiling)"
                   if have_latex else "boundary-truncated (Omega=1.80 ceiling)")

    ax_, ay_, az_ = zip(*anchor_pts)
    ax.scatter(ax_, ay_, [z + 0.006 for z in az_], marker="o", s=70,
               facecolors="none", edgecolors="crimson", linewidths=1.6,
               depthshade=False, label="frozen S2/S4 production cases (reproduced exactly)")

    ax.set_xlabel(r"$\chi$ (material contrast)" if have_latex else "chi (material contrast)")
    ax.set_ylabel(r"$\eta$ (filling fraction)" if have_latex else "eta (filling fraction)")
    ax.set_zlabel(r"$\Delta\Omega$ (band-gap width)" if have_latex else "Delta-Omega (band-gap width)")
    ax.view_init(elev=28, azim=-60)
    cbar = fig.colorbar(surf, ax=ax, shrink=0.6, pad=0.1)
    cbar.set_label(r"$\Delta\Omega$" if have_latex else "Delta-Omega")
    ax.legend(loc="upper left", fontsize=7.5, bbox_to_anchor=(0.0, 0.95))

    out_path = os.path.join(figures_dir, "Fig_S1_chi_eta_surface_3D.png")
    fig.tight_layout()
    fig.savefig(out_path, dpi=300)
    plt.close(fig)
    print(f"wrote {out_path}  (grid {len(chis)}x{len(etas)}, "
          f"{int((Z > 0).sum())} nonzero-gap points of {Z.size})")
    return out_path


# ---------------------------------------------------------------------------
# Figure S2: 3D waterfall alpha_a(Omega) across Family S5 DPL lag cases
# ---------------------------------------------------------------------------
def _segments_from_pts(pts, xkey, ykey, floor=None, min_len=4):
    """
    Reproduces ONLY the segment-break / display-filter loop of
    `branch_utils.plot_acoustic_branch` (see its docstring), adapted to
    return line segments instead of calling a 2-D `ax.plot`, so the same
    kept/dropped decision applies here. `pts` must already carry the
    `_hopped` / `_display` flags set by `extract_acoustic_branch` --
    that extraction logic itself is imported and used unmodified.
    """
    if not pts:
        return []
    xs = [float(r[xkey]) for r in pts]
    ys_raw = [float(r[ykey]) for r in pts]
    ys = [max(y, floor) for y in ys_raw] if floor is not None else ys_raw

    segments = []
    seg_start = 0

    def flush(i0, i1):
        n = i1 - i0 + 1
        kept = pts[i0].get("_display", n >= min_len)
        if kept:
            segments.append((xs[i0:i1 + 1], ys[i0:i1 + 1]))

    for i in range(1, len(xs)):
        if pts[i].get("_hopped", False):
            flush(seg_start, i - 1)
            seg_start = i
    flush(seg_start, len(xs) - 1)
    return segments


def make_dpl_waterfall_3d():
    ACTIVE_FLOOR = 1e-7  # identical convention to Fig. 8 (fig6_dpl_lags.png)
    s5_path = os.path.join(results_dir, "S5_results.csv")
    with open(s5_path) as f:
        rec_s5 = list(csv.DictReader(f))

    cases = [
        ("S5_tauq_1ps",   r"$\tau_q=1$ ps"        if have_latex else "tau_q = 1 ps",     "g"),
        ("S5_tauq_10ps",  r"$\tau_q=10$ ps (base)" if have_latex else "tau_q = 10 ps (base)", "b"),
        ("S5_tauq_1ns",   r"$\tau_q=1$ ns"        if have_latex else "tau_q = 1 ns",     "r"),
        ("S5_tauth_01ps", r"$\tau_\theta=0.1$ ps" if have_latex else "tau_theta = 0.1 ps", "orange"),
        ("S5_tauth_100ps", r"$\tau_\theta=100$ ps" if have_latex else "tau_theta = 100 ps", "purple"),
    ]

    present_ids = {r["case_id"] for r in rec_s5}
    missing = [cid for cid, _, _ in cases if cid not in present_ids]
    if missing:
        raise ValueError(f"case_id(s) not found in S5_results.csv: {missing}")

    # Depth spacing between cases: widened (DEPTH_STEP > 1) purely as a
    # display parameter on this categorical case axis (case identity has no
    # natural numeric spacing to begin with) so the 5 curves are visually
    # separated instead of crowding/crossing near the attenuation peaks.
    # This changes ONLY how far apart the case "sheets" sit along the y-axis;
    # no Omega or alpha_a value, and no data point, is altered.
    DEPTH_STEP = 2.4
    Z_FLOOR = np.log10(ACTIVE_FLOOR)

    fig = plt.figure(figsize=(10.5, 7.2))
    ax = fig.add_subplot(111, projection="3d")

    n_segments_total = 0
    n_points_total = 0
    for i, (cid, label, color) in enumerate(cases):
        depth = i * DEPTH_STEP
        case_records = [r for r in rec_s5 if r["case_id"] == cid]
        pts = extract_acoustic_branch(case_records)
        segments = _segments_from_pts(pts, "Omega", "alpha_a", floor=ACTIVE_FLOOR)
        for xs, ys in segments:
            zs = np.log10(np.maximum(np.array(ys), ACTIVE_FLOOR))
            y_depth = np.full(len(xs), depth, dtype=float)
            # Waterfall "sheet": a translucent curtain dropping from the
            # curve down to the shared floor, drawn on the same (x, depth)
            # plane as the curve itself -- a presentation aid (like a
            # joyplot baseline) that makes each case's own depth slot
            # unambiguous at a glance; it carries no data beyond the curve
            # already plotted (the top edge of the curtain IS the curve).
            if len(xs) >= 2:
                verts = [list(zip(xs, y_depth, zs)) +
                         [(xs[-1], depth, Z_FLOOR), (xs[0], depth, Z_FLOOR)]]
                curtain = Poly3DCollection(verts, facecolor=color, edgecolor="none", alpha=0.18)
                ax.add_collection3d(curtain)
            ax.plot(xs, y_depth, zs, color=color, lw=2.1, zorder=10)
            n_segments_total += 1
            n_points_total += len(xs)
        # one proxy line per case for the legend (all real segments already
        # drawn above; this adds no new data points, only a legend handle)
        ax.plot([], [], [], color=color, lw=2.1, label=label)

    ax.set_xlabel(r"$\Omega$ (dimensionless frequency)" if have_latex else "Omega (dimensionless frequency)")
    ax.set_ylabel("DPL time-lag case")
    ax.set_zlabel(r"$\log_{10}(\alpha a)$" if have_latex else "log10(alpha a)")
    ax.set_yticks([i * DEPTH_STEP for i in range(len(cases))])
    ax.set_yticklabels([lbl for _, lbl, _ in cases])
    ax.set_ylim(-0.5, (len(cases) - 1) * DEPTH_STEP + 0.5)
    ax.view_init(elev=20, azim=-68)
    ax.legend(loc="upper left", fontsize=8, bbox_to_anchor=(0.0, 0.98))

    out_path = os.path.join(figures_dir, "Fig_S2_dpl_lag_waterfall_3D.png")
    fig.tight_layout()
    fig.savefig(out_path, dpi=300)
    plt.close(fig)
    print(f"wrote {out_path}  ({len(cases)} cases, {n_segments_total} displayed "
          f"segments, {n_points_total} plotted points)")
    return out_path


if __name__ == "__main__":
    p1 = make_chi_eta_surface_3d()
    p2 = make_dpl_waterfall_3d()
    print("\nBoth supplementary 3D figures generated from frozen production "
          "data only. No manuscript file was modified by this script.")
    print(p1)
    print(p2)
