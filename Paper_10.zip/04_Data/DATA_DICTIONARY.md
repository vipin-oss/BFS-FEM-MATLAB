# Data Dictionary — Paper 10 Production Datasets

**Manuscript:** Dual-Phase-Lag (DPL) Thermoelastic Band-Gap Tuning and Acoustic Dissipation in 1D Periodic Metamaterials with Dipolar Gradient Elasticity  
**Dataset Location:** `04_Data/`  
**Total Cases:** 36 parameter cases across 7 sweep families (S1–S7)  
**Frequency Sampling:** 100 uniformly spaced points across $\Omega \in [0.05, 1.80]$ ($\Delta\Omega = 0.01768$)  
**Total Modal Records:** 17,900 records  
**Solver revision:** equilibrated-pencil (see "Numerical Conditioning Fix" note in Section 2 below). All files in this directory were generated with this corrected solver, after an earlier numerical-conditioning defect in the pencil assembly was identified and fixed; see `README_FINAL_PACKAGE.md` for the full fix history and verification.  

---

## 1. Dataset Overview

| File Name | Sweep Family & Focus | Cases Included | Records | Primary Sweep Parameter(s) |
| :--- | :--- | :---: | :---: | :--- |
| `S1_results.csv` | Baseline Dispersion & DPL | 2 | 1,000 | Conservative ($\beta \to 0$) vs Active DPL Baseline |
| `S2_results.csv` | Material Contrast | 6 | 2,985 | Contrast parameter $\chi \in \{0.0, 0.5, 1.0\}$ |
| `S3_results.csv` | Gradient Length Scales | 7 | 3,275 | Micro-inertia $d_1/a$, micro-stiffness $\sqrt{c_1}/a$, classical limit ($c,d\to 0$) |
| `S4_results.csv` | Geometric Asymmetry | 6 | 3,000 | Layer A filling fraction $\eta = a_1/a \in \{0.2, 0.5, 0.8\}$ |
| `S5_results.csv` | Non-Fourier Thermal Lags | 5 | 2,500 | Relaxation lag $\tau_q \in [1\text{ ps}, 1\text{ ns}]$, retardation lag $\tau_\theta \in [0.1\text{ ps}, 100\text{ ps}]$ |
| `S6_results.csv` | Thermoelastic Coupling | 4 | 2,000 | Coupling scaling $\alpha_t / \alpha_{t,\text{base}} \in \{0.0, 0.5, 1.0, 2.0\}$ |
| `S7_results.csv` | Combined-Parameter Interaction Study | 6 | 2,987 | Representative combinations of Bragg, gradient, and DPL mechanisms |
| `PRODUCTION_BANDGAP_SUMMARY.csv` | Extracted Bragg Stop Bands | 36 | 38 | Authoritative lower/upper gap edges, widths, and truncation flags |
| `PRODUCTION_ATTENUATION_SUMMARY.csv`| Pass/Stop Band Attenuation | 36 | 36 | Min, mean, max pass-band attenuation and peak stop-band attenuation |
| `PRODUCTION_METRIC_MANIFEST.json` | Master Campaign Manifest | 36 | --- | Runtime, hardware, environment, and numerical health metrics |
| `PHASE3_PARAMETER_MATRIX.json` | Parameter Specifications | 36 | --- | Master locked parameter configurations |

---

## 2. Record Field Definitions (`S1_results.csv` through `S7_results.csv`)

Each row in the family result CSVs represents one forward-propagating or evanescent mode at a discrete frequency $\Omega$:

| Column Header | Data Type | Physical Meaning | Physical Units | Valid Range / Interpretation |
| :--- | :---: | :--- | :---: | :--- |
| `family_id` | String | Sweep family identifier | --- | `S1` to `S7` |
| `case_id` | String | Unique parameter case identifier | --- | e.g., `S1_cons`, `S1_dpl`, `S3_classical` |
| `case_name` | String | Descriptive case name | --- | e.g., `Active DPL Thermoelastic Baseline` |
| `freq_index` | Integer | Frequency grid index | --- | `0` to `99` |
| `Omega` | Float | Normalized frequency | Dimensionless | $\Omega = \omega a / (2\pi v_m) \in [0.05, 1.80]$ |
| `omega_rad_s` | Float | Circular frequency | $\text{rad/s}$ | $\omega = 2\pi v_m \Omega / a \approx 2.72 \times 10^4$ to $9.79 \times 10^5\text{ rad/s}$ |
| `branch_id` | Integer | Hungarian branch tracking index | --- | `0` to `4` (5 forward modes extracted from 10-state pencil) |
| `lambda_real` | Float | Real part of Bloch multiplier $\lambda$ | Dimensionless | $\lambda = e^{i k_x a}$ |
| `lambda_imag` | Float | Imaginary part of Bloch multiplier $\lambda$| Dimensionless | $\lambda = e^{i k_x a}$ |
| `kr_a_over_pi`| Float | Real normalized Bloch wavenumber | Dimensionless | $k_r a / \pi \in [0.0, 1.0]$ (First Brillouin zone) |
| `ki_a` | Float | Signed imaginary Bloch wavenumber | Dimensionless | Negative for forward spatial decay |
| `alpha_a` | Float | Spatial attenuation magnitude | Dimensionless | $\alpha a = \|k_i a\| \ge 0.0$ |
| `phase_vel_m_s`| Float | Acoustic phase velocity | $\text{m/s}$ | $v_p = \omega / k_r$ |
| `is_pass_band`| Boolean | Automated pass-band flag | --- | `True` if $\alpha a < 0.05$ and $0.01 < k_r a < \pi - 0.01$; `False` otherwise |
| `cond_P_equil` | Float | Row/column-equilibrated modal-matrix condition number | Dimensionless | $\kappa(P_\text{equil})$, computed by `compute_modal_matrix()`; $\le 22.72$ for standard baseline cases, peaks at $4648.99$ for `S3_classical` |
| `cond_Tcell` | Float | Equilibrated 10×10 layer transfer-matrix condition number | Dimensionless | Monitoring diagnostic only, not the eigenvalue-solve stability metric |
| `cond_pencil_raw` | Float | Condition number of the ASSEMBLED 20×20 pencil `[A_mat;B_mat]` built from the raw (un-equilibrated) modal matrices | Dimensionless | **This is the quantity that was destroying floating-point precision before the fix** (observed $10^{12}$–$10^{17}$); retained for transparency/audit |
| `cond_pencil_equil` | Float | Condition number of the same pencil AFTER the two-sided max-norm equilibration fix | Dimensionless | The actual eigenvalue-solve stability metric as of this package; typically $O(10)$–$O(10^2)$, confirming the fix restores good conditioning |

**Numerical Conditioning Fix (this revision):** `solve_unit_cell_bloch()`
previously assembled its 20×20 generalized eigenvalue pencil directly from
the raw 10×10 modal matrices, whose columns mix SI quantities differing by
up to $10^{16}$ in magnitude (displacement vs. stress vs. heat flux). This
silently destroyed essentially all floating-point precision in the
eigenvalue solve, producing spurious near-duplicate eigenvalues for single
physical modes (visible as jagged/spiking attenuation curves and, in several
DPL-active cases, entirely spurious extra Bragg gaps). The fix applies a
two-sided max-norm equilibration to the fully assembled pencil immediately
before the eigenvalue solve — a mathematically exact equivalence transform
for a generalized eigenvalue problem, so it changes no eigenvalue, only the
floating-point accuracy with which it is computed. See
`README_FINAL_PACKAGE.md` for the full derivation and verification.

---

## 3. Band-Gap Summary Table (`PRODUCTION_BANDGAP_SUMMARY.csv`)

| Column Header | Data Type | Physical Meaning | Interpretation |
| :--- | :---: | :--- | :--- |
| `case_id` | String | Parameter case ID | Maps to simulation sweep |
| `case_name` | String | Descriptive name | Maps to production matrix |
| `gap_index` | Integer | Gap sequential index | `1`, `2`, `3`, etc. within case |
| `Omega_L` | Float | Lower band-gap edge frequency | Onset of stop band |
| `Omega_U` | Float | Upper band-gap edge frequency | Termination of stop band |
| `delta_Omega` | Float | Band-gap frequency width | $\Delta\Omega = \Omega_U - \Omega_L$ |
| `Omega_mid` | Float | Mid-gap central frequency | $\Omega_c = (\Omega_L + \Omega_U)/2$ |
| `gap_to_midgap_ratio` | Float | Relative gap width ratio | $\Delta\Omega / \Omega_c$ |
| `is_boundary_truncated`| Boolean | Boundary truncation flag | **Crucial:** `True` indicates the stop band remains **open** at the frequency ceiling $\Omega = 1.8000$, with its upper physical edge lying outside the investigated window. Exactly 4 records are flagged `True` (`S3_d10`, `S4_eta08_cons`, `S4_eta08_dpl`, `S7_case4`). `False` indicates a fully closed internal stop band. |

---

## 4. Attenuation Summary Table (`PRODUCTION_ATTENUATION_SUMMARY.csv`)

| Column Header | Data Type | Physical Meaning | Interpretation |
| :--- | :---: | :--- | :--- |
| `case_id` | String | Parameter case ID | Maps to simulation sweep |
| `case_name` | String | Descriptive name | Maps to production matrix |
| `pass_alpha_min` | Float | Minimum pass-band attenuation | Governed by eigensolver numerical noise floor in conservative limit ($\sim 10^{-9}$) |
| `pass_alpha_mean`| Float | Mean pass-band attenuation | Average dissipation across modes satisfying `is_pass_band == True` |
| `pass_alpha_max` | Float | Maximum pass-band attenuation | Peak dissipation near band edges |
| `stop_alpha_peak`| Float | Peak stop-band attenuation | Maximum geometric evanescence inside Bragg gaps ($\alpha a \approx 4.915$) |

---

## 5. Critical Physical Distinctions Preserved in Data

1. **Bragg Stop Bands vs. DPL Dissipation:**
   In conservative cases (`S1_cons`), $\alpha a_\text{mean} \approx 1.05 \times 10^{-15}$ (true machine-precision zero) across pass bands and surges to $4.915$ inside the single Bragg gap $\Omega \in [1.5702, 1.6763]$ (pure geometric reflection). In active DPL cases (`S1_dpl`), thermoelastic entropy generation establishes a genuine non-zero attenuation baseline ($\alpha a_{\text{mean}} = 1.57 \times 10^{-6}$) across all propagating frequencies, with its own single, slightly narrower gap $\Omega \in [1.5702, 1.6409]$.
2. **Open Boundary Gaps:**
   The 4 records terminating at $\Omega_U = 1.8000$ (`S3_d10`, `S4_eta08_cons`, `S4_eta08_dpl`, `S7_case4`) are explicitly designated with `is_boundary_truncated = True`. They are **open attenuation bands**, not closed physical band gaps.
3. **Identical Layers Limit:**
   In case `S2_chi00_dpl` ($\chi = 0$), acoustic impedance mismatch is zero, yielding $\Delta\Omega \equiv 0.0000$ (no Bragg gaps). Intrinsic dipolar gradient dispersion and thermal attenuation remain active throughout the homogeneous medium. The same is now also true, within the $\Delta\Omega \ge 0.02$ resolution threshold, for the intermediate contrast `S2_chi05_*` cases (no appreciable gap), a genuinely new finding from the conditioning fix, not present in the earlier (uncorrected) solver's results.

---

## 4. Phase-0 Supplementary Grid Datasets (added 2026-09-26)

These files were added during the Phase-0 scientific-depth expansion (2-D material-contrast x filling-fraction campaign), and were **regenerated** (2026-09-27) with the same numerical-conditioning fix applied to `run_phase3b_production.py` (this runner carried its own copy of the same solver code, now fixed identically; see `README_FINAL_PACKAGE.md`). The S1-S7 production datasets remain a separate campaign. The runner is `03_Program/production/run_chi_eta_grid.py`. At the five grid points shared with the corresponding S2/S4 production cases ($(\chi,\eta)$ = $(0.0,0.5)$ no-gap, $(0.5,0.5)$ no-gap, $(1.0,0.5)$ gap, $(1.0,0.2)$ gap, $(1.0,0.8)$ gap), the supplementary run reproduces `PRODUCTION_BANDGAP_SUMMARY.csv` exactly — all 5 match.

| File Name | Content | Cases | Records |
| :--- | :--- | :---: | :---: |
| `SUPP_CHI_ETA_GAP_SUMMARY.csv` | All extracted band gaps over the 11x11 (chi, eta) grid (DPL-active baseline) | 121 | 11 gap records (only $\chi=1.0$ opens a gap of appreciable width) |
| `SUPP_CHI_ETA_CASE_METRICS.csv` | Per-case runtime, worst equilibrated modal conditioning, pass/stop attenuation statistics | 121 | 121 |
| `SUPP_CHI_ETA_GRID_META.json` | Run metadata: chi/eta value vectors, Omega grid, anchors-passed flag, total runtime | --- | --- |

### Record Field Definitions (`SUPP_CHI_ETA_GAP_SUMMARY.csv`)

| Column Header | Data Type | Physical Meaning |
| :--- | :---: | :--- |
| `chi` | Float | Material contrast parameter in [0.0, 1.0] (Layer B = linear interpolation Epoxy->Al benchmark) |
| `eta` | Float | Filling fraction a1/a in [0.2, 0.8] |
| `gap_index` | Integer | Sequential gap index within the case (1 = first Bragg gap) |
| `Omega_L`, `Omega_U` | Float | Lower/upper gap edge (normalized frequency) |
| `delta_Omega` | Float | Gap width Omega_U - Omega_L |
| `Omega_mid` | Float | Midgap frequency |
| `gap_to_midgap_ratio` | Float | Delta_Omega / Omega_mid |
| `is_boundary_truncated` | Boolean | True if the gap remains open at the Omega = 1.80 ceiling |

**Physics note:** at chi = 0 the unit cell is homogeneous (no impedance contrast) and the first Bragg gap is identically zero, consistent with the frozen `S2_chi00` production record ("No gap"). The published Fig. 12 heatmap enforces this identity.
