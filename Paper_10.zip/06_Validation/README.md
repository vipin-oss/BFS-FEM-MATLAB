# Validation — Overview

This folder archives the benchmark/validation scripts and their output data, corresponding
to manuscript Section 3.5 (External Validation Against Published Benchmarks) and Section 3.6
(Internal Verification).

## Contents

- `run_benchmarks.py` — runs the Papargyri-Beskou et al. (2009) gradient dispersion
  benchmark and the classical acoustic elastic-limit check.
- `run_periodic_pilot.py` — runs the periodic conservative two-layer pilot compared against
  Li et al. (2016) classical Bragg-gap results.
- `benchmark_papargyri_beskou_results.csv` / `.json` — output of `run_benchmarks.py`; source
  of the $2.45\times10^{-15}$ maximum relative discrepancy reported in manuscript Section 3.5
  and Table 1.
- `periodic_pilot_results.json` — output of `run_periodic_pilot.py`; source of the
  $\le 0.3\%$ classical Bragg-gap discrepancy reported in manuscript Section 3.5 and Table 1.
- `PHASE2_BENCHMARK.md`, `PHASE2_REPRODUCIBILITY.md`, `PHASE2_TARGETED_VALIDATION_AUDIT.md`,
  `VALIDATION_README.md` — development-time validation notes, retained here as supplementary
  documentation of how the benchmark checks were designed and audited. These predate the
  manuscript's final terminology cleanup (Sections 3.5/3.6 split into External Validation vs.
  Internal Verification); the manuscript itself, not these development notes, is the
  authoritative statement of what was validated and how.

## Mapping to manuscript claims

| Manuscript claim | Section | Source file here |
|---|---|---|
| Max relative discrepancy $2.45\times10^{-15}$ vs. Papargyri-Beskou et al. (2009) | 3.5, Table 1 | `benchmark_papargyri_beskou_results.csv` |
| Classical Bragg gap match $\le 0.3\%$ vs. Li et al. (2016) | 3.5, Table 1 | `periodic_pilot_results.json` |
| Secular residual, classical speed limit, symplecticity checks | 3.6, Table 1 | `run_benchmarks.py` output (see also `../03_Program/validation/validate_benchmark_acta.py`) |

## Known limitation (not resolved by this folder)

No independently published closed-form DPL/thermoelastic dispersion relation for a layered
medium was identified or benchmarked against. The coupled DPL thermoelastic channel is
checked only by the internal self-consistency diagnostics referenced above, not against an
external published result. This is disclosed in manuscript Section 7 (Limitations) as an
open item, not claimed as resolved anywhere in this folder.
