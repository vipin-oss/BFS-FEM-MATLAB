# Paper 10 — Final Submission Package

**Dual-Phase-Lag (DPL) Thermoelastic Band-Gap Tuning and Acoustic Dissipation in
1D Periodic Metamaterials with Dipolar Gradient Elasticity**
Vipin Gupta, Department of Mathematics, Gurugram University, Gurugram, Haryana, India
(vipin@gurugramuniversity.ac.in)

This package is a complete, self-contained submission bundle: the manuscript, an
Overleaf-ready compile folder, the source code that produced the reported results, the
numerical data itself, the figure-generation scripts and final figures, and the
validation/benchmark record.

## Folder structure

```
Paper10_FINAL_SUBMISSION_PACKAGE/
├── 01_Manuscript/        Final .tex, compiled .pdf, references.bib, and .cls/.bst files
├── 02_Overleaf/          The same manuscript, arranged to upload directly to Overleaf
├── 03_Program/           All source code (solver, production runs, figures, validation)
├── 04_Data/              All production CSV/JSON datasets
├── 05_Figures_Source/    Figure-generation scripts + final figure files (FigNN_*.png)
├── 06_Validation/        Benchmark/validation scripts, outputs, and documentation
├── README.md             This file
└── MANIFEST.txt          Full file listing with one-line purpose per file
```

## 1. Software / environment requirements

- Python 3.11 (built and run under 3.11.2)
- LaTeX (TeX Live 2023 or later, or Overleaf's default TeX Live), with the `elsarticle`
  document class (bundled in `02_Overleaf/` and `01_Manuscript/` as `elsarticle.cls` /
  `elsarticle-num.bst`, so no separate install is required)

## 2. Required Python packages

See `03_Program/requirements.txt`:
```
numpy==2.4.6
scipy==1.17.1
matplotlib==3.11.2
```
Install with `pip install -r 03_Program/requirements.txt`.

## 3. How to run the validation

```
cd 03_Program/validation
python3 run_benchmarks.py
python3 run_periodic_pilot.py
```
See `06_Validation/README.md` for how these outputs map onto the manuscript's reported
validation numbers.

## 4. How to reproduce the production cases

```
cd 03_Program/production
python3 run_pilot_sweep.py         # optional diagnostic pilot
python3 run_phase3b_production.py  # full 36-case S1-S7 production campaign
python3 run_chi_eta_grid.py        # supplementary 2-D (chi, eta) grid
```

## 5. How to regenerate the figures

```
cd 03_Program/production
python3 make_phase0_figures.py
python3 regenerate_phaseA_figures.py
python3 regenerate_calibrated_figures.py
python3 make_3d_supplementary_figures.py  # current Fig08 (3D DPL waterfall) and Fig12 (3D chi-eta surface)
python3 audit_branch_figures.py
```
See `05_Figures_Source/README.md` for the exact script -> figure mapping.

## 6. Where generated CSV/JSON files are written

Each script writes to the path set near the top of the script itself (`OUT_DIR` /
`figures_dir` variables). The exact files used for the manuscript's reported numbers are
archived unmodified in `04_Data/`.

## 7. Which script corresponds to each figure

See the table in `05_Figures_Source/README.md` (also reproduced in `03_Program/README.md`).

## 8. Which data files correspond to Table 3 and Appendix Table A.1

- **Table 3** (band-gap summary): `04_Data/PRODUCTION_BANDGAP_SUMMARY.csv`
- **Appendix Table A.1** (36-case manifest): the case-identifying columns of
  `04_Data/S1_results.csv` through `04_Data/S7_results.csv`

## 8a. How the packaged figures relate to the packaged data

Every figure in `01_Manuscript/figures/`, `02_Overleaf/figures/`, and
`05_Figures_Source/figures/` is a direct rendering of the corresponding CSV/JSON file(s) in
`04_Data/`, produced by the script named for it in `05_Figures_Source/README.md` / Section 5
above — no figure was hand-edited after generation, and no figure encodes a computation not
already present in `04_Data/`. This was re-verified for this package: `04_Data/S7_results.csv`
(unmodified) was re-run through `regenerate_phaseA_figures.py` and the freshly regenerated
`Fig10_combined_interaction.png` is byte-for-byte identical to the packaged copy; the 3D
`Fig08_DPL_lags.png` and `Fig12_parameter_map.png` were independently regenerated from
`04_Data/S5_results.csv` and `04_Data/SUPP_CHI_ETA_*` respectively via
`make_3d_supplementary_figures.py` and are likewise byte-for-byte identical to the packaged
copies.

## 9. Limitations (disclosed, not resolved by this package)

- **Native 100-point frequency grid.** The production campaign uses a uniform grid over
  $\Omega \in [0.05, 1.80]$ (step $\approx 0.0177$); no sub-grid root-finding refinement was
  applied.
- **Grid-resolved band edges.** Reported band-edge coordinates ($\Omega_L$, $\Omega_U$ in
  Table 3 and the manuscript text) are native-grid estimates, not sub-grid-refined values;
  the resulting $\Delta\Omega$ uncertainty is not simply $\pm 0.0177$ and candidate gaps near
  the $\Delta\Omega = 0.02$ significance threshold should be read cautiously.
- **Four boundary-truncated gaps.** `S3_d10`, `S4_eta08_cons`, `S4_eta08_dpl`, and
  `S7_case4` have an upper band edge at the $\Omega = 1.80$ frequency ceiling; their true
  upper closure frequency is unknown and lies beyond the investigated range.
- **DPL admissibility caveat for two Family S5 cases.** `S5_tauq_1ps`
  ($\tau_q = 1\text{ ps} < \tau_\theta = 2\text{ ps}$) and `S5_tauth_100ps`
  ($\tau_\theta = 100\text{ ps} > \tau_q = 10\text{ ps}$) fall outside the DPL thermodynamic
  admissibility condition $\tau_q \ge \tau_\theta$. They are retained as points in a formal
  mathematical parameter sweep, not as claims of thermodynamically admissible physical
  operating states (see manuscript Section 7, item 7).
- **No independent external DPL benchmark.** No independently published closed-form
  DPL/thermoelastic dispersion relation for a layered medium was identified. The coupled DPL
  channel is checked only by internal self-consistency diagnostics (manuscript Section 3.6),
  not against an external published result. This is an open, disclosed limitation
  (manuscript Section 7, item 6), not something this package claims to have resolved.

This package does not claim complete, unattended, one-command reproduction of every
intermediate development artifact referenced in the internal development notes under
`06_Validation/` — those documents are retained for transparency but predate the
manuscript's final terminology cleanup, and the manuscript itself is the authoritative
statement of what was validated, verified, and disclosed as a limitation.

## 10. Compilation and reproducibility status of this package

- `02_Overleaf/` was compiled standalone, from a clean copy of only that folder's contents,
  using `pdflatex -> bibtex -> pdflatex -> pdflatex`: 0 errors, 0 undefined references, 0
  multiply-defined labels, 0 missing-figure warnings, 0 "??" markers, 30 pages. Body text of
  the fresh compile is identical to the packaged `Paper10_Final.pdf` (`pdftotext -layout`
  diff is empty).
- `01_Manuscript/Paper10_Final.pdf` is that same compiled output (byte-identical to the copy
  in `02_Overleaf/`).
- All internal `04_PRODUCTION_DATA` / `03_SOURCE_CODE` / `05_VALIDATION` path references from
  earlier development-stage layouts have been corrected package-wide to `04_Data` /
  `03_Program` / `06_Validation`.
- `03_Program/production/run_chi_eta_grid.py`'s Phase-0 supplementary grid handling,
  `03_Program/production/regenerate_phaseA_figures.py` (Fig03/05/07/10), and
  `03_Program/production/make_3d_supplementary_figures.py` (Fig08/12) were each executed
  directly from this clean package directory against `04_Data/` with no path errors; all
  regenerated figures matched the packaged figures byte-for-byte (see Section 8a). Output
  directories that the scripts write to (`02_FIGURES/`, a plain staging directory, not part
  of the shipped package structure) are created on demand by the scripts themselves and are
  not shipped in this package.
- `03_Program/production/audit_branch_figures.py` was re-run against this package and reports
  31/31 dispersion-figure cases passing their continuity gate (archived at
  `06_Validation/BRANCH_AUDIT_REPORT.md`).
