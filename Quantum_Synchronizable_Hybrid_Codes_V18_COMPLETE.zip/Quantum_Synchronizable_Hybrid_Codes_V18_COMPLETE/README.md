# Quantum Synchronizable Hybrid Codes from Cyclic Codes over Fq[v]/(v^3-v)

## Current manuscript — V18

This package contains the latest approved Title Case title, Introduction, and user-proposed abstract with the four approved precision corrections. No earlier manuscript PDFs are included. Mathematical ring notation is typeset in the PDF.

- **Read:** `submission/Idempotent_QSC_REVIEW_CORRECTED_V18.pdf` (13 pages).
- **Edit/compile:** `submission/Idempotent_QSC_FINAL.tex`.
- **Bibliography:** `submission/references.bib` (16 entries).
- **Optional pre-generated bibliography:** `submission/Idempotent_QSC_FINAL.bbl` from the V18 build. BibTeX regenerates it during a fresh build.

The TeX source contains its own tables and TikZ drawing; no external figure or web download is needed for compilation. The standalone SVG and data tables are supplementary.

## Build the paper

Install pdfLaTeX, BibTeX, latexmk, and the standard LaTeX packages including AMS, booktabs, array, TikZ, microtype, geometry and hyperref. On Debian/Ubuntu the corresponding packages are `texlive-latex-base`, `texlive-latex-recommended`, `texlive-pictures`, and `latexmk`. No package installer is run automatically by this archive.

From the extracted package root:

```sh
sh build.sh build_v18_reproduction
```

Use a new, nonexistent output directory. The script refuses existing output directories; it does not overwrite the included PDF. Output: `build_v18_reproduction/Idempotent_QSC_REVIEW_CORRECTED_V18.pdf`. Alternatively, from `submission/`, run:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir=../another_new_build -jobname=Idempotent_QSC_REVIEW_CORRECTED_V18 Idempotent_QSC_FINAL.tex
```

## Programs and dependencies

Use Python 3.10 or newer. The original finite-field/theorem/quantum test code uses the Python standard library; independent SymPy-based programs require the dependency below. SymPy 1.14.0 is the environment used for the independent-table validation.

```sh
python3 -m venv .venv
# Linux/macOS:
. .venv/bin/activate
# Windows: .venv\Scripts\activate
python3 -m pip install -r requirements.txt
```

### Regenerate the current coverage tables

Run from the package root, choosing a new output directory:

```sh
python3 scripts/review_table_verification.py --out regenerated_tables
```

Expected: 118 relaxation families, 38 positive relaxation factors, and 27 admissible proper-D pairs among 81 examined pairs. The finite maximum factor is 12 for the stated q<=101 cutoff, not a universal bound. See `data/README.md` for exact table-label mappings, selection rules and legacy-data caveats.

### Independent branch census

```sh
mkdir census_reproduction
python3 code/branch_census.py census_reproduction/branch_census_output.json
```

Expected: 20,724 branches across 81 eligible (q,n) pairs; 39 pairs admit branches. The script writes the explicit output file and also prints a summary. Do not pass the included JSON path if preserving shipped evidence.

### Theorem, theory and quantum checks

Tests write results and sometimes example data in their own directories. To preserve the included evidence, make a disposable copy first:

```sh
python3 -c "import shutil; shutil.copytree('supporting_programs', 'programs_rerun')"
cd programs_rerun
python3 tests/test_theorems.py
python3 tests/test_theory.py
python3 tests/test_quantum.py
```

Fresh previously completed results are included in `supporting_programs/results/`: 751 theorem checks; 8,794 nested-pair and 1,466 full-QSC collision checks; 60 boundary cases; 11 fusion triples; 18 bridge, 6 CSS, 13 recovery and 4 nonfree quantum instances. Runs may take several minutes. These computations corroborate mathematical arguments and do not replace proofs.

Additional independent checks are in `code/independent_checks.py`; these include potentially costly codeword enumeration. Magma programs are optional historical cross-checks and require a separate Magma installation/license; they are not required for the Python or LaTeX workflows. The older `supporting_programs/python/experiments.py`, baseline research README, and supplementary candidate datasets are retained as legacy material, NOT as regenerators of the revised 118/27 coverage tables. Some historical table counts/paths differ; current guidance is this README, `data/README.md`, and `scripts/review_table_verification.py`.

## Evidence and scope

- `validation/PACKAGE_VALIDATION.md`: package integrity and fresh build checks.
- `validation/abstract_v18/`: latest abstract revision/build records.
- `validation/editorial_history/`: earlier Introduction/title/abstract diffs, explicitly historical.
- `validation/review_corrections_v1_historical/`: verified review corrections and previously completed computation logs. Its manuscript hash/page count concern V1, not V18; later revisions changed prose/title/abstract only.
- `SHA256SUMS.txt`: checksums of all other package files. Verify from package root with `sha256sum -c SHA256SUMS.txt` where available.

The source and PDF are byte-identical to the recorded approved V18 hashes. During packaging the restored V18 submission folder was absent; the source was recovered from preserved V17 plus the exact approved V18 abstract and matched the recorded V18 SHA-256. The V18 PDF and bibliography were recovered from preserved build/prior-copy evidence and hash-checked. No prior file was modified.

The model assumes exact (error-free or successfully corrected) marker syndromes and shared offsets by whole three-qudit cells. No noisy syndrome-extraction or joint noisy-decoder theorem is claimed. Fusion can improve selected components but not the unrestricted single-branch maximum. The example's underlying hybrid capacity is 9 ternary symbols, while marker messages carry 4; 39 unpadded versus 75 padded qudits. Gauge/subsystem extensions are structural; the evaluated construction has no gauge qudits. Global novelty and unrelated unresolved bibliography/provenance questions are not certified by this package. No license grant is inferred; consult the author for reuse terms.
