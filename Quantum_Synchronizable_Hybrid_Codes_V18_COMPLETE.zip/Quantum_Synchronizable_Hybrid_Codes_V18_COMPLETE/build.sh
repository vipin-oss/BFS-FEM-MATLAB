#!/bin/sh
# Run from any directory. A fresh output directory is required.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec sh "$ROOT/supporting_programs/tools/build_pdf.sh" "${1:-build_v18_reproduction}"
