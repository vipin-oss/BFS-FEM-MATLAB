"""Exhaustive census of genuine QSC branches C^perp <= C < D (cyclic, length n, F_q, gcd(n,q)=1).
Independent of the authors' code: uses sympy factorisation over GF(q).
A branch is a pair (S, T) of sets of irreducible factors of x^n-1 with
  g_C = prod(S), g_D = prod(T), T proper subset of S, and C dual-containing
  (S contains no self-reciprocal factor and no reciprocal pair).
Then f = prod(S\\T), deg f = sum of degrees, e = lcm of ord_x of the factors in S\\T."""
import math, itertools, json, sys
from sympy import Poly, symbols
x = symbols('x')

def recip_monic(g, p):
    c = g.all_coeffs(); r = Poly(list(reversed(c)), x, modulus=p); return r.monic()

def ordx(f, p, n):
    for e in range(1, n + 1):
        if n % e == 0 and Poly(x**e - 1, x, modulus=p).rem(f).is_zero:
            return e

def census(q, n):
    xn = Poly(x**n - 1, x, modulus=q)
    facs = [fa.monic() for fa, _ in xn.factor_list()[1]]
    key = lambda P: tuple(int(c) % q for c in P.all_coeffs())
    info = {key(P): (P.degree(), ordx(P, q, n)) for P in facs}
    pairs, seen = [], set()
    for P in facs:
        k = key(P); rk = key(recip_monic(P, q))
        if k == rk or k in seen: continue
        seen.add(k); seen.add(rk); pairs.append((k, rk))
    counts = {"branches": 0, "e_gt_deg": 0, "e_eq_deg": 0, "e_lt_deg": 0, "max_e": 0}
    # per pair: state 0 none; 1 p in S\T; 2 p in T; 3 p* in S\T; 4 p* in T
    for states in itertools.product(range(5), repeat=len(pairs)):
        diff = []
        for (a, b), s in zip(pairs, states):
            if s == 1: diff.append(a)
            elif s == 3: diff.append(b)
        if not diff: continue          # T = S  -> C = D, excluded
        degf = sum(info[k][0] for k in diff)
        e = math.lcm(*[info[k][1] for k in diff])
        counts["branches"] += 1
        counts["max_e"] = max(counts["max_e"], e)
        if e > degf: counts["e_gt_deg"] += 1
        elif e == degf: counts["e_eq_deg"] += 1
        else: counts["e_lt_deg"] += 1
    return counts, len(pairs)

rows = []
tot = {"branches": 0, "e_gt_deg": 0, "e_eq_deg": 0, "e_lt_deg": 0}
maxe_ok = True
for q in [3, 5, 7, 11, 13]:
    for n in range(2, 21):
        if math.gcd(n, q) != 1: continue
        c, m = census(q, n)
        rows.append((q, n, m, c))
        for k in tot: tot[k] += c[k]
        if c["branches"] and c["max_e"] != n: maxe_ok = False
print("q n  #recip-pairs  branches  e>deg  e=deg  e<deg  max_e")
for q, n, m, c in rows:
    print(q, n, m, c["branches"], c["e_gt_deg"], c["e_eq_deg"], c["e_lt_deg"], c["max_e"])
print("TOTAL", tot, " share e>deg = %.1f%%" % (100 * tot["e_gt_deg"] / tot["branches"]))
print("(q,n) pairs:", len(rows), " with a branch:", sum(1 for r in rows if r[3]['branches']), " max_e == n whenever a branch exists:", maxe_ok)
json.dump({"rows": [(q, n, m, c) for q, n, m, c in rows], "total": tot}, open(sys.argv[1], "w"), indent=1)
