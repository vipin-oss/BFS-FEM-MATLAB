# Data for the review-corrected manuscript

Manuscript table labels, not numbers from earlier drafts, identify the data:

| Label | CSV |
|---|---|
| tab:single | tables/table2_single_branch.csv |
| tab:hybrid | tables/table10_hybrid.csv |
| tab:census | code/branch_census_output.json (81 pairs; 20724 branches) |
| tab:fusion | tables/table3_fusion.csv |
| tab:relax | tables/table4_optimal.csv (118 pairs;38 factor>1) |
| tab:dconstr | tables/table9_distance_constrained.csv (27 admissible pairs) |

`review_tables.json` records the explicit selection rule, all selected triples, all 81 proper-D search outcomes and polynomial witnesses. The 118-row relaxation and 27-row proper-D data supersede only the corresponding tables in this new working copy. Historical 74-row/partial data remain untouched in the previous approved working copies and preserved package. `tables.json` has updated `optimal` and `dconstrained` keys; other keys retain their earlier datasets, including supplementary data not displayed in the current manuscript.

Regenerate the corrected tables using `python3 scripts/review_table_verification.py --out NEW_EMPTY_OUTPUT_DIRECTORY` from package root (Python3 + SymPy). Original `supporting_programs/python/experiments.py` is retained as legacy provenance and does not generate these corrected coverage tables; do not use it to overwrite the updated data. Original theory tests are included and their import paths corrected in this working copy only. They write under `supporting_programs/results/`. `examples.*` are legacy theory-suite outputs; classical fusion examples must not be conflated with the dual-containing table. `flagship_candidates.json` is historical candidate provenance, not an additional manuscript claim.
