#!/usr/bin/env python3
"""Independent, exact verification for the review table corrections.
Requires SymPy. Writes ONLY to the explicit new --out directory (must not exist).
No distance enumeration is claimed: d_X>=2 iff D is proper is used and proved in report.
"""
from pathlib import Path
from itertools import combinations_with_replacement
from math import gcd,lcm
import argparse,csv,json,warnings
from sympy import Poly,symbols,factor_list,divisors,primerange
from sympy.utilities.exceptions import SymPyDeprecationWarning
warnings.filterwarnings('ignore',category=SymPyDeprecationWarning)
x=symbols('x')
def coeff(p):return [int(p.nth(i))%p.get_modulus() for i in range(p.degree()+1)]
def key(p):return tuple(coeff(p.monic()))
def reciprocal(p):return Poly.from_list(list(reversed(p.all_coeffs())),x,modulus=p.get_modulus()).monic()
def order(p,n):
 e=n
 for prime in dict(__import__('sympy').factorint(n)):
  while e%prime==0 and Poly(x**(e//prime)-1,x,modulus=p.get_modulus()).rem(p).is_zero:e//=prime
 return e

def main(out):
 out.mkdir(parents=True,exist_ok=False)
 linear=[]
 for q in primerange(3,102):
  q=int(q)
  for n in divisors(q-1):
   n=int(n)
   options=[t for t in combinations_with_replacement([int(a) for a in divisors(n) if a>=3],3) if lcm(*t)==n]
   if not options:continue
   best=min(options,key=lambda t:(max(t),t))
   linear.append(dict(q=q,n=n,orders=list(best),e_R=n,relaxation_factor=n/max(best)))
 assert len(linear)==118 and sum(row['relaxation_factor']>1 for row in linear)==38
 linear.sort(key=lambda r:(-r['relaxation_factor'],r['q'],r['n']))
 structural=[];allpairs=[];branches=0;properbranches=0
 for q in [3,5,7,11,13]:
  for n in range(2,21):
   if gcd(q,n)!=1:continue
   M=Poly(x**n-1,x,modulus=q)
   factors=sorted([a.monic() for a,m in factor_list(M)[1]],key=key)
   ids={key(a):i for i,a in enumerate(factors)}
   reciprocal_ids=[ids[key(reciprocal(a))] for a in factors]
   orders=[order(a,n) for a in factors]
   E={};pairbranches=0
   for cmask in range(1,1<<len(factors)):
    ci=[i for i in range(len(factors)) if cmask>>i&1]
    if any(cmask>>reciprocal_ids[i]&1 for i in ci):continue
    # D generator is a subset of C's irreducibles. Nonempty iff D proper.
    dmask=cmask
    while True:
     dmask=(dmask-1)&cmask
     quotient=[i for i in ci if not(dmask>>i&1)]
     if quotient:
      pairbranches+=1;branches+=1
      if dmask:
       properbranches+=1
       e=lcm(*(orders[i] for i in quotient))
       if e not in E:
        gC=Poly(1,x,modulus=q);gD=Poly(1,x,modulus=q)
        for i in ci:gC*=factors[i]
        for i in ci:
         if dmask>>i&1:gD*=factors[i]
        f=gC.exquo(gD)
        assert M.rem(gC*reciprocal(gC)).is_zero
        assert gD.degree()>0 and order(f,n)==e
        E[e]=dict(gC=coeff(gC),gD=coeff(gD),f=coeff(f),e=e,kC=n-gC.degree(),kD=n-gD.degree())
     if dmask==0:break
   allpairs.append(dict(q=q,n=n,branches=pairbranches,proper_periods=sorted(E)))
   if E:
    vals=sorted(E);best=max(vals)
    triples=list(combinations_with_replacement(vals,3))
    maxlcm=max(lcm(*t) for t in triples)
    witnesses=[t for t in triples if lcm(*t)==maxlcm]
    tri=min(witnesses,key=lambda t:(max(t),sum(t),t))
    assert best==maxlcm==n
    structural.append(dict(q=q,n=n,E2=vals,max_single=best,max_lcm3=maxlcm,witness=list(tri),witness_branches=[E[e] for e in tri]))
   print(q,n,'branches',pairbranches,'proper periods',sorted(E),flush=True)
 assert len(allpairs)==81 and branches==20724
 assert len(structural)==27
 result=dict(selection_rule='q odd prime <=101, n>=3 divides q-1; 3<=m1<=m2<=m3, mi|n, lcm=n; minimize (max(mi),lexicographic triple)',linear_families=linear,proper_D_pairs=structural,all_pairs=allpairs,total_branches=branches,total_proper_D_branches=properbranches)
 (out/'review_tables.json').write_text(json.dumps(result,indent=2,default=int)+'\n')
 with (out/'table4_optimal.csv').open('w',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=['q','n','orders','e_R','relaxation_factor']);wr.writeheader();wr.writerows(linear)
 with (out/'table9_distance_constrained.csv').open('w',newline='') as f:
  cols=['q','n','E2','max_single','max_lcm3','witness'];wr=csv.DictWriter(f,fieldnames=cols);wr.writeheader();wr.writerows({k:r[k] for k in cols} for r in structural)
 print('PASS 118 families;38 factor>1;27 proper-D pairs;81 total pairs;20724 branches',flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);main(p.parse_args().out)
