#!/bin/sh
# Fresh output directory required; never replace shipped or prior PDFs.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
OUT=${1:?Usage: sh supporting_programs/tools/build_pdf.sh NEW_OUTPUT_DIRECTORY}
case "$OUT" in /*) ;; *) OUT="$ROOT/$OUT" ;; esac
if [ -e "$OUT" ]; then echo "Refusing existing output directory: $OUT" >&2; exit 1; fi
mkdir -p "$OUT"
cd "$ROOT/submission"
latexmk -pdf -interaction=nonstopmode -halt-on-error -outdir="$OUT" -jobname=Idempotent_QSC_REVIEW_CORRECTED_V18 Idempotent_QSC_FINAL.tex
