# Single-paragraph formatting — V8

Merged exactly the four user-selected Introduction paragraphs, from “Building on these frameworks” through “rather than to claim a larger unrestricted window”, into one paragraph by replacing the three internal blank-line separators with spaces. All wording, mathematics and citation commands unchanged: tokenized whole-source equality verified. The following paper-organisation paragraph remains separate. Exact diff saved.

Before source SHA-256: `3d1cf1c5b718db0a441ff7252733aba75e99147687d6ca881fa0179e1454e984`. After source SHA-256: `34c679f918ca7230765816f5c48142e06bf04618345b990d8a940f695cb02b83`.

Fresh latexmk/pdfLaTeX/BibTeX build exit0; no unresolved citations/references. Layout advisories recorded in build log. PDF: `/home/user/audit_workspace/audit/working_copies/REVIEW_ERRORS_V8/submission/Idempotent_QSC_REVIEW_CORRECTED_V8.pdf`; SHA-256 `60c42c0ad05079cdc06dcf7929bf23b21c40961ef7ac28a89f414d9966f814c8`. All 1220 pre-existing project/backup files unchanged. Prior PDFs/sources/ZIPs/manifests retained; only new V8 checksum generated. No GitHub action. Stop for PDF review.
