# Introduction three-paragraph removal — V4

Removed exactly the user-selected block beginning “For message-carrying markers, this distinction has an additional consequence.” and ending with the paragraph concluding “the design role of the ring decomposition in this setting.” The following paper-organisation paragraph is retained. Removed text saved verbatim in REMOVED_PARAGRAPHS.tex, exact diff in EXACT_SOURCE_DIFF.patch. All remaining source bytes and all main sections unchanged from V3.

Source before SHA-256: `54abd61d12b79efcd8ecb82e9ba81343efdd9f9436f1c77afa37166153cf8855`.
Source after SHA-256: `7bc89489ca27e81a9894dd0a58fc6de95eeabca43d530b0b5284ffa382a4a041`.

Fresh latexmk/pdfLaTeX/BibTeX build exit0; no unresolved citation/reference warnings. PDF: `/home/user/audit_workspace/audit/working_copies/REVIEW_ERRORS_V4/submission/Idempotent_QSC_REVIEW_CORRECTED_V4.pdf`; SHA-256 `275a237d210f10bb931b093a9968072c077b21339bc30d74df6431e514d7c769`. Commands, outputs and any installation records saved separately. Previously authorized pinned minimal toolchain reinstalled only if missing, with no apt-get update.

All 861 pre-existing project/backup files unchanged. Earlier sources/PDFs/ZIPs preserved. New working-copy manifest regenerated only in V4. No GitHub operation or other correction. Stop for visual PDF review.
