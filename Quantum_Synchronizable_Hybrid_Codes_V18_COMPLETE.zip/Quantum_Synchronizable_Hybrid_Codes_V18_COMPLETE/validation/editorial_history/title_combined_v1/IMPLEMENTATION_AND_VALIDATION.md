# User-combined title — V14

Applied user wording “Quantum Synchronizable Hybrid Codes from Cyclic Codes over Fq[v]/(v^3-v)” with correctly typeset mathematical ring notation, removing only the pasted duplicate rendering of that notation. Matching short running head “Quantum Synchronizable Hybrid Codes”. Only the single title command differs from V13; exact diff saved. No other manuscript edits.

Source SHA-256 `657e66cc301917f8d26ecf03533c1c21b8d6eb33e1f58ba30b96daf549073f67`. Fresh latexmk/pdfLaTeX/BibTeX build exit0; no unresolved citations/references. Layout advisories retained in log. PDF `/home/user/audit_workspace/audit/working_copies/REVIEW_ERRORS_V14/submission/Idempotent_QSC_REVIEW_CORRECTED_V14.pdf`; SHA-256 `4f9b9137b71df512f4629e6e58dffc209901a8e9534d07bf17e3c70afb8267e4`. All 1809 pre-existing project/backup files unchanged. Prior sources/PDFs/ZIPs/manifests retained. V14 manifest generated only. No GitHub action. Stop for visual review.
