# Review-error corrections — implementation, adjudication and validation

**User authorization:** apply the uploaded report's verified corrections in a new copy, include expanded Introduction V3, save all artifacts and install the approved minimal toolchain for PDF compilation. No author approval is claimed beyond the user's stated scope.

## Locations

New source: `/home/user/audit_workspace/audit/working_copies/REVIEW_ERRORS_V1/submission/Idempotent_QSC_FINAL.tex`  
Updated PDF: `/home/user/audit_workspace/audit/working_copies/REVIEW_ERRORS_V1/submission/Idempotent_QSC_REVIEW_CORRECTED.pdf`  
Evidence/report directory: `/home/user/audit_workspace/audit/review_errors_v1`

Expanded V3 Introduction was integrated as explicitly chosen in clarification; scoped observation-model and no-gain explanation was added. Earlier approved copies and all original/backup artifacts remain unchanged.

## Item-by-item decision (uploaded review numbering)

| Item | Decision and action |
|---|---|
| 1 | Verified finite/global ambiguity. Abstract, relaxation discussion and conclusion now make factor12 a finite q≤101 result. Verified examples factor30 at(211,210), factor35 at(281,280). An explicit unbounded-family argument is stated, invoking standard Dirichlet existence of primes1 modulo n; pairwise-coprime(t,t+1,2t+1),t≥3 give factor t(t+1). These linear families have d_X=1. |
| 2 | Independently reproduced **118 pairs /38 factor>1** for the explicit all-divisor-triples rule. Rebuilt relaxation CSV/JSON and displayed all seven pairs with factor≥6, including ties; no misleading “six largest” list. Tie-break=min(max order,lexicographic triple). This does not prove the older74-family run was false under an undocumented rule; new coverage is explicitly defined. |
| 3 | Complete factor-set enumeration of all81 eligible pairs gives **27 proper-D-admissible pairs**, all max single=max triple LCM=n. Full27-row table replaces the earlier partial table; all other54 pairs have no such branch. Scope and question updated. No infeasible full codeword-distance enumeration claimed. |
| 4 | Added and proved proper-D equivalence for d_X≥2 in a nontrivial dual-containing branch. Captions/text use proper D with the equivalent weight cutoff. Does not generalize this equivalence to t≥3. |
| 5 | Consistent underlying parameters **[[39,3:9,0,3]]_3**;4 of9 classical-symbol slots used by y=(0,2,2);12-cell window;75 padded qudits. New expanded Introduction and abstract/conclusion distinguish capacity, messages, unpadded/padded lengths and distance scope. |
| 6 | **Review premise rejected after primary check.** TN v2 §2.3 explicitly uses `[\![n,k\!:\!m,r,d]\!]`, i.e. double quantum brackets, not the claimed single brackets. Saved exact primary excerpt. Retained correct double brackets and clarified q-ary parameter-role adaptation; no false notation change. |
| 7 | Added proof of injectivity at y=deg f and that this family fills the quotient (including zero), giving a collision for every nonzero shift. Explained why marker construction reserves capacity and restricts y≤deg f−1. P1-001 boundary +1 retained; full M_i=deg f_i distinguished from marker y_i. |
| 8 | Added exact/corrected-marker-syndrome assumption in Introduction, recovery section and conclusion. Necessity is for ideal observation-map injectivity. No noisy-syndrome or joint physical-error/offset decoder theorem claimed. The limitation is disclosed, not falsely “solved.” |
| 9 | Defined inactive C_i=D_i via f_i=1,e_i=1 convention; constant zero observation. Added convention at first definitions and fusion statement/proof. No multiplicative order in a zero quotient ring asserted. |
| 10 | New expanded Introduction explicitly credits established idempotent/CSS/order tools and notes elementary e_i|n→LCM≤n; contribution is model-specific analysis/parameter accounting, not a claim of new unrestricted window gain. |
| 11 | Crossref directly confirmed TN page/article identifier2100730 and Liu2024 DOI10.1007/s11128-023-04248-y. Added only these two missing fields to the NEW bibliography.16 keys unchanged; BibTeX warning resolved. |
| 12 | **Partly snapshot-dependent:** source project already contained scripts; older delivered minimal ZIP excluded non-build tooling. Preserved all old artifacts. New working copy includes supplied scripts, corrected test import paths, fresh outputs, independent table-regeneration script and explicit current data mapping. Legacy experiment program is marked as such, not represented as regenerating the corrected118/27 tables. README/build script updated for real layout. Old74-row/partial data remain in prior immutable copies. |
| 13 | Short running title replaced by “Idempotent Synchronizable Hybrid Codes”; full title unchanged. |

The uploaded review's theorem/table numbers and7-fusion-row count refer to a different snapshot. Changes were located by exact labels/content in the approved cumulative source, not copied by those numbers. No supplied `Idempotent_QSC_CORRECTED.pdf` existed in the attachment, so the source was independently checked and rebuilt here.

## Fresh validation

- New independent factor-set program: **81 pairs,20724 branches**, matching the preserved census. Proper-D subset **27 pairs**, every maximum n. It uses reciprocal-factor disjointness and exact polynomial arithmetic; per-triple polynomial witnesses and full E2 period sets saved. The proof proper-D⇔d_X≥2 avoids full high-dimensional codeword enumeration; it does not assert the exact distance of each witness is2.
- Explicit relaxation search:118 selected pairs,38 factor>1; all7 with factor≥6 displayed; maximum12 in q≤101. Larger examples verified using actual primitive elements and gg* divisibility. Unboundedness follows from the written proof plus Dirichlet; finite tests alone do not prove it.
- Marker-family test: y2 has9/9 residues, y3 has27/27, y4 has27 distinct out of81. At y3 every nonzero shift collides via the zero residue. Inactive-component observation test passes.
- Supplied theorem suite rerun in NEW copy: **751 checks /0 failures**,45.9s.
- Supplied theory suite completed: **8794 nested pairs /0 mismatches**,1466 dual-containing branches /0 mismatches;60/60 boundary cases;11 triples all identities true; total443.1s. Full logs and JSON retained. A tool call timed out waiting at180s, but the same running process was allowed to finish; it was not duplicated or reported successful early.
- Quantum suite:18 bridge instances,6 CSS instances,13 recovery cases,4 nonfree instances; assertions pass,152.2s. The report's “not verifiable because programs missing” conclusion is not valid for the complete current source project.
- **16 citation keys** resolve; all39 source reference labels resolve, no duplicated labels. P1-001/P1-003 mathematical/attribution intent retained; unrelated P1-004 historical22-case provenance unchanged.

## Build and PDF status

Approved pinned installation succeeded without `apt-get update`:17 required new packages, no upgrades/removals. Exact command, all installed versions and package snapshots saved in this directory. Compiler/build command saved in `COMPILE_COMMAND.txt`; latexmk/pdfLaTeX/BibTeX exited0 and converged.

PDF: **14 pages**, **413461 bytes**; SHA-256 `0374eb2492ffe5107a89ec24f69ed04b00a707e14d18e50aa18ff5ac28057e8b`.  
Source SHA-256 before(new copy base): `d5d2445a10175c68e033ed86aec8d115c6d54ede7bb59c11bca06d07d9bfe9e2`.  
Source SHA-256 after: `40c50fd4009b4228aaeb5f54e2e39d21fa1b5233de6440d7e8bcb9e2a5886a24`.  
Bibliography before: `3d6af14d2b1a285b984800f44d649b892955b84ac29ac4e2e7373b19e9cfaea2`.  
Bibliography after: `a3c951abbb3d206fb6dced2361da708fb21121381a0c3582edb77e269d94e135`.

PDF parses and contains expanded Introduction, corrected coverage values, larger relaxation examples and article identifier.16 bibliography entries; no unresolved citations/references, no BibTeX warnings, no overfull boxes. **One nonfatal layout advisory remains:** `Underfull \vbox (badness10000) ... output is active` on page2; this is vertical spacing, not a compilation/mathematical error. No visual perfection claim is made; PDF is presented for user inspection.

## Exact records and preservation

- `MANUSCRIPT_CHANGES.diff`: exact source change from cumulative P1-001+P1-003 base.
- `CUMULATIVE_ORIGINAL_MANUSCRIPT.diff`: exact source change from immutable original.
- `BIBLIOGRAPHY_CHANGES.diff`: two fields only.
- `NEW_WORKING_COPY_CHANGE_MANIFEST.json`: before/after SHA-256 per changed/new working-copy file.
- `VALIDATION_RESULTS.json`, independent table JSON/CSVs, test logs/results, source review, Crossref records, original-notation excerpt and install/build logs all saved.
- All**573 pre-existing project/backup files** match pre-change hashes; authoritative original manifest **43/43** matches. Original PDFs, old FINAL ZIP, reports, manifests, evidence and backups unchanged. New checksum manifest generated only for this new working copy; its copied old stale manifest saved as historical evidence.

## Still not claimed

The observation-model limitation is disclosed, not a physical-error theorem. Global novelty, unrelated bibliography author discrepancies, higher-distance optimality and historical22-case provenance remain outside this correction task. Correcting verified review items does not certify every statement in the uploaded review. No GitHub modification, commit or push.

**STOP for visual review of the new PDF.** All source/evidence retained; no further correction without approval.

## Verification-run provenance note

The first independent-table run completed its mathematical assertions but failed while serializing a SymPy integer (`TypeError: Object of type One is not JSON serializable`). Its failure log is preserved as `TABLE_VERIFICATION.log`. Serialization was corrected in the new script, and a fresh output directory/run completed all assertions and wrote the verified tables (`TABLE_VERIFICATION_VERIFIED.log`, `independent_tables_verified/`). No failed run is used as the accepted output.
