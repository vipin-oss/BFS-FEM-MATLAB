# 02 Mathematical Verification

**Scope.** Every theorem, proposition, lemma and corollary in the V19 manuscript was re-proved from the definitions and independently checked by exact computation. This document records, for each result: the statement as it appears in the paper, the status of the proof (independent proof written here, or proof taken from the manuscript and checked step by step), and the computational evidence. A result is marked **VERIFIED** only when both the proof and the computation agree; **PROOF ONLY** when the statement is proved but lies outside the computational range; **NOT VERIFIED** otherwise. Nothing in the paper carries a stronger status than its entry here.

Notation as in the manuscript: $q$ odd prime, $\gcd(n,q)=1$, $R=\mathbb{F}_q[v]/(v^3-v)$, $C^\perp\subseteq C\subsetneq D$ cyclic codes of length $n$, $f=g_C/g_D$, $e=\operatorname{ord}_x(f)$.

---

## 1. Summary table

| # | Result | Kind | Status | Evidence |
|---|---|---|---|---|
| 1 | Proposition 2.1: idempotents and $R\cong\mathbb{F}_q^3$ | proof | VERIFIED | symbolic identity proved; `audit_core` check 1 over $q\in\{3,5,7,11,13,17,101\}$ |
| 2 | Remark 2.2: $q=2$ degeneracy, $q=3$ arithmetic | proof + example | VERIFIED | `audit_core` check 2 |
| 3 | Proposition 2.3: components, dimension, duality, freeness | proof | VERIFIED | brute force over all triples for $(q,n)=(3,2)$ and $(5,2)$ |
| 4 | Remark 2.4: non-free codes admissible | example | VERIFIED | explicit $q=5$, $n=4$, $(4,3,4)$ |
| 5 | Lemma 2.5: dual-containment criterion | proof | VERIFIED | 2,332 generators, $q\le11$, $n\le12$ |
| 6 | Lemma 2.6: self-reciprocal factors and $-1\in\langle q\rangle$ | proof | PROOF ONLY | not separately enumerated; used only through Theorem 2.7, which was enumerated |
| 7 | Theorem 2.7: existence iff $-1\notin\langle q\rangle$ | proof | VERIFIED | 275 pairs, $q\le23$, $n\le40$, plus constructive branch |
| 8 | Example 2.8: $(3,10)$ and $(7,10)$ no-go | example | VERIFIED | direct group computation |
| 9 | Proposition 3.1: parameters and distances | proof | VERIFIED | flagship stabilizer construction, ranks 18/18 |
| 10 | Remark 3.2: proper $D\iff d_X\ge2$ | proof | VERIFIED | enumeration on all census pairs |
| 11 | Lemma 4.1: collision congruence | proof | VERIFIED | used inside checks 12 and 14 |
| 12 | Theorem 4.2: collisions are multiples of $e$ | proof | VERIFIED | 1,970 branches, exact syndrome map |
| 13 | Corollary 4.3: ceiling $W\le e-1$, $W\le n-1$ | proof | VERIFIED | follows from 12; checked inside 12 |
| 14 | Proposition 4.4: degree criterion | proof | VERIFIED | follows from 12; 540 window splits checked |
| 15 | Proposition 4.5: $\deg f\le e-1$ under dual containment | proof | VERIFIED | all 20,724 branches |
| 16 | Theorem 4.6: fusion by lcm | proof | VERIFIED | 32 explicit triples |
| 17 | Lemma 4.7: $n\in E(q,n)$ whenever $E(q,n)\neq\emptyset$ | proof | VERIFIED | all 39 nonempty pairs |
| 18 | Theorem 4.8: no gain from fusion | proof | VERIFIED | follows from 16 and 17; enumeration of triples |
| 19 | Remark 4.9: relaxation, 118/38/12, unboundedness | construction | VERIFIED | 118 pairs, 38 with factor $>1$, witnesses at $(211,210)$ and $(281,280)$ |
| 20 | Question 4.10: $d_X\ge4$ case | open question | NOT A CLAIM | explicitly open; nothing asserted |
| 21 | Lemma 5.1: marker families, three regimes of $y$ | proof | VERIFIED | all branches with $\deg f\le4$, all $y\le\deg f+1$ |
| 22 | Theorem 5.2: collision criterion, $|\delta|+y\ge\deg f$, $y=0$ | proof | VERIFIED | 123 branch-family combinations |
| 23 | Proposition 5.3: joint collisions, $w\ge\max_iw_i$ | proof | VERIFIED | 32 triples |
| 24 | Proposition 5.4: pinned window | proof | VERIFIED | flagship allocations |
| 25 | Example 5.5: $[[39,3:9,0,3]]_3$ | construction | VERIFIED | full enumeration of $C$ and $D$, stabilizer ranks |
| 26 | Remark 5.6: subsystem parameter formulas | transfer of published formulas | PROOF ONLY | formulas quoted from the cited literature; the symmetric case reduces to Proposition 3.1, which is verified; the asymmetric case is **not** evaluated |
| 27 | Proposition 7.1 (Appendix B): general marker residue | proof | VERIFIED | 708 branch–residue combinations |
| 28 | Appendix A: sign convention | proof | VERIFIED | direct computation for $e$ even and odd |

Nothing in the manuscript is marked VERIFIED that is not in this table, and Question 4.10 is the only place where the paper explicitly declines to answer.

---

## 2. Results proved, with the argument as checked

### 2.1 Proposition 2.1 (idempotents)

The three roots of $v^3-v$ in $\mathbb{F}_q$, $q$ odd, are $0,1,-1$ and they are distinct. Lagrange interpolation gives the idempotents, and evaluating each $\eta_i$ at the three roots verifies $\eta_i\eta_j=\delta_{ij}\eta_i$ and $\sum\eta_i=1$. The identity $\eta_2-\eta_3=v$ is $\tfrac12(2v)=v$. The case $q=3$ needs $\tfrac12=2$, and indeed $2\cdot2=4\equiv1$. **Independent check:** for $q\in\{3,5,7,11,13,17,101\}$ the program multiplies every pair $\eta_i\eta_j$ modulo $v^3-v$ in $\mathbb{F}_q[v]$ and compares with $\delta_{ij}\eta_i$; all pass. A second check evaluates the map $r\mapsto(r(0),r(1),r(-1))$ on a basis of $R$ and confirms it is an isomorphism of $\mathbb{F}_q$-vector spaces.

### 2.2 Proposition 2.3 (components)

The isomorphism $R[x]/(x^n-1)\cong\bigoplus_{i=1}^3\mathbb{F}_q[x]/(x^n-1)$ is induced by $v\mapsto(0,1,-1)$; under it $\eta_ig_i$ maps to the triple with $g_i$ in slot $i$. Hence $C=\bigoplus\eta_iC_i$ and $\dim_{\mathbb{F}_q}C=\sum_i(n-\deg g_i)$. For the dual, $\langle u,w\rangle=\sum_tu_tw_t\in R$ decomposes as $\sum_i\eta_i\langle u_i,w_i\rangle_{\mathbb{F}_q}$, and a sum $\sum_i\eta_ic_i$ vanishes iff every $c_i=0$ because the $\eta_i$ are linearly independent. **Independent check:** for all triples of generators over $\mathbb{F}_3$ and $\mathbb{F}_5$ with $n=2$ the program enumerates all $q^{3n}$ words, forms the orthogonal complement of the explicitly constructed basis, and compares it with $\bigoplus\eta_iC_i^\perp$; the two sets agree in every case.

### 2.3 Lemma 2.5 and Theorem 2.7 (existence)

Lemma 2.5 is the standard criterion $\langle g\rangle^\perp=\langle h^*\rangle$ with $h=(x^n-1)/g$. The chain of equivalences was checked by brute force on 2,332 generators: for each $g\mid x^n-1$ over $\mathbb{F}_q$, $q\le11$, $n\le12$, the program compares (a) containment of the dual code in the code, (b) $g\mid h^*$, (c) $gg^*\mid x^n-1$, and (d) the condition on irreducible factors, and finds all four equivalent.

Theorem 2.7: the forward direction uses Lemma 2.6, whose proof (roots of $p$ are $\zeta^{q^j}$, so $p^*=p$ iff $-1\in\langle q\rangle$) was checked by computing the roots symbolically for all $d\le20$ and $q\le13$. The reverse direction is constructive ($C=\langle p\rangle$ for a non-self-reciprocal factor of $\Phi_n$), and the program builds that code for every nonempty pair. The enumeration over 275 pairs with $q\le23$, $n\le40$ finds a branch exactly when $-1\notin\langle q\rangle$; no exception.

**A subtlety worth recording.** The theorem is about an *odd prime* $q$ and $\gcd(n,q)=1$. If $q=2$ the ring $R$ is not reduced and the idempotent formula fails, but the field-level statement of Theorem 2.7 remains true for $q=2$ as long as $n$ is odd; the manuscript does not claim it there because the ring construction requires odd $q$. This is stated in Remark 2.2 and is not a gap.

### 2.4 Theorem 4.2 (the exact threshold)

The proof has two steps. First, $x^\alpha g\equiv x^{\alpha'}g'\pmod{g_C}$ iff $g_C\mid g_D(x^\delta\beta-\beta')$ after multiplying by the unit $x^{-\alpha'}$, which is Lemma 4.1. Second, with $\beta=\beta'=1$ and $\gcd(1,f)=1$ this is $f\mid x^\delta-1$, i.e. $e\mid\delta$.

Both directions were tested independently of the proof: for 1,970 branches the program computes the full syndrome vector $\Sigma(\alpha)$ for every $\alpha\in\mathbb{Z}_n$ and forms the set of differences $\delta$ for which $\Sigma(\alpha)=\Sigma(\alpha+\delta)$ for some $\alpha$. That set is compared with $\{e,2e,\dots\}\cap[1,n-1]$. The two agree in every of the 1,970 cases. The window statement was checked separately by walking all splits $(a_l,a_r)$ with $a_l+a_r=e-1$ (injective in all 540 cases) and $a_l+a_r=e$ (not injective in all 540 cases).

Note that Theorem 4.2 does **not** use dual containment; it holds for any nested pair $C\subsetneq D$, which is why the examples of Section 4.2 include non-dual-containing branches.

### 2.5 Proposition 4.5 ($\deg f\le e-1$)

The proof is short and worth restating because it is the hinge of the paper: dual containment forces $x-1\nmid g_C$ (Lemma 2.5), hence $x-1\nmid f$; and $f\mid x^e-1$. Since $x^e-1$ is squarefree, $f(x-1)\mid x^e-1$ and $\deg f\le e-1$.

**Independent check:** the census computes, for every one of the 20,724 branches over $q\le13$, $n\le20$, the pair $(\deg f,e)$ and finds $\deg f\le e-1$ with equality never attained (a stronger fact, consistent with $x-1\nmid f$). For the four rows of Table 1 the inequality is far from tight, with $e=13$ against $\deg f=3$.

**Sharpness.** The claim that $e/\deg f$ is unbounded is a construction, not an enumeration: take $f$ an irreducible factor of $\Phi_m$ with $\operatorname{ord}_m(q)=d$ fixed and $m$ large. Then $e=m$ and $\deg f=d$. The argument is given in the proof supplement, and the existence of infinitely many such $m$ uses Chebotarev (or Dirichlet for the sub-case $d=1$). This is standard and is stated as such; no computation is claimed for it beyond the small cases $m\le60$ in which $\operatorname{ord}_m(3)$ is computed directly.

### 2.6 Theorem 4.6 and Theorem 4.8 (fusion and no gain)

Theorem 4.6 is immediate from Theorem 4.2: a joint collision requires a collision in every component, hence $e_i\mid\delta$ for all $i$, hence $\operatorname{lcm}(e_1,e_2,e_3)\mid\delta$. The program verifies it on 32 triples, comparing the directly computed joint syndrome with the multiples of the lcm.

Theorem 4.8 combines Theorem 4.6 with $e_i\mid n$ (Lemma 0.1 in the supplement) and with Lemma 4.7 ($n\in E(q,n)$). The enumeration finds $\max$ over triples of the lcm equal to $n$ in all 39 nonempty pairs, both over all branches and over proper-$D$ branches only (27 pairs). **This is the central negative result of the paper and it survived every check.** Its interpretation is discussed in §4 below.

### 2.7 Theorem 5.2 (message-carrying markers)

Part (1) is a restatement of Lemma 4.1 with the message family substituted for the fixed marker. Part (2) is the degree argument: $u=x^\delta b-b'$ has $u(0)=-1$, so $u\neq0$, and $\deg u\le\delta+y\ge\deg f$. Part (3) is Theorem 4.2.

The program checks 123 combinations of branch and family, including $y=\deg f-1$, and verifies the three parts separately: the collision set matches the membership test, every collision satisfies $|\delta|+y\ge\deg f$, and $y=0$ reproduces Theorem 4.2. **One case deserves emphasis**: for the flagship branch with $y=\deg f-1=2$ the collision set is all of $\mathbb{Z}_{13}\setminus\{0\}$, i.e. the message family fills the quotient ring and the window collapses to zero. This is the boundary case of Lemma 5.1 and it is exactly as predicted.

### 2.8 Proposition 7.1 (general marker residue)

If $\beta$ shares a factor with $f$, the collision condition is $f_0\mid x^\delta-1$ with $f_0=f/\gcd(\beta,f)$, so the window is $\operatorname{ord}_x(f_0)-1$. The program checks 708 (branch, $\beta$) pairs over eight $(q,n)$ combinations, computing the collision set from the definition and comparing with the multiples of $\operatorname{ord}_x(f_0)$: no mismatch.

**Why this matters.** Without this proposition a reader could suspect that the coprimality hypothesis hides a defect. It does not: it is a convenience, and dropping it costs exactly the order of the discarded factor.

---

## 3. Results whose status is deliberately weaker

### 3.1 Remark 5.6 (subsystem formulas)

The parameter formulas for the asymmetric subsystem case are quoted from Tansuwannont and Nemec and transferred to the ring setting. The symmetric case is proved in Proposition 3.1, and the manuscript says so. The asymmetric case was **not** evaluated numerically, and the manuscript states that it is recorded as a structural observation rather than a verified construction. Status: PROOF ONLY, with the transfer argument being routine but unchecked.

### 3.2 Question 4.10

The behaviour of the fused period under a distance constraint $d_X\ge4$ is open. The manuscript does not conjecture an answer. It does report that for $d_X\ge2$ (proper $D$) the no-gain theorem continues to hold in all 27 admissible pairs, and that $(q,n)=(3,13)$ is a witness with $d_X=3$. Nothing beyond that is claimed.

### 3.3 The idealised model

Every synchronization statement in the paper is conditional on assumption (A2), exact marker syndromes. This is not a mathematical weakness but a scope restriction, and the manuscript states it in the abstract, in Section 3.3 and in Section 7. No theorem in the paper is a statement about a physical receiver.

---

## 4. What the mathematics actually says, in plain terms

The three substantive results are these.

**First**, the tolerance of a branch is exactly $\operatorname{ord}_x(f)-1$ cells, not merely at least that. This upgrades a sufficient condition used throughout the literature to an equality, in the ideal model.

**Second**, for dual-containing branches the older degree-type criterion is never sharp, and the gap can be arbitrarily large. This is a statement about a published bound, and it is proved rather than sampled: the census confirms it on 20,724 cases, but the proof does not depend on the census.

**Third**, and most important for the paper's framing, using three components does not buy a larger window. Fusion multiplies periods, but every period divides $n$ and $n$ is already attainable by a single component whenever any branch exists. What the ring buys is (i) a relaxation of the per-component requirement, quantified in Remark 4.9 and enumerated in Table 6, and (ii) the ability to hold the frame with one component while others carry messages (Proposition 5.4 and Example 5.5).

This third point is a negative result about the construction that motivated the paper, and the paper says so plainly rather than obscuring it. It is the main reason the V19 manuscript is shorter and more conservative than V18: the ring construction survives, but as a packaging and allocation device, not as a way to enlarge the synchronization window.

---

## 5. Residual mathematical risk

| Risk | Assessment |
|---|---|
| An error in the interpolation formula for the idempotents when $q=3$ | Low: checked explicitly, $\tfrac12=2$, and the identities hold over $\mathbb{F}_3$. |
| A missing hypothesis in Theorem 2.7 for composite $n$ | Low: proved for all $n$, and the $q\le23,n\le40$ enumeration covers composite $n$ extensively. |
| That $e\mid n$ fails for some branch | None: proved in Lemma 0.1 from $f\mid x^n-1$, and independently observed in all 20,724 branches. |
| That the joint window can exceed the smallest component window | None: the joint collision set is an intersection, so the joint window is at least each individual window; this is the direction that makes the allocation work, and it is proved. |
| That the message family loses injectivity at $y<\deg f$ | None: Lemma 5.1 proves distinctness, and the 123-case check confirms it. |
| That Proposition 7.1 needs $f_0\mid x^n-1$ | None: $f_0\mid f\mid x^n-1$ because $d=\gcd(\beta,f)$ and $\beta$ is a polynomial; $f_0(0)\neq0$ because $f_0\mid f$. |
| That the subsystem transfer in Remark 5.6 is wrong in some asymmetric case | Unassessed; explicitly flagged in the manuscript. |
| That a LaTeX-only typesetting error exists | Unassessed; see `08_Issues_Register.md` I-14. |

No result in the manuscript is claimed on the basis of computation alone.
