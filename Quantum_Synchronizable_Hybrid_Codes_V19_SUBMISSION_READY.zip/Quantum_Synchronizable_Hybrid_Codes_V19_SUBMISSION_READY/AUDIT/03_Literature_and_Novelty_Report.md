# 03 Literature and Novelty Report

**Purpose.** To establish, record by record, that every reference in the V19 bibliography exists and is cited accurately, and to position the contribution honestly against the prior art. No claim of novelty is made that could not be defended in front of an author of one of the cited papers.

**Method.** Each entry was resolved through the Crossref REST API and, where Crossref was unreachable from this environment, through the Semantic Scholar Graph API. The retrieved title, author list, journal, volume, issue, pages or article number, year and DOI were compared with the entry in `MANUSCRIPT/References.bib`. Discrepancies were corrected in the `.bib`, never in the record. The raw responses are preserved in `REPRODUCIBILITY/generated_data/crossref_report.json`; the script that produced them is `REPRODUCIBILITY/source_code/verify_refs.py`.

A note on the infrastructure: direct HTTPS requests to `api.crossref.org` from the sandbox failed with a TLS handshake reset for all 36 attempted DOIs. The same queries were then issued through the page-fetch tool, which does have outbound access, and Crossref answered normally there. This is recorded because it explains why `verify_refs.py` cannot be re-run unmodified inside the sandbox; the responses it would produce are in the JSON file.

---

## 1. Reference-by-reference verification

### 1.1 Synchronizable codes: the founding and order-based papers

| Key | Verified metadata | Status |
|---|---|---|
| `BoseCaldwell1967` | R. C. Bose, J. G. Caldwell, "Synchronizable error-correcting codes", *Information and Control* **10**(6), 616–630 (1967), DOI 10.1016/S0019-9958(67)91048-0 | VERIFIED |
| `Fujiwara2013` | Y. Fujiwara, "Block synchronization for quantum information", *Phys. Rev. A* **87**, 022344 (2013), DOI 10.1103/PhysRevA.87.022344 | VERIFIED |
| `FujiwaraTonchevWong2013` | Y. Fujiwara, V. D. Tonchev, T. W. H. Wong, "Algebraic techniques in designing quantum synchronizable codes", *Phys. Rev. A* **88**(1), 012318 (2013), DOI 10.1103/PhysRevA.88.012318 | VERIFIED |
| `FujiwaraVandendriessche2014` | Y. Fujiwara, P. Vandendriessche, "Quantum synchronizable codes from finite geometries", *IEEE Trans. Inf. Theory* **60**(11), 7345–7354 (2014), DOI 10.1109/TIT.2014.2357029 | VERIFIED |
| `XieYuanFujiwara2014` | Y. Xie, J. Yuan, Y. Fujiwara, "Quantum synchronizable codes from quadratic residue codes and their supercodes", arXiv:1403.6192 (2014), DOI 10.48550/arXiv.1403.6192 | VERIFIED as a preprint; no journal version located |
| `XieYangYuan2016` | Y. Xie, L. Yang, J. Yuan, "$q$-ary chain-containing quantum synchronizable codes", *IEEE Commun. Lett.* **20**(3), 414–417 (2016), DOI 10.1109/LCOMM.2015.2512261 | VERIFIED |
| `GuendaEtAl2017` | K. Guenda, G. G. La Guardia, T. A. Gulliver, "Algebraic quantum synchronizable codes", *J. Appl. Math. Comput.* **55**, 393–407 (2017), DOI 10.1007/s12190-016-1042-7 | VERIFIED |
| `LuoMa2018` | L. Luo, Z. Ma, "Non-binary quantum synchronizable codes from repeated-root cyclic codes", *IEEE Trans. Inf. Theory* **64**(3), 1461–1470 (2018), DOI 10.1109/TIT.2018.2795479 | VERIFIED |
| `LuoMaLin2019` | L. Luo, Z. Ma, D. Lin, "Two new families of quantum synchronizable codes", *Quantum Inf. Process.* **18**, 277 (2019), DOI 10.1007/s11128-019-2389-0 | VERIFIED |
| `LiZhuLiu2019` | L. Li, S. Zhu, L. Liu, "Quantum synchronizable codes from the cyclotomy of order four", *IEEE Commun. Lett.* **23**(1), 12–15 (2019), DOI 10.1109/LCOMM.2018.2877989 | VERIFIED |
| `ShiYueHuang2021` | X. Shi, Q. Yue, X. Huang, "Quantum synchronizable codes from the Whiteman's generalized cyclotomy", *Cryptogr. Commun.* **13**, 727–739 (2021), DOI 10.1007/s12095-021-00501-2 | VERIFIED |
| `LiZhu2022` | Z. Li, S. Zhu, "Two classes of quantum synchronizable codes", *Int. J. Theor. Phys.* **61**(10), 251 (2022), DOI 10.1007/s10773-022-05163-1 | VERIFIED (metadata only; full text not obtained) |
| `LiuKai2023` | T. Liu, X. Kai, "Some quantum synchronizable codes with explicit distance", *J. Appl. Math. Comput.* **69**, 1751–1764 (2023), DOI 10.1007/s12190-022-01811-1 | VERIFIED |
| `SunEtAl2023` | S. Sun, T. Yan, Y. Sun, T. Wang, X. Wang, "Non-binary quantum synchronizable codes based on cyclic codes over $\mathbb{F}_q$", *Quantum Inf. Process.* **22**, 72 (2023), DOI 10.1007/s11128-022-03794-1 | VERIFIED |
| `TansuwannontNemec2026` | T. Tansuwannont, A. Nemec, "Synchronizable hybrid subsystem codes", *IEEE Trans. Quantum Eng.* **7**, article 2100730 (2026), DOI 10.1109/TQE.2026.3673092 | VERIFIED; see §2 |

### 1.2 Synchronizable codes over rings and related constructions

| Key | Verified metadata | Status |
|---|---|---|
| `LiuLiu2021` | H. Liu, X. Liu, "Quantum synchronizable codes from finite rings", *Quantum Inf. Process.* **20**(3), 125 (2021), DOI 10.1007/s11128-021-03058-4 | VERIFIED |
| `DaiLiu2022` | Y. Dai, X. Liu, "QSCs from the Euclidean sums of cyclic codes over finite rings", *Quantum Inf. Process.* **21**, 295 (2022), DOI 10.1007/s11128-022-03625-3 | VERIFIED |
| `DuMaLiu2023` | C. Du, Z. Ma, Y. Liu, "Quantum synchronizable codes from repeated-root quasi-cyclic codes", *Comput. Appl. Math.* **42**, 161 (2023), DOI 10.1007/s40314-023-02298-7 | VERIFIED |
| `DuMaLuoWang2020` | C. Du, Z. Ma, L. Luo, D. Huang, H. Wang, "On a family of quantum synchronizable codes based on the $(\lambda(u+v)\lvert u-v)$ construction", *IEEE Access* **8**, 8449–8458 (2020), DOI 10.1109/ACCESS.2019.2963289 | VERIFIED |
| `LiuHuLiu2024` | J. Liu, P. Hu, X. Liu, "Quantum synchronizable codes from the ring $\mathbb{F}_q+v\mathbb{F}_q$", *Quantum Inf. Process.* **23**(2), 44 (2024), DOI 10.1007/s11128-023-04248-y | VERIFIED |

### 1.3 Quantum codes from ring decompositions

| Key | Verified metadata | Status |
|---|---|---|
| `DinhBagUpadhyay2021` | H. Q. Dinh, T. Bag, A. K. Upadhyay, M. Ashraf, G. Mohammad, W. Chinnakum, "Quantum codes from a class of constacyclic codes over finite commutative rings", *J. Algebra Appl.* **19**(12), 2150003 (2020), DOI 10.1142/S0219498821500031 | VERIFIED. The key name is misleading (the year in the key is not the publication year) but the entry itself is correct. |
| `DinhEtAl2021` | H. Q. Dinh, T. Bag, A. K. Upadhyay, R. Bandi, W. Tansuchat, "A class of skew cyclic codes and application in quantum codes construction", *Discrete Math.* **344**(2), 112189 (2021), DOI 10.1016/j.disc.2020.112189 | VERIFIED |

### 1.4 Classical coding theory used

| Key | Verified metadata | Status |
|---|---|---|
| `Massey1964` | J. L. Massey, "Reversible codes", *Information and Control* **7**(3), 369–380 (1964), DOI 10.1016/S0019-9958(64)90438-3 | VERIFIED |
| `YangMassey1994` | X. Yang, J. L. Massey, "The condition for a cyclic code to have a complementary dual", *Discrete Math.* **126**(1–3), 391–393 (1994), DOI 10.1016/0012-365X(94)90283-6 | VERIFIED |
| `CalderbankShor1996` | A. R. Calderbank, P. W. Shor, "Good quantum error-correcting codes exist", *Phys. Rev. A* **54**(2), 1098–1105 (1996), DOI 10.1103/PhysRevA.54.1098 | VERIFIED |
| `Steane1996` | A. M. Steane, "Multiple-particle interference and quantum error correction", *Proc. R. Soc. Lond. A* **452**(1954), 2551–2577 (1996), DOI 10.1098/rspa.1996.0136 | VERIFIED |
| `KribsLaflammePoulin2005` | D. Kribs, R. Laflamme, D. Poulin, "Unified and generalized approach to quantum error correction", *Phys. Rev. Lett.* **94**(18), 180501 (2005), DOI 10.1103/PhysRevLett.94.180501 | VERIFIED |

**Total: 27 entries, 27 verified.** No entry is retained on the authority of the V18 package.

---

## 2. The Tansuwannont–Nemec reference in detail

This entry matters more than the others because the V19 framing leans on it for the hybrid parameter notation and for the claim that the trade-off between synchronization, gauge freedom and classical capacity is the subject of current work.

| Field | Value |
|---|---|
| Authors | Theerapat Tansuwannont, Andrew Nemec |
| Title | Synchronizable hybrid subsystem codes |
| Preprint | arXiv:2409.11312v2, 25 September 2024 |
| Journal | IEEE Transactions on Quantum Engineering |
| Volume | 7 |
| Pages | article number 2100730 |
| Year | 2026 |
| DOI | 10.1109/TQE.2026.3673092 |
| Online | 11 March 2026 |
| Affiliations | Osaka University (Tansuwannont); University of Texas at Dallas and Duke University (Nemec) |

V18's entry for this paper was already correct in its identifying data: same authors, same title, same volume, article number 2100730, same DOI, with an arXiv note. V19 keeps those fields, drops the arXiv note so that the entry points at the published version only, and adds the explicit article-number label. No correction of substance was needed here; the entry is recorded in full because the V19 framing depends on it.

**What the paper does.** It unifies quantum synchronizable codes, hybrid codes and subsystem codes, and proves trade-offs between the number of tolerable misalignments, the number of gauge qudits and the number of classical symbols that can be transmitted. The parameter notation $[[N,K:M,R_g,d]]_q$ used in V19 follows the roles assigned to these symbols there.

**What V19 takes from it.** The notation, the framing of the problem as one with three resources, and the symmetric special case used in Remark 5.6. V19 does **not** claim an improvement on that paper's trade-offs, and the comparison in Section 7 is explicit that the present construction is a very special case of the framework.

**What V19 does not take from it.** No theorem, no proof technique, no numeric bound. Every result in V19 is proved from scratch.

---

## 3. What changed in the bibliography relative to V18

V18's bibliography is internally consistent: 16 entries, 16 `\bibitem`s in the shipped `.bbl`, and 16 distinct cited keys, with no dangling reference in either direction. The comparison below was made field by field between the two `.bib` files, and each discrepancy was resolved against Crossref, not against either file.

### 3.1 Entries whose metadata was wrong in V18 and is corrected

| Key | V18 | Crossref | V19 |
|---|---|---|---|
| `DuMaLiu2023` | Du, **Chengcheng**; Ma, Zhi; Liu, **Yaru** | Du, **Chao**; Ma, Zhi; Liu, **Yiting**; *Comput. Appl. Math.* **42**(4), 161 | Corrected, with the issue number added |
| `DinhEtAl2021` | Upadhyay, **Ashok** Kumar | Upadhyay, **Ashish K.** | Corrected |

Neither error would have been caught by a key check: the titles, journals, volumes and DOIs were right, and only the given names were wrong. They matter because a reader searching for the first author of the second entry under "Ashok" finds nothing.

### 3.2 Entries completed or normalised

| Key | Change | Reason |
|---|---|---|
| `FujiwaraVandendriessche2014` | Issue number 11 added | IEEE TIT **60**(11) |
| `TansuwannontNemec2026` | arXiv note removed; article number kept | The entry should point at the published version |
| `LiuHuLiu2024`, `SunEtAl2023` | Math in the title written as plain `{F}_q` | The PDF renderer prints raw `\mathbb{F}_q` literally in a bibliography; the metadata is unchanged |

### 3.3 Entries added

Eleven works are cited in V19 that were not in V18. Each is verified in §1.

| Key | Why it is cited |
|---|---|
| `BoseCaldwell1967` | Origin of classical synchronizable codes |
| `CalderbankShor1996` | The CSS construction |
| `Steane1996` | The CSS construction |
| `KribsLaflammePoulin2005` | Origin of hybrid quantum-classical codes |
| `GuendaEtAl2017` | Algebraic account of the QSC framework |
| `LiZhuLiu2019` | Cyclotomic QSCs |
| `ShiYueHuang2021` | Cyclotomic QSCs |
| `LiZhu2022` | Recent QSC families |
| `LiuKai2023` | QSCs with explicit distance |
| `DuMaLuoWang2020` | QSCs from the $(\lambda(u+v)|u-v)$ construction |
| `DinhBagUpadhyay2021` | Ring-based quantum codes via the CRT |

The first four are the ones a referee would notice first. A paper on quantum synchronizable hybrid codes that cites neither the origin of classical synchronization nor the CSS construction nor the origin of hybrid codes is under-referenced regardless of how good its bibliography hygiene is, and V18's 16-entry list had that gap. V19 does not repeat it.

### 3.4 What was checked, and how

| Check | Result |
|---|---|
| Every DOI resolves | 27 of 27 through Crossref or Semantic Scholar; four preprints/papers resolved through their own records |
| Title matches the record | 27 of 27 |
| Author list matches the record | 27 of 27 after the two corrections above |
| Volume, issue, pages/article number match | 27 of 27 |
| Every entry cited in the text | 27 of 27 (`check_tex.py` reports no uncited entry) |
| Every citation has an entry | 27 of 27 |

The one limitation is recorded in §5: full text was not obtained for `LiZhu2022`, and its metadata is taken from Crossref without an abstract check.

## 4. Novelty position

### 4.1 What is certainly not new

* The ring $\mathbb{F}_q[v]/(v^3-v)$ or its generalisations as a source of decomposable cyclic codes, and the idempotent decomposition into three field components. Both appear in the quantum-code literature on rings [Dinh et al. 2020, 2021].
* The order criterion: the tolerance of a synchronizable code is governed by $\operatorname{ord}_x(f)$. This originates with Fujiwara, Tonchev and Wong (2013) and is used throughout the $q$-ary literature.
* The converse of the order criterion. A reader of Fujiwara–Tonchev–Wong would not be surprised: the order is described there as the period of the marker, and a period is by definition the smallest shift that returns the marker to itself. The V19 proof is a clean derivation from the collision lemma, not a discovery.
* Hybrid quantum-classical codes, and synchronizable hybrid codes in particular, including the resource trade-offs. This is the subject of Tansuwannont and Nemec (2026), and the present construction is a special case of their framework.
* The observation that a nested pair $C\subseteq D$ over a decomposable ring reduces to three nested pairs over a field. This is exactly what the decomposition is for.

### 4.2 What is, to the best of the search, not in the literature

* **The uniform application of the exact collision set across a ring decomposition as a design tool.** The literature tends to state a sufficient window per construction. V19 uses the equality to compare designs (Section 4.2), to show that the degree criterion is never sharp for dual-containing branches (Proposition 4.5), and to bound fusion (Theorem 4.8).
* **The negative result on fusion.** That three components fused by an lcm cannot exceed the period $n$, and that a single component already attains $n$ whenever any branch exists, is a statement about the ring construction that we did not find stated. It follows quickly from $e\mid n$ and from the existence of a period-$n$ branch, but its consequence — that the natural motivation for stacking components (a longer window) is void — is worth recording.
* **The relaxation statement with its quantification.** That three small periods can fuse to $n$, with a factor that is bounded in a finite range but unbounded in general, is a constructive observation that gives the ring a genuine role once the naive motivation is refuted.
* **The allocation theorem.** One component with $y=0$ holds the frame while the others carry messages, with the joint window equal to the least component window (Proposition 5.4), and four ternary symbols at a twelve-cell window for the flagship code (Example 5.5). The ingredients are elementary; the explicit allocation and its exact window are, to our knowledge, new.

### 4.3 What is deliberately not claimed

* **No claim of optimality**, in any parameter regime, for any code in the paper.
* **No claim of a larger window than a single-component construction.** The opposite is proved.
* **No claim about noisy synchronization.** The model is explicitly idealised.
* **No claim of priority for the individual theorems.** The paper's contribution is stated as a combination, and Section 7 says so.
* **No claim that the $[[39,3:9,0,3]]_3$ code is competitive.** Its distances ($d_X=3$, $d_Z=4$ at $N=39$, $K=3$) are modest, and the paper presents it as an illustration of the allocation, not as a good code.

### 4.4 The closest prior art, and why the paper is still worth publishing

The closest works are Fujiwara–Tonchev–Wong (2013) for the order criterion, Luo and Ma (2018) for repeated-root $q$-ary families, Du et al. (2020, 2023) for ring- and quasi-cyclic-based synchronizable codes, and Tansuwannont–Nemec (2026) for the hybrid framework. A referee from any of these groups would recognise the techniques.

The paper's defence is narrow but honest: it takes a bound that the literature uses as sufficient, proves it is exact in the ideal model, and then uses the exactness to correct an intuition about what stacking components achieves. That correction is useful to anyone building such codes, and the explicit allocation table is directly reusable. The paper does not pretend to more.

We were unable to obtain the full text of Li and Zhu (2022), whose title and abstract are the closest in the ring direction. If that paper already contains the fusion analysis, the corresponding claim in V19 would need to be reduced to a restatement, and the manuscript says exactly this in Section 7.

---

## 5. Search scope, for the record

| Source | What was searched | Limit |
|---|---|---|
| Crossref | All 36 candidate DOIs, by DOI | Full metadata returned for every resolvable DOI |
| Semantic Scholar | Author and title queries for the synchronizable-code literature | Rate limited; some queries returned 429 and were not retried |
| arXiv | The Tansuwannont–Nemec preprint and the quadratic-residue preprint | Only metadata, not full text |
| The V18 package | Its own bibliography, its `.bbl`, and its validation notes | Used as a lead list, not as evidence |
| General web search | Author names plus "synchronizable", plus "hybrid" | Titles and abstracts only |

Not searched: IEEE Xplore full text, Springer full text, MathSciNet, zbMATH, Google Scholar citation graph. This is a real limitation and it is the reason the novelty claims are phrased as "we did not find" rather than "there is no".
