# 04 Computational Verification

**What this document is.** A record of the computations behind every numerical statement in V19: what was computed, with which algorithm, on which input range, how long it took, and what could have gone wrong. The point of separating this from the mathematical verification (`02_Mathematical_Verification.md`) is that an error here would be an implementation error, not a proof error, and the two need different defences.

**Independence from V18.** The V19 audit code shares no routine with the V18 programs. It contains its own arithmetic in $\mathbb{F}_q$ (polynomial addition, multiplication, division, extended Euclid, modular exponentiation), its own factorisation of $x^n-1$ (cyclotomic splitting plus Berlekamp-style distinct-degree and Cantor–Zassenhaus equal-degree steps), its own order computation, its own cyclic-code enumeration and its own syndrome computation. The V18 scripts were run only as a second opinion, never as an oracle.

---

## 1. The three suites

| Suite | File | Checks | Wall clock | Report |
|---|---|---|---|---|
| Core | `audit_core.py` | 18 | ≈25 s | `core_report.json` |
| Census | `audit_census.py` | assertions (see §3) | ≈0.2 s | `census_report.json` |
| Extra | `audit_extra.py` | 8 | ≈0.2 s | `extra_report.json` |

Total: 26 named checks plus the census assertions, all passing, in about 25 seconds on one core. The exact timings of the run shipped in this package are in `REPRODUCIBILITY/generated_data/test_results.json`; wall-clock times vary by a few tenths of a second between machines, and the manuscript quotes the shipped run.

The core suite is the slow one because it enumerates codewords: the four Table 1 rows alone require enumerating $3^{10}=59,049$ words, and the flagship stabilizer check constructs the full $18$-dimensional span in each type.

---

## 2. What each core check does

| # | Check | Input range | What would catch an implementation error |
|---|---|---|---|
| 1 | Idempotents and $R\cong\mathbb{F}_q^3$ | $q\in\{3,5,7,11,13,17,101\}$ | multiplication of every pair modulo $v^3-v$, plus a basis evaluation of the isomorphism |
| 2 | $q=2$ degeneracy, $q=3$ arithmetic | $q=2,3$ | direct evaluation of $v^3-v$ at $0,\pm1$ |
| 3 | Components and duality | $(q,n)\in\{(3,2),(5,2)\}$, all generator triples | full $q^{3n}$ enumeration of the orthogonal complement |
| 4 | Lemma 2.5 equivalence | $q\le11$, $n\le12$, 2,332 generators | four independent formulations of the same condition compared pairwise |
| 5 | Theorem 2.7 | $q\le23$, $n\le40$, 275 pairs | existence asserted from both directions, plus a constructive branch |
| 6 | Theorem 4.2 | 1,970 branches | syndrome map computed from scratch, not from the formula |
| 7 | Window boundary | 540 splits at $e-1$ and at $e$ | injectivity tested by explicit linear algebra over $\mathbb{F}_q$ |
| 8 | Proposition 4.5 | sampled branches of all 81 pairs | $(\deg f,e)$ compared directly |
| 9 | Theorem 4.6 | 32 triples | joint syndrome computed componentwise |
| 10 | Theorem 5.2 | 123 branch–family combinations | collision set from the definition |
| 11 | Lemma 5.1 | all branches with $\deg f\le4$, all $y\le\deg f+1$ | injectivity of the reduction map by enumeration |
| 12 | Flagship parameters | the single code | divisibility, dual containment, dimensions |
| 13 | Flagship marker table | $y=0,1,2$ | collision sets by enumeration over all message pairs |
| 14 | Flagship stabilizer | the single code | commutation of all generator pairs, rank in each type |
| 15 | Table 1 | four rows | every entry recomputed, including $d_Z$ and $d_X$ |
| 16 | Table 2 | seven rows | collision set and window recomputed |
| 17 | Table 5 | eight rows | explicit triple realising each row |
| 18 | Marker families | all small cases | distinctness, bijectivity, collision at $y>\deg f$ |

## 3. What the census suite does

The census walks $q\in\{3,5,7,11,13\}$ and $2\le n\le20$ with $\gcd(n,q)=1$, which is 81 pairs. For each pair it factors $x^n-1$ over $\mathbb{F}_q$, groups the factors into reciprocal pairs, and enumerates the $5^m-3^m$ branches. For each branch it computes $f$, $\deg f$, $e=\operatorname{ord}_x(f)$, and checks $e> \deg f$.

The suite asserts, rather than merely prints:

* 81 pairs, of which 39 are nonempty;
* 20,724 branches in total, distributed as 38 (q=3), 136 (q=5), 808 (q=7), 16,134 (q=11), 3,608 (q=13);
* every branch satisfies $e>\deg f$;
* the closed forms $5^m-3^m$ and $5^m-2\cdot3^m+1$ reproduce the total and the proper-$D$ count for every pair;
* 27 pairs admit a proper-$D$ branch, and in each of them some triple attains $\lcm=n$;
* 118 relaxation pairs with 38 factors $>1$, maximum factor $12$ at $(61,60)$;
* the unboundedness witnesses $(211,210,(5,6,7))$ and $(281,280,(5,7,8))$.

## 4. What the extra suite does

| Check | Content |
|---|---|
| General marker residue | 708 (branch, $\beta$) cases; collision set against multiples of $\operatorname{ord}_x(f/\gcd(f,\beta))$ |
| Flagship cascade | $y=0$ window 12; $y=1$ collisions $\{3,10\}$, window 2; $y=2$ all differences, window 0 |
| Flagship allocation | the five ring allocations of Table 3, each recomputed from the definition |
| Proper-$D$ table | all 27 witness triples admissible; maximum lcm equal to $n$ |
| Relaxation table | the seven rows with factor $\ge6$ |
| Padding cost | 39, 45, 75 qudits for windows 0, 2, 12 |
| Scatter data | 38 branches over $\mathbb{F}_3$ used for Figure 3 |

---

## 5. Cross-validation against V18

The V18 scripts `code/branch_census.py`, `code/independent_checks.py` and `scripts/review_table_verification.py` were run on the same inputs. They use SymPy rather than the V19 arithmetic. Result:

| Quantity | V18 scripts | V19 audit | Agree |
|---|---|---|---|
| Pairs with branches | 39 | 39 | yes |
| Total branches | 20,724 | 20,724 | yes |
| Relaxation pairs | 118 | 118 | yes |
| Relaxation factors $>1$ | 38 | 38 | yes |
| Proper-$D$ pairs | 27 | 27 | yes |
| Flagship window | 12 | 12 | yes |
| Flagship $K$ | 3 | 3 | yes |

Two engines, written independently and using different algebra systems, agree on every reported count. This does not prove the counts are right — a shared misreading of the problem would survive both — but it does exclude arithmetic and algorithmic slips in either implementation.

---

## 6. Determinism and seeds

The only randomised step is the Cantor–Zassenhaus splitting inside the factorisation of $x^n-1$. It is seeded once, at import, with the fixed seed 20261021. Re-running any suite produces byte-identical JSON apart from the timestamp. The `check_tex.py` step is deterministic.

## 7. What could still be wrong

| Failure mode | Defence | Residual risk |
|---|---|---|
| A coding error in $\mathbb{F}_q$ arithmetic | every polynomial routine is exercised by the ring-axiom check (check 1) and by the exhaustive $n=2$ enumeration (check 3), which compares against brute-force vector space computations | Low |
| A wrong factorisation of $x^n-1$ | the branch counts match the closed forms $5^m-3^m$ for all 81 pairs, and a missed or duplicated factor would change $m$ | Low |
| A wrong order computation | the order is checked by verifying $x^e\equiv1$ and that no proper divisor of $e$ works; the window is separately confirmed by the syndrome map | Low |
| The census range being unrepresentative | the range is stated explicitly; the paper's claims about large $e/\deg f$ rest on a construction, not on the census | None for the theorems |
| A mismatch between the numbers here and the numbers in the PDF | every table in the manuscript is generated from the same JSON that this document describes, and the PDF is built from those generated files in one pass | Low |

## 8. Reproducing all of it

From the package root:

```
cd REPRODUCIBILITY/tests
python3 test_all.py
```

This runs the three suites in a scratch directory, writes fresh reports to `REPRODUCIBILITY/generated_data/`, and rewrites `test_results.json`. It needs Python 3.11 and nothing else; SymPy is required only for the frozen V18 scripts in `source_code/v18_frozen/`, which are not part of the V19 pass/fail totals.

To rebuild the PDFs from the Markdown sources:

```
cd REPRODUCIBILITY/source_code
python3 build.py ../../src/paper.md --typ ../../MANUSCRIPT/Main.typ --tex ../../MANUSCRIPT/Main_Manuscript.tex
python3 -c "import typst; typst.compile('../../MANUSCRIPT/Main.typ', output='../../MANUSCRIPT/Main_Manuscript.pdf')"
```

(`src/paper.md` is the concatenation of the four section files; the command is given in full in `REPRODUCIBILITY/reproduction_commands.md`.)
