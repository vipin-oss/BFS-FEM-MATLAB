# 05 Round 1 — Mathematical Review

**Role assumed.** A referee for a journal in quantum information theory who works on algebraic coding. The reviewer's job in this round is to find statements that are false, unproved, or proved with an argument that does not support the claim.

**What was done.** The manuscript was read section by section against the definitions, with each proof re-derived by hand before its computational check was consulted. The computational evidence was used to *test* the proofs, never to replace them. Where a proof was found to rely on an unstated assumption, the assumption was either added to the hypotheses or removed by a sharper argument.

---

## 1. Findings

### R1-1 (major) — The classical label of a hybrid code was not shown to be the marker

**Where.** Proposition 3.1 and its proof; Section 3.3.

**Problem.** The original proof asserted that "the operators $X(u)$ with $u$ running over representatives of $D/C$ label $q^{k_D-k_C}$ mutually orthogonal code spaces", and then treated the marker as a separate object added to the encoded block. That leaves the relation between the $M$ classical symbols of the hybrid code and the marker codeword $g\in D$ unspecified. A reader could reasonably ask whether the code has $2M$ symbol slots (marker plus classical message) or $M$. The answer is $M$, but the paper did not say so, and the parameter table is only meaningful if the two coincide.

**Resolution.** The proof was rewritten to construct the transmitted word explicitly as $|\psi+g\rangle$ and to show that measuring the $Z$-syndrome with respect to $C^\perp$ returns $v\cdot g$, independent of the codeword. This shows that the same $g$ is both the marker and the classical label, so the marker payload and the classical capacity are drawn from one pool of $M$ slots. Section 3.3 was amended to state the identification, and Remark 5.6 and Section 5.4 now refer to it when they talk about spending symbol slots.

**Verification.** The rewritten proof was checked against the flagship code by explicit construction of the stabilizer and by computing the syndrome map (core checks 12–14). No numerical statement changed.

### R1-2 (major) — The claim that the marker can carry messages needed its scope fixed

**Where.** Lemma 5.1, Theorem 5.2, and the paragraph following Lemma 5.1.

**Problem.** The original text defined $\mathcal{M}_y=\{1+b_1x+\cdots+b_yx^y\}$ and stated the three regimes of $y$ but did not isolate $y=\deg f$ as the boundary at which the message family fills the quotient ring and the window collapses. Without that sentence, the example with $y=2$ and $\deg f=3$ reads as an arbitrary choice rather than as the extreme case of a phase transition.

**Resolution.** A paragraph was added after Lemma 5.1 explaining that $\mathcal{M}_{\deg f}$ is a complete set of representatives, that every nonzero $\delta$ is then a collision, and that a positive window therefore requires $y\le\deg f-1$. The sentence in Example 5.5 that says the fourth row attains the maximum was rewritten to give the reason ($y_1=0$ forced because a single symbol already produces the collisions $\{3,10\}$) rather than merely the conclusion.

**Verification.** The boundary case is check 10 in the core suite and check 2 in the extra suite; both confirm the collapse.

### R1-3 (major) — Theorem 4.8 was stated without its logical dependence on Lemma 4.7

**Where.** Theorem 4.8 and its proof.

**Problem.** The proof said "by Lemma 4.7 $n\in E(q,n)$, and the triple $(n,n,n)$ attains the bound", but the statement of the theorem as first drafted included the case $E(q,n)=\emptyset$ in a way that made the "otherwise" clause ambiguous: if no branch exists, the maximum over an empty set is undefined, and the sentence "$k=n$ is attainable" is vacuous.

**Resolution.** The theorem was split into its two cases in the statement itself, and the proof now says explicitly that the first statement combines Theorem 2.7 with Proposition 2.3 and that the maximum is taken over nonempty sets of branches. The phrase "the same holds for any number of components" was retained because the argument genuinely does not use three.

**Verification.** The census enumerates all 39 nonempty pairs and finds $\max E(q,n)=n$ in each; for the 42 empty pairs no maximum is claimed.

### R1-4 (minor) — Two proofs used a step that is true but was not justified

**Where.** Proposition 4.5 and Proposition 5.4.

**Problem.** Proposition 4.5 said "both $f$ and $x-1$ divide the squarefree polynomial $x^e-1$ and are coprime, so $f(x-1)\mid x^e-1$" without saying why the product of two coprime divisors of a polynomial divides it. Proposition 5.4 said "whose least absolute element is $e_1$" without noting that $e_1\mid n$, which is what makes $n-e_1\ge e_1$.

**Resolution.** Both steps are now written out. In Proposition 4.5, coprimality of $f$ and $x-1$ follows from $x-1\nmid f$ since $x-1$ is irreducible. In Proposition 5.4, the positive multiples of $e_1$ in $[1,n-1]$ are listed explicitly and the inequality $n-e_1\ge e_1$ is attributed to $e_1\mid n$.

**Verification.** Neither change alters a conclusion; both are recorded here because a referee would have flagged them.

### R1-5 (minor) — The relaxed-family claim about $d_X$ was imprecise

**Where.** Remark 4.9 and Note to Table 6.

**Problem.** The note said "All these branches have $d_X=1$" without saying why. The reason is that the selected branches are the linear ones $C_i=\langle x-a_i\rangle$ with $D_i=\mathbb{F}_q^n$, and a full space has unit vectors.

**Resolution.** The note now identifies the branches as linear and gives the one-line reason. The manuscript also says, in the same remark, that a linear family cannot improve the Pauli distance, which was previously left implicit.

### R1-6 (minor) — The closed-form branch count was stated with a wrong derivation

**Where.** Section 6.1, equation (15).

**Problem.** The original derivation described the five states per reciprocal pair loosely ("neither factor, the first to $f$, the second to $f$, or either factor to $D$") in a way that double-counts. The formula $5^m-3^m$ is right, but the sentence explaining it was not.

**Resolution.** The counting is now given as: three choices per pair for $g_C$ (neither factor, the first, the second); given a chosen factor, two further choices (assign it to $g_D$ or to $f$); a pair not represented in $g_C$ contributes nothing to $f$. This gives five states per pair, and the $3^m$ cases with $f=1$ are removed.

**Verification.** The formula and the proper-$D$ variant $5^m-2\cdot3^m+1$ are asserted in `audit_census.py` for all 81 pairs.

### R1-7 (minor) — "Optimal" survived in one place

**Where.** Section 4.2, final sentence of the paragraph after Proposition 4.5.

**Problem.** The draft said the degree criterion "is optimal in general, outside the dual-containing setting". The word optimal is not defined here; what is meant is that the criterion is sharp for some non-dual-containing branches (e.g. $f=x-1$), not that it cannot be improved.

**Resolution.** Rewritten as "the degree criterion is also sharp in general, outside the dual-containing setting", with the $f=x-1$ example. No other occurrence of "optimal" remains in a mathematical claim; Section 7 states explicitly that no optimality is claimed.

### R1-8 (informational) — The subsystem remark is unverified

**Where.** Remark 5.6.

**Problem.** The asymmetric subsystem parameter formulas are quoted from [20] and transferred to the ring setting. The transfer is plausible but was not checked, and a referee would want that said.

**Resolution.** The remark now ends by stating that only the symmetric case is evaluated in this paper and that the asymmetric case is recorded as a structural observation rather than a verified construction. `02_Mathematical_Verification.md` records the same status.

---

## 2. Changes made in this round

| # | File | Change |
|---|---|---|
| 1 | `sec3-4.md` | Proposition 3.1 proof rewritten around the explicit transmitted word $|\psi+g\rangle$ |
| 2 | `sec3-4.md` | Section 3.3 states that marker and classical label are one object |
| 3 | `sec3-4.md` | Proposition 4.5 proof: coprimality step written out |
| 4 | `sec3-4.md` | Theorem 4.8 statement and proof split by case |
| 5 | `sec3-4.md` | Remark 4.9 note identifies the linear family and $d_X=1$ |
| 6 | `sec5-6.md` | Paragraph added after Lemma 5.1 on the $y=\deg f$ boundary |
| 7 | `sec5-6.md` | Example 5.5 allocation paragraph gives the reason, not just the count |
| 8 | `sec5-6.md` | Proposition 5.4 proof lists the positive multiples and uses $e_1\mid n$ |
| 9 | `sec5-6.md` | Closed-form derivation rewritten |
| 10 | `sec3-4.md` | "optimal" replaced by "sharp" with the $f=x-1$ example |
| 11 | `sec5-6.md` | Remark 5.6 ends with the scope limitation |

## 3. What the round did not find

No false theorem, no gap in Theorem 4.2 or Theorem 4.6, no counterexample to Proposition 4.5 in the census range, and no inconsistency between the parameters of Proposition 3.1 and the flagship code. The mathematical core survived the round unchanged; what changed was the precision of the proofs and the honesty of the framing.

## 4. Consequence for the package

After this round the manuscript was rebuilt, the LaTeX structural check re-run (0 problems), the PDF re-rendered and read page by page, and the test suites re-run (all pass). The changes in this round are all in the manuscript and supplements; no computational result was altered, so the JSON reports did not change.
