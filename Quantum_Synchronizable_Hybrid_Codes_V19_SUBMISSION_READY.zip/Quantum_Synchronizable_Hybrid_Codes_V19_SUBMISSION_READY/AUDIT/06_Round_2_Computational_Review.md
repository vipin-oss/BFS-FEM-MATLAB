# 06 Round 2 — Computational Review

**Role assumed.** A referee whose concern is reproducibility: could an independent reader recover every number in the paper, and are the numbers actually what the text says they are?

**What was done.** Every numeric claim in the manuscript was traced to a code path, the code was re-run from a clean copy of the source tree, and each table in the PDF was compared entry by entry against the machine-generated data. Where a number appeared in the text but not in a table, the code that produces it was located or written.

---

## 1. Findings

### R2-1 (major) — Table 1 could not be reproduced from the package

**Where.** Table 1 of the manuscript.

**Problem.** The four rows of Table 1 quote $g_C$, $g_D$, $(k_C,k_D)$, $\deg f$, $e$, the window, the degree bound, $d_Z$ and $d_X$. In V18 only the aggregate counts were reproducible; the four specific branches and their distances were not in any script, so a reader could not tell whether the generators in the table are the ones the counts came from.

**Resolution.** The four branches were located by exhaustive search over the census (the program that does this is part of `audit_core.py`), the exact generator polynomials were hard-coded as the input to the check, and every entry of the table was recomputed from them. The table in the manuscript is now generated from those computed rows, not typed.

**Verified.** The generator polynomials published in the table are the ones the program uses as input: `(3,13)`: $g_C=1+x^2+x^5+x^6$, $g_D=2+x+x^2+x^3$; the resulting $f=2+2x+x^3$, $e=13$, $d_Z=4$, $d_X=3$. Note that `audit_core.py` encodes the same polynomials in ascending coefficient order as `(1,0,1,0,0,1,1)` and `(2,1,1,1)`, which is the same data.

### R2-2 (major) — The census table in the paper lacked the per-pair data

**Where.** Table 4 and Section 6.2.

**Problem.** The paper reported five rows of aggregate counts (one per $q$) and asserted that the full census consists of 81 pairs and 20,724 branches. Nothing in the package listed all 81 pairs with their branch counts and period sets, so a reader could not check the totals or the claim that $\max E(q,n)=n$ for every nonempty pair.

**Resolution.** `audit_census.py` now writes every pair's row to `census_report.json`, and `SUPPLEMENTARY/Additional_Tables/A1_branch_census.csv` contains all 81 rows. The supplement prints the 13 rows for $q=3$ and points to the CSV for the rest.

### R2-3 (major) — The relaxation table was a filter, not the data

**Where.** Table 6 and Figure 4.

**Problem.** Table 6 shows the seven rows with factor $\ge6$, and Figure 4 originally plotted only those seven. The caption said the figure showed the distribution over 118 pairs. That was false: a histogram of seven values cannot show a distribution over 118 pairs.

**Resolution.** `audit_census.py` now stores all 118 rows under `relaxation.all` (in addition to the filtered `table`), the figure is generated from the full set, and the histogram reads 80/4/14/9/4/3/1/2/1 for factors 1,2,3,4,5,6,7,8,12. The caption is accurate now.

**Verified.** 80 + 4 + 14 + 9 + 4 + 3 + 1 + 2 + 1 = 118, and the count of factors $>1$ is 38.

### R2-4 (major) — The flagship allocation table asserted intersections that were not computed

**Where.** Table 3, rows $(0,1,1)$ and $(0,2,2)$.

**Problem.** The manuscript asserted that these allocations keep the full twelve-cell window because the second and third components have collision sets equal to all of $\mathbb{Z}_{13}\setminus\{0\}$ and therefore cannot shrink the intersection. That is a correct argument, but the table presented it as a computation. A referee is entitled to see the computation.

**Resolution.** `audit_extra.py` now computes, for each of the five allocations, the joint collision set as an actual intersection of the three computed sets, and Table 3 is generated from that output. The argument and the computation agree, as they must.

### R2-5 (minor) — The window boundary was tested only at the endpoints

**Where.** Section 6.3.

**Problem.** The first version tested injectivity at $a_l+a_r=e-1$ and at $a_l+a_r=e$ but did not state how many splits were tested, so "was checked separately" was unquantified.

**Resolution.** The check now walks all $(a_l,a_r)$ with $a_l+a_r=e-1$ and all with $a_l+a_r=e$ for every branch in the sample, which is 540 cases, and the paper quotes the number.

### R2-6 (minor) — Two run-time claims in the complexity section were unmeasured

**Where.** Section 6.6.

**Problem.** The paragraph on complexity quoted 25.1 s and 0.17 s. Those numbers were genuine but came from an earlier run; without a recorded timing file a reader could not check them.

**Resolution.** The timings are now produced by `test_all.py` and written to `test_results.json`, which records 25.21 s and 0.16 s for the final run. The manuscript quotes the final values.

### R2-7 (minor) — The “2,332 generators”, “1,970 branches” and similar counts were in the text but not in any report

**Where.** Section 6.3 and the summary sentences.

**Problem.** Counts such as 2,332 (Lemma 2.5), 1,970 (Theorem 4.2), 540 (window splits), 32 (Theorem 4.6), 123 (Theorem 5.2), 708 (Appendix B) and 275 (Theorem 2.7) appeared in the paper but not in a machine-readable file, so they could drift if the code changed.

**Resolution.** Each count is now emitted in the corresponding `record()` line of `audit_core.py` or `audit_extra.py`. The `summary` field of the check string contains the count and the JSON report preserves it. Re-running the suite prints the same numbers.

### R2-8 (informational) — The scatter figure plots 38 points but the text did not say where they come from

**Where.** Figure 3.

**Problem.** The figure plots $e$ against $\deg f$ for branches over $\mathbb{F}_3$ with $n\le20$. The data were generated inside the figure script, not saved.

**Resolution.** `audit_extra.py` now emits the 38 rows as `scatter_q3`, the CSV `A7_scatter_window_vs_degree.csv` contains them, and the figure script reads that file.

---

## 2. Independent re-run

The complete suite was run from a scratch copy of `REPRODUCIBILITY/source_code/` with no access to the development tree, using `REPRODUCIBILITY/tests/test_all.py`. All three suites passed; the reports were written to `REPRODUCIBILITY/generated_data/`. The result is recorded in `test_results.json` with `"overall": "PASS"`.

The LaTeX structural check was run on the regenerated manuscript and reported 0 problems and 35 informational notes (mostly labels that are defined but not cross-referenced, which is normal).

## 3. Table-by-table disposition

| Table | Source | Checked against |
|---|---|---|
| 1, four branches | `core_report.json` → `table_single` | recomputed from explicit generators; distances by enumeration |
| 2, marker families | `core_report.json` → `table_hybrid` | collision sets from the definition |
| 3, flagship allocations | `extra_report.json` → `flagship_allocation` | joint sets computed as intersections |
| 4, census | `census_report.json` → `census.per_q` | totals and closed forms |
| 5, fusion | `core_report.json` → `table_fusion` | explicit triple realising each row |
| 6, relaxation | `census_report.json` → `relaxation.table` | all 118 rows stored; filter is $\ge6$ |
| 7, proper $D$ | `extra_report.json` → `proper_D_table` | 27 pairs, witness lcm $=n$ |

Figure 1 and Figure 2 are schematic and contain no data. Figure 3 reads `A7`, Figure 4 reads `A2`.

## 4. What this round did not resolve

* The PDF is produced by Typst, not by LaTeX. The numbers in the PDF come from the same generated source as the `.tex`, but a defect that exists only in the LaTeX rendering would not be visible in the PDF that was inspected. This is recorded as I-14 in the issues register.
* The V18 Magma scripts were not executed (no interpreter), so any computation that depends on them is not reproduced here. It is also not relied on by any V19 claim.
* The `supporting_programs/tests/` unit test that imports a missing module remains failing. It tests V18 code that V19 does not use.

## 5. Score

| Aspect | Before the round | After the round |
|---|---|---|
| Numbers traceable to code | 6 of 7 tables | 7 of 7 |
| Figures generated from stored data | 2 of 4 | 4 of 4 |
| Counts in text present in reports | partial | all |
| Independent re-run from scratch | not attempted | passed |
| LaTeX structural problems | not measured | 0 |
