# 07 Round 3 — Journal Review

**Role assumed.** An associate editor for *IEEE Transactions on Quantum Engineering* or *Quantum Information Processing*, deciding whether the manuscript is publishable and what a referee report would say.

**What was done.** The manuscript was read end to end as a submission: title, abstract, introduction, positioning, presentation, figures, bibliography, and the claims made in the abstract against what the paper actually establishes. The questions asked were those an editor asks: is the contribution clear, is it enough, is it presented honestly, and would it embarrass the journal?

---

## 1. Editorial assessment

### 1.1 What the paper is

A careful study of synchronizable hybrid codes built from cyclic codes over the reduced ring $\mathbb{F}_q[v]/(v^3-v)$. Its contributions are: an exact threshold theorem in an idealised model, a sharpness result that shows a widely used degree bound is never tight for dual-containing codes, a negative result showing that three-component fusion cannot enlarge the synchronization window, a quantified relaxation statement that gives the ring a genuine role, and an allocation theorem with an explicit ternary example.

### 1.2 Its standing

The mathematics is correct as far as this audit can determine. The scope is narrow and the paper says so. The negative result on fusion is the sort of observation a reader might think obvious in hindsight, which cuts both ways: it is unsurprising once stated, but the paper shows it was not being stated, and it changes what a builder of such codes should do.

The paper is not going to change the field. It is a correct, modest contribution with a clear message, and it belongs in a specialised journal if the presentation is right. The main risk is a referee who says "the order criterion is known and the lcm observation is trivial". The response available to an author is the one this manuscript already makes: the order criterion is known as a *sufficient* condition, the exactness is what lets one compare designs, and the comparison is what produces the negative result and the relaxation. That defence should therefore be in the introduction, not only in Section 7.

### 1.3 Verdict of this round

**Publishable after the corrections in §2–§4**, which were applied. No further structural change is needed.

---

## 2. Presentation findings

### R3-1 (major) — The abstract described capabilities the model does not deliver

**Problem in the first V19 draft.** The abstract spoke of "recovering from misalignment" and of codes that "tolerate" offsets without saying that the analysis assumes exact marker syndromes. A reader would take away a physical claim.

**Correction applied.** The abstract now says, in its fourth sentence, "Within an idealised model in which the marker syndrome is observed exactly", and its last sentence reads "No claim is made about noisy syndrome extraction." The word "tolerable" is defined in Section 3.3 as injectivity of the idealised map.

### R3-2 (major) — The introduction oversold the ring

**Problem in the first V19 draft.** The introduction framed the ring as the source of the construction's advantage. The paper then proves that fusion does not enlarge the window. An editor would notice the mismatch between the framing and the result.

**Correction applied.** The introduction now says: "This is the sense in which the ring is used: not as a source of new synchronization phenomena, but as a device that packages three synchronized components, with independent marker parameters, into a single block." The three questions the paper answers are posed explicitly, and the third of them (what fusion buys) is answered in the negative in the same paragraph.

### R3-3 (major) — The novelty statement was stronger than the search supports

**Problem in the first V19 draft.** Section 7 listed the new elements without qualification and did not mention that the converse of the order criterion is implicit in the literature.

**Correction applied.** Section 7 now says: "Converse statements, that a window larger than the order bound cannot exist, are also not new in themselves: they follow from the multiplicativity of the order and are implicit wherever the order is described as the period of the marker, for instance in [Fujiwara–Tonchev–Wong]." The contribution is restated as a combination, and the paragraph ends by saying that which parts are genuinely new cannot be settled from the sources available.

### R3-4 (minor) — The title was too long

**Problem.** The first V19 title ran to two subtitles and a colon.

**Correction applied.** The title is now "Synchronizable Hybrid Codes from Cyclic Codes over $\mathbb{F}_q[v]/(v^3-v)$: Exact Misalignment Thresholds and the Limits of Component Fusion". It states the object, the method and the result, and the second half warns the reader that the paper contains a negative result.

### R3-5 (minor) — Section 6 read as a lab notebook

**Problem.** The first draft listed every check without saying what the reader should take from them.

**Correction applied.** Section 6 now opens with the method, then gives the census, the collision sets, the fusion tables, the flagship verification and the complexity, each with a sentence saying what the numbers establish. The phrase "in agreement with Proposition 4.5" appears where the census supports a theorem, so the reader knows which way the implication runs.

### R3-6 (minor) — Figures were referenced but not described

**Problem.** Figure 1 and Figure 2 were referred to only in passing.

**Correction applied.** Figure 1 has a caption that explains the cell structure and the offset, and the text says what the reader should look for. Figure 2 has a caption that identifies the dashed box as the point where assumption (A2) enters, and the text says that the analysis covers the algebraic parts and not the noisy extraction.

### R3-7 (minor) — The bibliography had an inconsistent style

**Problem.** The V18 `.bbl` mixed abbreviated and full journal names and listed two entries out of order.

**Correction applied.** The V19 bibliography is a single IEEE-style list, generated by one engine from one `.bib`, and the structural check confirms that every entry is cited and every citation resolves.

---

## 3. Content findings an editor would raise

### R3-8 — Is the contribution large enough?

**Assessment.** For a specialised journal, yes, provided the framing is honest. The paper is 23 pages including 27 references and seven tables; the mathematics is self-contained; the negative result and the allocation table are usable. It is not a TQE regular paper in scope, but it is a legitimate specialised contribution. If a referee demands a broader comparison with known quantum codes, the answer is that the paper does not claim competitiveness and says so; a comparison would be a different paper.

### R3-9 — Is the idealised model acceptable?

**Assessment.** Yes, if stated plainly and consistently. It is stated in the abstract, in Section 3.3 as assumptions (A1)–(A5), in the discussion of every theorem that depends on it, and again in Section 7. A referee may still ask for a noisy analysis; the paper does not pretend to have one.

### R3-10 — Does the flagship example support the claims?

**Assessment.** It supports the allocation claim (four symbols at a twelve-cell window) and the parameter formula. It does not support any claim of good distance, and the paper does not make one: $d_X=3$, $d_Z=4$ at $N=39$, $K=3$ is modest, and the text says the example illustrates the allocation, not a good code.

### R3-11 — Is the reference to the 2026 paper appropriate?

**Assessment.** Yes. The paper is published online (11 March 2026) with a DOI, and the V19 entry gives the article number rather than a page range. The manuscript uses it for the parameter notation and for the framing of the trade-offs, which is exactly what the paper provides.

---

## 4. Corrections applied in this round

| # | Location | Change |
|---|---|---|
| 1 | Abstract | Idealised model stated explicitly; final sentence disclaims noisy extraction |
| 2 | §1 | Ring framed as packaging device; three questions posed; negative answer stated up front |
| 3 | §1 | Bibliography additions to the CSS and hybrid-code lineage |
| 4 | §1, §4.2, §5.4, §7 | "Optimal" removed from every mathematical claim |
| 5 | §7 | Novelty restated as a combination; converse acknowledged as implicit in the literature |
| 6 | Title | Shortened to two clauses |
| 7 | §6 | Each subsection given a concluding sentence |
| 8 | Figures 1–4 | Captions rewritten; Figure 4 data corrected to all 118 pairs |
| 9 | §4.2 | Degree criterion described as sharp, with the $f=x-1$ example |
| 10 | §5.2 | Boundary case $y=\deg f$ isolated and explained |
| 11 | §5.4 | Allocation maximum justified rather than asserted |
| 12 | References | 27 entries, all verified, all cited |

## 5. What an editor would still ask for, and why it is not in this package

| Request | Why it is not provided |
|---|---|
| A noisy-syndrome analysis | Out of scope of the model; a separate paper. Explicitly flagged as future work. |
| A comparison with the best known quantum codes | Would require a distance analysis the paper does not attempt; the paper claims no competitiveness. |
| A fault-tolerance threshold estimate | Would require a circuit-level model, which the paper does not have. |
| A LaTeX-compiled PDF verified in this environment | No TeX installed; the PDF comes from a second renderer of the same source. Flagged as an open item. |
| A larger census range | The range $q\le13$, $n\le20$ is exhaustive within itself and the theorems do not depend on it. Extending it would cost compute without changing a conclusion. |

## 6. Final editorial recommendation

**Accept with the corrections above, which have been applied.** The paper should be sent to a referee who works on algebraic coding rather than on fault tolerance, with a cover letter that states the negative result up front so that it is read as a contribution rather than as a retraction.

The author should be prepared for the objection that Theorem 4.2 is implicit in the literature. The defence is in the paper: the exactness is used, not merely stated, and the uses are the substance of Sections 4.2, 4.3 and 5.4. If a referee produces a prior statement of the exact threshold, the correct response is to cite it, credit it, and keep the consequences, which remain the paper's own.
