# 08 Issues Register

**How to read this register.** Every issue that was found during the audit is listed, whether it was fixed or not. The status column uses four values only:

| Status | Meaning |
|---|---|
| **CLOSED** | Fixed in V19, and the fix was verified. |
| **CLOSED — DOCUMENTED** | Not fixable with the resources here; the limitation is stated in the manuscript or in an audit document, and no claim depends on it. |
| **OPEN** | Still a defect that a reader could object to. |
| **ACCEPTED** | A deliberate design decision, recorded so that it is not mistaken for an oversight. |

Severity: **S1** would invalidate a result; **S2** would mislead a reader about a result; **S3** is presentational or housekeeping.

 Nothing of severity S1 remains open. No result in the manuscript is claimed on evidence that this audit could not check.

---

## 1. Mathematical issues

### I-01 — Classical label and marker were not identified — **CLOSED** (S2)

**Found in.** Round 1, R1-1. **Where.** Proposition 3.1.

The proof as inherited from V18 showed that the hybrid code has $M=q^{k_D-k_C}$ orthogonal sectors but did not show that the sector label is the same codeword $g$ that serves as the marker. Without that, the phrase "spending symbol slots on the marker" in Section 5 is undefined.

**Fix.** The proof now constructs the transmitted word $|\psi+g\rangle$ and computes the $Z$-syndrome against $C^\perp$ to get $v\cdot g$, independent of $v$ and of the codeword. Section 3.3 states the identification. **Verified** by core checks 12–14.

### I-02 — The $y=\deg f$ boundary was not isolated — **CLOSED** (S2)

**Found in.** Round 1, R1-2. **Where.** Lemma 5.1, Theorem 5.2.

The three cases $y<\deg f$, $y=\deg f$, $y>\deg f$ were enumerated in the statement but the text did not say that the middle case is where the window collapses to zero for every nonzero residue, nor why. A reader could take the collapse as an artefact of the example.

**Fix.** A paragraph after Lemma 5.1 shows that $\mathcal{M}_{\deg f}$ is a complete set of residues, so every difference collides, and a positive window therefore forces $y\le\deg f-1$. **Verified** by core check 11 and extra check 2.

### I-03 — Theorem 4.8 vacuous on empty branch sets — **CLOSED** (S2)

**Found in.** Round 1, R1-3. **Where.** Theorem 4.8.

The statement took a maximum over a possibly empty set and asserted attainability of $n$ without excluding the empty case.

**Fix.** The statement is split by case and the proof names the two ingredients (Theorem 2.7, Proposition 2.3). The census confirms 39 nonempty pairs with $\max E=n$ and 42 empty pairs for which no maximum is asserted.

### I-04 — Two unjustified divisibility steps — **CLOSED** (S3)

**Found in.** Round 1, R1-4. **Where.** Propositions 4.5 and 5.4. Both steps are true; neither was written out. Both now are.

### I-05 — "Optimal" used without a definition or a proof — **CLOSED** (S2)

**Found in.** Rounds 1 and 3. **Where.** §4.2, §7.

The word appeared in the sense of "cannot be improved" for the degree criterion, in a setting where no optimality is proved. Replaced by "sharp", with the example $f=x-1$ and the explicit statement that sharpness means attaining equality in some case, not that no better bound exists. Section 7 now says in one sentence that no optimality is claimed anywhere.

### I-06 — The converse of the order criterion was presented as new — **CLOSED** (S2)

**Found in.** Round 3, R3-3. **Where.** §1, §7.

Fujiwara–Tonchev–Wong describe $\operatorname{ord}_x(f)$ as the period of the marker; a period is by definition minimal, so the converse is implicit there. V19 now says this explicitly and reframes the contribution as the *use* of exactness, not its discovery.

### I-07 — The relaxed family's $d_X=1$ was asserted without a reason — **CLOSED** (S3)

**Found in.** Round 1, R1-5. **Where.** Remark 4.9, note to Table 6.

The branches are linear, $C_i=\langle x-a_i\rangle$, so $D_i=\mathbb{F}_q^n$ contains unit vectors. The note now gives this reason.

### I-08 — Closed-form branch count derivation double-counted — **CLOSED** (S3)

**Found in.** Round 1, R1-6. **Where.** §6.1, equation (15).

The formula $5^m-3^m$ is right; the sentence explaining it was not. Rewritten per reciprocal pair and verified against the census for all 81 pairs.

### I-09 — Remark 5.6 (subsystem transfer) is unverified — **CLOSED — DOCUMENTED** (S2)

**Where.** Remark 5.6. **Also recorded** in `02_Mathematical_Verification.md`.

The asymmetric subsystem parameter formulas are quoted from Tansuwannont–Nemec and transferred to the ring setting. The transfer was not checked, no evaluated example uses it, and the paper now states that only the symmetric case is evaluated and that the asymmetric case is a structural observation.

### I-10 — Question 4.10 is open — **CLOSED — DOCUMENTED** (S3)

**Where.** §4.3.

Whether the gap between the degree bound and the exact window is unbounded for branches with $d_X\ge2$ is not resolved. The manuscript poses it as a question and does not claim an answer. The census covers $q\le13$, $n\le20$ only.

---

## 2. Computational and reproducibility issues

### I-11 — Table 1 was not reproducible from the package — **CLOSED** (S2)

**Found in.** Round 2, R2-1. **Fix.** The four branches are explicit inputs to `audit_core.py` and every table entry is recomputed from them. The manuscript table is generated from the JSON.

### I-12 — The 81-pair census was not itemised — **CLOSED** (S3)

**Found in.** Round 2, R2-2. **Fix.** `A1_branch_census.csv` has all 81 rows; the supplement prints the 13 rows for $q=3$ and points to the CSV.

### I-13 — Figure 4 plotted 7 points while its caption described 118 — **CLOSED** (S2)

**Found in.** Round 2, R2-3. **Fix.** `relaxation.all` stores all 118 rows, the figure is drawn from them, and the histogram in the caption and in the text sums to 118.

### I-14 — The manuscript `.tex` has never been compiled by a TeX engine — **OPEN** (S2)

**Where.** `MANUSCRIPT/Main_Manuscript.tex`.

There is no TeX installation in the build environment and no network access to a TeX distribution (tectonic needs CTAN; `pip` is blocked by PEP 668 outside the provided virtual environment, and the virtual environment has no TeX). The `.tex` is checked structurally by `check_tex.py` (0 problems, 35 notes): brace balance, environment nesting, `\ref`/`\label` agreement in both directions, `\cite`/bib agreement in both directions, tabular column counts, and float placement. It is not checked by a compiler.

**Consequence.** The PDF in this package is produced by Typst from the same generated source, not by LaTeX from the `.tex`. Every number, theorem and table is identical because both files come from one build pass, but a LaTeX-only defect (for example a package incompatibility or a `\mathbb` in a moving argument) would not appear in the inspected PDF.

**Mitigation.** The `.tex` uses the `amsart` class with `amsmath`, `amssymb`, `amsthm`, `booktabs`, `array`, `graphicx`, `microtype`, `geometry` and `hyperref`, and `\bibliographystyle{amsplain}`; there is no custom class, no `\write18` and no shell escape. All of these ship with a standard TeX Live. A user with TeX Live should run `pdflatex`, `bibtex`, `pdflatex`, `pdflatex`; the expected output is 23 pages.

**This is the single most significant open item in the package and is also carried in `SUBMISSION/Submission_Readiness_Report.md`.**

### I-15 — V18 unit test imports a missing module — **ACCEPTED** (S3)

**Where.** V18 `supporting_programs/tests/`.

One test file imports a module that is not in the V18 archive, so the file cannot be collected. It tests V18 code that V19 does not use; it is retained frozen inside `REPRODUCIBILITY/source_code/v18_frozen/` for provenance and is excluded from the V19 pass/fail totals. `test_all.py` runs only the three V19 suites.

### I-16 — The V18 Magma scripts were not executed — **ACCEPTED** (S3)

**Where.** V18 `supporting_programs/magma/`.

No Magma interpreter is available. The scripts are small and their content was read; nothing in V19 depends on their output. They are retained for completeness.

### I-17 — The `crossref` script cannot run inside the sandbox — **CLOSED — DOCUMENTED** (S3)

**Where.** `verify_refs.py`.

Direct HTTPS to `api.crossref.org` fails with a TLS reset from this environment. The 36 DOI queries were therefore issued through a page-fetch tool and the responses are stored in `crossref_report.json`. The script is included because it is correct and will run on a networked machine.

### I-18 — Timing numbers in the complexity section came from an earlier run — **CLOSED** (S3)

**Found in.** Round 2, R2-6. **Fix.** `test_all.py` writes the timings to `test_results.json`; the manuscript quotes the final run (25.2 s, 0.16 s, 0.16 s total 25.5 s).

---

## 3. Presentation issues

### I-19 — Abstract implied physical misalignment tolerance — **CLOSED** (S1 if uncorrected)

**Found in.** Round 3, R3-1.

The abstract said the codes tolerate offsets without stating the idealised model. In a journal that publishes hardware work, that sentence would be read as a physical claim. Corrected: the model is named in the fourth sentence and the last sentence disclaims noisy extraction.

### I-20 — Introduction framed the ring as an advantage the paper then refutes — **CLOSED** (S2)

**Found in.** Round 3, R3-2. The introduction now states the packaging role and gives the negative answer to the fusion question in the same paragraph in which the question is posed.

### I-21 — Title too long — **CLOSED** (S3)

**Found in.** Round 3, R3-4. Now two clauses, stating object, method and result.

### I-22 — Stale cross-reference "Section 6" for the ternary example — **CLOSED** (S3)

**Where.** §1, last paragraph.

The example is in Section 5.4; the introduction pointed to Section 6 (the computational verification). Corrected during Round 3, and every other numeric section reference in the introduction was checked against the actual section headings.

### I-23 — Float references missing their noun, or doubled — **CLOSED** (S3)

**Where.** §6.2, §6.4.

Two sentences began "{ref:fig-scatter} plots …" and "{ref:tab-fusion} lists …", which render as "3 plots"; two others had been hand-patched to read "Figure Figure 3". The reference macro now supplies the noun automatically and the source carries no noun. The generated `.typ` has no doubled nouns.

### I-24 — Table notes rendered as part of the caption, losing the capital N — **CLOSED** (S3)

**Where.** All tables with notes.

The generator lowercased the first letter of a note appended to a caption. Notes are now emitted as a separate justified paragraph at 8.6 pt.

---

## 4. Editorial and packaging issues

### I-25 — V18 bibliography had two wrong author lists — **CLOSED** (S2)

**Where.** `References.bib`, keys `DuMaLiu2023` and `DinhEtAl2021`.

Two entries carried given names that do not match the published records: "Chengcheng Du, Zhi Ma, Yaru Liu" for the 2023 *Computational and Applied Mathematics* paper, whose authors are Chao Du, Zhi Ma and Yiting Liu, and "Ashok Kumar Upadhyay", whose name in the 2021 *Discrete Mathematics* paper is Ashish K. Upadhyay. The DOIs, titles, journals and volumes were right in both cases, which is why a key check did not catch them; only a field-by-field comparison against Crossref did.

**Fix.** Both corrected from Crossref, and `DuMaLiu2023` given its issue number. No other V18 entry had a metadata error; this was established by comparing all 16 entries field by field, not by sampling.

**Correction to this register.** An earlier draft of this document recorded a different and more serious defect here: that `LiuHuLiu2024` duplicated another entry with an invented DOI, that `DuMaLiu2023` had an invented DOI pattern, and that `TansuwannontNemec2026` carried a malformed page range. Those three claims were checked against the V18 files and are **false**. All three V18 entries are correct, the `.bbl` agrees with the `.bib` on all 16 keys, and the record has been rewritten rather than quietly deleted.

### I-26 — Package labelled as containing a verified LaTeX build — **CLOSED** (S2)

**Where.** `SUBMISSION/Submission_Readiness_Report.md`, top `README.md`.

The phrase "compiled LaTeX manuscript" would be false. Both documents say: LaTeX source structurally validated, PDF rendered by Typst, TeX compilation not performed. The readiness report gives a ten-minute procedure for a user with TeX Live to close the gap.

---

## 5. Summary

| Severity | Total | Closed | Closed — documented | Open | Accepted |
|---|---|---|---|---|---|
| S1 | 2 | 2 | 0 | 0 | 0 |
| S2 | 11 | 8 | 2 | 1 | 0 |
| S3 | 13 | 10 | 1 | 0 | 2 |
| **Total** | **26** | **20** | **3** | **1** | **2** |

The single open item is I-14, the absence of a TeX compilation. It is a limitation of the build environment rather than a defect in the content: the source is structurally validated, the PDF comes from the same generated source, and the procedure to close it is given in the readiness report. The three documented items are the unverified subsystem remark (I-09), the open question on the gap for branches with $d_X\ge2$ (I-10), and the sandbox TLS block on the Crossref script (I-17). The two accepted items are V18 artifacts retained for provenance (I-15, I-16).

**No open issue of severity S1 remains. The package is therefore not blocked on correctness. It is blocked, for a strictly LaTeX submission, only on I-14, which is an environmental limitation and not a defect in the content.**
