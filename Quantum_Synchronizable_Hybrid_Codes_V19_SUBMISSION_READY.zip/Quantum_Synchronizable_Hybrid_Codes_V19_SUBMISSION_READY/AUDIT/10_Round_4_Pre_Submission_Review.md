# 10 Round 4 — Pre-Submission Proofread

**Why a fourth round.** Rounds 1–3 reviewed the mathematics, the computation and the editorial framing. They did not read the typeset PDF line by line against the data, and they did not test the renderer's treatment of punctuation next to generated references. This round does both. It was requested after the package had been assembled, and it found seven defects, all of them now fixed.

**Method.** The full text of the 23-page PDF was extracted and read page by page against the source, the tables and the JSON reports. Every sentence that refers to a row of a table was checked against the row it names. Every generated inline element that can interact with punctuation — `\cite`, `\ref`, math symbols — was tested in isolation. The two supplements were read the same way.

---

## 1. Findings

### R4-1 (major) — Semicolons after citations disappeared in the PDF

**Where.** §2.2, after [27]; §4.1, after [13].

**Problem.** The source reads `… of Yang and Massey [@YangMassey1994]; we record it …`. The Typst file contains `#cite(<YangMassey1994>); we record it …`, which is correct markup, but Typst parses a semicolon after a code expression as the terminator of that expression and does not typeset it. The PDF therefore read "[27] we record it", joining two sentences. A second occurrence after "[13]" produced the same run-on.

**Why earlier rounds missed it.** The defect exists only in the rendered PDF. The `.tex` is correct, the `.typ` is correct, and the extracted text looked plausible on a fast read. It was found by comparing a punctuation-heavy sentence in the source against the rendered line.

**Fix.** The Typst emitter now detects a semicolon immediately after a citation and emits it as `#text(";")`, so the character survives expression parsing. Both occurrences were verified in the re-rendered PDF. The LaTeX output is unchanged, because `\cite{…};` was never affected.

**Generalisation.** Any punctuation that Typst treats as an expression terminator would be lost the same way. The only other candidate is the comma inside an argument list, which does not occur here; comma, period and colon after a citation were tested and render correctly.

### R4-2 (major) — Two row references in the discussion of Table 2 pointed at the wrong rows

**Where.** §5.2, paragraph after Theorem 5.2.

**Problem.** The text said: "as Table 2 shows in the third row, where the exact window is two cells while the guarantee is one." The row with window 2 and guarantee 1 is the **second** row. The third row is $y=\deg f-1$, where both numbers are zero. The next sentence said the guarantee is attained "as in the second and fifth rows", but the second row is precisely the case where it is *not* attained; the attainment cases are the third and fifth rows.

**Diagnosis.** The prose was written when the table was being drafted and the row order changed afterwards. Nothing in the build links a sentence that names a row number to the row it means.

**Fix.** Corrected to "second row" and "third and fifth rows". Both statements are now checked against the table: second row $(y=1)$ window 2, guarantee 1; third row $(y=2)$ window 0 $=$ guarantee 0 with $\delta=1$, $y=2=\deg f$; fifth row $(5,8,y=1)$ window 0 $=$ guarantee 0 with $\delta=1$, $y=1$, $\deg f=2$.

**Residual risk.** Other sentences that name a row were checked: Table 1 ("in the first row"), Table 3 ("the fourth row") and Table 6 ("the seven pairs") are correct.

### R4-3 (minor) — "(A2)'s" rendered with an opening quotation mark

**Where.** §3.3, last paragraph.

**Problem.** The ASCII apostrophe in `(A2)'s` is converted by the renderer with a context guess that fails after a closing parenthesis: the PDF shows `(A2)‘s`, an opening single quote.

**Fix.** Reworded to "subject to the failure modes of (A2)", which avoids the possessive entirely and reads better. No other apostrophe in the document follows a bracket.

### R4-4 (minor) — The cost of computing $\operatorname{ord}_x(f)$ was understated by a logarithmic factor

**Where.** §6.6.

**Problem.** The text said the order computation costs $O(n^2\log n)$. The exponentiation in each trial already costs $O(n^2\log n)$ (log $n$ squarings of polynomials of degree at most $n$), and there are $O(\log n)$ trials, one per prime factor of $n$ with repetition. The correct bound is $O(n^2\log^2 n)$.

**Fix.** Corrected, with the reason written out: $e\mid n$, the exponent is found by dividing $n$ by its prime factors, and each of the $O(\log n)$ trials is a modular exponentiation.

### R4-5 (minor) — Negated relations printed as "¬ ⊆" and "¬ ≡" in the detailed proofs

**Where.** `SUPPLEMENTARY/Detailed_Proofs.pdf`, §4 (the proof of Lemma S2.5) and §9.

**Problem.** `\not\subseteq` and `\not\equiv` were converted to the Typst identifier `not` followed by the relation, which typesets as a separate negation sign: "$\{0\}\,\lnot\subseteq C$" instead of "$\{0\}\not\subseteq C$". A reader would parse it, but it is not the glyph a typesetter would use, and in the second case the spacing was wrong as well.

**Fix.** The converter now maps `\not\subseteq`, `\not\subset`, `\not\in` and `\not\equiv` to the proper negated symbols (`subset.eq.not`, `subset.not`, `in.not`, `equiv.not`), inserts a space so that a following digit is not glued to the modifier, and falls back to the old behaviour for any other `\not`. Verified: the supplement now contains zero occurrences of "¬" and the expected "⊈", "≢".

**Note.** The main manuscript never uses `\not`, so it was not affected.

### R4-6 (minor) — The supplementary results described five allocations as "nine"

**Where.** `SUPPLEMENTARY/Supplementary_Results.pdf`, §4.

**Problem.** The text said the table covered "every marker allocation $(y_1,y_2,y_3)\in\{0,1,2\}^3$ restricted to the nine allocations that were evaluated". The data file has eight rows: three branch-level marker degrees and five ring allocations. There are 27 possible triples, of which five were evaluated. The word "nine" was a leftover from an earlier draft of the table.

**Fix.** Rewritten: "the three branch-level marker degrees and the five ring allocations $(y_1,y_2,y_3)\in\{0,1,2\}^3$ that were evaluated out of the 27 possible triples". The counts now match `A6_flagship_marker_allocations.csv` row by row.

### R4-7 (cosmetic) — The supplement title broke inside "Proper-D"

**Where.** Title page of `Supplementary_Results.pdf`.

**Problem.** The title ended with "… and the Proper-D Constraint", and the renderer broke the line after the hyphen, leaving "Proper-" at the end of the first line. Legal typography, poor appearance.

**Fix.** Retitled "Supplementary Results: Branch Census, Relaxation Families, and Proper $D$". The hyphenated compound no longer sits at a break point.

---

## 2. What was re-verified after the fixes

| Check | Result |
|---|---|
| Main manuscript pages | 23 (unchanged) |
| Detailed proofs pages | 5 (unchanged) |
| Supplementary results pages | 3 (unchanged) |
| `check_tex.py` on the regenerated `.tex` | 0 problems, 35 notes |
| Tests (`test_all.py`) | core 18/18, census, extra 8/8, latex 0 problems, `overall: PASS` |
| Semicolons after citations | both present in the PDF |
| Negated relations | 0 "¬", 1 "⊈", 2 "≢" across the supplement |
| Row references | all sentences naming a table row checked |

## 3. What this round did not find

No numerical error, no broken cross-reference, no missing citation, no duplicated float label, no overfull table, and no inconsistency between the abstract and the body. The seven defects above are the complete list.

## 4. Effect on the readiness verdict

The verdict does not change: **READY, with LaTeX compilation open (I-14)**. Four of the seven defects were in the rendered PDF only and would have been visible to a referee; two were in the supplementary material; one was a wrong complexity exponent. All are fixed, and the fixes are in the shipped package.

The round also changes one thing in the register: it is no longer accurate to say that the PDF was read page by page *before* the package was sealed. It was read page by page twice, and the second reading found these seven items. That is recorded rather than glossed, because the value of a review round is exactly the number of things it catches.
