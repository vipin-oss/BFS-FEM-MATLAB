// Generated from the single Markdown source; do not edit by hand.
#set document(title: "Synchronizable Hybrid Codes from Cyclic Codes over Fq[v]/(v^3-v): Exact Misalignment Thresholds and the Limits of Component Fusion", author: "Arun Kumar Yadav")
#set page(paper: "us-letter", margin: (x: 1.05in, y: 1.0in),
         numbering: "1", number-align: center)
#set text(font: "New Computer Modern", size: 10.2pt, lang: "en", hyphenate: true)
#set par(justify: true, leading: 0.72em, spacing: 1.15em)
#set par.line(numbering: none)
#set heading(numbering: "1.")
#show heading.where(level: 1): it => { v(0.7em); it; v(0.35em) }
#show heading.where(level: 2): it => { v(0.5em); it; v(0.2em) }
#set math.equation(numbering: "(1)")
#set figure(supplement: none, numbering: none)
#set table(inset: 4pt, stroke: 0.4pt)
#show figure.where(kind: "table"): set figure.caption(position: top)
#show figure.where(kind: "figure"): set figure.caption(position: bottom)
#set figure.caption(separator: [. ])
#set footnote(numbering: "1")
#set cite(form: "normal")

#align(center)[#set par(justify: false)
  #text(size: 15pt, weight: "bold")[Synchronizable Hybrid Codes from Cyclic Codes over $bb(F)_(q)[v] slash (v^(3)-v)$: Exact Misalignment Thresholds and the Limits of Component Fusion]
  #v(0.7em)
  #text(size: 11.5pt)[Arun Kumar Yadav]
  #v(0.35em)
  #text(size: 10pt)[School of Basic and Applied Sciences, K. R. Mangalam University, Gurugram 122103, India]
  #v(0.2em)
  #text(size: 9.5pt, "arunyadav0317@gmail.com")
]

#v(0.6em)
#block(inset: (x: 2.2em), width: 100%)[
  #text(size: 9.8pt)[*Abstract.* We study synchronizable hybrid codes built from cyclic codes over the reduced ring $R=bb(F)_(q)[v] slash (v^(3)-v)$, where $q$ is an odd prime and $op("gcd")(n,q)=1$. The Chinese remainder theorem gives $R tilde.equiv bb(F)_(q)^(3)$, so a cyclic code over $R$ is a triple of cyclic codes over $bb(F)_(q)$, and an interleaved lift places the three components on $3 n$ qudits grouped into $n$ cells of three qudits. A block misalignment is a shift by a whole number of cells. Within an idealised model in which the marker syndrome is observed exactly, we prove that the collision differences of a component are precisely the multiples of $e=op("ord")_(x)(f)$, where $f$ is the quotient of the two generator polynomials, so the largest tolerable misalignment is $e-1$ cells; the known sufficient condition $a_(l)+a_(r)<e$ is therefore also necessary. For every dual-containing branch we show $op("deg") f <= e-1$, so the degree-type bound $op("deg") f-1$ is never sharp and can be arbitrarily far from the exact value. Three components fuse with period $op("lcm")(e_(1),e_(2),e_(3))$, but the largest attainable period is $n$, already attained by a single component: fusion cannot enlarge the window, although it does allow the window to be sustained by components whose individual periods are small. When the marker carries classical symbols we give an exact collision criterion, prove that a collision at difference $delta$ forces $|delta|+y >= op("deg") f$, and show that the window can be held by one component while the others transmit messages. A ternary example with underlying hybrid parameters $[[39,3#":"9,0,3]]_(3)$ transmits four ternary marker symbols over a twelve-cell window at a padded length of $75$ qudits. All numerical statements were re-derived by an independent exact-arithmetic implementation, including an exhaustive census of $20#h(0.17em)724$ dual-containing branches. No claim is made about noisy syndrome extraction.]
]
#v(0.6em)


= Introduction

Quantum error-correcting codes protect encoded information against Pauli errors on the physical carriers; the stabilizer construction that underlies everything below is the CSS construction of Calderbank and Shor #cite(<CalderbankShor1996>) and Steane #cite(<Steane1996>), and the simultaneous transmission of quantum and classical information in one block goes back to the operator-algebra framework of Kribs, Laflamme and Poulin #cite(<KribsLaflammePoulin2005>). In a stream of encoded blocks they do not, by themselves, protect the receiver's knowledge of where each block begins. A frame displaced by a few positions causes the decoder to act on the wrong subset of carriers, and the resulting error is not a Pauli error of the encoded block but a mismatch between the physical positions and the coordinates the decoder assumes. Classical synchronizable codes address this problem with markers or comma-free constructions, an approach that goes back to Bose and Caldwell #cite(<BoseCaldwell1967>). Such schemes rely on inspecting individual symbols, which is not directly possible for quantum data because measurement collapses the encoded state unless the measurement commutes with the encoded algebra; the synchronizable construction arranges precisely that, at the price of a marker that is measured only in a syndrome.

Fujiwara introduced quantum synchronizable codes (QSCs), in which recovery from block misalignment is built into the code algebra rather than obtained by inspecting the encoded state #cite(<Fujiwara2013>). The construction starts from two classical cyclic codes $cal(C) subset.eq cal(D)$ of length $n$ over $bb(F)_(q)$ with $cal(C)^(perp) subset.eq cal(C)$, and uses the nested pair to attach a marker coset to a CSS-type code; the marker is measured only in the syndrome of $cal(C)$, which leaves the encoded quantum information undisturbed. The magnitude of the tolerable misalignment is governed by the multiplicative order of the quotient polynomial $f=g_(cal(C)) slash g_(cal(D))$. Fujiwara's original sufficient condition $a_(l)+a_(r)<k_(cal(D))-k_(cal(C))$ was refined by Fujiwara, Tonchev and Wong to the order condition $a_(l)+a_(r)<op("ord")_(x)(f)$ #cite(<FujiwaraTonchevWong2013>), which is the form used in essentially all later constructions: quadratic residue codes and their supercodes #cite(<XieYuanFujiwara2014>), finite geometries #cite(<FujiwaraVandendriessche2014>), cyclotomic classes #cite(<LiZhuLiu2019>), #cite(<ShiYueHuang2021>), #cite(<LiZhu2022>), chain-containing $q$-ary codes #cite(<XieYangYuan2016>), repeated-root and quasi-cyclic families #cite(<LuoMa2018>), #cite(<DuMaLiu2023>), the $lambda(u+v)|u-v$ construction #cite(<DuMaLuoWang2020>), and further families with explicit distance or two new classes #cite(<LuoMaLin2019>), #cite(<LiuKai2023>) and BCH-type families #cite(<SunEtAl2023>). Guenda, La Guardia and Gulliver gave an algebraic account of the framework #cite(<GuendaEtAl2017>).

Two extensions of the basic problem are relevant here. The first replaces the field by a finite ring. Several authors have constructed QSCs from cyclic or constacyclic codes over rings, using Euclidean sums, chain rings, or rings of the form $bb(F)_(q)+u bb(F)_(q)$ #cite(<LiuLiu2021>), #cite(<DaiLiu2022>), #cite(<LiuHuLiu2024>). Independently, the coding-theory literature has made extensive use of decomposable rings such as $bb(F)_(p)[u] slash (u^(k+1)-u)$ to build quantum codes from cyclic codes, with the Chinese remainder theorem reducing the problem to several field components #cite(<DinhEtAl2021>), #cite(<DinhBagUpadhyay2021>). The second extension adds a classical message: hybrid quantum-classical codes carry quantum and classical information simultaneously, and Tansuwannont and Nemec have recently unified synchronizable codes, hybrid codes and subsystem codes, proving trade-offs between the number of correctable misalignments, the number of gauge qudits and the number of classical symbols #cite(<TansuwannontNemec2026>).

This paper sits at the intersection of these two lines. We take the reduced ring $R=bb(F)_(q)[v] slash (v^(3)-v)$ with $q$ odd, so that $R tilde.equiv bb(F)_(q)^(3)$ through three explicit primitive idempotents. A cyclic code over $R$ is then a triple $(cal(C)_(1),cal(C)_(2),cal(C)_(3))$ of cyclic codes over $bb(F)_(q)$, and a chain $cal(C)^(perp) subset.eq cal(C) subset.eq cal(D)$ over $R$ is the same thing as three chains over $bb(F)_(q)$. Placing the three components on disjoint coordinates of a block of $3 n$ qudits, grouped into $n$ cells of three qudits, produces a hybrid code whose parameters are read off from the components. Because the three components share one physical frame, they also share one misalignment, which is measured in cells. This is the sense in which the ring is used: not as a source of new synchronization phenomena, but as a device that packages three synchronized components, with independent marker parameters, into a single block.

Our analysis is deliberately confined to an idealised observation model in which the marker syndrome is known exactly, either because the channel is noiseless or because the physical errors have already been corrected. Within that model the synchronization problem becomes a purely algebraic question about the map from the offset to the observed syndrome, and we answer it completely for a single component: the offsets that cannot be distinguished are exactly the multiples of $e=op("ord")_(x)(f)$, so the window is $e-1$ and the classical sufficient condition is also necessary. This much is implicit in the order-based literature, where $op("ord")_(x)(f)$ appears as a sufficient bound; making the converse explicit is what allows the subsequent comparison of designs, and we use it to settle three questions that the sufficient condition alone cannot answer.

First, how much is lost by the degree-type condition $a_(l)+a_(r)<op("deg") f$? For dual-containing branches nothing is gained by it, because dual containment forces $op("deg") f <= e-1$; the gap between the two criteria is therefore at least one cell for every branch and can be made arbitrarily large by taking $f$ to be an irreducible factor of a cyclotomic polynomial $Phi_(m)$ with $m slash op("ord")_(m)(q)$ large. This is a statement about the sharpness of a widely used bound, not a new construction.

Second, does using three components enlarge the attainable window? It does not. Since $e | n$ for every branch, the fused period $op("lcm")(e_(1),e_(2),e_(3))$ never exceeds $n$, and a single component already attains $n$ whenever a nontrivial dual-containing branch exists. What fusion provides is a relaxation: a window of $n-1$ cells can be sustained by three components whose individual periods are far below $n$, which matters when no single branch of the required length is available or when the per-component code parameters must be kept small. We quantify this relaxation over a finite range and show that the relaxation factor is unbounded in general, at the price of a poor $X$-distance.

Third, how do classical messages interact with synchronization? Encoding a message in the marker residue restricts the set of admissible residues, and a collision then occurs exactly when a shifted residue lands back in the message family. We characterise this criterion exactly, prove the bound $|delta|+y >= op("deg") f$ that relates the collision distance $delta$, the marker degree $y$ and the code parameter $op("deg") f$, and show that the work can be divided among the components: one component can hold the frame with an empty message while the others transmit. In the ternary example of Section 5.4 this yields four classical symbols over a twelve-cell window, out of the nine symbol slots that the underlying hybrid code offers.

The paper is organised as follows. Section 2 develops the algebra of $R$ and of cyclic codes over $R$, including the dual-containment criterion and the existence question for branches. Section 3 describes the interleaved construction, its parameters and its distance, and fixes the observation model. Section 4 proves the exact threshold for a single component, compares it with the degree bound, and analyses fusion. Section 5 treats message-carrying markers and the allocation of synchronization and message capacity. Section 6 reports the computational verification, Section 7 discusses limitations and Section 8 concludes. Appendix A records the sign convention in the collision criterion, and Appendix B extends the threshold theorem to marker residues that are not coprime to $f$.

A note on what is and is not claimed. The synchronization results are theorems about an idealised model with exact syndromes and offsets by whole cells; they say nothing about noisy syndrome extraction, about the propagation of physical errors into the offset estimate, or about fault-tolerant decoding. The distance statements are combinatorial and refer to the hybrid code's minimum distance in the usual sense. No claim of optimality is made for any construction: the thresholds are exact for the codes considered, but the codes themselves are not claimed to be optimal in any parameter regime.

= The coefficient ring and its cyclic codes

Throughout, $q$ is an odd prime, $n >= 2$ satisfies $op("gcd")(n,q)=1$, and

$ R=bb(F)_(q)[v] slash (v^(3)-v). $ <eq-ring>

For a polynomial $a$ of degree $d$ with $a(0) != 0$ we write $a^(*)(x)=x^(d) a(1 slash x)$ for its reciprocal and call $a$ self-reciprocal when $a^(*)$ is a scalar multiple of $a$. All codes in this section have length $n$ and are cyclic.

== The idempotent decomposition

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Proposition 2.1.] The polynomial $v^(3)-v=v(v-1)(v+1)$ has three distinct roots in $bb(F)_(q)$, so the Chinese remainder theorem gives an isomorphism of $bb(F)_(q)$-algebras $R tilde.equiv bb(F)_(q) times bb(F)_(q) times bb(F)_(q)$. The corresponding primitive idempotents are

$ eta_(1)=1-v^(2),#h(2.2em) eta_(2)=frac(1, 2)(v^(2)+v),#h(2.2em) eta_(3)=frac(1, 2)(v^(2)-v), $ <eq-idem>

and they satisfy $eta_(i)^(2)=eta_(i)$, $eta_(i) eta_(j)=0$ for $i != j$, $eta_(1)+eta_(2)+eta_(3)=1$ and $v=eta_(2)-eta_(3)$. Every $r in R$ has a unique expression $r=r_(1) eta_(1)+r_(2) eta_(2)+r_(3) eta_(3)$ with $r_(i) in bb(F)_(q)$.]

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Remark 2.2.] The hypothesis that $q$ is odd is essential for the formula #context numbering("(1)", counter(math.equation).at(<eq-idem>).first()), not for the decomposition as such. Over $bb(F)_(2)$ one has $v^(3)-v=v(v+1)^(2)$, the ring is not reduced, and $frac(1, 2)(v^(2) plus.minus v)$ is undefined. Nothing in Sections 2--5 uses primality of $q$; the restriction to prime fields is made because the enumerations of Section 6 were carried out over prime fields. The case $q=3$ is included, with $frac(1, 2)=2$: then $eta_(2)=2 v^(2)+2 v$ and $eta_(3)=2 v^(2)+v$, and indeed $eta_(2)+eta_(3)=v^(2)$ and $eta_(2)-eta_(3)=v$.]

A cyclic code of length $n$ over $R$ is an ideal of $R[x] slash (x^(n)-1)$. Since $R[x] slash (x^(n)-1) tilde.equiv ⊕_(i=1)^(3) bb(F)_(q)[x] slash (x^(n)-1)$, every such ideal has the form

$ C=eta_(1) C_(1)⊕eta_(2) C_(2)⊕eta_(3) C_(3),#h(2.2em) C_(i)=⟨ g_(i)⟩ subset.eq bb(F)_(q)[x] slash (x^(n)-1),#h(1.2em) g_(i) | x^(n)-1, $ <eq-decomp>

and $C=⟨ eta_(1) g_(1)+eta_(2) g_(2)+eta_(3) g_(3)⟩$. We call $C_(i)$ the $i$-th component of $C$. On $R^(n)$ we use the Euclidean form $⟨ u,w⟩=sum_(t) u_(t) w_(t) in R$, whose values lie in $R$ rather than in $bb(F)_(q)$; orthogonality is therefore tested in each component separately, as the next proposition records.

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Proposition 2.3.] Let $k_(i)=op("dim")_(bb(F)_(q)) C_(i)$. Then $op("dim")_(bb(F)_(q)) C=k_(1)+k_(2)+k_(3)$ and $|C|=q^(k_(1)+k_(2)+k_(3))$. The code $C$ is a free $R$-module if and only if $k_(1)=k_(2)=k_(3)$. Moreover

$ C^(perp)=eta_(1) C_(1)^(perp)⊕eta_(2) C_(2)^(perp)⊕eta_(3) C_(3)^(perp),#h(2.2em) "so"#h(2.2em) C^(perp) subset.eq C arrow.l.r.double.long C_(i)^(perp) subset.eq C_(i) "for " i=1,2,3. $ <eq-dualcomp>]

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Remark 2.4.] All statements below are phrased in terms of $op("dim")_(bb(F)_(q)) C=sum_(i) k_(i)$ and of the component codes; no $R$-rank is used. Non-free codes are admissible: for $q=5$ and $n=4$ the component dimensions $(4,3,4)$ give $|C|=5^(11)$.]

== Dual containment

For a divisor $g$ of $x^(n)-1$ over $bb(F)_(q)$ put $h=(x^(n)-1) slash g$. It is standard that $⟨ g⟩ ^(perp)=⟨ h^(*)⟩$; the next lemma records the resulting criterion in the three equivalent forms used below.

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Lemma 2.5.] Let $C=⟨ g⟩$ with $g | x^(n)-1$. Then $C^(perp) subset.eq C$ if and only if $g | h^(*)$, equivalently $g g^(*) | x^(n)-1$, equivalently no irreducible factor $p$ of $g$ has $p^(*)$ (up to a scalar) dividing $g$. In particular $x-1∤ g$ whenever $C^(perp) subset.eq C$ and $C != \{0\}$.]

The last assertion uses that $x-1$ is self-reciprocal and that $x-1$ divides $x^(n)-1$ exactly once when $op("gcd")(n,q)=1$. The criterion itself is classical; we use it only to decide which branches exist.

Which $(q,n)$ admit a nontrivial dual-containing code is decided by the position of $-1$ in the group generated by $q$. The following statement is the dual-containment counterpart of Massey's characterisation of reversible cyclic codes #cite(<Massey1964>) and of the complementary-dual condition of Yang and Massey #cite(<YangMassey1994>)#text(";") we record it because it determines the range of the construction.

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Lemma 2.6.] Let $d | n$ and let $p$ be an irreducible factor of the cyclotomic polynomial $Phi_(d)$ over $bb(F)_(q)$. Then $p$ is self-reciprocal if and only if $-1 in ⟨ q⟩ subset.eq (bb(Z) slash d bb(Z))^(*)$. In particular, if $-1 in.not ⟨ q⟩ subset.eq (bb(Z) slash n bb(Z))^(*)$ then every irreducible factor of $Phi_(n)$ is non-self-reciprocal.]

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Theorem 2.7.] There is a cyclic code $C$ of length $n$ over $bb(F)_(q)$ with $\{0\} != C^(perp) subset.eq C subset.neq bb(F)_(q)^(n)$ if and only if $-1 in.not ⟨ q⟩ subset.eq (bb(Z) slash n bb(Z))^(*)$.]

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Example 2.8.] For $(q,n)=(3,10)$ and $(7,10)$ one has $⟨ 3⟩ =⟨ 7⟩ =\{1,3,7,9\}in.rev-1$ in $(bb(Z) slash 10 bb(Z))^(*)$. Hence no nontrivial dual-containing cyclic code of length $10$ exists over $bb(F)_(3)$ or over $bb(F)_(7)$, and no synchronizable code of the type considered here, with or without a ring structure, exists for these parameters.]

Two consequences of Theorem 2.7 are used repeatedly. First, the existence question for the ring code is exactly the existence question for a single field component, because Proposition 2.3 reduces dual containment to the three components. Second, whenever branches exist, one of them has order $n$; this is Lemma 4.7 in Section 4 and it is what caps the achievable window.

= The interleaved construction

== Layout and offset model

The physical system consists of $3 n$ qudits of dimension $q$, grouped into $n$ cells of three qudits. Position $3 t+i-1$, with $0 <= t <= n-1$ and $i=1,2,3$, carries the $i$-th component of the ring symbol $c_(t)=c_(t)^((1)) eta_(1)+c_(t)^((2)) eta_(2)+c_(t)^((3)) eta_(3)$, as in Figure 1. A frame misalignment is a cyclic shift of the ring word by $alpha in bb(Z)_(n)$ cells, that is, a shift of the $3 n$ qudits by $3 alpha$ positions. The offset is common to the three components because it is a property of the block structure and not of a component. Shifts by one or two qudits, which would move the components relative to one another, lie outside the model; this is the main structural restriction imposed by the interleaving, and we return to it in Section 7. A block padded by $a_(l)$ cells on the left and $a_(r)$ cells on the right occupies $3(n+a_(l)+a_(r))$ qudits, so padding is counted in cells as well.

#figure(image("figures/fig_lift.svg", width: 78%), caption: [*Figure 1.* The interleaved lift for $n=5$. Each cell holds one qudit of each component; a frame offset of $alpha$ cells shifts all three components by the same number of positions.]) <fig-lift>

== Parameters

Fix a chain $C^(perp) subset.eq C subset.eq D$ of $R$-cyclic codes of length $n$. By Proposition 2.3 this is the same as three chains $C_(i)^(perp) subset.eq C_(i) subset.eq D_(i)$ of cyclic codes over $bb(F)_(q)$ with generator polynomials $g_(C_(i))$ and $g_(D_(i))$. A component with $C_(i) subset.neq D_(i)$ is called a _branch_; a component with $C_(i)=D_(i)$ is _inactive_. For a branch we write

$ f_(i)=frac(g_(C_(i)), g_(D_(i))),#h(2.2em) e_(i)=op("ord")_(x)(f_(i)),#h(2.2em) op("deg") f_(i)=k_(D,i)-k_(C,i), $ <eq-fi>

where $op("ord")_(x)(f)$ denotes the multiplicative order of $x$ in the finite ring $bb(F)_(q)[x] slash (f)$, that is, the least $e >= 1$ with $x^(e) equiv 1 (op("mod") f)$. The order is defined because $f(0) != 0$ for a proper divisor of $x^(n)-1$. For an inactive component we set $f_(i)=1$ and $e_(i)=1$; its marker syndrome is constant and imposes no condition on the offset. We write $[[N,K#":"M,R_(g),d]]_(q)$ for a code on $N$ qudits with $K$ logical qudits, $M$ classical $q$-ary symbols, $R_(g)$ gauge qudits and distance $d$, following the parameter roles of #cite(<TansuwannontNemec2026>).

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Proposition 3.1.] The interleaved lift of the chain $C^(perp) subset.eq C subset.eq D$ is a hybrid code with parameters $[[N,K#":"M,0,d]]_(q)$ where

$ N=3 n,#h(2.2em) K=sum_(i=1)^(3)(2 k_(C,i)-n),#h(2.2em) M=sum_(i=1)^(3)(k_(D,i)-k_(C,i)),#h(2.2em) d=op("min")(d_(X),d_(Z)), $ <eq-params>

and

$ d_(X)=op("min")_(i) op("min") op("wt")(D_(i) without C_(i)^(perp)),#h(2.2em) d_(Z)=op("min")_(i) op("min") op("wt")(C_(i) without C_(i)^(perp)). $ <eq-dist>

In particular $d >= op("min")_(i) d(D_(i))$ and $d >= op("min")_(i) d(C_(i))$, where $d(dot)$ is the minimum distance of the classical code.]

*Proof.* Work first with a single component and drop the index. The operators $X(a)$ and $Z(b)$ with $a,b in C^(perp)$ commute, since $X(a) Z(b)=omega^(a dot b) Z(b) X(a)$ with $omega=e^(2 pi i slash q)$ and $a dot b=0$ because $a,b in C^(perp) subset.eq (C^(perp))^(perp)=C$. They therefore generate a stabilizer group of order $q^(2(n-k_(C)))$ and the number of logical qudits is $n-2(n-k_(C))=2 k_(C)-n$. The transmitted word is $|psi+g⟩$ with $psi$ a superposition of codewords of $C$ and $g in D$ the classical label. Measuring the $Z$-syndrome with respect to $C^(perp)$, that is the eigenvalues of $Z(v)$ for a basis of $v in C^(perp)$, returns $v dot (c+g)=v dot g$ for every $c in C$, so the outcome is independent of the codeword and the measurement leaves the superposition intact; it equals the class of $g$ modulo $(C^(perp))^(perp)=C$. Hence the classical label is an element of $D slash C$ and there are $q^(k_(D)-k_(C))$ of them. An $X$-type error $X(e)$ is a stabilizer when $e in C^(perp)$; when $e in C without C^(perp)$ it leaves the label in its class but acts as a nontrivial logical $X$; when $e in D without C$ it moves the label to another valid class, and the receiver cannot tell this from a different message; and when $e in.not D$ the observed class is not a valid message and the error is flagged. The undetected and harmful $X$-type errors are therefore exactly the elements of $D without C^(perp)$, which gives $d_(X)$. For a $Z$-type error, $Z(v)$ commutes with the label measurement if and only if $v in C$, and among those it is trivial on the code space if and only if $v in C^(perp)$, which gives $d_(Z)$. An operator mixing the two types has weight at least the larger of the weights of its parts and its nontrivial part is of one of the two kinds already counted, so the minimum is $op("min")(d_(X),d_(Z))$. The lift places the three components on disjoint coordinates, so the stabilizer groups multiply, $K$ and $M$ add, and the distance is the minimum over the components. No gauge qudits occur because the construction is symmetric in $X$ and $Z$; the general asymmetric case is described in Remark 5.6. The final bounds follow from $D_(i) without C_(i)^(perp) subset.eq D_(i) without \{0\}$ and $C_(i) without C_(i)^(perp) subset.eq C_(i) without \{0\}$. $square$

The parameter count should be read with care. $M$ counts classical symbol slots, not synchronized ones: Section 5 shows that part of this capacity must be spent on marker degrees of freedom if a window is required.

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Remark 3.2.] For a branch $C^(perp) subset.eq C subset.neq D$, the condition $op("min") op("wt")(D without C^(perp)) >= 2$, that is $d_(X) >= 2$, is equivalent to $D != bb(F)_(q)^(n)$. Indeed, a cyclic code containing a word of weight one contains all of its cyclic shifts, hence all unit vectors, hence is the full space. Conversely, if $D=bb(F)_(q)^(n)$ then no unit vector lies in $C^(perp)$, since cyclicity would force $C^(perp)=bb(F)_(q)^(n)$ and $C=\{0\}$, contradicting dual containment. This equivalence concerns the threshold $2$ only; it says nothing about larger distance requirements.]

== The observation model

In the construction the transmitted word is $|psi+g⟩$, where $psi$ is the encoded quantum state in $C$ and $g in D$ is the marker codeword. By the proof of Proposition 3.1 this same $g$ is the classical label, so the marker and the classical symbol are one object rather than two: the $M$ symbol slots of the hybrid code are exactly the $M$ coordinates of the marker, and the receiver obtains them by measuring the $Z$-syndrome with respect to $C^(perp)$. The block is then padded cyclically and the receiver measures, on the $n$ positions it takes to be the block, the syndrome of the marker with respect to $g_(C)$. If the true frame is shifted by $alpha$, the measured syndrome is the class of $x^(alpha) g$ modulo $g_(C)$. Writing $g=g_(D) beta$, the marker is described by its _residue_ $beta$ modulo $f$; the natural choice is $beta=1$, that is $g=g_(D)$. For the ring code the receiver observes the triple of component syndromes

$ Sigma(alpha)=(x^(alpha) g_(D_(1)) (op("mod") g)_(C_(1)),x^(alpha) g_(D_(2)) (op("mod") g)_(C_(2)),x^(alpha) g_(D_(3)) (op("mod") g)_(C_(3))). $ <eq-sigma>

Suppose the offset is known to lie in $[-a_(r),a_(l)]$ with $a_(l),a_(r) >= 0$ and put $W=a_(l)+a_(r) <= n-1$. The offset is _recoverable_ if $alpha arrow.r.bar Sigma(alpha)$ is injective on $[-a_(r),a_(l)]$, that is, if no difference $delta=alpha-alpha'$ with $1 <= |delta| <= W$ is a _collision_ in the sense $Sigma(alpha)=Sigma(alpha')$. The largest $W$ for which this holds is the _window_ of the code. Because $Sigma$ is defined on $bb(Z)_(n)$, the window never exceeds $n-1$.

The following assumptions delimit the analysis; they are stated once and used throughout Sections 4 and 5.

(A1) Offsets are whole cells and satisfy $W <= n-1$. (A2) The marker syndrome #context numbering("(1)", counter(math.equation).at(<eq-sigma>).first()) is known exactly. This is the case if the channel is noiseless, or if the physical errors have been corrected before the offset is estimated. (A3) The receiver knows $g_(C_(i))$, $g_(D_(i))$ and the message family in use. (A4) Physical Pauli errors are the object of the distance statement of Proposition 3.1; they are not modelled jointly with the offset estimate. (A5) There is no qudit loss, insertion or deletion, and the syndrome-extraction circuit is not itself noisy.

Under (A1)--(A5) the synchronization problem is exactly the injectivity question for #context numbering("(1)", counter(math.equation).at(<eq-sigma>).first()), and the results of Sections 4 and 5 are theorems about that question. They do not assert that a physical receiver subject to the failure modes of (A2) will synchronize; that requires a separate analysis of syndrome noise and of the coupling between physical errors and the offset estimate. Figure 2 summarises the design pipeline and marks the point at which the idealisation enters.

#figure(image("figures/fig_flow.svg", width: 78%), caption: [*Figure 2.* Construction and decoding pipeline. The shaded box marks the step that the idealised model (A2) replaces by an exact observation; the analysis in this paper covers the algebraic parts and the distance statement, not the noisy extraction.]) <fig-flow>

= Exact misalignment thresholds

== A single component

Fix one component and drop the index. Let $C subset.neq D$ be cyclic codes of length $n$ over $bb(F)_(q)$, let $f=g_(C) slash g_(D)$ and $e=op("ord")_(x)(f)$. Neither the collision lemma nor Theorem 4.2 uses the dual-containment condition; they are statements about nested cyclic codes.

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Lemma 4.1.] Let $g=g_(D) beta$ and $g'=g_(D) beta'$ be marker codewords with residues $beta,beta'$ modulo $f$. Then $x^(alpha) g equiv x^(alpha') g'(op("mod") g_(C))$ if and only if

$ f | x^(delta) beta-beta',#h(2.2em) delta=alpha-alpha'. $ <eq-collision>]

*Proof.* The congruence means $g_(C) | x^(alpha')(x^(delta) g_(D) beta-g_(D) beta')$ with $x^(delta)$ read modulo $x^(n)-1$. Since $g_(C) | x^(n)-1$ and $x$ is invertible modulo $x^(n)-1$, this is equivalent to $g_(C) | g_(D)(x^(delta) beta-beta')$, and division by $g_(D)$ gives #context numbering("(1)", counter(math.equation).at(<eq-collision>).first()). $square$

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Theorem 4.2.] Let the marker residue $beta$ be coprime to $f$, for instance $beta=1$. A difference $delta$ is a collision if and only if $e | delta$. Consequently the syndrome map is injective on $[-a_(r),a_(l)]$ if and only if $a_(l)+a_(r) <= e-1$, and the window equals $e-1$.]

*Proof.* By Lemma 4.1, $delta$ is a collision if and only if $f | beta(x^(delta)-1)$, which by $op("gcd")(beta,f)=1$ is equivalent to $f | x^(delta)-1$, that is $e | delta$. The differences occurring in $[-a_(r),a_(l)]$ are those with $1 <= |delta| <= a_(l)+a_(r)$, and none of them is a multiple of $e$ exactly when $a_(l)+a_(r)<e$. $square$

The sufficiency of $a_(l)+a_(r)<e$ is the order criterion of #cite(<FujiwaraTonchevWong2013>), #cite(<XieYangYuan2016>), #cite(<LuoMa2018>)#text(";") Theorem 4.2 adds that no larger window is possible in the ideal model and identifies the complete collision set. This is a short argument, but it changes the status of the order condition from a bound to an exact value, and the rest of the paper uses that change: comparisons between designs, and the negative results on fusion, are statements about the exact value.

Two immediate consequences deserve recording. First, since $f | x^(n)-1$,

$ e | n#h(1.2em) "for every branch," $ <eq-edivn>

so the window is at most $n-1$ for every choice of nested pair. Second, the same argument applied to an arbitrary marker family shows that the multiples of $e$ are always collisions, whatever the marker encodes; this yields a uniform ceiling that is used in Section 5.

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Corollary 4.3.] For every marker residue and every marker family, the window of a branch satisfies $W <= e-1$. In particular the window of a ring code whose active components have periods $e_(1),e_(2),e_(3)$ satisfies $W <= op("lcm")(e_(1),e_(2),e_(3))-1 <= n-1$.]

The proof is the observation that $x^(e) equiv 1 (op("mod") f)$, so a shift by $e$ cells returns every marker to itself and is therefore a collision. Appendix B removes the coprimality hypothesis of Theorem 4.2 and shows that the collision set is then the set of multiples of $op("ord")_(x)(f slash op("gcd")(f,beta))$, so a marker that shares a factor with $f$ loses part of the window in a way that is again computable exactly.

== The degree bound and its sharpness

Fujiwara's original construction certifies a window from the codimension, and the hybrid framework of #cite(<TansuwannontNemec2026>) uses the same degree-type condition. The following comparison is therefore relevant to published statements rather than only to the present construction.

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Proposition 4.4.] If $a_(l)+a_(r)<op("deg") f=k_(D)-k_(C)$, the syndrome map is injective on $[-a_(r),a_(l)]$.]

*Proof.* Since $f | x^(e)-1$ we have $op("deg") f <= e$, and the claim follows from Theorem 4.2. $square$

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Proposition 4.5.] If $C^(perp) subset.eq C subset.neq D$, then $op("deg") f <= e-1$. Hence the exact window $e-1$ is always at least $op("deg") f$, while the degree criterion certifies only $op("deg") f-1$.]

*Proof.* By Lemma 2.5, $x-1∤ g_(C)$ and therefore $x-1∤ f$. Both $f$ and $x-1$ divide the squarefree polynomial $x^(e)-1$ and are coprime, so $f(x-1) | x^(e)-1$ and $op("deg") f <= e-1$. $square$

The gap is not a small constant. Table 1 lists four branches with $d_(X) >= 2$; in the first row the exact window is twelve cells while the degree criterion certifies two. The ratio can be made arbitrarily large: if $f$ is an irreducible factor of $Phi_(m)$ over $bb(F)_(q)$, then $op("deg") f=op("ord")_(m)(q)$ and $e=m$, so $e slash op("deg") f=m slash op("ord")_(m)(q)$ is unbounded as $m$ varies over primes for which $op("ord")_(m)(q)$ stays small. The degree criterion is also sharp in general, outside the dual-containing setting: for $f=x-1$ one has $op("deg") f=e=1$ and both criteria give the empty window, so Proposition 4.5 is a consequence of dual containment and not of the degree count alone.

#figure(
  table(columns: 10, align: center,
    table.header([*$q$*], [*$n$*], [*$g_(C)$*], [*$g_(D)$*], [*$(k_(C),k_(D))$*], [*$op("deg") f$*], [*$e$*], [*window*], [*degree bound*], [*$(d_(Z),d_(X))$*]),
    [3], [13], [$1+x^(2)+x^(5)+x^(6)$], [$2+x+x^(2)+x^(3)$], [$(7,10)$], [3], [13], [12], [2], [$(4,3)$],
    [5], [8], [$1+2 x+3 x^(2)+x^(3)$], [$3+x$], [$(5,7)$], [2], [8], [7], [1], [$(3,2)$],
    [7], [6], [$6+2 x+x^(2)$], [$5+x$], [$(4,5)$], [1], [6], [5], [0], [$(3,2)$],
    [11], [5], [$3+9 x+x^(2)$], [$2+x$], [$(3,4)$], [1], [5], [4], [0], [$(3,2)$]
  ),
  caption: [*Table 1.* Branches $C^(perp) subset.eq C subset.neq D subset.neq bb(F)_(q)^(n)$: exact window $e-1$ against the degree bound $op("deg") f-1$. All entries were recomputed by exhaustive enumeration of the two cyclic codes.],
  kind: "table",
) <tab-single>
  #v(0.35em)
  #par(justify: true, first-line-indent: 0em)[#text(size: 8.6pt)[$d_(Z)=op("min") op("wt")(C without C^(perp))$ and $d_(X)=op("min") op("wt")(D without C^(perp))$ are obtained by enumerating all codewords; the window is $e-1$ by Theorem 4.2. Coefficients are listed in increasing powers of $x$.]]

== Fusion of three components

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Theorem 4.6.] For each active component let $e_(i)=op("ord")_(x)(f_(i))$ and let the marker residue be coprime to $f_(i)$; for an inactive component set $f_(i)=1$ and $e_(i)=1$. Then the joint map $alpha arrow.r.bar Sigma(alpha)$ is injective on $[-a_(r),a_(l)]$ if and only if $a_(l)+a_(r) <= e_(R)-1$, where $e_(R)=op("lcm")(e_(1),e_(2),e_(3))$; the joint collisions are the multiples of $e_(R)$. In particular $op("max")_(i) e_(i) <= e_(R) <= n$.]

*Proof.* A difference is a joint collision if and only if it is a collision in every component, that is, if and only if $e_(i) | delta$ for all $i$ by Theorem 4.2 for the active components and by constancy of the syndrome for the inactive ones. This is the condition $e_(R) | delta$. The inequalities follow from $e_(i) | e_(R)$ and #context numbering("(1)", counter(math.equation).at(<eq-edivn>).first()). $square$

Thus one triple may well gain from fusion: components with periods $(3,4,5)$ fuse to $60$, and Table 6 lists the triples of that kind with the largest ratio between the fused period and the largest component period. The question is whether fusion raises the _best achievable_ window, and the answer is negative.

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Lemma 4.7.] Let $E(q,n)$ be the set of periods $op("ord")_(x)(f)$ of branches $C^(perp) subset.eq C subset.neq D$ of length $n$ over $bb(F)_(q)$. Then $E(q,n) != emptyset$ if and only if $-1 in.not ⟨ q⟩ subset.eq (bb(Z) slash n bb(Z))^(*)$, and in that case $n in E(q,n)$.]

*Proof.* If $-1 in ⟨ q⟩$ there is no branch by Theorem 2.7. Otherwise let $p$ be an irreducible factor of $Phi_(n)$. By Lemma 2.6 it is not self-reciprocal, so $C=⟨ p⟩$ is dual-containing by Lemma 2.5. With $D=bb(F)_(q)^(n)$ one gets $f=p$, whose roots are primitive $n$-th roots of unity, hence $op("ord")_(x)(p)=n$. $square$

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Theorem 4.8.] If $-1 in ⟨ q⟩ subset.eq (bb(Z) slash n bb(Z))^(*)$, no synchronizable code of the above type exists over $bb(F)_(q)$ or over $R$. Otherwise

$ op("max")_("triples") op("lcm")(e_(1),e_(2),e_(3))=op("max") E(q,n)=n, $ <eq-nogain>

so the largest window of a ring code of length $n$ is $n-1$ and is already attained by a single component. The same holds for any number of components.]

*Proof.* The first statement combines Theorem 2.7 with Proposition 2.3. By #context numbering("(1)", counter(math.equation).at(<eq-edivn>).first()) every $e_(i)$ divides $n$, so $op("lcm")(e_(1),e_(2),e_(3)) <= n$; by Lemma 4.7 $n in E(q,n)$, and the triple $(n,n,n)$ attains the bound. The argument does not refer to the number of components. $square$

The ring's contribution is therefore not the window itself but the freedom to distribute it. This is worth stating precisely, because a natural reading of "three components fused by an lcm" suggests a gain that Theorem 4.8 rules out.

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Remark 4.9.] What the ring provides is a _relaxation_: the maximal period $n$ can be obtained from three components whose individual periods $m_(1),m_(2),m_(3)$ are much smaller, provided $op("lcm")(m_(1),m_(2),m_(3))=n$. For $n | q-1$ this is realised by linear branches $C_(i)=⟨ x-a_(i)⟩ subset.neq bb(F)_(q)^(n)$ with $a_(i) in bb(F)_(q)^(*)$ of order $m_(i)$. For a reproducible finite enumeration take every odd prime $q <= 101$ and every $n >= 3$ dividing $q-1$, enumerate the sorted divisor triples $3 <= m_(1) <= m_(2) <= m_(3)$ with $m_(i) | n$ and $op("lcm")(m_(1),m_(2),m_(3))=n$, and for each $(q,n)$ minimise the largest order, breaking ties lexicographically. This gives $118$ pairs, of which $38$ have relaxation factor $n slash op("max")_(i) m_(i)>1$; the maximum in this range is $12$, attained at $(q,n)=(61,60)$ with orders $(3,4,5)$. The bound is not universal: the orders $(5,6,7)$ at $(211,210)$ give factor $30$ and $(5,7,8)$ at $(281,280)$ give factor $35$. In general, for pairwise coprime $a,b,c >= 3$ choose a prime $q equiv 1 (op("mod") a#h(0em)b#h(0em)c)$, whose existence is Dirichlet's theorem, and put $n=a b c$; linear branches of orders $(a,b,c)$ then have factor $a b c slash op("max")(a,b,c)$, and the choice $(a,b,c)=(t,t+1,2 t+1)$ makes this $t(t+1)$. These linear families have $d_(X)=1$ and therefore do not improve the Pauli-error distance.]

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Question 4.10.] Does $op("max")_("triples") op("lcm")(e_(1),e_(2),e_(3))=n$ persist when $op("min") op("wt")(D_(i) without C_(i)^(perp)) >= t$ is required on every branch, for $t >= 4$? For $t=2$, equivalently proper $D_(i)$ by Remark 3.2, it holds in all $27$ admissible pairs of Table 7, and at $(q,n)=(3,13)$ the branch of Example 5.5 is a witness with $t=3$. Larger $t$ was beyond our search, and we do not conjecture an answer.]

= Message-carrying markers

== Marker families

A marker that carries classical information has a residue restricted to a message family. Fix a branch with $f=g_(C) slash g_(D)$, $e=op("ord")_(x)(f)$ and an integer $y$ with $0 <= y <= op("deg") f-1$, and put

$ cal(M)_(y)=\{1+b_(1) x+dots+b_(y) x^(y)#":"b_(1),dots,b_(y) in bb(F)_(q)\} subset.eq bb(F)_(q)[x] slash (f),#h(2.2em) |cal(M)_(y)|=q^(y). $ <eq-My>

The condition $b_(0)=1$ normalises the family: every nonzero residue class modulo $f$ has a unique scalar multiple with constant term $1$, so $cal(M)_(y)$ selects one representative from each of $q^(y)$ classes rather than a linear subspace. This is what makes the family closed under the comparison of two messages and keeps the zero residue out of the message set for $y<op("deg") f$.

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Lemma 5.1.] Let $0 <= y$ and let $cal(M)_(y)$ be as in #context numbering("(1)", counter(math.equation).at(<eq-My>).first()). If $y <= op("deg") f$, distinct elements of $cal(M)_(y)$ have distinct residues modulo $f$; for $y=op("deg") f$ the reduction map $cal(M)_(op("deg") f) arrow.r bb(F)_(q)[x] slash (f)$ is a bijection. If $y >= op("deg") f+1$, two distinct elements of $cal(M)_(y)$ have the same residue.]

*Proof.* If $b != b'$ in $cal(M)_(y)$ had $b equiv b'(op("mod") f)$, then $u=b-b'$ would be a nonzero polynomial of degree at most $y$ divisible by $f$, so $op("deg") f <= y$; and $u(0)=0$. For $y<op("deg") f$ this is impossible. For $y=op("deg") f$ the only possibility would be $u=c f$ with $c != 0$, which has $u(0)=c f(0) != 0$, again impossible; the map is then injective between sets of size $q^(op("deg") f)$, hence bijective. For $y >= op("deg") f+1$, $b=1+x f$ and $b'=1$ are distinct elements of $cal(M)_(y)$ with equal residues. $square$

The boundary case $y=op("deg") f$ is worth isolating, because it is the point at which the message family fills the whole quotient ring and the zero class enters: $cal(M)_(op("deg") f)$ is a complete set of representatives of $bb(F)_(q)[x] slash (f)$, so for every offset difference $delta$ and every $b in cal(M)_(op("deg") f)$ the residue of $x^(delta) b$ is again an admissible message, and every nonzero $delta$ is a collision. A positive window therefore requires $y <= op("deg") f-1$ in every component that is used for messages.

== The collision criterion

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Theorem 5.2.] Fix a branch with $f$, $e$ and a marker family $cal(M)_(y)$ with $0 <= y <= op("deg") f-1$, and let $Delta subset.eq bb(Z)_(n) without \{0\}$ be the set of collision differences. 1. A difference $delta != 0$ lies in $Delta$ if and only if $x^(delta) cal(M)_(y)∩cal(M)_(y) != emptyset$ modulo $f$, that is, if and only if $x^(delta) b (op("mod") f) in cal(M)_(y)$ for some $b in cal(M)_(y)$. 2. If $delta in Delta$ then $|delta|+y >= op("deg") f$. Consequently $a_(l)+a_(r) <= op("deg") f-y-1$ guarantees injectivity, without knowledge of $e$. 3. For $y=0$ the collision set is the set of multiples of $e$ and the window is $e-1$.]

*Proof.* (1) A collision means $f | x^(delta) b-b'$ for some $b,b' in cal(M)_(y)$, which is the same as $x^(delta) b (op("mod") f)=b'$. (2) For $delta >= 1$ the polynomial $u=x^(delta) b-b'$ is nonzero: $b$ has constant term $1$, so $x^(delta) b$ has constant term $0$ and $u(0)=-1 != 0$. Since $f | u$ and $op("deg") u <= delta+y$, we get $op("deg") f <= delta+y$. For $delta <= -1$, multiply the congruence by the unit $x^(|delta|)$ modulo $f$ and exchange the roles of $b$ and $b'$. (3) With $cal(M)_(0)=\{1\}$ this is Theorem 4.2. $square$

Part (2) is a bound, not a value, and the difference matters. When $e>op("deg") f$ the exact window can exceed the guarantee, as Table 2 shows in the second row, where the exact window is two cells and the guarantee one. When the guarantee is attained it is attained exactly at $delta+y=op("deg") f$, as in the third and fifth rows. Both behaviours occur for the same branch as $y$ varies, so neither can be inferred from $op("deg") f$ alone.

#figure(
  table(columns: 10, align: center,
    table.header([*$q$*], [*$n$*], [*$f$*], [*$op("deg") f$*], [*$e$*], [*$y$*], [*$|cal(M)_(y)|$*], [*collisions $delta in [1,n-1]$*], [*window*], [*guarantee*]),
    [3], [13], [$2+2 x+x^(3)$], [3], [13], [0], [1], [none], [12], [2],
    [3], [13], [$2+2 x+x^(3)$], [3], [13], [1], [3], [$\{3,10\}$], [2], [1],
    [3], [13], [$2+2 x+x^(3)$], [3], [13], [2], [9], [all], [0], [0],
    [5], [8], [$2+x^(2)$], [2], [8], [0], [1], [none], [7], [1],
    [5], [8], [$2+x^(2)$], [2], [8], [1], [5], [$\{1,3,5,7\}$], [0], [0],
    [7], [6], [$4+x$], [1], [6], [0], [1], [none], [5], [0],
    [11], [5], [$7+x$], [1], [5], [0], [1], [none], [4], [0]
  ),
  caption: [*Table 2.* Collision sets for message-carrying markers with $0 <= y <= op("deg") f-1$; the last column is the guarantee $op("deg") f-y-1$ of Theorem 5.2(2).],
  kind: "table",
) <tab-hybrid>
  #v(0.35em)
  #par(justify: true, first-line-indent: 0em)[#text(size: 8.6pt)[The third row is the boundary case $y=op("deg") f-1$ of a cubic $f$ over $bb(F)_(3)$; the collision set is all of $bb(Z)_(13) without \{0\}$ because the nine messages exhaust the classes with constant term one among the $27$ residues.]]

== Sharing the frame

At ring level each component has its own marker family $cal(M)_(y_(i))$, and the receiver observes the triple #context numbering("(1)", counter(math.equation).at(<eq-sigma>).first()). A joint collision at difference $delta$ requires a collision in every component at the same difference, so the joint collision set is an intersection.

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Proposition 5.3.] Let $Delta_(i) subset.eq bb(Z)_(n) without \{0\}$ be the collision set of component $i$, with $Delta_(i)=emptyset$ for an inactive component, and let $w_(i)$ be its window. Then the joint collision set is $Delta_(1)∩Delta_(2)∩Delta_(3)$, the joint window is $w=op("min")\{|delta|#":"delta in Delta_(1)∩Delta_(2)∩Delta_(3)\}-1$, with $w=n-1$ if the intersection is empty, and $w >= op("max")_(i) w_(i)$. The ring code carries $y_(1)+y_(2)+y_(3)$ classical symbols.]

*Proof.* Two pairs $(alpha,m)$ and $(alpha',m')$ produce the same observation exactly when they do so in every component. If $alpha=alpha'$ then $m=m'$ because distinct elements of $cal(M)_(y_(i))$ are distinct modulo $f_(i)$ by Lemma 5.1; if $alpha-alpha'=delta != 0$ then $delta in Delta_(i)$ for every $i$. The symbol count is the sum because the components occupy disjoint coordinates. For the inequality, note that $Delta_(1)∩Delta_(2)∩Delta_(3) subset.eq Delta_(i)$ for each $i$, so the least absolute element of the intersection is at least the least absolute element of $Delta_(i)$. $square$

The inequality $w >= op("max")_(i) w_(i)$ is what makes the allocation of Section 5.4 useful, and it has a clean special case.

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Proposition 5.4.] Suppose $y_(1)=0$ and the marker residue of component $1$ is coprime to $f_(1)$. Then $Delta_(1)$ consists of the multiples of $e_(1)$, so $w <= e_(1)-1$; and $w=e_(1)-1$ as soon as some component $j$ has $w_(j) >= e_(1)-1$.]

*Proof.* Theorem 4.2 gives $Delta_(1)=e_(1) bb(Z)_(n) without \{0\}$. The positive elements of $e_(1) bb(Z)_(n)$ are $e_(1),2 e_(1),dots,n-e_(1)$; this set is empty when $e_(1)=n$, and otherwise $n-e_(1) >= e_(1)$ because $e_(1) | n$, so its least element in absolute value is $e_(1)$. Hence $w <= e_(1)-1$. The reverse inequality is Proposition 5.3. $square$

Proposition 5.4 is the precise form of the statement that one component can hold the frame while the others carry messages. It should not be read as an increase in capacity: the total number of classical symbols is still $M=sum_(i)(k_(D,i)-k_(C,i))$, and the messages occupy $y_(i)$ of the $op("deg") f_(i)$ symbol slots of component $i$. What the ring buys is the freedom to spend those slots asymmetrically.

== A ternary example

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Example 5.5.] Over $bb(F)_(3)$ with $n=13$ let $C=⟨ 1+x^(2)+x^(5)+x^(6)⟩$, a $[13,7,4]$ code, and $D=⟨ 2+x+x^(2)+x^(3)⟩$, a $[13,10,3]$ code. Then $C^(perp) subset.eq C subset.eq D$, and $f=2+2 x+x^(3)$. Since $op("ord")_(13)(3)=3$, every irreducible factor of $Phi_(13)$ over $bb(F)_(3)$ is a cubic whose roots are primitive $13$-th roots of unity, and $f$ is one of them; hence $e=13$ and the window is $12$ cells, whereas the degree criterion certifies $2$. Replicating this branch in all three components gives, by Proposition 3.1,

$ [[#h(0.17em)39,#h(0.17em)3#":"9,#h(0.17em)0,#h(0.17em)3#h(0.17em)]]_(3), $ <eq-flagship>

since $N=39$, $K=3(2 dot 7-13)=3$, $M=3(10-7)=9$ and $d=op("min")(d_(Z),d_(X))=op("min")(4,3)=3$.]

The example is small enough that every quantity in it can be checked by enumerating all codewords, which we did: $|C|=3^(7)=2187$, $|D|=3^(10)=59049$, $C^(perp) subset.eq C subset.eq D$, $d(C)=4$, $d(D)=3$, $op("min") op("wt")(C without C^(perp))=4$ and $op("min") op("wt")(D without C^(perp))=3$. Table 3 records the allocations. The first row is the pure synchronization mode; the second spends one ternary symbol per component and loses most of the window; the fourth keeps the full window while transmitting four symbols, because components $2$ and $3$ have collision sets equal to all of $bb(Z)_(13) without \{0\}$ and therefore cannot destroy the discrimination provided by component $1$. The last figure, four symbols, is the largest possible with a twelve-cell window. A single symbol in component $1$ already produces the collisions $\{3,10\}$, which lie inside $[1,12]$, so $y_(1)=0$ is forced; components $2$ and $3$ may each carry up to $op("deg") f-1=2$ symbols, since $y=2$ gives a collision at every difference but its intersection with an empty collision set is still empty. It is also well below the nine symbol slots of #context numbering("(1)", counter(math.equation).at(<eq-flagship>).first()), which is the distinction between the hybrid capacity of the code and the marker payload actually transmitted.

#figure(
  table(columns: 6, align: center,
    table.header([*$(y_(1),y_(2),y_(3))$*], [*symbols*], [*joint collisions*], [*window $w$*], [*padded length*], [*payload $K slash (3(13+w))$*]),
    [$(0,0,0)$], [0], [none], [12], [75], [0.040],
    [$(1,1,1)$], [3], [$\{3,10\}$], [2], [45], [0.067],
    [$(2,2,2)$], [6], [all], [0], [39], [0.077],
    [$(0,1,1)$], [2], [none], [12], [75], [0.040],
    [$(0,2,2)$], [4], [none], [12], [75], [0.040]
  ),
  caption: [*Table 3.* Marker allocations for the code of Example 5.5. Symbols are ternary; the padded length is $3(13+w)$ qudits.],
  kind: "table",
) <tab-alloc>
  #v(0.35em)
  #par(justify: true, first-line-indent: 0em)[#text(size: 8.6pt)[The payload column is the number of logical qudits per physical qudit and is included only to make the cost of the window explicit; the code itself is the same in all rows, and only the marker allocation changes.]]

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Remark 5.6.] The construction extends formally to subsystem codes in the framework of #cite(<TansuwannontNemec2026>). Per component take cyclic codes $C_(x),C_(z)$ with $C_(z)^(perp) subset.eq C_(x)$ and marker codes $C_(x) subset.eq D_(x)$, $C_(z) subset.eq D_(z)$, and the gauge group $G=⟨ omega I,#h(0.17em) X(C_(z)^(perp)),#h(0.17em) Z(C_(x)^(perp))⟩$. With $r_(x)=op("dim")(C_(x)+C_(z)^(perp))$ and $r_(z)=op("dim")(C_(z)+C_(x)^(perp))$ the parameters are $k=r_(x)+k_(z)-n$, $m=k_(D_(x))+k_(D_(z))-k_(x)-k_(z)$, $r=r_(x)-k_(x)$, and the distances are $d_(x)=op("min") op("wt")((D_(x)+D_(z)^(perp)) without C_(z)^(perp))$ and $d_(z)=op("min") op("wt")((D_(z)+D_(x)^(perp)) without C_(x)^(perp))$. In the symmetric case $C_(x)=C_(z)=C$, $D_(x)=D$, $D_(z)=C$ one recovers $r=0$, $k=2 k_(C)-n$, $m=k_(D)-k_(C)$, $d_(x)=op("min") op("wt")(D without C^(perp))$ and $d_(z)=op("min") op("wt")(C without C^(perp))$, which is Proposition 3.1. The three components have independent gauge sectors but share one frame, so the synchronization threshold depends only on the markers. Only the symmetric case is evaluated numerically in this paper, and the asymmetric case is recorded here as a structural observation rather than as a verified construction.]

= Computational verification

== Method

All numerical statements in this paper were produced by an exact-arithmetic implementation written for the verification and independent of the programs distributed with the earlier version of this work. The implementation contains its own arithmetic over prime fields, its own factorisation of $x^(n)-1$ into irreducible factors (distinct-degree decomposition followed by Cantor--Zassenhaus splitting), its own order computation, and its own routines for enumerating branches, collision sets and codewords. No floating-point operation is used at any point where an algebraic decision is made, and no result is imported from the earlier programs.

Two cross-checks guard against implementation error. First, the branch count for a pair $(q,n)$ has the closed form

$ N_("br")(q,n)=5^(m)-3^(m), $ <eq-closedform>

where $m$ is the number of reciprocal pairs among the non-self-reciprocal irreducible factors of $x^(n)-1$. The reason is that $g_(C)$ may contain at most one member of each pair, which leaves three choices per pair for $g_(C)$ (neither factor, the first, the second) and then two further choices for the factor that is present, namely whether it is assigned to $g_(D)$ or to $f$; counting the resulting states per pair and removing the $3^(m)$ cases with $f=1$ gives #context numbering("(1)", counter(math.equation).at(<eq-closedform>).first()). The branches with $D$ proper are those with $g_(D) != 1$; since $g_(D)=1$ means $D=bb(F)_(q)^(n)$ and then $f=g_(C)$ ranges over the $3^(m)$ dual-containing generators with $f != 1$, their number is $5^(m)-2 dot 3^(m)+1$. Both formulas were checked against the explicit enumeration on all $81$ pairs. Second, the independent programs distributed with the earlier version, which use a different computer-algebra system, were run on the same inputs and agree with the present implementation on every count reported below.

== The census

Table 4 reports the exhaustive census of branches for $q in \{3,5,7,11,13\}$ and $2 <= n <= 20$ with $op("gcd")(n,q)=1$. Branches exist for exactly the $39$ pairs with $-1 in.not ⟨ q⟩$, in agreement with Theorem 2.7; the largest period equals $n$ for each of them, in agreement with Lemma 4.7; and every one of the $20#h(0.17em)724$ branches satisfies $e>op("deg") f$, in agreement with Proposition 4.5. The last column is therefore a complete check of Proposition 4.5 in this range rather than a sample.

#figure(
  table(columns: 6, align: center,
    table.header([*$q$*], [*pairs $(q,n)$*], [*pairs with a branch*], [*branches*], [*$e>op("deg") f$*], [*largest period*]),
    [3], [13], [5], [38], [38], [$n$],
    [5], [15], [6], [136], [136], [$n$],
    [7], [17], [9], [808], [808], [$n$],
    [11], [18], [9], [16 134], [16 134], [$n$],
    [13], [18], [10], [3 608], [3 608], [$n$],
    [total], [81], [39], [20 724], [20 724], [---]
  ),
  caption: [*Table 4.* Exhaustive census of branches $C^(perp) subset.eq C subset.neq D$ for $2 <= n <= 20$ and $op("gcd")(n,q)=1$.],
  kind: "table",
) <tab-census>
  #v(0.35em)
  #par(justify: true, first-line-indent: 0em)[#text(size: 8.6pt)[The largest period column records that $op("max") E(q,n)=n$ for every pair that admits a branch.]]

The census also shows how the exact threshold compares with the degree bound across a whole family; Figure 3 plots $e$ against $op("deg") f$ for all $38$ branches over $bb(F)_(3)$ with $n <= 20$. All points lie above the diagonal, as Proposition 4.5 requires, and the vertical distance to the diagonal is the number of cells by which the degree criterion understates the window.

#figure(image("figures/fig_scatter.svg", width: 78%), caption: [*Figure 3.* Exact window $e-1$ against the degree bound $op("deg") f-1$ for all branches over $bb(F)_(3)$ with $2 <= n <= 20$ and $op("gcd")(n,3)=1$. Points above the diagonal are branches for which the degree criterion is not sharp; the diagonal is drawn for reference.]) <fig-scatter>

== Collision sets and windows

Theorem 4.2 was checked against the directly computed syndrome map for $1#h(0.17em)970$ branches: for each branch the set of differences $delta$ with $Sigma(alpha)=Sigma(alpha+delta)$ for some $alpha$ was compared with the set of multiples of $e$, and the two sets coincided in every case. The injectivity boundary was checked separately: for $540$ combinations of branch and split $(a_(l),a_(r))$ with $a_(l)+a_(r)=e-1$ the map was injective, and with $a_(l)+a_(r)=e$ it was not. Theorem 4.6 was checked on $32$ triples of branches drawn from eight pairs, and Theorem 5.2 on $123$ branch-family combinations, including the boundary case $y=op("deg") f-1$. Proposition 5.3 and the general-residue statement of Appendix B were checked on $708$ combinations of branch and marker residue. In each case the computed collision set matched the predicted one exactly.

== Fusion, relaxation and the proper-$D$ constraint

The comparison is made concrete by Table 5, which lists ring codes assembled from three explicit branches. In every row the fused period equals the best single period, as Theorem 4.8 predicts, and the two no-go lengths are those of Example 2.8. The table also makes the point of Theorem 4.8 concrete: the ring construction adds quantum symbols ($K$ exceeds what the best single component would carry) but not synchronization.

#figure(
  table(columns: 8, align: center,
    table.header([*$q$*], [*$n$*], [*$(e_(1),e_(2),e_(3))$*], [*$e_(R)$*], [*best single*], [*$N$*], [*$K$*], [*window*]),
    [3], [8], [$(8,8,8)$], [8], [8], [24], [12], [7],
    [3], [13], [$(13,13,13)$], [13], [13], [39], [21], [12],
    [5], [8], [$(4,4,8)$], [8], [8], [24], [16], [7],
    [5], [12], [$(4,4,12)$], [12], [12], [36], [28], [11],
    [7], [6], [$(3,3,6)$], [6], [6], [18], [12], [5],
    [7], [15], [$(3,3,15)$], [15], [15], [45], [33], [14],
    [11], [5], [$(5,5,5)$], [5], [5], [15], [9], [4],
    [13], [6], [$(3,3,6)$], [6], [6], [18], [12], [5],
    [3], [10], [no branch], [---], [---], [---], [---], [---],
    [7], [10], [no branch], [---], [---], [---], [---], [---]
  ),
  caption: [*Table 5.* Ring codes from three explicit branches: periods, fused period, best single period and parameters. For $(3,10)$ and $(7,10)$ no branch exists.],
  kind: "table",
) <tab-fusion>
  #v(0.35em)
  #par(justify: true, first-line-indent: 0em)[#text(size: 8.6pt)[Each row was realised by an explicit triple of branches whose component dimensions reproduce the listed $K$; the window is $e_(R)-1$ cells.]]

Table 6 lists the relaxation families with the largest factors in the enumeration of Remark 4.9. Figure 4 shows the distribution of the factor over all $118$ pairs: most pairs gain nothing, but a substantial minority does, and the tail reaches $12$ within the stated cutoff.

#figure(
  table(columns: 5, align: center,
    table.header([*$q$*], [*$n$*], [*component periods $(m_(1),m_(2),m_(3))$*], [*$e_(R)$*], [*$n slash op("max")_(i) m_(i)$*]),
    [61], [60], [$(3,4,5)$], [60], [12],
    [73], [72], [$(3,8,9)$], [72], [8],
    [89], [88], [$(4,8,11)$], [88], [8],
    [71], [70], [$(5,7,10)$], [70], [7],
    [43], [42], [$(3,6,7)$], [42], [6],
    [67], [66], [$(3,6,11)$], [66], [6],
    [79], [78], [$(3,6,13)$], [78], [6]
  ),
  caption: [*Table 6.* Relaxation families with linear branches ($n | q-1$): the seven pairs with factor at least $6$ in the enumeration of Remark 4.9.],
  kind: "table",
) <tab-relax>
  #v(0.35em)
  #par(justify: true, first-line-indent: 0em)[#text(size: 8.6pt)[For $q <= 101$ all $118$ pairs and their selected triples are given in the accompanying data set; $38$ have factor $>1$. Ties in minimising the largest period are broken lexicographically. The selected branches are linear, $C_(i)=⟨ x-a_(i)⟩ subset.neq bb(F)_(q)^(n)$, so $D_(i)=bb(F)_(q)^(n)$ and $d_(X)=1$ in every row.]]

#figure(image("figures/fig_relax.svg", width: 78%), caption: [*Figure 4.* Distribution of the relaxation factor $n slash op("max")_(i) m_(i)$ over the $118$ pairs of Remark 4.9.]) <fig-relax>

Imposing the constraint that $D$ be proper restricts $d_(X) >= 2$ by Remark 3.2 and reduces the list to $27$ pairs, tabulated in Table 7. Every one of them still admits a triple with fused period $n$, so the negative result of Theorem 4.8 is not an artefact of degenerate branches; the question left open is the behaviour for $d_(X) >= 4$.

#figure(
  table(columns: 4, align: center,
    table.header([*$q$*], [*$n$*], [*attainable periods $E$*], [*witness*]),
    [3], [13], [$\{13\}$], [$(13,13,13)$],
    [3], [16], [$\{8,16\}$], [$(8,8,16)$],
    [5], [8], [$\{4,8\}$], [$(4,4,8)$],
    [5], [12], [$\{4,12\}$], [$(4,4,12)$],
    [5], [16], [$\{4,8,16\}$], [$(4,4,16)$],
    [7], [6], [$\{3,6\}$], [$(3,3,6)$],
    [7], [9], [$\{3,9\}$], [$(3,3,9)$],
    [7], [12], [$\{3,6,12\}$], [$(3,3,12)$],
    [7], [15], [$\{3,15\}$], [$(3,3,15)$],
    [7], [16], [$\{16\}$], [$(16,16,16)$],
    [7], [18], [$\{3,6,9,18\}$], [$(3,6,9)$],
    [7], [19], [$\{19\}$], [$(19,19,19)$],
    [11], [5], [$\{5\}$], [$(5,5,5)$],
    [11], [10], [$\{5,10\}$], [$(5,5,10)$],
    [11], [14], [$\{7,14\}$], [$(7,7,14)$],
    [11], [15], [$\{5,15\}$], [$(5,5,15)$],
    [11], [16], [$\{8,16\}$], [$(8,8,16)$],
    [11], [19], [$\{19\}$], [$(19,19,19)$],
    [11], [20], [$\{5,10,20\}$], [$(5,5,20)$],
    [13], [6], [$\{3,6\}$], [$(3,3,6)$],
    [13], [8], [$\{4,8\}$], [$(4,4,8)$],
    [13], [9], [$\{3,9\}$], [$(3,3,9)$],
    [13], [12], [$\{3,4,6,12\}$], [$(3,3,4)$],
    [13], [15], [$\{3,15\}$], [$(3,3,15)$],
    [13], [16], [$\{4,8,16\}$], [$(4,4,16)$],
    [13], [18], [$\{3,6,9,18\}$], [$(3,6,9)$],
    [13], [20], [$\{4,20\}$], [$(4,4,20)$]
  ),
  caption: [*Table 7.* All $27$ pairs for which a branch with proper $D$ exists, with the attainable periods $E$ and a witness triple whose least common multiple is $n$.],
  kind: "table",
) <tab-dconstr>
  #v(0.35em)
  #par(justify: true, first-line-indent: 0em)[#text(size: 8.6pt)[$E$ lists all periods $op("ord")_(x)(f)$ realised by branches with proper $D$ for that pair; a single branch already attains $op("max") E=n$ in every row. The other $54$ pairs of the census admit no such branch.]]

== The flagship code

For the code of Example 5.5 the stabilizer group was constructed explicitly and its generators were verified to commute pairwise; the $X$-type part and the $Z$-type part each have rank $18$ over $bb(F)_(3)$, giving $K=39-2 dot 18=3$ in agreement with #context numbering("(1)", counter(math.equation).at(<eq-flagship>).first()). The distances $d_(Z)=4$ and $d_(X)=3$ were obtained by enumerating all $2#h(0.17em)187$ and $59#h(0.17em)049$ words of $C$ and $D$; no word of $D without C^(perp)$ has weight below $3$, and the minimum is attained. The marker cascade of Table 3 was verified by computing the collision sets directly from equation #context numbering("(1)", counter(math.equation).at(<eq-collision>).first()) for each allocation, not from Theorem 5.2.

== Complexity

The computations have three layers with different costs. Factoring $x^(n)-1$ by distinct-degree decomposition and Cantor--Zassenhaus splitting costs $O(n^(2) op("log") n)$ field operations with schoolbook polynomial arithmetic, plus the cost of the randomised splitting. Computing $e=op("ord")_(x)(f)$ for one branch costs $O(n^(2) op("log")^(2) n)$ in the worst case, since $e | n$, the exponent is found by dividing $n$ by its prime factors, and each of the $O(op("log") n)$ trials requires a modular exponentiation costing $O(n^(2) op("log") n)$. Enumerating all branches of a pair costs $5^(m)-3^(m)$ steps for $m$ reciprocal factor pairs, which is exponential in $m$; in the census $m <= 6$, so no pair required more than $14#h(0.17em)896$ enumerations. Brute-force collision sets cost $O(n^(2))$ syndrome comparisons per branch and were used only where the exhaustive check was the point; the criterion of Theorem 4.2 computes the same set in $O(n)$ after $e$ is known. Message-collision tests cost $O(n q^(y))$ reductions modulo $f$, which is why the message tables are confined to small $y$. Distance computations require enumerating $q^(k)$ words and were therefore restricted to codes with $q^(k) <= 6 times 10^(4)$.

Measured on one core of the verification environment, the complete core suite of eighteen theorem checks, which includes $1#h(0.17em)970$ branch collision sets and $540$ window splittings, runs in $25.1$ s, and the entire census of $20#h(0.17em)724$ branches over $81$ pairs runs in $0.17$ s. These figures describe construction-time algebra; they say nothing about the cost of decoding a received block, which is not analysed here.

= Discussion and limitations

The results above are exact within their model, and the model is narrow. It is worth being specific about what the narrowness excludes, because the phrase "synchronizable code" can suggest a physical capability that the theorems do not deliver.

_Exact syndromes._ Assumption (A2) is the substantive restriction. Theorem 4.2 characterises the injectivity of an idealised syndrome map; a physical receiver measures syndromes through a noisy circuit, and errors in that circuit can move the observed syndrome to a value belonging to a different offset. The analysis here neither bounds the resulting error probability nor designs a decoder that tolerates it. A treatment of this question would need to model the syndrome extraction explicitly and to combine the offset estimate with the physical-error correction, which is a different problem from the one solved here.

_Whole-cell offsets._ Misalignments by one or two qudits, which would displace the three components relative to each other, are excluded by construction. The interleaving of Section 3 is what makes the components share an offset, and it is also what forbids offsets that are not multiples of three. A construction that corrects single-qudit offsets would need either a different lift or a nested structure within each component, and we do not propose one.

_Prime fields._ The algebra of Sections 2--4 uses only that $bb(F)_(q)$ is a field of odd characteristic and that $op("gcd")(n,q)=1$; the restriction to prime $q$ is a restriction of the computations, not of the theory. Extending the enumerations to prime powers would require field arithmetic over $bb(F)_(p^(m))$ and would not change any of the proofs.

_Distances._ The distance statement of Proposition 3.1 is combinatorial and was evaluated only for small codes, by enumeration. No asymptotic distance analysis is attempted, and the constructions are not compared with the best known quantum codes of comparable length; such a comparison would require either bounds that do not need enumeration or a much larger computational budget.

_Novelty._ The individual ingredients of this paper are known. Ring decompositions of the type #context numbering("(1)", counter(math.equation).at(<eq-decomp>).first()) and the idempotents #context numbering("(1)", counter(math.equation).at(<eq-idem>).first()) are standard in the construction of quantum codes from cyclic codes over rings #cite(<DinhEtAl2021>), #cite(<DinhBagUpadhyay2021>), and synchronizable codes over rings have been constructed before #cite(<LiuLiu2021>), #cite(<DaiLiu2022>), #cite(<LiuHuLiu2024>). The order criterion is due to #cite(<FujiwaraTonchevWong2013>) in the binary case and is used in the $q$-ary literature #cite(<XieYangYuan2016>), #cite(<LuoMa2018>). Converse statements, that a window larger than the order bound cannot exist, are also not new in themselves: they follow from the multiplicativity of the order and are implicit wherever the order is described as the period of the marker, for instance in #cite(<FujiwaraTonchevWong2013>). Hybrid synchronizable codes, including the trade-offs between synchronization, gauge degrees of freedom and classical capacity, are the subject of #cite(<TansuwannontNemec2026>). What we have not found in the literature is the combination used here as a design tool: the exact collision set, applied uniformly across a ring decomposition to show that the degree criterion is never sharp for dual-containing branches, that three components cannot fuse to a period beyond $n$, and that the fusion nevertheless buys a quantifiable relaxation of the per-component period. Which parts of this are genuinely new, as opposed to implicit in the order literature, we cannot settle from the sources available to us. In particular we could not obtain the full text of #cite(<LiZhu2022>), whose title and abstract indicate the closest overlap, so we cannot exclude that part of the ring construction is anticipated there. This is a limitation of our search, not a claim about that paper, and it is the reason the contribution is stated as a combination rather than as an individual theorem.

_Optimality._ No optimality is claimed. The thresholds are exact for the codes considered, but the codes are not shown to be optimal in any sense, and the relaxation families of Remark 4.9 have $d_(X)=1$, which makes them poor choices for Pauli-error protection even though their synchronization parameters are excellent.

_Question 4.10._ The behaviour of the fused period under a distance constraint $d_(X) >= 4$ is open in this paper. It is conceivable that the constraint forces every branch to have small order, which would make the relaxation of Remark 4.9 unavailable in the regime where it matters most; we did not find a proof either way.

Two positive conclusions survive these caveats. The first is methodological: for design purposes the quantity to compute is $op("ord")_(x)(f)$, not $k_(D)-k_(C)$, and the difference between the two can be a factor of six in window for a code as small as the one in Example 5.5. The second is structural: the three-component ring does not enlarge the window, but it does allow the window to be carried by a component whose period is small while the other components carry messages, and it allows the synchronized part of a design to be separated from the parts that are optimized for distance.

= Conclusion

We analysed synchronizable hybrid codes obtained from cyclic codes over $R=bb(F)_(q)[v] slash (v^(3)-v)$ for odd prime $q$, using the idempotent decomposition $R tilde.equiv bb(F)_(q)^(3)$ and an interleaved lift to $3 n$ qudits grouped into cells. Within the idealised model of exact marker syndromes, collision sets, existence and fused thresholds are characterised by proofs, and the numerical statements were confirmed independently.

The undetectable offsets of a branch are exactly the multiples of $e=op("ord")_(x)(f)$, so the window is $e-1$ and the known sufficient order condition is also necessary in the ideal model. For every dual-containing branch $op("deg") f <= e-1$, so the degree-type criterion is never sharp; the census of $20#h(0.17em)724$ branches confirms this, and for the $[13,7,4] subset.eq [13,10,3]$ branch over $bb(F)_(3)$ the exact window of twelve cells is six times the two cells that the degree criterion certifies.

Branches of length $n$ exist if and only if $-1 in.not ⟨ q⟩ (op("mod") n)$, and then one of them has period $n$. Three components fuse with period $op("lcm")(e_(1),e_(2),e_(3))$, which never exceeds $n$ and is already attained by a single component: fusion does not enlarge the window. What it does provide is a relaxation of the per-component requirement, whose factor is bounded by $12$ in the enumeration with $q <= 101$ but is unbounded in general, at the cost of a poor $X$-distance.

With message-carrying markers the window is governed by an exact membership criterion, a collision at difference $delta$ forces $|delta|+y >= op("deg") f$, and the frame can be held by one component while the others transmit. In the ternary example the underlying hybrid code has parameters $[[39,3#":"9,0,3]]_(3)$ and four of its nine classical symbol slots can be used for messages at a twelve-cell window and a padded length of $75$ qudits.

The natural continuations are the three that the limitations make visible: a model in which the marker syndrome is noisy and the offset estimate is combined with physical-error correction; offsets by single qudits, which require a different lift; and Question 4.10, the behaviour of the fused period under a distance constraint. A fourth, more speculative direction is to replace the three-component ring by $bb(F)_(q)[v] slash (v^(k+1)-v)$ with $k+1$ components, where Theorem 4.8 applies verbatim but the relaxation and allocation trade-offs change.

#heading(numbering: none, level: 1)[Appendix A. The sign in the collision criterion]

In characteristic two the polynomials $x^(delta) b-b'$ and $x^(delta) b+b'$ coincide. In odd characteristic a shift by $delta$ multiplies a codeword polynomial by $x^(delta)$, so the collision condition is $f | x^(delta) b-b'$, and for $b=b'=1$ it reads $f | x^(delta)-1$. The condition $f | x^(delta)+1$, obtained with the opposite sign, holds exactly when $x^(delta) equiv -1 (op("mod") f)$, which requires $e$ even and $delta equiv e slash 2 (op("mod") e)$; its solution set is therefore disjoint from the set of multiples of $e$. Since $e slash 2$ is never a multiple of $e$, using the wrong sign would produce a collision set of the wrong size and, in the case $e=2$, a window of zero for a branch whose true window is one.

#heading(numbering: none, level: 1)[Appendix B. Marker residues that are not coprime to the generator quotient]

Theorem 4.2 assumes $op("gcd")(beta,f)=1$. The general case is not much harder and is useful when the marker is chosen for reasons other than synchronization, for instance to make the message family a subgroup.

#block(inset: (left: 1.1em), width: 100%, above: 0.85em, below: 0.85em)[#text(weight: "bold")[Proposition B.1.] Let $g=g_(D) beta$ with $beta$ not identically zero modulo $f$, and put $d=op("gcd")(beta,f)$ and $f_(0)=f slash d$. Then $delta$ is a collision for the marker $g$ if and only if $f_(0) | x^(delta)-1$; the collision set is the set of multiples of $op("ord")_(x)(f_(0))$, and the window is $op("ord")_(x)(f_(0))-1$. If $beta equiv 0 (op("mod") f)$, that is $g in C$, every difference is a collision and the window is zero.]

*Proof.* By Lemma 4.1 with $beta'=beta$, a difference $delta$ is a collision if and only if $f | beta(x^(delta)-1)$. Writing $beta=d b$ and $f=d f_(0)$ with $op("gcd")(b,f_(0))=1$, this is equivalent to $f_(0) | x^(delta)-1$. The order of $x$ modulo $f_(0)$ is defined because $f_(0)(0) != 0$, being a divisor of $f$, and the collision set is the set of its multiples. If $beta equiv 0$ the condition holds for every $delta$. $square$

Proposition B.1 shows that a marker sharing a factor with $f$ keeps a window equal to $op("ord")_(x)(f_(0))-1$ for the reduced modulus $f_(0)$, which divides $e$; in particular the window can only decrease, and it does so by the order of the discarded factor. This is the precise sense in which the coprimality hypothesis of Theorem 4.2 is a convenience rather than a restriction on the construction.


#v(1.2em)
#bibliography("References.bib", style: "ieee", title: "References")
