# LaTeX dependencies

`../Main_Manuscript.tex` is a self-contained `amsart` document. It needs no custom class, no local `.sty`, no shell escape and no external figure download. Everything it uses is in a standard TeX Live installation.

## Class and packages

| Item | Used for | TeX Live package |
|---|---|---|
| `amsart` (11pt, `reqno`) | document class | `amscls` |
| `amsmath`, `amssymb`, `amsthm` | display math, blackboard bold, theorem environments | `amsmath`, `amsfonts`, `amscls` |
| `booktabs` | `\toprule`, `\midrule`, `\bottomrule` in the seven tables | `booktabs` |
| `array` | column specifications in the tables | `tools` |
| `graphicx` | the four figures in `../figures/` | `graphics` |
| `microtype` | protrusion and font expansion | `microtype` |
| `geometry` (margin 1.05in) | page layout | `geometry` |
| `hyperref` (`hidelinks`) | internal links and PDF metadata | `hyperref` |
| `amsplain` (`.bst`) | bibliography style | `amscls` |

## Local commands defined in the preamble

`\F` → `\mathbb{F}`, `\Z` → `\mathbb{Z}`, `\wt` → `\operatorname{wt}`, `\ord` → `\operatorname{ord}`, `\lcm` → `\operatorname{lcm}`, `\M` → `\mathcal{M}`, `\gen{}` → `\langle \cdot \rangle`. All are defined in the preamble of the `.tex` itself, so no external file is required.

## Figures

Four SVGs in `../figures/`: `fig_flow.svg`, `fig_lift.svg`, `fig_scatter.svg`, `fig_relax.svg`. They are referenced with `\includegraphics`, which requires either `pdflatex` with the `svg` package or a conversion to PDF. **If your TeX installation cannot include SVG directly, convert the four files with `rsvg-convert -f pdf` or Inkscape and change the four `\includegraphics` extensions to `.pdf`.** This is the one build step that may need local action; it is recorded as a known caveat in the readiness report.

## Build

```
pdflatex Main_Manuscript.tex
bibtex   Main_Manuscript
pdflatex Main_Manuscript.tex
pdflatex Main_Manuscript.tex
```

Expected result: 23 pages, 27 references, seven tables, four figures, two appendices. The number of pages may differ by one or two depending on the TeX Live version and the font set, because line breaking differs between engines.

## What was verified here, and what was not

`verify/check_tex.py` (in `REPRODUCIBILITY/source_code/`) checks the following mechanically and reports 0 problems:

* brace and `$`-delimiter balance;
* environment nesting, including `\begin`/`\end` matching;
* every `\ref` has a `\label` and every `\label` is used;
* every `\cite` key exists in `References.bib` and every entry is cited;
* every tabular row has the column count declared in its `{...}` specification;
* no non-ASCII characters in math mode;
* float placement consistent with `[t]`/`[htbp]` usage.

It does **not** compile the document. No TeX engine was available in the environment where this package was assembled, so a LaTeX-only error (an incompatibility between package versions, for example) cannot be excluded. The PDF shipped in this package was produced from the same Markdown source by a second renderer, so the content matches; the typesetting does not.
