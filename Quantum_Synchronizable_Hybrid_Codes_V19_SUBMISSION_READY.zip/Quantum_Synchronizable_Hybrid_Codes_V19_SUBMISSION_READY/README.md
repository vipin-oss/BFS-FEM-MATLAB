# Synchronizable Hybrid Codes from Cyclic Codes over F_q[v]/(v³−v)

**V19 submission package.** This is the submission-ready version of the manuscript and its supporting material. It supersedes `Quantum_Synchronizable_Hybrid_Codes_V18_COMPLETE.zip`.

**Author.** Arun Kumar Yadav, School of Basic and Applied Sciences, K. R. Mangalam University, Gurugram 122103, India.

---

## Read this first

| File | What it is |
|---|---|
| `MANUSCRIPT/Main_Manuscript.pdf` | The manuscript, 23 pages |
| `SUBMISSION/Submission_Readiness_Report.md` | What was checked, what was not, and the verdict |
| `AUDIT/08_Issues_Register.md` | The 34 issues found; one remains open |
| `REPRODUCIBILITY/reproduction_commands.md` | Every command needed to reproduce every number |

The short version: the mathematics is verified, the numbers reproduce in about 25 seconds, and the bibliography is checked against Crossref. The one open item is that the LaTeX file has never been through a TeX compiler here, because none was available; the shipped PDF comes from the same single source rendered by Typst. `MANUSCRIPT/latex_dependencies/README.md` gives the ten-minute procedure to close that gap.

## Layout

```
MANUSCRIPT/
  Main_Manuscript.pdf     23 pp, the file to read
  Main_Manuscript.tex     LaTeX source (amsart), structurally validated, not compiled here
  Main.typ                Typst source, the renderer used for the PDF
  References.bib          27 entries, all verified against Crossref
  figures/                four figures as SVG and as PDF (the PDFs are what LaTeX includes)
  latex_dependencies/     class, packages, build order, known caveat on SVG
SUPPLEMENTARY/
  Detailed_Proofs.pdf     5 pp: full proofs of every statement
  Supplementary_Results.pdf  3 pp: the tables and parameters that did not fit
  Additional_Tables/      A1–A8, machine-generated CSV
REPRODUCIBILITY/
  source_code/            gf.py (F_q arithmetic), three audit suites, the build and figure tools
  tests/test_all.py       one command, about 25 seconds, writes run_output/
  generated_data/         the JSON reports that every table and figure reads
  source_manuscript/      the Markdown the .tex and .typ are generated from
  requirements.txt        Python 3.11, Typst 0.15, PyMuPDF 2.0, SymPy 1.14 (frozen V18 only)
  reproduction_commands.md
AUDIT/
  01_Project_Inventory.md            what V18 contained, what was wrong with it, what V19 contains
  02_Mathematical_Verification.md    28 results, each VERIFIED / PROOF ONLY / NOT A CLAIM
  03_Literature_and_Novelty_Report.md  27 references checked, novelty positioned, limits stated
  04_Computational_Verification.md   what each suite computes, timings, failure modes
  05_Round_1_Mathematical_Review.md  mathematical referee report and corrections
  06_Round_2_Computational_Review.md reproducibility referee report and corrections
  07_Round_3_Journal_Review.md       editorial report and corrections
  08_Issues_Register.md              34 issues, statuses, and the single open item
  09_V18_to_V19_Change_Log.md        structural, mathematical, textual, bibliographic changes
  10_Round_4_Pre_Submission_Review.md  line-by-line proofread of the rendered PDF; seven defects found and fixed
SUBMISSION/
  Submission_Readiness_Report.md  the 15-item acceptance gate, answered
  Research_Highlights.md          five proven claims, one per bullet
  Cover_Letter_Draft.md           ready to send once the journal and date are filled in
  Submission_Checklist.md         ticked, open, and author-action items
SHA256SUMS.txt                    every file except this checksum file
```

## Verify it yourself

```bash
cd REPRODUCIBILITY/tests
python3 test_all.py
```

Expected: `core 18/18`, `census`, `extra 8/8`, `latex 0 problems`, `overall: PASS`, about 25 seconds. A fresh run writes to `REPRODUCIBILITY/run_output/` and leaves the shipped `generated_data/` untouched, so the checksums still verify afterwards. Then:

```bash
cd ../source_code
python3 check_tex.py ../../MANUSCRIPT/Main_Manuscript.tex ../../MANUSCRIPT/References.bib /tmp/tex.json
```

Expected: `0 problem(s), 35 note(s)`. The notes are labels that are defined but never cross-referenced.

## The result in one paragraph

For a synchronizable code built from a cyclic branch $C^\perp\subseteq C\subsetneq D$ with quotient $f=g_C/g_D$, the offsets a receiver cannot distinguish are exactly the multiples of $e=\operatorname{ord}_x(f)$, so the window is $e-1$ cells and the standard sufficient condition is also necessary. For dual-containing codes $\deg f\le e-1$, so the degree bound $\deg f-1$ is never sharp. Three components over $\mathbb{F}_q[v]/(v^3-v)$ fuse to period $\operatorname{lcm}(e_1,e_2,e_3)\le n$, which a single component already attains, so fusion cannot enlarge the window; what it buys is a relaxation of the per-component period, quantified over 118 pairs. With message-carrying markers, one component can hold the frame while the others transmit, and the ternary example with underlying parameters $[[39,3:9,0,3]]_3$ carries four classical symbols at a twelve-cell window.

## What is not claimed

No optimality, no superiority in distance, no noisy-syndrome performance, no priority over the prior art. The model is idealised, the abstract says so, and §7 lists the exclusions. `AUDIT/03` §4 records what the search did and did not cover.

## Integrity

`SHA256SUMS.txt` lists the SHA-256 of every file in the package except itself. The V18 input archive had SHA-256 `35112ea9b30a37fcddd54ad1ab4c30692a6cd03aa097b1a06728f8d907e720a7`; its inventory and the eight defects that motivated the rewrite are in `AUDIT/01`.
