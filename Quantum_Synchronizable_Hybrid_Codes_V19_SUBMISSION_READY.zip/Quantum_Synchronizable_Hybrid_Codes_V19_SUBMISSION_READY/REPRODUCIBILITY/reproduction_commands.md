# Reproduction commands

Every command below was executed in the environment that produced this package. Paths are relative to the package root, `Quantum_Synchronizable_Hybrid_Codes_V19_SUBMISSION_READY/`.

---

## 1. Run the verification suites (about about 25 seconds)

```bash
cd REPRODUCIBILITY/tests
python3 test_all.py
```

Output: a line per suite and a final `overall: PASS`. The fresh reports go to `REPRODUCIBILITY/run_output/` (created on demand, `--out DIR` to change it); the reports shipped in `generated_data/` are not touched, so `SHA256SUMS.txt` stays valid after a verification run. No network, no arguments, no data files needed: the inputs are constructed in the script.

Expected:

```
core     audit_core.py      PASS   25.0s  18/18 core checks passed
census   audit_census.py    PASS    0.16s
extra    audit_extra.py     PASS    0.16s  8/8 extra checks passed
overall: PASS
```

The census suite prints nothing on success; its assertions are in the code and its output is `census_report.json`. If any assertion fails it raises and `test_all.py` records `FAIL`.

---

## 2. Run one suite on its own

```bash
cd REPRODUCIBILITY/source_code
python3 audit_core.py       # writes core_report.json next to the script
python3 audit_census.py     # writes census_report.json
python3 audit_extra.py      # reads census_report.json, writes extra_report.json
```

Run `audit_census.py` before `audit_extra.py`: the second reads the first's output.

---

## 3. Check the generated LaTeX

```bash
cd REPRODUCIBILITY/source_code
python3 check_tex.py ../../MANUSCRIPT/Main_Manuscript.tex ../../MANUSCRIPT/References.bib /tmp/tex_report.json
```

Expected: `0 problem(s), 35 note(s)`. The notes are labels that are defined but never cross-referenced, which is normal.

---

## 4. Regenerate the manuscript (`.tex` and `.typ`) from the Markdown source

```bash
cd REPRODUCIBILITY/source_manuscript
cat sec1-2.md sec3-4.md sec5-6.md sec7-8.md > paper.md
python3 ../source_code/build.py paper.md --typ Main.typ --tex Main_Manuscript.tex
```

Then copy `Main.typ` and `Main_Manuscript.tex` into `MANUSCRIPT/`, and copy `References.bib` and `figures/` alongside them.

The build script resolves `{ref:key}` labels, numbers theorems and floats, emits table notes as separate paragraphs, and writes both a LaTeX file (for submission) and a Typst file (for rendering here).

## 5. Regenerate the supplements

```bash
cd REPRODUCIBILITY/source_manuscript
python3 ../source_code/build.py supp_proofs.md  --typ ../supplement/Detailed_Proofs.typ      --tex ../supplement/Detailed_Proofs.tex
python3 ../source_code/build.py supp_results.md --typ ../supplement/Supplementary_Results.typ --tex ../supplement/Supplementary_Results.tex
```

## 6. Render the PDFs (needs Typst 0.15)

```bash
python3 -c "import typst; typst.compile('MANUSCRIPT/Main.typ', output='MANUSCRIPT/Main_Manuscript.pdf', root='MANUSCRIPT')"
python3 -c "import typst; typst.compile('SUPPLEMENTARY/Detailed_Proofs.typ', output='SUPPLEMENTARY/Detailed_Proofs.pdf', root='SUPPLEMENTARY')"
python3 -c "import typst; typst.compile('SUPPLEMENTARY/Supplementary_Results.typ', output='SUPPLEMENTARY/Supplementary_Results.pdf', root='SUPPLEMENTARY')"
```

## 7. Regenerate the figures and the data tables

```bash
cd REPRODUCIBILITY/source_code
python3 make_figures.py --data ../generated_data --out ../../MANUSCRIPT/figures
```

The eight CSVs in `SUPPLEMENTARY/Additional_Tables/` were written from the same JSON reports by short scripts; the column definitions are documented in `SUPPLEMENTARY/Supplementary_Results.pdf` §1 and in each file's header row.

## 8. Re-run the bibliography check (needs outbound network)

```bash
cd REPRODUCIBILITY/source_code
python3 verify_refs.py
```

This issues one Crossref query per DOI and writes `crossref_report.json`. **It will fail in a sandbox without outbound HTTPS.** In the environment where this package was assembled, Crossref was reachable through an interactive fetch tool but not from Python; the stored report is the record of those queries.

---

## Environment used for the recorded run

| Item | Version |
|---|---|
| Python | 3.11.2 |
| Typst | 0.15.0 |
| PyMuPDF | 2.0 |
| SymPy | 1.14.0 (frozen V18 scripts only) |
| OS | Linux, x86-64, single core |
| Network | none from Python; Crossref reached through a page-fetch tool |

## Determinism

The only randomness is the Cantor–Zassenhaus splitting inside the factorisation of $x^n-1$, seeded at 20261021. Re-running any suite reproduces the JSON apart from timestamps and wall-clock times. The PDF is reproducible up to the Typst version: a different Typst version may break lines differently.
