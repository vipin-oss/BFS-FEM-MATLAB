"""V19 audit, part 2: exhaustive censuses, relaxation families, proper-D search.

Independent re-implementation: irreducibles of x^n-1 are computed with the
audit's own Cantor-Zassenhaus code (gf.py), and branch counts are obtained by
enumerating admissible principal factor sets S and all sub-sets T of S, with
the count of T obtained both combinatorially and (for small cases) explicitly.
"""
from __future__ import annotations
import json, sys, itertools
from math import comb, gcd
sys.path.insert(0, __file__.rsplit('/', 1)[0])
import gf
import os

OUT = {}


def factor_data(q, n):
    """[(factor, degree, order, self_reciprocal, reciprocal_index)] for x^n-1."""
    facs = [f for f, _ in gf.factor_xn_minus_1(n, q)]
    idx = {f: i for i, f in enumerate(facs)}
    data = []
    for f in facs:
        r = gf.monic(gf.reciprocal(f, q), q)
        data.append(dict(f=f, deg=gf.deg(f), e=gf.ord_x(f, q, n),
                         selfrec=(r == f), recip=idx.get(r)))
    return data


def census_pair(q, n):
    """Count branches and collect the achievable orders (both D allowed and D proper)."""
    data = factor_data(q, n)
    # reciprocal pairs among non-self-reciprocal factors
    pairs, used = [], set()
    for i, d in enumerate(data):
        if d["selfrec"] or i in used:
            continue
        j = d["recip"]
        if j is None:
            raise RuntimeError("reciprocal factor missing")
        used.add(i); used.add(j)
        pairs.append((i, j))
    m = len(pairs)
    res = dict(q=q, n=n, n_factors=len(data), m_pairs=m,
               branches=0, e_gt_deg=0, e_eq_deg=0, e_lt_deg=0,
               max_e=0, E=set(), E_proper=set(),
               proper_branches=0)
    # state per pair: 0 = neither, 1 = first, 2 = second
    for state in itertools.product(range(3), repeat=m):
        S = [pairs[k][s - 1] for k, s in enumerate(state) if s]
        if not S:
            continue
        degS = sum(data[i]["deg"] for i in S)
        # every nonempty U subset of S gives a branch (T = S \ U)
        for r in range(1, len(S) + 1):
            for U in itertools.combinations(S, r):
                degf = sum(data[i]["deg"] for i in U)
                e = gf.lcmm(*[data[i]["e"] for i in U])
                res["branches"] += 1
                res["max_e"] = max(res["max_e"], e)
                res["E"].add(e)
                if e > degf:
                    res["e_gt_deg"] += 1
                elif e == degf:
                    res["e_eq_deg"] += 1
                else:
                    res["e_lt_deg"] += 1
                if len(U) < len(S):          # T nonempty  <=>  D proper
                    res["proper_branches"] += 1
                    res["E_proper"].add(e)
    res["E"] = sorted(res["E"]); res["E_proper"] = sorted(res["E_proper"])
    return res


def main():
    # ---------------------------------------------------------- census
    rows, tot = [], dict(pairs=0, with_branch=0, branches=0, e_gt=0)
    per_q = {}
    for q in [3, 5, 7, 11, 13]:
        acc = dict(pairs=0, with_branch=0, branches=0, e_gt=0)
        for n in range(2, 21):
            if gcd(n, q) != 1:
                continue
            r = census_pair(q, n)
            acc["pairs"] += 1
            acc["with_branch"] += 1 if r["branches"] else 0
            acc["branches"] += r["branches"]
            acc["e_gt"] += r["e_gt_deg"]
            # theorem checks on every pair
            minus_one_in = ((n - 1) % n) in _group(q, n)
            assert (r["branches"] > 0) == (not minus_one_in), (q, n)
            if r["branches"]:
                assert r["max_e"] == n, (q, n, r["max_e"])
                assert r["e_gt_deg"] == r["branches"], (q, n)   # deg f <= e-1
            rows.append(dict(q=q, n=n, branches=r["branches"], m_pairs=r["m_pairs"],
                             max_e=r["max_e"], E=r["E"], E_proper=r["E_proper"],
                             proper_branches=r["proper_branches"]))
        per_q[q] = acc
        tot["pairs"] += acc["pairs"]; tot["with_branch"] += acc["with_branch"]
        tot["branches"] += acc["branches"]; tot["e_gt"] += acc["e_gt"]
        print("q=%2d pairs %2d with-branch %2d branches %6d  (e>deg f: %6d)"
              % (q, acc["pairs"], acc["with_branch"], acc["branches"], acc["e_gt"]), flush=True)
    print("TOTAL", tot, flush=True)
    assert tot["pairs"] == 81 and tot["with_branch"] == 39 and tot["branches"] == 20724
    assert tot["e_gt"] == 20724
    OUT["census"] = dict(per_q=per_q, total=tot, rows=rows)

    # combinatorial cross-check of the closed form 5^m - 3^m
    for r in rows:
        assert r["branches"] == 5 ** r["m_pairs"] - 3 ** r["m_pairs"], r
        assert r["proper_branches"] == sum(
            comb(r["m_pairs"], j) * 2 ** j * (2 ** j - 2) for j in range(1, r["m_pairs"] + 1))
    print("closed forms 5^m-3^m and sum_j C(m,j)2^j(2^j-2) verified on all 81 pairs", flush=True)

    # ------------------------------------------------- proper-D (27 pairs)
    admissible = [r for r in rows if r["proper_branches"] > 0]
    print("proper-D admissible pairs:", len(admissible), flush=True)
    assert len(admissible) == 27
    ok_lcm = all(max(r["E_proper"]) == r["n"] for r in admissible)
    print("max proper-D order equals n in all 27 pairs:", ok_lcm, flush=True)
    assert ok_lcm
    OUT["proper_D"] = [dict(q=r["q"], n=r["n"], E=r["E_proper"], max_e=max(r["E_proper"]),
                            proper_branches=r["proper_branches"]) for r in admissible]
    # cross-check the witness triples claimed in Table dconstr: lcm of three admissible
    # orders can reach n for every admissible pair (trivially, since n itself is attainable)
    tri_ok = True
    for r in admissible:
        E = r["E_proper"]
        best = max(gf.lcmm(*t) for t in itertools.combinations_with_replacement(E, 3))
        if best != r["n"]:
            tri_ok = False
    print("max lcm over triples equals n in all 27 pairs:", tri_ok, flush=True)
    assert tri_ok

    # ------------------------------------------------------- relaxation
    def isprime(m):
        if m < 2: return False
        d = 2
        while d * d <= m:
            if m % d == 0: return False
            d += 1
        return True

    fams = []
    for q in range(3, 102, 2):
        if not isprime(q):
            continue
        for n in gf.divisors(q - 1):
            if n < 3:
                continue
            cand = [t for t in itertools.combinations_with_replacement(
                        [d for d in gf.divisors(n) if d >= 3], 3) if gf.lcmm(*t) == n]
            if not cand:
                continue
            best = min(cand, key=lambda t: (max(t), t))
            fams.append(dict(q=q, n=n, orders=list(best), e_R=gf.lcmm(*best),
                             factor=n / max(best)))
    import collections
    print("factor histogram:", dict(sorted(collections.Counter(int(f["factor"]) for f in fams).items())),
          flush=True)
    print("relaxation (q,n) pairs:", len(fams),
          " with factor > 1:", sum(1 for f in fams if f["factor"] > 1), flush=True)
    assert len(fams) == 118
    assert sum(1 for f in fams if f["factor"] > 1) == 38
    top = max(fams, key=lambda f: f["factor"])
    print("max factor:", top, flush=True)
    # the three element orders must be realisable in F_q^*: each divides n | q-1
    assert all(all(f["n"] % m == 0 and (f["q"]-1) % m == 0 for m in f["orders"]) for f in fams)
    OUT["relaxation"] = dict(n_pairs=len(fams),
                             n_factor_gt1=sum(1 for f in fams if f["factor"] > 1),
                             max_factor=top,
                             table=[f for f in sorted(fams, key=lambda f: (-f["factor"], f["q"]))
                                    if f["factor"] >= 6],
                             all=[f for f in sorted(fams, key=lambda f: (-f["factor"], f["q"]))])
    # claims of unboundedness quoted in Remark relax
    for q, n, orders, factor in [(211, 210, (5, 6, 7), 30), (281, 280, (5, 7, 8), 35)]:
        assert isprime(q) and gf.lcmm(*orders) == n and n / max(orders) == factor
    print("unboundedness witnesses (211,210,(5,6,7)) and (281,280,(5,7,8)) verified", flush=True)

    json.dump(OUT, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'census_report.json'), 'w'), indent=1, default=str)
    print("written census_report.json")


def _group(q, d):
    s, x = set(), 1
    while True:
        x = (x * q) % d
        if x in s:
            return s
        s.add(x)


if __name__ == "__main__":
    main()
