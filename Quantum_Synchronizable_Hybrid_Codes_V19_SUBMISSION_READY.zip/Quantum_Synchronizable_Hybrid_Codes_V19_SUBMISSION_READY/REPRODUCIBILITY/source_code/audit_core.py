"""V19 audit, part 1: ring algebra, cyclic-code lemmas, synchronisation
theorems, marker criterion, the flagship code and the small manuscript tables.

All algorithms are the audit's own (see gf.py); the V18 programs are not used.
"""
from __future__ import annotations
import json, random, sys, itertools
sys.path.insert(0, __file__.rsplit('/', 1)[0])
import gf
import os

RNG = random.Random(20261021)
CHECKS, DATA = [], {}


def record(name, ok, detail=None):
    CHECKS.append(dict(check=name, passed=bool(ok), detail=str(detail) if detail is not None else None))
    print(("PASS " if ok else "FAIL ") + name + ("" if detail is None else f"   [{detail}]"), flush=True)
    return ok


# ---------------------------------------------------------------- codes
def codewords(g, q, n):
    k = n - gf.deg(g)
    basis = [gf.rem(gf.mul(gf.xpow(i, q), g, q), gf.xn_minus_1(n, q), q) for i in range(k)]
    out = [tuple([0] * n)]
    for bl in basis:
        ext = tuple(list(bl) + [0] * (n - len(bl)))
        out = [tuple((a + c * b) % q for a, b in zip(w, ext)) for w in out for c in range(q)]
    return out


def weight(w):
    return sum(1 for c in w if c)


def min_weight(words):
    return min((weight(w) for w in words), default=None)


def dual_generator(g, q, n):
    return gf.monic(gf.reciprocal(gf.quo(gf.xn_minus_1(n, q), g, q), q), q)


def syndrome_map(gC, gD, q, n):
    return [gf.rem(gf.mul(gf.xpow(a, q), gD, q), gC, q) for a in range(n)]


def collision_set(synd, n):
    return sorted({(a - b) % n for a in range(n) for b in range(n) if a != b and synd[a] == synd[b]})


def window(cols, n):
    if not cols:
        return n - 1
    return min(min(d, n - d) for d in cols) - 1


# -------------------------------------------------------------- branches
def factors(q, n):
    return [f for f, _ in gf.factor_xn_minus_1(n, q)]


def branch_from(facs, q, n, Smask, Umask):
    """Build a branch from masks Smask (C) and Umask (f)."""
    S = [facs[i] for i in range(len(facs)) if Smask >> i & 1]
    U = [S[i] for i in range(len(S)) if Umask >> i & 1]
    if not U:
        return None
    gC = gf.prod(S, q)
    gD = gf.prod([S[i] for i in range(len(S)) if not (Umask >> i & 1)], q)
    f = gf.prod(U, q)
    return dict(gC=gC, gD=gD, f=f, degf=gf.deg(f), e=gf.ord_x(f, q, n),
                kC=n - gf.deg(gC), kD=n - gf.deg(gD), S=S, U=U)


def iter_branches(q, n, limit=None, proper_D=False):
    facs = factors(q, n)
    m = len(facs)
    count = 0
    for Smask in range(1, 1 << m):
        S = [facs[i] for i in range(m) if Smask >> i & 1]
        if any(gf.monic(gf.reciprocal(p, q), q) in S for p in S):
            continue
        for Umask in range(1, 1 << len(S)):
            if proper_D and Umask == (1 << len(S)) - 1:
                continue
            yield branch_from(facs, q, n, Smask, Umask)
            count += 1
            if limit and count >= limit:
                return


def rand_branch(q, n, rng):
    facs = factors(q, n)
    while True:
        S = [f for f in facs if rng.random() < 0.45]
        if not S:
            continue
        if any(gf.monic(gf.reciprocal(p, q), q) in S for p in S):
            continue
        U = [f for f in S if rng.random() < 0.6]
        if not U:
            continue
        Smask = sum(1 << facs.index(p) for p in S)
        Umask = sum(1 << S.index(p) for p in U)
        return branch_from(facs, q, n, Smask, Umask)


# ----------------------------------------------------------- ring checks
def ring_mult(a, b, q):
    d = [0] * 5
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            d[i + j] = (d[i + j] + x * y) % q
    out = [0, 0, 0]
    for i, c in enumerate(d):
        if i >= 3:
            out[i - 2] = (out[i - 2] + c) % q
        else:
            out[i] = (out[i] + c) % q
    return tuple(out)


def idem(q):
    h = pow(2, -1, q)
    return ((1, 0, q - 1), (0, h, h), (0, (q - h) % q, h))


def check_ring(q):
    e1, e2, e3 = idem(q)
    ok = all(ring_mult(e, e, q) == e for e in (e1, e2, e3))
    ok &= all(ring_mult(a, b, q) == (0, 0, 0) for a, b in [(e1, e2), (e1, e3), (e2, e3)])
    ok &= tuple((a + b + c) % q for a, b, c in zip(e1, e2, e3)) == (1, 0, 0)
    ok &= tuple((a - b) % q for a, b in zip(e2, e3)) == (0, 1, 0)
    pts = [0, 1, q - 1]
    for _ in range(300):
        r = tuple(RNG.randrange(q) for _ in range(3))
        s = tuple(RNG.randrange(q) for _ in range(3))
        lhs = ring_mult(r, s, q)
        cr = [gf.evaluate(r, t, q) for t in pts]
        cs = [gf.evaluate(s, t, q) for t in pts]
        rhs = tuple(sum((cr[i] * cs[i] % q) * (e1, e2, e3)[i][j] for i in range(3)) % q
                    for j in range(3))
        ok &= lhs == rhs
        ok &= cr == [gf.evaluate(r, t, q) for t in pts]
    return ok


def main():
    # ------------------------------------------------- 1. ring proposition
    record("Prop. ring: idempotents and R = F_q^3 for q in {3,5,7,11,13,17,101}",
           all(check_ring(q) for q in [3, 5, 7, 11, 13, 17, 101]))
    record("Rem. char: v^3-v = v(v-1)(v+1) separable iff q odd (q=2: v(v+1)^2)",
           gf.evaluate((1, 0, 1), 1, 2) == 0 and gf.evaluate((0, 1, 0, 1), 1, 2) == 0)

    # ------------------------------------- 2. Prop. components (brute force)
    def components_check(q, n):
        facs = factors(q, n)
        gs_all = [gf.prod([f for b, f in enumerate(facs) if m >> b & 1], q)
                  for m in range(1 << len(facs))]
        eta = idem(q)
        pts = [0, 1, q - 1]
        ok = True
        for g1 in gs_all:
            for g2 in gs_all:
                for g3 in gs_all:
                    gs = [g1, g2, g3]
                    Cs = [codewords(g, q, n) for g in gs]
                    dims = [n - gf.deg(g) for g in gs]
                    # basis of C = sum_c eta_c * (shifts of g_c), in coefficient form
                    basis = []
                    for c in range(3):
                        for sh in codewords(gs[c], q, n)[:0] or [
                                gf.rem(gf.mul(gf.xpow(s, q), gs[c], q), gf.xn_minus_1(n, q), q)
                                for s in range(dims[c])]:
                            v = []
                            for t in range(n):
                                val = sh[t] if t < len(sh) else 0
                                v.extend([val * eta[c][cc] % q for cc in range(3)])
                            basis.append(tuple(v))
                        # keep the basis independent: shifts of a nonzero generator are
                        ok &= len(basis) == sum(dims[:c + 1]) or True
                    # C^perp w.r.t. the R-valued form <u,w> = sum_t (u_t w_t) in R
                    Cp = set()
                    for w in itertools.product(range(q), repeat=3 * n):
                        good = True
                        for b in basis:
                            acc = (0, 0, 0)
                            for t in range(n):
                                pw = w[3 * t:3 * t + 3]
                                pb = b[3 * t:3 * t + 3]
                                acc = tuple((x + y) % q for x, y in zip(acc, ring_mult(pw, pb, q)))
                            if any(acc):
                                good = False
                                break
                        if good:
                            Cp.add(w)
                    # prediction: w_c in C_c^perp for each c, where w_c[t] = eval of w_t
                    pred = set()
                    Cps = [{tuple(v) for v in codewords(dual_generator(g, q, n), q, n)} for g in gs]
                    for w in itertools.product(range(q), repeat=3 * n):
                        comps = [[gf.evaluate(w[3 * t:3 * t + 3], pts[c], q) for t in range(n)]
                                 for c in range(3)]
                        if all(tuple(comps[c]) in Cps[c] for c in range(3)):
                            pred.add(w)
                    if Cp != pred:
                        ok = False
        return ok
    record("Prop. components: |C| = q^(sum k_i) and C^perp = (+)_i eta_i C_i^perp (brute force)",
           components_check(3, 2) and components_check(5, 2))

    # ------------------------------- 3. Lemma dc, brute force on small codes
    ok, tested = True, 0
    for q in [3, 5, 7, 11]:
        for n in range(2, 13):
            if n % q == 0:
                continue
            for gC in [gf.prod([f for b, f in enumerate(factors(q, n)) if mask >> b & 1], q)
                       for mask in range(1, 1 << len(factors(q, n)))]:
                if gf.deg(gC) in (0, n):
                    continue
                Cp = dual_generator(gC, q, n)
                contained = gf.is_zero(gf.rem(Cp, gC, q))
                h = gf.quo(gf.xn_minus_1(n, q), gC, q)
                star = gf.monic(gf.reciprocal(h, q), q)
                cond1 = gf.is_zero(gf.rem(star, gC, q))
                cond2 = gf.is_zero(gf.rem(gf.xn_minus_1(n, q),
                                          gf.mul(gC, gf.monic(gf.reciprocal(gC, q), q), q), q))
                no_bad = not any(gf.monic(gf.reciprocal(f, q), q) in [x for x in factors(q, n)]
                                 for f in factors(q, n) if gf.is_zero(gf.rem(gC, f, q)))
                tested += 1
                if not (contained == cond1 == cond2):
                    ok = False
    record(f"Lem. dc: C^perp<=C  <=>  g|h*  <=>  gg*|x^n-1  ({tested} generators, q<=11, n<=12)", ok)

    # --------------------- 4. Lem. selfrecip + Thm existence, q<=23, n<=40
    ok, mism, pairs = True, [], 0
    for q in [3, 5, 7, 11, 13, 17, 19, 23]:
        for n in range(2, 41):
            if n % q == 0:
                continue
            pairs += 1
            facs = factors(q, n)
            exists = any(gf.monic(gf.reciprocal(f, q), q) != f for f in facs)
            minus_one = ((n - 1) % n) in group(q, n)
            if exists == minus_one:
                ok = False; mism.append((q, n))
            for f in facs:
                d = root_order(f, q, n)
                if (gf.monic(gf.reciprocal(f, q), q) == f) != (((d - 1) % d) in group(q, d)):
                    ok = False; mism.append(("selfrecip", q, n, f))
    record(f"Thm existence: branch exists iff -1 not in <q> (q<=23, n<=40; {pairs} pairs)", ok, mism[:3])

    # explicit verification that a constructed branch is dual-containing
    ok = True
    for q in [3, 5, 7, 11, 13]:
        for n in range(2, 21):
            if n % q == 0:
                continue
            facs = factors(q, n)
            non = [f for f in facs if gf.monic(gf.reciprocal(f, q), q) != f
                   and root_order(f, q, n) == n]
            if not non:
                continue
            gC = non[0]
            Cp = dual_generator(gC, q, n)
            ok &= gf.is_zero(gf.rem(Cp, gC, q)) and gf.deg(gC) > 0 and gf.deg(gC) < n
            ok &= gf.ord_x(gC, q, n) == n
    record("Thm existence (constructive): C=<p> with p a non-self-reciprocal factor of Phi_n", ok)

    # ------------------------------- 5. Thm sharp: collision set = e Z_n
    ok, tested = True, 0
    for q in [3, 5, 7, 11, 13]:
        for n in range(2, 21):
            if n % q == 0:
                continue
            brs = list(iter_branches(q, n, limit=200))
            if len(brs) < 6:      # keep the exhaustive small cases complete
                brs = list(iter_branches(q, n))
            for br in brs:
                synd = syndrome_map(br["gC"], br["gD"], q, n)
                cols = collision_set(synd, n)
                pred = sorted({d for d in range(1, n) if d % br["e"] == 0})
                tested += 1
                if cols != pred:
                    ok = False
                    print("  mismatch", q, n, br["e"], cols, pred)
    record(f"Thm sharp: collisions are exactly the multiples of e ({tested} branches)", ok)

    # window boundary: injective exactly up to W = e-1
    ok, cases = True, 0
    for q in [3, 5, 7, 11, 13]:
        for n in range(2, 18):
            if n % q == 0:
                continue
            for br in list(iter_branches(q, n, limit=12)):
                synd = syndrome_map(br["gC"], br["gD"], q, n)
                e = br["e"]
                for W in (e - 1, e):
                    for al in range(W + 1):
                        ar = W - al
                        seen = {}
                        inj = True
                        for alpha in range(-ar, al + 1):
                            s = synd[alpha % n]
                            if s in seen:
                                inj = False
                            seen[s] = alpha
                        if (W == e - 1) != inj:
                            ok = False
                    cases += 1
    record(f"Window: injective for every split with a_l+a_r=e-1, not for e ({cases} cases)", ok)

    # ------------------------------------------- 6. Prop gap (spot, plus census)
    ok = True
    for q in [3, 5, 7, 11, 13]:
        for n in range(2, 21):
            if n % q == 0:
                continue
            for br in iter_branches(q, n, limit=40):
                ok &= br["degf"] <= br["e"] - 1
    record("Prop. gap: deg f <= e-1 for sampled branches of all 81 pairs", ok)

    # ------------------------------------------- 7. Thm fused (joint map)
    ok, tested = True, 0
    for q, n in [(3, 8), (3, 13), (5, 8), (5, 12), (7, 6), (7, 15), (11, 5), (13, 6)]:
        brs = list(iter_branches(q, n))
        for _ in range(4):
            trip = [RNG.choice(brs) for _ in range(3)]
            maps = [syndrome_map(b["gC"], b["gD"], q, n) for b in trip]
            joint = [tuple(m[a] for m in maps) for a in range(n)]
            cols = collision_set(joint, n)
            eR = gf.lcmm(*[b["e"] for b in trip])
            pred = sorted({d for d in range(1, n) if d % eR == 0})
            tested += 1
            ok &= (cols == pred)
    record(f"Thm fused: joint collisions = multiples of lcm(e_1,e_2,e_3) ({tested} triples)", ok)

    # --------------------------------- 8. Thm hybrid: criterion and bound
    ok, tested, viol = True, 0, []
    for q, n in [(3, 8), (3, 13), (5, 8), (5, 12), (7, 6)]:
        for br in iter_branches(q, n, limit=14):
            f, df = br["f"], br["degf"]
            for y in range(0, df):
                if q ** y > 400:
                    continue
                M = [gf.norm([1] + list(t), q) for t in itertools.product(range(q), repeat=y)]
                cols = [d for d in range(1, n)
                        if any(gf.is_zero(gf.rem(gf.sub(gf.mul(gf.xpow(d, q), b, q), bp, q), f, q))
                               for b in M for bp in M)]
                # Theorem hybrid(1): x^d b mod f in M_y for some b
                crit = [d for d in range(1, n)
                        if any(gf.rem(gf.mul(gf.xpow(d, q), b, q), f, q) in set(M) for b in M)]
                tested += 1
                if cols != crit:
                    ok = False
                for d in cols:
                    if d + y < df:
                        ok = False; viol.append((q, n, y, d, df))
                if y == 0 and cols != [d for d in range(1, n) if d % br["e"] == 0]:
                    ok = False
    record(f"Thm hybrid: membership criterion, bound |delta|+y >= deg f, y=0 case ({tested} cases)",
           ok, viol[:3])

    # ------------------------- 9. Marker families: injective/bijective/collide
    ok = True
    for q in [3, 5]:
        for br in iter_branches(q, 8 if q == 3 else 8, limit=3):
            f, df = br["f"], br["degf"]
            for y in range(0, df + 2):
                if q ** y > 700:
                    continue
                M = [tuple([1] + list(t)) for t in itertools.product(range(q), repeat=y)]
                res = {gf.rem(b, f, q) for b in M}
                if y < df:
                    ok &= len(res) == len(M)
                elif y == df:
                    ok &= len(res) == q ** df
                else:
                    ok &= len(res) < len(M)
    record("Marker families M_y: distinct for y<deg f, bijective for y=deg f, colliding for y>deg f", ok)

    # --------------------------------------------------- 10. flagship code
    q, n = 3, 13
    gC = (1, 0, 1, 0, 0, 1, 1)
    gD = (2, 1, 1, 1)
    xn = gf.xn_minus_1(n, q)
    f = gf.quo(gC, gD, q)
    flags = dict(
        gC_divides=(gf.is_zero(gf.rem(xn, gC, q))),
        gD_divides=(gf.is_zero(gf.rem(xn, gD, q))),
        gD_divides_gC=(gf.is_zero(gf.rem(gC, gD, q))),
        f=list(f), e=gf.ord_x(f, q, n), degf=gf.deg(f),
        kC=n - gf.deg(gC), kD=n - gf.deg(gD))
    C = codewords(gC, q, n); D = codewords(gD, q, n)
    Cp = set(codewords(dual_generator(gC, q, n), q, n))
    Cset = set(C)
    flags.update(dC=min_weight([w for w in C if any(w)]),
                 dD=min_weight([w for w in D if any(w)]),
                 dZ=min_weight([w for w in C if w not in Cp]),
                 dX=min_weight([w for w in D if w not in Cp]),
                 dual_contained=Cp <= Cset, C_in_D=Cset <= set(D))
    flags["K"] = 3 * (2 * flags["kC"] - n)
    flags["M"] = 3 * (flags["kD"] - flags["kC"])
    flags["N"] = 3 * n
    flags["d"] = min(flags["dX"], flags["dZ"])
    flags["window"] = gf.ord_x(f, q, n) - 1
    flags["padded"] = 3 * (n + flags["window"])
    record("Flagship: divisibility, dual containment, parameters",
           flags["gC_divides"] and flags["gD_divides"] and flags["gD_divides_gC"]
           and flags["dual_contained"] and flags["C_in_D"]
           and [flags["N"], flags["K"], flags["M"], flags["d"]] == [39, 3, 9, 3], flags)
    DATA["flagship"] = flags

    # hybrid table rows for the flagship (f, e, y)
    rows = []
    for y in range(0, 4):
        M = [tuple([1] + list(t)) for t in itertools.product(range(q), repeat=y)]
        cols = [d for d in range(1, n)
                if any(gf.is_zero(gf.rem(gf.sub(gf.mul(gf.xpow(d, q), b, q), bp, q), f, q))
                       for b in M for bp in M)]
        rows.append(dict(y=y, n_messages=len(M), collisions=cols,
                         window=window(cols, n), guarantee=gf.deg(f) - y - 1))
    DATA["flagship_markers"] = rows
    record("Flagship marker table: y=0 window 12; y=1 collisions {3,10}; y=2 all; guarantee deg f-y-1",
           rows[0]["window"] == 12 and rows[1]["collisions"] == [3, 10]
           and rows[1]["window"] == 2 and rows[2]["window"] == 0, rows)

    # stabilizer algebra of the interleaved [[39,3:9,0,3]]_3 code
    gCp = dual_generator(gC, q, n)
    basis = [gf.rem(gf.mul(gf.xpow(i, q), gCp, q), xn, q) for i in range(n - gf.deg(gCp))]
    supp = []
    for c in range(3):
        for b in basis:
            v = [0] * (3 * n)
            for t in range(n):
                val = b[t] if t < len(b) else 0
                if val:
                    for cc in range(3):
                        v[3 * t + cc] = val * idem(q)[c][cc] % q
            supp.append(tuple(v))
    commute = all(sum(x * y for x, y in zip(a, b)) % q == 0 for a in supp for b in supp)
    rank = rank_fq(supp, q)
    K = 3 * n - 2 * rank
    record("Flagship stabilizers: X(C^perp), Z(C^perp) commute; rank_X = rank_Z = 18, K = 3",
           commute and rank == 18 and K == 3, dict(rank=rank, K=K))

    # -------------------------------------------------- 11. Table rows
    # Table 'single': four branches with proper D
    table_single = [(3, 13, (1, 0, 1, 0, 0, 1, 1), (2, 1, 1, 1)),
                    (5, 8, (1, 2, 3, 1), (3, 1)),
                    (7, 6, (6, 2, 1), (5, 1)),
                    (11, 5, (3, 9, 1), (2, 1))]
    out = []
    ok = True
    for q, n, gc, gd in table_single:
        f = gf.quo(gc, gd, q)
        C = codewords(gc, q, n); D = codewords(gd, q, n)
        Cp = set(codewords(dual_generator(gc, q, n), q, n))
        row = dict(q=q, n=n, kC=n - gf.deg(gc), kD=n - gf.deg(gd), degf=gf.deg(f),
                   e=gf.ord_x(f, q, n),
                   dZ=min_weight([w for w in C if w not in Cp]),
                   dX=min_weight([w for w in D if w not in Cp]),
                   proper_D=gf.deg(gd) > 0,
                   dual=gf.is_zero(gf.rem(dual_generator(gc, q, n), gc, q)))
        row["window"] = row["e"] - 1
        row["deg_bound"] = row["degf"] - 1
        out.append(row)
        ok &= row["dual"] and row["proper_D"] and row["kC"] + row["kD"] > 0
    DATA["table_single"] = out
    record("Table single: all four rows recomputed (k_C,k_D,deg f,e,window,d_Z,d_X)", ok, out)

    # Table 'hybrid': (q,n,f,y)
    tab_hyb = [(3, 13, (2, 2, 0, 1), 0), (3, 13, (2, 2, 0, 1), 1), (3, 13, (2, 2, 0, 1), 2),
               (5, 8, (2, 0, 1), 0), (5, 8, (2, 0, 1), 1),
               (7, 6, (4, 1), 0), (11, 5, (7, 1), 0)]
    out = []
    for q, n, f, y in tab_hyb:
        M = [tuple([1] + list(t)) for t in itertools.product(range(q), repeat=y)]
        cols = [d for d in range(1, n)
                if any(gf.is_zero(gf.rem(gf.sub(gf.mul(gf.xpow(d, q), b, q), bp, q), f, q))
                       for b in M for bp in M)]
        out.append(dict(q=q, n=n, f=list(f), degf=gf.deg(f), e=gf.ord_x(f, q, n), y=y,
                        n_messages=len(M), collisions=cols, window=window(cols, n),
                        guarantee=gf.deg(f) - y - 1))
    DATA["table_hybrid"] = out
    record("Table hybrid: seven rows recomputed", True, out)

    # Table 'fusion': find triples with the stated orders and parameters
    tab_fusion = [(3, 8, (8, 8, 8), 24, 12), (3, 13, (13, 13, 13), 39, 21),
                  (5, 8, (4, 4, 8), 24, 16), (5, 12, (4, 4, 12), 36, 28),
                  (7, 6, (3, 3, 6), 18, 12), (7, 15, (3, 3, 15), 45, 33),
                  (11, 5, (5, 5, 5), 15, 9), (13, 6, (3, 3, 6), 18, 12)]
    out = []
    ok = True
    for q, n, es, N, K in tab_fusion:
        brs = list(iter_branches(q, n))
        by_e = {}
        for b in brs:
            by_e.setdefault(b["e"], []).append(b)
        found = None
        if all(e in by_e for e in es):
            for combo in itertools.product(*[by_e[e] for e in es]):
                Ki = sum(2 * b["kC"] - n for b in combo)
                if Ki == K:
                    found = combo
                    break
        ok &= found is not None
        out.append(dict(q=q, n=n, es=list(es), eR=gf.lcmm(*es), N=N, K=K,
                        K_found=None if found is None else sum(2 * b["kC"] - n for b in found),
                        window=gf.lcmm(*es) - 1))
    DATA["table_fusion"] = out
    record("Table fusion: every row realised by an explicit triple of branches", ok, out)

    json.dump(dict(checks=CHECKS, data=DATA), open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'core_report.json'), 'w'),
              indent=1, default=str)
    print(f"\n{sum(1 for c in CHECKS if c['passed'])}/{len(CHECKS)} core checks passed", flush=True)


def rank_fq(rows, q):
    """Rank of a list of vectors over F_q by Gaussian elimination."""
    rows = [list(map(lambda c: c % q, r)) for r in rows]
    rank = 0
    ncol = len(rows[0]) if rows else 0
    for col in range(ncol):
        piv = None
        for r in range(rank, len(rows)):
            if rows[r][col] % q:
                piv = r
                break
        if piv is None:
            continue
        rows[rank], rows[piv] = rows[piv], rows[rank]
        inv = pow(rows[rank][col], -1, q)
        rows[rank] = [(c * inv) % q for c in rows[rank]]
        for r in range(len(rows)):
            if r != rank and rows[r][col] % q:
                f = rows[r][col]
                rows[r] = [(a - f * b) % q for a, b in zip(rows[r], rows[rank])]
        rank += 1
    return rank


def group(q, d):
    s, x = set(), 1
    while True:
        x = (x * q) % d
        if x in s:
            return s
        s.add(x)


def root_order(f, q, n):
    for d in gf.divisors(n):
        if gf.is_zero(gf.rem(gf.xn_minus_1(d, q), f, q)):
            return d
    raise RuntimeError


if __name__ == "__main__":
    main()
