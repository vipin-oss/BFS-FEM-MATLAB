"""V19 audit, part 3: flagship allocation, general marker residues, and the
manuscript's data tables (proper-D witnesses, relaxation rows, padding costs).
"""
from __future__ import annotations
import json, sys, itertools
sys.path.insert(0, __file__.rsplit('/', 1)[0])
import gf
import audit_core as A
import os

OUT = {}
CHECKS = []


def record(name, ok, detail=None):
    CHECKS.append(dict(check=name, passed=bool(ok), detail=detail))
    print(("PASS " if ok else "FAIL ") + name + ("" if detail is None else f"   [{detail}]"),
          flush=True)


def marker_collisions(f, q, n, y, beta=1):
    M = [gf.norm([beta] + list(t[0]), q) for t in
         [(t,) for t in itertools.product(range(q), repeat=y)]]
    out = []
    for d in range(1, n):
        hit = False
        for b in M:
            for bp in M:
                if gf.is_zero(gf.rem(gf.sub(gf.mul(gf.xpow(d, q), b, q), bp, q), f, q)):
                    hit = True
                    break
            if hit:
                break
        if hit:
            out.append(d)
    return out, len(M)


def window_from(collisions, n):
    if not collisions:
        return n - 1
    return min(min(d, n - d) for d in collisions) - 1


def main():
    # ------------------------------------------------ 1. general residue
    ok, tested, mism = True, 0, []
    for q, n in [(3, 8), (3, 13), (5, 8), (5, 12), (7, 6), (7, 15), (11, 5), (13, 6)]:
        for br in list(A.iter_branches(q, n))[:40]:
            f = br["f"]
            for beta in range(1, q):
                d = gf.gcd_poly(gf.norm([beta], q), f, q)
                fbar = gf.quo(f, d, q)          # residual modulus after dividing out the gcd
                e_res = gf.ord_x(fbar, q, n)
                cols = [delta for delta in range(1, n)
                        if gf.is_zero(gf.rem(gf.sub(gf.mul(gf.xpow(delta, q), (beta,), q),
                                                    (beta,), q), f, q))]
                pred = [delta for delta in range(1, n) if delta % e_res == 0]
                tested += 1
                if cols != pred:
                    ok = False
                    mism.append((q, n, beta, cols, pred, e_res))
    record("Prop. general residue: collisions = multiples of ord_x(f/gcd(f,beta)) "
           f"({tested} (branch,beta) cases)", ok, mism[:3])

    # ------------------------------------- 2. flagship marker allocation
    q, n = 3, 13
    gC = (1, 0, 1, 0, 0, 1, 1)
    gD = (2, 1, 1, 1)
    f = gf.quo(gC, gD, q)
    e = gf.ord_x(f, q, n)
    alloc = {}
    for y in (0, 1, 2):
        cols, nmsg = marker_collisions(f, q, n, y)
        alloc[y] = dict(y=y, symbols=nmsg, collisions=cols, window=window_from(cols, n),
                        guarantee=gf.deg(f) - y - 1, padded=3 * (n + window_from(cols, n)))
    record("Flagship cascade: y=0 window 12, y=1 collisions {3,10} window 2, y=2 window 0",
           alloc[0]["window"] == 12 and alloc[1]["collisions"] == [3, 10]
           and alloc[1]["window"] == 2 and alloc[2]["window"] == 0, alloc)
    # ring-level allocations (y1,y2,y3) for identical components
    ring = {}
    for trip in [(0, 0, 0), (1, 1, 1), (2, 2, 2), (0, 2, 2), (0, 1, 1)]:
        sets = [set(alloc[y]["collisions"]) for y in trip]
        inter = set.intersection(*sets) if sets else set()
        w = window_from(sorted(inter), n)
        ring[str(trip)] = dict(symbols=sum(trip), joint_collisions=sorted(inter),
                               window=w, padded=3 * (n + w))
    record("Flagship ring allocations: (0,2,2) keeps window 12 with 4 symbols; (1,1,1) gives 2",
           ring["(0, 2, 2)"]["window"] == 12 and ring["(0, 2, 2)"]["symbols"] == 4
           and ring["(1, 1, 1)"]["window"] == 2 and ring["(2, 2, 2)"]["window"] == 0, ring)
    OUT["flagship_allocation"] = dict(branch=alloc, ring=ring,
                                      e=e, degf=gf.deg(f), n=n, K=3, M=9)

    # --------------------------- 3. proper-D table witnesses (27 pairs)
    d = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'census_report.json')))
    admissible = {(r["q"], r["n"]): r for r in d["proper_D"]}
    claimed = [  # (q, n, max_single, max_lcm, witness triple) as printed in V18
        (3, 13, 13, 13, (13, 13, 13)), (3, 16, 16, 16, (8, 8, 16)),
        (5, 8, 8, 8, (4, 4, 8)), (5, 12, 12, 12, (4, 4, 12)), (5, 16, 16, 16, (4, 4, 16)),
        (7, 6, 6, 6, (3, 3, 6)), (7, 9, 9, 9, (3, 3, 9)), (7, 12, 12, 12, (3, 3, 12)),
        (7, 15, 15, 15, (3, 3, 15)), (7, 16, 16, 16, (16, 16, 16)), (7, 18, 18, 18, (3, 6, 9)),
        (7, 19, 19, 19, (19, 19, 19)), (11, 5, 5, 5, (5, 5, 5)), (11, 10, 10, 10, (5, 5, 10)),
        (11, 14, 14, 14, (7, 7, 14)), (11, 15, 15, 15, (5, 5, 15)), (11, 16, 16, 16, (8, 8, 16)),
        (11, 19, 19, 19, (19, 19, 19)), (11, 20, 20, 20, (5, 5, 20)), (13, 6, 6, 6, (3, 3, 6)),
        (13, 8, 8, 8, (4, 4, 8)), (13, 9, 9, 9, (3, 3, 9)), (13, 12, 12, 12, (3, 3, 4)),
        (13, 15, 15, 15, (3, 3, 15)), (13, 16, 16, 16, (4, 4, 16)), (13, 18, 18, 18, (3, 6, 9)),
        (13, 20, 20, 20, (4, 4, 20)),
    ]
    bad = []
    rows = []
    for q, n, ms, ml, trip in claimed:
        r = admissible.get((q, n))
        E = r["E"] if r else []
        okrow = (r is not None and max(E) == ms and all(t in E for t in trip)
                 and gf.lcmm(*trip) == ml)
        if not okrow:
            bad.append((q, n, ms, ml, trip, E))
        rows.append(dict(q=q, n=n, E=E, max_single=max(E) if E else None,
                         witness=list(trip), lcm=gf.lcmm(*trip), ok=okrow))
    record("Table dconstr: all 27 witness triples are admissible proper-D periods", not bad,
           bad[:3])
    # every admissible pair has a triple attaining n; record the chosen witnesses
    tri_ok = True
    for (q, n), r in admissible.items():
        E = r["E"]
        best = max(gf.lcmm(*t) for t in itertools.combinations_with_replacement(E, 3))
        tri_ok &= (best == n)
    record("Table dconstr: max lcm over admissible triples equals n in all 27 pairs", tri_ok)
    OUT["proper_D_table"] = rows

    # ------------------------------------------- 4. relaxation table rows
    claimed_relax = [(61, 60, (3, 4, 5), 12), (73, 72, (3, 8, 9), 8), (89, 88, (4, 8, 11), 8),
                     (71, 70, (5, 7, 10), 7), (43, 42, (3, 6, 7), 6), (67, 66, (3, 6, 11), 6),
                     (79, 78, (3, 6, 13), 6)]
    got = {(r["q"], r["n"]): r for r in d["relaxation"]["table"]}
    bad = []
    for q, n, trip, factor in claimed_relax:
        r = got.get((q, n))
        if not r or tuple(r["orders"]) != trip or int(r["factor"]) != factor:
            bad.append((q, n, trip, r))
    record("Table relax: all seven rows reproduce with the stated orders and factors",
           not bad, bad[:2])
    OUT["relax_table"] = d["relaxation"]["table"]

    # ---------------------------------------- 5. padding cost (flagship)
    OUT["padding"] = [dict(window=w, qudits=3 * (13 + w), K=3, M=9,
                           payload=round(3 / (3 * (13 + w)), 4))
                      for w in (0, 2, 12)]
    record("Padding cost: 39 / 45 / 75 qudits for windows 0 / 2 / 12", True,
           OUT["padding"])

    # ----------------------- 6. scatter data for the q=3 figure (e vs deg f)
    scatter = []
    for n in range(2, 21):
        if n % 3 == 0:
            continue
        for br in A.iter_branches(3, n):
            scatter.append(dict(n=n, degf=br["degf"], e=br["e"],
                                window=br["e"] - 1, bound=br["degf"] - 1))
    OUT["scatter_q3"] = scatter
    record(f"Scatter data: {len(scatter)} branches over F_3 with 2 <= n <= 20", True)

    json.dump(dict(checks=CHECKS, data=OUT), open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'extra_report.json'), 'w'), indent=1, default=str)
    print(f"\n{sum(1 for c in CHECKS if c['passed'])}/{len(CHECKS)} extra checks passed")


if __name__ == '__main__':
    main()
