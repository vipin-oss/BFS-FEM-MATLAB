#!/usr/bin/env python3
"""Build the LaTeX and Typst versions of a V19 document from one Markdown source.

The Markdown dialect is deliberately small (see docstring of parse()).

  python3 build.py paper.md --tex out.tex --typ out.typ
"""
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
import mathconv

THM_KINDS = {
    'theorem': ('theorem', 'Theorem'), 'proposition': ('proposition', 'Proposition'),
    'lemma': ('lemma', 'Lemma'), 'corollary': ('corollary', 'Corollary'),
    'definition': ('definition', 'Definition'), 'example': ('example', 'Example'),
    'remark': ('remark', 'Remark'), 'question': ('question', 'Question'),
    'conjecture': ('conjecture', 'Conjecture'), 'fact': ('fact', 'Fact'),
}


class Doc:
    def __init__(self):
        self.meta = {}
        self.abstract = []
        self.blocks = []           # list of dicts
        self.labels = {}           # key -> (kind, number)


def parse(text):
    d = Doc()
    lines = text.split('\n')
    i = 0
    section = 0
    appendix = 0
    seclabel = '0'
    counters = {}
    while i < len(lines):
        ln = lines[i]
        s = ln.strip()
        if not s:
            i += 1; continue
        if s.startswith('@') and not s.startswith('@ '):
            key, _, val = s[1:].partition(' ')
            if key == 'abstract':
                buf = [val] if val.strip() else []
                i += 1
                while i < len(lines) and not lines[i].strip().startswith('@body'):
                    buf.append(lines[i]); i += 1
                d.abstract = buf
                i += 1
                continue
            d.meta[key] = val.strip()
            i += 1; continue
        if s == '@body':
            i += 1; continue
        if s.startswith('#'):
            level = len(s) - len(s.lstrip('#'))
            title = s[level:].strip()
            if level == 1:
                section += 1
                counters = {}
                if title.lower().startswith('appendix'):
                    appendix += 1
                    seclabel = chr(64 + appendix)
                else:
                    seclabel = str(section)
            d.blocks.append(dict(t='heading', level=level, title=title, sec=section))
            i += 1; continue
        if s.startswith('$$'):
            buf = [s]
            one_liner = len(re.findall(r'\$\$', s)) >= 2
            while not one_liner and not re.match(r'^\$\$\s*(\{#[^}]*\})?\s*$', buf[-1]):
                i += 1
                if i >= len(lines):
                    raise ValueError('unterminated display math starting %r' % s)
                buf.append(lines[i].strip())
            body = '\n'.join(buf)
            body = re.sub(r'^\$\$', '', body).strip()
            body = re.sub(r'\$\$', '', body).strip()
            label = None
            m = re.search(r'\{#((?:eq|tab|fig)[-:][A-Za-z0-9:_-]+)\}\s*$', body)
            if m:
                label = m.group(1).replace('-', ':', 1)
                body = body[:m.start()].strip()
            d.blocks.append(dict(t='display', math=body, label=label))
            if label:
                d.labels[label] = ('eq', None)
            i += 1; continue
        if s.startswith(':::'):
            head = s[3:].strip()
            parts = head.split(None, 1)
            kind = parts[0]
            rest = parts[1] if len(parts) > 1 else ''
            m = re.match(r'([A-Za-z0-9:_-]+)\s*(?:"(.*)")?', rest)
            key = m.group(1) if m else ''
            title = (m.group(2) or '') if m else ''
            body = []
            i += 1
            while i < len(lines) and lines[i].strip() != ':::':
                body.append(lines[i]); i += 1
            i += 1
            texx, disp = THM_KINDS[kind]
            counters[texx] = counters.get(texx, 0) + 1
            number = f'{seclabel}.{sum(counters.values())}'
            if key:
                d.labels[key] = ('thm', number)
            d.blocks.append(dict(t='thm', kind=kind, texx=texx, disp=disp, key=key,
                                 title=title, number=number, lines=body, sec=section))
            continue
        if s.startswith('Table:'):
            m = re.match(r'Table:\s*(.*?)\s*\{#((?:tab|fig)[-:][A-Za-z0-9:_-]+)\}\s*(.*)$', s)
            if not m:
                raise ValueError('bad table header: %r' % s)
            caption, key, extra = m.group(1), m.group(2).replace('-', ':', 1), m.group(3)
            i += 1
            rows = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                cells = [c.strip() for c in _split_row(lines[i].strip())]
                rows.append(cells)
                i += 1
            note = ''
            if i < len(lines) and lines[i].strip().startswith('Note:'):
                note = lines[i].strip()[5:].strip(); i += 1
            rows = [r for r in rows if not all(re.fullmatch(r':?-{2,}:?', c) for c in r)]
            d.blocks.append(dict(t='table', caption=caption, key=key, rows=rows,
                                 note=note, extra=extra))
            d.labels[key] = ('tab', None)
            continue
        if s.startswith('Figure:'):
            m = re.match(r'Figure:\s*(.*?)\s*\{#((?:fig|tab)[-:][A-Za-z0-9:_-]+)\}\s*(.*)$', s)
            if not m:
                raise ValueError('bad figure header: %r' % s)
            caption, key, extra = m.group(1), m.group(2).replace('-', ':', 1), m.group(3)
            i += 1
            img = lines[i].strip()
            m2 = re.match(r'!\[(.*?)\]\((.*?)\)(.*)', img)
            path = m2.group(2)
            d.blocks.append(dict(t='figure', caption=caption, key=key, path=path, extra=extra))
            d.labels[key] = ('fig', None)
            i += 1
            continue
        if s.startswith('- '):
            items = []
            while i < len(lines) and lines[i].strip().startswith('- '):
                items.append(lines[i].strip()[2:]); i += 1
            d.blocks.append(dict(t='ul', items=items)); continue
        if re.match(r'^\d+\.\s', s):
            items = []
            while i < len(lines) and re.match(r'^\d+\.\s', lines[i].strip()):
                items.append(re.sub(r'^\d+\.\s', '', lines[i].strip())); i += 1
            d.blocks.append(dict(t='ol', items=items)); continue
        if s.startswith('> '):
            quote = []
            while i < len(lines) and lines[i].strip().startswith('> '):
                quote.append(lines[i].strip()[2:]); i += 1
            d.blocks.append(dict(t='quote', lines=quote)); continue
        # paragraph
        para = [s]
        i += 1
        while i < len(lines) and lines[i].strip() and not re.match(
                r'^(#|:::|Table:|Figure:|\$\$|- |\d+\. |> |@)', lines[i].strip()):
            para.append(lines[i].strip()); i += 1
        d.blocks.append(dict(t='p', text=' '.join(para)))
    return d


# --------------------------------------------------------------- inline
def inline_tex(s, labels, cite_style='ams'):
    s, spans = _protect_math(s, lambda x: x)
    return _restore_math(_inline_tex_protected(s, labels), spans, '$%s$')


def _inline_tex_protected(s, labels):
    out, i = [], 0
    while i < len(s):
        c = s[i]
        if s.startswith('**', i):
            j = s.find('**', i + 2)
            if j == -1:
                out.append('*'); i += 1; continue
            out.append('\\textbf{' + _inline_tex_protected(s[i + 2:j], labels) + '}'); i = j + 2; continue
        if s.startswith('*', i) and not s.startswith('**', i):
            j = s.find('*', i + 1)
            if j != -1:
                out.append('\\emph{' + _inline_tex_protected(s[i + 1:j], labels) + '}'); i = j + 1; continue
        if s.startswith('{ref:', i):
            j = s.index('}', i)
            key = s[i + 5:j]
            if key not in labels and key.replace('-', ':', 1) in labels:
                key = key.replace('-', ':', 1)
            if key.startswith('tab:'):
                out.append('Table~\\ref{%s}' % key)
            elif key.startswith('fig:'):
                out.append('Figure~\\ref{%s}' % key)
            elif key.startswith('eq:'):
                out.append('\\eqref{%s}' % key)
            else:
                out.append('\\ref{%s}' % key)
            i = j + 1; continue
        if s.startswith('[@', i):
            j = s.index(']', i)
            keys = [k.strip().lstrip('@') for k in s[i + 2:j].split(';') if k.strip()]
            out.append('\\cite{%s}' % ','.join(keys)); i = j + 1; continue
        if c == '`':
            j = s.index('`', i + 1)
            out.append('\\texttt{' + s[i + 1:j].replace('_', '\\_') + '}'); i = j + 1; continue
        if c == '\\':
            out.append(s[i:i + 2]); i += 2; continue
        if c in '_%&#':
            out.append('\\' + c); i += 1; continue
        out.append(c); i += 1
    return ''.join(out)


def _protect_math(s, convert):
    """Replace each $...$ span by a placeholder and return (text, spans)."""
    out, spans, i = [], [], 0
    while i < len(s):
        if s[i] == '\\':
            out.append(s[i:i + 2]); i += 2; continue
        if s[i] == '$':
            j = s.find('$', i + 1)
            if j == -1:
                out.append('\\$'); i += 1; continue
            spans.append(convert(s[i + 1:j]))
            out.append('\x00%d\x00' % (len(spans) - 1))
            i = j + 1; continue
        out.append(s[i]); i += 1
    return ''.join(out), spans


def _restore_math(txt, spans, tmpl):
    return re.sub(r'\x00(\d+)\x00', lambda m: tmpl % spans[int(m.group(1))], txt)


def inline_typ(s, labels):
    s, spans = _protect_math(s, mathconv.convert)
    return _restore_math(_inline_typ_protected(s, labels), spans, '$%s$')


def _inline_typ_protected(s, labels):
    out, i = [], 0
    while i < len(s):
        c = s[i]
        if s.startswith('**', i):
            j = s.find('**', i + 2)
            if j == -1:
                out.append('*'); i += 1; continue
            out.append('*' + _inline_typ_protected(s[i + 2:j], labels) + '*'); i = j + 2; continue
        if c == '*':
            j = s.find('*', i + 1)
            if j == -1:
                out.append('*'); i += 1; continue
            out.append('_' + _inline_typ_protected(s[i + 1:j], labels) + '_'); i = j + 1; continue
        if s.startswith('{ref:', i):
            j = s.index('}', i)
            key = s[i + 5:j]
            if ':' not in key and '-' in key:
                key = key.replace('-', ':', 1)
            if key.startswith('eq:'):
                lab = key.replace(':', '-')
                out.append('#context numbering("(1)", counter(math.equation).at(<%s>).first())' % lab)
            elif labels.get(key, ('', ''))[0] in ('tab', 'fig') and labels[key][1]:
                kind, num = labels[key]
                out.append('%s %s' % ('Table' if kind == 'tab' else 'Figure', num))
            else:
                kind, num = labels.get(key, ('thm', '??'))
                out.append(num or ('@' + key.replace(':', '-')))
            i = j + 1; continue
        if c == '@' and i + 1 < len(s):
            m = re.match(r'@(eq|tab|fig)[-:]([A-Za-z0-9_-]+)', s[i:])
            if m:
                key = '%s:%s' % (m.group(1), m.group(2))
                if key not in labels and m.group(1) in ('tab', 'fig'):
                    for cand in labels:
                        if cand.replace(':', '-') == m.group(0)[1:]:
                            key = cand
                            break
                if m.group(1) == 'eq':
                    out.append('#context numbering("(1)", counter(math.equation).at(<%s>).first())'
                               % m.group(0)[1:].replace(':', '-'))
                elif labels.get(key, ('', ''))[0] in ('tab', 'fig') and labels[key][1]:
                    kind, num = labels[key]
                    out.append('%s %s' % ('Table' if kind == 'tab' else 'Figure', num))
                else:
                    out.append('@' + m.group(0)[1:].replace(':', '-'))
                i += len(m.group(0))
                continue
        if s.startswith('[@', i):
            j = s.index(']', i)
            keys = [k.strip().lstrip('@') for k in s[i + 2:j].split(';') if k.strip()]
            out.append(', '.join('#cite(<%s>)' % k for k in keys))
            i = j + 1
            # Typst parses ';' after a code expression as a terminator and drops it.
            if i < len(s) and s[i] == ';':
                out.append('#text(";")'); i += 1
            continue
        if c == '`':
            j = s.index('`', i + 1)
            out.append('`' + s[i + 1:j] + '`'); i = j + 1; continue
        if c in '*_\\#':
            out.append('\\' + c if c in '*_\\#' else c); i += 1; continue
        out.append(c); i += 1
    return ''.join(out)


# ---------------------------------------------------------------- LaTeX
PREAMBLE = r'''\documentclass[11pt,reqno]{amsart}
\usepackage{amsmath,amssymb,amsthm}
\usepackage{booktabs}
\usepackage{array}
\usepackage{graphicx}
\usepackage{microtype}
\usepackage[margin=1.05in]{geometry}
\usepackage[hidelinks]{hyperref}

\newtheorem{theorem}{Theorem}[section]
\newtheorem{proposition}[theorem]{Proposition}
\newtheorem{lemma}[theorem]{Lemma}
\newtheorem{corollary}[theorem]{Corollary}
\theoremstyle{definition}
\newtheorem{definition}[theorem]{Definition}
\newtheorem{example}[theorem]{Example}
\newtheorem{question}[theorem]{Question}
\newtheorem{conjecture}[theorem]{Conjecture}
\theoremstyle{remark}
\newtheorem{remark}[theorem]{Remark}
\newtheorem{fact}[theorem]{Fact}

\emergencystretch=2em
\newcommand{\F}{\mathbb{F}}
\newcommand{\Z}{\mathbb{Z}}
\newcommand{\wt}{\operatorname{wt}}
\newcommand{\ord}{\operatorname{ord}}
\newcommand{\lcm}{\operatorname{lcm}}
\newcommand{\M}{\mathcal{M}}
\newcommand{\gen}[1]{\langle #1\rangle}

\title[%(shorttitle)s]{%(title)s}
\author{%(author)s}
\address{%(affiliation)s}
\email{%(email)s}
\subjclass[2020]{%(msc)s}
\keywords{%(keywords)s}

\begin{document}

\begin{abstract}
%(abstract)s
\end{abstract}

\maketitle
'''

POSTAMBLE = r'''
\bibliographystyle{amsplain}
\bibliography{References}

\end{document}
'''


def _blocks_tex(lines, labels):
    """LaTeX rendering of raw block lines, keeping display math intact."""
    out, i, cur = [], 0, []

    def flush():
        if cur:
            out.append(inline_tex(' '.join(x.strip() for x in cur), labels))
            cur.clear()

    while i < len(lines):
        s = lines[i].strip()
        if not s:
            i += 1
            continue
        if s.startswith('$$'):
            flush()
            buf = [s]
            one = len(re.findall(r'\$\$', s)) >= 2
            while not one and not re.match(r'^\$\$\s*(\{#[^}]*\})?\s*$', buf[-1]):
                i += 1
                if i >= len(lines):
                    raise ValueError('unterminated display math in block: %r' % s)
                buf.append(lines[i].strip())
            body = '\n'.join(buf)
            body = re.sub(r'^\$\$', '', body).strip()
            body = re.sub(r'\$\$', '', body).strip()
            m = re.search(r'\{#((?:eq|tab|fig)[-:][A-Za-z0-9:_-]+)\}\s*$', body)
            if m:
                out.append('\\begin{equation}\\label{%s}\n%s\n\\end{equation}'
                           % (m.group(1).replace('-', ':', 1), body[:m.start()].strip()))
            else:
                out.append('\\[\n%s\n\\]' % body)
            i += 1
            continue
        cur.append(s)
        i += 1
    flush()
    return out


def to_tex(d):
    _number_floats(d)
    d_appendix = [False]
    meta = dict(title=d.meta.get('title', '').replace('_', '\\_'),
                shorttitle=d.meta.get('shorttitle', d.meta.get('title', '')),
                author=d.meta.get('author', ''), affiliation=d.meta.get('affiliation', ''),
                email=d.meta.get('email', ''), msc=d.meta.get('msc', ''),
                keywords=d.meta.get('keywords', ''))
    # LaTeX needs _ escaped only outside math; keep as given for author fields
    meta['title'] = d.meta.get('title', '')
    meta['abstract'] = inline_tex(' '.join(x.strip() for x in d.abstract), d.labels)
    out = [PREAMBLE % meta]
    first = True
    for i, b in enumerate(d.blocks):
        t = b['t']
        if t == 'heading':
            if first:
                out.append('\\section{%s}\\label{sec:%s}' % (
                    inline_tex(b['title'], d.labels), _slug(b['title'])))
                first = False
            elif b['level'] == 1:
                if b['title'].lower().startswith('appendix') and not d_appendix[0]:
                    out.append('\\appendix')
                    d_appendix[0] = True
                clean = re.sub(r'^appendix\s*:?\s*', '', b['title'], flags=re.I)
                out.append('\\section{%s}\\label{sec:%s}' % (
                    inline_tex(clean, d.labels), _slug(b['title'])))
            elif b['level'] == 2:
                out.append('\\subsection{%s}' % inline_tex(b['title'], d.labels))
            else:
                out.append('\\subsubsection{%s}' % inline_tex(b['title'], d.labels))
        elif t == 'p':
            out.append(inline_tex(b['text'], d.labels) + '\n')
        elif t == 'display':
            if b['label']:
                out.append('\\begin{equation}\\label{%s}\n%s\n\\end{equation}' % (b['label'], b['math']))
            else:
                out.append('\\[\n%s\n\\]' % b['math'])
        elif t == 'thm':
            env = b['texx']
            title = ('[%s]' % b['title']) if b['title'] else ''
            body = '\n\n'.join(_blocks_tex(b['lines'], d.labels))
            out.append('\\begin{%s}%s\\label{%s}\n%s\n\\end{%s}' % (
                env, title, b['key'] or ('auto%d' % i), body, env))
        elif t == 'ul':
            out.append('\\begin{itemize}\n' + '\n'.join(
                '\\item ' + inline_tex(x, d.labels) for x in b['items']) + '\n\\end{itemize}')
        elif t == 'ol':
            out.append('\\begin{enumerate}\n' + '\n'.join(
                '\\item ' + inline_tex(x, d.labels) for x in b['items']) + '\n\\end{enumerate}')
        elif t == 'quote':
            out.append('\\begin{quote}\n' + '\n\n'.join(
                inline_tex(x, d.labels) for x in b['lines']) + '\n\\end{quote}')
        elif t == 'table':
            cols = _cols(b['extra'], b['rows'])
            body = ' \\\\\n'.join(' & '.join(inline_tex(c, d.labels) for c in row)
                                  for row in b['rows'])
            out.append('\\begin{table}[t]\n\\centering\n\\caption{%s\\label{%s}}\n'
                       '\\small\n\\begin{tabular}{%s}\n\\toprule\n%s \\\\\n\\bottomrule\n'
                       '\\end{tabular}\n%s\n\\end{table}' % (
                           inline_tex(b['caption'], d.labels), b['key'], cols, body,
                           ('\n\\smallskip\n\\parbox{\\linewidth}{\\footnotesize %s}' %
                            inline_tex(b['note'], d.labels)) if b['note'] else ''))
        elif t == 'figure':
            out.append('\\begin{figure}[t]\n\\centering\n\\includegraphics[width=%s]{%s}\n'
                       '\\caption{%s\\label{%s}}\n\\end{figure}' % (
                           '0.8\\linewidth', b['path'].replace('.svg', '.pdf'),
                           inline_tex(b['caption'], d.labels), b['key']))
    out.append(POSTAMBLE)
    return '\n\n'.join(out).replace('{REF:', '{ref:')


def _split_row(row):
    """Split a table row at pipes that are not inside inline math."""
    assert row.startswith('|')
    body = row[1:-1] if row.endswith('|') else row[1:]
    out, cur, in_math = [], [], False
    for ch in body:
        if ch == '$':
            in_math = not in_math
            cur.append(ch)
        elif ch == '|' and not in_math:
            out.append(''.join(cur)); cur = []
        else:
            cur.append(ch)
    out.append(''.join(cur))
    return out


def _slug(t):
    return re.sub(r'[^a-z0-9]+', '-', t.lower()).strip('-')


def _nonblank(lines):
    paras, cur = [], []
    for ln in lines:
        if ln.strip():
            cur.append(ln)
        elif cur:
            paras.append(' '.join(cur)); cur = []
    if cur:
        paras.append(' '.join(cur))
    return paras


def _cols(extra, rows):
    m = re.search(r'cols=([lcr|]+)', extra or '')
    if m:
        return m.group(1).replace('|', '')
    return 'c' * max(len(r) for r in rows)


# ---------------------------------------------------------------- Typst
TYP_PRE = r'''// Generated from the single Markdown source; do not edit by hand.
#set document(title: "%(title)s", author: "%(author)s")
#set page(paper: "us-letter", margin: (x: 1.05in, y: 1.0in),
         numbering: "1", number-align: center)
#set text(font: "New Computer Modern", size: 10.2pt, lang: "en", hyphenate: true)
#set par(justify: true, leading: 0.72em, spacing: 1.15em)
#set par.line(numbering: none)
#set heading(numbering: "1.")
#show heading.where(level: 1): it => { v(0.7em); it; v(0.35em) }
#show heading.where(level: 2): it => { v(0.5em); it; v(0.2em) }
#set math.equation(numbering: "(1)")
#set figure(supplement: none, numbering: none)
#set table(inset: 4pt, stroke: 0.4pt)
#show figure.where(kind: "table"): set figure.caption(position: top)
#show figure.where(kind: "figure"): set figure.caption(position: bottom)
#set figure.caption(separator: [. ])
#set footnote(numbering: "1")
#set cite(form: "normal")

#align(center)[#set par(justify: false)
  #text(size: 15pt, weight: "bold")[%(titlerender)s]
  #v(0.7em)
  #text(size: 11.5pt)[%(author)s]
  #v(0.35em)
  #text(size: 10pt)[%(affiliation)s]
  #v(0.2em)
  #text(size: 9.5pt, "%(email)s")
]

#v(0.6em)
#block(inset: (x: 2.2em), width: 100%%)[
  #text(size: 9.8pt)[*Abstract.* %(abstract)s]
]
#v(0.6em)
'''

TYP_POST = r'''
#v(1.2em)
#bibliography("References.bib", style: "ieee", title: "References")
'''

TYP_POST_NOBIB = r'''
'''


def plain(s):
    """Plain-text rendering of a title, for PDF metadata."""
    s = s.replace('$', '')
    out, i = [], 0
    while i < len(s):
        if s[i] == '\\' and i + 1 < len(s) and s[i + 1].isalpha():
            j = i + 1
            while j < len(s) and s[j].isalpha():
                j += 1
            name = s[i + 1:j]
            out.append({'F': 'F', 'Z': 'Z', 'M': 'M', 'wt': 'wt', 'ord': 'ord',
                        'lcm': 'lcm'}.get(name, ''))
            i = j
        elif s[i] in '{}':
            i += 1
        elif s[i] == '_':
            out.append('')
            i += 2 if i + 1 < len(s) and s[i + 1] == '{' else 1
        else:
            out.append(s[i]); i += 1
    return re.sub(r'\s+', ' ', ''.join(out)).strip()


def _display_typ(math, label):
    body = mathconv.convert(math)
    if label:
        return '$ %s $ <%s>' % (body, label.replace(':', '-'))
    return '$ %s $' % body


def _blocks_typ(lines, labels):
    """Convert raw body lines of a theorem/quote block into Typst chunks."""
    out, i, cur = [], 0, []

    def flush():
        if cur:
            out.append(inline_typ(' '.join(x.strip() for x in cur), labels))
            cur.clear()

    while i < len(lines):
        s = lines[i].strip()
        if not s:
            i += 1
            continue
        if s.startswith('$$'):
            flush()
            buf = [s]
            one = len(re.findall(r'\$\$', s)) >= 2
            while not one and not re.match(r'^\$\$\s*(\{#[^}]*\})?\s*$', buf[-1]):
                i += 1
                if i >= len(lines):
                    raise ValueError('unterminated display math in block: %r' % s)
                buf.append(lines[i].strip())
            body = '\n'.join(buf)
            body = re.sub(r'^\$\$', '', body).strip()
            body = re.sub(r'\$\$', '', body).strip()
            m = re.search(r'\{#((?:eq|tab|fig)[-:][A-Za-z0-9:_-]+)\}\s*$', body)
            label = None
            if m:
                label = m.group(1)
                body = body[:m.start()].strip()
            out.append(_display_typ(body, label))
            i += 1
            continue
        cur.append(s)
        i += 1
    flush()
    return out


def _number_floats(d):
    ntab = nfig = 0
    for b in d.blocks:
        if b['t'] == 'table':
            ntab += 1
            d.labels[b['key']] = ('tab', str(ntab))
            b['num'] = str(ntab)
        elif b['t'] == 'figure':
            nfig += 1
            d.labels[b['key']] = ('fig', str(nfig))
            b['num'] = str(nfig)


def to_typ(d):
    _number_floats(d)
    meta = dict(title=plain(d.meta.get('title', '')).replace('"', "'"),
                author=d.meta.get('author', '').replace('"', "'"),
                affiliation=d.meta.get('affiliation', '').replace('"', "'"),
                email=d.meta.get('email', '').replace('"', "'"))
    meta['titlerender'] = inline_typ(d.meta.get('title', ''), d.labels)
    abstract = ' '.join(x.strip() for x in d.abstract if x.strip())
    meta['abstract'] = inline_typ(abstract, d.labels)
    out = [TYP_PRE % meta]
    first = True
    app = 0
    for i, b in enumerate(d.blocks):
        t = b['t']
        if t == 'heading':
            if b['level'] == 1 and b['title'].lower().startswith('appendix'):
                app += 1
                clean = re.sub(r'^appendix\s*:?\s*', '', b['title'], flags=re.I)
                out.append('#heading(numbering: none, level: 1)[Appendix %s. %s]'
                           % (chr(64 + app), inline_typ(clean, d.labels)))
            elif b['level'] == 1:
                out.append('= %s' % inline_typ(b['title'], d.labels))
            elif b['level'] == 2:
                out.append('== %s' % inline_typ(b['title'], d.labels))
            else:
                out.append('=== %s' % inline_typ(b['title'], d.labels))
        elif t == 'p':
            out.append(inline_typ(b['text'], d.labels))
        elif t == 'display':
            out.append(_display_typ(b['math'], b['label']))
        elif t == 'thm':
            body = '\n\n'.join(_blocks_typ(b['lines'], d.labels))
            title = (' (%s)' % b['title']) if b['title'] else ''
            out.append('#block(inset: (left: 1.1em), width: 100%%, above: 0.85em, below: 0.85em)['
                       '#text(weight: "bold")[%s %s%s.] %s]' % (
                           b['disp'], b['number'], title, body))
        elif t == 'ul':
            out.append('\n'.join('- ' + inline_typ(x, d.labels) for x in b['items']))
        elif t == 'ol':
            out.append('\n'.join('+ ' + inline_typ(x, d.labels) for x in b['items']))
        elif t == 'quote':
            out.append('#block(inset: (left: 1.2em), stroke: (left: 0.6pt), width: 100%%)[%s]' %
                       ' '.join(inline_typ(x, d.labels) for x in b['lines']))
        elif t == 'table':
            ncol = max(len(r) for r in b['rows'])
            rows = ',\n    '.join(', '.join('[' + inline_typ(c, d.labels) + ']' for c in row)
                                  for row in b['rows'])
            hdr = ', '.join('[*%s*]' % inline_typ(c, d.labels) for c in b['rows'][0])
            rest = b['rows'][1:]
            rest_txt = ',\n    '.join(', '.join('[' + inline_typ(c, d.labels) + ']' for c in row)
                                      for row in rest)
            note = ('\n  #v(0.35em)\n  #par(justify: true, first-line-indent: 0em)[#text(size: 8.6pt)[%s]]'
                    % inline_typ(b['note'], d.labels)) if b['note'] else ''
            out.append('#figure(\n  table(columns: %d, align: center,\n    table.header(%s),\n    %s\n  ),\n'
                       '  caption: [*Table %s.* %s],\n  kind: "table",\n) <%s>%s' % (
                           ncol, hdr, rest_txt, b.get('num', ''), inline_typ(b['caption'], d.labels),
                           b['key'].replace(':', '-'), note))
        elif t == 'figure':
            out.append('#figure(image("%s", width: 78%%), caption: [*Figure %s.* %s]) <%s>' % (
                b['path'], b.get('num', ''), inline_typ(b['caption'], d.labels),
                b['key'].replace(':', '-')))
    out.append(TYP_POST if d.meta.get('bibliography', 'yes') != 'no' else TYP_POST_NOBIB)
    return '\n\n'.join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('src')
    ap.add_argument('--tex')
    ap.add_argument('--typ')
    a = ap.parse_args()
    d = parse(Path(a.src).read_text())
    if a.tex:
        Path(a.tex).write_text(to_tex(d))
    if a.typ:
        Path(a.typ).write_text(to_typ(d))
    print(json.dumps({'labels': {k: v[0] for k, v in d.labels.items()},
                      'n_blocks': len(d.blocks)}, indent=1))


if __name__ == '__main__':
    main()
