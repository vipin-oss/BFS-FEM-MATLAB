#!/usr/bin/env python3
"""Static validation of the generated LaTeX manuscript.

No TeX installation is available in the verification environment, so the
manuscript is validated structurally instead of being compiled:

  * environments balance and nest;
  * braces and dollar signs balance;
  * every \\ref, \\eqref and \\cite resolves;
  * every label is referenced at least once;
  * every table row has the declared number of columns;
  * only characters from a conservative whitelist appear outside math;
  * theorem-like environments are used only with the numbering scheme that
    the preamble declares.
"""
import os
import json
import re
import sys
import unicodedata

TEX = sys.argv[1] if len(sys.argv) > 1 else 'manuscript/Main_Manuscript.tex'
BIB = sys.argv[2] if len(sys.argv) > 2 else 'manuscript/References.bib'

src = open(TEX, encoding='utf-8').read()
bib = open(BIB, encoding='utf-8').read()
problems, notes = [], []

# ---------------------------------------------------------------- environments
stack = []
for m in re.finditer(r'\\(begin|end)\{([^}]+)\}', src):
    kind, name = m.group(1), m.group(2)
    if kind == 'begin':
        stack.append((name, m.start()))
    else:
        if not stack:
            problems.append('\\end{%s} without matching \\begin at offset %d' % (name, m.start()))
        elif stack[-1][0] != name:
            problems.append('\\begin{%s} closed by \\end{%s} at offset %d'
                            % (stack[-1][0], name, m.start()))
            stack.pop()
        else:
            stack.pop()
if stack:
    problems.append('unclosed environments: %s' % [s[0] for s in stack])

# ---------------------------------------------------------------------- braces
depth = 0
i = 0
while i < len(src):
    if src[i] == '\\':
        i += 2
        continue
    if src[i] == '{':
        depth += 1
    elif src[i] == '}':
        depth -= 1
        if depth < 0:
            problems.append('unbalanced closing brace at offset %d' % i)
            depth = 0
    i += 1
if depth:
    problems.append('%d unclosed braces' % depth)

# ---------------------------------------------------------- inline math parity
body = src[src.index('\\begin{document}'):]
text = re.sub(r'\\\[.*?\\\]', '', body, flags=re.S)
text = re.sub(r'\\begin\{(equation\*?|align\*?|gather\*?)\}.*?\\end\{\1\}', '', text, flags=re.S)
n_dollar = len(re.findall(r'(?<!\\)\$', text))
if n_dollar % 2:
    problems.append('odd number of $ delimiters (%d)' % n_dollar)

# ------------------------------------------------------------ refs and labels
labels = set(re.findall(r'\\label\{([^}]+)\}', src))
refs = re.findall(r'\\(?:eq)?ref\{([^}]+)\}', src)
for r in refs:
    if r not in labels:
        problems.append('reference to undefined label %r' % r)
for lab in labels:
    if lab not in refs:
        notes.append('label %r is never referenced' % lab)
dupes = [l for l in labels if len(re.findall(r'\\label\{%s\}' % re.escape(l), src)) > 1]
if dupes:
    problems.append('duplicate labels: %s' % dupes)

# -------------------------------------------------------------------- citations
keys = set()
for m in re.findall(r'\\cite\{([^}]+)\}', src):
    for k in m.split(','):
        keys.add(k.strip())
bibkeys = set(re.findall(r'@\w+\{([^,]+),', bib))
for k in sorted(keys - bibkeys):
    problems.append('citation %r has no bibliography entry' % k)
for k in sorted(bibkeys - keys):
    notes.append('bibliography entry %r is never cited' % k)

# ---------------------------------------------------------------------- tables
for m in re.finditer(r'\\begin\{tabular\}\{([^}]*)\}(.*?)\\end\{tabular\}', src, re.S):
    ncol = len(re.sub(r'[^lcrpmb|]', '', m.group(1)))
    # split rows on \\ only outside math
    body_t = m.group(2)
    rows, cur, in_math = [], [], False
    k = 0
    while k < len(body_t):
        if body_t[k] == '\\' and k + 1 < len(body_t) and body_t[k + 1] == '\\':
            if in_math:
                cur.append('\\\\'); k += 2; continue
            rows.append(''.join(cur)); cur = []; k += 2; continue
        if body_t[k] == '\\' and k + 1 < len(body_t) and body_t[k + 1] in '{}%$':
            cur.append(body_t[k:k + 2]); k += 2; continue
        if body_t[k] == '$':
            in_math = not in_math
        cur.append(body_t[k]); k += 1
    rows.append(''.join(cur))
    for row in rows:
        row = row.strip()
        if not row or row.startswith('\\toprule') or row.startswith('\\midrule') \
                or row.startswith('\\bottomrule') or row.startswith('\\cmidrule') \
                or 'multicolumn' in row:
            continue
        cells = row.count('&') + 1
        if cells != ncol:
            problems.append('table row with %d cells in a %d-column table: %r'
                            % (cells, ncol, row[:70]))

# ------------------------------------------------------------ graphics targets
for m in re.finditer(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}', src):
    target = m.group(1).strip()
    base = os.path.dirname(os.path.abspath(TEX))
    cands = [target] if os.path.splitext(target)[1] else \
        [target + '.' + e for e in ('pdf', 'png', 'jpg', 'jpeg', 'eps')]
    if not any(os.path.exists(os.path.join(base, c)) for c in cands):
        problems.append('\\includegraphics target not found: %s' % target)
    else:
        notes.append('graphic %s found' % target)

# ------------------------------------------------------------- character check
allowed_extra = set('—–‘’“”… ±×·−')
bad = {}
for ch in body:
    if ord(ch) < 128 or ch in allowed_extra:
        continue
    if ch in 'αβγδεζηθικλμνξπρστυφχψωΓΔΘΛΞΠΣΦΨΩ':
        continue
    bad.setdefault(ch, 0)
    bad[ch] += 1
if bad:
    notes.append('non-ASCII characters outside math: %s'
                 % ', '.join('%r x%d' % (k, v) for k, v in sorted(bad.items())))
    problems.append('non-ASCII characters in text mode: %s' % ''.join(sorted(bad)))

# ------------------------------------------------------- theorem environments
for name in ['theorem', 'proposition', 'lemma', 'corollary', 'example', 'remark',
             'question', 'definition']:
    n = len(re.findall(r'\\begin\{%s\}' % name, src))
    if n:
        notes.append('environment %-12s used %d times' % (name, n))

report = dict(file=TEX, bytes=len(src), lines=src.count('\n') + 1,
              labels=len(labels), refs=len(refs), citations=len(keys),
              problems=problems, notes=notes)
open(sys.argv[3] if len(sys.argv) > 3 else 'verify/tex_report.json', 'w').write(
    json.dumps(report, indent=1))
for p in problems:
    print('PROBLEM', p[:200])
print('%d problem(s), %d note(s)' % (len(problems), len(notes)))
sys.exit(1 if problems else 0)
