"""Independent exact arithmetic over prime fields F_q (V19 audit).

Deliberately shares no code with the V18 package (which relies on SymPy).
Polynomials are tuples of ints in [0,q), lowest degree first.
Factorisation uses Cantor-Zassenhaus; only squarefree inputs are required,
which covers x^n - 1 whenever gcd(n,q) = 1.
"""
from __future__ import annotations
import random
from math import gcd as igcd


# ---------------------------------------------------------------- basics
def norm(a, q):
    a = [c % q for c in a]
    while len(a) > 1 and a[-1] == 0:
        a.pop()
    return tuple(a)


def deg(a):
    return -1 if all(c == 0 for c in a) else len(a) - 1


def is_zero(a):
    return all(c == 0 for c in a)


def add(a, b, q):
    n = max(len(a), len(b))
    return norm([(a[i] if i < len(a) else 0) + (b[i] if i < len(b) else 0) for i in range(n)], q)


def sub(a, b, q):
    n = max(len(a), len(b))
    return norm([(a[i] if i < len(a) else 0) - (b[i] if i < len(b) else 0) for i in range(n)], q)


def neg(a, q):
    return norm([-c for c in a], q)


def scalar(c, a, q):
    return norm([c * x for x in a], q)


def mul(a, b, q):
    if is_zero(a) or is_zero(b):
        return (0,)
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        if x:
            for j, y in enumerate(b):
                if y:
                    out[i + j] = (out[i + j] + x * y) % q
    return norm(out, q)


def divmod_poly(a, b, q):
    a = list(norm(a, q))
    b = norm(b, q)
    if is_zero(b):
        raise ZeroDivisionError
    db = len(b) - 1
    inv = pow(b[-1], -1, q)
    bq = list(b)
    quo = [0] * max(1, len(a) - db)
    while len(a) - 1 >= db and any(a):
        d = len(a) - 1 - db
        c = a[-1] * inv % q
        quo[d] = c
        if c:
            for i in range(db + 1):
                a[d + i] = (a[d + i] - c * bq[i]) % q
        while len(a) > 1 and a[-1] == 0:
            a.pop()
    return norm(quo, q), norm(a, q)


def rem(a, b, q):
    return divmod_poly(a, b, q)[1]


def quo(a, b, q):
    return divmod_poly(a, b, q)[0]


def monic(a, q):
    if is_zero(a):
        return (0,)
    inv = pow(a[-1], -1, q)
    return norm([c * inv for c in a], q)


def gcd_poly(a, b, q):
    a, b = norm(a, q), norm(b, q)
    while not is_zero(b):
        a, b = b, rem(a, b, q)
    return monic(a, q) if not is_zero(a) else (0,)


def powmod(base, e, mod, q):
    r = (1,)
    b = rem(base, mod, q)
    while e:
        if e & 1:
            r = rem(mul(r, b, q), mod, q)
        b = rem(mul(b, b, q), mod, q)
        e >>= 1
    return r


def deriv(a, q):
    return norm([(i * a[i]) % q for i in range(1, len(a))], q) if len(a) > 1 else (0,)


def reciprocal(a, q):
    """a*(x) = x^deg(a) a(1/x) (not normalised)."""
    return norm(list(reversed(norm(a, q))), q)


def evaluate(a, x0, q):
    acc = 0
    for c in reversed(a):
        acc = (acc * x0 + c) % q
    return acc


def xpow(e, q):
    out = [0] * (e + 1)
    out[e] = 1
    return tuple(out)


def xn_minus_1(n, q):
    a = [0] * (n + 1)
    a[0] = (q - 1) % q
    a[n] = 1
    return norm(a, q)


def prod(polys, q):
    out = (1,)
    for p in polys:
        out = mul(out, p, q)
    return out


# ------------------------------------------------------- irreducibility
def is_irreducible(f, q):
    f = monic(f, q)
    d = deg(f)
    if d <= 0:
        return False
    if d == 1:
        return True
    x = (0, 1)
    if powmod(x, q ** d, f, q) != rem(x, f, q):
        return False
    for p in prime_factors(d):
        if deg(gcd_poly(sub(powmod(x, q ** (d // p), f, q), x, q), f, q)) > 0:
            return False
    return True


def prime_factors(m):
    out, d = [], 2
    while d * d <= m:
        if m % d == 0:
            out.append(d)
            while m % d == 0:
                m //= d
        d += 1
    if m > 1:
        out.append(m)
    return out


def factorint(m):
    out = {}
    d = 2
    while d * d <= m:
        while m % d == 0:
            out[d] = out.get(d, 0) + 1
            m //= d
        d += 1
    if m > 1:
        out[m] = out.get(m, 0) + 1
    return out


def divisors(m):
    ds = [1]
    for p, e in factorint(m).items():
        ds = [d * p ** i for d in ds for i in range(e + 1)]
    return sorted(ds)


# -------------------------------------------------------- factorisation
def distinct_degree(f, q):
    """Distinct-degree decomposition: [(d, product of irreducibles of degree d)]."""
    out = []
    g = monic(f, q)
    h = (0, 1)
    i = 0
    while deg(g) > 0:
        i += 1
        h = powmod(h, q, g, q)
        d = gcd_poly(sub(h, (0, 1), q), g, q)
        if deg(d) > 0:
            out.append((i, d))
            g = quo(g, d, q)
            if deg(g) == 0:
                break
            h = rem(h, g, q)
        if 2 * i >= deg(g):
            out.append((deg(g), g))
            break
    return out


def equal_degree(poly, d, q, rng):
    """Split a product of distinct irreducibles, all of degree d, into factors."""
    poly = monic(poly, q)
    if deg(poly) == d:
        return [poly]
    exp = (q ** d - 1) // 2
    for _ in range(600):
        a = tuple(rng.randrange(q) for _ in range(deg(poly)))
        if is_zero(a):
            continue
        g = gcd_poly(sub(powmod(a, exp, poly, q), (1,), q), poly, q)
        if 0 < deg(g) < deg(poly):
            return equal_degree(g, d, q, rng) + equal_degree(quo(poly, g, q), d, q, rng)
    raise RuntimeError("EDF failed on %r over F_%d" % (poly, q))


def factor_squarefree(f, q, rng=None):
    """Factor a monic squarefree polynomial over F_q; returns {factor: 1}."""
    rng = rng or random.Random(20261021)
    f = monic(f, q)
    out = {}
    for d, prod in distinct_degree(f, q):
        for p in equal_degree(prod, d, q, rng):
            out[p] = 1
    return out


def factor_xn_minus_1(n, q, rng=None):
    """Irreducible factors of x^n - 1 over F_q (needs gcd(n,q) = 1)."""
    rng = rng or random.Random(20261021)
    f = xn_minus_1(n, q)
    assert deg(gcd_poly(f, deriv(f, q), q)) == 0, "x^n-1 is not squarefree"
    return sorted(factor_squarefree(f, q, rng).items())


# ---------------------------------------------------------------- orders
def ord_x(f, q, n):
    """Order of x modulo f, where f | x^n - 1 and f(0) != 0."""
    f = monic(f, q)
    assert f[0] != 0
    if deg(f) == 0:
        return 1
    e = n
    for p in prime_factors(n):
        while e % p == 0 and is_zero(rem(sub(powmod((0, 1), e // p, f, q), (1,), q), f, q)):
            e //= p
    return e


def ord_of_element(a, q):
    assert a % q != 0
    e = q - 1
    for p in prime_factors(q - 1):
        while e % p == 0 and pow(a, e // p, q) == 1:
            e //= p
    return e


def lcm(a, b):
    return a * b // igcd(a, b)


def lcmm(*xs):
    out = 1
    for x in xs:
        out = lcm(out, x)
    return out
