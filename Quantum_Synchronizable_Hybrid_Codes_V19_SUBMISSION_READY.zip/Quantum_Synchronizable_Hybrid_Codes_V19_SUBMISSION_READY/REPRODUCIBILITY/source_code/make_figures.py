#!/usr/bin/env python3
"""Generate the three figures as plain SVG (no plotting library required)."""
import json, math, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '..', 'manuscript', 'figures')
os.makedirs(OUT, exist_ok=True)

INK = '#1a1a1a'
GREY = '#6b6b6b'
LIGHT = '#d8d8d8'
ACCENT = '#8c2d04'
FONT = 'font-family="New Computer Modern, DejaVu Serif, Georgia, serif"'


def svg_open(w, h):
    return ['<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" '
            'viewBox="0 0 %d %d">' % (w, h, w, h),
            '<rect width="100%%" height="100%%" fill="white"/>' % ()]


def text(x, y, s, size=12, anchor='start', colour=INK, style=''):
    esc = s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    return ('<text x="%.1f" y="%.1f" font-size="%d" %s text-anchor="%s" fill="%s" %s>%s</text>'
            % (x, y, size, FONT, anchor, colour, style, esc))


# ------------------------------------------------------------------ figure 1
def fig_lift(path):
    n, cell, left, top = 5, 46, 54, 96
    w, h = left + n * cell + 30, 250
    out = svg_open(w, h)
    # cell frames
    for t in range(n):
        x = left + t * cell
        out.append('<rect x="%d" y="%d" width="%d" height="%d" fill="none" stroke="%s" '
                   'stroke-width="0.8"/>' % (x, top, cell, cell, LIGHT))
        out.append(text(x + cell / 2, top - 7, 'cell %d' % t, 9, 'middle', GREY))
    # three component rows inside each cell
    labels = ['comp. 1', 'comp. 2', 'comp. 3']
    for t in range(n):
        for i in range(3):
            x = left + t * cell + 8
            y = top + 9 + i * 12
            out.append('<circle cx="%.1f" cy="%.1f" r="3.2" fill="%s"/>' %
                       (x + 6, y, INK if i == 0 else GREY))
            if t == 0:
                out.append(text(left - 10, y + 4, labels[i], 9, 'end', GREY))
    # offset arrow
    y2 = top + cell + 34
    out.append('<path d="M %d %d H %d" stroke="%s" stroke-width="1"/>' %
               (left, y2, left + 2 * cell, ACCENT))
    out.append('<path d="M %d %d l -7 -3.2 v 6.4 z" fill="%s"/>' % (left + 2 * cell, y2, ACCENT))
    out.append(text(left + cell + 6, y2 + 15, 'offset 2 cells', 10, 'middle', ACCENT))
    out.append(text(left, 34, 'n = 5 cells, 3 qudits each, 3n = 15 qudits', 11, 'start', INK))
    out.append('</svg>')
    open(path, 'w').write('\n'.join(out))


# ------------------------------------------------------------------ figure 2
def fig_flow(path):
    w, h = 660, 216
    out = svg_open(w, h)
    boxes = [('nested cyclic\ncode triple', 40, 30), ('interleaved lift\n3n qudits', 200, 30),
             ('marker + padding\nn + a_l + a_r cells', 360, 30),
             ('channel:\noffset by cells', 200, 120),
             ('marker syndrome\n(idealised: exact)', 40, 120),
             ('offset estimate\nand recovery', 360, 120)]
    bw, bh = 130, 52
    for label, x, y in boxes:
        dash = ' stroke-dasharray="4 3"' if 'idealised' in label else ''
        out.append('<rect x="%d" y="%d" width="%d" height="%d" rx="5" fill="none" '
                   'stroke="%s" stroke-width="1"%s/>' % (x, y, bw, bh, INK, dash))
        for k, line in enumerate(label.split('\n')):
            out.append(text(x + bw / 2, y + 21 + k * 14, line, 9.5, 'middle', INK))
    def arrow(x1, y1, x2, y2):
        out.append('<path d="M %d %d L %d %d" stroke="%s" stroke-width="0.9" '
                   'marker-end="url(#a)"/>' % (x1, y1, x2, y2, GREY))
    out.insert(1, '<defs><marker id="a" markerWidth="7" markerHeight="7" refX="6" refY="3.5" '
                  'orient="auto"><path d="M0,0 L7,3.5 L0,7 z" fill="%s"/></marker></defs>' % GREY)
    arrow(172, 56, 198, 56)
    arrow(332, 56, 358, 56)
    arrow(425, 84, 425, 118)
    arrow(358, 146, 332, 146)
    arrow(198, 146, 172, 146)
    arrow(105, 118, 105, 84)
    out.append(text(330, 202, 'dashed step is where assumption (A2) enters', 9, 'middle', GREY))
    out.append('</svg>')
    open(path, 'w').write('\n'.join(out))


# ------------------------------------------------------------------ figure 3
def fig_scatter(path, pts):
    W, H = 380, 330
    L, R, T, B = 62, 18, 26, 54
    pw, ph = W - L - R, H - T - B
    xmax = max(p['bound'] for p in pts) + 1
    ymax = max(p['window'] for p in pts) + 1
    xmax = ymax = max(xmax, ymax)
    def X(v): return L + v / xmax * pw
    def Y(v): return T + ph - v / ymax * ph
    out = svg_open(W, H)
    # axes
    out.append('<path d="M %d %d V %d H %d" fill="none" stroke="%s" stroke-width="1"/>' %
               (L, T + ph, T, L + pw, INK))
    step = 2 if xmax <= 14 else 4
    for v in range(0, xmax + 1, step):
        out.append('<path d="M %d %d v 4" stroke="%s" stroke-width="0.8"/>' % (X(v), T + ph, INK))
        out.append(text(X(v), T + ph + 15, str(v), 8.5, 'middle', GREY))
        out.append('<path d="M %d %d h -4" stroke="%s" stroke-width="0.8"/>' % (L, Y(v), INK))
        out.append(text(L - 7, Y(v) + 3, str(v), 8.5, 'end', GREY))
    # diagonal
    out.append('<path d="M %.1f %.1f L %.1f %.1f" stroke="%s" stroke-width="0.9" '
               'stroke-dasharray="5 4"/>' % (X(0), Y(0), X(xmax), Y(xmax), GREY))
    out.append(text(X(xmax) - 52, Y(xmax) + 22, 'bound = window', 8.5, 'end', GREY))
    for p in pts:
        out.append('<circle cx="%.1f" cy="%.1f" r="2.6" fill="%s" fill-opacity="0.75"/>' %
                   (X(p['bound']), Y(p['window']), INK))
    out.append(text(L + pw / 2, H - 12, 'degree bound deg f \u2212 1 (cells)', 10, 'middle', INK))
    out.append('<g transform="translate(14 %.1f) rotate(-90)">%s</g>' %
               (T + ph / 2, text(0, 0, 'exact window e \u2212 1 (cells)', 10, 'middle', INK)))
    out.append('</svg>')
    open(path, 'w').write('\n'.join(out))


# ------------------------------------------------------------------ figure 4
def fig_relax(path, rows):
    W, H = 430, 250
    L, R, T, B = 48, 16, 20, 46
    pw, ph = W - L - R, H - T - B
    from collections import Counter
    cnt = Counter(int(r['factor']) for r in rows)
    keys = sorted(cnt)
    bw = pw / (len(keys) + 1)
    import math as _m
    hmax = max(cnt.values())
    out = svg_open(W, H)
    out.append('<path d="M %d %d V %d H %d" fill="none" stroke="%s" stroke-width="1"/>' %
               (L, T + ph, T, L + pw, INK))
    for i, k in enumerate(keys):
        v = cnt[k]
        hgt = v / hmax * (ph - 16)
        x = L + (i + 0.6) * bw
        out.append('<rect x="%.1f" y="%.1f" width="%.1f" height="%.1f" fill="%s"/>' %
                   (x, T + ph - hgt, bw * 0.8, hgt, INK))
        out.append(text(x + bw * 0.4, T + ph + 15, str(k), 9, 'middle', GREY))
        out.append(text(x + bw * 0.4, T + ph - hgt - 4, str(v), 8.5, 'middle', GREY))
    out.append(text(L + pw / 2, H - 10, 'relaxation factor n / max m', 10, 'middle', INK))
    out.append('<g transform="translate(13 %.1f) rotate(-90)">%s</g>' %
               (T + ph / 2, text(0, 0, 'pairs', 10, 'middle', INK)))
    out.append('</svg>')
    open(path, 'w').write('\n'.join(out))


def main():
    fig_lift(os.path.join(OUT, 'fig_lift.svg'))
    fig_flow(os.path.join(OUT, 'fig_flow.svg'))
    extra = json.load(open(os.path.join(HERE, '..', 'verify', 'extra_report.json')))
    fig_scatter(os.path.join(OUT, 'fig_scatter.svg'), extra['data']['scatter_q3'])
    full = json.load(open(os.path.join(HERE, '..', 'verify', 'census_report.json')))['relaxation']['all']
    fig_relax(os.path.join(OUT, 'fig_relax.svg'), full)
    print('wrote 4 figures to', os.path.normpath(OUT))


if __name__ == '__main__':
    main()
