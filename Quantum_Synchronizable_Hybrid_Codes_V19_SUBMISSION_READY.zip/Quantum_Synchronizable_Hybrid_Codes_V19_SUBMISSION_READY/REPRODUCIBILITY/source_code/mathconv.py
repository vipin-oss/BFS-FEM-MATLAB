"""Convert the restricted LaTeX math used in the V19 sources into Typst math.

Only constructs that occur in the manuscript are supported; anything else
raises, so a silent mistranslation is impossible.  Two rules matter:

* Typst parses a run of letters as a single identifier, so tokens are joined
  with a space whenever both sides are word-like.
* Attachments bind to the preceding symbol, so no space is inserted before
  `_` or `^`.
"""
import re

GREEK = {
    'alpha': 'alpha', 'beta': 'beta', 'gamma': 'gamma', 'delta': 'delta',
    'Delta': 'Delta', 'epsilon': 'epsilon', 'varepsilon': 'epsilon.alt',
    'zeta': 'zeta', 'eta': 'eta', 'theta': 'theta', 'vartheta': 'theta.alt',
    'iota': 'iota', 'kappa': 'kappa', 'lambda': 'lambda', 'Lambda': 'Lambda',
    'mu': 'mu', 'nu': 'nu', 'xi': 'xi', 'pi': 'pi', 'rho': 'rho',
    'sigma': 'sigma', 'Sigma': 'Sigma', 'tau': 'tau', 'upsilon': 'upsilon',
    'phi': 'phi', 'varphi': 'phi.alt', 'Phi': 'Phi', 'chi': 'chi',
    'psi': 'psi', 'Psi': 'Psi', 'omega': 'omega', 'Omega': 'Omega',
    'Gamma': 'Gamma', 'Theta': 'Theta', 'ell': 'ell',
}

SYMBOLS = {
    'le': '<=', 'leq': '<=', 'ge': '>=', 'geq': '>=', 'ne': '!=', 'neq': '!=',
    'equiv': 'equiv', 'in': 'in', 'notin': 'in.not', 'subseteq': 'subset.eq',
    'subset': 'subset', 'subsetneq': 'subset.neq', 'supset': 'supset',
    'supseteq': 'supset.eq', 'cap': '\u2229', 'cup': '\u222a',
    'oplus': '\u2295', 'otimes': '\u2297', 'cdot': 'dot',
    'times': 'times', 'pm': 'plus.minus', 'to': 'arrow.r',
    'rightarrow': 'arrow.r', 'mapsto': 'arrow.r.bar',
    'Rightarrow': 'arrow.r.double', 'iff': 'arrow.l.r.double.long',
    'langle': '\u27e8', 'rangle': '\u27e9',
    'angle': '\u2220', 'lhd': 'triangle.stroked.l', 'rhd': 'triangle.stroked.r', 'lvert': '|', 'rvert': '|',
    'vert': '|', 'mid': '|', 'setminus': 'without', 'perp': 'perp',
    'sim': 'tilde.op', 'approx': 'approx', 'll': '<<', 'gg': '>>',
    'infty': 'infinity', 'ldots': 'dots', 'dots': 'dots', 'cdots': 'dots',
    'prime': 'prime', 'forall': 'forall', 'exists': 'exists',
    'lfloor': 'floor.l', 'rfloor': 'floor.r', 'lceil': 'ceil.l',
    'rceil': 'ceil.r', 'circ': 'compose', 'star': 'star', 'ast': '*',
    'dagger': 'dagger', 'quad': '#h(1.2em)', 'qquad': '#h(2.2em)',
    'ell': 'ell', 'Vert': '\u2016', 'lVert': '\u2016',
    'rVert': '\u2016', 'partial': '\u2202', 'nabla': '\u2207', 'top': 'top',
    'ldots': 'dots', 'square': 'square', 'blacksquare': 'blacksquare',
    'varepsilon': 'epsilon.alt', 'leqq': '<=', 'geqq': '>=',
    'nmid': '\u2224', 'bigcirc': 'circle.stroked.small',
    'Leftarrow': 'arrow.l.double', 'impliedby': 'arrow.l.double',
    'longleftarrow': 'arrow.l.long', 'leftrightarrow': 'arrow.l.r',
    'Leftrightarrow': 'arrow.l.r.double', 'gets': 'arrow.l',
    'vDash': 'models', 'models': 'models', 'vdash': 'tack.r', 'vdash': 'tack.r',
    'sqsubseteq': 'subset.eq.sq', 'sqsupseteq': 'supset.eq.sq',
    'triangle': 'triangle.stroked.t', 'triangleq': 'triangle.eq',
    'cong': 'tilde.equiv', 'simeq': 'tilde.eq', 'propto': 'prop',
    'lnsim': 'lt.double', 'Rightarrow': 'arrow.r.double',
    'longrightarrow': 'arrow.r.long', 'longleftrightarrow': 'arrow.l.r.long',
    'subseteqq': 'subset.eq', 'vartriangleleft': 'triangle.stroked.l',
    'varnothing': 'emptyset', 'emptyset': 'emptyset', 'setminus': 'without',
    'and': 'and', 'or': 'or', 'neg': 'not', 'square': 'square',
    'checkmark': 'checkmark', 'bullet': 'bullet', 'cdots': 'dots',
    'imath': 'dotless.i', 'jmath': 'dotless.j', 'hbar': '\u210f',
    'rho': 'rho', 'varrho': 'rho.alt', 'sigma': 'sigma', 'varsigma': 'sigma.alt',
    'ni': 'in.rev', 'owns': 'in.rev', 'aleph': 'aleph', 'wp': 'wp',
    'Re': 'Re', 'Im': 'Im', 'partial': 'diff', 'infty': 'infinity',
    'rightarrowtail': 'arrow.r.tail', 'twoheadrightarrow': 'arrow.r.twohead',
    'nearrow': 'arrow.r.ne', 'searrow': 'arrow.r.se', 'swarrow': 'arrow.l.sw',
    'nwarrow': 'arrow.l.nw', 'rightsquigarrow': 'arrow.r.squiggly',
}

FUNCS = {
    'ord': 'ord', 'wt': 'wt', 'lcm': 'lcm', 'gcd': 'gcd', 'deg': 'deg',
    'min': 'min', 'max': 'max', 'log': 'log', 'ln': 'ln', 'exp': 'exp',
    'dim': 'dim', 'ker': 'ker', 'rank': 'rank', 'supp': 'supp', 'tr': 'tr',
    'det': 'det', 'lim': 'lim', 'Pr': 'Pr', 'sin': 'sin', 'cos': 'cos',
}

BIGOPS = {'sum': 'sum', 'prod': 'product', 'int': 'integral',
          'bigoplus': '\u2295', 'bigotimes': '\u2297',
          'bigcup': '\u22c3', 'bigcap': '\u22c2', 'coprod': '\u2a3f'}

SPACED_OPS = {'!=', '<=', '>=', '<<', '>>', '->', '|->', 'equiv', 'approx',
              'in', 'perp', 'without', '|', '*', 'compose', 'subset', 'subset.eq',
              'subset.neq', 'supset', 'supset.eq', 'sect', 'union', 'plus.circle',
              'times.circle', 'dot', 'times', 'plus.minus', 'arrow.r', 'arrow.r.double',
              'arrow.l.r.double.long', 'tilde.op', 'in.not', 'bar.v.not', 'prime'}

SPACES = {',': 'thin', ';': 'med', '!': '', ' ': ' ', 'quad': 'quad'}


MACROS = {
    '\\F': '\\mathbb{F}', '\\Z': '\\mathbb{Z}', '\\M': '\\mathcal{M}',
    '\\Q': '\\mathbb{Q}', '\\C': '\\mathbb{C}', '\\R': '\\mathbb{R}',
    '\\wt': '\\operatorname{wt}', '\\ord': '\\operatorname{ord}',
    '\\lcm': '\\operatorname{lcm}',
}


def expand(s):
    """Expand the paper's macros into standard LaTeX (used by the Typst path)."""
    for k, v in MACROS.items():
        s = re.sub(re.escape(k) + r'(?![A-Za-z])', v.replace('\\', '\\\\'), s)
    # \gen{...} -> \langle ... \rangle
    while '\\gen{' in s:
        i = s.index('\\gen{')
        depth, j = 1, i + 5
        while j < len(s) and depth:
            if s[j] == '{':
                depth += 1
            elif s[j] == '}':
                depth -= 1
            j += 1
        inner = s[i + 5:j - 1]
        s = s[:i] + '\\langle ' + inner + '\\rangle ' + s[j:]
    return s


def split_top(s, sep):
    out, depth, cur, i = [], 0, [], 0
    while i < len(s):
        ch = s[i]
        if ch == '\\' and i + 1 < len(s):
            cur.append(s[i:i + 2]); i += 2; continue
        if ch == '{':
            depth += 1
        elif ch == '}':
            depth -= 1
        if s.startswith(sep, i) and depth == 0:
            out.append(''.join(cur)); cur = []; i += len(sep); continue
        cur.append(ch); i += 1
    out.append(''.join(cur))
    return out


def group_at(s, i):
    while i < len(s) and s[i] == ' ':
        i += 1
    if i >= len(s):
        return '', i
    if s[i] == '{':
        depth, j = 1, i + 1
        while j < len(s) and depth:
            if s[j] == '\\':
                j += 2; continue
            if s[j] == '{':
                depth += 1
            elif s[j] == '}':
                depth -= 1
            j += 1
        return s[i + 1:j - 1], j
    if s[i] == '\\':
        j = i + 1
        while j < len(s) and s[j].isalpha():
            j += 1
        return s[i:j], j
    return s[i], i + 1


def _join(tokens):
    """Join (text, wordlike) tokens, inserting spaces between word-like pairs."""
    out = []
    prev_word = False
    for txt, word in tokens:
        if not txt:
            continue
        if out and word and prev_word and not txt.startswith(('_', '^', ')', ']', ',')):
            out.append(' ')
        elif out and word and prev_word and txt[0].isalnum():
            out.append(' ')
        out.append(txt)
        prev_word = txt[-1].isalnum() or txt[-1] in ')]'
    return ''.join(out)


def conv(s):
    toks = []
    i, n = 0, len(s)
    while i < n:
        c = s[i]
        if c == '\\':
            j = i + 1
            while j < n and s[j].isalpha():
                j += 1
            name = s[i + 1:j]
            if name == '':
                esc = s[j] if j < n else ''
                if esc in SPACES:
                    toks.append(('#h(0.17em)' if SPACES[esc] == 'thin' else
                                 '#h(0.25em)' if SPACES[esc] == 'med' else '', False))
                elif esc in '{}':
                    toks.append(('\\' + esc, False))
                elif esc in '&%_':
                    toks.append((esc, False))
                elif esc == '#':
                    toks.append(('\\#', False))
                elif esc == '|':
                    toks.append(('\u2016', False))
                elif esc == '\\':
                    toks.append(('\\', False))
                else:
                    toks.append((esc, False))
                i = j + 1
                continue
            if name in GREEK:
                toks.append((GREEK[name], True)); i = j; continue
            if name in ('mathbb', 'mathcal', 'mathrm', 'mathbf', 'mathsf', 'mathit'):
                arg, i = group_at(s, j)
                fn = {'mathbb': 'bb', 'mathcal': 'cal', 'mathrm': 'upright',
                      'mathbf': 'bold', 'mathsf': 'sans', 'mathit': 'italic'}[name]
                inner = conv(arg)
                if arg.isalpha() and len(arg) > 1:
                    inner = '"%s"' % arg
                toks.append(('%s(%s)' % (fn, inner), True)); continue
            if name == 'operatorname':
                arg, i = group_at(s, j)
                toks.append(('op("%s")' % arg, True)); continue
            if name in ('text', 'textrm', 'textit', 'mbox', 'textnormal'):
                arg, i = group_at(s, j)
                toks.append(('"%s"' % arg.replace('"', '\\"'), True)); continue
            if name in ('frac', 'dfrac', 'tfrac'):
                a, i = group_at(s, j)
                b, i = group_at(s, i)
                toks.append(('frac(%s, %s)' % (conv(a), conv(b)), True)); continue
            if name == 'binom':
                a, i = group_at(s, j)
                b, i = group_at(s, i)
                toks.append(('binom(%s, %s)' % (conv(a), conv(b)), True)); continue
            if name == 'sqrt':
                a, i = group_at(s, j)
                toks.append(('sqrt(%s)' % conv(a), True)); continue
            if name in ('overline', 'bar'):
                a, i = group_at(s, j)
                toks.append(('overline(%s)' % conv(a), True)); continue
            if name in ('hat', 'widehat'):
                a, i = group_at(s, j)
                toks.append(('hat(%s)' % conv(a), True)); continue
            if name in ('not', 'lnot'):
                # \not\subseteq and friends have proper negated glyphs in Typst;
                # a bare 'not' would render as a separate negation sign.
                m = re.match(r'\s*\\(subseteq|subset|in|equiv)(?![A-Za-z])', s[j:])
                if m:
                    neg = {'subseteq': 'subset.eq.not', 'subset': 'subset.not',
                           'in': 'in.not', 'equiv': 'equiv.not'}[m.group(1)]
                    toks.append((neg + ' ', True)); i = j + m.end(); continue
                toks.append((' not ', False)); i = j; continue
            if name == 'colon':
                toks.append(('#":"', False)); i = j; continue
            if name in ('pmod', 'bmod'):
                a, i = group_at(s, j)
                toks.append(('(op("mod") %s)' % conv(a), True)); continue
            if name in ('left', 'right', 'bigl', 'bigr', 'Bigl', 'Bigr', 'big',
                        'Big', 'displaystyle', 'textstyle', 'limits', 'nolimits',
                        'mathstrut'):
                i = j
                if name in ('left', 'right'):
                    while i < n and s[i] == ' ':
                        i += 1
                    if i < n:
                        d = s[i]
                        if d == '\\' and i + 1 < n and s[i + 1] in '{}':
                            toks.append(('\\' + s[i + 1], False)); i += 2; continue
                        if d == '.' and name == 'right':
                            i += 1; continue
                        toks.append((d, False)); i += 1
                continue
            if name in SYMBOLS:
                val = SYMBOLS[name]
                if val in SPACED_OPS:
                    toks.append((' ' + val + ' ', False))
                else:
                    toks.append((val, val[0].isalpha()))
                i = j; continue
            if name in FUNCS:
                toks.append(('op("%s")' % FUNCS[name], True)); i = j; continue
            if name in BIGOPS:
                toks.append((BIGOPS[name], True)); i = j; continue
            raise ValueError('unsupported LaTeX command \\%s in %r' % (name, s))
        if c in '^_':
            arg, i = group_at(s, i + 1)
            toks.append((c + '(' + conv(arg) + ')', False))
            continue
        if c == '{':
            arg, i = group_at(s, i)
            toks.append(('(' + conv(arg) + ')', False))
            continue
        if c == '|':
            toks.append(('|', False)); i += 1; continue
        if c == ':':
            toks.append(('#":"', False)); i += 1; continue
        if c == '/':
            toks.append((' slash ', False)); i += 1; continue
        if c == '~':
            toks.append((' ', False)); i += 1; continue
        if c.isalpha():
            # In LaTeX each letter is a separate variable; Typst would read a
            # run of letters as one identifier, so the letters are separated.
            k = i
            while k < n and s[k].isalpha():
                k += 1
            run = s[i:k]
            toks.append(('#h(0em)'.join(run) if len(run) > 1 else run, True))
            i = k; continue
        if c.isdigit():
            k = i
            while k < n and (s[k].isdigit() or (s[k] == '.' and k + 1 < n and s[k + 1].isdigit())):
                k += 1
            toks.append((s[i:k], False)); i = k; continue
        toks.append((c, False)); i += 1
    return _join(toks)


def _tidy(txt):
    """Collapse whitespace outside string literals; drop spaces inside parens."""
    out, buf, i = [], [], 0
    pieces = re.split(r'("(?:[^"\\]|\\.)*")', txt)
    for k, piece in enumerate(pieces):
        if k % 2 == 1:                 # string literal: keep verbatim
            buf.append(piece)
        else:
            p = re.sub(r'[ \t]{2,}', ' ', piece)
            p = re.sub(r'\(\s+', '(', p)
            p = re.sub(r'\s+\)', ')', p)
            buf.append(p)
    return ''.join(buf).strip()


def convert(s):
    return _tidy(conv(expand(s)))
