#!/usr/bin/env python3
"""Single entry point for the reproducibility tests of V19.

Runs every audit suite in a scratch copy of the source directory, collects the
pass/fail counts and the wall-clock times, and writes test_results.json.
Nothing here writes into the packaged tree.

Usage:  python3 test_all.py [--package ROOT] [--out DIR]

A fresh run writes its reports to REPRODUCIBILITY/run_output/ so that the
reports shipped in REPRODUCIBILITY/generated_data/ stay byte-identical and the
package's SHA256SUMS.txt remains valid after verification.
"""
from __future__ import annotations
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_ROOT = os.path.dirname(HERE)                 # .../REPRODUCIBILITY
PACKAGE = os.path.dirname(DEFAULT_ROOT)              # .../Quantum_..._V19
for i, a in enumerate(sys.argv):
    if a == '--package' and i + 1 < len(sys.argv):
        PACKAGE = os.path.abspath(sys.argv[i + 1])

SRC = os.path.join(DEFAULT_ROOT, 'source_code')
if not os.path.isdir(SRC):
    SRC = os.path.join(PACKAGE, 'REPRODUCIBILITY', 'source_code')
DATA = os.path.join(DEFAULT_ROOT, 'generated_data')      # shipped reports, never overwritten
OUT = os.path.join(DEFAULT_ROOT, 'run_output')            # default destination for a fresh run
for i, a in enumerate(sys.argv):
    if a == '--out' and i + 1 < len(sys.argv):
        OUT = os.path.abspath(sys.argv[i + 1])
os.makedirs(OUT, exist_ok=True)

SUITES = [
    ('core', 'audit_core.py', 'core_report.json'),
    ('census', 'audit_census.py', 'census_report.json'),
    ('extra', 'audit_extra.py', 'extra_report.json'),
]

results = dict(generated=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
               python=sys.version.split()[0], suites=[], failures=[])

work = tempfile.mkdtemp(prefix='v19tests.')
try:
    for f in os.listdir(SRC):
        if f.endswith('.py'):
            shutil.copy(os.path.join(SRC, f), work)
    for name, script, report in SUITES:
        path = os.path.join(work, script)
        if not os.path.exists(path):
            results['failures'].append('%s missing' % script)
            results['suites'].append(dict(name=name, script=script, status='MISSING'))
            continue
        t0 = time.time()
        p = subprocess.run([sys.executable, '-u', script], cwd=work,
                           capture_output=True, text=True)
        dt = time.time() - t0
        out = p.stdout.strip().split('\n')
        summary = next((l for l in reversed(out) if 'passed' in l), '')
        status = 'PASS' if p.returncode == 0 else 'FAIL'
        entry = dict(name=name, script=script, status=status, seconds=round(dt, 2),
                     summary=summary.strip(), returncode=p.returncode)
        # copy the JSON report next to the others
        rp = os.path.join(work, report)
        if os.path.exists(rp):
            shutil.copy(rp, os.path.join(OUT, report))
            entry['report'] = report
            try:
                j = json.load(open(rp))
                if 'checks' in j:
                    entry['checks_total'] = len(j['checks'])
                    entry['checks_passed'] = sum(1 for c in j['checks'] if c['passed'])
                if 'census' in j:
                    entry['branches'] = j['census']['total']['branches']
                    entry['pairs'] = j['census']['total']['pairs']
            except Exception as e:
                entry['report_error'] = str(e)[:120]
        if status != 'PASS':
            results['failures'].append('%s exited with %d: %s'
                                       % (script, p.returncode, (p.stderr or '')[-400:]))
        results['suites'].append(entry)
        print('%-8s %-18s %-5s %6.2fs  %s' % (name, script, status, dt, entry['summary']))

    # structural check of the generated LaTeX, if present
    tex = os.path.join(PACKAGE, 'MANUSCRIPT', 'Main_Manuscript.tex')
    bib = os.path.join(PACKAGE, 'MANUSCRIPT', 'References.bib')
    checker = os.path.join(work, 'check_tex.py')
    if os.path.exists(tex) and os.path.exists(checker):
        p = subprocess.run([sys.executable, checker, tex, bib,
                            os.path.join(OUT, 'tex_report.json')],
                           cwd=work, capture_output=True, text=True)
        results['suites'].append(dict(name='latex', script='check_tex.py',
                                      status='PASS' if p.returncode == 0 else 'FAIL',
                                      summary=p.stdout.strip().split('\n')[-1]))
        print('%-8s %-18s %-5s %s' % ('latex', 'check_tex.py',
                                      'PASS' if p.returncode == 0 else 'FAIL',
                                      p.stdout.strip().split('\n')[-1]))
        if p.returncode != 0:
            results['failures'].append('check_tex.py reported problems')
finally:
    shutil.rmtree(work, ignore_errors=True)

results['overall'] = 'PASS' if not results['failures'] else 'FAIL'
out = os.path.join(OUT, 'test_results.json')
json.dump(results, open(out, 'w'), indent=1)
print('\noverall:', results['overall'], '->', out)
sys.exit(0 if results['overall'] == 'PASS' else 1)
