# Frozen V18 programs

These three files are the V18 programs, copied unchanged for provenance:

* `branch_census.py` — V18 census, writes `branch_census_output.json`
* `independent_checks.py` — V18 SymPy-based checks
* `review_table_verification.py` — V18 table regeneration

They are **not** part of the V19 pass/fail totals and are **not** used by `REPRODUCIBILITY/tests/test_all.py`. The V19 audit code in the parent directory re-derives the same results with its own arithmetic and shares no routine with these files.

They were run once during this audit and reproduced the published counts (20,724 branches; 81 pairs; 118 relaxation pairs; 38 with factor $>1$; 27 proper-$D$ pairs; flagship window 12). Running them requires SymPy 1.14.

They are retained because a comparison between two independent implementations is evidence, and a reader should be able to repeat that comparison. They are excluded from the totals because a test suite that reuses the code under test is not a test.

The V18 package also contains a Magma directory (`supporting_programs/magma/`) that was not executed for lack of an interpreter, and one unit test that imports a module absent from V18. Neither is reproduced here; both are recorded in `AUDIT/08_Issues_Register.md` as I-15 and I-16.
