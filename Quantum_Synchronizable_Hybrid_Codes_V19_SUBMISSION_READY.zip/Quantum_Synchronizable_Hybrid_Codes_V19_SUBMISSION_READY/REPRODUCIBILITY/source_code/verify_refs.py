#!/usr/bin/env python3
"""Verify bibliographic metadata through the Crossref REST API.

Only entries whose DOI resolves in Crossref are accepted into References.bib.
Everything else is reported as UNVERIFIED so it can be removed or flagged.
"""
import os
import json, sys, time, urllib.parse, urllib.request, urllib.error

DOIS = [
    '10.1103/PhysRevA.87.022344',
    '10.1103/PhysRevA.88.012318',
    '10.1109/TIT.2014.2357029',
    '10.1109/LCOMM.2015.2512261',
    '10.1109/TIT.2018.2795479',
    '10.1007/s11128-019-2389-0',
    '10.1007/s11128-022-03794-1',
    '10.1007/s40314-023-02298-7',
    '10.1007/s11128-021-03058-4',
    '10.1007/s11128-022-03625-3',
    '10.1007/s11128-023-04248-y',
    '10.1016/j.disc.2020.112189',
    '10.1109/TQE.2026.3673092',
    '10.1016/S0019-9958(64)90438-3',
    '10.1016/0012-365X(94)90283-6',
    '10.1007/s10773-022-05163-1',
    '10.1142/S0219498821500031',
    '10.1007/s12190-016-1042-7',
    '10.1109/LCOMM.2018.2877989',
    '10.1109/ACCESS.2019.2963289',
    '10.1007/s12095-021-00501-2',
    '10.1007/s12190-022-01811-1',
    '10.1103/PhysRevA.54.1862',
    '10.1103/PhysRevLett.77.793',
    '10.1098/rspa.1996.0130',
    '10.1007/s11128-019-2384-5',
    '10.1007/s12190-018-01230-1',
    '10.1016/j.ffa.2016.06.007',
    '10.1109/TIT.2004.831789',
    '10.1109/ACCESS.2020.3006001',
    '10.1007/s11128-023-03958-7',
    '10.1007/s11128-021-03306-7',
    '10.1007/s11128-025-04666-0',
    '10.1007/s12190-020-01407-7',
    '10.3390/axioms12040367',
    '10.1103/PhysRevA.87.032321',
]

OUT = {}
for doi in DOIS:
    url = 'https://api.crossref.org/works/' + urllib.parse.quote(doi)
    try:
        with urllib.request.urlopen(url, timeout=25) as f:
            m = json.load(f)['message']
    except Exception as e:
        OUT[doi] = dict(status='ERROR', error=str(e)[:120])
        print('ERROR', doi, str(e)[:80], flush=True)
        continue
    authors = ['%s, %s' % (a.get('family', ''), a.get('given', ''))
               for a in m.get('author', [])]
    OUT[doi] = dict(status='OK',
                    title=(m.get('title') or [''])[0],
                    author=authors,
                    journal=(m.get('container-title') or [''])[0],
                    volume=m.get('volume', ''),
                    issue=m.get('issue', ''),
                    page=m.get('page', ''),
                    article_number=m.get('article-number', ''),
                    year=(m.get('issued', {}).get('date-parts', [[None]])[0][0]),
                    doi=m.get('DOI'))
    r = OUT[doi]
    print('OK   %-32s %s | %s %s(%s) %s %s' % (
        doi, r['title'][:58], r['journal'][:34], r['volume'], r['issue'], r['page'], r['year']),
        flush=True)
    time.sleep(0.15)

json.dump(OUT, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'crossref_report.json'), 'w'), indent=1)
print('\nverified %d / %d' % (sum(1 for v in OUT.values() if v['status'] == 'OK'), len(DOIS)))
