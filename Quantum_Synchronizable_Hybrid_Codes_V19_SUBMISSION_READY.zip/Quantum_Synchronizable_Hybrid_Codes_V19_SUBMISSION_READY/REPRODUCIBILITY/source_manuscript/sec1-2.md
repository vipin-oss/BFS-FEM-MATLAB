@title Synchronizable Hybrid Codes from Cyclic Codes over $\F_q[v]/(v^3-v)$: Exact Misalignment Thresholds and the Limits of Component Fusion
@shorttitle Quantum Synchronizable Hybrid Codes
@author Arun Kumar Yadav
@affiliation School of Basic and Applied Sciences, K. R. Mangalam University, Gurugram 122103, India
@email arunyadav0317@gmail.com
@msc 81P73, 94B15, 11T71
@keywords quantum synchronizable codes; hybrid quantum-classical codes; cyclic codes over finite rings; idempotent decomposition; block misalignment; order of a polynomial
@abstract We study synchronizable hybrid codes built from cyclic codes over the reduced ring $R=\F_q[v]/(v^3-v)$, where $q$ is an odd prime and $\gcd(n,q)=1$. The Chinese remainder theorem gives $R\cong\F_q^3$, so a cyclic code over $R$ is a triple of cyclic codes over $\F_q$, and an interleaved lift places the three components on $3n$ qudits grouped into $n$ cells of three qudits. A block misalignment is a shift by a whole number of cells. Within an idealised model in which the marker syndrome is observed exactly, we prove that the collision differences of a component are precisely the multiples of $e=\ord_x(f)$, where $f$ is the quotient of the two generator polynomials, so the largest tolerable misalignment is $e-1$ cells; the known sufficient condition $a_l+a_r<e$ is therefore also necessary. For every dual-containing branch we show $\deg f\le e-1$, so the degree-type bound $\deg f-1$ is never sharp and can be arbitrarily far from the exact value. Three components fuse with period $\lcm(e_1,e_2,e_3)$, but the largest attainable period is $n$, already attained by a single component: fusion cannot enlarge the window, although it does allow the window to be sustained by components whose individual periods are small. When the marker carries classical symbols we give an exact collision criterion, prove that a collision at difference $\delta$ forces $|\delta|+y\ge\deg f$, and show that the window can be held by one component while the others transmit messages. A ternary example with underlying hybrid parameters $[[39,3:9,0,3]]_3$ transmits four ternary marker symbols over a twelve-cell window at a padded length of $75$ qudits. All numerical statements were re-derived by an independent exact-arithmetic implementation, including an exhaustive census of $20\,724$ dual-containing branches. No claim is made about noisy syndrome extraction.
@body

# Introduction

Quantum error-correcting codes protect encoded information against Pauli errors on the physical carriers; the stabilizer construction that underlies everything below is the CSS construction of Calderbank and Shor [@CalderbankShor1996] and Steane [@Steane1996], and the simultaneous transmission of quantum and classical information in one block goes back to the operator-algebra framework of Kribs, Laflamme and Poulin [@KribsLaflammePoulin2005]. In a stream of encoded blocks they do not, by themselves, protect the receiver's knowledge of where each block begins. A frame displaced by a few positions causes the decoder to act on the wrong subset of carriers, and the resulting error is not a Pauli error of the encoded block but a mismatch between the physical positions and the coordinates the decoder assumes. Classical synchronizable codes address this problem with markers or comma-free constructions, an approach that goes back to Bose and Caldwell [@BoseCaldwell1967]. Such schemes rely on inspecting individual symbols, which is not directly possible for quantum data because measurement collapses the encoded state unless the measurement commutes with the encoded algebra; the synchronizable construction arranges precisely that, at the price of a marker that is measured only in a syndrome.

Fujiwara introduced quantum synchronizable codes (QSCs), in which recovery from block misalignment is built into the code algebra rather than obtained by inspecting the encoded state [@Fujiwara2013]. The construction starts from two classical cyclic codes $\mathcal C\subseteq\mathcal D$ of length $n$ over $\F_q$ with $\mathcal C^\perp\subseteq\mathcal C$, and uses the nested pair to attach a marker coset to a CSS-type code; the marker is measured only in the syndrome of $\mathcal C$, which leaves the encoded quantum information undisturbed. The magnitude of the tolerable misalignment is governed by the multiplicative order of the quotient polynomial $f=g_{\mathcal C}/g_{\mathcal D}$. Fujiwara's original sufficient condition $a_l+a_r<k_{\mathcal D}-k_{\mathcal C}$ was refined by Fujiwara, Tonchev and Wong to the order condition $a_l+a_r<\ord_x(f)$ [@FujiwaraTonchevWong2013], which is the form used in essentially all later constructions: quadratic residue codes and their supercodes [@XieYuanFujiwara2014], finite geometries [@FujiwaraVandendriessche2014], cyclotomic classes [@LiZhuLiu2019;@ShiYueHuang2021;@LiZhu2022], chain-containing $q$-ary codes [@XieYangYuan2016], repeated-root and quasi-cyclic families [@LuoMa2018;@DuMaLiu2023], the $\lambda(u+v)|u-v$ construction [@DuMaLuoWang2020], and further families with explicit distance or two new classes [@LuoMaLin2019;@LiuKai2023] and BCH-type families [@SunEtAl2023]. Guenda, La Guardia and Gulliver gave an algebraic account of the framework [@GuendaEtAl2017].

Two extensions of the basic problem are relevant here. The first replaces the field by a finite ring. Several authors have constructed QSCs from cyclic or constacyclic codes over rings, using Euclidean sums, chain rings, or rings of the form $\F_q+u\F_q$ [@LiuLiu2021;@DaiLiu2022;@LiuHuLiu2024]. Independently, the coding-theory literature has made extensive use of decomposable rings such as $\F_p[u]/(u^{k+1}-u)$ to build quantum codes from cyclic codes, with the Chinese remainder theorem reducing the problem to several field components [@DinhEtAl2021;@DinhBagUpadhyay2021]. The second extension adds a classical message: hybrid quantum-classical codes carry quantum and classical information simultaneously, and Tansuwannont and Nemec have recently unified synchronizable codes, hybrid codes and subsystem codes, proving trade-offs between the number of correctable misalignments, the number of gauge qudits and the number of classical symbols [@TansuwannontNemec2026].

This paper sits at the intersection of these two lines. We take the reduced ring $R=\F_q[v]/(v^3-v)$ with $q$ odd, so that $R\cong\F_q^3$ through three explicit primitive idempotents. A cyclic code over $R$ is then a triple $(\mathcal C_1,\mathcal C_2,\mathcal C_3)$ of cyclic codes over $\F_q$, and a chain $\mathcal C^\perp\subseteq\mathcal C\subseteq\mathcal D$ over $R$ is the same thing as three chains over $\F_q$. Placing the three components on disjoint coordinates of a block of $3n$ qudits, grouped into $n$ cells of three qudits, produces a hybrid code whose parameters are read off from the components. Because the three components share one physical frame, they also share one misalignment, which is measured in cells. This is the sense in which the ring is used: not as a source of new synchronization phenomena, but as a device that packages three synchronized components, with independent marker parameters, into a single block.

Our analysis is deliberately confined to an idealised observation model in which the marker syndrome is known exactly, either because the channel is noiseless or because the physical errors have already been corrected. Within that model the synchronization problem becomes a purely algebraic question about the map from the offset to the observed syndrome, and we answer it completely for a single component: the offsets that cannot be distinguished are exactly the multiples of $e=\ord_x(f)$, so the window is $e-1$ and the classical sufficient condition is also necessary. This much is implicit in the order-based literature, where $\ord_x(f)$ appears as a sufficient bound; making the converse explicit is what allows the subsequent comparison of designs, and we use it to settle three questions that the sufficient condition alone cannot answer.

First, how much is lost by the degree-type condition $a_l+a_r<\deg f$? For dual-containing branches nothing is gained by it, because dual containment forces $\deg f\le e-1$; the gap between the two criteria is therefore at least one cell for every branch and can be made arbitrarily large by taking $f$ to be an irreducible factor of a cyclotomic polynomial $\Phi_m$ with $m/\ord_m(q)$ large. This is a statement about the sharpness of a widely used bound, not a new construction.

Second, does using three components enlarge the attainable window? It does not. Since $e\mid n$ for every branch, the fused period $\lcm(e_1,e_2,e_3)$ never exceeds $n$, and a single component already attains $n$ whenever a nontrivial dual-containing branch exists. What fusion provides is a relaxation: a window of $n-1$ cells can be sustained by three components whose individual periods are far below $n$, which matters when no single branch of the required length is available or when the per-component code parameters must be kept small. We quantify this relaxation over a finite range and show that the relaxation factor is unbounded in general, at the price of a poor $X$-distance.

Third, how do classical messages interact with synchronization? Encoding a message in the marker residue restricts the set of admissible residues, and a collision then occurs exactly when a shifted residue lands back in the message family. We characterise this criterion exactly, prove the bound $|\delta|+y\ge\deg f$ that relates the collision distance $\delta$, the marker degree $y$ and the code parameter $\deg f$, and show that the work can be divided among the components: one component can hold the frame with an empty message while the others transmit. In the ternary example of Section 5.4 this yields four classical symbols over a twelve-cell window, out of the nine symbol slots that the underlying hybrid code offers.

The paper is organised as follows. Section 2 develops the algebra of $R$ and of cyclic codes over $R$, including the dual-containment criterion and the existence question for branches. Section 3 describes the interleaved construction, its parameters and its distance, and fixes the observation model. Section 4 proves the exact threshold for a single component, compares it with the degree bound, and analyses fusion. Section 5 treats message-carrying markers and the allocation of synchronization and message capacity. Section 6 reports the computational verification, Section 7 discusses limitations and Section 8 concludes. Appendix A records the sign convention in the collision criterion, and Appendix B extends the threshold theorem to marker residues that are not coprime to $f$.

A note on what is and is not claimed. The synchronization results are theorems about an idealised model with exact syndromes and offsets by whole cells; they say nothing about noisy syndrome extraction, about the propagation of physical errors into the offset estimate, or about fault-tolerant decoding. The distance statements are combinatorial and refer to the hybrid code's minimum distance in the usual sense. No claim of optimality is made for any construction: the thresholds are exact for the codes considered, but the codes themselves are not claimed to be optimal in any parameter regime.

# The coefficient ring and its cyclic codes

Throughout, $q$ is an odd prime, $n\ge2$ satisfies $\gcd(n,q)=1$, and
$$ R=\F_q[v]/(v^3-v). $$ {#eq:ring}
For a polynomial $a$ of degree $d$ with $a(0)\neq0$ we write $a^*(x)=x^{d}a(1/x)$ for its reciprocal and call $a$ self-reciprocal when $a^*$ is a scalar multiple of $a$. All codes in this section have length $n$ and are cyclic.

## The idempotent decomposition

::: proposition ring
The polynomial $v^3-v=v(v-1)(v+1)$ has three distinct roots in $\F_q$, so the Chinese remainder theorem gives an isomorphism of $\F_q$-algebras $R\cong\F_q\times\F_q\times\F_q$. The corresponding primitive idempotents are
$$ \eta_1=1-v^2,\qquad \eta_2=\tfrac12(v^2+v),\qquad \eta_3=\tfrac12(v^2-v), $$ {#eq:idem}
and they satisfy $\eta_i^2=\eta_i$, $\eta_i\eta_j=0$ for $i\neq j$, $\eta_1+\eta_2+\eta_3=1$ and $v=\eta_2-\eta_3$. Every $r\in R$ has a unique expression $r=r_1\eta_1+r_2\eta_2+r_3\eta_3$ with $r_i\in\F_q$.
:::

::: remark char
The hypothesis that $q$ is odd is essential for the formula @eq:idem, not for the decomposition as such. Over $\F_2$ one has $v^3-v=v(v+1)^2$, the ring is not reduced, and $\tfrac12(v^2\pm v)$ is undefined. Nothing in Sections 2--5 uses primality of $q$; the restriction to prime fields is made because the enumerations of Section 6 were carried out over prime fields. The case $q=3$ is included, with $\tfrac12=2$: then $\eta_2=2v^2+2v$ and $\eta_3=2v^2+v$, and indeed $\eta_2+\eta_3=v^2$ and $\eta_2-\eta_3=v$.
:::

A cyclic code of length $n$ over $R$ is an ideal of $R[x]/(x^n-1)$. Since $R[x]/(x^n-1)\cong\bigoplus_{i=1}^{3}\F_q[x]/(x^n-1)$, every such ideal has the form
$$ C=\eta_1C_1\oplus\eta_2C_2\oplus\eta_3C_3,\qquad C_i=\gen{g_i}\subseteq\F_q[x]/(x^n-1),\quad g_i\mid x^n-1, $$ {#eq:decomp}
and $C=\gen{\eta_1g_1+\eta_2g_2+\eta_3g_3}$. We call $C_i$ the $i$-th component of $C$. On $R^n$ we use the Euclidean form $\langle u,w\rangle=\sum_t u_tw_t\in R$, whose values lie in $R$ rather than in $\F_q$; orthogonality is therefore tested in each component separately, as the next proposition records.

::: proposition components
Let $k_i=\dim_{\F_q}C_i$. Then $\dim_{\F_q}C=k_1+k_2+k_3$ and $|C|=q^{k_1+k_2+k_3}$. The code $C$ is a free $R$-module if and only if $k_1=k_2=k_3$. Moreover
$$ C^\perp=\eta_1C_1^\perp\oplus\eta_2C_2^\perp\oplus\eta_3C_3^\perp,\qquad\text{so}\qquad C^\perp\subseteq C\iff C_i^\perp\subseteq C_i\ \text{for } i=1,2,3. $$ {#eq:dualcomp}
:::

::: remark rank
All statements below are phrased in terms of $\dim_{\F_q}C=\sum_ik_i$ and of the component codes; no $R$-rank is used. Non-free codes are admissible: for $q=5$ and $n=4$ the component dimensions $(4,3,4)$ give $|C|=5^{11}$.
:::

## Dual containment

For a divisor $g$ of $x^n-1$ over $\F_q$ put $h=(x^n-1)/g$. It is standard that $\gen{g}^\perp=\gen{h^*}$; the next lemma records the resulting criterion in the three equivalent forms used below.

::: lemma dc
Let $C=\gen{g}$ with $g\mid x^n-1$. Then $C^\perp\subseteq C$ if and only if $g\mid h^*$, equivalently $g g^*\mid x^n-1$, equivalently no irreducible factor $p$ of $g$ has $p^*$ (up to a scalar) dividing $g$. In particular $x-1\nmid g$ whenever $C^\perp\subseteq C$ and $C\neq\{0\}$.
:::

The last assertion uses that $x-1$ is self-reciprocal and that $x-1$ divides $x^n-1$ exactly once when $\gcd(n,q)=1$. The criterion itself is classical; we use it only to decide which branches exist.

Which $(q,n)$ admit a nontrivial dual-containing code is decided by the position of $-1$ in the group generated by $q$. The following statement is the dual-containment counterpart of Massey's characterisation of reversible cyclic codes [@Massey1964] and of the complementary-dual condition of Yang and Massey [@YangMassey1994]; we record it because it determines the range of the construction.

::: lemma selfrecip
Let $d\mid n$ and let $p$ be an irreducible factor of the cyclotomic polynomial $\Phi_d$ over $\F_q$. Then $p$ is self-reciprocal if and only if $-1\in\gen{q}\subseteq(\Z/d\Z)^*$. In particular, if $-1\notin\gen{q}\subseteq(\Z/n\Z)^*$ then every irreducible factor of $\Phi_n$ is non-self-reciprocal.
:::

::: theorem existence
There is a cyclic code $C$ of length $n$ over $\F_q$ with $\{0\}\neq C^\perp\subseteq C\subsetneq\F_q^n$ if and only if $-1\notin\gen{q}\subseteq(\Z/n\Z)^*$.
:::

::: example nogo
For $(q,n)=(3,10)$ and $(7,10)$ one has $\gen{3}=\gen{7}=\{1,3,7,9\}\ni-1$ in $(\Z/10\Z)^*$. Hence no nontrivial dual-containing cyclic code of length $10$ exists over $\F_3$ or over $\F_7$, and no synchronizable code of the type considered here, with or without a ring structure, exists for these parameters.
:::

Two consequences of Theorem {ref:existence} are used repeatedly. First, the existence question for the ring code is exactly the existence question for a single field component, because Proposition {ref:components} reduces dual containment to the three components. Second, whenever branches exist, one of them has order $n$; this is Lemma {ref:periodn} in Section 4 and it is what caps the achievable window.
