# The interleaved construction

## Layout and offset model

The physical system consists of $3n$ qudits of dimension $q$, grouped into $n$ cells of three qudits. Position $3t+i-1$, with $0\le t\le n-1$ and $i=1,2,3$, carries the $i$-th component of the ring symbol $c_t=c_t^{(1)}\eta_1+c_t^{(2)}\eta_2+c_t^{(3)}\eta_3$, as in {ref:fig-lift}. A frame misalignment is a cyclic shift of the ring word by $\alpha\in\Z_n$ cells, that is, a shift of the $3n$ qudits by $3\alpha$ positions. The offset is common to the three components because it is a property of the block structure and not of a component. Shifts by one or two qudits, which would move the components relative to one another, lie outside the model; this is the main structural restriction imposed by the interleaving, and we return to it in Section 7. A block padded by $a_l$ cells on the left and $a_r$ cells on the right occupies $3(n+a_l+a_r)$ qudits, so padding is counted in cells as well.

Figure: The interleaved lift for $n=5$. Each cell holds one qudit of each component; a frame offset of $\alpha$ cells shifts all three components by the same number of positions. {#fig-lift} width=0.86
![Interleaved lift](figures/fig_lift.svg)

## Parameters

Fix a chain $C^\perp\subseteq C\subseteq D$ of $R$-cyclic codes of length $n$. By Proposition {ref:components} this is the same as three chains $C_i^\perp\subseteq C_i\subseteq D_i$ of cyclic codes over $\F_q$ with generator polynomials $g_{C_i}$ and $g_{D_i}$. A component with $C_i\subsetneq D_i$ is called a *branch*; a component with $C_i=D_i$ is *inactive*. For a branch we write
$$ f_i=\frac{g_{C_i}}{g_{D_i}},\qquad e_i=\ord_x(f_i),\qquad \deg f_i=k_{D,i}-k_{C,i}, $$ {#eq:fi}
where $\ord_x(f)$ denotes the multiplicative order of $x$ in the finite ring $\F_q[x]/(f)$, that is, the least $e\ge1$ with $x^e\equiv1\pmod f$. The order is defined because $f(0)\neq0$ for a proper divisor of $x^n-1$. For an inactive component we set $f_i=1$ and $e_i=1$; its marker syndrome is constant and imposes no condition on the offset. We write $[[N,K:M,R_g,d]]_q$ for a code on $N$ qudits with $K$ logical qudits, $M$ classical $q$-ary symbols, $R_g$ gauge qudits and distance $d$, following the parameter roles of [@TansuwannontNemec2026].

::: proposition params
The interleaved lift of the chain $C^\perp\subseteq C\subseteq D$ is a hybrid code with parameters $[[N,K:M,0,d]]_q$ where
$$ N=3n,\qquad K=\sum_{i=1}^{3}(2k_{C,i}-n),\qquad M=\sum_{i=1}^{3}(k_{D,i}-k_{C,i}),\qquad d=\min(d_X,d_Z), $$ {#eq:params}
and
$$ d_X=\min_i\ \min\wt(D_i\setminus C_i^\perp),\qquad d_Z=\min_i\ \min\wt(C_i\setminus C_i^\perp). $$ {#eq:dist}
In particular $d\ge\min_i d(D_i)$ and $d\ge\min_i d(C_i)$, where $d(\cdot)$ is the minimum distance of the classical code.
:::

**Proof.** Work first with a single component and drop the index. The operators $X(a)$ and $Z(b)$ with $a,b\in C^\perp$ commute, since $X(a)Z(b)=\omega^{a\cdot b}Z(b)X(a)$ with $\omega=e^{2\pi i/q}$ and $a\cdot b=0$ because $a,b\in C^\perp\subseteq(C^\perp)^\perp=C$. They therefore generate a stabilizer group of order $q^{2(n-k_C)}$ and the number of logical qudits is $n-2(n-k_C)=2k_C-n$. The transmitted word is $|\psi+g\rangle$ with $\psi$ a superposition of codewords of $C$ and $g\in D$ the classical label. Measuring the $Z$-syndrome with respect to $C^\perp$, that is the eigenvalues of $Z(v)$ for a basis of $v\in C^\perp$, returns $v\cdot(c+g)=v\cdot g$ for every $c\in C$, so the outcome is independent of the codeword and the measurement leaves the superposition intact; it equals the class of $g$ modulo $(C^\perp)^\perp=C$. Hence the classical label is an element of $D/C$ and there are $q^{k_D-k_C}$ of them. An $X$-type error $X(e)$ is a stabilizer when $e\in C^\perp$; when $e\in C\setminus C^\perp$ it leaves the label in its class but acts as a nontrivial logical $X$; when $e\in D\setminus C$ it moves the label to another valid class, and the receiver cannot tell this from a different message; and when $e\notin D$ the observed class is not a valid message and the error is flagged. The undetected and harmful $X$-type errors are therefore exactly the elements of $D\setminus C^\perp$, which gives $d_X$. For a $Z$-type error, $Z(v)$ commutes with the label measurement if and only if $v\in C$, and among those it is trivial on the code space if and only if $v\in C^\perp$, which gives $d_Z$. An operator mixing the two types has weight at least the larger of the weights of its parts and its nontrivial part is of one of the two kinds already counted, so the minimum is $\min(d_X,d_Z)$. The lift places the three components on disjoint coordinates, so the stabilizer groups multiply, $K$ and $M$ add, and the distance is the minimum over the components. No gauge qudits occur because the construction is symmetric in $X$ and $Z$; the general asymmetric case is described in Remark {ref:subsystem}. The final bounds follow from $D_i\setminus C_i^\perp\subseteq D_i\setminus\{0\}$ and $C_i\setminus C_i^\perp\subseteq C_i\setminus\{0\}$. $\square$

The parameter count should be read with care. $M$ counts classical symbol slots, not synchronized ones: Section 5 shows that part of this capacity must be spent on marker degrees of freedom if a window is required.

::: remark properD
For a branch $C^\perp\subseteq C\subsetneq D$, the condition $\min\wt(D\setminus C^\perp)\ge2$, that is $d_X\ge2$, is equivalent to $D\neq\F_q^n$. Indeed, a cyclic code containing a word of weight one contains all of its cyclic shifts, hence all unit vectors, hence is the full space. Conversely, if $D=\F_q^n$ then no unit vector lies in $C^\perp$, since cyclicity would force $C^\perp=\F_q^n$ and $C=\{0\}$, contradicting dual containment. This equivalence concerns the threshold $2$ only; it says nothing about larger distance requirements.
:::

## The observation model

In the construction the transmitted word is $|\psi+g\rangle$, where $\psi$ is the encoded quantum state in $C$ and $g\in D$ is the marker codeword. By the proof of Proposition {ref:params} this same $g$ is the classical label, so the marker and the classical symbol are one object rather than two: the $M$ symbol slots of the hybrid code are exactly the $M$ coordinates of the marker, and the receiver obtains them by measuring the $Z$-syndrome with respect to $C^\perp$. The block is then padded cyclically and the receiver measures, on the $n$ positions it takes to be the block, the syndrome of the marker with respect to $g_C$. If the true frame is shifted by $\alpha$, the measured syndrome is the class of $x^\alpha g$ modulo $g_C$. Writing $g=g_D\beta$, the marker is described by its *residue* $\beta$ modulo $f$; the natural choice is $\beta=1$, that is $g=g_D$. For the ring code the receiver observes the triple of component syndromes
$$ \Sigma(\alpha)=\bigl(x^\alpha g_{D_1}\bmod g_{C_1},\ x^\alpha g_{D_2}\bmod g_{C_2},\ x^\alpha g_{D_3}\bmod g_{C_3}\bigr). $$ {#eq:sigma}

Suppose the offset is known to lie in $[-a_r,a_l]$ with $a_l,a_r\ge0$ and put $W=a_l+a_r\le n-1$. The offset is *recoverable* if $\alpha\mapsto\Sigma(\alpha)$ is injective on $[-a_r,a_l]$, that is, if no difference $\delta=\alpha-\alpha'$ with $1\le|\delta|\le W$ is a *collision* in the sense $\Sigma(\alpha)=\Sigma(\alpha')$. The largest $W$ for which this holds is the *window* of the code. Because $\Sigma$ is defined on $\Z_n$, the window never exceeds $n-1$.

The following assumptions delimit the analysis; they are stated once and used throughout Sections 4 and 5.

(A1) Offsets are whole cells and satisfy $W\le n-1$.
(A2) The marker syndrome @eq:sigma is known exactly. This is the case if the channel is noiseless, or if the physical errors have been corrected before the offset is estimated.
(A3) The receiver knows $g_{C_i}$, $g_{D_i}$ and the message family in use.
(A4) Physical Pauli errors are the object of the distance statement of Proposition {ref:params}; they are not modelled jointly with the offset estimate.
(A5) There is no qudit loss, insertion or deletion, and the syndrome-extraction circuit is not itself noisy.

Under (A1)--(A5) the synchronization problem is exactly the injectivity question for @eq:sigma, and the results of Sections 4 and 5 are theorems about that question. They do not assert that a physical receiver subject to the failure modes of (A2) will synchronize; that requires a separate analysis of syndrome noise and of the coupling between physical errors and the offset estimate. {ref:fig-flow} summarises the design pipeline and marks the point at which the idealisation enters.

Figure: Construction and decoding pipeline. The shaded box marks the step that the idealised model (A2) replaces by an exact observation; the analysis in this paper covers the algebraic parts and the distance statement, not the noisy extraction. {#fig-flow} width=0.92
![Construction flow](figures/fig_flow.svg)

# Exact misalignment thresholds

## A single component

Fix one component and drop the index. Let $C\subsetneq D$ be cyclic codes of length $n$ over $\F_q$, let $f=g_C/g_D$ and $e=\ord_x(f)$. Neither the collision lemma nor Theorem {ref:sharp} uses the dual-containment condition; they are statements about nested cyclic codes.

::: lemma collision
Let $g=g_D\beta$ and $g'=g_D\beta'$ be marker codewords with residues $\beta,\beta'$ modulo $f$. Then $x^\alpha g\equiv x^{\alpha'}g'\pmod{g_C}$ if and only if
$$ f\mid x^\delta\beta-\beta',\qquad \delta=\alpha-\alpha'. $$ {#eq:collision}
:::

**Proof.** The congruence means $g_C\mid x^{\alpha'}(x^\delta g_D\beta-g_D\beta')$ with $x^\delta$ read modulo $x^n-1$. Since $g_C\mid x^n-1$ and $x$ is invertible modulo $x^n-1$, this is equivalent to $g_C\mid g_D(x^\delta\beta-\beta')$, and division by $g_D$ gives @eq:collision. $\square$

::: theorem sharp
Let the marker residue $\beta$ be coprime to $f$, for instance $\beta=1$. A difference $\delta$ is a collision if and only if $e\mid\delta$. Consequently the syndrome map is injective on $[-a_r,a_l]$ if and only if $a_l+a_r\le e-1$, and the window equals $e-1$.
:::

**Proof.** By Lemma {ref:collision}, $\delta$ is a collision if and only if $f\mid\beta(x^\delta-1)$, which by $\gcd(\beta,f)=1$ is equivalent to $f\mid x^\delta-1$, that is $e\mid\delta$. The differences occurring in $[-a_r,a_l]$ are those with $1\le|\delta|\le a_l+a_r$, and none of them is a multiple of $e$ exactly when $a_l+a_r<e$. $\square$

The sufficiency of $a_l+a_r<e$ is the order criterion of [@FujiwaraTonchevWong2013;@XieYangYuan2016;@LuoMa2018]; Theorem {ref:sharp} adds that no larger window is possible in the ideal model and identifies the complete collision set. This is a short argument, but it changes the status of the order condition from a bound to an exact value, and the rest of the paper uses that change: comparisons between designs, and the negative results on fusion, are statements about the exact value.

Two immediate consequences deserve recording. First, since $f\mid x^n-1$,
$$ e\mid n\quad\text{for every branch,} $$ {#eq:edivn}
so the window is at most $n-1$ for every choice of nested pair. Second, the same argument applied to an arbitrary marker family shows that the multiples of $e$ are always collisions, whatever the marker encodes; this yields a uniform ceiling that is used in Section 5.

::: corollary ceiling
For every marker residue and every marker family, the window of a branch satisfies $W\le e-1$. In particular the window of a ring code whose active components have periods $e_1,e_2,e_3$ satisfies $W\le\lcm(e_1,e_2,e_3)-1\le n-1$.
:::

The proof is the observation that $x^e\equiv1\pmod f$, so a shift by $e$ cells returns every marker to itself and is therefore a collision. Appendix B removes the coprimality hypothesis of Theorem {ref:sharp} and shows that the collision set is then the set of multiples of $\ord_x(f/\gcd(f,\beta))$, so a marker that shares a factor with $f$ loses part of the window in a way that is again computable exactly.

## The degree bound and its sharpness

Fujiwara's original construction certifies a window from the codimension, and the hybrid framework of [@TansuwannontNemec2026] uses the same degree-type condition. The following comparison is therefore relevant to published statements rather than only to the present construction.

::: proposition degree
If $a_l+a_r<\deg f=k_D-k_C$, the syndrome map is injective on $[-a_r,a_l]$.
:::

**Proof.** Since $f\mid x^e-1$ we have $\deg f\le e$, and the claim follows from Theorem {ref:sharp}. $\square$

::: proposition gap
If $C^\perp\subseteq C\subsetneq D$, then $\deg f\le e-1$. Hence the exact window $e-1$ is always at least $\deg f$, while the degree criterion certifies only $\deg f-1$.
:::

**Proof.** By Lemma {ref:dc}, $x-1\nmid g_C$ and therefore $x-1\nmid f$. Both $f$ and $x-1$ divide the squarefree polynomial $x^e-1$ and are coprime, so $f(x-1)\mid x^e-1$ and $\deg f\le e-1$. $\square$

The gap is not a small constant. {ref:tab-single} lists four branches with $d_X\ge2$; in the first row the exact window is twelve cells while the degree criterion certifies two. The ratio can be made arbitrarily large: if $f$ is an irreducible factor of $\Phi_m$ over $\F_q$, then $\deg f=\ord_m(q)$ and $e=m$, so $e/\deg f=m/\ord_m(q)$ is unbounded as $m$ varies over primes for which $\ord_m(q)$ stays small. The degree criterion is also sharp in general, outside the dual-containing setting: for $f=x-1$ one has $\deg f=e=1$ and both criteria give the empty window, so Proposition {ref:gap} is a consequence of dual containment and not of the degree count alone.

Table: Branches $C^\perp\subseteq C\subsetneq D\subsetneq\F_q^n$: exact window $e-1$ against the degree bound $\deg f-1$. All entries were recomputed by exhaustive enumeration of the two cyclic codes. {#tab-single} cols=rlllcccccc
| $q$ | $n$ | $g_C$ | $g_D$ | $(k_C,k_D)$ | $\deg f$ | $e$ | window | degree bound | $(d_Z,d_X)$ |
| 3 | 13 | $1+x^2+x^5+x^6$ | $2+x+x^2+x^3$ | $(7,10)$ | 3 | 13 | 12 | 2 | $(4,3)$ |
| 5 | 8 | $1+2x+3x^2+x^3$ | $3+x$ | $(5,7)$ | 2 | 8 | 7 | 1 | $(3,2)$ |
| 7 | 6 | $6+2x+x^2$ | $5+x$ | $(4,5)$ | 1 | 6 | 5 | 0 | $(3,2)$ |
| 11 | 5 | $3+9x+x^2$ | $2+x$ | $(3,4)$ | 1 | 5 | 4 | 0 | $(3,2)$ |
Note: $d_Z=\min\wt(C\setminus C^\perp)$ and $d_X=\min\wt(D\setminus C^\perp)$ are obtained by enumerating all codewords; the window is $e-1$ by Theorem {ref:sharp}. Coefficients are listed in increasing powers of $x$.

## Fusion of three components

::: theorem fused
For each active component let $e_i=\ord_x(f_i)$ and let the marker residue be coprime to $f_i$; for an inactive component set $f_i=1$ and $e_i=1$. Then the joint map $\alpha\mapsto\Sigma(\alpha)$ is injective on $[-a_r,a_l]$ if and only if $a_l+a_r\le e_R-1$, where $e_R=\lcm(e_1,e_2,e_3)$; the joint collisions are the multiples of $e_R$. In particular $\max_ie_i\le e_R\le n$.
:::

**Proof.** A difference is a joint collision if and only if it is a collision in every component, that is, if and only if $e_i\mid\delta$ for all $i$ by Theorem {ref:sharp} for the active components and by constancy of the syndrome for the inactive ones. This is the condition $e_R\mid\delta$. The inequalities follow from $e_i\mid e_R$ and @eq:edivn. $\square$

Thus one triple may well gain from fusion: components with periods $(3,4,5)$ fuse to $60$, and {ref:tab-relax} lists the triples of that kind with the largest ratio between the fused period and the largest component period. The question is whether fusion raises the *best achievable* window, and the answer is negative.

::: lemma periodn
Let $E(q,n)$ be the set of periods $\ord_x(f)$ of branches $C^\perp\subseteq C\subsetneq D$ of length $n$ over $\F_q$. Then $E(q,n)\neq\emptyset$ if and only if $-1\notin\gen{q}\subseteq(\Z/n\Z)^*$, and in that case $n\in E(q,n)$.
:::

**Proof.** If $-1\in\gen{q}$ there is no branch by Theorem {ref:existence}. Otherwise let $p$ be an irreducible factor of $\Phi_n$. By Lemma {ref:selfrecip} it is not self-reciprocal, so $C=\gen{p}$ is dual-containing by Lemma {ref:dc}. With $D=\F_q^n$ one gets $f=p$, whose roots are primitive $n$-th roots of unity, hence $\ord_x(p)=n$. $\square$

::: theorem nogain
If $-1\in\gen{q}\subseteq(\Z/n\Z)^*$, no synchronizable code of the above type exists over $\F_q$ or over $R$. Otherwise
$$ \max_{\text{triples}}\lcm(e_1,e_2,e_3)=\max E(q,n)=n, $$ {#eq:nogain}
so the largest window of a ring code of length $n$ is $n-1$ and is already attained by a single component. The same holds for any number of components.
:::

**Proof.** The first statement combines Theorem {ref:existence} with Proposition {ref:components}. By @eq:edivn every $e_i$ divides $n$, so $\lcm(e_1,e_2,e_3)\le n$; by Lemma {ref:periodn} $n\in E(q,n)$, and the triple $(n,n,n)$ attains the bound. The argument does not refer to the number of components. $\square$

The ring's contribution is therefore not the window itself but the freedom to distribute it. This is worth stating precisely, because a natural reading of "three components fused by an lcm" suggests a gain that Theorem {ref:nogain} rules out.

::: remark relax
What the ring provides is a *relaxation*: the maximal period $n$ can be obtained from three components whose individual periods $m_1,m_2,m_3$ are much smaller, provided $\lcm(m_1,m_2,m_3)=n$. For $n\mid q-1$ this is realised by linear branches $C_i=\gen{x-a_i}\subsetneq\F_q^n$ with $a_i\in\F_q^*$ of order $m_i$. For a reproducible finite enumeration take every odd prime $q\le101$ and every $n\ge3$ dividing $q-1$, enumerate the sorted divisor triples $3\le m_1\le m_2\le m_3$ with $m_i\mid n$ and $\lcm(m_1,m_2,m_3)=n$, and for each $(q,n)$ minimise the largest order, breaking ties lexicographically. This gives $118$ pairs, of which $38$ have relaxation factor $n/\max_im_i>1$; the maximum in this range is $12$, attained at $(q,n)=(61,60)$ with orders $(3,4,5)$. The bound is not universal: the orders $(5,6,7)$ at $(211,210)$ give factor $30$ and $(5,7,8)$ at $(281,280)$ give factor $35$. In general, for pairwise coprime $a,b,c\ge3$ choose a prime $q\equiv1\pmod{abc}$, whose existence is Dirichlet's theorem, and put $n=a b c$; linear branches of orders $(a,b,c)$ then have factor $a b c/\max(a,b,c)$, and the choice $(a,b,c)=(t,t+1,2t+1)$ makes this $t(t+1)$. These linear families have $d_X=1$ and therefore do not improve the Pauli-error distance.
:::

::: question distance
Does $\max_{\text{triples}}\lcm(e_1,e_2,e_3)=n$ persist when $\min\wt(D_i\setminus C_i^\perp)\ge t$ is required on every branch, for $t\ge4$? For $t=2$, equivalently proper $D_i$ by Remark {ref:properD}, it holds in all $27$ admissible pairs of {ref:tab-dconstr}, and at $(q,n)=(3,13)$ the branch of Example {ref:flagship} is a witness with $t=3$. Larger $t$ was beyond our search, and we do not conjecture an answer.
:::
