# Message-carrying markers

## Marker families

A marker that carries classical information has a residue restricted to a message family. Fix a branch with $f=g_C/g_D$, $e=\ord_x(f)$ and an integer $y$ with $0\le y\le\deg f-1$, and put
$$ \M_y=\{1+b_1x+\cdots+b_yx^y:\ b_1,\dots,b_y\in\F_q\}\subseteq\F_q[x]/(f),\qquad |\M_y|=q^y. $$ {#eq:My}
The condition $b_0=1$ normalises the family: every nonzero residue class modulo $f$ has a unique scalar multiple with constant term $1$, so $\M_y$ selects one representative from each of $q^y$ classes rather than a linear subspace. This is what makes the family closed under the comparison of two messages and keeps the zero residue out of the message set for $y<\deg f$.

::: lemma marker
Let $0\le y$ and let $\M_y$ be as in @eq:My. If $y\le\deg f$, distinct elements of $\M_y$ have distinct residues modulo $f$; for $y=\deg f$ the reduction map $\M_{\deg f}\to\F_q[x]/(f)$ is a bijection. If $y\ge\deg f+1$, two distinct elements of $\M_y$ have the same residue.
:::

**Proof.** If $b\neq b'$ in $\M_y$ had $b\equiv b'\pmod f$, then $u=b-b'$ would be a nonzero polynomial of degree at most $y$ divisible by $f$, so $\deg f\le y$; and $u(0)=0$. For $y<\deg f$ this is impossible. For $y=\deg f$ the only possibility would be $u=c f$ with $c\neq0$, which has $u(0)=c f(0)\neq0$, again impossible; the map is then injective between sets of size $q^{\deg f}$, hence bijective. For $y\ge\deg f+1$, $b=1+x f$ and $b'=1$ are distinct elements of $\M_y$ with equal residues. $\square$

The boundary case $y=\deg f$ is worth isolating, because it is the point at which the message family fills the whole quotient ring and the zero class enters: $\M_{\deg f}$ is a complete set of representatives of $\F_q[x]/(f)$, so for every offset difference $\delta$ and every $b\in\M_{\deg f}$ the residue of $x^\delta b$ is again an admissible message, and every nonzero $\delta$ is a collision. A positive window therefore requires $y\le\deg f-1$ in every component that is used for messages.

## The collision criterion

::: theorem hybrid
Fix a branch with $f$, $e$ and a marker family $\M_y$ with $0\le y\le\deg f-1$, and let $\Delta\subseteq\Z_n\setminus\{0\}$ be the set of collision differences.
1. A difference $\delta\neq0$ lies in $\Delta$ if and only if $x^\delta\M_y\cap\M_y\neq\emptyset$ modulo $f$, that is, if and only if $x^\delta b\bmod f\in\M_y$ for some $b\in\M_y$.
2. If $\delta\in\Delta$ then $|\delta|+y\ge\deg f$. Consequently $a_l+a_r\le\deg f-y-1$ guarantees injectivity, without knowledge of $e$.
3. For $y=0$ the collision set is the set of multiples of $e$ and the window is $e-1$.
:::

**Proof.** (1) A collision means $f\mid x^\delta b-b'$ for some $b,b'\in\M_y$, which is the same as $x^\delta b\bmod f=b'$. (2) For $\delta\ge1$ the polynomial $u=x^\delta b-b'$ is nonzero: $b$ has constant term $1$, so $x^\delta b$ has constant term $0$ and $u(0)=-1\neq0$. Since $f\mid u$ and $\deg u\le\delta+y$, we get $\deg f\le\delta+y$. For $\delta\le-1$, multiply the congruence by the unit $x^{|\delta|}$ modulo $f$ and exchange the roles of $b$ and $b'$. (3) With $\M_0=\{1\}$ this is Theorem {ref:sharp}. $\square$

Part (2) is a bound, not a value, and the difference matters. When $e>\deg f$ the exact window can exceed the guarantee, as {ref:tab-hybrid} shows in the third row, where the exact window is two cells while the guarantee is one. When the guarantee is attained it is attained exactly at $\delta+y=\deg f$, as in the second and fifth rows. Both behaviours occur for the same branch as $y$ varies, so neither can be inferred from $\deg f$ alone.

Table: Collision sets for message-carrying markers with $0\le y\le\deg f-1$; the last column is the guarantee $\deg f-y-1$ of Theorem {ref:hybrid}(2). {#tab-hybrid} cols=rrlccccclc
| $q$ | $n$ | $f$ | $\deg f$ | $e$ | $y$ | $|\M_y|$ | collisions $\delta\in[1,n-1]$ | window | guarantee |
| 3 | 13 | $2+2x+x^3$ | 3 | 13 | 0 | 1 | none | 12 | 2 |
| 3 | 13 | $2+2x+x^3$ | 3 | 13 | 1 | 3 | $\{3,10\}$ | 2 | 1 |
| 3 | 13 | $2+2x+x^3$ | 3 | 13 | 2 | 9 | all | 0 | 0 |
| 5 | 8 | $2+x^2$ | 2 | 8 | 0 | 1 | none | 7 | 1 |
| 5 | 8 | $2+x^2$ | 2 | 8 | 1 | 5 | $\{1,3,5,7\}$ | 0 | 0 |
| 7 | 6 | $4+x$ | 1 | 6 | 0 | 1 | none | 5 | 0 |
| 11 | 5 | $7+x$ | 1 | 5 | 0 | 1 | none | 4 | 0 |
Note: The third row is the boundary case $y=\deg f-1$ of a cubic $f$ over $\F_3$; the collision set is all of $\Z_{13}\setminus\{0\}$ because the nine messages exhaust the classes with constant term one among the $27$ residues.

## Sharing the frame

At ring level each component has its own marker family $\M_{y_i}$, and the receiver observes the triple @eq:sigma. A joint collision at difference $\delta$ requires a collision in every component at the same difference, so the joint collision set is an intersection.

::: proposition joint
Let $\Delta_i\subseteq\Z_n\setminus\{0\}$ be the collision set of component $i$, with $\Delta_i=\emptyset$ for an inactive component, and let $w_i$ be its window. Then the joint collision set is $\Delta_1\cap\Delta_2\cap\Delta_3$, the joint window is $w=\min\{|\delta|:\delta\in\Delta_1\cap\Delta_2\cap\Delta_3\}-1$, with $w=n-1$ if the intersection is empty, and $w\ge\max_iw_i$. The ring code carries $y_1+y_2+y_3$ classical symbols.
:::

**Proof.** Two pairs $(\alpha,m)$ and $(\alpha',m')$ produce the same observation exactly when they do so in every component. If $\alpha=\alpha'$ then $m=m'$ because distinct elements of $\M_{y_i}$ are distinct modulo $f_i$ by Lemma {ref:marker}; if $\alpha-\alpha'=\delta\neq0$ then $\delta\in\Delta_i$ for every $i$. The symbol count is the sum because the components occupy disjoint coordinates. For the inequality, note that $\Delta_1\cap\Delta_2\cap\Delta_3\subseteq\Delta_i$ for each $i$, so the least absolute element of the intersection is at least the least absolute element of $\Delta_i$. $\square$

The inequality $w\ge\max_iw_i$ is what makes the allocation of Section 5.4 useful, and it has a clean special case.

::: proposition pinned
Suppose $y_1=0$ and the marker residue of component $1$ is coprime to $f_1$. Then $\Delta_1$ consists of the multiples of $e_1$, so $w\le e_1-1$; and $w=e_1-1$ as soon as some component $j$ has $w_j\ge e_1-1$.
:::

**Proof.** Theorem {ref:sharp} gives $\Delta_1=e_1\Z_n\setminus\{0\}$. The positive elements of $e_1\Z_n$ are $e_1,2e_1,\dots,n-e_1$; this set is empty when $e_1=n$, and otherwise $n-e_1\ge e_1$ because $e_1\mid n$, so its least element in absolute value is $e_1$. Hence $w\le e_1-1$. The reverse inequality is Proposition {ref:joint}. $\square$

Proposition {ref:pinned} is the precise form of the statement that one component can hold the frame while the others carry messages. It should not be read as an increase in capacity: the total number of classical symbols is still $M=\sum_i(k_{D,i}-k_{C,i})$, and the messages occupy $y_i$ of the $\deg f_i$ symbol slots of component $i$. What the ring buys is the freedom to spend those slots asymmetrically.

## A ternary example

::: example flagship
Over $\F_3$ with $n=13$ let $C=\gen{1+x^2+x^5+x^6}$, a $[13,7,4]$ code, and $D=\gen{2+x+x^2+x^3}$, a $[13,10,3]$ code. Then $C^\perp\subseteq C\subseteq D$, and $f=2+2x+x^3$. Since $\ord_{13}(3)=3$, every irreducible factor of $\Phi_{13}$ over $\F_3$ is a cubic whose roots are primitive $13$-th roots of unity, and $f$ is one of them; hence $e=13$ and the window is $12$ cells, whereas the degree criterion certifies $2$. Replicating this branch in all three components gives, by Proposition {ref:params},
$$ [[\,39,\,3:9,\,0,\,3\,]]_3, $$ {#eq:flagship}
since $N=39$, $K=3(2\cdot7-13)=3$, $M=3(10-7)=9$ and $d=\min(d_Z,d_X)=\min(4,3)=3$.
:::

The example is small enough that every quantity in it can be checked by enumerating all codewords, which we did: $|C|=3^7=2187$, $|D|=3^{10}=59049$, $C^\perp\subseteq C\subseteq D$, $d(C)=4$, $d(D)=3$, $\min\wt(C\setminus C^\perp)=4$ and $\min\wt(D\setminus C^\perp)=3$. {ref:tab-alloc} records the allocations. The first row is the pure synchronization mode; the second spends one ternary symbol per component and loses most of the window; the fourth keeps the full window while transmitting four symbols, because components $2$ and $3$ have collision sets equal to all of $\Z_{13}\setminus\{0\}$ and therefore cannot destroy the discrimination provided by component $1$. The last figure, four symbols, is the largest possible with a twelve-cell window. A single symbol in component $1$ already produces the collisions $\{3,10\}$, which lie inside $[1,12]$, so $y_1=0$ is forced; components $2$ and $3$ may each carry up to $\deg f-1=2$ symbols, since $y=2$ gives a collision at every difference but its intersection with an empty collision set is still empty. It is also well below the nine symbol slots of @eq:flagship, which is the distinction between the hybrid capacity of the code and the marker payload actually transmitted.

Table: Marker allocations for the code of Example {ref:flagship}. Symbols are ternary; the padded length is $3(13+w)$ qudits. {#tab-alloc} cols=cccccc
| $(y_1,y_2,y_3)$ | symbols | joint collisions | window $w$ | padded length | payload $K/(3(13+w))$ |
| $(0,0,0)$ | 0 | none | 12 | 75 | 0.040 |
| $(1,1,1)$ | 3 | $\{3,10\}$ | 2 | 45 | 0.067 |
| $(2,2,2)$ | 6 | all | 0 | 39 | 0.077 |
| $(0,1,1)$ | 2 | none | 12 | 75 | 0.040 |
| $(0,2,2)$ | 4 | none | 12 | 75 | 0.040 |
Note: The payload column is the number of logical qudits per physical qudit and is included only to make the cost of the window explicit; the code itself is the same in all rows, and only the marker allocation changes.

::: remark subsystem
The construction extends formally to subsystem codes in the framework of [@TansuwannontNemec2026]. Per component take cyclic codes $C_x,C_z$ with $C_z^\perp\subseteq C_x$ and marker codes $C_x\subseteq D_x$, $C_z\subseteq D_z$, and the gauge group $G=\gen{\omega I,\,X(C_z^\perp),\,Z(C_x^\perp)}$. With $r_x=\dim(C_x+C_z^\perp)$ and $r_z=\dim(C_z+C_x^\perp)$ the parameters are $k=r_x+k_z-n$, $m=k_{D_x}+k_{D_z}-k_x-k_z$, $r=r_x-k_x$, and the distances are $d_x=\min\wt((D_x+D_z^\perp)\setminus C_z^\perp)$ and $d_z=\min\wt((D_z+D_x^\perp)\setminus C_x^\perp)$. In the symmetric case $C_x=C_z=C$, $D_x=D$, $D_z=C$ one recovers $r=0$, $k=2k_C-n$, $m=k_D-k_C$, $d_x=\min\wt(D\setminus C^\perp)$ and $d_z=\min\wt(C\setminus C^\perp)$, which is Proposition {ref:params}. The three components have independent gauge sectors but share one frame, so the synchronization threshold depends only on the markers. Only the symmetric case is evaluated numerically in this paper, and the asymmetric case is recorded here as a structural observation rather than as a verified construction.
:::

# Computational verification

## Method

All numerical statements in this paper were produced by an exact-arithmetic implementation written for the verification and independent of the programs distributed with the earlier version of this work. The implementation contains its own arithmetic over prime fields, its own factorisation of $x^n-1$ into irreducible factors (distinct-degree decomposition followed by Cantor--Zassenhaus splitting), its own order computation, and its own routines for enumerating branches, collision sets and codewords. No floating-point operation is used at any point where an algebraic decision is made, and no result is imported from the earlier programs.

Two cross-checks guard against implementation error. First, the branch count for a pair $(q,n)$ has the closed form
$$ N_{\text{br}}(q,n)=5^{m}-3^{m}, $$ {#eq:closedform}
where $m$ is the number of reciprocal pairs among the non-self-reciprocal irreducible factors of $x^n-1$. The reason is that $g_C$ may contain at most one member of each pair, which leaves three choices per pair for $g_C$ (neither factor, the first, the second) and then two further choices for the factor that is present, namely whether it is assigned to $g_D$ or to $f$; counting the resulting states per pair and removing the $3^m$ cases with $f=1$ gives @eq:closedform. The branches with $D$ proper are those with $g_D\neq1$; since $g_D=1$ means $D=\F_q^n$ and then $f=g_C$ ranges over the $3^m$ dual-containing generators with $f\neq1$, their number is $5^m-2\cdot3^m+1$. Both formulas were checked against the explicit enumeration on all $81$ pairs. Second, the independent programs distributed with the earlier version, which use a different computer-algebra system, were run on the same inputs and agree with the present implementation on every count reported below.

## The census

{ref:tab-census} reports the exhaustive census of branches for $q\in\{3,5,7,11,13\}$ and $2\le n\le20$ with $\gcd(n,q)=1$. Branches exist for exactly the $39$ pairs with $-1\notin\gen{q}$, in agreement with Theorem {ref:existence}; the largest period equals $n$ for each of them, in agreement with Lemma {ref:periodn}; and every one of the $20\,724$ branches satisfies $e>\deg f$, in agreement with Proposition {ref:gap}. The last column is therefore a complete check of Proposition {ref:gap} in this range rather than a sample.

Table: Exhaustive census of branches $C^\perp\subseteq C\subsetneq D$ for $2\le n\le20$ and $\gcd(n,q)=1$. {#tab-census} cols=rccccc
| $q$ | pairs $(q,n)$ | pairs with a branch | branches | $e>\deg f$ | largest period |
| 3 | 13 | 5 | 38 | 38 | $n$ |
| 5 | 15 | 6 | 136 | 136 | $n$ |
| 7 | 17 | 9 | 808 | 808 | $n$ |
| 11 | 18 | 9 | 16 134 | 16 134 | $n$ |
| 13 | 18 | 10 | 3 608 | 3 608 | $n$ |
| total | 81 | 39 | 20 724 | 20 724 | --- |
Note: The largest period column records that $\max E(q,n)=n$ for every pair that admits a branch.

The census also shows how the exact threshold compares with the degree bound across a whole family; {ref:fig-scatter} plots $e$ against $\deg f$ for all $38$ branches over $\F_3$ with $n\le20$. All points lie above the diagonal, as Proposition {ref:gap} requires, and the vertical distance to the diagonal is the number of cells by which the degree criterion understates the window.

Figure: Exact window $e-1$ against the degree bound $\deg f-1$ for all branches over $\F_3$ with $2\le n\le20$ and $\gcd(n,3)=1$. Points above the diagonal are branches for which the degree criterion is not sharp; the diagonal is drawn for reference. {#fig-scatter} width=0.58
![Window versus degree bound](figures/fig_scatter.svg)

## Collision sets and windows

Theorem {ref:sharp} was checked against the directly computed syndrome map for $1\,970$ branches: for each branch the set of differences $\delta$ with $\Sigma(\alpha)=\Sigma(\alpha+\delta)$ for some $\alpha$ was compared with the set of multiples of $e$, and the two sets coincided in every case. The injectivity boundary was checked separately: for $540$ combinations of branch and split $(a_l,a_r)$ with $a_l+a_r=e-1$ the map was injective, and with $a_l+a_r=e$ it was not. Theorem {ref:fused} was checked on $32$ triples of branches drawn from eight pairs, and Theorem {ref:hybrid} on $123$ branch-family combinations, including the boundary case $y=\deg f-1$. Proposition {ref:joint} and the general-residue statement of Appendix B were checked on $708$ combinations of branch and marker residue. In each case the computed collision set matched the predicted one exactly.

## Fusion, relaxation and the proper-$D$ constraint

The comparison is made concrete by {ref:tab-fusion}, which lists ring codes assembled from three explicit branches. In every row the fused period equals the best single period, as Theorem {ref:nogain} predicts, and the two no-go lengths are those of Example {ref:nogo}. The table also makes the point of Theorem {ref:nogain} concrete: the ring construction adds quantum symbols ($K$ exceeds what the best single component would carry) but not synchronization.

Table: Ring codes from three explicit branches: periods, fused period, best single period and parameters. For $(3,10)$ and $(7,10)$ no branch exists. {#tab-fusion} cols=rrcccccc
| $q$ | $n$ | $(e_1,e_2,e_3)$ | $e_R$ | best single | $N$ | $K$ | window |
| 3 | 8 | $(8,8,8)$ | 8 | 8 | 24 | 12 | 7 |
| 3 | 13 | $(13,13,13)$ | 13 | 13 | 39 | 21 | 12 |
| 5 | 8 | $(4,4,8)$ | 8 | 8 | 24 | 16 | 7 |
| 5 | 12 | $(4,4,12)$ | 12 | 12 | 36 | 28 | 11 |
| 7 | 6 | $(3,3,6)$ | 6 | 6 | 18 | 12 | 5 |
| 7 | 15 | $(3,3,15)$ | 15 | 15 | 45 | 33 | 14 |
| 11 | 5 | $(5,5,5)$ | 5 | 5 | 15 | 9 | 4 |
| 13 | 6 | $(3,3,6)$ | 6 | 6 | 18 | 12 | 5 |
| 3 | 10 | no branch | --- | --- | --- | --- | --- |
| 7 | 10 | no branch | --- | --- | --- | --- | --- |
Note: Each row was realised by an explicit triple of branches whose component dimensions reproduce the listed $K$; the window is $e_R-1$ cells.

{ref:tab-relax} lists the relaxation families with the largest factors in the enumeration of Remark {ref:relax}. {ref:fig-relax} shows the distribution of the factor over all $118$ pairs: most pairs gain nothing, but a substantial minority does, and the tail reaches $12$ within the stated cutoff.

Table: Relaxation families with linear branches ($n\mid q-1$): the seven pairs with factor at least $6$ in the enumeration of Remark {ref:relax}. {#tab-relax} cols=rrccc
| $q$ | $n$ | component periods $(m_1,m_2,m_3)$ | $e_R$ | $n/\max_im_i$ |
| 61 | 60 | $(3,4,5)$ | 60 | 12 |
| 73 | 72 | $(3,8,9)$ | 72 | 8 |
| 89 | 88 | $(4,8,11)$ | 88 | 8 |
| 71 | 70 | $(5,7,10)$ | 70 | 7 |
| 43 | 42 | $(3,6,7)$ | 42 | 6 |
| 67 | 66 | $(3,6,11)$ | 66 | 6 |
| 79 | 78 | $(3,6,13)$ | 78 | 6 |
Note: For $q\le101$ all $118$ pairs and their selected triples are given in the accompanying data set; $38$ have factor $>1$. Ties in minimising the largest period are broken lexicographically. The selected branches are linear, $C_i=\gen{x-a_i}\subsetneq\F_q^n$, so $D_i=\F_q^n$ and $d_X=1$ in every row.

Figure: Distribution of the relaxation factor $n/\max_im_i$ over the $118$ pairs of Remark {ref:relax}. {#fig-relax} width=0.68
![Relaxation factors](figures/fig_relax.svg)

Imposing the constraint that $D$ be proper restricts $d_X\ge2$ by Remark {ref:properD} and reduces the list to $27$ pairs, tabulated in {ref:tab-dconstr}. Every one of them still admits a triple with fused period $n$, so the negative result of Theorem {ref:nogain} is not an artefact of degenerate branches; the question left open is the behaviour for $d_X\ge4$.

Table: All $27$ pairs for which a branch with proper $D$ exists, with the attainable periods $E$ and a witness triple whose least common multiple is $n$. {#tab-dconstr} cols=rrlr
| $q$ | $n$ | attainable periods $E$ | witness |
| 3 | 13 | $\{13\}$ | $(13,13,13)$ |
| 3 | 16 | $\{8,16\}$ | $(8,8,16)$ |
| 5 | 8 | $\{4,8\}$ | $(4,4,8)$ |
| 5 | 12 | $\{4,12\}$ | $(4,4,12)$ |
| 5 | 16 | $\{4,8,16\}$ | $(4,4,16)$ |
| 7 | 6 | $\{3,6\}$ | $(3,3,6)$ |
| 7 | 9 | $\{3,9\}$ | $(3,3,9)$ |
| 7 | 12 | $\{3,6,12\}$ | $(3,3,12)$ |
| 7 | 15 | $\{3,15\}$ | $(3,3,15)$ |
| 7 | 16 | $\{16\}$ | $(16,16,16)$ |
| 7 | 18 | $\{3,6,9,18\}$ | $(3,6,9)$ |
| 7 | 19 | $\{19\}$ | $(19,19,19)$ |
| 11 | 5 | $\{5\}$ | $(5,5,5)$ |
| 11 | 10 | $\{5,10\}$ | $(5,5,10)$ |
| 11 | 14 | $\{7,14\}$ | $(7,7,14)$ |
| 11 | 15 | $\{5,15\}$ | $(5,5,15)$ |
| 11 | 16 | $\{8,16\}$ | $(8,8,16)$ |
| 11 | 19 | $\{19\}$ | $(19,19,19)$ |
| 11 | 20 | $\{5,10,20\}$ | $(5,5,20)$ |
| 13 | 6 | $\{3,6\}$ | $(3,3,6)$ |
| 13 | 8 | $\{4,8\}$ | $(4,4,8)$ |
| 13 | 9 | $\{3,9\}$ | $(3,3,9)$ |
| 13 | 12 | $\{3,4,6,12\}$ | $(3,3,4)$ |
| 13 | 15 | $\{3,15\}$ | $(3,3,15)$ |
| 13 | 16 | $\{4,8,16\}$ | $(4,4,16)$ |
| 13 | 18 | $\{3,6,9,18\}$ | $(3,6,9)$ |
| 13 | 20 | $\{4,20\}$ | $(4,4,20)$ |
Note: $E$ lists all periods $\ord_x(f)$ realised by branches with proper $D$ for that pair; a single branch already attains $\max E=n$ in every row. The other $54$ pairs of the census admit no such branch.

## The flagship code

For the code of Example {ref:flagship} the stabilizer group was constructed explicitly and its generators were verified to commute pairwise; the $X$-type part and the $Z$-type part each have rank $18$ over $\F_3$, giving $K=39-2\cdot18=3$ in agreement with @eq:flagship. The distances $d_Z=4$ and $d_X=3$ were obtained by enumerating all $2\,187$ and $59\,049$ words of $C$ and $D$; no word of $D\setminus C^\perp$ has weight below $3$, and the minimum is attained. The marker cascade of {ref:tab-alloc} was verified by computing the collision sets directly from equation {ref:eq:collision} for each allocation, not from Theorem {ref:hybrid}.

## Complexity

The computations have three layers with different costs. Factoring $x^n-1$ by distinct-degree decomposition and Cantor--Zassenhaus splitting costs $O(n^2\log n)$ field operations with schoolbook polynomial arithmetic, plus the cost of the randomised splitting. Computing $e=\ord_x(f)$ for one branch costs $O(n^2\log n)$ in the worst case, since the exponent is found by dividing $n$ by its prime factors and each trial requires a modular exponentiation. Enumerating all branches of a pair costs $5^m-3^m$ steps for $m$ reciprocal factor pairs, which is exponential in $m$; in the census $m\le6$, so no pair required more than $14\,896$ enumerations. Brute-force collision sets cost $O(n^2)$ syndrome comparisons per branch and were used only where the exhaustive check was the point; the criterion of Theorem {ref:sharp} computes the same set in $O(n)$ after $e$ is known. Message-collision tests cost $O(n q^{y})$ reductions modulo $f$, which is why the message tables are confined to small $y$. Distance computations require enumerating $q^{k}$ words and were therefore restricted to codes with $q^{k}\le6\times10^{4}$.

Measured on one core of the verification environment, the complete core suite of eighteen theorem checks, which includes $1\,970$ branch collision sets and $540$ window splittings, runs in $25.1$ s, and the entire census of $20\,724$ branches over $81$ pairs runs in $0.17$ s. These figures describe construction-time algebra; they say nothing about the cost of decoding a received block, which is not analysed here.
