# Cover Letter — Draft

> **Status: draft.** It is written to be sent; only the journal name, the date and the author's signature line are left for the author to fill in. No invented editor name, no invented submission ID, no claimed prior correspondence.

---

[Date]

The Editor-in-Chief
[Journal name]

Dear Editor,

I submit for consideration the manuscript **"Synchronizable Hybrid Codes from Cyclic Codes over $\mathbb{F}_q[v]/(v^3-v)$: Exact Misalignment Thresholds and the Limits of Component Fusion"**.

**What the paper does.** Quantum synchronizable codes tolerate a receiver that does not know where each encoded block begins. The standard design rule bounds the tolerable offset by the multiplicative order of a quotient of generator polynomials. The paper proves that, in an idealised model where the marker syndrome is observed exactly, this bound is not merely sufficient but exact: the indistinguishable offsets are precisely the multiples of that order. The proof is short, and its value is what it permits. It lets me show that the commonly used degree-type bound is never sharp for a dual-containing code, and it lets me settle a question that the sufficient condition cannot: whether packaging three synchronized components over a decomposable ring enlarges the window. It does not. The fused period is the least common multiple of the component periods, which divides the block length, and a single component already reaches that length.

**Why the negative result is the contribution.** A paper that concludes "the natural construction does not do what one might hope" is useful only if it also says what the construction *does* do. Two things survive. First, the ring allows a window to be held by one component while others carry classical messages; for a ternary code with underlying hybrid parameters $[[39,3:9,0,3]]_3$, four of the nine classical slots are usable at the full twelve-cell window. Second, fusing components with small individual periods gives a genuine relaxation: the window can be sustained without a single component of large period, at a quantified cost in $X$-distance.

**What I have done to make it checkable.** Every numerical statement is produced by a program that is included, and the program is independent of the one that produced the earlier version of these results. The exhaustive census of 20,724 branches, the 118 relaxation pairs, the 27 proper-$D$ pairs and every entry of every table are regenerated from scratch in about 25 seconds by `REPRODUCIBILITY/tests/test_all.py`. A five-page supplement contains the full proofs; a three-page supplement contains the tables and the parameters that did not fit in the article. An audit directory records three review rounds, an issues register in which the single open item is named, and a change log against the previous version.

**What the paper does not claim.** It does not claim optimality, superiority in distance, or any behaviour under noisy syndrome extraction. The model is idealised and the abstract says so in its fourth sentence and its last. A referee who works on fault tolerance may find the model too narrow; I would rather state that plainly than let the words "synchronizable code" imply a physical capability the theorems do not deliver.

**Prior version.** This replaces a 13-page version (V18). The mathematical core is preserved; the proofs are fuller, the bibliography is corrected and extended from 16 to 27 entries, and the framing has been rewritten around the negative result rather than around the ring.

The manuscript is not under consideration elsewhere, and I have no conflicts of interest to declare. I would be glad to suggest referees on request.

Yours sincerely,

Arun Kumar Yadav
School of Basic and Applied Sciences
K. R. Mangalam University
Gurugram 122103, India
arunyadav0317@gmail.com

---

## Notes for the author before sending

1. Fill in the journal name and the date. If the journal requires a suggested-referee list, draw it from `AUDIT/03_Literature_and_Novelty_Report.md` §1 — the authors of [5], [6], [13] and [25] are the closest readers of this material.
2. Run the LaTeX build first (see `MANUSCRIPT/latex_dependencies/README.md`). If it fails, fix it before submitting; do not submit the Typst-rendered PDF to a LaTeX-only venue.
3. If the journal requires a "novelty statement" shorter than this letter, use `Research_Highlights.md` and cut the third paragraph.
4. Keep the sentence about the idealised model. Removing it would make the paper easier to accept and wrong.
