# Research Highlights

Five bullets, as a journal would ask for them. Each is a claim the manuscript proves, with the location.

---

**1. The order criterion for quantum synchronizable codes is exact, not merely sufficient, in the idealised model.**
For a branch $C^\perp\subseteq C\subsetneq D$ with quotient $f=g_C/g_D$, the offsets that a receiver cannot distinguish are exactly the multiples of $e=\operatorname{ord}_x(f)$, so the window is $e-1$ cells. The known sufficient condition $a_l+a_r<e$ is therefore also necessary. *(Theorem 4.2)*

**2. The degree-type bound is never sharp for a dual-containing code, and the gap is unbounded.**
Dual containment forces $\deg f\le e-1$, so the window always exceeds the bound $\deg f-1$ by at least one cell; taking $f$ to be an irreducible factor of a cyclotomic polynomial $\Phi_m$ makes the ratio $e/\deg f=m/\operatorname{ord}_m(q)$ arbitrarily large. For the ternary example the exact window is 12 cells against a certified bound of 2. *(Proposition 4.5, Example 5.5)*

**3. Combining three ring components cannot enlarge the synchronization window.**
Each period divides $n$, so the fused period $\operatorname{lcm}(e_1,e_2,e_3)$ never exceeds $n$, and a single component already attains $n$ whenever any branch exists. This settles, negatively, the natural reason for building a code over the ring. *(Theorem 4.8)*

**4. What fusion does buy is a relaxation, and it is quantifiable.**
A window of $n-1$ cells can be sustained by three components whose individual periods are far below $n$. Over the enumerated range the relaxation factor reaches 12, and a construction makes it unbounded. The trade-off is explicit: these families have $X$-distance 1. *(Remark 4.9, Table 6)*

**5. Classical messages can be carried at full window by pinning the frame to one component.**
If one component's marker carries no message, its collision set is the multiples of its own period and the joint window equals the least component window. For the ternary code with underlying parameters $[[39,3:9,0,3]]_3$, four of the nine classical symbol slots are usable at the full twelve-cell window at a padded length of 75 qudits; the other five would cost the window. *(Propositions 5.3 and 5.4, Example 5.5, Table 3)*

---

## One-sentence summary

A ring-based construction of synchronizable hybrid codes is analysed exactly in an idealised model: the standard order bound is proved tight, the natural motivation for stacking components is disproved, and the remaining benefit — trading per-component period against window — is quantified and demonstrated on an explicit ternary code.

## What the paper deliberately does not claim

No optimality of any code; no advantage over single-component constructions in window; no noisy-syndrome performance; no competitiveness in distance. These exclusions are stated in the abstract and in §7.
