# Submission Checklist

A working checklist, not a claim. Each box is either ticked because the item was verified here, left open with the reason, or marked as the author's responsibility.

## A. Manuscript

- [x] Title, abstract, keywords, MSC codes present.
- [x] Author name, affiliation, e-mail match the V18 package; no invented metadata.
- [x] 23 pages; 7 tables; 4 figures; 2 appendices; 27 references.
- [x] Abstract states the idealised model and disclaims noisy extraction.
- [x] Every theorem has a proof either in the text or in `SUPPLEMENTARY/Detailed_Proofs.pdf`.
- [x] No occurrence of "optimal" in a mathematical claim (checked by search).
- [x] No claim of superiority over prior constructions.
- [x] Notation table not required: every symbol is defined at first use, and §2 fixes the ring notation.
- [x] Cross-references resolve: 0 problems in `check_tex.py`, and the PDF was read page by page after the final rebuild.
- [ ] **LaTeX compilation.** Not performed: no TeX engine available. See `MANUSCRIPT/latex_dependencies/README.md`. **Author action required.**
- [ ] **Figure inclusion in `pdflatex`.** The four figures are SVG; convert to PDF if the local TeX cannot embed SVG. **Author action required.**
- [ ] Journal template and reference style: the manuscript uses `amsart` and `amsplain`. If the target journal requires `IEEEtran`, the class line and the bibliography style must be changed. **Author action required.**

## B. Supplementary material

- [x] `Detailed_Proofs.pdf` (5 pp) contains full proofs of every statement.
- [x] `Supplementary_Results.pdf` (3 pp) contains the data tables and the parameters.
- [x] `Additional_Tables/A1`–`A8` are machine-generated CSVs with header rows.
- [x] Every table in the supplement is referenced from the main text or from the supplement's own text.
- [x] The supplement's numbering (S-prefix) is explained in its abstract.

## C. Reproducibility

- [x] `REPRODUCIBILITY/tests/test_all.py` runs all suites: about 25 s, `overall: PASS`.
- [x] `test_results.json` records the run, with Python version and timings.
- [x] A fresh run writes to `run_output/` and does not invalidate `SHA256SUMS.txt`.
- [x] Source of every table and figure is in `source_code/` and reads from `generated_data/`.
- [x] `requirements.txt` lists the version of every package used.
- [x] `reproduction_commands.md` gives every command, in order, with expected output.
- [x] No absolute path outside the package is required to run the tests.
- [ ] `verify_refs.py` requires outbound HTTPS; it will not run in an offline review environment. The stored `crossref_report.json` is the record. *(Environmental.)*

## D. Ethics and integrity

- [x] No fabricated data. Every number traces to a script and a stored report.
- [x] No fabricated references. All 27 verified against Crossref or the DOI record.
- [x] No copied prose. The manuscript was written for V19 from the facts of V18.
- [x] No invented affiliations, funding or acknowledgements.
- [x] Prior version disclosed in the cover letter.
- [x] Not under consideration elsewhere (author to confirm at submission).
- [ ] Conflict-of-interest statement: none to declare; author to confirm.
- [ ] Data-availability statement: the package itself is the statement; author to adapt to journal wording.

## E. Package

- [x] Tree matches the requested layout.
- [x] `SHA256SUMS.txt` covers every file except itself.
- [x] ZIP built from the tree, with the tree as the top-level directory.
- [x] No scratch files (`_tmp.*`) in the tree.
- [x] `README.md` at the root explains what is where.
- [x] Ten audit documents in `AUDIT/`, including the round-4 proofread.
- [x] Issues register records the single open item and does not describe the package as fully verified.

## F. Author actions before submission

1. Compile the `.tex` with TeX Live (`pdflatex` → `bibtex` → `pdflatex` ×2). Fix any error; expected 23 pages.
2. Convert the four SVGs to PDF if needed.
3. Replace `amsart`/`amsplain` with the target journal's class and style, if required.
4. Fill in the journal name and date in `Cover_Letter_Draft.md`.
5. Confirm the "not under consideration elsewhere" and conflict-of-interest statements.
6. Re-run `tests/test_all.py` after any change to the source, and update `test_results.json`.

## Sign-off

Checked by: the audit scripts named in `AUDIT/04`, on 21 October 2026.
Not checked by: a TeX compiler, a journal editor, or a referee.
Status: **READY, with item A (LaTeX compilation) open and assigned to the author.**
