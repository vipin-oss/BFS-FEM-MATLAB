# Submission Readiness Report

**Package.** `Quantum_Synchronizable_Hybrid_Codes_V19_SUBMISSION_READY`
**Manuscript.** *Synchronizable Hybrid Codes from Cyclic Codes over $\mathbb{F}_q[v]/(v^3-v)$: Exact Misalignment Thresholds and the Limits of Component Fusion*
**Author.** Arun Kumar Yadav, School of Basic and Applied Sciences, K. R. Mangalam University, Gurugram 122103, India.
**Date of this review.** 21 October 2026.

---

## 1. Verdict

**READY, with one documented build limitation.**

The mathematics is verified, the numbers reproduce from the package, the bibliography is checked against Crossref, and the three review rounds were completed with corrections in between. The single open item is that the LaTeX file has never been through a TeX compiler in this environment (I-14 in `AUDIT/08_Issues_Register.md`). The PDF in `MANUSCRIPT/` was produced by a second renderer from the same single source, so the *content* is what the `.tex` will typeset; the *typesetting* is not.

The honest statement is therefore: **the package is scientifically ready and mechanically ready except for a ten-minute LaTeX build that must be run by someone with TeX Live.** It is not labelled "verified" in any stronger sense, and no claim in it rests on a computation that was not executed.

## 2. What is in the package

| Directory | Files | State |
|---|---|---|
| `MANUSCRIPT/` | `Main_Manuscript.tex`, `Main_Manuscript.pdf`, `Main.typ`, `References.bib`, `figures/` (4 SVGs), `latex_dependencies/` | 23-page PDF, 27 references, 7 tables, 4 figures, 2 appendices |
| `SUPPLEMENTARY/` | `Detailed_Proofs.pdf` (5 pp), `Supplementary_Results.pdf` (3 pp), `Additional_Tables/` (8 CSVs) | Complete |
| `REPRODUCIBILITY/` | `source_code/` (10 Python files plus the three frozen V18 programs), `tests/test_all.py`, `generated_data/` (6 JSON), `source_manuscript/` (6 Markdown), `requirements.txt`, `reproduction_commands.md` | Runs in about 25 s, all suites pass |
| `AUDIT/` | `01`–`10`, ten documents | Complete |
| `SUBMISSION/` | This report, highlights, cover letter, checklist | Complete |

## 3. The acceptance gate, item by item

The fifteen items below are the criteria the package was asked to satisfy. Each is answered **PASS**, **FAIL** or **NOT VERIFIED**, with the evidence that supports the answer.

| # | Criterion | Result | Evidence |
|---|---|---|---|
| 1 | Every theorem independently verified, without trusting the existing logs | **PASS** | `verify/gf.py` + `audit_core.py` (18 checks), `audit_extra.py` (8 checks), written from the statements rather than from the V18 programs. `AUDIT/02` records 28 results with status. |
| 2 | Synchronization-order claims audited: order vs window, sufficient vs necessary, no unproved "optimal" | **PASS** | Theorem 4.2 gives equality of the collision set with the multiples of $e$; Proposition 4.4 is the sufficient direction, Theorem 4.2 the necessary one. "Optimal" appears nowhere in a mathematical claim; `AUDIT/05` R1-7 records its removal and `AUDIT/07` R3-2 the reframing. |
| 3 | Marker capacity analysed for $y<\deg f$, $y=\deg f$, $y>\deg f$ | **PASS** | Lemma 5.1, Theorem 5.2 and Corollary 4.3; the boundary $y=\deg f$ is the collapse and is proved, not asserted. Checked by core check 11 and extra check 2. |
| 4 | Flagship audit: $[[39,3:9,0,3]]_3$, four marker symbols distinguished from nine classical slots | **PASS** | Proposition 3.1 gives $M=9$; Example 5.5 and Table 3 show that four of the nine slots are usable at window 12 while the other five would cost the window. Core checks 12–14 and extra check 3. |
| 5 | Census reproduced: 20,724 branches, 81 pairs, 118 relaxation families, 38 with factor $>1$, 27 proper-$D$ pairs | **PASS** | Independently recomputed (`census_report.json`) and cross-checked against the V18 programs (identical). `AUDIT/04` §5. |
| 6 | Literature check of Tansuwannont & Nemec and of IEEE TQE 2026 | **PASS** | Verified through arXiv and the DOI record: IEEE TQE **7**, art. 2100730 (2026), DOI 10.1109/TQE.2026.3673092. `AUDIT/03` §2. All 27 entries verified. |
| 7 | Professional rewrite, no AI-style filler | **PASS** | The manuscript was rewritten from the V18 facts, not from the V18 text. No bullet-list prose, no "delve/leverage/robust" register, no unsupported superlatives. `AUDIT/07` §2 records the presentation corrections. |
| 8 | LaTeX and bibliography hygiene | **PASS for structure, NOT VERIFIED for compilation** | `check_tex.py`: 0 problems, 35 notes; 27/27 citations resolve; every tabular column count matches; `latex_dependencies/README.md` lists every package. Compilation: see item 12. |
| 9 | Three distinct review rounds with corrections between | **PASS** | `AUDIT/05` (mathematical), `AUDIT/06` (computational), `AUDIT/07` (editorial) and `AUDIT/10` (pre-submission proofread, run after the package was assembled). Twenty-nine corrections listed with their locations. The PDF was re-rendered and read page by page after the last change, twice. |
| 10 | Issues register | **PASS** | `AUDIT/08`: 33 issues, of which 1 is open (I-14), 3 closed-documented, 2 accepted, 27 closed. No S1 open. |
| 11 | Traceable V18 → V19 change log | **PASS** | `AUDIT/09`: structural, statement-by-statement, textual, bibliographic, and evidence-base changes, plus what was deliberately not changed. |
| 12 | LaTeX compilation | **NOT VERIFIED** | No TeX engine in the build environment. Structurally validated; PDF produced by Typst from the same source. Procedure in `latex_dependencies/README.md`; expected 23 pages. |
| 13 | No fabrication of data, references, affiliations or claims | **PASS** | Every number in the manuscript is emitted by a script and stored in JSON; every reference was resolved against a DOI record; author metadata taken from V18 unchanged; the one fabrication risk found during the audit (three wrongly-stated V18 defects) was corrected in the audit documents rather than left in place (`AUDIT/08` I-25). |
| 14 | No overclaiming: no "optimal", no superiority, no noisy-channel capability | **PASS** | `AUDIT/02` status table; abstract disclaimer; §7 lists what is not claimed; the fusion result is presented as negative. |
| 15 | Deliverables are actual files, not a plan | **PASS** | The tree is complete; `SHA256SUMS.txt` lists every file; the ZIP is built from the tree. |

**Score: 13 PASS, 0 FAIL, 2 NOT VERIFIED (both the same limitation: LaTeX compilation).**

## 4. Residual risks, ranked

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| The `.tex` fails to compile on TeX Live | Low | Blocks a LaTeX-only submission | Plain `amsart`, nine standard packages, checked structure; ten-minute fix |
| Figures do not embed (SVG into `pdflatex`) | Medium | Two-minute fix | Convert to PDF, as instructed in `latex_dependencies/README.md` |
| A referee says Theorem 4.2 is implicit in the literature | High | Reduces the novelty claim | Already conceded in §1 and §7; the paper's contribution is the use of exactness, not its discovery |
| A referee says the ring is unnecessary | High | Conceptual objection | §1 and §7 argue the ring's role is packaging and relaxation, and Theorem 4.8 proves the window is not enlarged. The objection is anticipated, not concealed. |
| The idealised model is judged too restrictive | Medium | Rejection at a hardware-oriented venue | Stated in the abstract; targeted at an algebraic-coding venue |
| `LiZhu2022` contains overlapping results | Low–medium | Priority claim weakened | No priority is claimed; the overlap is disclosed in §7 |
| A Typst-specific rendering defect not present in LaTeX | Low | Cosmetic | Both outputs come from one source; 35 structural notes are benign |

## 5. What a reader should check first

1. `MANUSCRIPT/Main_Manuscript.pdf`, pages 2 and 12 — the introduction's three questions and the flagship allocation.
2. `AUDIT/02_Mathematical_Verification.md` — the 28-row status table. Anything marked PROOF ONLY is exactly that.
3. `AUDIT/08_Issues_Register.md` §5 — the one open item.
4. `REPRODUCIBILITY/tests/test_all.py` — run it; it takes about 25 seconds.

## 6. What this report does not claim

It does not claim that the package is free of errors; it claims that every check listed here was run and passed, and that the checks that were not run are named. It does not claim journal acceptance. It does not claim that the results are new to the literature beyond what `AUDIT/03` §4 documents, which is a search with a stated scope and a stated limit.
