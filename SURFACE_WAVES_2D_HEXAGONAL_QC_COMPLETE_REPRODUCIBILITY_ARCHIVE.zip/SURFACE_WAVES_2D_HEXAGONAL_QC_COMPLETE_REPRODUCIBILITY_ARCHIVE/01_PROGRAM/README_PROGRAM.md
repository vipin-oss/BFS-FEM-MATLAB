# 01_PROGRAM — complete computational program

Everything needed to reproduce the numerical work of the paper. This folder is a
**tested, self-contained working tree**: all paths in all scripts resolve relative
to this folder's root (`run_all.py` states and enforces this). The layout is the
one the code was developed and validated against; it is deliberately preserved
(not re-organised into `src/`+`scripts/`) so every documented command runs
unmodified.

## 1. Programming language

Python 3 (pure Python scientific stack). No MATLAB, no compiled extensions.

## 2. Required version

- Python ≥ 3.9 (declared in `environment.yml`; developed/tested on CPython 3.13).
- Package versions are **not pinned** beyond lower bounds — the computation is
  deterministic double-precision numerics on well-conditioned library routines
  (numpy SVD/eigenvalues, scipy scalar minimisation, sympy exact rationals).

## 3. Dependencies

| Package | Min version | Used for |
|---|---|---|
| numpy | 1.24 | linear algebra (SVD, eigenvalues), arrays |
| scipy | 1.10 | scalar bounded minimisation (`minimize_scalar`) in the branch solver |
| matplotlib | 3.7 | all figures (Agg backend; no display needed) |
| sympy | 1.11 | exact-rational symbolic checks (test V4, det M(ω=0)) |
| pypdf | 3.0 | *optional* — page counting in `run_all.py`'s compile report |

Install: `pip install -r requirements.txt`  (or `conda env create -f environment.yml`).

A TeX engine is needed only for the manuscript-compile step of `run_all.py`
(`pdflatex`; the step is skipped gracefully if absent — the equivalent tectonic
command is documented in `02_OVERLEAF/compile.sh`).

## 4. Installation

```bash
cd 01_PROGRAM
python3 -m venv .venv && source .venv/bin/activate   # optional but recommended
pip install -r requirements.txt
```

No installation of the project itself is required (no setup.py); scripts import
`solver/` from the working root.

## 5. Folder structure (the tested layout)

```
01_PROGRAM/
├── run_all.py              # top-level reproduction driver (entry point)
├── params.json             # SINGLE SOURCE of all parameters (dimensional + derived starred)
├── grids.json              # sweep grids (Study-1 121 pts, Study-2 61x61, tau0 set, ...)
├── requirements.txt
├── environment.yml
├── solver/                 # five-field solver package
│   ├── material.py         #   parameters + frozen nondimensionalisation
│   ├── matrix.py           #   pencil M = A0 + p A1 + p^2 A2 (entrywise, frozen)
│   ├── roots.py            #   depth-root solver + admissible/grazing selector
│   ├── boundary.py         #   5x5 boundary matrix B (free/clamped x isothermal/insulated)
│   ├── residual.py         #   secular indicator r = sigma_min(B)/||B||_2
│   ├── branch.py           #   branch tracking (scan, continuation, Brent refine, guards)
│   ├── diagnostics.py      #   P_w, delta*, mode diagnostics
│   ├── resolution.py       #   refinement-based resolution benchmark (u_V, eps_Delta)
│   └── record.py           #   result record schema
├── drivers/                # production sweeps (write results/raw/*)
│   ├── study1_baseline.py  #   3 models x 121 frequencies (baseline)
│   ├── study2_friction_map.py  # models B,C x 61 Dw x 61 Omega
│   ├── study3_thermal.py   #   5 tau0 x 121 Omega (model C)
│   ├── study_bc.py         #   free vs clamped phason BC (models A, C)
│   └── roots_diag.py       #   depth-root diagnostic (fig8 data)
├── figures/
│   ├── make_all_figures.py # ALL 11 figures, raw-data-only, deterministic
│   └── style.py            # shared matplotlib style
├── tests/
│   ├── V0/test_V0_integrity.py       # solver identities + invariant checks
│   ├── V1/test_V1_two_path.py        # two-path (Omega->k vs k->Omega) consistency
│   ├── V2/test_V2_elastic_limit.py   # decoupled elastic + classical Rayleigh limit
│   ├── V3/test_V3_model_limits.py    # C->A and C->B limit reproduction (full grid)
│   ├── V4/test_V4_symbolic.py        # exact symbolic identities (sympy)
│   └── V5/test_V5_nondim.py          # nondimensionalisation consistency
├── verification/
│   └── verify_invariants.py          # 22 science-preservation invariant checks
├── manuscript/             # tex + bib + figures/ used by run_all's compile step
│   ├── FINAL_MANUSCRIPT.tex
│   ├── FINAL_MANUSCRIPT.bib
│   └── figures/fig1.pdf … fig11.pdf
└── results/
    ├── raw/                # canonical raw outputs of the drivers (16 files + MANIFEST)
    │                       #   + chain_log.txt (solver chain provenance)
    └── manifests/          # RAW_DATA_CHECKSUMS.sha256, RAW_DATA_MANIFEST.md
```

`figures/output/` is **generated** (not shipped here); it is created by the
figure step. Archived copies of the figures ship in `../02_OVERLEAF/figures/`
and `../08_FINAL_OUTPUTS/final_figures/`.

## 6. Main entry point

```bash
python3 run_all.py                # reproduce FROM THE SHIPPED RAW DATA:
                                  #   env check -> verify_invariants -> figures ->
                                  #   manuscript compile -> REPRODUCTION_REPORT.md
python3 run_all.py --check-only   # env + invariant checks only
python3 run_all.py --from-scratch # ALSO regenerate raw data first:
                                  #   5 drivers + 6 test suites, then the above
```

## 7. Exact execution order (equivalent to `--from-scratch`)

1. `python3 drivers/study1_baseline.py`        → `results/raw/study1_baseline.csv`, `fig4_deltas.csv`
2. `python3 drivers/study2_friction_map.py`    → `results/raw/study2_map_incremental.csv`, `fig5_friction1d.csv`
3. `python3 drivers/study3_thermal.py`         → `results/raw/fig6_tau.csv`, `fig9c_map_dT.npz`
4. `python3 drivers/study_bc.py`               → `results/raw/fig7_bc.csv`, `fig7_bc_summary.csv`
5. `python3 drivers/roots_diag.py`             → `results/raw/fig8_roots.csv`, `fig8_roots_summary.csv`
6. `python3 tests/V0/test_V0_integrity.py` … `tests/V5/test_V5_nondim.py`
7. `python3 verification/verify_invariants.py`
8. `python3 figures/make_all_figures.py`       → `figures/output/fig1..fig11.pdf` (+ Fig01..Fig11.eps)
9. manuscript compile (see `../02_OVERLEAF/compile.sh`)

Run all driver/test commands with `PYTHONPATH=<this folder>` and the working
directory set to this folder's root (the run drivers do this for you).

## 8. Command examples

```bash
cd 01_PROGRAM
python3 run_all.py --check-only          # ~1 min: quick science sanity gate
python3 run_all.py                       # ~1 min: figures + invariants from raw data
python3 run_all.py --from-scratch        # ~2-2.5 h: full regeneration (see runtimes)
python3 drivers/study1_baseline.py       # single study
python3 tests/V2/test_V2_elastic_limit.py
python3 ../06_VALIDATION/validation_scripts/complex_k_check.py   # needs PYTHONPATH=.
```

## 9. Expected runtime (single CPU core, circa 2026 hardware)

| Step | Runtime |
|---|---|
| study1_baseline | ~1–2 min |
| study2_friction_map (3721×2 solves) | ~60–90 min |
| study3_thermal (605 solves) | ~2–3 min |
| study_bc (484 solves) | ~2–3 min |
| roots_diag | < 1 min |
| tests V0, V4, V5 | < 1 min each |
| test V1 (15 anchors) | ~20 s |
| test V2 | ~1 min |
| test V3 (model limits, full grid) | ~14 min |
| figures | ~30 s |
| manuscript compile | ~1 min |
| **total `--from-scratch`** | **~2–2.5 h** (measured 2026-09-28) |

## 10. Expected outputs

- `results/raw/*.csv/.txt` — 16 raw result files + `chain_log.txt` (see `03_DATA/raw/`)
- `figures/output/fig1.pdf … fig11.pdf` and `Fig01.eps … Fig11.eps`
- `manuscript/FINAL_MANUSCRIPT.pdf` (when pdflatex is available)
- `REPRODUCTION_REPORT.md` (generated summary PASS/FAIL)
- `tests/results/*.csv` when tests run (test-run scratch; delete before packaging)

## 11. Where outputs are saved

Drivers write to `results/raw/`; the figure script writes to `figures/output/`
(override: set `QC_FIG_OUT` — see header of `make_all_figures.py`); tests write
scratch CSVs to `tests/results/`; `run_all.py` writes `REPRODUCTION_REPORT.md`
at the root. Nothing is written outside this folder.

## 12. How figures are generated

`python3 figures/make_all_figures.py` reads **only** `results/raw/*` and writes
all 11 figures (no hard-coded data arrays in the plotting code; panel constants
that annotate plots — floor lines, reference lines — are computed from
`params.json`/the same raw columns, see `07_DOCUMENTATION/FIGURE_PROVENANCE.md`).
Figures 1–8 and 10–11 are pixel-stable; Fig 9 colour limits are the exact data
min/max. EPS companions are Matplotlib vector exports of the same figure objects.

## 13. How tables are generated

Tables are typeset directly in the manuscript (`02_OVERLEAF/main.tex`); their
numbers come from `params.json` and the validation logs — see
`02_OVERLEAF/tables/README.md`. There is no table-generation script.

## 14. How validation is reproduced

```bash
for t in tests/V*/test_*.py; do python3 "$t"; done     # V0–V5
python3 verification/verify_invariants.py               # 22 invariants
python3 ../06_VALIDATION/validation_scripts/complex_k_check.py  # complex-k check
# frozen resolution benchmark (4 points; source of results/raw/resolution_bench.csv):
PYTHONPATH=. python3 -c "
from solver.material import Material
from solver import resolution
bc = {'phason':'free','thermal':'isothermal'}
pts = [('C',1e-2),('C',1.0),('C',1e2),('A',1.0)]
resolution.benchmark(pts, Material(), bc, out_csv='results/raw/resolution_bench.csv')"
```
Each writes/prints its evidence; archived runs are in
`../06_VALIDATION/validation_results/`. Expected values and tolerances:
`../04_REPRODUCTION/expected_outputs/EXPECTED_VALUES.md`.

**Packaging note (erratum C29).** In the source package the drivers wrote to
`results/` while the figure/verification code read `results/raw/`; this archive
unifies all producers/consumers on `results/raw/` (paths only — no numerical
code changed). See `../07_DOCUMENTATION/CORRECTIONS_ERRATA.md` C29.

## 15. Known numerical issues (honest record)

- **Double-precision clip.** Difference plots clip at 1e-16; dips of gate curves
  into that band are cancellation, not solver failure (documented in Fig. 2 caption).
- **Near-grazing model-A roots.** At the fixed reference scan k*=2Ω* model A has
  4 admissible + 2 grazing roots; on the solved physical branch it has 5+0. The
  admissibility tolerance (below) is scale-aware; grazing roots are recorded, never used.
- **Real-axis estimator.** Production solves the real-k minimum of r; the
  complex-wavenumber check (§5.5 of the paper) bounds the induced speed error
  (≤6.6e-7 relative at the band top; model differences far better).
- **Degenerate minima.** Quasi-static V*<0.15 minima (clamped-A case) are rejected
  and recorded as degenerate-only; never plotted as branches.
- **V3 duration.** Test V3 is slow (~14 min): it re-solves the full 121-point grid
  for two limit models. Do not kill it mid-run.

## 16. Random seeds

**None.** The computation is fully deterministic (no RNG anywhere). Two runs on
the same machine produce byte-identical CSVs except for the `run_id` timestamp
column; figure PDFs differ only in their embedded creation timestamp.

## 17. Tolerance values (authoritative: `params.json` → `solver_defaults`)

| Quantity | Value | Meaning |
|---|---|---|
| `admissibility_tol` | 1e-10 | root admissible iff Im p > tol·max(1,|p|) |
| `root_polish_newton_iters` | 2 | Newton polish steps per depth root |
| `root_residual_flag` | 1e-8 | per-root residual σmin(M)/σmax(M) flag level |
| `r_accept` | 1e-10 | residual level below which a point is 'accepted' (else 'resolved_min') |
| `n_scan` | 160 | global log-scan points per sweep (×3 in the resolution benchmark) |
| `brent_xtol` / `rel_xtol` | 1e-12 / 1e-15 | local bracketed refinement of the r-minimum |
| `eps_Delta_multiplier` | 10 | ε_Δ = 10·max(u_V) |
| `branch_jump_flag_rel` | 0.05 | branch-jump diagnostic: fail on unexplained V* change >5% between neighbours |
| degenerate cutoff | V*<0.15 | quasi-static degenerate minima rejected |

## 18. Mesh / time-step settings

**NOT APPLICABLE** — the half-space is not discretised (semi-analytical depth
roots). The equivalent discretisation-of-parameter-space settings are the sweep
grids in `grids.json`: Study-1 = 121 logarithmic Ω*∈[1e-3,1e3]; Study-2 =
61×61 (Ω*, D_w*); Study-3 = 5 τ0* × 121 Ω*; Study-BC = 121 Ω* × {free,clamped}.
Harmonic time dependence e^{-iωt}; no time stepping.

## 19. Solver settings

Depth roots: eigenvalues of the 10×10 companion linearisation of det M, then 2
Newton polish steps; admissible set = Im p>tol (5 roots on every accepted point);
eigenvectors = unit-norm SVD null vectors; B assembled per
`02_OVERLEAF` §3.7 rows; secular r = σmin(B)/σmax(B); branch = log-scan
(n_scan points, sub-scans at the bulk-grazing wavenumbers) + local bracketed
minimisation of every interior candidate + continuation-preferred selection with
staleness guard + jump diagnostic; acceptance recorded per point
(`accepted` / `resolved_min` / `no_branch`).

## 20. Convergence criteria

- Local: minimiser refinement converged when the bracketing tolerance
  rel_xtol=1e-15 (Brent xtol=1e-12 in production callers) is reached on k.
- Branch-level: a point is a physical branch only if exactly 5 admissible roots
  exist and the V*<0.15 degenerate cutoff and 5% jump diagnostic pass.
- Global resolution: refinement-based u_V (production scan vs 3× scan, all
  tolerances identical) ≤1.13e-9 → ε_Δ=1.13e-8 (absolute V units).
- Verification gates (must reproduce): see
  `../04_REPRODUCTION/expected_outputs/EXPECTED_VALUES.md`.
