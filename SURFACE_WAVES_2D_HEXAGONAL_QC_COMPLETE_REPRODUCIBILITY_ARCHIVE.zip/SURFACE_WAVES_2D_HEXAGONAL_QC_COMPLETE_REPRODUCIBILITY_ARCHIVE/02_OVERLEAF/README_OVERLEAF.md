# 02_OVERLEAF — Overleaf-ready manuscript folder

This folder compiles **stand-alone**: upload the whole folder to Overleaf
(or run `bash compile.sh` locally) and set `main.tex` as the main document.

## Contents

| File | Role |
|---|---|
| `main.tex` | Manuscript source (final, submission-ready). Byte-identical to `../01_PROGRAM/manuscript/FINAL_MANUSCRIPT.tex` and to the source that produced `../08_FINAL_OUTPUTS/manuscript.pdf`. |
| `references.bib` | Bibliography database (provenance copy). **The compiled document uses the embedded `\begin{thebibliography}` list inside `main.tex`**, so this file is reference material for future re-formatting (e.g. elsarticle/natbib), not a compile dependency. |
| `figures/` | All 11 figure PDFs (`fig1.pdf` … `fig11.pdf`) + EPS companions (`Fig01.eps` … `Fig11.eps`). The preamble's `\graphicspath{{../figures/output/}{figures/}}` resolves `figures/` here. |
| `tables/` | No external table files: every table is typeset inside `main.tex`. See `tables/README.md`. |
| `supplementary/` | No supplementary material. See `supplementary/README.md`. |
| `compile.sh` | Compilation script (pdflatex or tectonic). |

## Compilation facts (verified 2026-09-28)

- Document class: standard `article` (11 pt). **No custom .cls or .bst is required.**
- Packages used: `graphicx`, `amsmath`, `amssymb`, `booktabs`, `hyperref`, and standard layout packages — all part of any full TeX Live / Overleaf TeX Live image.
- Bibliography: embedded `\bibitem` list (`\begin{thebibliography}{47}`); there is therefore **no `main.bbl`** (NOT APPLICABLE) and no `\addbibresource` step.
- Figure dependencies: exactly `figures/fig1.pdf` … `figures/fig11.pdf`; all present. No `\input`/`\include` of external .tex fragments.
- Verified compile: tectonic 0.15.0 → 35 pages, 0 errors, all 47 citations resolved, all `\ref`/`eqref` labels resolved (no undefined references).
- `main.tex` contains the standard author placeholders (title page) and declaration placeholders; fill them before journal submission.

## How to compile on Overleaf

1. Create a new project → Upload Project → upload this folder as a ZIP.
2. Menu → set Main document = `main.tex`.
3. Compiler: `pdfLaTeX` (default) — done.

## Path notes

- The only path assumption is `\graphicspath{{../figures/output/}{figures/}}` (already in the source).
  The first entry (`../figures/output/`) exists only in the program working tree;
  Overleaf resolves the second (`figures/`) — nothing to edit.
- No absolute machine-specific paths exist anywhere in `main.tex`.
