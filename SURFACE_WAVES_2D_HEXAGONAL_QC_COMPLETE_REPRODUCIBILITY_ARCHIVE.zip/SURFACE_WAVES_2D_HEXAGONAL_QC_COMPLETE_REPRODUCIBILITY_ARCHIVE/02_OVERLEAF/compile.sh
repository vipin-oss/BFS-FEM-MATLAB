#!/usr/bin/env bash
# Compile the manuscript. Works with either TeX Live (pdflatex) or tectonic.
# Usage:  bash compile.sh
set -e
cd "$(dirname "$0")"
if command -v pdflatex >/dev/null 2>&1; then
    pdflatex -interaction=nonstopmode main.tex
    pdflatex -interaction=nonstopmode main.tex
    pdflatex -interaction=nonstopmode main.tex
elif command -v tectonic >/dev/null 2>&1; then
    tectonic main.tex
else
    echo "ERROR: neither pdflatex nor tectonic found on PATH." >&2
    echo "Install TeX Live (pdflatex) or tectonic (https://tectonic-typesetting.github.io)." >&2
    exit 1
fi
echo "OK: main.pdf written."
