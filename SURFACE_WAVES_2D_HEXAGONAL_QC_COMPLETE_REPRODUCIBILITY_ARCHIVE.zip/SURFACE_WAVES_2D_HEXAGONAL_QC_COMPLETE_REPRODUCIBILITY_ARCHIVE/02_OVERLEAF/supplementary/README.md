# supplementary/ — supplementary material

**NOT AVAILABLE.** No supplementary material exists for this project
(no supplementary PDF, no extra tables, no extra figures). All results are in
the manuscript and this archive (`03_DATA`, `06_VALIDATION`).
The folder is retained (empty) so the Overleaf layout is complete and any
future supplementary material has a designated location.

Historical note: the source package carried
`manuscript/supplementary/README.md` with the same statement.
