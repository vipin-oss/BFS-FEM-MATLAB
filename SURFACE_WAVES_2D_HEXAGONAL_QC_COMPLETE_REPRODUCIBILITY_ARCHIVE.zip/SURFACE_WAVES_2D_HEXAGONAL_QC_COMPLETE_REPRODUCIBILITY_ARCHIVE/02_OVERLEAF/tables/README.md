# tables/ — table dependencies

There are **no external table files** in this project.

Every table of the manuscript is typeset directly in `main.tex`
(`\begin{table}...\end{table}` blocks):

| Table (label) | Content | Data source (for regeneration) |
|---|---|---|
| `tab:params` | Dimensional parameter set with provenance | `01_PROGRAM/params.json` (`dimensional_SI`, `provenance_labels`) |
| `tab:nondim` | Controlling nondimensional groups + swept ranges | `01_PROGRAM/params.json` (`frozen_starred_targets`) + `01_PROGRAM/grids.json` |
| `tab:dim` | Dimensional endpoints (f, λ, δ*) | computed from `params.json` scales + Fig. 11 products (documented in `../08_FINAL_OUTPUTS/final_results/KEY_RESULTS.md`) |
| `tab:cxk` | Complex-wavenumber dispersion check | `06_VALIDATION/validation_results/complex_k_dispersion.log` |
| (results tables inside sections) | verification gates, model limits | `06_VALIDATION/validation_results/*.log` |

To edit a table, edit `main.tex` directly; there is no table-generation script.
