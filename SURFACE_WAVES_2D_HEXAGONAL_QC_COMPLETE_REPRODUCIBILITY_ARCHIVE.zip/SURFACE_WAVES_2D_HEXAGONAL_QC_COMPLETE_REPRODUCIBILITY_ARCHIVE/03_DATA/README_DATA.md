# 03_DATA — all data files

## raw/  — canonical raw solver outputs (16 files)

The exact raw outputs of the five production drivers plus the two
boundary-cell grid files used by Fig. 9:

| File | Producer | Content |
|---|---|---|
| `study1_baseline.csv` | `drivers/study1_baseline.py` | 363 rows (3 models × 121 Ω*): V*, r, k*, P_w, δ*, branch flags |
| `study2_map_incremental.csv` | `drivers/study2_friction_map.py` | 7442 rows (models B,C × 61 D_w* × 61 Ω*): the V*(Ω*,D_w*) map |
| `fig4_deltas.csv` | study1 (derived dump) | model speed-difference curves Δ_BC, Δ_AC, Δ_AB |
| `fig5_friction1d.csv` | study2 (derived dump) | Δ_BC vs D_w* at Ω*=1e-3 (49 rows) |
| `fig6_tau.csv` | `drivers/study3_thermal.py` | 605 rows: V*, ΔT, floor test across 5 τ0* |
| `fig7_bc.csv` | `drivers/study_bc.py` | 484 rows: free vs clamped phason BC sweep |
| `fig7_bc_summary.csv` | study_bc (derived dump) | dV/V and penalty curves |
| `fig8_roots.csv` | `drivers/roots_diag.py` | depth-root diagnostic (model × root per point) |
| `fig8_roots_summary.csv` | roots_diag | per-point summary incl. P_w, δ* |
| `fig9b_map_dBC.npz` | study2 + fig9 precompute | fig9b field array (boundary cells, documented in `MANIFEST.md`) |
| `fig9c_map_dT.npz` | study3 | fig9c ΔT map field array |
| `resolution_bench.csv` | `solver/resolution.py` (run by tests) | 6 rows: u_V, ε_Δ per model × Ω*=1e3 |
| `v2_elastic_limit.csv` | `tests/V2/...` | elastic-limit raw evidence |
| `v3_model_limits.csv` | `tests/V3/...` | model-limit raw evidence (A,B,telegraph→C) |
| `MANIFEST.md` | — | per-file description of raw/ |
| `chain_log.txt` | `solver/material.py` log hook | solver-hash chain of the production runs |

**Reproducibility copy:** the same 16 files are mirrored in
`../01_PROGRAM/results/raw/` so that `run_all.py` works out of the box. Both
copies are hash-identical (see `../09_ARCHIVE_METADATA/SHA256SUMS.txt`). The
canonical archival copy is this folder; the program copy is the working-tree copy.

## processed/

**No intermediate processed layer exists** — figure scripts and analysis read
the raw CSVs directly. The folder is kept empty for future derived data.

## generated/

All figures are generated programmatically from `raw/` by
`../01_PROGRAM/figures/make_all_figures.py`. Archived figure outputs live in
`../02_OVERLEAF/figures/` (tex dependencies) and
`../08_FINAL_OUTPUTS/final_figures/` (final deliverable copies). No other
generated datasets exist.

## validation/

Copies of the three validation-evidence CSVs (`resolution_bench.csv`,
`v2_elastic_limit.csv`, `v3_model_limits.csv`) — these are also in `raw/`
(they are produced by the test suite and were archived there during the
production runs). Canonical locations are `raw/`.

## metadata/

`RAW_DATA_CHECKSUMS.sha256` — SHA-256 of each raw file (relative to `raw/`),
`RAW_DATA_MANIFEST.md` — provenance manifest of the raw data.

## Missing data (honest)

- No data expected by the manuscript is missing; every figure panel traces to
  `raw/` (see `../07_DOCUMENTATION/FIGURE_DATA_TRACEABILITY.md`).
- No supplementary datasets exist.
- No instrument/lab data exist (purely computational project).
