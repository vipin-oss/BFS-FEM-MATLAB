# REPRODUCE_FROM_SCRATCH.md — step-by-step complete regeneration

Target audience: a researcher with a fresh machine, five years from now.
Everything below is literal, copy-pasteable, and was executed on 2026-09-28
in this exact form (see `expected_outputs/REPRODUCTION_REPORT.md`).

## STEP 0 — environment

```bash
# 1. Python 3.9+ (3.13 tested). Check:
python3 --version

# 2. Dependencies (numpy>=1.24, scipy>=1.10, matplotlib>=3.7, sympy>=1.11):
pip install numpy scipy matplotlib sympy
#    (or: pip install -r 01_PROGRAM/requirements.txt)
#    (or: conda env create -f 01_PROGRAM/environment.yml)

# 3. TeX engine for the manuscript (pick one):
#    - TeX Live (pdflatex), or
#    - tectonic 0.15  (https://tectonic-typesetting.github.io)
```

## STEP 1 — obtain the program

Unpack the archive; the program root is `01_PROGRAM/`. All commands below are
run **from that folder**:

```bash
cd 01_PROGRAM
```

## STEP 2 — sanity gate (optional, ~1 min)

```bash
python3 run_all.py --check-only
# EXPECTED: environment OK; 22/22 invariant checks PASS; test gates summary printed.
```

## STEP 3 — regenerate ALL raw data (the expensive part, ~2–2.5 h on one CPU core; study2 alone is ~60–90 min)

```bash
python3 run_all.py --from-scratch
```

This runs, in order (you may also run them one by one — see `RUN_ORDER.md`):
1. `drivers/study1_baseline.py`   → `results/raw/study1_baseline.csv`, `fig4_deltas.csv`
2. `drivers/study2_friction_map.py` → `results/raw/study2_map_incremental.csv`, `fig5_friction1d.csv`
3. `drivers/study3_thermal.py`    → `results/raw/fig6_tau.csv`, `fig9c_map_dT.npz`
4. `drivers/study_bc.py`          → `results/raw/fig7_bc.csv`, `fig7_bc_summary.csv`
5. `drivers/roots_diag.py`        → `results/raw/fig8_roots.csv`, `fig8_roots_summary.csv`
6. the six test suites V0–V5 (they also emit `resolution_bench.csv`,
   `v2_elastic_limit.csv`, `v3_model_limits.csv` and refresh the two fig9 NPZ
   fields via `tests/results/`)

## STEP 4 — verify against the archived data

```bash
# 4a. raw data: compare regenerated CSVs with the archived ones (ignoring run_id/solver_hash):
python3 - << 'EOF'
import csv, glob, os
new='results/raw'; old='../03_DATA/raw'
worst=0.0; ok=True
for f in sorted(glob.glob(os.path.join(old,'*.csv'))):
    b=os.path.basename(f)
    if b=='v2_elastic_limit.csv': continue          # transcript format
    rn=list(csv.DictReader(open(os.path.join(new,b))))
    ro=list(csv.DictReader(open(f)))
    if len(rn)!=len(ro): print('ROWS DIFFER',b,len(rn),len(ro)); ok=False; continue
    for a,c in zip(rn,ro):
        for k in c:
            if k in ('run_id','solver_hash'): continue
            try: d=abs(float(a[k])-float(c[k]))
            except ValueError: d=0.0 if a[k]==c[k] else 1.0
            worst=max(worst,d)
            if d!=0.0 and d>1e-12*max(1,abs(float(c.get(k) or 0))): ok=False
print('worst abs numeric difference:',worst,'OK' if ok else 'CHECK')
EOF
# EXPECTED: worst abs numeric difference 0.0 (bitwise-equal floats, same machine/libraries);
# across library versions, agreement at the 1e-9 relative level is the documented bound.

# 4b. the scientific gates (also run by the test suite):
for t in tests/V*/test_*.py; do python3 "$t"; done
# EXPECTED: every test prints PASS; exact expected numbers:
#   ../04_REPRODUCTION/expected_outputs/EXPECTED_VALUES.md
```

## STEP 5 — regenerate all figures

```bash
python3 figures/make_all_figures.py
ls figures/output/        # fig1..fig11.pdf + Fig01..Fig11.eps
```

Compare with the archived figures (`../08_FINAL_OUTPUTS/final_figures/`):
pixel-identical rendering is expected on the same Matplotlib version; across
versions, all curves must coincide (the data behind them is bitwise-equal —
step 4a). The Matplotlib version is recorded in every figure's PDF metadata.

## STEP 6 — compile the manuscript

```bash
cd ../02_OVERLEAF
bash compile.sh            # pdflatex ×3 or tectonic
# EXPECTED: main.pdf, 35 pages, 0 errors.
```

## STEP 7 — final comparison report

```bash
cd ../01_PROGRAM
python3 run_all.py         # from the raw data you just regenerated:
                           # re-runs invariants + figures + compile attempt and writes
                           # REPRODUCTION_REPORT.md
```

## How to verify the archive itself was not corrupted

```bash
cd ../09_ARCHIVE_METADATA
sha256sum -c SHA256SUMS.txt          # every file hash must be OK
# or, cross-folder consistency:
python3 ../04_REPRODUCTION/verification/verify_checksums.py
```

## What to do if something fails

- SciPy/NumPy major-version differences can change the *last digits* of CSV
  outputs (minimiser stopping). Compare at the 1e-9 relative level first; only
  failures beyond that indicate real breakage.
- If a driver reports `no_branch` where the archive has a solved point: check
  the tolerances are exactly the `solver_defaults` values in `params.json`.
- If LaTeX fails on `hyperref`/`bookmark` warnings: they are non-fatal; compile
  with `pdflatex -interaction=nonstopmode` as `compile.sh` does.
