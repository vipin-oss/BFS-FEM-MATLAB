# RUN_ORDER.md — dependency-aware execution order

## Fast path (from shipped raw data) — ~2 minutes

| # | Command | Writes | Reads |
|---|---|---|---|
| 1 | `python3 verification/verify_invariants.py` | stdout | `params.json`, `solver/` |
| 2 | `python3 figures/make_all_figures.py` | `figures/output/*` | `results/raw/*`, `params.json` |
| 3 | `bash ../02_OVERLEAF/compile.sh` | `../02_OVERLEAF/main.pdf` | `02_OVERLEAF/{main.tex,figures/}` |
| 4 | `python3 run_all.py` | `REPRODUCTION_REPORT.md` | steps 1–3 |

(`run_all.py` without flags = steps 1–4 in one command.)

## Full path (from scratch) — ~2–2.5 hours (one CPU core)

| # | Command | Writes | Must follow |
|---|---|---|---|
| 1 | `python3 drivers/study1_baseline.py` | `results/raw/study1_baseline.csv`, `fig4_deltas.csv` | — |
| 2 | `python3 drivers/study2_friction_map.py` | `results/raw/study2_map_incremental.csv`, `fig5_friction1d.csv` | — |
| 3 | `python3 drivers/study3_thermal.py` | `results/raw/fig6_tau.csv`, `fig9c_map_dT.npz` | — |
| 4 | `python3 drivers/study_bc.py` | `results/raw/fig7_bc.csv`, `fig7_bc_summary.csv` | — |
| 5 | `python3 drivers/roots_diag.py` | `results/raw/fig8_roots.csv`, `fig8_roots_summary.csv` | — |
| 6 | `python3 tests/V0/test_V0_integrity.py` | `tests/results/V0_*.csv` | 1–5 (checks identities) |
| 7 | `python3 tests/V1/test_V1_two_path.py` | `tests/results/V1_*.csv` | — |
| 8 | `python3 tests/V2/test_V2_elastic_limit.py` | `results/raw/v2_elastic_limit.csv` | — |
| 9 | `python3 tests/V3/test_V3_model_limits.py` | `results/raw/v3_model_limits.csv` | — |
| 10 | `python3 tests/V4/test_V4_symbolic.py` | `tests/results/V4_*.csv` | — |
| 11 | `python3 tests/V5/test_V5_nondim.py` | `tests/results/V5_*.csv` | — |
| 11b | resolution-bench regeneration (frozen points; see `../07_DOCUMENTATION/DATA_DICTIONARY.md` for the exact command) | `results/raw/resolution_bench.csv` | — |
| 12 | `python3 figures/make_all_figures.py` | `figures/output/*` | 1–5, 8, 9, 11b (raw data) |
| 13 | `bash ../02_OVERLEAF/compile.sh` | `../02_OVERLEAF/main.pdf` | 12 (figures) |
| 14 | `python3 verification/verify_invariants.py` | stdout | — |

(Steps 1–11 = `python3 run_all.py --from-scratch`; it then performs 12–14.)

## Notes

- Steps 1–5 are independent of each other (order 1→5 is the archival convention).
- The tests (6–11) are independent; run in numeric order for clean logs.
- Fig. 9's NPZ fields (`fig9b_map_dBC.npz`, `fig9c_map_dT.npz`) are produced by
  the study2/study3 driver runs (step 2/3) plus the fig9 precompute inside
  `tests/results/` — after steps 2–3 the figure script can consume them directly.
- Runtimes assume one CPU core; no MPI, no GPU.
- `run_id` columns embed wall-clock timestamps — regenerate-compare scripts
  must skip those columns (as `REPRODUCE_FROM_SCRATCH.md` STEP 4a does).
