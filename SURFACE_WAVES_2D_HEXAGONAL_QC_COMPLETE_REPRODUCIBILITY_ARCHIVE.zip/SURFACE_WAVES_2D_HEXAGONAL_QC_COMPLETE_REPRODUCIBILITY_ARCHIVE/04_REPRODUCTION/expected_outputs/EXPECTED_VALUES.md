# EXPECTED_VALUES.md — scientific gates for reproduction comparison

Compare regenerated values at the **1e-9 relative level** across library
versions (same-stack reruns are bitwise-equal). "Expected" = what the archived
data contain (audit-verified 2026-09-28). Location of evidence in parentheses.

## Test gates (each must print PASS)

| Gate | Expected |
|---|---|
| V0 integrity / invariants | 22/22 invariant checks pass; residual identity holds |
| V1 two-path (15 anchors) | worst \|ΔV\| = 9.35e-10 |
| V2 elastic limit | v_P/v0=1, v_S/v0=0.5 exact; Rayleigh computed 0.932525906 vs analytic 0.932525905931 (rel err 1.1e-11); V_A 0.310726890370 → two-path 0.310726616 |
| V3 model limits (121/121 each) | C(D_w*→1e-14)→A gate 1.110e-9; C(ρ_w*→1e-8)→B gate 3.266e-9 |
| V4 symbolic | all identities exact (0 residual, rational arithmetic) |
| V5 nondim | consistency residual 0 |
| complex-k (13 pts) | speed ≤6.6e-7 rel (A ≤2.5e-10); attenuation ≤7.0e-4/λ (A ≤3.1e-7); Δ_BC shift ≤8.0e-10 (≤8.4e-8 at D_w*=0.01) |

## Raw-data spot values (regenerated CSVs must match)

| Dataset | Column/point | Expected |
|---|---|---|
| study1_baseline.csv | V* (A, Ω*=1e-3) | 0.3107268903703 |
| study1_baseline.csv | V* (B, Ω*=1e-3) | 0.4663012299753 |
| study1_baseline.csv | rows | 363 |
| study2_map_incremental.csv | rows | 7442 (122 combos × 61 Ω*) |
| study2 range V_B* | min/max | 0.464987 / 0.466301 |
| study2 range V_C* | min/max | 0.466264 / 0.467355 |
| fig6_tau.csv | ΔT maxima (4 curves) | 1.09e-5, 1.07e-5, 2.94e-5, 7.879e-5 |
| fig6_tau.csv | floor dips | 0/0/1/0 (only τ0*=1e-2, Ω*=44.7, ΔT=5.83e-8) |
| fig6_tau.csv | `above_floor` True counts per τ0* | 58 / 58 / 0 / 60 / 78 (needs the frozen `resolution_bench.csv` with ε_Δ=1.129857263305e-08 present at `results/` before study3 — see note) |
| fig7_bc_summary.csv | dV/V max (C) | 8.1e-6 at Ω*=1e3 |
| fig7_bc.csv | dV/V max (A) | 8.0609e-6 |
| fig8_roots_summary.csv | r range | 9.67e-9 … 3.249e-5 |
| fig8_roots_summary.csv | P_w (A) | 0.99095 |
| resolution_bench.csv | u_V / ε_Δ | ≤1.13e-9 / 1.13e-8 |
| fig4_deltas.csv | Δ_AC | ≈0.334 (constant, branch identity) |

## Note on `resolution_bench.csv` (honest numerical sensitivity)

The frozen benchmark file (`03_DATA/raw/resolution_bench.csv`, ε_Δ =
1.129857263305e-08) is the threshold behind the manuscript's floor language
and fig6's `above_floor` column. Regenerating it with the documented command
produces the same V_L1 to 12 digits but a **smaller u_V on today's library
stack** (measured 2026-09-28: u_V(C,1e-2)=6.3e-11 → ε_Δ=6.3e-10): the u_V
measure is sensitive to the scan-refinement stopping behaviour (and the
historical run's exact scan multiplier is NOT DOCUMENTED — the module
docstring says "doubled-scan", the shipped code uses 3×). The archived
ε_Δ=1.13e-8 is the conservative threshold used in all captions and is kept as
canonical. For figure regeneration and study3's `above_floor` column, the
frozen file must be present (copy `03_DATA/raw/resolution_bench.csv` into
`results/` and `results/raw/` of the working tree before running).

## Figure comparison

- Same Matplotlib version: pixel-identical rendering expected.
- Different versions: curves must coincide (data bitwise-equal); PDF bytes will
  differ (embedded timestamp/version metadata) — do NOT use PDF hashes for
  figure comparison; use the raw-data comparison instead.

## Manuscript

- `main.pdf` after compile: 35 pages; 0 LaTeX errors; 47 bibliography items;
  no undefined references; all 11 figures included (see
  `../06_VALIDATION/validation_results/` for the 2026-09-28 text-verification
  record of must-have/must-absent strings).
