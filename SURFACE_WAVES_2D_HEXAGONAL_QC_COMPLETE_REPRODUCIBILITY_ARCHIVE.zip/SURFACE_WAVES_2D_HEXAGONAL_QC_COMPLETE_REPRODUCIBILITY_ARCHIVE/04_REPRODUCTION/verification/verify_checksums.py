#!/usr/bin/env python3
"""Verify archive integrity against 09_ARCHIVE_METADATA/SHA256SUMS.txt.

Usage (from anywhere):
    python3 verify_checksums.py [path-to-archive-root]

Exit code 0 = all OK; 1 = mismatch/missing. Also cross-checks the mirrored raw
data copies (01_PROGRAM/results/raw vs 03_DATA/raw).
"""
import hashlib, os, sys

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.path.join(here, "..", "..")
    root = os.path.abspath(root)
    sums = os.path.join(root, "09_ARCHIVE_METADATA", "SHA256SUMS.txt")
    if not os.path.exists(sums):
        print("ERROR: SHA256SUMS.txt not found at", sums); return 1
    ok = bad = missing = 0
    with open(sums) as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            digest, rel = line.split(None, 1)
            rel = rel.lstrip("*").strip()
            p = os.path.join(root, rel)
            if not os.path.exists(p):
                print("MISSING:", rel); missing += 1; continue
            if sha256(p) == digest:
                ok += 1
            else:
                print("MISMATCH:", rel); bad += 1
    print(f"checked: {ok} OK, {bad} mismatch, {missing} missing")
    # raw-mirror cross-check
    a = os.path.join(root, "01_PROGRAM", "results", "raw")
    b = os.path.join(root, "03_DATA", "raw")
    if os.path.isdir(a) and os.path.isdir(b):
        diffs = 0
        for fn in sorted(os.listdir(b)):
            pa, pb = os.path.join(a, fn), os.path.join(b, fn)
            if not os.path.exists(pa):
                print("MIRROR-MISSING:", fn); diffs += 1
            elif sha256(pa) != sha256(pb):
                print("MIRROR-MISMATCH:", fn); diffs += 1
        print("raw mirror (01_PROGRAM vs 03_DATA):", "OK" if diffs == 0 else f"{diffs} problems")
    return 0 if (bad == 0 and missing == 0) else 1

if __name__ == "__main__":
    sys.exit(main())
