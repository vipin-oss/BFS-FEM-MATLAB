# 05_DERIVATIONS — derivation record

**Authoritative source:** the final manuscript (`02_OVERLEAF/main.tex`). The
files in this folder are *navigational transcriptions* of the paper's
derivations, written to help a future reader follow the logic and locate every
ingredient. They contain **no new or conflicting equations** — where an equation
exists in the paper it is referenced by its LaTeX label (`eq:...`) and section.
Anything that is not derivable from the archived material is marked
NOT DOCUMENTED.

| Folder | Content | Paper location |
|---|---|---|
| `governing_equations/` | Balance laws + constitutive structure + symmetry relations | §2 (`eq:sxx`…`eq:symrels`, `eq:LS`) |
| `nondimensionalization/` | Scales, starred system, derived scale relations | §4 (`eq:scales`, `eq:starred`, `eq:omegac`) |
| `numerical_method/` | Matrix pencil, companion linearisation, root selector | §3.2–3.3, §3.7 (`eq:Mpoly`, `eq:decay`) |
| `boundary_conditions/` | The five surface rows + secular determinant | §3.4–3.5, §3.7 (`eq:BCmech`, `eq:secular`, `eq:rind`) |
| `analytical_derivations/` | ω→0 factorisation, A₁ identity, A₂ determinant, Rayleigh limit | §5.1, §3.7 (`eq:A1ident`, `eq:statfact`, `eq:detA2`, `eq:rayleigh`) |
| `validation/` | Complex-wavenumber method and limit-verification logic | §5.4–5.5 |
