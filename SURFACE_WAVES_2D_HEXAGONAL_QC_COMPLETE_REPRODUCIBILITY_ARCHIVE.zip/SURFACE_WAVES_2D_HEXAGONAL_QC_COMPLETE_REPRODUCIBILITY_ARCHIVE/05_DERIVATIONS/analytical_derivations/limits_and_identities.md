# Analytical checks and limits (transcription)

Source of truth: `02_OVERLEAF/main.tex` §3.7, §5 (`eq:A1ident`, `eq:statfact`, `eq:detA2`, `eq:rayleigh`).

## 1. ω → 0 factorisation (`eq:statfact`)

The static determinant factors into bulk electro-elastic, phason and thermal
factors; implemented as the symbolic identities `A0identity`/`A1identity` in
`solver/matrix.py` and re-checked exactly (rational arithmetic) by test V4.
Purpose: verify the static block structure is not coupled through error terms.

## 2. A1 identity (`eq:A1ident`) and A2 determinant (`eq:detA2`)

- `eq:A1ident`: the p¹ coefficient matrix satisfies an exact identity used to
  validate the entry-by-entry pencil assembly (implementation record §3.7).
- `eq:detA2`: det A2 = const × (phason coupling factor); when the phason
  inertia/elastic sector decouples, det A2 reduces to the pure piezoelectric
  (or pure elastic) value — the check that the pencil's leading block is exactly
  the expected one.

## 3. Classical Rayleigh limit (`eq:rayleigh`)

Decoupled elastic isotropic limit (piezoelectric/thermal/phason off):
the secular determinant reduces to the classical Rayleigh equation; the
nondimensional Rayleigh speed for ν = 1/3 is V_R* = 0.932525905921
(fixed, not fitted). Verified by test V2 and used as the reference line in Fig. 3.

## 4. Model limits (§5.2, tests V3)

- **C → B:** telegraph phason balance → diffusive balance as τ_tel → 0
  (D_w* → 0 at fixed ρ_w*, or ρ_w* → 0): the telegraph speed curve converges
  to the diffusive one. Archived end-point comparison in
  `03_DATA/raw/v3_model_limits.csv`.
- **C → A:** telegraph → inertial in the high-frequency/frozen-friction sense
  (documented in §5.2): the telegraph speed tends to the inertial-model speed
  in the corresponding limit. Both limits are computed over the full 121-point
  grid (test V3, ~14 min).

## 5. Complex-wavenumber check (§5.5)

Independent branch consistency: solve det B(k,ω) = 0 for complex k at fixed real
ω (Newton on the secular determinant from the real-axis root) and compare the
branch speed with the real-axis minimum and the complex-mode speed.
Method details: `06_VALIDATION/README_VALIDATION.md`; results: `04_REPRODUCTION/expected_outputs/EXPECTED_VALUES.md`.
