# Boundary conditions and secular determinant (transcription)

Source of truth: `02_OVERLEAF/main.tex` §3.4–3.5, §3.7 (`eq:BCmech`, `eq:secular`, `eq:rind`).

## The five surface rows (z = 0)

1–2. Mechanical traction-free: σ_zz = 0, σ_zx = 0 (canonical Rayleigh BCs).
3–4. Phason BC (two options, both studied):
   - **free:** H_zz = 0, H_zx = 0;
   - **clamped:** w_x = 0, w_z = 0.
5. Thermal (two options):
   - **isothermal:** θ = 0;
   - **insulated:** ∂_z θ = 0. With Lord–Shulman flux (q_z + τ0 q̇_z = 0 at the
     surface) this is implemented as the equivalent row ∂_z θ = 0 (§3.7
     implementation record). Model comparison baseline in the paper: isothermal.

## Boundary matrix and secular equation

- Substituting the root superposition Σ_j c_j (amplitude vector at p_j) into the
  five rows gives B(ω,k) c = 0 with B a 5×5 matrix (5 admissible roots → 5 unknowns).
- Nontrivial solution ⇔ det B = 0 (`eq:BCmech`).
- Numerical criterion (`eq:secular`): r = σmin(B)/σmax(B); minimise r in k
  (`eq:rind` states the equivalent indicator). Acceptance levels in
  `params.json` (`r_accept` = 1e-10; flags at 1e-8).

## Conditioning and penalties

cond₂(B) recorded per point (conditioning of the boundary solve); the BC study
(`fig7_*`) reports the free→clamped relative speed change dV/V and the
penetration-depth penalty dPen.
