# Governing equations and constitutive structure (transcription)

Source of truth: `02_OVERLEAF/main.tex` §2 (labels `eq:sxx`–`eq:symrels`, `eq:LS`).
This file is a navigation aid; read the paper for the equations themselves.

## 1. Field variables (§2.1)

- Elastic: displacement u = (u_x, u_z), strain ε_ij, stress σ_ij.
- Phason: phason displacement w = (w_x, w_z), phason strain k_ij = ∂_j w_i
  (2D hexagonal: w in the periodic plane), phason stress H_ij.
- Thermal: θ = T − T0 (linearised), heat flux q_i.
- Piezoelectric: electric displacement D_i, potential φ via E_i = −∂_i φ.

## 2. Balance laws (§2.1, §2.4)

- Momentum: σ_ij,j = ρ ü_i (quasi-static electric field; charge equation ∂_i D_i = 0).
- Phason balance — three models (§2.4):
  - **A (inertial):** H_ij,j = ρ_w ẅ_i (phason inertia).
  - **B (diffusive):** H_ij,j = −C_w ẇ_i (friction/mobility form; C_w = 1/D_w).
  - **C (telegraph):** H_ij,j + (τ0/D_w) Ḣ_ij,j = −(1/D_w) ẇ_i  (finite phason-relaxation
    time τ0; recovers B at τ0→0 and the inertial character at the high-frequency end).
- Heat (Lord–Shulman, §2.5, `eq:LS`): q_i + τ0 q̇_i = −k_ij T_,j and the linearised
  energy balance T0 β1 ε̇_kk + c_e θ̇ = −q_i,i (plus the analogous phason term where
  present in the coupling set).

## 3. Constitutive relations (§2.2–2.3, `eq:sxx`…`eq:hxz`)

- σ_ij = C_ijkl ε_kl − e_kij E_k − β_i θ δ_ij-type thermal stress terms.
- H_ij = K_ijkl k_kl − (thermal/phason couplings as in `eq:hxx`–`eq:hzx`).
- D_i = e_ijk ε_jk + κ_ij E_j (piezoelectric displacement).
- **Constitutive asymmetry (documented, intentional):** the 2D hexagonal
  phason sector has H_xz ≠ H_zx in the convention used; the extra K3 p² term
  appears in the w_x row of the matrix polynomial (implementation record §3.7).
  This asymmetry is part of the adopted model; it is NOT a typo (audit-verified).

## 4. Symmetry relations (§2.2, `eq:symrels`)

- 2 C66 = C11 − C12; K6 = K1 − K2 − K3; 2 R6 = R1 − R2
  (used to derive the C66, K6, R6 table entries from independent constants).

## 5. Parameter provenance (see `04_REPRODUCTION/parameter_manifest.json`)

Labels: composite table (wang2020 = li2017 Table 1); frozen symmetry relations;
SURROGATE (ρ, c_e — declared); DECLARED identifications (ρ_w = ρ; τ0 swept;
k11 = 6 W/(m K), discrepancy with li2017's 5.3 noted in the paper);
D_w = 1/C_w with C_w = 4.8e-19 m³ s/kg from chellappan2015.
