# Nondimensionalization (transcription)

Source of truth: `02_OVERLEAF/main.tex` §4 (`eq:scales`, `eq:starred`, `eq:omegac`).

## Scales (`eq:scales`)

| Scale | Definition | Value |
|---|---|---|
| v0 | √(C11/ρ) | 6917.1446 m/s |
| ω0 | Dw k0²/ρw, Dw = 1/Cw, k0 = 2π×10⁶ m⁻¹ | 4.34617×10¹⁰ s⁻¹ (f0 ≈ 6.917 GHz) |
| k0 | reference wavenumber (λ = 1 μm) | 2π×10⁶ m⁻¹ |

σ0 = C11 U0 k0 = β1 T0 (dual stress/thermal-stress scale), electric potential scale
U0 and the choices β1*=1, c_e*=1, T0β1*=2.3047e-3, k11*=0.0026077 are the
"frozen nondimensionalization" targets (see `parameter_manifest.json`).

## Starred system (`eq:starred`)

Every term of the governing system is divided by the scales; the result is the
dimensionless system actually solved. Controlling dimensionless groups:

- Ω* = ω/ω0 (frequency), k* = k/k0 (wavenumber), V* = ω/(k v0).
- Phason friction D_w* (=Dw/Dw_scale; Study-2 grid 1e-2 … 1e4, 61 log points), phason mass density ratio ρ_w*.
- Thermal relaxation τ0* = τ0/τ0_scale (grid 1e-5 … 1e-1); Ωc = Dw*/ρ_w* (`eq:omegac`);
  telegraph τ_tel = 2ρ_w*/Dw*.
- Piezoelectric coupling e* (R1*,R2*), thermal coupling β*.

## Derived relations

- Band mapped: f = 6.92 MHz … 6.92 THz (f/f0 = 1e-3 … 1e3); the characteristic
  thermal frequency fc ≈ 79.3 THz lies above the mapped band.
- Dimensional endpoints (λ, penetration depth) are tabulated in the manuscript
  (`tab:dim`) from the products V*·(ω0/k0) and δ*·k0⁻¹.

## Consistency check

Test `tests/V5/test_V5_nondim.py` re-derives the starred system symbolically
from the dimensional one and compares coefficients; expected residual 0
(exact rational arithmetic via sympy for the pure-elastic subset) — see
`04_REPRODUCTION/expected_outputs/EXPECTED_VALUES.md`.
