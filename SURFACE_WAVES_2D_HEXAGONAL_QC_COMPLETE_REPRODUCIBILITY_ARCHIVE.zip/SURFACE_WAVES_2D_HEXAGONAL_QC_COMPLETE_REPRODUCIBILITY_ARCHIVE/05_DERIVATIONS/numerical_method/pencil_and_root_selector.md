# Numerical method (transcription)

Source of truth: `02_OVERLEAF/main.tex` §3.1–3.3, §3.7 (`eq:decay`, `eq:Mpoly`).

## Plane-wave ansatz (§3.1)

u,w,φ,θ ∝ exp(i k (p z + x) − i ω t): depth dependence e^{ikpz}, p = complex
depth root. Substitution gives the 4-field (×2 for the phason pair) amplitude
system.

## Matrix polynomial (§3.2, `eq:Mpoly`)

M(p) = A0 + p A1 + p² A2 (entries explicitly listed in §3.7). A2 is singular
(mechanical/piezoelectric leading structure); `eq:A1ident` and `eq:detA2` record
the identities used. det M(p) = 0 is the depth-root condition.

## Depth-root solver (§3.3, `eq:decay`)

1. Companion linearisation: eigenvalues of the 10×10 companion matrix of det M.
2. Two Newton polish steps on det M for each eigenvalue.
3. Admissibility: Im p > tol·max(1,|p|), tol = 1e-10 (params.json
   `solver_defaults.admissibility_tol`) → decaying e^{ikpz} for k>0.
4. Grazing classification: |Im p| ≤ tol → recorded, never used in B.
5. Per-root residual flag: σmin(M)/σmax(M) > 1e-8.

Accepted physical points have exactly 5 admissible roots (one grazing/decoupled
configuration is documented in the manuscript: fixed-reference scan of model A).

## Eigenvectors and amplitudes

Null vectors of M(p) at each root via unit-norm SVD; amplitude participation
P_w = (|a_wx|²+|a_wz|²)/Σ|a_i|² (§ diagnostics); penetration depth
δ* = 1/|min Im p| (weighted variant in the raw data columns).

## Branch tracking (§3.6)

- Global log-scan of Ω* (n_scan = 160 points; sub-scans at bulk-grazing
  wavenumbers to avoid crossing artefacts), seeding k from neighbours.
- Local refinement: bounded minimisation of r = σmin(B)/σmax(B) in k
  (Brent xtol=1e-12; production rel_xtol as recorded).
- Continuation-preferred selection with staleness guard; jump diagnostic flags
  unexplained V* changes > 5% between neighbouring Ω* points (branch-jump bug
  guards — the failed candidate is retried from other seeds before acceptance).
- Acceptance statuses: `accepted` (r ≤ 1e-10), `resolved_min` (minimum found but
  r above that level), `no_branch`, plus explicit degenerate-cutoff records.

## Resolution benchmark (§3.8 / `solver/resolution.py`)

u_V = |V(n_scan) − V(3·n_scan)| at identical tolerances; ε_Δ = 10·max(u_V).
Archived values: u_V ≤ 1.13e-9 → ε_Δ = 1.13e-8 (absolute V units).
