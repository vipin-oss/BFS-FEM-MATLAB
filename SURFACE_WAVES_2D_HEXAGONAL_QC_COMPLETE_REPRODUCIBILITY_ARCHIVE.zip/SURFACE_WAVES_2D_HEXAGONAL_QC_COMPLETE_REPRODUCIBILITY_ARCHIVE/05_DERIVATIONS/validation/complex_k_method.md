# Complex-wavenumber verification method (transcription)

Source of truth: `02_OVERLEAF/main.tex` §5.5 + `06_VALIDATION/validation_scripts/complex_k_check.py`.

## Method

1. Pick (model, Ω*) anchors: models A, B, C at Ω* = 0.1, 10, 1e3 (baseline) and
   models B, C at Ω* = 1, 100 with D_w* = 0.01 (friction variant) — 13 points.
2. At each anchor take the real-axis solution (k_r from the production solver).
3. Solve det B(k, ω) = 0 for complex k by Newton iteration seeded at k_r,
   evaluating B from the same 5×5 assembly (complex-arithmetic safe).
4. Record:
   - complex-mode speed: ω/Re(k)·(k0/ω0) vs the real-axis V* — relative speed
     difference;
   - attenuation per wavelength: Im(k)/Re(k)·2π;
   - boundary-condition stability: |Δ_BC(complex k) − Δ_BC(real k)| using the
     free/clamped pair at the same complex k.

## What it verifies

The production pipeline solves the real-k minimum of r; this check bounds the
physical error of that estimator (speed error, attenuation per wavelength) and
confirms the model-comparison statistic Δ_BC is stable under the substitution.

## Archived evidence

- `06_VALIDATION/validation_results/complex_k_dispersion.log` (13 rows).
- Re-run: `PYTHONPATH=01_PROGRAM python3 06_VALIDATION/validation_scripts/complex_k_check.py`.
- The manuscript quotes the summary in §5.5 and tabulates the anchors in
  `tab:cxk`.
