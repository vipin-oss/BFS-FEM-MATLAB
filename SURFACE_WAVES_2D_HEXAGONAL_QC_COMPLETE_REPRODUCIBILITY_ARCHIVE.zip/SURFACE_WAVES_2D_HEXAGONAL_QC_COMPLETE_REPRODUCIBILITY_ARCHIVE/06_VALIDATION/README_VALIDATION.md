# 06_VALIDATION — benchmarks, validation scripts, results

## README_VALIDATION.md — validation record

| Check | Type | What it verifies | Evidence | Reproduced 2026-09-28? |
|---|---|---|---|---|
| V0 integrity | internal | solver identities, residual identity, resolution benchmark | `validation_results/V0_integrity_*.log`, `03_DATA/raw/resolution_bench.csv` | see `04_REPRODUCTION/expected_outputs/REPRODUCTION_REPORT.md` |
| V1 two-path | internal | ω→k vs k→ω path independence at 15 anchors (worst 9.35e-10) | `validation_results/V1_two_path_*.log` | same |
| V2 elastic limit | **benchmark** | decoupled elastic + classical Rayleigh (ν=1/3): V_R*=0.932525905921; V_A 0.310726890→0.310726616 | `validation_results/V2_elastic_limit_*.log`, `03_DATA/raw/v2_elastic_limit.csv` | same |
| V3 model limits | **benchmark** | telegraph→C (D_w*→0/1e-14) and diffusive→A (ρ_w*→0) over full 121-pt grid | `validation_results/V3_model_limits_*.log`, `03_DATA/raw/v3_model_limits.csv` | same |
| V4 symbolic | internal | exact rational identities (A0/A1/ω→0 factorisation), symmetry relations | `validation_results/V4_symbolic_*.log` | same |
| V5 nondim | internal | dimensional→starred consistency | `validation_results/V5_nondim_*.log` | same |
| invariants (22) | internal | science-preservation invariants of the production solver | `validation_results/invariants_*.log` + `01_PROGRAM/verification/reports/INVARIANT_CHECK.md` | same |
| complex-k | **benchmark** | real-axis estimator error: speed ≤6.6e-7 rel (A ≤2.5e-10); attenuation ≤7.0e-4/λ (A ≤3.1e-7); Δ_BC shift ≤8.0e-10 | `validation_results/complex_k_dispersion.log` | yes (regenerated) |
| literature benchmark | **benchmark** | benchmark table reproduction (published values) | `benchmark_data/*`, `benchmark_sources/SELECTED_BENCHMARK.md`, driver `validation_scripts/LITERATURE_BENCHMARK_DRIVER.py` | NOT REPRODUCED in the 2026-09-28 rerun (historical record retained; see note below) |

## Benchmark sources (source papers and DOIs)

Classical benchmarks used in the manuscript:

1. **Classical Rayleigh wave, isotropic elastic half-space** — classical result
   (Lord Rayleigh 1885) as reproduced in standard texts; the paper uses the
   ν = 1/3 nondimensional value V_R* = 0.932525905921 derived from the classical
   secular equation (no external data file needed; see
   `benchmark_sources/PUBLISHED_EQUATIONS.md`). Classical result — no DOI required.
2. **E. Agiasofitou & M. Lazar, "The elastodynamic model of wave-telegraph type
   for quasicrystals"** — Int. J. Solids Struct. 51(5), 923–929 (2014).
   DOI 10.1016/j.ijsolstr.2013.11.016 (arXiv:1311.5095).
   (Source of the wave-telegraph phason model (model C); limit relations
   C→A/C→B are the asymptotic cases of this unified model.)
3. **V. Chellappan, S. Gopalakrishnan & V. Mani, "Wave propagation of phonon and
   phason displacement modes in quasicrystals: Determination of wave parameters"** —
   J. Appl. Phys. 117, 054905 (2015). DOI 10.1063/1.4907212.
   (Source of the phason-friction parameter C_w = 4.8e-19 m³ s/kg, eq. (3) + p. 8.)
4. **B. Zhang, H. Tu, L. Li, J. Yu & J. Dai, "Rayleigh Waves Propagating in the
   Functionally Graded One-Dimensional Hexagonal Quasicrystal Half-Space"** —
   Crystals 13(8), 1205 (2023). DOI 10.3390/cryst13081205.
   (Hexagonal QC Rayleigh-wave context.)
5. **M. de Boissieu**, Chem. Soc. Rev. 41(20), 6778–6786 (2012).
   DOI 10.1039/C2CS35212E. (Phason dynamics review — diffusive vs propagative.)
6. **Françoual et al.**, Phys. Rev. Lett. 91, 225501 (2003).
   DOI 10.1103/PhysRevLett.91.225501. (Phason dynamics in i-AlPdMn — diffusive.)
7. **Yang, Ding, Wang & Hu**, Phys. Rev. B 49(18), 12656–12661 (1994).
   DOI 10.1103/PhysRevB.49.12656. (Generalized elasticity theory of QCs — inertial/propagative phasons.)
8. **Dev, Sladek & Stevens (2025)** — reference parameter set (transverse-isotropic
   QC half-space; in-plane phason-free surface-wave baseline). Full citation:
   NOT DOCUMENTED in the archived metadata beyond the label "Dev/Sladek/Stevens (2025)"
   (the parameter table's declared source). A researcher extending this work should
   locate it via the parameter table's declaration.

> **Honesty note.** The manuscript states the transverse-isotropic limit
> "relates to the in-plane phason-free surface waves of Dev/Sladek/Stevens
> (2025) (the correspondence is directional, not exact)". No quantitative
> claim against that paper is made; the complex-k and limit checks are the
> quantitative validation of this work.

## What was NOT reproduced (2026-09-28 rerun)

- The literature benchmark comparison (`benchmark_data/LITERATURE_REPRODUCTION_COMPARISON.csv`,
  figures `validation_figures/benchmark_*.pdf`) was produced in the historical
  campaign and is archived as evidence. Re-running
  `validation_scripts/LITERATURE_BENCHMARK_DRIVER.py` was NOT part of the final
  reproduction test (it depends on external literature values encoded in the
  benchmark CSVs, not on the production solver). Its integrity is protected by
  the SHA-256 manifests.
- No experimental data exist for this project; all comparisons to experiment are
  NOT APPLICABLE.

## Layout

| Folder | Content |
|---|---|
| `benchmark_sources/` | `SELECTED_BENCHMARK.md`, `PUBLISHED_EQUATIONS.md`, `CANDIDATE_PAPERS.md`, `MISSING_INFORMATION_LEDGER.csv`, `literature/` (bib + missing-PDF record) |
| `benchmark_data/` | `INDEPENDENT_REPRODUCTION_RESULTS.csv`, `LITERATURE_REPRODUCTION_COMPARISON.csv`, `LITERATURE_BENCHMARK_PARAMETERS.csv` |
| `validation_scripts/` | `complex_k_check.py`, `LITERATURE_BENCHMARK_DRIVER.py` (V0–V5 live in `01_PROGRAM/tests/`) |
| `validation_results/` | archived logs of every validation run (V0–V5, invariants, complex-k) |
| `validation_figures/` | benchmark comparison figures (historical) |
