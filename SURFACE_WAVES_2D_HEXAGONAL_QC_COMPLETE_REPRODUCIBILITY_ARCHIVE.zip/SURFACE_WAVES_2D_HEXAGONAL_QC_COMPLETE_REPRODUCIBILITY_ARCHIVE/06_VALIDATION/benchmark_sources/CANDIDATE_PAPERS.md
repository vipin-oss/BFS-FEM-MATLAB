# CANDIDATE_PAPERS.md

# Systematic Literature Search & Benchmark Candidate Inventory
## Research Area: Surface Waves and Wave Propagation in Quasicrystals and Anisotropic Media

This inventory records 10 published candidate papers evaluated for numerical reproduction and benchmark validation against the present 2D hexagonal piezoelectric thermoelastic quasicrystal surface-wave framework.

---

## Candidate Papers Evaluation Matrix

### CAND-01: Rayleigh waves propagating in the functionally graded one-dimensional hexagonal quasicrystal half-space
- **Authors:** Bo Zhang, Honghang Tu, Liangjuan Li, Jiangong Yu, Jun Dai
- **Citation:** *Crystals* **13** (2023) 1205; DOI: `10.3390/cryst13081205`
- **Physical Model:** 1D Hexagonal QC, Bak elastodynamic model (Model A phason inertia)
- **Geometry & Dimensionality:** Half-space (x-z plane, depth decay in z, propagation in x)
- **Crystallographic Symmetry:** 1D Hexagonal (point group 6mm / 6/mmm)
- **Material System:** QC1 (Al-Cu-Li / Al-Pd-Mn composite) and QC2
- **Boundary Conditions:** Traction-free surface: Tzz = Txz = Hzz = 0 at z = 0
- **Quantity Plotted / Reported:** Phase velocity v_ph vs wavenumber k; displacement depth profiles U(z), W(z), gamma(z)
- **Numerical Values Available:** YES (Table 2, Table 3 exact numbers; Figs 2, 3, 4, 5)
- **Exact Parameters Available:** YES (Table 1: complete Cij, Ki, Ri, rho values)
- **Reproducibility Status:** YES (Exact tabular numbers + digitized dispersion curves)
- **Hierarchy Classification:** `TIER 2 (Quasicrystal Rayleigh Wave Half-Space Benchmark)`
- **Verdict:** **SELECTED FOR FULL NUMERICAL REPRODUCTION**

### CAND-02: A coupled Legendre-Laguerre polynomial method with analytical integration for the Rayleigh waves in a quasicrystal layered half-space with an imperfect interface
- **Authors:** Bo Zhang, Honghang Tu, Weiqiu Chen, Jiangong Yu, L. Elmaimouni
- **Citation:** *Applied Mathematics and Mechanics (English Edition)* **45** (2024) 1539-1556; DOI: `10.1007/s10483-024-3145-8`
- **Physical Model:** 1D Hexagonal QC layered half-space (Bak model + spring interface)
- **Geometry & Dimensionality:** Layered half-space (coating thickness h, substrate z > h)
- **Crystallographic Symmetry:** 1D Hexagonal
- **Material System:** QC1 coating on QC2 substrate; Brass 62 on Steel 3 (validation)
- **Boundary Conditions:** Traction-free surface at z = 0; imperfect/perfect interface at z = h
- **Quantity Plotted / Reported:** Phase velocity v_ph vs kh; displacement and stress distributions
- **Numerical Values Available:** YES (Table 3 exact phase velocity values; Fig 2 validation curve)
- **Exact Parameters Available:** YES (Table 1: complete material constants)
- **Reproducibility Status:** YES (Exact tabular numbers + Fig 2 curve)
- **Hierarchy Classification:** `TIER 2 (QC Layered Half-Space Benchmark)`
- **Verdict:** **SELECTED FOR CROSS-VALIDATION**

### CAND-03: Wave propagation of phonon and phason displacement modes in quasicrystals: determination of wave parameters
- **Authors:** Vinita Chellappan, S. Gopalakrishnan, V. Mani
- **Citation:** *Journal of Applied Physics* **117** (2015) 054905; DOI: `10.1063/1.4907212`
- **Physical Model:** Bulk wave dynamics in 1D and 2D quasicrystals with phason diffusion and wave equations
- **Geometry & Dimensionality:** 1D / 2D bulk propagation
- **Crystallographic Symmetry:** Hexagonal and Icosahedral
- **Material System:** Al-Pd-Mn / Al-Cu-Li
- **Boundary Conditions:** Infinite medium (unbounded)
- **Quantity Plotted / Reported:** Dispersion relations, phase velocity vs frequency, attenuation
- **Numerical Values Available:** YES (Phason mobility C_w = 4.8e-19 m^3 s/kg source)
- **Exact Parameters Available:** YES (Elastic, phason, and coupling parameters)
- **Reproducibility Status:** YES (Bulk wave dispersion)
- **Hierarchy Classification:** `TIER 3 (Bulk Phason Dynamic Parameter Benchmark)`
- **Verdict:** **SELECTED AS PHYSICAL MOBILITY SOURCE BENCHMARK**

### CAND-04: The elastodynamic model of wave-telegraph type for quasicrystals
- **Authors:** E. C. Agiasofitou, M. Lazar
- **Citation:** *International Journal of Solids and Structures* **51** (2014) 923-929; DOI: `10.1016/j.ijsolstr.2013.11.016`
- **Physical Model:** Wave-telegraph continuum mechanics unification (tau d^2w/dt^2 + dw/dt = C_w div H)
- **Geometry & Dimensionality:** Theoretical continuum framework
- **Crystallographic Symmetry:** General Quasicrystalline Classes
- **Material System:** Theoretical formulation
- **Boundary Conditions:** N/A (Continuum PDEs)
- **Quantity Plotted / Reported:** Dispersion relation, characteristic speeds, telegraph relaxation time
- **Numerical Values Available:** YES (Analytical dispersion relations)
- **Exact Parameters Available:** YES (Symbolic parameter relationships)
- **Reproducibility Status:** YES (Mathematical operator mapping verified in Phase 3)
- **Hierarchy Classification:** `TIER 3 (Theoretical Dynamic Formulation Benchmark)`
- **Verdict:** **VERIFIED AS THEORETICAL DYNAMIC FOUNDATION**

### CAND-05: Fundamental solutions in a half space of two-dimensional hexagonal quasicrystal and their applications
- **Authors:** T. Wang, X. Y. Li, X. Zhang, R. Müller
- **Citation:** *Journal of Applied Physics* **117** (2015) 154904; DOI: `10.1063/1.4918535`
- **Physical Model:** Static 2D Hexagonal QC half-space (Boussinesq and Cerruti problems)
- **Geometry & Dimensionality:** Half-space z > 0
- **Crystallographic Symmetry:** 2D Hexagonal (Laue class 10)
- **Material System:** 2D Hexagonal QC constants
- **Boundary Conditions:** Prescribed point force at z = 0; traction-free surface otherwise; phason traction free
- **Quantity Plotted / Reported:** Green's functions, displacement and stress fields
- **Numerical Values Available:** YES (Closed-form analytical expressions)
- **Exact Parameters Available:** YES (2D Hexagonal QC parameters)
- **Reproducibility Status:** YES (Static limit)
- **Hierarchy Classification:** `TIER 2 (2D Hexagonal Static Half-Space Benchmark)`
- **Verdict:** **VERIFIED FOR 2D HEXAGONAL STATIC BC PRECEDENT**

### CAND-06: Three-dimensional fundamental thermo-elastic field in an infinite space of two-dimensional hexagonal quasi-crystal with a penny-shaped/half-infinite plane crack
- **Authors:** X.-Y. Li, Y.-W. Wang, P.-D. Li, G.-Z. Kang, R. Müller
- **Citation:** *Theoretical and Applied Fracture Mechanics* **88** (2017) 18-30; DOI: `10.1016/j.tafmec.2016.11.005`
- **Physical Model:** 3D Thermoelasticity of 2D Hexagonal QC
- **Geometry & Dimensionality:** 3D infinite space with crack
- **Crystallographic Symmetry:** 2D Hexagonal (Laue class 10)
- **Material System:** 2D Hexagonal QC thermoelastic parameter table
- **Boundary Conditions:** Crack face temperature/traction
- **Quantity Plotted / Reported:** Stress intensity factors, temperature and displacement fields
- **Numerical Values Available:** YES (Analytical and tabulated parameters)
- **Exact Parameters Available:** YES (Primary source of composite material table C11..R2 in Table 1)
- **Reproducibility Status:** YES (Static thermoelastic limit)
- **Hierarchy Classification:** `TIER 2 (2D Hexagonal Material Parameter Source)`
- **Verdict:** **VERIFIED AS MATERIAL PARAMETER SOURCE**

### CAND-07: General solutions for three-dimensional thermoelasticity of two-dimensional hexagonal quasicrystals and an application
- **Authors:** Lianzhi Yang, Liangliang Zhang, Fan Song, Yang Gao
- **Citation:** *Journal of Thermal Stresses* **37** (2014) 363-379; DOI: `10.1080/01495739.2013.869149`
- **Physical Model:** 3D Thermoelasticity of 2D Hexagonal QC
- **Geometry & Dimensionality:** 3D space / crack geometry
- **Crystallographic Symmetry:** 2D Hexagonal (Laue class 10, point group 6/mmm)
- **Material System:** 2D Hexagonal QC
- **Boundary Conditions:** Prescribed temperature on crack surface
- **Quantity Plotted / Reported:** Quasi-harmonic potential functions, displacement and thermal stresses
- **Numerical Values Available:** YES (Analytical closed-form solutions)
- **Exact Parameters Available:** YES (Constitutive equations (1)-(3))
- **Reproducibility Status:** YES (Constitutive equations audited in Phase 2)
- **Hierarchy Classification:** `TIER 2 (Constitutive Formulation Benchmark)`
- **Verdict:** **VERIFIED AS CONSTITUTIVE BASELINE**

### CAND-08: Thermo-electric response in 2D hexagonal QC exhibiting piezoelectric effect
- **Authors:** W. Wang, C. Li, Y.-T. Zhou
- **Citation:** *ZAMM - Journal of Applied Mathematics and Mechanics* **101** (2021) e201900212; DOI: `10.1002/zamm.201900212`
- **Physical Model:** 2D Hexagonal Piezoelectric Thermoelastic QC
- **Geometry & Dimensionality:** 2D plane problem
- **Crystallographic Symmetry:** 2D Hexagonal (point group 6mm)
- **Material System:** Piezoelectric thermoelastic QC constants
- **Boundary Conditions:** Crack problem with electric/thermal loads
- **Quantity Plotted / Reported:** Field distributions, electric displacements
- **Numerical Values Available:** YES (Analytical representations)
- **Exact Parameters Available:** YES (Piezoelectric and dielectric tensor structure)
- **Reproducibility Status:** YES (Piezoelectric passivity in Configuration I audited in Phase 2)
- **Hierarchy Classification:** `TIER 2 (Piezoelectric Tensor Structure Source)`
- **Verdict:** **VERIFIED FOR PIEZOELECTRIC DECOUPLING PROOF**

### CAND-09: Free surface (Rayleigh) waves in anisotropic elastic half-spaces: the surface impedance method
- **Authors:** D. M. Barnett, J. Lothe
- **Citation:** *Proceedings of the Royal Society of London. Series A* **402** (1985) 135-152; DOI: `10.1098/rspa.1985.0111`
- **Physical Model:** Classical Stroh/Barnett-Lothe surface impedance method for anisotropic half-spaces
- **Geometry & Dimensionality:** Anisotropic Half-Space
- **Crystallographic Symmetry:** General Anisotropy
- **Material System:** Anisotropic crystals
- **Boundary Conditions:** Traction-free surface at z = 0
- **Quantity Plotted / Reported:** Surface impedance tensor Z(v), secular equation det Z = 0
- **Numerical Values Available:** YES (Existence proofs, subsonic Rayleigh velocity theorems)
- **Exact Parameters Available:** YES (General elasticity)
- **Reproducibility Status:** YES (Analytical secular equations)
- **Hierarchy Classification:** `TIER 4 (Anisotropic Surface Wave Framework Benchmark)`
- **Verdict:** **VERIFIED AS SURFACE IMPEDANCE BENCHMARK**

### CAND-10: A generalized dynamical theory of thermoelasticity
- **Authors:** H. W. Lord, Y. Shulman
- **Citation:** *Journal of the Mechanics and Physics of Solids* **15** (1967) 299-309; DOI: `10.1016/0022-5096(67)90024-5`
- **Physical Model:** Hyperbolic thermoelasticity with finite thermal wave speed (Lord-Shulman model)
- **Geometry & Dimensionality:** Half-space / 1D and 2D domains
- **Crystallographic Symmetry:** Isotropic / Anisotropic
- **Material System:** Thermoelastic materials with relaxation time tau_0
- **Boundary Conditions:** Thermal shock / step heating
- **Quantity Plotted / Reported:** Thermal wave speed v_T = sqrt(k11 / (rho c_e tau_0)), second sound propagation
- **Numerical Values Available:** YES (Analytical hyperbolic heat equations)
- **Exact Parameters Available:** YES (Relaxation time tau_0 formulation)
- **Reproducibility Status:** YES (Lord-Shulman equation audited in Phase 4)
- **Hierarchy Classification:** `TIER 4 (Hyperbolic Thermoelasticity Benchmark)`
- **Verdict:** **VERIFIED AS LORD-SHULMAN MODEL BENCHMARK**
