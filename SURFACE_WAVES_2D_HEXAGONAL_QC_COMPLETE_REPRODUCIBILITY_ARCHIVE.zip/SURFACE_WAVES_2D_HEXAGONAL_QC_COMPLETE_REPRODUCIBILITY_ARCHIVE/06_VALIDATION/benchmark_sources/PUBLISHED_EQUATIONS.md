# PUBLISHED_EQUATIONS.md

# Mathematical Formulation and Governing Equations Extract
## Primary Benchmark: Zhang et al. (2023), *Crystals* 13(8): 1205

---

## 1. Coordinate System & Geometry

- **Propagation Direction:** $x$-axis (along free surface $z = 0$).
- **Depth Direction:** $z$-axis (pointing into the half-space $z \ge 0$).
- **Transverse Direction:** $y$-axis (plane strain condition, $\partial/\partial y = 0, u_y = 0$).
- **Waveform:** Harmonic surface wave $\propto \exp[i(kx - \omega t)] = \exp[ik(x - c t)]$, where $k$ is the horizontal wavenumber, $\omega$ is angular frequency, and $c = \omega / k$ is phase velocity.

---

## 2. Published Constitutive Relations (Zhang et al. 2023, Eqs. 1–2)

For a 1D hexagonal quasicrystal with quasi-periodic direction along the $z$-axis:

### Phonon Stresses $\sigma_{ij}$:
$$\sigma_{xx} = C_{11} \frac{\partial u_x}{\partial x} + C_{13} \frac{\partial u_z}{\partial z} + R_1 \frac{\partial w_z}{\partial z}$$
$$\sigma_{zz} = C_{13} \frac{\partial u_x}{\partial x} + C_{33} \frac{\partial u_z}{\partial z} + R_2 \frac{\partial w_z}{\partial z}$$
$$\sigma_{xz} = C_{44} \left(\frac{\partial u_x}{\partial z} + \frac{\partial u_z}{\partial x}\right) + R_3 \frac{\partial w_z}{\partial x}$$

### Phason Stresses $H_{ij}$:
$$H_{zz} = R_1 \frac{\partial u_x}{\partial x} + R_2 \frac{\partial u_z}{\partial z} + K_1 \frac{\partial w_z}{\partial z}$$
$$H_{xz} = R_3 \left(\frac{\partial u_x}{\partial z} + \frac{\partial u_z}{\partial x}\right) + K_2 \frac{\partial w_z}{\partial x}$$

where:
- $u_x, u_z$: phonon displacement components in $x$ and $z$ directions.
- $w_z$: phason displacement component in $z$ direction.
- $C_{11}, C_{13}, C_{33}, C_{44}$: phonon elastic stiffness constants ($10^9\text{ N/m}^2$).
- $K_1, K_2$: phason elastic stiffness constants ($10^9\text{ N/m}^2$).
- $R_1, R_2, R_3$: phonon-phason coupling constants ($10^9\text{ N/m}^2$).

---

## 3. Published Dynamic Governing Equations (Zhang et al. 2023, Eqs. 3–5)

Using the Bak elastodynamic model with phason effective inertia:
$$\frac{\partial \sigma_{xx}}{\partial x} + \frac{\partial \sigma_{xz}}{\partial z} = \rho \frac{\partial^2 u_x}{\partial t^2}$$
$$\frac{\partial \sigma_{xz}}{\partial x} + \frac{\partial \sigma_{zz}}{\partial z} = \rho \frac{\partial^2 u_z}{\partial t^2}$$
$$\frac{\partial H_{xz}}{\partial x} + \frac{\partial H_{zz}}{\partial z} = \rho_w \frac{\partial^2 w_z}{\partial t^2}$$

where $\rho$ is mass density (kg/m$^3$) and $\rho_w$ is the phason dynamic density parameter.

---

## 4. Published Boundary Conditions (Zhang et al. 2023, Eq. 6)

At the traction-free surface $z = 0$:
$$\sigma_{zz}(x, z=0, t) = 0$$
$$\sigma_{xz}(x, z=0, t) = 0$$
$$H_{zz}(x, z=0, t) = 0$$

At infinite depth $z \to \infty$ (surface wave decay condition):
$$\lim_{z \to \infty} u_x(x, z, t) = 0, \quad \lim_{z \to \infty} u_z(x, z, t) = 0, \quad \lim_{z \to \infty} w_z(x, z, t) = 0$$

---

## 5. Dual Method Formulation for Reproduction

To ensure complete scientific rigor and hostile disproof validation, two complementary solution methods are executed:

### Method 1: Published Orthogonal Laguerre Polynomial Spectral Method (Zhang et al. 2023)
The displacements are expanded as:
$$u_x(x, z, t) = \sum_{m=0}^{M-1} U_m L_m(\alpha z) e^{-\alpha z / 2} e^{i(kx - \omega t)}$$
$$u_z(x, z, t) = \sum_{m=0}^{M-1} W_m L_m(\alpha z) e^{-\alpha z / 2} e^{i(kx - \omega t)}$$
$$w_z(x, z, t) = \sum_{m=0}^{M-1} \Gamma_m L_m(\alpha z) e^{-\alpha z / 2} e^{i(kx - \omega t)}$$
where $L_m(\xi)$ is the $m$-th Laguerre polynomial, $\alpha$ is the decay scale parameter, and $M$ is the truncation order.
Substituting into the weak form / Galerkin projection yields the generalized algebraic eigenvalue problem:
$$\left( \mathbf{K}(k) - \omega^2 \mathbf{M} \right) \mathbf{V} = 0$$
The phase velocity is obtained directly from the eigenvalues: $v_{\text{ph}} = \omega / k$.

### Method 2: Stroh Formalism / Partial Wave Secular Determinant Method
In a homogeneous half-space, substituting partial waves $\mathbf{u}(x,z,t) = \mathbf{A} \exp[i k (x + p z - c t)]$ into the equations of motion yields the sextic Christoffel polynomial:
$$\det \mathbf{\Gamma}(p, c) = 0$$
Selecting the three decay roots with $\text{Im}(p_n) > 0$ ($n = 1, 2, 3$), the total displacement is:
$$\mathbf{u}(x,z,t) = \sum_{n=1}^3 C_n \mathbf{A}^{(n)} \exp[i k p_n z] \exp[i k (x - c t)]$$
Substituting into the surface boundary conditions at $z = 0$ yields:
$$\mathbf{B}(c) \mathbf{C} = 0$$
The secular equation for Rayleigh wave phase velocity is:
$$\mathcal{S}(c) \equiv \det \mathbf{B}(c) = 0$$
Both methods are implemented in the independent benchmark driver `LITERATURE_BENCHMARK_DRIVER.py`.