# SELECTED_BENCHMARK.md

# Benchmark Ranking, Selection Rationale, and Validation Chain
## Hierarchy Classification and Formal Literature Grounding

---

## 1. Literature Hierarchy Classification

The 10 candidate papers identified in the systematic search are ranked into four rigorous tiers:

### Tier 1: Exact Direct Reproduction (Unified 2D Hexagonal Piezoelectric-Thermoelastic Quasicrystal Rayleigh Wave)
- **Availability Assessment:** **NONE IN PUBLISHED LITERATURE PRIOR TO THIS WORK.**
- **Scientific Justification:** Prior literature treats subsets of the fully coupled system:
  1. Hexagonal quasicrystal surface waves with phason inertia (Model A/Bak elastodynamics) without piezoelectricity or Lord-Shulman thermoelasticity (Zhang et al. 2023, 2024).
  2. Static 2D hexagonal quasicrystal elasticity and thermoelastic crack problems (Wang et al. 2015, Li et al. 2017, Yang et al. 2014).
  3. 2D hexagonal piezoelectric quasicrystal static crack problems (Wang et al. 2021).
  4. Bulk phason wave propagation and mobility determination (Chellappan et al. 2015, Agiasofitou & Lazar 2014).
  Therefore, no published external paper contains the simultaneous 7x7 unified matrix for 2D hexagonal piezoelectric-thermoelastic Rayleigh waves. Consequently, scientific integrity requires establishing an **unbroken, multi-tier benchmark validation chain** across Tier 2, Tier 3, and Tier 4.

### Tier 2: Quasicrystal Rayleigh Wave Half-Space & Layered Benchmarks (Primary Reproductions)
- **Primary Benchmark 1 (CAND-01):** **Zhang, Tu, Li, Yu, Dai (2023)**, *Crystals* 13(8): 1205.
  - *Physics:* Rayleigh surface waves in 1D hexagonal quasicrystal half-space with phonon-phason elastodynamic coupling (Bak model with phason inertia).
  - *Geometry:* Half-space $z \ge 0$, surface wave propagating in $x$-direction with exponential/polynomial depth decay in $z$.
  - *Boundary Conditions:* Traction-free surface ($T_{zz} = T_{xz} = H_{zz} = 0$ at $z = 0$) and radiation/decay condition as $z \to \infty$.
  - *Available Numerical Data:* Complete material parameter table (Table 1), exact numerical phase velocities for phonon-dominant and phason-dominant modes at $k = 0.5, 1.0, 2.0\text{ mm}^{-1}$ (Table 3), and dispersion curves (Figs 2-5).
  - *Role in Validation:* Direct numerical reproduction of quasicrystal Rayleigh wave phase velocities, dispersion behavior, and depth decay.

- **Primary Benchmark 2 (CAND-02):** **Zhang, Tu, Chen, Yu, Elmaimouni (2024)**, *Appl. Math. Mech.-Engl. Ed.* 45(9): 1539–1556.
  - *Physics:* Coupled Legendre-Laguerre polynomial method for Rayleigh waves in quasicrystal layered half-spaces and homogeneous validation.
  - *Geometry:* Coated half-space and homogeneous substrate limits.
  - *Available Numerical Data:* Brass/Steel classical benchmark curve (Fig 2) and QC phase velocity table (Table 3).
  - *Role in Validation:* Independent cross-method numerical benchmark.

- **Secondary Source Benchmarks (CAND-05, CAND-06, CAND-07, CAND-08):**
  - *Wang et al. (2015), Li et al. (2017), Yang et al. (2014), Wang et al. (2021)*.
  - *Role in Validation:* Grounding of exact 2D hexagonal constitutive tensor forms ($C_{11}, C_{12}, C_{13}, C_{33}, C_{44}$, $K_1, K_2$, $R_1, R_2$, $\beta_{ij}$, $e_{ijk}$, $\varepsilon_{ij}$) and verification that in Configuration I ($P$ along $x_3$, wave in $x_1-x_2$), in-plane piezoelectric coupling identically decouples ($e_{222}=e_{211}=0$).

### Tier 3: Bulk Dynamic & Phason Mobility Benchmarks
- **CAND-03 (Chellappan et al. 2015, *J. Appl. Phys.* 117: 054905):** Experimental/theoretical determination of phason mobility $C_w = 4.8 \times 10^{-19}\text{ m}^3\text{s/kg}$ and bulk phonon-phason wave speeds.
- **CAND-04 (Agiasofitou & Lazar 2014, *Int. J. Solids Struct.* 51: 923):** Wave-telegraph dynamic formulation proving equivalence between hyperbolic telegraph equations and parabolic diffusion in the limit $\tau \to 0$.

### Tier 4: Classical Anisotropic Surface Wave & Hyperbolic Thermoelasticity Benchmarks
- **CAND-09 (Barnett & Lothe 1985, *Proc. R. Soc. Lond. A* 402: 135):** Classical anisotropic surface impedance and secular determinant for pure elastic half-space ($v_R / c_T = 0.920959$ for Poisson ratio $\nu = 0.28$).
- **CAND-10 (Lord & Shulman 1967, *J. Mech. Phys. Solids* 15: 299):** Hyperbolic thermoelasticity foundation with finite thermal relaxation time $\tau_0$, proving thermal wave speed $v_T = \sqrt{k_{11}/(\rho c_e \tau_0)}$.

---

## 2. Benchmark Validation Chain Architecture

```
=========================================================================================================
                                  BENCHMARK VALIDATION CHAIN
=========================================================================================================
  [TIER 4: Classical Limits]
   * Barnett-Lothe (1985) Pure Elastic Rayleigh Wave: v_R = 2906.5 m/s (rel error < 1e-11)
   * Lord-Shulman (1967) Hyperbolic Thermoelasticity: finite v_T, hyperbolic thermal wavefront
                                        │
                                        ▼
  [TIER 3: Bulk Phason Dynamics & Material Parameters]
   * Chellappan et al. (2015): Phason mobility C_w = 4.8e-19 m^3 s/kg, bulk wave speeds
   * Agiasofitou & Lazar (2014): Wave-telegraph relaxation time tau = 1e-11 s
   * Li et al. (2017) / Yang et al. (2014): 2D Hexagonal QC stiffness & thermal expansion
                                        │
                                        ▼
  [TIER 2: Quasicrystal Rayleigh Wave Half-Space Benchmarks (PRIMARY NUMERICAL REPRODUCTION)]
   * Zhang et al. (2023) Crystals 13: 1205 (Half-space QC Rayleigh wave dispersion & modes)
     - Homogeneous QC1 & QC2 Rayleigh velocities (Table 3 reproduction)
     - Phonon-dominant and Phason-dominant mode dispersion curves (Figs 2-5)
     - Traction-free boundary condition exact matching
   * Zhang et al. (2024) AMM 45: 1539 (Layered QC half-space & Brass/Steel benchmark)
                                        │
                                        ▼
  [FULL UNIFIED MODEL: 2D Hexagonal Piezoelectric-Thermoelastic QC Rayleigh Wave]
   * Fully coupled 7x7 Stroh/surface-impedance system
   * Configuration I: Exact decoupling of out-of-plane and in-plane fields proven
   * Phason wave-telegraph dynamics + Lord-Shulman finite-speed heat conduction
=========================================================================================================
```

## 3. Selected Primary Benchmark Specification

For full independent numerical reproduction, **Zhang et al. (2023), *Crystals* 13(8): 1205** is selected as the primary benchmark because:
1. It solves the exact Rayleigh surface wave problem on a quasicrystal half-space with traction-free boundary conditions.
2. It provides complete, unambiguous material parameters for two distinct quasicrystal compositions (QC1 and QC2) as well as isotropic Aluminum (Al).
3. It provides explicit tabulated numerical phase velocities (Table 3) for multiple wavenumbers ($k = 0.5, 1.0, 2.0\text{ mm}^{-1}$) across both Phonon Modes and Phason Modes.
4. It provides published continuous dispersion curves (Figs 2, 3, 4, 5) allowing both discrete point and continuous curve error validation.
5. Its formulation uses the Laguerre polynomial spectral method, providing a completely independent numerical method against which our Stroh eigen-system and boundary secular solver can be compared.