# Missing Reference PDFs & Document Provenance

In accordance with scholarly copyright restrictions, third-party published copyrighted PDF papers are not distributed in this research package.

Below is the verified DOI and citation metadata for all primary reference papers:

| Citation Key | Primary Authors | Journal / Year | DOI / Source | Role in Present Work |
| :--- | :--- | :--- | :--- | :--- |
| `zhang2023cryst` | Zhang, B., Tu, H., Li, L., et al. | *Crystals* 13: 1205 (2023) | [10.3390/cryst13081205](https://doi.org/10.3390/cryst13081205) | Tier 2 precedent (Rayleigh waves in functionally graded 1D QC) |
| `zhang2024amm` | Zhang, B., Tu, H., Chen, W., et al. | *Appl. Math. Mech.-Engl. Ed.* 45: 1539 (2024) | [10.1007/s10483-024-3145-8](https://doi.org/10.1007/s10483-024-3145-8) | Tier 2 precedent (Rayleigh waves in layered 1D QC) |
| `zhang2025zamm` | Zhang, B., Tu, H., Li, L., et al. | *ZAMM* (2025) | [10.1002/zamm.70114](https://doi.org/10.1002/zamm.70114) | Related 1D QC Love/Rayleigh waves |
| `chellappan2015` | Chellappan, V., Gopalakrishnan, S., Mani, V. | *J. Appl. Phys.* 117: 054905 (2015) | [10.1063/1.4907212](https://doi.org/10.1063/1.4907212) | Bulk phonon-phason wave parameters and mobility |
| `agiasofitou2014` | Agiasofitou, E.C., Lazar, M. | *Int. J. Solids Struct.* 51: 923 (2014) | [10.1016/j.ijsolstr.2013.11.016](https://doi.org/10.1016/j.ijsolstr.2013.11.016) | Wave-telegraph phason dynamic model formulation |
| `barnett1985` | Barnett, D.M., Lothe, J. | *Proc. R. Soc. Lond. A* 402: 135 (1985) | [10.1098/rspa.1985.0111](https://doi.org/10.1098/rspa.1985.0111) | Classical surface-impedance method and Rayleigh secular equation |
| `lord1967` | Lord, H.W., Shulman, Y. | *J. Mech. Phys. Solids* 15: 299 (1967) | [10.1016/0022-5096(67)90024-5](https://doi.org/10.1016/0022-5096(67)90024-5) | Generalized dynamical theory of thermoelasticity |
| `li2017` | Li, X.-Y., Wang, Y.-W., et al. | *Theor. Appl. Fract. Mech.* 88: 18 (2017) | [10.1016/j.tafmec.2016.11.005](https://doi.org/10.1016/j.tafmec.2016.11.005) | 2D hexagonal QC thermoelastic material constants |
| `yang2014` | Yang, L., Zhang, L., Song, F., Gao, Y. | *J. Therm. Stresses* 37: 363 (2014) | [10.1080/01495739.2013.869149](https://doi.org/10.1080/01495739.2013.869149) | 3D thermoelasticity of 2D hexagonal quasicrystals |
| `wang2021` | Wang, W., Li, C., Zhou, Y.-T. | *ZAMM* 101: e201900212 (2021) | [10.1002/zamm.201900212](https://doi.org/10.1002/zamm.201900212) | Thermo-electric response in 2D hexagonal QC |
