import json, sys, math, csv
import numpy as np
sys.path.insert(0,'/home/user/SUBMISSION_PACKAGE/FINAL_SURFACE_WAVES_2D_HEXAGONAL_QC_RESEARCH_PACKAGE_SUBMISSION')
from solver import material as mat
par = json.load(open('/home/user/SUBMISSION_PACKAGE/FINAL_SURFACE_WAVES_2D_HEXAGONAL_QC_RESEARCH_PACKAGE_SUBMISSION/params.json'))

def detB(k, Omega, model, m, bc):
    from solver import roots as rt, boundary as bd
    rr = rt.depth_roots(k, Omega, model, m)
    if rr['n_ad'] != 5: return None, rr
    V = rr['V'].copy()
    for j in range(V.shape[1]):
        col=V[:,j]; imax=np.argmax(np.abs(col)); V[:,j]=col/(col[imax]/abs(col[imax]))
    B = bd.B_matrix(k, rr['p_ad'], V, m, bc)
    return np.linalg.det(B), rr

def newton_k(Omega, model, m, bc, k0, nmax=100):
    k=complex(k0); F,rr=detB(k,Omega,model,m,bc)
    if F is None: return None,'no-branch',None,None
    F0=F
    for it in range(nmax):
        h=1e-7*max(1.0,abs(k))
        Fp,_=detB(k+h,Omega,model,m,bc); Fm,_=detB(k-h,Omega,model,m,bc)
        if Fp is None or Fm is None: return None,'root-sel',None,None
        d=(Fp-Fm)/(2*h)
        if d==0: return None,'zeroder',None,None
        step=F/d; k=k-step; F,rr=detB(k,Omega,model,m,bc)
        if F is None: return None,'root-sel',None,None
        if abs(step)<=1e-14*abs(k): return k,'ok',abs(F0),abs(F)
    return k,'max-iter',abs(F0),abs(F)

bc={'phason':'free','thermal':'isothermal'}
rows=list(csv.DictReader(open('/home/user/SUBMISSION_PACKAGE/FINAL_SURFACE_WAVES_2D_HEXAGONAL_QC_RESEARCH_PACKAGE_SUBMISSION/results/raw/study1_baseline.csv')))
A={(r['model'],float(r['Omega'])):(float(r['k']),float(r['V'])) for r in rows}
print('=== baseline (Dw*=11467.5) ===')
tab={}
for model in ['A','B','C']:
    for Om in [0.1,10.0,1000.0]:
        ks,Vs=A[(model,Om)]
        k,st,F0,F1=newton_k(Om,model,mat.Material(par),bc,ks)
        kr,ki=k.real,k.imag
        tab[(model,Om)]=(ks,Vs,kr,ki)
        print('%s  %-7g  k*=%.10e  Rek=%.10e  Imk=%.4e  |V-V|/V=%.3e  att=%.3e  |F0|=%.2e->|F|=%.2e  %s'%(
            model,Om,ks,kr,ki,abs(Om/kr-Vs)/Vs,2*math.pi*ki/kr,F0,F1,st))
print()
for Om in [0.1,10.0,1000.0]:
    ksB,VB,kB,_=tab[('B',Om)]; ksC,VC,kC,_=tab[('C',Om)]
    dB=abs(VB-VC)/VC
    dCx=abs(Om/kB-Om/kC)/(Om/kC)
    print('Om=%-7g  Delta_BC real-axis=%.4e   complex-mode=%.4e   change=%.2e'%(Om,dB,dCx,abs(dB-dCx)))
print()
print('=== low friction (Dw*=0.01) spot check ===')
rows2=list(csv.DictReader(open('/home/user/SUBMISSION_PACKAGE/FINAL_SURFACE_WAVES_2D_HEXAGONAL_QC_RESEARCH_PACKAGE_SUBMISSION/results/raw/study2_map_incremental.csv')))
A2={(r['model'],float(r['Omega']),float(r['Dw'])):(float(r['k']),float(r['V'])) for r in rows2}
m2=mat.Material(par, overrides={'Dw':0.01}) if True else None
for model in ['B','C']:
    for Om in [1.0,100.0]:
        ks,Vs=A2[(model,Om,0.01)]
        k,st,F0,F1=newton_k(Om,model,m2,bc,ks)
        kr,ki=k.real,k.imag
        tab[(model,Om,0.01)]=(ks,Vs,kr,ki)
        print('%s  %-7g  k*=%.10e  Rek=%.10e  Imk=%.4e  |V-V|/V=%.3e  att=%.3e  %s'%(model,Om,ks,kr,ki,abs(Om/kr-Vs)/Vs,2*math.pi*ki/kr,st))
for Om in [1.0,100.0]:
    ksB,VB,kB,_=tab[('B',Om,0.01)]; ksC,VC,kC,_=tab[('C',Om,0.01)]
    dB=abs(VB-VC)/VC; dCx=abs(Om/kB-Om/kC)/(Om/kC)
    print('Om=%-7g Dw=0.01: Delta_BC real-axis=%.4e  complex-mode=%.4e  change=%.2e'%(Om,dB,dCx,abs(dB-dCx)))
