#!/usr/bin/env python3
"""
independent_zhang2024_driver.py
===============================
Independent Assessment & Reproduction Evaluation for:
  Zhang et al. (2024), Appl. Math. Mech.-Engl. Ed. 45(9): 1539-1556
  (DOI: 10.1007/s10483-024-3145-8)
  "A coupled Legendre-Laguerre polynomial method with analytical integration
   for the Rayleigh waves in a quasicrystal layered half-space with an imperfect interface"

SCIENTIFIC INTEGRITY & CLASSIFICATION STATUS:
  Status: NOT REPRODUCIBLE FROM PUBLISHED INFORMATION (CLASS C)
  
  Rationale:
  1. The publication introduces a coupled Legendre-Laguerre polynomial basis across an imperfect interface
     between a QC1 coating and QC2 substrate.
  2. Crucial implementation details required for exact numerical reconstruction are omitted:
     - The exact coordinate transformation and scaling parameters between Legendre and Laguerre domains.
     - The explicit algebraic form of the interface spring coupling matrix connecting the spectral blocks.
     - The regularization parameter for the imperfect interface traction jump.
  3. Under strict scientific integrity rules:
     - NO hardcoded phase velocities.
     - NO curve fitting / exponential approximations.
     - NO copying published values into calculated fields.
  4. Consequently, Zhang et al. (2024) Table 3 values are cataloged as discrete literature reference
     anchors, and independent numerical reproduction is declared NOT REPRODUCIBLE FROM PUBLISHED INFORMATION.
"""

import sys, os, math
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent

# =============================================================================
# 1. PUBLISHED MATERIAL CONSTANTS (Zhang et al. 2024 Table 1)
# =============================================================================
QC1_COATING = {
    'C11': 2.3433e11, 'C12': 5.741e10, 'C13': 6.663e10, 'C33': 2.3222e11, 'C44': 7.019e10,
    'K1': 1.2e11, 'K2': 2.4e10, 'R1': 8.846e8, 'R2': 8.846e8, 'R3': 8.846e8,
    'rho': 4186.0
}

QC2_SUBSTRATE = {
    'C11': 3.8e11, 'C12': 1.2e11, 'C13': 1.2e11, 'C33': 3.8e11, 'C44': 1.3e11,
    'K1': 1.8e11, 'K2': 5.0e10, 'R1': 1.3e9, 'R2': 1.3e9, 'R3': 1.3e9,
    'rho': 2370.0
}

# Published Table 3 comparison targets (cataloged as literature reference anchors)
PUBLISHED_TABLE3_ZHANG2024 = {
    '1st_phason': {5: 2.53637, 10: 2.43376, 20: 2.40419},
    '2nd_phason': {5: 3.71068, 10: 3.01252, 20: 2.56408},
    '1st_phonon': {5: 4.30451, 10: 3.81615, 20: 3.84074},
    '2nd_phonon': {5: 5.09893, 10: 4.11824, 20: 3.93713}
}

def run_independent_zhang2024():
    print("================================================================================")
    print("     INDEPENDENT REPRODUCTION EVALUATION: ZHANG ET AL. (2024)")
    print("================================================================================")
    print("Classification: NOT REPRODUCIBLE FROM PUBLISHED INFORMATION (CLASS C)")
    print("Reason: Omitted interface coupling matrix and coordinate domain transformations.\n")
    
    # Analytical physical limits:
    v_coat_shear = math.sqrt(QC1_COATING['C44'] / QC1_COATING['rho']) / 1000.0  # km/s
    v_sub_shear = math.sqrt(QC2_SUBSTRATE['C44'] / QC2_SUBSTRATE['rho']) / 1000.0  # km/s
    v_coat_phason = math.sqrt(QC1_COATING['K2'] / QC1_COATING['rho']) / 1000.0  # km/s
    v_sub_phason = math.sqrt(QC2_SUBSTRATE['K2'] / QC2_SUBSTRATE['rho']) / 1000.0  # km/s
    
    print("Physical Asymptotic Limiting Speeds:")
    print(f"  QC1 Coating Shear Speed:   {v_coat_shear:.3f} km/s | Phason Speed: {v_coat_phason:.3f} km/s")
    print(f"  QC2 Substrate Shear Speed: {v_sub_shear:.3f} km/s | Phason Speed: {v_sub_phason:.3f} km/s\n")
    
    results_summary = []
    
    for mode_name, kh_dict in PUBLISHED_TABLE3_ZHANG2024.items():
        print(f"--- Mode: {mode_name.replace('_', ' ').title()} ---")
        for kh_val, pub_v in kh_dict.items():
            print(f"  kh = {kh_val:2d}: Published = {pub_v:.5f} km/s | Calculated = [NOT REPRODUCIBLE - CLASS C]")
            results_summary.append({
                'Paper': 'Zhang2024',
                'Mode': mode_name,
                'k_or_kh': kh_val,
                'Published_km_s': pub_v,
                'Calculated_km_s': 'NOT_REPRODUCIBLE',
                'Abs_Error_m_s': 'N/A',
                'Rel_Error_Pct': 'N/A',
                'Status': 'NOT_REPRODUCIBLE_FROM_PUBLISHED_INFORMATION'
            })
        print()
        
    return results_summary

if __name__ == "__main__":
    run_independent_zhang2024()
