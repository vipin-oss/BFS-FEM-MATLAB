#!/usr/bin/env python3
"""
make_independent_figures.py
===========================
Generates publication-quality comparison figures for the independent literature benchmarks.
All paths resolve relatively from Path(__file__).
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from pathlib import Path

HERE = Path(__file__).resolve().parent
fig_dir = HERE / 'figures'
fig_dir.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    'font.size': 10,
    'font.family': 'sans-serif',
    'axes.labelsize': 11,
    'axes.titlesize': 11,
    'legend.fontsize': 9,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'lines.linewidth': 1.8,
    'lines.markersize': 6,
    'pdf.fonttype': 42,
    'ps.fonttype': 42
})

# =============================================================================
# FIGURE 1: INDEPENDENT ZHANG 2023 COMPARISON
# =============================================================================
fig1, ax1 = plt.subplots(figsize=(7, 4.5))

# Published Table 3 points
k_pub = np.array([0.5, 1.0, 2.0])
v_pub_phonon = np.array([2.912, 2.989, 3.121])
v_pub_phason = np.array([2.005, 1.994, 1.988])

# Independent Laguerre Spectral calculations (M=16)
v_calc_phonon = np.array([2.4515, 2.4518, 2.4519])
v_calc_phason = np.array([2.4080, 2.4080, 2.4081])

ax1.plot(k_pub, v_pub_phonon, 's-', color='#1f77b4', label='Published Phonon (Zhang 2023 Tab 3)')
ax1.plot(k_pub, v_pub_phason, 'o-', color='#ff7f0e', label='Published Phason (Zhang 2023 Tab 3)')
ax1.plot(k_pub, v_calc_phonon, 's--', color='#2ca02c', label='Independent Laguerre Phonon (M=16)')
ax1.plot(k_pub, v_calc_phason, 'o--', color='#d62728', label='Independent Laguerre Phason (M=16)')

ax1.set_xlabel(r'Wavenumber $k$ [$\mathrm{mm}^{-1}$]')
ax1.set_ylabel(r'Phase Velocity $v$ [$\mathrm{km/s}$]')
ax1.set_title('Independent Spectral Laguerre Reproduction: Zhang et al. (2023)', fontweight='bold')
ax1.grid(True, linestyle=':', alpha=0.6)
ax1.legend(frameon=True, facecolor='white', framealpha=0.9)
fig1.tight_layout()
fig1.savefig(fig_dir / 'independent_zhang2023_comparison.pdf')
plt.close(fig1)

# =============================================================================
# FIGURE 2: ZHANG 2024 REFERENCE BENCHMARKS & LIMITS
# =============================================================================
fig2, ax2 = plt.subplots(figsize=(7, 4.5))

kh_vals = np.array([5, 10, 20])
pub_1st_phason = np.array([2.53637, 2.43376, 2.40419])
pub_2nd_phason = np.array([3.71068, 3.01252, 2.56408])
pub_1st_phonon = np.array([4.30451, 3.81615, 3.84074])
pub_2nd_phonon = np.array([5.09893, 4.11824, 3.93713])

ax2.plot(kh_vals, pub_1st_phason, 'o-', color='#1f77b4', label='Pub 1st Phason (Table 3)')
ax2.plot(kh_vals, pub_2nd_phason, 's-', color='#ff7f0e', label='Pub 2nd Phason (Table 3)')
ax2.plot(kh_vals, pub_1st_phonon, '^-', color='#2ca02c', label='Pub 1st Phonon (Table 3)')
ax2.plot(kh_vals, pub_2nd_phonon, 'd-', color='#d62728', label='Pub 2nd Phonon (Table 3)')

# Asymptotic physical limits
ax2.axhline(2.395, color='#1f77b4', linestyle=':', label='QC1 Phason Speed (2.395 km/s)')
ax2.axhline(4.095, color='#2ca02c', linestyle=':', label='QC1 Shear Speed (4.095 km/s)')

ax2.set_xlabel(r'Nondimensional Wavenumber $kh$')
ax2.set_ylabel(r'Phase Velocity $v$ [$\mathrm{km/s}$]')
ax2.set_title('Layered QC Reference Anchors & Asymptotic Limits: Zhang et al. (2024)', fontweight='bold')
ax2.grid(True, linestyle=':', alpha=0.6)
ax2.legend(frameon=True, facecolor='white', framealpha=0.9, fontsize=8)
fig2.tight_layout()
fig2.savefig(fig_dir / 'independent_zhang2024_comparison.pdf')
plt.close(fig2)

print("Generated independent literature figures in", fig_dir)
