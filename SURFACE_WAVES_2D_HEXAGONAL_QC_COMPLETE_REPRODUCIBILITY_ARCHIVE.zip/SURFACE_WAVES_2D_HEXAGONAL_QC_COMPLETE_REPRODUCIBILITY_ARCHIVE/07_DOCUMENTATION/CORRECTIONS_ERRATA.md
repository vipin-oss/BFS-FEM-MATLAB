# Corrections & errata log (2026-09-28 submission build)

This log records every correction applied to the package between the
2026-09-08 archival build and the 2026-09-28 submission build. Each entry
gives: the claim as previously written, the corrected claim, and the data
evidence (all values recomputed from the archived raw data in
`05_RESULTS_RAW/raw/`, which is **unchanged** in this build).

The scientific results are unchanged: all corrections are to captions,
prose wording, or bibliography entries. The one regenerated figure (fig9)
changes only its z-axis framing (see C2); all other figures are
pixel-identical to the archived build (mean |pixel difference| = 0.000000
at 150 dpi).

---

## C1. Fig. 4(b) resolution crossing (major)

- **Was:** "the curve crosses unity only above $\Omega^*\approx6$" (fig4
  caption) and "$\Delta_{BC}$ … is below unity … up to $\Omega^*\approx6$"
  (§6.2).
- **Now:** "above $\Omega^*\approx50$–$56$".
- **Evidence:** from `fig4_deltas.csv`, $\Delta_{BC}/(2.42\times10^{-8})$ =
  0.987 at $\Omega^*=50.1$ and 1.242 at $\Omega^*=56.2$; the first grid
  point above unity is $\Omega^*=56.2$. At $\Omega^*=6.3$ the ratio is
  0.016 (far below unity).

## C2. Fig. 9 z-axis ranges (caption + code + regenerated figure)

- **Was:** caption quoted $[0.4650,0.4664]$ and $[0.4662,0.4674]$ as
  "exactly the data ranges"; the plotted z-limits were the rounded
  (visually clipped) pairs `(0.4650, 0.4664)`, `(0.4662, 0.4675)`.
- **Now:** caption quotes the exact data ranges
  $[0.464987,\,0.466301]$ ($V_B^*$) and $[0.466264,\,0.467355]$ ($V_C^*$);
  `make_all_figures.py` now sets the z-limits to the exact data min/max;
  `fig9.pdf` regenerated (5 copies kept in sync).
- **Evidence:** `fig9b_map_dBC.npz` / `study2_map_incremental.csv`:
  $V_B^*\in[0.464986632,\,0.466301231]$, $V_C^*\in[0.466263836,\,0.467354937]$.
  §6.4 range statement corrected to the same values.

## C3. Fig. 6(b)/§6.5 similarity-variable claim ($\tau_0^*\Omega^*$)

- **Was:** "for $\tau_0^*\Omega^*\gtrsim10^{-2}$ all five curves merge onto a
  single relaxation-controlled branch"; fig10 caption/text
  "i.e. $\tau_0^*\Omega^*\gtrsim1$"; §7.5 "significant only for
  $\tau_0^*\Omega^*\gtrsim1$".
- **Now:** $\tau_0^*\Omega^*$ organises the *onset* (first resolvable points
  at $\tau_0^*\Omega^*=1.3\times10^{-5}$–$1.4\times10^{-2}$, curve
  dependent); the two large-$\tau_0^*$ curves (which alone span
  $\tau_0^*\Omega^*\gtrsim1$) agree only within a factor $\sim2$–$4.5$ at
  matched $\tau_0^*\Omega^*$; the curves do **not** collapse onto a single
  similarity branch. $\tau_0^*\Omega^*$ is a useful organising coordinate,
  not an exact similarity variable.
- **Evidence:** `fig6_tau.csv`; log-log interpolation at matched
  $\chi=\tau_0^*\Omega^*$ gives
  $\Delta_T(0.1)/\Delta_T(10^{-2}) = 0.76,\,1.17,\,4.49,\,2.60,\,1.87,\,2.19$
  at $\chi = 0.03,\,0.1,\,0.3,\,1,\,3,\,10$.

## C4. Near-baseline thermal claim (§6.5, §7.5, Conclusions 5)

- **Was:** "Near the baseline $\tau_0^*=4.3462\times10^{-3}$ the effect is at
  or below the floor … not significant near baseline."
- **Now:** at the baseline itself $\Delta_T\equiv0$ by construction (it is
  the reference); the two nearest swept values bracket it —
  $\tau_0^*=10^{-4}$: $\max\Delta_T=1.1\times10^{-5}$;
  $\tau_0^*=10^{-2}$: $\max\Delta_T=2.9\times10^{-5}$, resolvable above
  $\Omega\approx1$ — so near baseline the effect is weak (order $10^{-5}$)
  but resolvable in the upper part of the frequency band.
- **Evidence:** `fig6_tau.csv`, `thermal` columns of the study-3 export:
  max $\Delta_T$ at $\tau_0^*=10^{-2}$ is $2.9365\times10^{-5}$ = 1214× the
  floor $2.42\times10^{-8}$; at $10^{-4}$, $1.0748\times10^{-5}$.

## C5. Interference-node count (§6.5, fig6 caption)

- **Was:** "Section 5 records 17–30 sign reversals per curve"; caption
  "the sharp dips are interference nodes where $\Delta_T$ changes sign".
- **Now:** "11–19 resolved interference nodes per curve in the archived
  grid"; "$\Delta_T$ is the absolute relative value, so a node appears as a
  dip toward zero" (the signed difference is not archived; the CSV stores
  $|\Delta V|/V$).
- **Evidence:** strict local minima of $\Delta_T(\Omega)$ per curve in
  `fig6_tau.csv`: 19, 18, 15, 11 (for $\tau_0^*=10^{-5},10^{-4},10^{-2},
  10^{-1}$). The earlier "17–30" figure is an internal audit diagnostic
  (`08_AUDITS/FINAL_FIGURE_AUDIT.md`, F3) whose exact counting rule is not
  specified; the reproducible count is quoted instead.

## C6. Fig. 5(b) maximum location

- **Was:** "maximum $\approx5.0\times10^{-3}$ at $D_w^*=1$".
- **Now:** "maximum $\approx5.0\times10^{-3}$ for $D_w^*\le1$".
- **Evidence:** map maxima are $4.9976\times10^{-3}$ at $D_w^*=10^{-2}$
  ($\Omega^*=46.4$) and $4.9959\times10^{-3}$ at $D_w^*=1$
  ($\Omega^*=100$); the strict maximum sits at $D_w^*=10^{-2}$.

## C7. Fig. 7 / §6.6 monotonicity wording

- **Was:** "|ΔV|/V growing monotonically from …", "likewise growing with
  $\Omega^*$".
- **Now:** "monotone above the resolution floor; 33 noise-level inversions
  confined to the sub-floor scatter below $\Omega^*\approx1.3$".
- **Evidence:** `fig7_bc_summary.csv`: 33 sign inversions of the slope, all
  at values $\le 3.28\times10^{-9} <$ floor $2.42\times10^{-8}$; the last
  is at $\Omega\approx1.26$; the curve is strictly increasing above the
  floor (first resolvable point $\Omega\approx20$).

## C8. §3.5 conditioning and residual floors

- **Was:** "$\kappa(B)$ (up to $\sim5\times10^8$ …) and the per-point
  residual floors ($10^{-11}$–$5.6\times10^{-6}$)".
- **Now:** "$\kappa(B)$ (up to $\sim5\times10^{10}$ at the most demanding
  points) and the per-point secular residual minima $r$
  ($\sim2\times10^{-11}$–$3.3\times10^{-5}$ over the production sweeps)".
- **Evidence:** `study1_baseline.csv`: $\max\kappa(B)=5.0568\times10^{10}$
  (model A, $\Omega=10^{-3}$); $r\in[1.98\times10^{-11},\,3.25\times10^{-5}]$
  (the same numbers appear in the study exports; the previous range
  $10^{-11}$–$5.6\times10^{-6}$ was a partial reading).

## C9. §5.3 singular-limit envelope (inverted statement)

- **Was:** "the ratio $\Omega/\Omega_c$ … grows without bound as
  $\Omega\to0$ at fixed small $D_w$".
- **Now:** "$\Omega/\Omega_c$ decays toward zero as $\Omega\to0$, so the
  singular-limit envelope $\Omega_c/\Omega$ grows without bound".
- **Evidence:** $\Omega/\Omega_c = \Omega\rho_w^*/D_w^*\to0$ as
  $\Omega\to0$; the envelope quoted in §5.2/fig2(b) is
  $\sim\Omega_c/\Omega$.

## C10. §6.1 $P_w$ and $\delta^*$ ranges (anchoring)

- **Was:** "$P_w$ between $1.7\times10^{-13}$ ($\Omega=0.1$) and
  $1.8\times10^{-5}$ ($\Omega=10^3$) … $\delta^*\approx12.9\to1.3\times10^{-3}$"
  (the $\delta^*$ pair corresponds to $\Omega=0.1\to10^3$ but sat in a
  sentence about the whole grid $\Omega=10^{-3}$–$10^3$).
- **Now:** "$P_w$ growing monotonically from $1.3\times10^{-17}$
  ($\Omega=10^{-3}$) to $1.8\times10^{-5}$ ($\Omega=10^3$) … $\delta^*=
  1.29\times10^{3}\to1.29\times10^{-3}$ over the grid
  ($\Omega\delta^*\approx1.29$)".
- **Evidence:** `study1_baseline.csv`: $P_w$ is monotone in $\Omega$
  (1.257×10⁻¹⁷ at 10⁻³ → 1.814×10⁻⁵ at 10³ for B; same for C);
  $\delta^*_B(10^{-3})=1292.0$, $\delta^*_B(10^{3})=1.2911\times10^{-3}$,
  $\Omega\delta^*=1.2920/1.2911$ (constant). §7.2 already carried the
  correct $P_w$ range $1.26\times10^{-17}$–$1.81\times10^{-5}$.

## C11. Fig. 8 root-pairing caption (wrong symmetry statement)

- **Was:** "the mirror symmetry about $\mathrm{Im}\,p=0$ reflects the
  real-coefficient depth problem."
- **Now:** "the roots pair exactly as $p\leftrightarrow-p$ (the depth
  polynomial is even in $p$; Section 3.3); the near-mirror appearance about
  $\mathrm{Im}\,p=0$ reflects the small dissipative parts and is not a
  conjugate-symmetry statement."
- **Evidence:** pairing test on `fig8_roots.csv`: worst relative
  $p\leftrightarrow-p$ mismatch $1.6\times10^{-9}$ (root-polish level);
  worst relative conjugate mismatch $1.44$ ($O(1)$). The depth polynomial
  is quadratic in $p^2$ (§3.3), hence even; with complex damping
  coefficients ($c_2,c_3,c_6$) conjugates are not roots.

## C12. Fig. 2(a) excluded record 0.934208 (dangling reference)

- **Was:** caption referenced "(open marker; Section 5.1)" but §5.1 never
  mentioned the record.
- **Now:** §5.1 explains the marker: an *excluded* exploratory coarse-scan
  record, a search-limited artefact (bracket did not resolve the narrow
  phason branch), superseded by the verified values and shown for
  transparency only.
- **Evidence:** `08_AUDITS/FINAL_FIGURE_AUDIT.md` (F5) documents the same
  provenance; the verified quasi-static ratios are $0.62145378$ (A) and
  $0.9326028$ (B/C) in `v2_elastic_limit.csv`.

## C13. Bibliography corrections (submission-critical)

1. **francoual2003 — wrong article, wrong title.** The entry cited
   "Phason fluctuations and the dynamical structuration of a quasicrystal,
   PRL 91, 225502 (2003)". The correct reference is
   *S. Francoual, F. Livet, M. de Boissieu, F. Yakhou, F. Bley,
   A. Létoublon, R. Caudron, J. Gastaldi, "Dynamics of phason fluctuations
   in the i-AlPdMn quasicrystal", Phys. Rev. Lett. **91**, 225501 (2003)*,
   DOI 10.1103/PhysRevLett.91.225501. (PRL 91, 225502 is an unrelated
   laser-ablation paper.) Corrected in the manuscript bibliography, both
   `FINAL_MANUSCRIPT.bib` copies, and both `09_LITERATURE/all_references.bib`
   copies.
2. **yang1994prb — incomplete entry.** Added the title
   "Group-theoretical derivation of the numbers of independent physical
   constants of quasicrystals", full pages 12656–12661, DOI
   10.1103/PhysRevB.49.12656, and corrected the author order to
   Yang, Ding, Wang, Hu.
3. **deboissieu2012 — missing pages.** Added pages 6778–6786 and DOI
   10.1039/C2CS35212E.
4. Removed the "page range not independently verified" / "As cited in …"
   audit-note text from the bibliography entries.

## C14. Figure-generation code comment

- Dangling comment reference `IMPLEMENTATION_AUDIT.md` →
  `08_AUDITS/FINAL_FIGURE_AUDIT.md` (F5) in `make_all_figures.py`
  (3 copies).

---

## Verified-correct items that were re-checked and NOT changed

- Rayleigh benchmark 0.932525905921 vs analytic 0.932525905931
  (rel. 1.1×10⁻¹¹); quasi-static ratios 0.62145378 / 0.9326028.
- Model-limit gates C(D_w*→10⁻¹⁴)→A, C(ρ_w*→10⁻⁸)→B: max |ΔV|/V =
  1.11×10⁻⁹ and 3.27×10⁻⁹; evidence curve meets 10⁻⁶ for Ω ≥ 0.3162
  (71/121 points), reaching 3.1×10⁻² at Ω=10⁻³ with envelope
  Ω_c/Ω (§5.2). The seed deviation 7.6×10⁻¹¹ quoted in §5.3 is correct
  (evidence curve vs model A at Ω=10³: 7.60×10⁻¹¹).
- 95/121 points below the floor 2.42×10⁻⁸ in fig4 (i.e. 26/121
  resolvable); 91/121 at 1.13×10⁻⁸; Δ_AC ≈ 0.334 constant;
  max Δ_BC/V = 9.5×10⁻⁶ at Ω=10³.
- Study-2 grid: 3721 points, resolvable windows (Ω ≥ 10⁻³ / 4.6×10⁻³ /
  0.46 / 46 at D_w* = 10⁻² / 1 / 10² / 10⁴), max Δ_BC = 4.9976×10⁻³.
- max Δ_T = 7.8794×10⁻⁵ at τ₀* = 10⁻¹ (3256× floor); clamped-phason
  max |ΔV|/V = 8.06×10⁻⁶; max |ΔPen|/Pen = 6.18×10⁻⁵.
- Penetration depths: Ωδ* = 1.9894 (A), 1.2911–1.2920 (B/C).
- fig8: n_ad = 5, n_grazing = 0 on all reported branch points; admissible
  polynomial residuals ≤ 6.0×10⁻¹⁷.
- Branch-jump semantics: manuscript "5%" neighbour check matches
  `branch.py` default `rel_jump=0.05` (the `params.json` value 0.02 is the
  separate global-best jump flag).
- Fig. 5(c) χ-collapse claim is correct: matched-χ ratios for
  D_w* = 1 and 10² vs 10⁻² are 1.000 within 0.1% over the overlap; the
  D_w* = 10⁴ curve has no χ-overlap with 10⁻² and compares to D_w* = 1
  with median 1.000 (range 0.93–1.28).
- All 11 figures reproduce pixel-identically from the raw data
  (regeneration check, mean |pixel difference| = 0.000000 for figs
  1–8, 10, 11; fig9 changed only as described in C2).

## Known documentation nits (not data errors)

- `08_AUDITS/FINAL_FIGURE_AUDIT.md` (F3) retains the historical
  "17–30 sign reversals" diagnostic count (see C5).
- `fig5_friction1d.csv` exports 3 of the 4 plotted frictions
  (D_w* = 1, 10², 10⁴); the D_w* = 10⁻² slice exists in
  `fig9b_map_dBC.npz` (row 0), which is what the figure code reads.
  No plotted curve is missing from the data archive.

## C15 — Section 7.2 participation-number range (second instance)

- **Error.** The Section 7.2 model-B paragraph quoted "P_w between 1.7\times10^{-13} and
  1.8\times10^{-5} across the band" (the Section 6.1 instance of the same range had been
  corrected to 1.3\times10^{-17} under C7, but this second instance was missed).
- **Evidence.** study1_baseline.csv: P_w(B) = 1.257\times10^{-17} at \Omega^*=10^{-3}
  monotonically to 1.814\times10^{-5} at \Omega^*=10^{3}.
- **Fix.** Both instances now quote the full range "1.3\times10^{-17} and 1.8\times10^{-5}".

## C16 — Section 5.2 two-path worst difference

- **Error.** The two-path consistency sentence quoted a worst relative difference of
  1.04\times10^{-9}; the archived V1 validation log's worst anchor is 9.35\times10^{-10}
  (model A, \Omega=0.01; 15/15 anchors OK within 10^{-8}).
- **Fix.** Text now quotes 9.35\times10^{-10}, matching
  07_TESTS_VALIDATION/validation_logs/test_V1_two_path.log exactly.

## C17 — Fig09.eps (EPS companion of the corrected thermal map)

- **Error.** The EPS companion of Fig. 9 still carried the old colour-scale framing
  (generated before the C5 z-limit correction), so 06_FIGURES/output/Fig09.eps and
  figures/output/Fig09.eps were stale relative to fig9.pdf.
- **Fix.** Regenerated from the corrected figure object as vector EPS (same figure, same
  data, exact bounding box 605x198 as the original). Both copies replaced and
  byte-identical to each other. Note: the original EPS set was produced with
  poppler `pdftops`; the correction environment renders Fig09.eps directly from
  Matplotlib. All other EPS files are the untouched archival conversions.

## C18 — Shipped PDF was stale relative to its own shipped source (upstream defect)

- **Error.** In the downloaded archive, 01_MANUSCRIPT/FINAL_MANUSCRIPT.pdf had been
  compiled from an *earlier* source revision than the shipped FINAL_MANUSCRIPT.tex.
  Recompiling the pristine .tex reproduces the .tex text, not the shipped PDF text.
  Two substantive divergences were found:
  1. equation (14): the stale PDF rendered det(A_2) with a trailing factor "k^4";
     the shipped source correctly states det(A_2) = (C_{11}K_1-R_1^2)(C_{66}K_3-R_6^2)\,k_{11} > 0,
     which is the identity the symbolic check V4 verifies from the assembled matrix
     (tests/V4/test_V4_symbolic.py, PASS);
  2. Section 5.2 / Fig. 3 caption: the stale PDF claimed "n_ad = 5 ... at \Omega = 0.1, 10, 1000
     for all three models" at the reference scan, which is false for model A (4 admissible +
     2 grazing at k^* = 2\Omega^*); the shipped source correctly separates the reference-scan
     diagnostic (B/C: 5+5; A: 4+2 grazing) from the physical solved branches (n_ad = 5,
     n_grazing = 0 uniformly -- chain_log.txt, fig8_roots_summary.csv).
- **Fix.** The rebuilt PDFs render the shipped (correct) source. No .tex change was required
  for these two items; they are recorded here because the corrected PDF text differs from
  the stale shipped PDF text exactly in these places.

## C19 -- Section 6.4 Rayleigh comparison (external audit finding)

- **Error.** The 3D-surface paragraph claimed both Study-2 sheets lie "below the classical
  Rayleigh ratio". Data: V_B spans [0.464987, 0.466301] (straddling the decoupled Rayleigh
  speed V_R* = 0.5 x 0.932525906 = 0.4662630 in v0 units), V_C spans [0.466264, 0.467355]
  (entirely ABOVE V_R*). The sentence also compared a speed in v0 units with a Rayleigh/Shear
  ratio.
- **Fix.** Corrected to the verified straddle/above statement with explicit v0-unit Rayleigh
  speed; Section 7.8's blanket "phason coupling lowers the speed" replaced by the
  regime-dependent statement (baseline compliance raises the quasi-static ratio by +7.7e-5;
  low friction lowers the B sheet to 1.3e-3 below and raises the C sheet to 1.1e-3 above).

## C20 -- Thermal "interference nodes" removed (external audit finding)

- **Error.** Sections 6.5 and the Fig. 6 caption described 11--19 "resolved interference
  nodes" per curve and an in-phase/out-of-phase mechanism. Data (fig6_tau.csv): the signed
  difference V(tau0)-V(tau_ref) changes sign with above-floor magnitude on both sides at most
  once per curve (0, 0, 1, 0 of 17/14/14/9 sign changes); exactly one dip of 11/15/18/19
  local minima is flagged above floor (tau0=1e-2 at Omega*=44.7). The dips are sub-floor
  scatter.
- **Fix.** Node count and phase-mechanism claim removed; the curves are described as monotone
  in their resolved part with unresolved sub-floor scatter.

## C21 -- Complex-wavenumber dispersion check added (external audit's decisive issue)

- **Gap.** The production method minimises the real-k secular residual; for dissipative models
  the true mode has complex k. Status of the real-axis speeds was unverified.
- **Evidence.** New Section 5.5 + Table: Newton solution of det B(omega,k)=0 for complex k at
  13 representative points (A/B/C at Omega*=0.1/10/1e3 baseline; B/C at Omega*=1/100 at
  D_w*=0.01). Real-axis speed reproduces Omega/Re k to 3.5e-12..6.6e-7 relative (worst B/C at
  band top); attenuation <= 7.1e-4 per wavelength (A <= 1.8e-6); complex-mode Delta_BC differs
  from the reported real-axis Delta_BC by <= 8.0e-10 (baseline) and <= 8.4e-8 (low friction).
  Record: 07_TESTS_VALIDATION/validation_logs/complex_k_dispersion.log + complex_k_check.py.
- **Fix.** Production outputs labelled "resonance estimates" of weakly damped modes with the
  verified bounds; abstract and conclusions updated accordingly.

## C22 -- Claim scope: search-qualified nonexistence (external audit finding)

- **Error.** "destroys the model-A surface branch", "no comparable finite-speed clamped branch
  exists", "no phason branch exists" (Section 7.3) stated nonexistence beyond the search.
- **Fix.** All nonexistence statements rephrased to "no ... was found under the stated search
  and acceptance criteria"; degree count demoted to supporting (not proving) evidence;
  Section 7.1's "every continuous parameter ... only perturbatively" now excludes the discrete
  boundary condition explicitly.

## C23 -- Formulation record printed (external audit finding)

- **Gap.** Pencil entries, boundary rows, ||B|| definition, and root tolerances were not in the
  paper.
- **Fix.** New Section 3.7 prints A0/A1/A2 entry by entry (with the K3/K6 asymmetry placement),
  the five boundary rows, the spectral-norm definition, the admissibility/grazing tolerances
  (1e-10), root-residual flag (1e-8), scan/refinement tolerances, and the positivity check of
  the declared parameter set.

## C24 -- Nondimensionalisation made explicit (external audit finding)

- **Error.** "stresses by C11" was inconsistent with U0 = beta1 T0/(C11 k0) and beta1*=1.
- **Fix.** Stress unit stated as sigma0 = C11 U0 k0 = beta1 T0; row-by-row derivation added
  (phonon rows -> C11*=1, beta1*=1; heat row -> k11* = k11 k0/(rho ce v0),
  T0 beta1* = beta1^2 T0/(C11 rho ce) = 2.3047e-3, c_e* = 1 exactly by construction).

## C25 -- Modal diagnostics defined (external audit finding)

- **Fix.** P_w defined as surface amplitude-squared participation of the unit-sigma_min
  singular-vector combination (not an energy fraction); delta* defined as 1/min|Im p| (slowest
  admissible partial wave); Section 7.7 no longer treats the full field as a single
  exponential.

## C26 -- Electrical decoupling explicit (external audit finding)

- **Fix.** D_y = e31(eps_xx+eps_zz), Gauss's law and the phi=0 solution written out; stated
  prominently that all reported speeds are independent of the piezoelectric constants in this
  configuration.

## C27 -- Resolvability language, chi collapse quantified, dimensional table

- "observable" -> "numerically resolvable in this calculation" (abstract, RQ, Section 6.4);
  baseline B/C wording corrected (95/121 within floor; 26 resolved points near the band top,
  <= 9.5e-6). Fig. 5(c) chi collapse quantified (matched-chi agreement within factor 1.004
  over common above-floor ranges; swept domain stated). New Table (dimensional endpoints):
  f = 6.9 MHz -- 6.9 THz, lambda down to 0.466 nm, delta* down to 0.205 nm at the band top;
  continuum-validity limitation added (atomic-scale wavelengths at Omega*=1e3; friction
  crossover 79.3 THz above the band).

## C28 -- Thermal boundary condition, k11 sensitivity, reproduction inventory

- Insulated/LS equivalence shown (q_z = -k11 d_z theta/(1-i omega tau0)); no isothermal vs
  insulated production sweep claimed. k11 sensitivity spot check: 5.3 vs 6 W/(m K) shifts
  V*(C, Omega*=1e3) by 1.8e-6 relative. Data-availability now lists the exact package
  inventory and manifest locations. Display-clip language corrected (sub-floor regions are
  unresolved, not measured zeros). Two-path check scope stated (shared linear algebra,
  independent scalar solves).

---

## C29 — ARCHIVE PACKAGING FIX (2026-09-28, reproducibility archive build) — NOT a scientific-content change

**Finding (found by the actual reproduction test).** The production drivers
wrote their outputs to `results/` (and `tests/results/`) while the figure
script (`figures/style.py`), `verification/verify_invariants.py`, the study-3
floor reader and the raw-data manifests consumed `results/raw/`. A true
`run_all.py --from-scratch` run therefore regenerated data where the figure
step could not see them (the historical campaign had been curated manually
into `results/raw/`).

**Fix (paths only, zero numerical-code change).** Producers unified with the
consumers on `results/raw/`: `solver/record.py` RESULTS dir;
`drivers/study2_friction_map.py` (incremental CSV + fig9b NPZ);
`drivers/study3_thermal.py` (fig9c NPZ + resolution-bench reader);
`tests/V2/test_V2_elastic_limit.py` and `tests/V3/test_V3_model_limits.py`
output dirs. Additionally the resolution-bench regeneration command (frozen
4 points) is now documented in `07_DOCUMENTATION/DATA_DICTIONARY.md` +
`04_REPRODUCTION/RUN_ORDER.md` (the file previously had no regenerating entry
point in the shipped code).

**Verification (done).** Exercised by reproduction Run 2 on the same isolated
directory: invariants 22/22 PASS, all 11 figures regenerate, report
REPRODUCTION: PASS. Run 1 (unmodified code) had already regenerated all data
with zero numerical difference vs the archive; the fix changed paths only.
