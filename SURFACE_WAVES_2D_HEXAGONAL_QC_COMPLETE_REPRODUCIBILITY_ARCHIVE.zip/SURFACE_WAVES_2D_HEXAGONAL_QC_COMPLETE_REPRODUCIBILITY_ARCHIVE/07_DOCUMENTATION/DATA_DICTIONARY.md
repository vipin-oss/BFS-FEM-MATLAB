# DATA_DICTIONARY.md — column semantics of every dataset

All CSVs are plain text, comma-separated, one header line (except
`v2_elastic_limit.csv`, which is a key/value transcript). Floats are
printed with 10–12 significant digits (repr-style scientific). All starred
(nondimensional) quantities use the paper's scales (§4 of the manuscript):
v0=6917.1446 m/s, ω0=4.34617e10 s⁻¹ (f0=6.917 GHz), k0=2π×10⁶ m⁻¹.

## Common columns (appear in most sweeps)

| Column | Meaning |
|---|---|
| `run_id` | run timestamp (UTC `YYYYMMDD-HHMMSS`) — the only non-reproducible column |
| `solver_hash` | 16-hex hash of the exact solver source used (chain provenance) |
| `model` | `A` = inertial, `B` = diffusive, `C` = telegraph |
| `bc_phason` | `free` \| `clamped` |
| `bc_thermal` | `isothermal` \| `insulated` (surface thermal condition) |
| `Omega` | nondimensional frequency Ω* = ω/ω0 |
| `k` | nondimensional wavenumber k* = k/k0 at the r-minimum |
| `V` | nondimensional surface-wave speed V* = ω/(k·v0) = (k0/ω0)·ω/k |
| `r` | secular residual σmin(B)/σmax(B) at the minimum (accept ≲1e-10) |
| `status` | `accepted` \| `resolved_min` \| `no_branch` \| `skipped_...` (see driver headers) |
| `jump` | 1 if the branch-jump diagnostic (>5% V* change to the neighbour) fired |

## study1_baseline.csv (363 rows)

| Column | Meaning |
|---|---|
| `n_ad` / `n_grazing` | admissible / grazing depth-root counts at the solution |
| `condB` | cond₂(B) boundary-matrix conditioning |
| `root_flags` | 1 if any per-root residual flag (>1e-8) fired |
| `max_root_res` | max per-root residual σmin(M)/σmax(M) over depth roots |
| `k_comp` / `r_comp` | independent recomputation of k* and r (residual identity) |
| `P_w` | wave-mode power fraction (|a_wx|²+|a_wz|²)/Σ|a_i|² from eigenvector amplitudes |
| `delta_pen` / `delta_pen_weighted` | penetration depth δ* (1/|min Im p|) and P_w-weighted variant |
| `rel_xtol` / `n_scan` | convergence metadata of the refinement |

## study2_map_incremental.csv (7442 rows)

| Column | Meaning |
|---|---|
| `i_Dw` | 0-based D_w* grid index (61 values: 1e-2 … 1e4, log, 10 per decade) |
| `Dw` | phason friction D_w* |

## fig4_deltas.csv (363 rows)

| Column | Meaning |
|---|---|
| `V_A`,`V_B`,`V_C` | solved speeds of the three models at the same Ω* (assembled from the study1 curves) |
| `Delta_BC`,`Delta_AC`,`Delta_AB` | model–model speed differences (B−C etc.; units of V*) |

## fig5_friction1d.csv (49 rows)

| Column | Meaning |
|---|---|
| `Dw` | friction value at which the matching-χ slice was evaluated |
| `Delta_BC_at_Dw` | |V_B − V_C| at Ω*=1e-3 on that slice |

## fig6_tau.csv (605 rows)

| Column | Meaning |
|---|---|
| `tau0` | thermal relaxation τ0* (1e-5 … 1e-1) |
| `Delta_T` | thermal branch thermal-origin amplitude change (see Fig 6 caption) |
| `above_floor` | True if ΔT exceeds the 1e-16 double-precision reference floor |

## fig7_bc.csv / fig7_bc_summary.csv (484 / 121 rows)

| Column | Meaning |
|---|---|
| `delta_pen` | penetration depth of the BC-mode at that point |
| `dV_over_V_A/C` | (clamped − free)/free relative speed change per model |
| `dPen_A/C` | relative penetration-depth change |

## fig8_roots.csv / fig8_roots_summary.csv

| Column | Meaning |
|---|---|
| `root_index` | depth-root index (0-based, sorted as returned by companion eigenvalues) |
| `Re_p` / `Im_p` | depth-root p* = p/k0 (complex) |
| `admissible` / `grazing` | per-root classification flags |
| `root_residual` | per-root σmin(M)/σmax(M) residual |
| `n_ad`,`n_grazing`,`delta_pen`,`P_w`,`k_branch`,`V_branch`,`r_branch` | per-point summary (summary file) |

## resolution_bench.csv (4 rows: C@Ω*=1e-2, C@1, C@100, A@1)

| Column | Meaning |
|---|---|
| `V_L1` / `V_L2` | V* at production scan (n_scan=160) and 3× scan with identical tolerances |
| `u_V` | resolution measure \|V_L2 − V_L1\| (max = 1.129857263305e-09) |
| `r_L1`,`r_L2`,`condB_L1` | residual and conditioning at both levels |
| `aux_dVdOm_rel` | auxiliary dV/dΩ relative sensitivity (diagnostic, NOT the definition) |
| `eps_Delta` | ε_Δ = 10·max(u_V) = 1.129857263305e-08 (frozen benchmark value) |

Regeneration (frozen benchmark points; documented command):
```bash
PYTHONPATH=. python3 -c "
from solver.material import Material
from solver import resolution
bc = {'phason':'free','thermal':'isothermal'}
pts = [('C',1e-2),('C',1.0),('C',1e2),('A',1.0)]
resolution.benchmark(pts, Material(), bc, out_csv='results/raw/resolution_bench.csv')"
```

## v2_elastic_limit.csv / v3_model_limits.csv

Test transcripts (key,value or per-model columns) documenting the decoupled
elastic limit (V_s*, V_P*, classical Rayleigh 0.932525905921) and the model
limits (telegraph→C at D_w*→0/1e-14, diffusive→A at ρ_w*→0;
values in `../04_REPRODUCTION/expected_outputs/EXPECTED_VALUES.md`).

## NPZ files (fig9b_map_dBC.npz, fig9c_map_dT.npz)

`numpy.load`-readable; exact arrays:

- `fig9b_map_dBC.npz`: `Omegas` (61), `Dws` (61), `V_B` (61×61), `V_C` (61×61),
  `dBC` (61×61 = |V_B−V_C| field), `Omega_c_ref` (61) — boundary-cell grid of
  Study 2 (layout identical to `study2_map_incremental.csv` reshaped per the
  driver; see `drivers/study2_friction_map.py` np.savez call).
- `fig9c_map_dT.npz`: `Omegas` (121), `taus` (5), `dT` (5×121) — Study-3
  thermal map (rows = τ0* values of `grids.json`).

## chain_log.txt

Append-only provenance log: one line per production run with the solver source
hash (`solver_hash`) that produced the subsequent raw files.
