# KNOWN_LIMITATIONS.md

Honest record of limitations, caveats and open items (cross-check with the
manuscript §7.9 and errata `CORRECTIONS_ERRATA.md`).

## Physical/modeling limitations

1. **Continuum validity.** At the top of the mapped band the computed
   penetration depth reaches sub-nanometre values (δ* down to ≈0.205 nm at the
   band top for the dimensional endpoints in `tab:dim`); a continuum
   quasicrystal model is not expected to hold there. The paper states this
   caveat explicitly. Treat the highest decade as formal extrapolation.
2. **Pseudo-SAW caveat.** Branches are minimisers of the real-axis secular
   residual; the complex-wavenumber check bounds, but does not eliminate, the
   real-axis estimator error (≤6.6e-7 relative speed at the band top;
   attenuation ≤7.0e-4 per wavelength). Branches are reported as
   "resonance (weakly damped) estimates" where relevant.
3. **Piezoelectricity passive in the studied cut.** The electric potential
   decouples at the retained coupling order; active-piezoelectric cuts are
   future work (the constitutive terms are present in the pencil).
4. **Declared surrogate parameters.** ρ (4180 kg/m³) and c_e (500 J/(kg K))
   are declared surrogates; ρ_w = ρ is an identification (no independent
   phason mass density in the literature); k11 = 6 W/(m K) conflicts with
   li2017's 5.3 — the discrepancy is genuine and unresolved. τ0 is a declared
   computational parameter (swept), not a measured material property.
5. **Half-space only.** No layering, no strata, no finite-thickness effects.

## Numerical limitations

6. **Resolution floor.** Model B–C differences below ε_Δ = 1.13e-8 (absolute)
   are indistinguishable from discretisation-of-k error; 95/121 baseline points
   sit below it. Do not quote sub-floor differences as physical signals.
7. **Double-precision floor.** Difference plots clip at 1e-16; dips into that
   band are cancellation, not signals (Fig. 2 caption note).
8. **Near-grazing model-A roots at the reference scan** (4 admissible + 2
   grazing at k*=2Ω*): documented behaviour of the fixed-reference diagnostic
   grid; on the solved physical branch n_ad=5 for every model.
9. **Restart-capable driver.** `study2_friction_map.py` resumes from an existing
   `study2_map_incremental.csv`; delete it for a true from-scratch rerun.
10. **Library-version sensitivity.** Last-digit reproducibility of minimiser
    outputs depends on SciPy/NumPy versions; compare at 1e-9 relative level
    across stacks. Original production pip versions: NOT DOCUMENTED.

## Process limitations

11. **Author metadata placeholders.** The manuscript title page carries the
    standard placeholder authorship/affiliation blocks — fill before journal
    submission.
12. **Dev/Sladek/Stevens (2025) citation.** The parameter table's [R]/[G]
    labels cite "Dev/Sladek/Stevens (2025)" as the convention source; the full
    bibliographic record is NOT DOCUMENTED in the archived metadata. The
    manuscript's comparison to it is qualitative ("directional, not exact") —
    no quantitative claim depends on it.
13. **No experimental validation** — purely computational; no experimental data
    exist for this system at these frequencies (NOT APPLICABLE, not a defect).
14. **No VCS history.** Only the final snapshot is archived; the development
    history is NOT DOCUMENTED.
