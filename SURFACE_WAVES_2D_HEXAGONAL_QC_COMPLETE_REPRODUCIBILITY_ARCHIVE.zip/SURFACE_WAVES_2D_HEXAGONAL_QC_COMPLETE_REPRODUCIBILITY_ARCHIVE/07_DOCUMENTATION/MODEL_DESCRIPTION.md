# MODEL_DESCRIPTION.md

(Companion to the manuscript §2–§3; authoritative text = `02_OVERLEAF/main.tex`.)

## Geometry

Half-space z>0 of a 2D hexagonal quasicrystal (periodic axis y; wave
propagation x; sagittal plane x–z). Free surface z=0.

## Fields

Displacement (u_x,u_z); phason displacement (w_x,w_z); temperature increment
θ=T−T0; electric potential φ (piezoelectricity passive in the studied cut —
charge equation ∂_i D_i = 0 decouples φ at the retained coupling order).

## Governing system (structure)

- Momentum balance (inertia ρ ü_i = σ_ij,j).
- Phason balance — three models:
  - **A** inertial: ρ_w ẅ_i = H_ij,j;
  - **B** diffusive: C_w ẇ_i = −H_ij,j (C_w = 1/D_w = 4.8e-19 m³ s/kg from
    chellappan2015);
  - **C** telegraph (Agiasofitou & Lazar 2014): both inertia and friction with
    relaxation time τ_tel = 2ρ_w*/D_w*.
- Heat: Lord–Shulman type with relaxation τ0 (τ0→0 gives Fourier).
- Constitutive: full 2D hexagonal piezoelectric thermoelastic QC set
  (elastic C_ijkl, phason K_ijkl, piezoelectric e, thermal β, electrostatic κ)
  with the documented phason-sector asymmetry H_xz≠H_zx (extra K3 p² term in
  the w_x row).

## Boundary conditions (z = 0)

- Mechanical: σ_zz = σ_zx = 0 (traction-free).
- Phason: **free** (H_zz = H_zx = 0) or **clamped** (w_x = w_z = 0).
- Thermal: **isothermal** (θ = 0) or **insulated** (q_z = 0 ⇔ ∂_zθ = 0 with LS).
- Baseline for model comparison: free-phason + isothermal.

## What is solved

For each (Ω*, k*): the five decaying depth roots of det M(p)=0 and the
nontrivial 5-vector in the boundary matrix B(ω,k)c=0; the surface-wave branch
is the r=σmin(B)/σmax(B) minimum in k, tracked over the Ω* grid.

## Model parameters

Single source: `01_PROGRAM/params.json`; transcribed table:
`PARAMETER_TABLE.md`; provenance labels [D]/[R]/[G]/[C]/[X] per the paper's
`tab:params`. Declared surrogate/identified values (ρ, c_e, ρ_w, k11 discrepancy)
are marked as such — nothing is presented as measured unless labeled [D].

## Not part of the model

- No defects, no strata/layering (half-space only).
- No finite electrical conductivity (quasi-static electric field).
- No experiment-calibrated damping beyond the phason sector.
