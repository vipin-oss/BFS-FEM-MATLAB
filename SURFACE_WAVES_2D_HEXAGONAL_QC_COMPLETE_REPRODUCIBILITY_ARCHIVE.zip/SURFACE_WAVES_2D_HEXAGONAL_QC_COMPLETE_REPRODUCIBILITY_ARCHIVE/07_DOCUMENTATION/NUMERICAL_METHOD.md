# NUMERICAL_METHOD.md

(Companion to manuscript §3; authoritative text = `02_OVERLEAF/main.tex`;
implementation-level details also in `05_DERIVATIONS/numerical_method/`.)

## Pipeline

1. **Pencil assembly** (`solver/matrix.py`): M(p) = A0 + pA1 + p²A2, entries
   from `params.json` (frozen construction; symbolically checked identities
   `eq:A1ident`, `eq:detA2`).
2. **Depth roots** (`solver/roots.py`): companion-matrix eigenvalues + 2 Newton
   polish steps; admissible iff Im p > 1e-10·max(1,|p|); grazing recorded;
   per-root residual flag at 1e-8.
3. **Boundary matrix** (`solver/boundary.py`): 5×5 rows per the surface BC set
   (free/clamped × isothermal/insulated), eigenvectors = unit-norm SVD null
   vectors of M(p_j).
4. **Secular residual** (`solver/residual.py`): r = σmin(B)/σmax(B).
5. **Branch tracking** (`solver/branch.py`): log-scan (n_scan=160, sub-scans at
   bulk-grazing wavenumbers) → local bounded minimisation (Brent xtol=1e-12,
   rel_xtol=1e-15) of every interior candidate → continuation-preferred
   selection with staleness guard → 5% jump diagnostic → status recording
   (`accepted` / `resolved_min` / `no_branch` / degenerate-cutoff V*<0.15).
6. **Diagnostics** (`solver/diagnostics.py`): P_w = (|a_wx|²+|a_wz|²)/Σ|a_i|²,
   δ* = 1/|min Im p| (and P_w-weighted variant).
7. **Resolution benchmark** (`solver/resolution.py`): u_V = |V(n_scan) − V(3·n_scan)|
   at identical tolerances; ε_Δ = 10·max(u_V) = 1.13e-8 (absolute V units).

## Numerical conventions

- Double precision throughout (IEEE-754); roundoff floor of difference
  quantities = 1e-16 (documented display clip).
- Deterministic: no RNG, no threading-dependent reductions in the solver path.
- Both Ω→k and k→Ω paths implemented (two-path consistency check V1:
  worst |Δ| = 9.35e-10 at 15 anchors).
- Complex-arithmetic-safe B assembly reused by the complex-wavenumber check.

## Runtime expectations

Per point ≈ 0.1–0.3 s single core (5-root solve + refine). Full sweep totals in
`01_PROGRAM/README_PROGRAM.md` §9.

## Software stack

numpy (linear algebra), scipy (scalar minimisation), sympy (exact checks),
matplotlib (figures). No compiled extensions; no GPU.
