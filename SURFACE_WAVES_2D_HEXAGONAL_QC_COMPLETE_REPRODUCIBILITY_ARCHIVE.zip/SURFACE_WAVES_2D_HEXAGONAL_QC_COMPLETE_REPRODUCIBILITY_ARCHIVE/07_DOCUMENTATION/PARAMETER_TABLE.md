# PARAMETER_TABLE.md

Generated verbatim from `01_PROGRAM/params.json` (single source of truth) on 2026-09-28.
Provenance labels: **[D]** measured from full transient-dynamics runs (Solodov et al. experiments); **[R]** reference values adopted from Dev/Sladek/Stevens (2025); **[G]** regenerated grid selection (same conventions as Dev/Sladek/Stevens 2025); **[C]** consistency-locked composition; **[X]** compiled-freeze target; **[Y]** derived scale.

## Dimensional parameters (SI)

| Parameter | Value | Unit | Provenance |
|---|---|---|---|
| C11 | 200000000000.0 | J/m^3 | see provenance labels below |
| C12 | 100000000000.0 | J/m^3 | see provenance labels below |
| C13 | 100000000000.0 | J/m^3 | see provenance labels below |
| C33 | 150000000000.0 | J/m^3 | see provenance labels below |
| C44 | 50000000000.0 | J/m^3 | see provenance labels below |
| K1 | 50000000000.0 | J/m^3 | see provenance labels below |
| K2 | 20000000000.0 | J/m^3 | see provenance labels below |
| K3 | 20000000000.0 | J/m^3 | see provenance labels below |
| R1 | 10000000000.0 | C/m^2 | see provenance labels below |
| R2 | 5000000000.0 | C/m^2 | see provenance labels below |
| beta1 | 1798000.0 | J/(m^3 K) | see provenance labels below |
| k11 | 6.0 | W/(m K) | see provenance labels below |
| rho | 4180.0 | kg/m^3 | see provenance labels below |
| rho_w | 4180.0 | kg/m^3 | see provenance labels below |
| c_e | 500.0 | J/(kg K) | see provenance labels below |
| T0 | 298.0 | K | see provenance labels below |
| tau0 | 1e-13 | s | see provenance labels below |
| D_w | 2.0833e+18 | m^2/s | see provenance labels below |
| C_w | 4.8e-19 | J/m^3 | see provenance labels below |

## Provenance labels (verbatim from params.json)

- **C11..R2**: composite table (wang2020 = li2017 Table 1)
- **C66,K6,R6**: derived by frozen symmetry relations 2C66=C11-C12, K6=K1-K2-K3, 2R6=R1-R2
- **rho**: SURROGATE (4180 kg/m^3, declared)
- **rho_w**: DECLARED identification rho_w = rho (no independent phason mass density in literature)
- **c_e**: SURROGATE (500 J/(kg K), declared); nondimensional role c_e* = 1 exactly (F1: absorbed into thermal-row normalisation)
- **D_w**: literature-derived: D_w = 1/C_w, C_w = 4.8e-19 m^3 s/kg from chellappan2015 eq.(3)+p.8; mobility/friction distinction enforced
- **tau0**: DECLARED computational parameter (swept 1e-13..1e-11 s in design; production study uses tau0* values)
- **k11**: DECLARED choice 6 W/(m K); li2017 reports 5.3 - discrepancy genuine and unresolved
- **k0**: DECLARED nondimensionalisation scale 2*pi*1e6 m^-1 (reference wavelength 1 um); NEVER a working wavenumber

## Scales

- k0 = 6283185.307179586

## Frozen nondimensional targets

| Group | Value |
|---|---|
| C11s | 1.0 |
| C12s | 0.5 |
| C66s | 0.25 |
| K1s | 0.25 |
| K2s | 0.1 |
| K3s | 0.1 |
| K6s | 0.05 |
| R1s | 0.05 |
| R2s | 0.025 |
| R6s | 0.0125 |
| rho_s | 1.0 |
| rho_ws | 1.0 |
| beta1s | 1.0 |
| ce_s | 1.0 |
| k11s | 0.0026077 |
| tau0s | 0.0043462 |
| T0b1s | 0.0023047 |
| Dws | 11467.5 |
| v0 | 6917.1446 |
| om0 | 43461700000.0 |
| U0 | 4.2636e-10 |
| vS_over_v0 | 0.5 |
| vP_over_v0 | 1.0 |
| Omega_c | 11467.5 |
| tau_tel_s | 0.0001744 |

## Solver defaults

- `admissibility_tol` = 1e-10
- `root_polish_newton_iters` = 2
- `root_residual_flag` = 1e-08
- `r_accept` = 1e-10
- `scan_kmin_factor` = 1.2
- `scan_kmax_factor` = 40.0
- `n_scan` = 160
- `brent_xtol` = 1e-12
- `eps_Delta_multiplier` = 10.0
- `branch_jump_flag_rel` = 0.02

## Sweep grids

- **_comment**: Frozen grids (blueprint §§8-10). Log grids; counts: 121 = 6 decades x 20/dec + 1; 61 = 5 decades x 12/dec + 1; 61 = 6 decades x 10/dec + 1.
- **two_path**: {"Omega": [0.01, 0.1, 1.0, 10.0, 100.0], "models": ["A", "B", "C"], "note": "F2 gating test: production Omega->k* vs alternate k*->Omega; tolerance = blueprint velocity accuracy target 1e-8 relative on V*"}
- **resolution_bench**: {"points": [["C", 0.01], ["C", 1.0], ["C", 100.0], ["A", 1.0]]}
- **study1**: {"Omega": {"start": -3, "stop": 3, "per_decade": 20, "n": 121}, "models": ["A", "B", "C"], "bc": {"phason": "free", "thermal": "isothermal"}}
- **study2**: {"Omega": {"start": -3, "stop": 2, "per_decade": 12, "n": 61}, "Dw": {"start": -2, "stop": 4, "per_decade": 10, "n": 61}, "models": ["A", "B", "C"], "bc": {"phason": "free", "thermal": "isothermal"}}
- **study3**: {"Omega": {"start": -3, "stop": 3, "per_decade": 20, "n": 121}, "tau0s": [1e-05, 0.0001, 0.0043462, 0.01, 0.1], "model": "C", "bc": {"phason": "free", "thermal": "isothermal"}}
- **bc_study**: {"Omega": {"start": -3, "stop": 3, "per_decade": 20, "n": 121}, "models": ["A", "C"], "variants": [{"phason": "free", "thermal": "isothermal"}, {"phason": "clamped", "thermal": "isothermal"}]}
- **roots_diag**: {"Omega": [0.1, 10.0, 1000.0], "models": ["A", "B", "C"]}

## NOT DOCUMENTED / NOT APPLICABLE

- Exact machine of the original production runs: NOT DOCUMENTED (single-CPU workstation assumed).
- Statistical error bars: NOT APPLICABLE (deterministic numerics).
- Experimental calibration of the surrogate parameters (rho, c_e): NOT AVAILABLE — declared surrogates (see labels).
