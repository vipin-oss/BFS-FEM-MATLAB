# PROJECT_OVERVIEW.md

## What this project is

A computational research project on **surface (Rayleigh-type) waves in a
two-dimensional hexagonal piezoelectric thermoelastic quasicrystal half-space**.
The deliverable is a research paper (35 pp) plus the complete, audited
computation behind it.

## Scientific questions

1. How do the three competing phason dynamic models — **A (inertial)**,
   **B (diffusive)**, **C (telegraph)** — differ in surface-wave speed,
   localisation, and boundary-condition sensitivity across a six-decade band
   (f ≈ 6.92 MHz … 6.92 THz)?
2. Are the model differences resolvable above the numerical resolution floor
   of the production solver?
3. What is the thermal (Lord–Shulman τ0) and phason-friction (D_w) sensitivity
   of the branches?

## Method (one paragraph)

Semi-analytical: harmonic sagittal ansatz → matrix pencil
M(p)=A0+pA1+p²A2 in the complex depth exponent p; five admissible decaying
roots; 5×5 surface boundary matrix (traction-free + phason free/clamped +
isothermal/insulated); secular residual r=σmin(B)/σmax(B) minimised in k along
continuation-tracked branches; verification by classical Rayleigh limit,
exact symbolic identities, full-grid model limits, two-path consistency,
resolution benchmark, and a 13-point complex-wavenumber check.

## Headline findings (values audit-verified)

- Models B and C occupy the phonon–Rayleigh branch (V*≈0.466); model A the
  phason-dominated branch (V*≈0.311) — the A-vs-(B,C) difference is branch
  identity (Δ_AC≈0.334 ≈ 1.4e7 × resolution floor), not a perturbation.
- B–C separation is tiny but structured: |V_B−V_C| grows to 4.4e-6 absolute at
  the band top; 95/121 baseline points lie below the resolution floor
  (ε_Δ=1.13e-8), resolvable only above Ω*≈50–56; matched-χ collapse factor ≤1.0035.
- Phason boundary condition (free→clamped): |ΔV|/V ≤ 8.1e-6 growing with Ω*;
  thermal relaxation effect ΔT ≤ 7.879e-5 (max over swept τ0).
- All three branches localise classically: Ω*δ* ≈ const (≈1.99 A; ≈1.29 B/C).
- Complex-wavenumber check: production real-axis speed error ≤6.6e-7 relative
  (A ≤2.5e-10); attenuation ≤7.0e-4 per wavelength (A ≤3.1e-7).

## What this archive contains

| Folder | Content |
|---|---|
| `01_PROGRAM` | complete runnable program + raw data working copy |
| `02_OVERLEAF` | Overleaf-ready manuscript folder (compiles stand-alone) |
| `03_DATA` | canonical data archive + dictionary pointers |
| `04_REPRODUCTION` | reproduction instructions, manifests, expected values |
| `05_DERIVATIONS` | derivation navigation record |
| `06_VALIDATION` | benchmarks, validation scripts + archived results |
| `07_DOCUMENTATION` | this documentation set |
| `08_FINAL_OUTPUTS` | final manuscript PDF, figures, key results |
| `09_ARCHIVE_METADATA` | archive README, version, SHA-256 integrity |

## Relationship to the source submission package

This archive was built from the corrected submission package
(`FINAL_SURFACE_WAVES_2D_HEXAGONAL_QC_RESEARCH_PACKAGE_SUBMISSION`, 295 files,
2026-09-28) by reorganising into the reproducibility structure, deduplicating
identical mirrors (with hash-identity documented), removing cache/internal
files, and adding the reproduction test record. No scientific content was
changed. Correction history: `CORRECTIONS_ERRATA.md` (C1–C28).
