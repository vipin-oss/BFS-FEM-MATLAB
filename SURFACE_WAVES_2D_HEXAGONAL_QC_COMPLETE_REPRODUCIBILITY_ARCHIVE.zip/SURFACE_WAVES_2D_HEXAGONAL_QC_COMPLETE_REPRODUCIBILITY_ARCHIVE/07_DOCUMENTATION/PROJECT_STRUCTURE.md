> **ARCHIVE NOTE (2026-09-28).** This describes the SOURCE SUBMISSION PACKAGE layout (numbered folders 01–12), preserved as a historical record. The structure of THIS archive is the 9-folder reproducibility layout — see `../09_ARCHIVE_METADATA/ARCHIVE_README.md`.

# PROJECT_STRUCTURE.md

# Comprehensive Project Architecture & Directory Organization

## 1. Dual-Layout Architecture Overview

This research package employs a dual-layout organization designed to satisfy both **archival preservation standards** and **frictionless command-line execution**:

```
FINAL_SURFACE_WAVES_2D_HEXAGONAL_QC_RESEARCH_PACKAGE_2026-09-08/
├── [Archival Partitioning: Numbered Categorical Folders 01–11]
│   ├── 01_MANUSCRIPT/              (Final LaTeX source, compiled PDF, BibTeX, embedded figures)
│   ├── 02_SOLVER/                  (Complete production solver modules, material properties, grids)
│   ├── 03_DRIVERS/                 (Production study runners 1–6, root diagnostics, make_all_figures.py)
│   ├── 04_LITERATURE_BENCHMARK/    (Independent Laguerre/transfer solvers, digitized data, comparison ledgers)
│   ├── 05_RESULTS_RAW/             (All non-regenerable CSV/NPZ raw data files and SHA-256 manifests)
│   ├── 06_FIGURES/                 (Vector PDF & EPS figures 1–11, make_all_figures.py, style, provenance)
│   ├── 07_TESTS_VALIDATION/        (V0–V5 validation test suite, invariant verification engine, logs)
│   ├── 08_AUDITS/                  (17 master scientific, mathematical, literature, and claim-integrity audits)
│   ├── 09_LITERATURE/              (Literature BibTeX, category references, MISSING_REFERENCE_PDFS.md)
│   ├── 10_DOCUMENTATION/           (README, REPRODUCTION, PROJECT_STRUCTURE, SCIENTIFIC_BASELINE, etc.)
│   └── 11_ARCHIVE_METADATA/        (FILE_MANIFEST.csv, MANIFEST_SHA256.txt, ARCHIVE_CONTENTS.md, GIT_INFO.txt)
│
└── [Execution Root: Direct Python Workflow Structure]
    ├── solver/                     (Imported directly by Python runtime without PYTHONPATH manipulation)
    ├── drivers/                    (Study drivers executed by run_all.py)
    ├── figures/                    (Figure generation scripts and output/ destination)
    ├── manuscript/                 (LaTeX compilation workspace)
    ├── results/                    (raw/ and validation/ data directories)
    ├── tests/                      (V0–V5 automated test suites)
    ├── verification/               (verify_invariants.py science preservation engine)
    ├── params.json                 (Frozen physical parameter definitions)
    ├── grids.json                  (Frozen computational grid specifications)
    ├── requirements.txt            (Complete dependency specifications)
    ├── environment.yml             (Conda environment specification)
    └── run_all.py                  (One-command master reproduction runner)
```

---

## 2. Rationale for the Dual Structure

1. **Archival & Journal Reviewer Partitioning (`01_` through `11_`):**
   - Provides clear, self-contained categorical directories for journal reviewers, data repositories (e.g., Zenodo, Figshare), and long-term archival storage.
   - Allows reviewers interested specifically in manuscript files, audit trails, literature benchmarks, or raw data to locate the relevant assets immediately.

2. **Immediate Root Execution (`solver/`, `drivers/`, etc.):**
   - Allows standard Python scripts and automated pipelines to run directly from the package root via `python3 run_all.py` without requiring manual setting of `PYTHONPATH`, environment variables, or navigating deep subfolders.
   - Ensures that relative imports (such as `from solver.material import Material`) resolve natively when executed from the unzipped root directory.

3. **Byte-Identity Guarantee:**
   - Every file shared between the root execution tree and the numbered archival folders (e.g., `solver/` vs. `02_SOLVER/solver/`, `manuscript/FINAL_MANUSCRIPT.tex` vs. `01_MANUSCRIPT/FINAL_MANUSCRIPT.tex`) is **100% byte-identical** and cryptographically verified against the master SHA-256 ledger.

---

## 3. Detailed Component Descriptions

### `01_MANUSCRIPT/` & `manuscript/`
- **`FINAL_MANUSCRIPT.tex`**: Complete LaTeX source for the 30-page article. Contains zero literature overclaims, correct rational determinant $\det(A_2)$, and precise description of Figure 8 depth roots.
- **`FINAL_MANUSCRIPT.pdf`**: Final compiled publication PDF with 11 embedded vector figures and 3 tables.
- **`FINAL_MANUSCRIPT.bib`**: 47 verified BibTeX citations with complete DOIs.
- **`COMPILATION.md`**: Step-by-step instructions for `pdflatex`, `xelatex`, and `bibtex`.

### `02_SOLVER/` & `solver/`
- **`material.py`**: Physical constants, nondimensionalization scales ($v_0 = 6917.14\text{ m/s}$, $\omega_0 = 4.346\times 10^{10}\text{ rad/s}$), and baseline parameter checks.
- **`matrix.py`**: Assembly of the $10\times 10$ acoustic pencil $M(\Omega^*, k^*, p) = A_0 + p A_1 + p^2 A_2$ for Models A, B, and C.
- **`roots.py`**: Decoupled and coupled polynomial depth eigenvalue solver, extracting the 5 admissible decaying roots ($\text{Im}(p) > 0$).
- **`boundary.py`**: Construction of the $5\times 5$ surface boundary matrix $B(\Omega^*, k^*)$ enforcing mechanical traction, phason traction, electric potential, and thermal conditions.
- **`branch.py`**: Continuation tracking, secular determinant minimization $r = \sigma_{\min}(B)/\|B\|$, and branch-verified seed tracking.
- **`diagnostics.py`**: Root count verification ($n_{\text{ad}}=5$), grazing root checks, condition numbers, and polynomial degree validation ($\deg_p = 10$).
- **`resolution.py`**: Numerical accuracy bounds ($u_V \le 1.13\times 10^{-9}$, resolution floor $\varepsilon_\Delta = 1.13\times 10^{-8}$).

### `03_DRIVERS/` & `drivers/`
- **`study1_baseline.py`**: Sweeps baseline frequency grid ($\Omega = 10^{-3}..10^3$, 121 points) for Models A, B, and C with free phason and isothermal boundary.
- **`study2_friction_map.py`**: Sweeps $61\times 61$ 2D grid over frequency $\Omega$ and phason friction $D_w$.
- **`study3_thermal.py`**: Sweeps thermal relaxation time $\tau_0 = 10^{-2}..10^2\text{ ps}$ probing Lord–Shulman hyperbolic conduction.
- **`study_bc.py`**: Analyzes clamped vs. free phason surface and insulated vs. isothermal boundaries.
- **`roots_diag.py`**: Generates depth root loci across frequency decades.
- **`make_all_figures.py`**: Deterministic figure generation engine producing all 11 PDF and EPS figures directly from raw data.
- **`run_all.py`**: Master one-command reproduction runner.

### `04_LITERATURE_BENCHMARK/`
- **`independent_zhang2023_driver.py`**: Unassisted first-principles Laguerre spectral solver ($M=16$ terms) for functionally graded 1D QC Rayleigh waves (Zhang et al., 2023). Honestly computes phase velocities (~15%–21% deviation due to omitted publication scaling parameters).
- **`independent_zhang2024_driver.py`**: Evaluation driver declaring Zhang et al. (2024) as NOT REPRODUCIBLE FROM PUBLISHED INFORMATION (Class C) due to omitted interface tensors and domain scalings.
- **`LITERATURE_BENCHMARK_DRIVER.py`**: Master runner evaluating classical Rayleigh benchmarks (Class A, $1.1\times 10^{-11}$ error) and QC benchmarks.
- **`LITERATURE_REPRODUCTION_COMPARISON.csv`**: Comprehensive 21-entry comparison ledger containing only genuine calculations or explicit unreproducibility markers.
- **`MISSING_INFORMATION_LEDGER.csv`**: Itemized ledger of 9 missing publication parameters.
- **`make_benchmark_figure.py` & `make_independent_figures.py`**: Relative-path vector PDF figure generators.

### `05_RESULTS_RAW/` & `results/`
- Contains all 13 non-regenerable CSV and NPZ raw numerical datasets and the SHA-256 ledger `results/manifests/RAW_DATA_CHECKSUMS.sha256`.

### `06_FIGURES/` & `figures/`
- Publication-ready vector PDF figures (`fig1.pdf` through `fig11.pdf`) and EPS figures (`Fig01.eps` through `Fig11.eps`).

### `07_TESTS_VALIDATION/` & `tests/` & `verification/`
- Validation suite V0–V5 and the 22/22 invariant verification script `verification/verify_invariants.py`.

### `08_AUDITS/`
- Complete library of 17 scientific, formulation, literature forensic, and claim-integrity audit reports.

### `09_LITERATURE/`
- Complete BibTeX database (`all_references.bib`), category reference files, and `MISSING_REFERENCE_PDFS.md`.

### `10_DOCUMENTATION/`
- `README.md`, `REPRODUCTION.md`, `PROJECT_STRUCTURE.md`, `SCIENTIFIC_BASELINE.md`, `VALIDATION_HIERARCHY.md`, `CHANGELOG_FINAL.md`, `requirements.txt`, `environment.yml`.

### `11_ARCHIVE_METADATA/`
- Complete whole-archive SHA-256 manifests (`MANIFEST_SHA256.txt`, `FILE_MANIFEST.csv`, `ARCHIVE_CONTENTS.md`, `GIT_INFO.txt`, `VERSION_INFO.txt`, `REPRODUCTION_STATUS.md`).
