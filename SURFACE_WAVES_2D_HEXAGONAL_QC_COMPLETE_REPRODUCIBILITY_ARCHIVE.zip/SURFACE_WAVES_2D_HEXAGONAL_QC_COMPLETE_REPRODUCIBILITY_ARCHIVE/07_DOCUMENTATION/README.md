# 07_DOCUMENTATION — documentation index

| File | Content |
|---|---|
| `PROJECT_OVERVIEW.md` | what the project is, questions, method, headline findings |
| `MODEL_DESCRIPTION.md` | physics/model companion (fields, equations structure, BCs) |
| `NUMERICAL_METHOD.md` | solver pipeline companion (implementation view) |
| `PARAMETER_TABLE.md` | full parameter table (generated from params.json) |
| `DATA_DICTIONARY.md` | column semantics of every CSV/NPZ dataset |
| `FIGURE_PROVENANCE.md` | per-figure generation record (all 11 figures) |
| `FIGURE_DATA_TRACEABILITY.md` | panel→data-column traceability map (audit record) |
| `KNOWN_LIMITATIONS.md` | honest limitations & caveats |
| `CORRECTIONS_ERRATA.md` | complete correction log C1–C28 (authoritative errata) |
| `FINAL_REFERENCE_AUDIT.md` | reference-citation audit record |
| `CHANGELOG.md` | change log of the research package |
| `SCIENTIFIC_BASELINE.md` | baseline results definition (historical doc) |
| `VALIDATION_HIERARCHY.md` | validation level definitions (historical doc) |
| `PROJECT_STRUCTURE.md` | source-package structure note (historical doc) |
| `REPRODUCTION.md` | reproduction overview (historical doc; superseded by `../04_REPRODUCTION/REPRODUCE_FROM_SCRATCH.md` where they differ) |

Manuscript-level documentation lives in `02_OVERLEAF/README_OVERLEAF.md` and
the paper itself (`08_FINAL_OUTPUTS/manuscript.pdf`).
