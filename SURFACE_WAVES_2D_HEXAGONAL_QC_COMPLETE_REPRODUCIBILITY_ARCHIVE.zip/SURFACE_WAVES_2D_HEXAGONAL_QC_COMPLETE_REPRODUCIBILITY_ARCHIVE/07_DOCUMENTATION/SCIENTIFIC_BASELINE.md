> **ARCHIVE NOTE (2026-09-28).** Historical baseline summary of the source package. The authoritative formulation is the manuscript (`../02_OVERLEAF/main.tex`); a wording caveat in this note is resolved in `CORRECTIONS_ERRATA.md` (C-series).

# Scientific Baseline & Mathematical Formulation Summary

## Material Symmetries:
- 2D Hexagonal Quasicrystal (Point group $6mm$, Laue class 10, transverse isotropic in $xy$-plane, periodic along $z$-axis).
- Acoustic wave propagation along sagittal plane $(x, z)$.

## Coupled PDEs:
1. **Phonon Equations of Motion:**
   $$\sigma_{ij,j} = \rho \ddot{u}_i$$
2. **Phason Wave-Telegraph Dynamics (Model C):**
   $$H_{ij,j} = \rho_w \ddot{w}_i + D_w \dot{w}_i$$
   * Limit $D_w \to 0$: Model A (pure elastodynamics / wave-like phason).
   * Limit $\rho_w \to 0$: Model B (diffusive phason dynamics).
3. **Maxwell Quasi-Static Electrostatics:**
   $$D_{i,i} = 0$$
4. **Lord–Shulman Generalized Heat Conduction:**
   $$k_0 \nabla^2 \theta = C_e (\dot{\theta} + \tau_0 \ddot{\theta}) + T_0 (\beta_{ij} \dot{u}_{i,j} + \tau_0 \beta_{ij} \ddot{u}_{i,j}) + T_0 (\gamma_{ij} \dot{w}_{i,j} + \tau_0 \gamma_{ij} \ddot{w}_{i,j})$$

## Decoupled Classical Rayleigh Limit:
$$v_R / v_S = 0.932525905921 \quad (\text{analytic } 0.932525905931; \text{ relative error } 1.1 \times 10^{-11})$$
