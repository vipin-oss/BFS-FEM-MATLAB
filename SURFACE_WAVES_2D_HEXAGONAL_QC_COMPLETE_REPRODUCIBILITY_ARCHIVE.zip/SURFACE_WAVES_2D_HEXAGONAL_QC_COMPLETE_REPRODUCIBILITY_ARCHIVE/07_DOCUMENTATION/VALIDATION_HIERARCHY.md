> **ARCHIVE NOTE (2026-09-28).** Historical validation-hierarchy doc of the source package; see `../06_VALIDATION/README_VALIDATION.md` for the current validation record.

# Scientific Validation Hierarchy

```
=========================================================================================================
                               CERTIFIED SCIENTIFIC VALIDATION HIERARCHY
=========================================================================================================
  [LEVEL A: Internal Mathematical Verification]
   * Exact symbolic polynomial degrees (deg_p = 10, deg_omega = 10/8/10)
   * Static polynomial determinant factorisation: 410478057/25600000000000 * (k^2+p^2)^5
   * Automated model limits C->A (1.11e-9) and C->B (3.27e-9) across 121 logarithmic points
   * Two-path consistency check (omega->k vs k->omega) verified to 1.04e-9
                                        │
                                        ▼
  [LEVEL B: Independent Classical Rayleigh Limiting-Case Reproduction]
   * Pure elastic uncoupled Rayleigh wave reproduced to 1.1e-11 relative error
   * Isotropic media (nu = 1/3, nu = 0.25, nu = 0.50) exactly verified to machine precision
                                        │
                                        ▼
  [LEVEL C: Independent Implementation of Related Published QC Surface-Wave Formulations]
   * Independent spectral Laguerre solver for Zhang 2023 executes from first principles (Class B)
   * Zhang 2024 evaluated and declared NOT REPRODUCIBLE FROM PUBLICATION (Class C) due to omitted interface tensors
                                        │
                                        ▼
  [LEVEL D: Published Discrete QC Results as Literature Reference Anchors]
   * Zhang 2023 Table 3 & Zhang 2024 Table 3 cataloged strictly as literature reference anchors
                                        │
                                        ▼
  [LEVEL E: Literature Grounding of Constitutive, Material, Phason, and Thermal Components]
   * 2D Hexagonal elastic & thermal constants: Li et al. (2017), Yang et al. (2014)
   * Phason wave-telegraph dynamics: Agiasofitou & Lazar (2014) (tau_w = 10 ps)
   * Phason mobility: Chellappan et al. (2015) (C_w = 4.8e-19 m^3 s/kg, Gamma_w = 2.083e18 kg/(m^3 s))
   * Hyperbolic heat conduction: Lord & Shulman (1967) (tau_0 = 0.1 ps)
=========================================================================================================
```
