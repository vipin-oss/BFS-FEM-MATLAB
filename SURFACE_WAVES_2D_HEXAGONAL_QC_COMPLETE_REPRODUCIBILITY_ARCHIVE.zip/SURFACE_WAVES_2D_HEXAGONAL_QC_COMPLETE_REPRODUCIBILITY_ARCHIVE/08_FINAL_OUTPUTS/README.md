# 08_FINAL_OUTPUTS — final deliverable outputs

| Item | File | Notes |
|---|---|---|
| **Final manuscript** | `manuscript.pdf` | 35 pp, submission-ready (title-page placeholders for authors — see `../07_DOCUMENTATION/KNOWN_LIMITATIONS.md` #11). Byte-identical to the PDF produced from `../02_OVERLEAF/main.tex`. |
| Supplementary material | `supplementary.pdf` | **NOT AVAILABLE** — no supplementary material exists for this project; all tables are inline in the manuscript and all data are in `../03_DATA/`. |
| Final figures | `final_figures/` | `fig1..fig11.pdf` + `Fig01..Fig11.eps` (11+11) — identical to `../02_OVERLEAF/figures/`. |
| Final tables | `final_tables/` | tables are inline in the manuscript — see `final_tables/README.md`. |
| Final results | `final_results/KEY_RESULTS.md` | archived numerical results (audit-verified). |
