# KEY_RESULTS.md — archived numerical results (audit-verified)

All values below were re-verified against the raw data on 2026-09-28. Units:
nondimensional (V*, Ω*, D_w*, τ0*, δ*) unless stated; scales in `../07_DOCUMENTATION/PARAMETER_TABLE.md`.

## Branch speeds (baseline: free phason, isothermal)

| Quantity | Value | Source |
|---|---|---|
| V_A* (phason-dominated branch) | 0.310726890370 | study1_baseline.csv (V_A 0.3107268903703e-01-style repr) |
| V_A* two-path cross-check | 0.310726616 (Ω→k vs k→Ω anchor; worst |Δ| 9.35e-10) | V1 log |
| V_B*, V_C* range over band | [0.464987, 0.466301] (B); [0.466264, 0.467355] (C) | fig9 z-limits (exact data min/max) |
| V_B*/v_S at baseline | 0.9326028 = 0.9326028·v_S (decoupled), +7.7e-5 vs Rayleigh | fig2 |
| decoupled Rayleigh V_R* (ν=1/3) | 0.932525905931 analytic; computed 0.932525906 (rel err 1.1e-11) | V2 |
| v_P/v0, v_S/v0 (decoupled) | 1, 0.5 (exact) | V2 |

## Model differences

| Quantity | Value |
|---|---|
| Δ_AC (A vs C) | ≈0.334 (≈1.4e7 × floor) — branch identity |
| \|V_B−V_C\| at band top | 4.4e-6 absolute (9.5e-6 relative) |
| Δ_BC resolvability | 95/121 points below floor ε_Δ=1.13e-8; crosses unity (floor-normalised) only above Ω*≈50–56 |
| matched-χ collapse factor | ≤1.0035 (worst; manuscript rounds to “within 1.004”) |
| Δ_BC max at D_w*≤1 / at D_w*=1e4 | ≈5.0e-3 / ≤1.25e-7 |

## Thermal (Lord–Shulman) sensitivity (model C)

| Quantity | Value |
|---|---|
| ΔT maxima per τ0* (4 non-reference) | 1.09e-5, 1.07e-5, 2.94e-5, 7.879e-5 |
| dips above 1e-16 floor | 0/0/1/0 (only τ0*=1e-2, Ω*=44.7, ΔT=5.83e-8) |
| onset coordinate | τ0*Ω* = 1.3e-5 … 1.4e-2 (curve-dependent) |

## Boundary condition (free → clamped phason)

| Quantity | Value |
|---|---|
| \|ΔV\|/V (model C) | 1e-9 → 8.1e-6 (Ω*: 1e-3 → 1e3), monotone above floor |
| model A companion max | 8.0609e-6 (fig7 dV/V column) |
| penalty δpen | comparable magnitude, growing with Ω* |

## Localisation

| Quantity | Value |
|---|---|
| Ω*δ* product | ≈1.99 (A); ≈1.29 (B/C) — constant across six decades |
| δ* at band top | ≈0.205 nm (continuum caveat) |

## Verification gates

| Check | Value |
|---|---|
| two-path worst \|Δ\| (15 anchors) | 9.35e-10 |
| model-limit gates (full grid 121/121) | 1.110e-9 (C→A, D_w*→1e-14); 3.266e-9 (C→B, ρ_w*→1e-8) |
| resolution benchmark | u_V ≤ 1.13e-9 → ε_Δ = 1.13e-8 |
| complex-k speed error | ≤6.6e-7 rel (A ≤2.5e-10) |
| complex-k attenuation | ≤7.0e-4 per λ (A ≤3.1e-7) |
| complex-k Δ_BC shift | ≤8.0e-10 baseline; ≤8.4e-8 at D_w*=0.01 |
| fig2 quasi-static coupled ratios | A 0.62145378; B/C 0.9326028 |
| fig8 r range | 9.67e-9 … 3.249e-5 |
| fig8 P_w (model A) | 0.99095 (raw-column basis) |
| Δ_BC max abs (BC sweep) | 9.4829e-6 (26/121 above floor; 95/121 within) |

## Manuscript

`manuscript.pdf` — 35 pages, 47 bibliography entries, 11 figures, all
references/labels resolved. Tables inline (see `final_tables/README.md`).
