# final_tables/

All tables of the manuscript are typeset inside `../manuscript.pdf`
(source: `../02_OVERLEAF/main.tex`):

| Table | Content | Data source |
|---|---|---|
| `tab:params` | dimensional parameter set + provenance | `../01_PROGRAM/params.json` |
| `tab:nondim` | nondimensional groups + swept ranges | `params.json` + `grids.json` |
| `tab:dim` | dimensional endpoints (f, λ, δ*) | computed (documented in `KEY_RESULTS.md`) |
| `tab:cxk` | complex-wavenumber check anchors | `../06_VALIDATION/validation_results/complex_k_dispersion.log` |

There are **no standalone table files** (CSV/LaTeX) in the archive beyond the
raw data in `../03_DATA/`; the manuscript tables are the canonical rendered form.
