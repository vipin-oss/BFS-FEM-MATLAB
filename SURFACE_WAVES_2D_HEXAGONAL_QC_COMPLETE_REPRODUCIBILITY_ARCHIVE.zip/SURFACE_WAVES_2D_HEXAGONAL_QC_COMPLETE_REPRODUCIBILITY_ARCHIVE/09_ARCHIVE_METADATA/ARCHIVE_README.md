# SURFACE_WAVES_2D_HEXAGONAL_QC_COMPLETE_REPRODUCIBILITY_ARCHIVE

**Complete reproducibility archive** of the research project
"Surface waves in a 2D hexagonal piezoelectric thermoelastic quasicrystal
half-space" (three phason models A/B/C; manuscript 35 pp).

Built 2026-09-28. This archive is self-contained: code, raw data, manuscript
source, figures, validation evidence, derivations record, and integrity
manifests. Start at `FINAL_PACKAGE_STATUS.md` (archive root) for the
verification checklist, then `07_DOCUMENTATION/PROJECT_OVERVIEW.md`.

## Folder map

```
01_PROGRAM/            complete runnable program (run_all.py + solver + drivers
                       + figures + tests + verification + working data copy)
02_OVERLEAF/           Overleaf-ready manuscript folder (main.tex compiles stand-alone)
03_DATA/               canonical data archive (raw/, validation/, metadata/)
04_REPRODUCTION/       how to reproduce: REPRODUCE_FROM_SCRATCH.md, RUN_ORDER.md,
                       parameter_manifest.json, run_manifest.json, expected_outputs/,
                       file_manifest_sha256.csv
05_DERIVATIONS/        derivation navigation record (6 topics)
06_VALIDATION/         benchmark sources+DOIs, validation scripts & archived results
07_DOCUMENTATION/      overview, model, numerics, parameters, data dictionary,
                       figure provenance, limitations, errata (C1–C28)
08_FINAL_OUTPUTS/      manuscript.pdf, final_figures/, final_tables/, KEY_RESULTS.md
09_ARCHIVE_METADATA/   this README, VERSION, SHA256SUMS.txt, PROJECT_MANIFEST.json
FINAL_PACKAGE_STATUS.md  verification checklist + reproduction-test report
```

## Provenance chain (short)

1. Research campaign (Sept 2026) produced the manuscript + computation in the
   submission package `FINAL_SURFACE_WAVES_2D_HEXAGONAL_QC_RESEARCH_PACKAGE_SUBMISSION`.
2. Three full audits + GPT-audit adjudication (2026-09-28) corrected captions,
   wording and one figure z-limit; all corrections logged in
   `07_DOCUMENTATION/CORRECTIONS_ERRATA.md` (C1–C28).
3. This archive reorganises that package into the reproducibility structure,
   deduplicates identical mirrors (hash-identical copies documented),
   removes caches/internal files, and adds an **actual reproduction test**
   (clean environment regeneration + comparison; report in
   `FINAL_PACKAGE_STATUS.md`).

## Integrity

- `SHA256SUMS.txt` — SHA-256 of every file (relative paths from archive root).
- `../04_REPRODUCTION/file_manifest_sha256.csv` — manifest in CSV form
  (path, bytes, sha256).
- `../04_REPRODUCTION/verification/verify_checksums.py` — verifier script.
- `../03_DATA/metadata/RAW_DATA_CHECKSUMS.sha256` — historical raw-data
  checksums from the production runs (compare with the current raw/ hashes to
  detect any post-production edit of the raw data).

## Honesty policy

Unknowns are marked **NOT DOCUMENTED** / **NOT AVAILABLE** with the location
where the information would be expected. Nothing was fabricated to fill gaps.
