# FINAL_PACKAGE_STATUS.md

**Project:** Surface waves in a 2D hexagonal piezoelectric thermoelastic
quasicrystal half-space (three phason models A/B/C; Lord–Shulman thermoelasticity)
**Deliverable:** `SURFACE_WAVES_2D_HEXAGONAL_QC_COMPLETE_REPRODUCIBILITY_ARCHIVE`
**Date:** 2026-09-28  **Version:** 1.0 (FINAL)

---

## 1. Archive contents summary

| | |
|---|---|
| Structure | 9 folders + this file (see `09_ARCHIVE_METADATA/ARCHIVE_README.md`) |
| Inventory | `09_ARCHIVE_METADATA/PROJECT_MANIFEST.json` (by-folder/extension counts) |
| Integrity | `09_ARCHIVE_METADATA/SHA256SUMS.txt` + `04_REPRODUCTION/file_manifest_sha256.csv` |
| Errata | `07_DOCUMENTATION/CORRECTIONS_ERRATA.md` (C1–C29) |

## 2. Overleaf-ready manuscript (`02_OVERLEAF/`)

- `main.tex` + `references.bib` + `figures/` (11 PDF + 11 EPS) + `compile.sh`.
- Stand-alone compile **verified 2026-09-28 with tectonic 0.15.0: 35 pages,
  0 errors, main.pdf = 827.04 KiB** (fresh directory copy; no path edits needed).
- No custom class/bst; no `main.bbl` (embedded thebibliography — NOT APPLICABLE).
- Title-page author placeholders remain (documented limitation #11).

## 3. Manuscript ↔ code ↔ data ↔ figure consistency

- `main.tex` byte-identical across `01_PROGRAM/manuscript/`, `02_OVERLEAF/`
  (hash-verified). Archived `manuscript.pdf` is the compiled twin (35 pp).
- Figure sets byte-identical across `01_PROGRAM/manuscript/figures/`
  (11 PDFs), `02_OVERLEAF/figures/` and `08_FINAL_OUTPUTS/final_figures/`
  (11 PDFs + 11 EPS) — hash-verified (earlier mirror copies differed only in
  embedded PDF creation timestamps; pixel comparison = 0 differing pixels).
- Every figure panel traces to raw columns: `07_DOCUMENTATION/FIGURE_DATA_TRACEABILITY.md`
  + `FIGURE_PROVENANCE.md`. Caption values re-audited against raw data
  (errata C-series record).

## 4. Actual reproducibility test (performed 2026-09-28)

**Environment:** clean isolated directory `/home/user/repro_test/`, CPython
3.13.14, numpy/scipy/matplotlib/sympy; pdflatex ABSENT (compile step uses
tectonic 0.15.0 as documented in `02_OVERLEAF/compile.sh`).

**Run 1 — unmodified program, `python3 run_all.py --from-scratch`:**
**RESULT: PARTIAL PASS (documented finding).** All five production drivers
completed (study1 363 rows; study2 7442 rows + fig9b NPZ + fig5 slice; study3
605 rows + fig9c NPZ; study_bc 484 + 121 rows; roots_diag). All six test
suites **PASS**: V0 integrity, V1 two-path (15/15, worst 9.35e-10 — matches the
archived gate exactly), V2 elastic limit, V3 model limits (both, 121-pt grid),
V4 symbolic, V5 nondim. The figure and invariant steps then **FAILED** on a
program path defect (below) — run_all correctly reported
`REPRODUCTION: FAIL`. Wall time ≈ 2 h (study2 ≈ 86 min single core).

**Finding during the test (honest):** the source program had a path mismatch —
drivers wrote outputs to `results/` while the figure/invariant code read
`results/raw/`. The test exposed it; fix = erratum **C29** (paths unified on
`results/raw/`; no numerical code changed).

**Run 2 — program + C29 fix, full/fast verification:**
**RESULT: PASS.** After the C29 path fix (applied to the same isolated tree):
`python3 run_all.py` — environment OK, invariants **22/22 PASS**, figures
**11/11 regenerated**, `REPRODUCTION_REPORT.md` = `REPRODUCTION: PASS`.
(Manuscript compile is a separate documented step — see comparisons.)

**Comparisons performed:**
- regenerated raw data vs `03_DATA/raw/` — **PASS (zero numerical difference).** All regenerated datasets compared
against `03_DATA/raw/` field-by-field (skipping only `run_id`/`solver_hash`
timestamp/hash columns): worst relative difference **0.000e+00** across
`study1_baseline.csv`, `study2_map_incremental.csv` (7442 rows), `fig4_deltas`,
`fig5_friction1d`, `fig6_tau` (incl. `above_floor` column), `fig7_bc`(+summary),
`fig8_roots`(+summary), `v2_elastic_limit` (transcript identical),
`v3_model_limits`, and both NPZ files (all arrays).
- regenerated figures vs `08_FINAL_OUTPUTS/final_figures/` — **PASS (11/11 pixel-identical).** Regenerated `fig1..fig11.pdf` rendered and
compared pixel-by-pixel against `08_FINAL_OUTPUTS/final_figures/`: 0 differing
pixels at 110 dpi. (PDF bytes differ only in embedded creation timestamps.)
- manuscript compile — **PASS.** `02_OVERLEAF/` compiled stand-alone in a clean copy with
tectonic 0.15.0 (`bash compile.sh`): `main.pdf`, **35 pages**, 0 errors,
827.04 KiB. (pdflatex is absent in the test environment; run_all's own compile
step reports SKIPPED — the tectonic path is the documented substitute.)
- scientific gates vs `04_REPRODUCTION/expected_outputs/EXPECTED_VALUES.md` — **PASS.** V1 worst 9.35e-10 (expected 9.35e-10); V2 Rayleigh 0.932525906;
V3 gates PASS on the full grid; V0/V4/V5 PASS; invariants 22/22; complex-k
13-point check re-run = identical values to the archived log
(`06_VALIDATION/validation_results/complex_k_dispersion.log`). See
`04_REPRODUCTION/expected_outputs/EXPECTED_VALUES.md` for the full gate table.

## 5. What was reproduced / what not

| Item | Status |
|---|---|
| 5 production drivers (363 + 7442 + 605 + 484 + roots rows) | REPRODUCED (Run 1; zero numerical difference) |
| Test suites V0–V5 | REPRODUCED — V0–V5 all PASS (Run 1) |
| 22 invariant checks | REPRODUCED — 22/22 PASS (Run 2) |
| 11 figures + 11 EPS | REPRODUCED — 11/11 pixel-identical (Run 2) |
| resolution_bench (frozen 4 points) | REGENERATED (documented command) — see numerical-sensitivity note in EXPECTED_VALUES.md; frozen archived file kept canonical |
| complex-k check (13 points) | REPRODUCED — values identical to archived log (rerun 2026-09-28) |
| Manuscript compile (35 pp) | PASS (tectonic, §2) |
| Literature benchmark suite (historical) | NOT REPRODUCED in this rerun (archived evidence retained; see `06_VALIDATION/README_VALIDATION.md`) |
| Byte-identical figure PDFs across runs | NOT expected (embedded timestamps); pixel/data identity verified |

## 6. Known issues / limitations

See `07_DOCUMENTATION/KNOWN_LIMITATIONS.md` (14 items: continuum validity at
the band top, real-axis estimator bounds, declared surrogate parameters,
library-version last-digit sensitivity, Dev/Sladek/Stevens (2025) citation
record, etc.) + C29 in the errata.

## 7. Environment recorded

- `01_PROGRAM/requirements.txt` (numpy>=1.24, scipy>=1.10, matplotlib>=3.7,
  sympy>=1.11, pypdf>=3.0), `01_PROGRAM/environment.yml` (conda-forge).
- Test-run stack: CPython 3.13.14 + pip packages (exact production pip
  versions NOT DOCUMENTED — see KNOWN_LIMITATIONS #10).
- TeX: tectonic 0.15.0 (static binary) used for all 2026-09-28 compiles.

## 8. Final file counts

212 files total (see `09_ARCHIVE_METADATA/PROJECT_MANIFEST.json` for the
by-folder/extension breakdown). Key counts: **58 Python program files**
(01_PROGRAM + validation/benchmark scripts), **18 data files**
(16 CSV + 2 NPZ in `03_DATA/raw`, plus validation/benchmark CSVs), **44 figure
files** (11 fig PDFs + 11 EPS in `08_FINAL_OUTPUTS/final_figures`, same PDFs in
`02_OVERLEAF/figures` and `01_PROGRAM/manuscript/figures`, 4 benchmark
validation figures), **1 TeX file** (`main.tex` + its mirror),
**1 .bib**, **validation**: 6 test suites + 22 invariants + complex-k + literature
benchmark suite with archived logs.

## 9. Integrity check command

```bash
python3 04_REPRODUCTION/verification/verify_checksums.py
# or: cd 09_ARCHIVE_METADATA && sha256sum -c SHA256SUMS.txt
```

**PASS** — `python3 04_REPRODUCTION/verification/verify_checksums.py`:
`checked: 210 OK, 0 mismatch, 0 missing; raw mirror (01_PROGRAM vs 03_DATA): OK`.
Historical production checksums (`03_DATA/metadata/RAW_DATA_CHECKSUMS.sha256`)
also verify ALL OK against `03_DATA/raw/` — the raw data are byte-identical to
the 2026-09-06 production runs.

## 10. How to use this archive

1. Read `09_ARCHIVE_METADATA/ARCHIVE_README.md`.
2. Reproduce: `04_REPRODUCTION/REPRODUCE_FROM_SCRATCH.md` (STEP 0–7).
3. Overleaf: upload `02_OVERLEAF/` as a project.
4. Expected values: `04_REPRODUCTION/expected_outputs/EXPECTED_VALUES.md`.


## 12. Final verification checklist (A–T)

| # | Item | Status |
|---|---|---|
| A | Single archive in the required 9-folder structure | PASS |
| B | All code in `01_PROGRAM` (runnable tested layout) | PASS |
| C | All data in `03_DATA` (raw mirror hash-identical) | PASS |
| D | All figures in `08_FINAL_OUTPUTS/final_figures` + `02_OVERLEAF/figures` (byte-synced) | PASS |
| E | All TeX in `02_OVERLEAF` (main.tex + references.bib) | PASS |
| F | Validation files complete (scripts + results + benchmarks + DOIs) | PASS |
| G | `02_OVERLEAF` compiles stand-alone (no path edits) | PASS (35 pp) |
| H | Manuscript ↔ figures ↔ data consistency verified | PASS |
| I | `parameter_manifest.json` complete; unknowns marked NOT DOCUMENTED | PASS |
| J | `run_manifest.json` per result with commands | PASS |
| K | `REPRODUCE_FROM_SCRATCH.md` steps executed as written | PASS (Run 1+2) |
| L | `RUN_ORDER.md` matches actual dependency order | PASS |
| M | `FIGURE_PROVENANCE.md` complete for all 11 figures | PASS |
| N | `DATA_DICTIONARY.md` complete for all datasets | PASS |
| O | Validation record with source papers + verified DOIs | PASS |
| P | Derivations set (6 topics) present, no conflicting versions | PASS |
| Q | SHA-256 integrity manifests + verifier script | PASS |
| R | Actual reproduction test performed, failures not hidden | PASS (Run 1 FAIL finding + fix + Run 2 PASS) |
| S | No fabrication; no caches; no internal/prompt files; redundancy removed | PASS |
| T | FINAL_PACKAGE_STATUS.md + single ZIP produced | PASS |

## 13. Sign-off

Built and verified 2026-09-28 as a complete reproducibility archive of the
audited research package. No data, parameter, benchmark, citation, command,
version or provenance entry was fabricated; all unknowns are marked
NOT DOCUMENTED / NOT AVAILABLE in place.
