# SUBMISSION CHECKLIST — TRILAYER_SH_WAVE

Manuscript: *Circumferential SH-Wave Dispersion in a Functionally Graded Smart
Cylindrical Structure with Gurtin–Murdoch Surface Elasticity and
Spring–Membrane Interfaces*

Final version: `CKP/09_OUTPUTS/Paper_FINAL.pdf` (40 pages, A4)
Final source: `CKP/02_MANUSCRIPT/Paper_FINAL.tex`
Cover letter: `CKP/09_OUTPUTS/cover_letter_FINAL.pdf` (2 pages)
Completed: 2026-10-04, end of Phase 14.

---

## A. Technical state of the manuscript — VERIFIED

| Item | Status |
|------|--------|
| Compilation (`latex → bibtex → latex ×3 → dvips -P pdf → ps2pdf`) | **0 errors** |
| Undefined references | **0** |
| Undefined citations | **0** |
| `??` in the output | **0** |
| Overfull boxes | **0** |
| Underfull boxes | **0** |
| Labels | 105 defined, 105 unique, 0 duplicates, 0 dangling |
| Bibliography | 42 entries, 42 cited, 0 uncited, 0 duplicate keys |
| Figures | 12, all EPS, all present in `02_MANUSCRIPT/figures/`, all referenced in order |
| Tables | 4, all referenced |
| Page size / length | A4, 40 pages |
| Declarations present | Funding; Competing Interest; Data Availability |
| Appendix | Derivation of the coefficient matrix |

---

## B. Scientific state — VERIFIED

| Item | Status |
|------|--------|
| Governing equations, reduction to Bessel form, and the 12 boundary/interface conditions | Re-derived independently; correct |
| $12\times12$ coefficient matrix | Verified entry by entry against the twelve conditions |
| Gurtin–Murdoch sign convention | Verified by an independent pillbox force balance |
| Limiting cases | Evaluated numerically; agreement at machine precision with an independent $6\times6$ system and with the closed-form annulus condition |
| Passivity of the spring–membrane interface | **Not satisfied over the whole wavenumber range at the tabulated parameters.** Quantified in Sec. 7.2, Table 4 and Conclusions item 5; consequences computed (≤ 1 %) rather than assumed |
| Gurtin–Murdoch contribution | Carried exactly, numerically inert at these radii; quantified in Sec. 7.13 |
| Novelty claims | Narrowed to what the model contains; three close prior works added and distinguished (AD-08) |
| Claim vs. computation | Every quantitative claim traced to a recomputed quantity; recorded in `06_VALUE_LEDGER/VALUE_LEDGER.csv` (231 rows) |
| Language | British English throughout; no boilerplate, no hedging, no unsupported evaluative claims (Phase 11) |
| Internal consistency | Numbers, symbols, units, cross-references and terminology verified across abstract, tables, figures and conclusions (Phase 13) |

---

## C. Author actions still required before submission

| ID | Item | Blocking? |
|----|------|-----------|
| AD-01 | **Target journal is unresolved.** The cover letter names *Composites Part B: Engineering*; `Final.tex` in the baseline declared *Waves in Random and Complex Media*. **Choose one** and re-run the format check against its Instructions for Authors. | **YES** |
| AD-30 | Confirm the year of `Dhua2026` (the record used gives publication 2025, accepted 21 Jan 2025). | No — minor |
| AD-32 | Confirm British vs American spelling for the chosen journal (15 tokens, mechanical). | No |
| AD-36 | The limiting-case validation numbers were produced by an independent re-implementation; re-run with the authors' own code and confirm. | No — but do it |
| AD-29 | The interfacial membrane stiffness $T_b=T_c=10^{6}$ N/m places the model outside the passive regime for $n\ge2$. Options: keep with the present quantified caveat (recommended), or lower to $\le5.6\times10^{3}$ N/m and regenerate all 22 figures. | No — the caveat is in the text |
| AD-38 | Confirm $c_{44}^{(3)}=5.90\times10^{11}$ N/m² against `Gupta2025`. If it is a transcription error the PM layer must be recomputed. | No — but check |
| AD-39 | Supply the averaging rule and phase fraction behind the MEE effective constants, or cite the specific table in `Gupta2026`. | No |
| AD-40 | The 27 % branch step at $K_b=10^{12}$ N/m³ is disclosed but the splice is not resolved. | No — the physics conclusion is unaffected |
| AD-37 | 40 pages: if the journal imposes a limit, delete the inline duplicates of the limitations statements rather than the *Scope and Limitations* subsection. | No |

---

## D. Journal-format items that CANNOT be checked yet

These depend on the Instructions for Authors, which were not supplied
(AD-01). Check each against the chosen journal before submitting.

1. Manuscript template and class (`elsarticle` is assumed).
2. Reference style (numerical, 42 entries).
3. Abstract length (the present abstract is ~200 words).
4. Keyword count and format (6 keywords are given).
5. Figure format: 12 EPS files, all regenerated; check the journal's resolution and
   colour requirements.
6. Table format (4 tables).
7. Author affiliation superscript conventions and the corresponding-author mark.
8. Declaration-section headings and their required wording.
9. Supplementary material policy (none is needed here).
10. Cover-letter length and required statements.

---

## E. Files in the submission package

| File | Purpose |
|------|---------|
| `09_OUTPUTS/Paper_FINAL.pdf` | The manuscript |
| `02_MANUSCRIPT/Paper_FINAL.tex` | Its source |
| `03_REFERENCES/ascexmpl-new.bib` | Bibliography (42 entries) |
| `02_MANUSCRIPT/figures/*.eps` | The 12 figures (22 EPS files on disk, 12 unique figures) |
| `09_OUTPUTS/cover_letter_FINAL.pdf` | Cover letter |
| `09_OUTPUTS/cover_letter_FINAL.tex` | Its source |
| `09_OUTPUTS/SUBMISSION_CHECKLIST.md` | This file |
| `07_PHASE_REPORTS/PHASE_08_*.md` … `PHASE_14_*.md` | The audit record (internal, not for submission) |

---

## F. Do not submit

Everything under `00_STATE/`, `01_BASELINE/`, `04_CODE/`, `06_VALUE_LEDGER/`,
`08_INTERNAL_QC/` and the phase reports is internal working material. The
manuscript and the cover letter are the only documents intended for the
journal.
