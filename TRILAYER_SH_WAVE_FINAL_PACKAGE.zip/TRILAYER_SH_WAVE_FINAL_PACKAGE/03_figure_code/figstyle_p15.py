# -*- coding: utf-8 -*-
"""PHASE 15 - one coherent visual language for every manuscript figure.

Design rules (from the Phase-15 brief)
--------------------------------------
* white background, no decoration, hierarchy through contrast and spacing
* every panel generated AT ITS FINAL PRINTED SIZE, so the font sizes below
  are the font sizes the reader sees (the LaTeX \\includegraphics width is
  chosen to reproduce the figure 1:1 - never rescale a panel)
* fonts:  axis labels 10 pt | tick / legend / annotation 8.5 pt | panel
  label bold 11 pt
* line widths:  main curve 1.6 | secondary / reference 1.0 | axes 0.9
* every important curve is separable by TWO properties
  (colour + line style, or colour + marker) so the figures survive
  greyscale printing and colour-blind viewing
* legends sit OUTSIDE the data region: in a dedicated cell of the panel grid
  for multi-panel figures, or above/below the single panel
* overlapping curves are never hidden: a y-magnified inset is added whenever
  the spread between curves is below 3 % of the panel's y-range

Sizes
-----
\\textwidth = 170 mm (single-column manuscript).
  single-panel figures : 84 mm wide  (one column)
  multi-panel figures  : 170 mm wide (full text block), panels 76 mm each
"""
import os
import matplotlib
matplotlib.use('Agg')
from matplotlib import rcParams
from matplotlib import pyplot as plt

# ------------------------------------------------------------------ sizes
MM = 1.0 / 25.4
SINGLE_W = 84.0 * MM          # single-column figure
FULL_W = 170.0 * MM           # full text block
PANEL_W = 76.0 * MM           # one panel inside a full-width figure
PANEL_H = 54.0 * MM
ROW_PITCH = 68.0 * MM         # panel + tick labels + axis label
GRID_H_2ROW = 146.0 * MM      # 2 x 2 panel grid (legend in cell 4)
GRID_H_1ROW = 89.0 * MM       # 1 x 2 panel grid + full-width legend row

# ------------------------------------------------------------------ fonts
rcParams.update({
    'font.family': 'serif',
    # STIX General is a Times-compatible serif with the full weight set and
    # it embeds as TrueType (Type 42); Type 3 output is rejected by several
    # publishers, and the only other Times clone available here (Nimbus
    # Roman, CFF outlines) cannot be embedded as Type 42.
    'font.serif': ['STIXGeneral', 'Times New Roman', 'Times', 'DejaVu Serif'],
    'mathtext.fontset': 'stix',
    'font.size': 8.5,
    'axes.labelsize': 10.0,
    'xtick.labelsize': 8.5,
    'ytick.labelsize': 8.5,
    'legend.fontsize': 8.5,
    'axes.titlesize': 10.0,
    'axes.linewidth': 0.9,
    'lines.linewidth': 1.6,
    'lines.solid_capstyle': 'round',
    'xtick.major.width': 0.9,
    'ytick.major.width': 0.9,
    'xtick.minor.width': 0.6,
    'ytick.minor.width': 0.6,
    'xtick.major.size': 4.0,
    'ytick.major.size': 4.0,
    'xtick.minor.size': 2.2,
    'ytick.minor.size': 2.2,
    'xtick.direction': 'in',
    'ytick.direction': 'in',
    'xtick.top': False,
    'ytick.right': False,
    'legend.frameon': False,
    'legend.handlelength': 2.0,
    'legend.handletextpad': 0.5,
    'legend.columnspacing': 1.2,
    'legend.labelspacing': 0.35,
    'legend.borderpad': 0.0,
    'figure.dpi': 300,
    'savefig.dpi': 300,
    'ps.fonttype': 42,
    'pdf.fonttype': 42,
})

# ------------------------------------------------------------------ colour
# Okabe-Ito: colour-blind safe, restrained, greyscale-legible.
CB = ['#0072B2',   # blue
      '#D55E00',   # vermillion
      '#009E73',   # bluish green
      '#BC5090',   # magenta (colour-blind-safe substitute for the
                   # Okabe-Ito reddish purple, which collides with the
                   # blue under deuteranopia)
      '#E69F00',   # orange
      '#56B4E9']   # sky blue
GREY = '#666666'
LGREY = '#B0B0B0'
INK = '#1A1A1A'

# ------------------------------------------------- line styles and markers
LS = ['-', '--', '-.', ':', (0, (5, 1.5)), (0, (1, 1.2))]
MK = ['o', 's', '^', 'D', 'v', 'P']

LW_MAIN = 1.6
LW_REF = 1.0
MS = 4.0          # marker size
MEW = 0.8         # marker edge width

# ------------------------------------------------------------ layer fills
LAYER_FILL = ['#EAF2FA', '#F7E3D0', '#CFE3D4']   # FGO / MEE / PM:
                                            # tints chosen so the three
                                            # bands also separate in
                                            # greyscale (L = 0.88 / 0.79 /
                                            # 0.73); the old tints were
                                            # 0.80 / 0.79 / 0.82 and
                                            # printed as one flat grey   # FGO, MEE, PM (solid: EPS-safe)
LAYER_NAME = ['FGO', 'MEE', 'PM']


def style(i):
    """colour, line style and marker for the i-th data series."""
    return CB[i % len(CB)], LS[i % len(LS)], MK[i % len(MK)]


# ------------------------------------------------------------------ panels
def rect_mm(fig, x_mm, y_mm, w_mm, h_mm):
    r"""Axes rectangle from absolute millimetres (origin: bottom-left).

    Working in millimetres is what keeps every panel at its designed printed
    size; the LaTeX \includegraphics width then reproduces the figure 1:1 and
    the font sizes below are exactly the sizes the reader sees.
    """
    W, H = fig.get_size_inches() / MM
    return [x_mm / W, y_mm / H, w_mm / W, h_mm / H]


# --- panel geometry inside the full-width (170 mm) multi-panel figures -----
PANEL_X = [19.0, 99.0]                # left column, right column  (mm)
PANEL_W_MM, PANEL_H_MM = 66.0, 54.0
GRID2_Y = [83.0, 15.0]                # top row, bottom row        (mm)
GRID1_Y = 26.0                        # single panel row           (mm)


def grid2(fig, row, col):
    """(a)(b) top row, (c) and the legend cell bottom row - 170 x 146 mm."""
    return rect_mm(fig, PANEL_X[col], GRID2_Y[row], PANEL_W_MM, PANEL_H_MM)


def grid1(fig, col):
    """(a)(b) side by side - 170 x 89 mm, legend row underneath."""
    return rect_mm(fig, PANEL_X[col], GRID1_Y, PANEL_W_MM, PANEL_H_MM)


def legend_row(fig):
    """Full-width legend cell under a one-row panel grid (170 x 89 mm)."""
    return rect_mm(fig, 9.0, 1.0, 156.0, 20.0)


def add_panel_label(ax, lab, title=None):
    """Bold '(a)' plus an optional grey title, ABOVE the axes frame.

    Both sit in the reserved top margin, so they can never cover data and
    are never clipped: the label is inside the axes' own left edge and the
    reserved margin is 9 mm against an 11 pt (3.9 mm) cap height.
    """
    ax.text(0.0, 1.035, lab, transform=ax.transAxes, fontsize=11,
            fontweight='bold', va='bottom', ha='left', color=INK)
    if title:
        ax.text(0.115, 1.035, title, transform=ax.transAxes, fontsize=9,
                va='bottom', ha='left', color=GREY)


def add_panel_label(ax, lab, title=None):
    """Bold '(a)' in the top-left margin plus an optional grey panel title.

    Both sit ABOVE the axes frame, so they can never cover data.
    """
    ax.text(-0.135, 1.045, lab, transform=ax.transAxes,
            fontsize=11, fontweight='bold', va='bottom', ha='left',
            color=INK)
    if title:
        ax.text(0.005, 1.045, title, transform=ax.transAxes,
                fontsize=9, va='bottom', ha='left', color=GREY)


def add_corner_note(ax, txt, corner='tr'):
    """Small grey note inside an empty corner of the panel."""
    x, ha = (0.97, 'right') if corner == 'tr' else (0.03, 'left')
    ax.text(x, 0.94, txt, transform=ax.transAxes, fontsize=8.5,
            ha=ha, va='top', color=GREY, style='italic')


def finish(ax, xlabel, ylabel, xlim=None, ylim=None, logx=False, logy=False,
           use_offset=False):
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if logx:
        ax.set_xscale('log')
    if logy:
        ax.set_yscale('log')
    if xlim:
        ax.set_xlim(*xlim)
    if ylim:
        ax.set_ylim(*ylim)
    if not use_offset:
        try:
            ax.ticklabel_format(axis='y', useOffset=False, style='plain')
        except Exception:
            pass
    try:
        from matplotlib import ticker as mtick
        if ax.get_xscale() == 'linear':
            ax.xaxis.set_major_locator(
                mtick.MaxNLocator(nbins=6, steps=(1, 2, 2.5, 5, 10)))
        if ax.get_yscale() == 'linear':
            ax.yaxis.set_major_locator(
                mtick.MaxNLocator(nbins=6, steps=(1, 2, 2.5, 5, 10)))
    except Exception:
        pass
    ax.tick_params(axis='both', which='major', pad=2.5)


def legend_cell(fig, rect, handles, labels, title=None, ncol=1):
    """A grid cell that contains only the figure legend (never over data)."""
    ax = fig.add_axes(rect)
    ax.axis('off')
    lg = ax.legend(handles, labels, loc='center', ncol=ncol,
                   title=title, frameon=False)
    if title:
        lg.get_title().set_fontsize(8.5)
    return ax


def magnified_inset(ax, x, y, w, h, xlim, ylim, label, tick_fmt=None):
    """A y-magnified view of the same curves - never hides data."""
    from mpl_toolkits.axes_grid1.inset_locator import mark_inset
    iax = ax.inset_axes([x, y, w, h])
    iax.set_xlim(*xlim)
    iax.set_ylim(*ylim)
    iax.tick_params(labelsize=7.0, pad=1.5)
    iax.ticklabel_format(axis='y', useOffset=False, style='plain')
    for s in ('top', 'right'):
        iax.spines[s].set_visible(False)
    iax.set_title(label, fontsize=7.5, color=GREY, pad=2.0, loc='left')
    return iax


def save(fig, name, outdir=None):
    """Save at exact figure size (no bbox cropping) so fonts stay 1:1."""
    outdir = outdir or os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    '..', '09_OUTPUTS', 'regenerated_figures')
    outdir = os.path.abspath(outdir)
    os.makedirs(outdir, exist_ok=True)
    fig.savefig(os.path.join(outdir, '%s.eps' % name), format='eps')
    fig.savefig(os.path.join(outdir, '%s.png' % name), format='png', dpi=300)
    plt.close(fig)
    print('   %-34s %.1f x %.1f mm'
          % (name, fig.get_size_inches()[0] / MM, fig.get_size_inches()[1] / MM))
