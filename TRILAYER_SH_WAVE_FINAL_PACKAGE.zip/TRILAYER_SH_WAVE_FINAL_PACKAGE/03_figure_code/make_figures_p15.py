# -*- coding: utf-8 -*-
"""PHASE 15 - regenerate every manuscript figure to one coherent, Q1-journal
visual standard.

Scientific content is IDENTICAL to the Phase-07/08 production figures:
the same root sets (09_OUTPUTS/recomputed_figures/cache/roots_<tag>.json),
the same branch assignment (track_joint, with the two ambiguous cases taken
from continued_extreme.json), the same c_p = omega*d/n, the same mode shapes.
Only the presentation is new.  No value is recomputed, smoothed, resampled or
interpolated; no point is dropped.

Run from 04_CODE/.
"""
import os
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
from scipy.special import jv, yv

import trilayer_sh as T
import track_joint as TJ
import figstyle_p15 as S

os.chdir(os.path.dirname(os.path.abspath(__file__)))
CACHE = '../09_OUTPUTS/recomputed_figures/cache'
D11 = 3.01329e-08
CONT = json.load(open(os.path.join(CACHE, 'continued_extreme.json')))
NAMES = ['fundamental', 'first higher', 'second higher']

PRM = dict(T.DEFAULT)
PRM.update(l1=1.0, Kb=1e10, Kc=1e10, Tb=1e6, Tc=1e6,
           mu_s=5.0, rho_s=1e-7, P=0.0, d11=D11)
Q = T.derived(T.MAT, D11)
BETA = (Q['beta1'], Q['beta2'], Q['beta3'])


# --------------------------------------------------------------------- data
def load(tag):
    return {int(k): np.array(v)
            for k, v in json.load(open(os.path.join(CACHE, 'roots_%s.json' % tag))).items()}


def branch(tag):
    if tag in CONT:
        return [{int(n): (float(v) if v is not None else np.nan)
                 for n, v in b.items()}
                for _, b in sorted(CONT[tag].items(), key=lambda kv: int(kv[0]))]
    return TJ.track_joint(load(tag))


def series(b, d=0.025):
    """(omega/1e6, c_p) arrays for the finite part of one branch."""
    ns = [n for n in sorted(b) if np.isfinite(b[n])]
    return (np.array([b[n] * 1e-6 for n in ns]),
            np.array([b[n] * d / n for n in ns]),
            np.array(ns))


BASE = branch('base')


def spread_of(sets, dlist):
    """Largest vertical gap between the curves, and where it occurs."""
    common = None
    for b, d in zip(sets, dlist):
        w, c, n = series(b, d)
        common = n if common is None else np.intersect1d(common, n)
    cs = []
    for b, d in zip(sets, dlist):
        w, c, n = series(b, d)
        cs.append(np.interp(common, n, c))
    cs = np.array(cs)
    gap = cs.max(axis=0) - cs.min(axis=0)
    return float(gap.max()), float(np.median(cs), ), common


# ============================================================ FIGURE 1
def fig1_geometry():
    fig = plt.figure(figsize=(S.SINGLE_W, S.SINGLE_W * 0.905))
    ax = fig.add_axes([0.0, 0.0, 1.0, 1.0])
    ax.set_aspect('equal')
    a, b, c, d = T.A_R, T.B_R, T.C_R, T.D_R
    th = np.linspace(0, 2 * np.pi, 480)
    # Each ring is a filled disc punched by a white disc.  The z-orders must
    # rise with every layer, otherwise the next disc is painted underneath
    # the previous knockout and the inner rings come out white.
    for k, (r0, r1, col) in enumerate(((c, d, S.LAYER_FILL[2]),
                                       (b, c, S.LAYER_FILL[1]),
                                       (a, b, S.LAYER_FILL[0]))):
        ax.add_patch(plt.Polygon(np.c_[r1 * np.cos(th), r1 * np.sin(th)],
                                 closed=True, fc=col, ec='none',
                                 zorder=1 + 2 * k))
        ax.add_patch(plt.Circle((0, 0), r0, fc='white', ec='none',
                                zorder=2 + 2 * k))
    for r, lw in ((a, 0.9), (b, 1.1), (c, 1.1), (d, 1.5)):
        ax.plot(r * np.cos(th), r * np.sin(th), color=S.INK, lw=lw, zorder=5)
    # spring--membrane symbols at the two internal interfaces
    for r in (b, c):
        for k in range(28):
            t = np.linspace(k * 2 * np.pi / 28, (k + 0.62) * 2 * np.pi / 28, 6)
            rr = r + 0.00085 * np.array([0, 1, 0, -1, 0, 1])
            ax.plot(rr * np.cos(t), rr * np.sin(t), color=S.CB[1],
                    lw=0.7, zorder=6)
    # Gurtin--Murdoch surface: a heavier arc outside r = d
    t = np.linspace(np.deg2rad(-28), np.deg2rad(118), 200)
    ax.plot((d + 0.0016) * np.cos(t), (d + 0.0016) * np.sin(t),
            color=S.CB[2], lw=2.6, zorder=7)
    ax.annotate('Gurtin--Murdoch surface',
                xy=(d * np.cos(np.deg2rad(58)), d * np.sin(np.deg2rad(58))),
                xytext=(0.0 * d, 1.17 * d), fontsize=8, ha='center',
                va='center', color=S.INK,
                arrowprops=dict(arrowstyle='-', lw=0.6, color=S.GREY))
    for r, lab in ((a, '$r=a$'), (b, '$r=b$'), (c, '$r=c$'), (d, '$r=d$')):
        ang = np.deg2rad(208)
        ax.text(r * np.cos(ang) * 1.10, r * np.sin(ang) * 1.10, lab,
                fontsize=8.5, ha='center', va='center', color=S.INK)
    for rm, lab, col in (((a + b) / 2, 'FGO\ngraded, $l_1$', S.CB[0]),
                         ((b + c) / 2, 'MEE', S.CB[1]),
                         ((c + d) / 2, 'PM\nstressed, $P$', S.CB[2])):
        ax.text(rm * np.cos(np.deg2rad(-42)), rm * np.sin(np.deg2rad(-42)),
                lab, fontsize=8.5, ha='center', va='center',
                color=col, fontweight='bold')
    ax.text(0, 0, 'traction-free', fontsize=8, ha='center', va='center',
            color=S.GREY)
    t0 = np.deg2rad(22)
    ax.plot([0, d * np.cos(t0)], [0, d * np.sin(t0)], color=S.LGREY,
            lw=0.8, ls=':', zorder=4)
    ax.text(d * 0.55 * np.cos(np.deg2rad(36)), d * 0.55 * np.sin(np.deg2rad(36)),
            r'$\theta$', fontsize=10, color=S.GREY)
    ax.annotate('spring--membrane interface', xy=(c * np.cos(np.deg2rad(-35)),
                                                   c * np.sin(np.deg2rad(-35))),
                xytext=(0.0 * d, -1.15 * d), fontsize=8, ha='center',
                va='center', color=S.INK,
                arrowprops=dict(arrowstyle='-', lw=0.6, color=S.GREY))
    ax.set_xlim(-1.50 * d, 1.50 * d)
    ax.set_ylim(-1.25 * d, 1.28 * d)
    ax.axis('off')
    S.save(fig, 'Fig01_Geometry')


# ============================================================ FIGURE 2
def fig2_rootcloud():
    fig = plt.figure(figsize=(S.SINGLE_W, S.SINGLE_W * 0.93))
    ax = fig.add_axes(S.rect_mm(fig, 15.0, 17.0, 66.0, 56.0))
    C = load('base')
    for n in range(1, 21):
        cp = C[n] * 0.025 / n
        ax.plot([C[n] * 1e-6] * len(cp), cp, ls='none', marker='o', ms=1.5,
                mfc=S.LGREY, mec=S.LGREY, color=S.LGREY, zorder=1)
    hs, ls_ = [], []
    for i, fam in enumerate(BASE):
        w, cp, n = series(fam)
        col, lst, mk = S.style(i)
        h, = ax.plot(w, cp, color=col, ls=lst, lw=S.LW_MAIN, zorder=3)
        ax.plot(w, cp, ls='none', marker=mk, ms=S.MS, mfc='white',
                mec=col, mew=S.MEW, zorder=4)
        hs.append(h)
        ls_.append(NAMES[i].capitalize())
    for i, (bb, nm) in enumerate(zip(BETA, (r'$\beta_1$', r'$\beta_2$', r'$\beta_3$'))):
        ax.axhline(bb, color=S.GREY, lw=S.LW_REF, ls=[':', '--', '-.'][i], zorder=2)
        ax.text(0.14, bb, nm, fontsize=8.5, color=S.INK, va='bottom',
                ha='left', bbox=dict(fc='white', ec='none', pad=0.4))
    hc, = ax.plot([], [], ls='none', marker='o', ms=3.0, mfc=S.LGREY,
                  mec=S.LGREY)
    hs.append(hc)
    ls_.append('All accepted roots')
    ax.set_yscale('log')
    ax.set_ylim(2.4e3, 2.6e5)
    ax.set_xlim(0, 7.6)
    ax.text(0.985, 0.945, 'higher roots of the same\nfrequency equation (not tracked)',
            transform=ax.transAxes, fontsize=8, color=S.GREY, ha='right',
            va='top', style='italic')
    S.finish(ax, r'$\omega$  ($10^{6}$ rad/s)', r'$c_p$  (m/s)')
    ax.legend(hs, ls_, loc='upper center', bbox_to_anchor=(0.5, -0.34),
              ncol=2, frameon=False, columnspacing=1.1)
    S.save(fig, 'Fig02_RootCloud')


# ============================================================ FIGURE 3
def fig3_dispersion():
    fig = plt.figure(figsize=(S.SINGLE_W, S.SINGLE_W * 0.80))
    ax = fig.add_axes(S.rect_mm(fig, 15.0, 12.0, 66.0, 51.0))
    for i, fam in enumerate(BASE):
        w, cp, n = series(fam)
        col, lst, mk = S.style(i)
        ax.plot(w, cp, color=col, ls=lst, lw=S.LW_MAIN, zorder=3)
        ax.plot(w, cp, ls='none', marker=mk, ms=S.MS, mfc='white', mec=col,
                mew=S.MEW, zorder=4)
        # direct label at the right-hand end of the curve (no legend needed)
        ax.annotate(NAMES[i].capitalize(), xy=(w[-1], cp[-1]),
                    xytext=(0, 7), textcoords='offset points',
                    fontsize=8.5, color=col, ha='center', va='bottom')
    ax.axhline(BETA[2], color=S.GREY, lw=S.LW_REF, ls='--', zorder=2)
    ax.text(0.12, BETA[2] * 1.012, r'$\beta_3$ (PM bulk shear speed)',
            fontsize=8.5, color=S.GREY, va='bottom', ha='left')
    ax.set_xlim(0, 8.2)
    ax.set_ylim(3900, 9500)
    S.finish(ax, r'$\omega$  ($10^{6}$ rad/s)', r'$c_p$  (m/s)')
    ax.set_xticks([0, 2, 4, 6, 8])
    S.save(fig, 'Fig03_DispersionCurves')


# ============================================== FIGURES 4-8 (3-panel grid)
def study_figure(name, tags, dlist, labels, xlabel, legend_title,
                 note=None):
    """2 x 2 grid: (a) (b) / (c) (legend).  One shared legend, never
    over the data; a y-magnified inset wherever the curves are closer
    together than 3 % of the panel range."""
    fig = plt.figure(figsize=(S.FULL_W, S.GRID_H_2ROW))
    sets = [branch(t) for t in tags]
    rects = [S.grid2(fig, 0, 0), S.grid2(fig, 0, 1), S.grid2(fig, 1, 0)]
    handles, labs = [], []
    for mi in range(3):
        ax = fig.add_axes(rects[mi])
        ws, cps = [], []
        for i, (b, d) in enumerate(zip(sets, dlist)):
            w, cp, n = series(b[mi], d)
            col, lst, mk = S.style(i)
            h, = ax.plot(w, cp, color=col, ls=lst, lw=S.LW_MAIN, zorder=3,
                         markevery=max(1, len(w) // 7))
            ax.plot(w, cp, ls='none', marker=mk, ms=S.MS, mfc='white',
                    mec=col, mew=S.MEW, zorder=4, markevery=max(1, len(w) // 7))
            ws.append(w)
            cps.append(cp)
            if mi == 0:
                handles.append(h)
                labs.append(labels[i])
        ymin = min(c.min() for c in cps)
        ymax = max(c.max() for c in cps)
        pad = 0.06 * (ymax - ymin)
        ax.set_xlim(0, max(w.max() for w in ws) * 1.02)
        ax.set_ylim(ymin - pad, ymax + pad)
        # ---- overlap handling: y-magnified inset
        gap, _, _ = spread_of([s[mi] for s in sets], dlist)
        rng = (ymax + pad) - (ymin - pad)
        if 1e-7 < gap < 0.03 * rng:
            lo = min(c.min() for c in cps)
            hi = max(c.max() for c in cps)
            m = 0.18 * (hi - lo)
            iax = S.magnified_inset(
                ax, 0.50, 0.06, 0.46, 0.34,
                (0, max(w.max() for w in ws) * 1.02), (lo - m, hi + m),
                r'$\Delta c_p$ = %.0e m/s' % (hi - lo + 2 * m))
            for i, (b, d) in enumerate(zip(sets, dlist)):
                w, cp, n = series(b[mi], d)
                col, lst, mk = S.style(i)
                iax.plot(w, cp, color=col, ls=lst, lw=1.1, zorder=3)
                iax.plot(w, cp, ls='none', marker=mk, ms=2.6, mfc='white',
                         mec=col, mew=0.6, zorder=4,
                         markevery=max(1, len(w) // 9))
        elif gap <= 1e-7:
            ax.text(0.97, 0.06, 'curves coincide to $<10^{-6}$ m/s',
                    transform=ax.transAxes, fontsize=8, ha='right',
                    va='bottom', color=S.GREY, style='italic')
        S.finish(ax, xlabel, r'$c_p$  (m/s)')
        S.add_panel_label(ax, '(%s)' % 'abc'[mi], title=NAMES[mi])
    S.legend_cell(fig, S.grid2(fig, 1, 1), handles, labs,
                  title=legend_title)
    if note:
        fig.text(0.008, 0.012, note, fontsize=7.5, color=S.GREY, ha='left')
    S.save(fig, name)


# ============================================================ FIGURE 9
def fig9_topology3d():
    from mpl_toolkits.mplot3d import Axes3D            # noqa: F401
    fig = plt.figure(figsize=(S.SINGLE_W * 1.28, S.SINGLE_W * 0.95))
    ax = fig.add_axes(S.rect_mm(fig, 12.0, 12.0, 84.0, 56.0), projection='3d')
    handles = []
    for i, fam in enumerate(BASE):
        w, cp, n = series(fam)
        col, lst, mk = S.style(i)
        h, = ax.plot(n, w, cp, color=col, ls=lst, lw=S.LW_MAIN, zorder=3)
        ax.plot(n, w, cp, ls='none', marker=mk, ms=S.MS, mfc='white',
                mec=col, mew=S.MEW, zorder=4)
        handles.append(h)
    ax.set_xlabel('$n$', labelpad=0)
    ax.set_ylabel(r'$\omega\;(10^{6}\,\mathrm{rad/s})$', labelpad=0)
    ax.set_zlabel(r'$c_p$  (m/s)', labelpad=0)
    ax.tick_params(labelsize=7.5, pad=-1.5)
    ax.set_box_aspect((1.55, 1.0, 0.62))
    # integer wavenumber axis: no spurious decimals, no ticks beyond n = 20
    ax.set_xticks([0, 5, 10, 15, 20])
    ax.set_yticks([0, 2, 4, 6, 8])
    ax.set_zticks([4000, 6000, 8000, 10000])
    ax.view_init(elev=20, azim=-56)
    ax.xaxis.pane.fill = ax.yaxis.pane.fill = ax.zaxis.pane.fill = False
    for p in (ax.xaxis, ax.yaxis, ax.zaxis):
        p.pane.set_edgecolor('0.85')
        p.pane.set_linewidth(0.5)
    ax.grid(color='0.85', lw=0.4)
    ax.legend(handles, [n.capitalize() for n in NAMES], loc='upper center',
              bbox_to_anchor=(0.5, 1.03), ncol=3, frameon=False,
              columnspacing=1.0)
    S.save(fig, 'Fig09_DispersionTopology3D')


# ============================================================ FIGURE 10
def fig10_surface():
    fig = plt.figure(figsize=(S.FULL_W, S.GRID_H_1ROW))
    tags = ['mus_0e+00', 'base', 'mus_1e+08', 'mus_1e+09', 'mus_5e+09']
    labs = [r'$\mu_s=0$', r'$5$', r'$10^{8}$', r'$10^{9}$',
            r'$5\times10^{9}$']
    sets = [branch(t) for t in tags]
    # (a) second higher mode - the only one that reaches the outer surface
    ax = fig.add_axes(S.grid1(fig, 0))
    hs = []
    for i, b in enumerate(sets):
        w, cp, n = series(b[2])
        col, lst, mk = S.style(i)
        h, = ax.plot(w, cp, color=col, ls=lst, lw=S.LW_MAIN, zorder=3,
                     markevery=max(1, len(w) // 7))
        ax.plot(w, cp, ls='none', marker=mk, ms=S.MS, mfc='white', mec=col,
                mew=S.MEW, zorder=4, markevery=max(1, len(w) // 7))
        hs.append(h)
    ax.set_xlim(0, 8.2)
    ax.set_ylim(8600, 14700)
    S.finish(ax, r'$\omega$  ($10^{6}$ rad/s)', r'$c_p$  (m/s)')
    S.add_panel_label(ax, '(a)', title='second higher mode')
    ax.annotate(r'$\mu_s=0$ and $5$ N/m coincide',
                xy=(2.0, 8880), xytext=(0.30, 0.30),
                textcoords='axes fraction', fontsize=8, color=S.GREY,
                ha='left', va='bottom',
                arrowprops=dict(arrowstyle='-', lw=0.6, color=S.LGREY))
    S.legend_cell(fig, S.legend_row(fig), hs, labs, ncol=5,
                   title=r'surface shear modulus $\mu_s$ (N/m)')
    # (b) departure from the classical surface
    ax = fig.add_axes(S.grid1(fig, 1))
    ms = np.array([5.0, 1e6, 1e8, 1e9, 5e9])
    f0 = branch('mus_0e+00')[2]
    dev = []
    for t in ['base', 'mus_1e+06', 'mus_1e+08', 'mus_1e+09', 'mus_5e+09']:
        f2 = branch(t)[2]
        dev.append(max(abs(f2[n] / f0[n] - 1) for n in range(1, 21)
                       if np.isfinite(f2[n]) and np.isfinite(f0[n])))
    dev = np.array(dev)
    ax.loglog(ms, dev, color=S.CB[1], ls='-', lw=S.LW_MAIN, marker='o',
              ms=S.MS, mfc='white', mec=S.CB[1], mew=S.MEW, zorder=3)
    ax.axhline(1e-2, color=S.GREY, lw=S.LW_REF, ls='--', zorder=2)
    ax.text(6.0, 1.35e-2, r'$1\,\%$', fontsize=8.5, color=S.GREY)
    ax.axvline(4e7, color=S.LGREY, lw=0.9, ls=':', zorder=1)
    ax.text(5.2e7, 3e-9, r'$\mu_s\simeq4\times10^{7}$ N/m', fontsize=8,
            color=S.GREY, rotation=90, va='bottom', ha='left')
    ax.set_xlim(2.0, 2.0e10)
    ax.set_ylim(1e-10, 1.0)
    S.finish(ax, r'$\mu_s$  (N/m)',
             r'max $|\Delta\omega/\omega|$ over $1\leq n\leq20$')
    S.add_panel_label(ax, '(b)', title='departure from the classical surface')
    S.save(fig, 'Fig10_SurfaceElasticity')
    print('   surface deviations:', ['%.3e' % v for v in dev])


# ============================================================ FIGURE 11
def fig11_magnetoelectric():
    fig = plt.figure(figsize=(S.FULL_W, S.GRID_H_1ROW))
    tags = ['d11_0', 'base', 'd11_1e-07', 'd11_2.674e-07',
            'd11_4.87e-07', 'd11_1e-06']
    d11s = [0.0, 3.01329e-08, 1.0e-07, 2.6741e-07, 4.87322e-07, 1.0e-06]
    labs = ['0', r'$3.01\times10^{-8}$', r'$1.0\times10^{-7}$',
            r'$2.674\times10^{-7}$', r'$4.87\times10^{-7}$',
            r'$1.0\times10^{-6}$']
    sets = [branch(t) for t in tags]
    hs = []
    for k, (mi, tit) in enumerate(((0, 'fundamental mode'),
                                   (2, 'second higher mode'))):
        ax = fig.add_axes(S.grid1(fig, k))
        for i, b in enumerate(sets):
            w, cp, n = series(b[mi])
            col, lst, mk = S.style(i)
            h, = ax.plot(w, cp, color=col, ls=lst, lw=S.LW_MAIN, zorder=3,
                         markevery=max(1, len(w) // 8))
            ax.plot(w, cp, ls='none', marker=mk, ms=S.MS, mfc='white',
                    mec=col, mew=S.MEW, zorder=4,
                    markevery=max(1, len(w) // 8))
            if k == 0:
                hs.append(h)
        ax.set_xlim(0, 7.45)
        if mi == 0:
            ax.set_ylim(4130, 4560)
            # the scientifically important minimum, magnified
            c1 = np.array([series(b[0])[1][0] for b in sets])
            iax = S.magnified_inset(
                ax, 0.52, 0.08, 0.44, 0.40, (-0.06e-6, 1.04e-6),
                (c1.min() - 3.0, c1.max() + 3.0),
                r'minimum at $d_{11}^\ast$')
            iax.plot(d11s, c1, color=S.CB[0], ls='-', lw=1.1)
            iax.plot(d11s, c1, ls='none', marker='o', ms=3.0, mfc='white',
                     mec=S.CB[0], mew=0.7)
            iax.axvline(2.6741e-7, color=S.GREY, lw=0.7, ls=':')
            iax.set_xticks([0, 5e-7, 1e-6])
            iax.tick_params(labelsize=6.2, pad=1.0)
            iax.set_xlabel(r'$d_{11}$ (s/m)', fontsize=6.5, labelpad=0.5)
        else:
            ax.set_ylim(8800, 8920)
            ax.text(0.97, 0.06, r'spread $<0.9$ m/s ($0.01\,\%$)',
                    transform=ax.transAxes, fontsize=8, ha='right',
                    va='bottom', color=S.GREY, style='italic')
        S.finish(ax, r'$\omega$  ($10^{6}$ rad/s)', r'$c_p$  (m/s)')
        S.add_panel_label(ax, '(%s)' % 'ab'[k], title=tit)
    S.legend_cell(fig, S.legend_row(fig), hs, labs, ncol=6,
                   title=r'magnetoelectric coefficient $d_{11}$ (s/m)')
    S.save(fig, 'Fig11_Magnetoelectric')


# ============================================================ FIGURE 12
def _shape(seed, n=1):
    """Radial mode shape from the null vector of the equilibrated matrix."""
    pp = dict(PRM)
    qq = Q
    w = BASE[seed][n]
    M = T.assemble(w, n, pp)
    Me, dr, dc = T.equilibrate(M)
    U, s, Vt = np.linalg.svd(Me)
    X = Vt[-1] / dc
    X = X / np.max(np.abs(X))
    k1 = w / qq['beta1']
    k2 = w / qq['beta2']
    k3 = w / qq['beta3']
    nu1 = np.sqrt(qq['cbar'] ** 2 * n * n + pp['l1'] ** 2 / 4.)
    eta = np.sqrt(n * n * (1.0 + pp['P'] / qq['cbar3']))
    r1 = np.linspace(T.A_R, T.B_R, 500)
    r2 = np.linspace(T.B_R, T.C_R, 500)
    r3 = np.linspace(T.C_R, T.D_R, 500)
    u1 = r1 ** (-pp['l1'] / 2) * (X[0] * jv(nu1, k1 * r1) + X[1] * yv(nu1, k1 * r1))
    u2 = X[2] * jv(n, k2 * r2) + X[3] * yv(n, k2 * r2)
    u3 = X[8] * jv(eta, k3 * r3) + X[9] * yv(eta, k3 * r3)
    r = np.concatenate([r1, r2, r3])
    u = np.concatenate([u1, u2, u3])
    return r, np.abs(u) / np.max(np.abs(u))


def fig12_modeshapes():
    fig = plt.figure(figsize=(S.FULL_W, S.GRID_H_2ROW))
    rects = [S.grid2(fig, 0, 0), S.grid2(fig, 0, 1), S.grid2(fig, 1, 0)]
    for mi in range(3):
        ax = fig.add_axes(rects[mi])
        for j, (r0, r1) in enumerate(((T.A_R, T.B_R), (T.B_R, T.C_R),
                                      (T.C_R, T.D_R))):
            ax.axvspan(r0 * 1e3, r1 * 1e3, color=S.LAYER_FILL[j], zorder=0)
        r, a = _shape(mi)
        col, lst, mk = S.style(mi)
        ax.semilogy(r * 1e3, np.maximum(a, 1e-14), color=col, ls=lst,
                    lw=S.LW_MAIN, zorder=3)
        for rr in (T.A_R, T.B_R, T.C_R, T.D_R):
            ax.axvline(rr * 1e3, color=S.GREY, lw=0.6, ls=':', zorder=2)
        for rm, lab in (((T.A_R + T.B_R) / 2, 'FGO'),
                        ((T.B_R + T.C_R) / 2, 'MEE'),
                        ((T.C_R + T.D_R) / 2, 'PM')):
            ax.text(rm * 1e3, 3.0, lab, ha='center', va='bottom',
                    fontsize=7.5, color=S.GREY)
        S.finish(ax, '$r$  (mm)', r'$|u_z|/|u_z|_{\max}$', logy=True)
        ax.set_xlim(9.4, 25.8)
        ax.set_ylim(2e-6, 5.0)
        ax.set_xticks([10, 14, 18, 22])
        S.add_panel_label(ax, '(%s)' % 'abc'[mi], title=NAMES[mi])
    # fourth cell: layer key
    ax = fig.add_axes(S.grid2(fig, 1, 1))
    ax.axis('off')
    hs = [plt.Rectangle((0, 0), 1, 1, fc=S.LAYER_FILL[j], ec=S.GREY, lw=0.6)
          for j in range(3)]
    ax.legend(hs, ['FGO layer  $a<r<b$', 'MEE layer  $b<r<c$',
                   'PM layer  $c<r<d$'], loc='center', frameon=False,
              fontsize=8.5, handlelength=1.6)
    ax.text(0.5, 0.16, 'Dotted verticals: $r=a,\\,b,\\,c,\\,d$\n'
            '$n=1$, default parameters\n'
            'steps: spring--membrane interfaces',
            transform=ax.transAxes, ha='center', va='bottom', fontsize=8,
            color=S.GREY)
    S.save(fig, 'Fig12_ModeShapes')


if __name__ == '__main__':
    print('Fig01'); fig1_geometry()
    print('Fig02'); fig2_rootcloud()
    print('Fig03'); fig3_dispersion()
    print('Fig04'); study_figure(
        'Fig04_InitialStress',
        ['base', 'P_1.18e+11', 'P_2.36e+11'], [0.025] * 3,
        [r'$P=0$', r'$P=1.18\times10^{11}$ Pa', r'$P=2.36\times10^{11}$ Pa'],
        r'$\omega$  ($10^{6}$ rad/s)', 'Initial circumferential stress $P$')
    print('Fig05'); study_figure(
        'Fig05_OuterRadius',
        ['base', 'd_0.030', 'd_0.035'], [0.025, 0.030, 0.035],
        ['$d=0.025$ m', '$d=0.030$ m', '$d=0.035$ m'],
        r'$\omega$  ($10^{6}$ rad/s)', 'Outer radius $d$')
    print('Fig06'); study_figure(
        'Fig06_InterfaceKb',
        ['Kb_1e+06', 'Kb_1e+09', 'Kb_1e+12'], [0.025] * 3,
        [r'$K_b=10^{6}$', r'$10^{9}$', r'$10^{12}$ N/m$^3$'],
        r'$\omega$  ($10^{6}$ rad/s)', 'Interfacial stiffness $K_b$')
    print('Fig07'); study_figure(
        'Fig07_InterfaceKc',
        ['Kc_1e+06', 'Kc_1e+09', 'Kc_1e+12'], [0.025] * 3,
        [r'$K_c=10^{6}$', r'$10^{9}$', r'$10^{12}$ N/m$^3$'],
        r'$\omega$  ($10^{6}$ rad/s)', 'Interfacial stiffness $K_c$')
    print('Fig08'); study_figure(
        'Fig08_GradingIndex',
        ['l1_0.0', 'l1_0.5', 'base'], [0.025] * 3,
        ['$l_1=0$', '$l_1=0.5$', '$l_1=1$'],
        r'$\omega$  ($10^{6}$ rad/s)', 'Grading index $l_1$')
    print('Fig09'); fig9_topology3d()
    print('Fig10'); fig10_surface()
    print('Fig11'); fig11_magnetoelectric()
    print('Fig12'); fig12_modeshapes()
    print('ALL FIGURES REGENERATED')
