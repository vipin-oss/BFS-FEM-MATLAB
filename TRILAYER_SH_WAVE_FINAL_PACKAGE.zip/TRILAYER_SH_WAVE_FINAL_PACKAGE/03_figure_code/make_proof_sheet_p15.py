# -*- coding: utf-8 -*-
"""Phase 15 - human visual-QA proof sheet (brief section 22, items 2, 3, 12, 13).

One A4 page per figure.  On each page:
  * the EPS rendered at its NATURAL size (the size the manuscript inserts it)
  * the same file reduced to an 85 mm column, for legibility checking
  * a greyscale strip, to check that the figure survives greyscale printing

Also prints a numeric greyscale/distinguishability report.
Run:  python3 make_proof_sheet_p15.py
"""
import os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import image as mpimg

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, '..', '09_OUTPUTS', 'regenerated_figures')
OUT = os.path.join(HERE, '..', '09_OUTPUTS', 'Figure_Proof_Sheet_Phase15.pdf')
DPI = 300
COL_MM = 85.0

# name, natural width mm, natural height mm, width inserted in the manuscript
FIG = [
    ('Fig01_Geometry',              84,  76, 0.50),
    ('Fig02_RootCloud',             84,  78, 0.50),
    ('Fig03_DispersionCurves',      84,  67, 0.50),
    ('Fig04_InitialStress',        170, 146, 1.00),
    ('Fig05_OuterRadius',          170, 146, 1.00),
    ('Fig06_InterfaceKb',          170, 146, 1.00),
    ('Fig07_InterfaceKc',          170, 146, 1.00),
    ('Fig08_GradingIndex',         170, 146, 1.00),
    ('Fig09_DispersionTopology3D', 107,  80, 0.63),
    ('Fig10_SurfaceElasticity',    170,  89, 1.00),
    ('Fig11_Magnetoelectric',      170,  89, 1.00),
    ('Fig12_ModeShapes',           170, 146, 1.00),
]
TEXT = 170.0     # manuscript \textwidth in mm


def grey(a):
    return 0.2126 * a[..., 0] + 0.7152 * a[..., 1] + 0.0722 * a[..., 2]


def main():
    from matplotlib.backends.backend_pdf import PdfPages
    rep = []
    with PdfPages(os.path.abspath(OUT)) as pdf:
        for i, (name, wmm, hmm, frac) in enumerate(FIG, start=1):
            a = mpimg.imread(os.path.join(SRC, name + '.png'))[..., :3]
            ins = frac * TEXT
            scale = a.shape[1] / (wmm / 25.4 * DPI)        # px per mm / expected
            col_mm = COL_MM                                 # column copy
            col_h = hmm * col_mm / wmm

            fig = plt.figure(figsize=(210 / 25.4, 297 / 25.4), dpi=150)
            fig.patch.set_facecolor('white')
            y = 297 - 14
            fig.text(12 / 25.4 / (210 / 25.4), y / 297,
                     'Figure %d  —  %s' % (i, name),
                     fontsize=11, fontweight='bold', va='top')
            fig.text(12 / 25.4 / (210 / 25.4), (y - 5) / 297,
                     'natural size %.0f × %.0f mm   |   inserted at %.2f\\textwidth '
                     '= %.0f mm   |   reduction %.0f %%'
                     % (wmm, hmm, frac, ins, 100 * ins / wmm),
                     fontsize=8.5, va='top', color='#333333')

            # (1) natural size
            y0 = y - 12
            ax1 = fig.add_axes([12 / 210, (297 - y0 - hmm) / 297,
                                wmm / 210, hmm / 297])
            ax1.imshow(a, extent=(0, wmm, 0, hmm))
            ax1.set_xlim(0, wmm); ax1.set_ylim(0, hmm); ax1.axis('off')
            ax1.set_title('at 100 % (natural size)', fontsize=8, pad=3,
                          loc='left')

            # (2) column size
            y1 = y0 + hmm + 9
            ax2 = fig.add_axes([12 / 210, (297 - y1 - col_h) / 297,
                                col_mm / 210, col_h / 297])
            ax2.imshow(a, extent=(0, col_mm, 0, col_h))
            ax2.set_xlim(0, col_mm); ax2.set_ylim(0, col_h); ax2.axis('off')
            ax2.set_title('reduced to an 85 mm column (%.0f %%) — legibility check'
                          % (100 * col_mm / wmm), fontsize=8, pad=3, loc='left')

            # (3) greyscale strip at column size
            x3 = 12 + col_mm + 12
            ax3 = fig.add_axes([x3 / 210, (297 - y1 - col_h) / 297,
                                col_mm / 210, col_h / 297])
            g = grey(a)
            ax3.imshow(g, cmap='gray', vmin=0, vmax=1,
                       extent=(0, col_mm, 0, col_h))
            ax3.set_xlim(0, col_mm); ax3.set_ylim(0, col_h); ax3.axis('off')
            ax3.set_title('greyscale, 85 mm column', fontsize=8, pad=3,
                          loc='left')

            # numeric checks
            ink = a.min(axis=2) < 0.97
            gin = g < 0.90
            rep.append((name, 100.0 * gin.mean(), 100.0 * ink.mean(),
                        round(float(scale), 3)))
            pdf.savefig(fig)
            plt.close(fig)

    print('%-30s %-16s %-14s %s' % ('figure', 'greyscale ink %', 'colour ink %',
                                    'px ratio (1.0 = exact)'))
    for r in rep:
        print('%-30s %-16.1f %-14.1f %s' % r)
    print('\nwrote', os.path.abspath(OUT))
    return rep


if __name__ == '__main__':
    main()
