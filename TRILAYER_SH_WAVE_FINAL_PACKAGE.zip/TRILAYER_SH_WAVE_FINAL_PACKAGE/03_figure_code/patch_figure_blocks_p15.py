# -*- coding: utf-8 -*-
"""Phase 15 - replace the twelve figure environments by the redesigned
single-file versions and rewrite every caption.

Idempotent: a file that already carries the new filenames is left alone.
Run as:  python3 patch_figure_blocks_p15.py <texfile> [...]
"""
import sys

def block(fname, width, cap, lab):
    return ("\\begin{figure}[htbp]\n\\centering\n"
            "\\includegraphics[width=%s\\textwidth]{%s}\n"
            "\\caption{%s}\n\\label{%s}\n\\end{figure}" % (width, fname, cap, lab))


NEW = {}

NEW['Geo.eps'] = block('Fig01_Geometry.eps', '0.50', r"""
Cross-section of the hollow cylinder and the notation used throughout.  The
radii $a=10$, $b=15$, $c=20$ and $d=25$~mm bound, from the inside outwards,
the functionally graded orthotropic (FGO), magneto-electro-elastic (MEE) and
piezomagnetic (PM) layers; in the FGO layer the two stiffnesses and the
density vary as $(r/b)^{l_1}$ with the grading index $l_1$.  The bore $r=a$
is traction-free, Eq.~\eqref{eq:BC1}; the two internal surfaces carry the
spring--membrane conditions Eqs.~\eqref{eq:BC2}--\eqref{eq:BC7}, across
which the displacement is discontinuous; the outer surface $r=d$ carries the
Gurtin--Murdoch surface stress and surface inertia, Eq.~\eqref{eq:BC11}.
$\theta$ is the circumferential coordinate and the integer $n$ counts whole
wavelengths around the circumference.""".strip(), 'fig:geometry')

NEW['Fig01_RootCloud_PhysicalBranches.eps'] = block('Fig02_RootCloud.eps', '0.50', r"""
Roots of the dispersion relation $\det\mathbf{M}(\omega,n)=0$,
Eq.~\eqref{eq:dispersion}, at the default parameter set for
$1\leq n\leq20$.  Each root is plotted as a phase velocity
$c_p=\omega d/n$ against the angular frequency $\omega$; the ordinate is
logarithmic because the roots span two decades.  Small grey dots: every root
returned by the solver, $230$ in all, the great majority of which belong to
higher branches of the same frequency equation and are not followed in this
work.  The three branches retained here are drawn over the cloud and are
labelled directly: blue solid line with circles, fundamental; orange dashed
line with squares, first higher; green dash-dotted line with triangles,
second higher.  The three horizontal reference lines are the bulk shear
speeds $\beta_1=2735.4$, $\beta_2=3010.9$ and $\beta_3=8042.9$~m/s of the
FGO, MEE and PM layers; $\beta_2$ is quoted at
$d_{11}=3.013\times10^{-8}$~s/m.""".strip(), 'fig:rootcloud')

NEW['Fig02_DispersionCurves_ThreeModes.eps'] = block('Fig03_DispersionCurves.eps', '0.50', r"""
Dispersion curves of the three retained branches at the default parameter
set: phase velocity $c_p=\omega d/n$ against angular frequency $\omega$ for
circumferential wavenumbers $1\leq n\leq20$.  Every $n$ carries a marker and
each branch is labelled directly at its right-hand end, so no legend is
needed: blue solid line with circles, fundamental; orange dashed line with
squares, first higher; green dash-dotted line with triangles, second higher.
The horizontal dash-dotted line is the bulk shear speed
$\beta_3=8042.9$~m/s of the piezomagnetic layer; the bulk shear speeds of
the other two layers lie below the plotted range.""".strip(), 'fig:dispersion')

NEW['Fig03a_initial_stress.eps'] = block('Fig04_InitialStress.eps', '1.00', r"""
Initial circumferential stress $P$ acting in the piezomagnetic layer.  Panels:
(a) fundamental, (b) first higher, (c) second higher mode; the fourth cell
carries the legend and the values of $P$.  In every panel the phase velocity
$c_p=\omega d/n$ is plotted against the angular frequency $\omega$ for
$1\leq n\leq20$, with every other parameter held at its default value.  The
three curves of a panel are separated only by the value of $P$ and are
distinguished by line style, marker and colour, as in the legend; they share
one axis and are not offset vertically.  In (a) and (b) the curves lie within
$0.01$~m/s of one another, well below the resolution of the axis, so each of
those panels carries a magnified inset drawn with its own ticks and its own
ordinate range; the inset repeats the three line styles and its label gives
the full-scale interval $\Delta c_p$ that it spans.  In (c) the curves differ
by up to $1.6\times10^{3}$~m/s and no magnification is needed.""".strip(), 'fig:initialstress')

NEW['Fig04a_radius.eps'] = block('Fig05_OuterRadius.eps', '1.00', r"""
Outer radius $d$.  Panels: (a) fundamental, (b) first higher, (c) second
higher mode; the fourth cell carries the legend and the values of $d$.  Phase
velocity $c_p=\omega d/n$ against angular frequency $\omega$ for
$1\leq n\leq20$; the inner radii $a$, $b$ and $c$ are held fixed, so changing
$d$ alters the thickness of the piezomagnetic layer alone.  Because the
ordinate is scaled by $d$, the curves separate even where the frequencies do
not.  No magnification is used: in every panel the three curves differ by
more than $1.3\times10^{3}$~m/s.  Line style, marker and colour identify $d$
as in the legend.""".strip(), 'fig:radius')

NEW['Fig05_kb.eps'] = block('Fig06_InterfaceKb.eps', '1.00', r"""
Spring stiffness $K_b$ of the FGO--MEE interface at $r=b$.  Panels:
(a) fundamental, (b) first higher, (c) second higher mode; the fourth cell
carries the legend and the values of $K_b$.  Phase velocity
$c_p=\omega d/n$ against angular frequency $\omega$ for $1\leq n\leq20$,
every other parameter at its default value.  In (c) the three curves lie
within $0.05$~m/s of one another and that panel carries a magnified inset
with its own ticks; the label of the inset gives the full-scale interval
$\Delta c_p$ it spans.  In (a) and (b) the curves are separated by several
hundred m/s and are drawn directly.  Line style, marker and colour identify
$K_b$ as in the legend.""".strip(), 'fig:kb')

NEW['fig06a_kc.eps'] = block('Fig07_InterfaceKc.eps', '1.00', r"""
Spring stiffness $K_c$ of the MEE--PM interface at $r=c$.  Panels:
(a) fundamental, (b) first higher, (c) second higher mode; the fourth cell
carries the legend and the values of $K_c$.  Phase velocity
$c_p=\omega d/n$ against angular frequency $\omega$ for $1\leq n\leq20$,
every other parameter at its default value.  The three curves of every panel
differ by more than $700$~m/s, so no magnification is used and no inset is
drawn.  Line style, marker and colour identify $K_c$ as in the legend.""".strip(), 'fig:kc')

NEW['fig07a_fg.eps'] = block('Fig08_GradingIndex.eps', '1.00', r"""
Grading index $l_1$ of the functionally graded orthotropic layer.  Panels:
(a) fundamental, (b) first higher, (c) second higher mode; the fourth cell
carries the legend and the values of $l_1$.  Phase velocity
$c_p=\omega d/n$ against angular frequency $\omega$ for $1\leq n\leq20$,
every other parameter at its default value.  In (a) and (c) the three curves
lie within $0.05$~m/s of one another, so each of those panels carries a
magnified inset with its own ticks and its own ordinate range; the label of
each inset gives the full-scale interval $\Delta c_p$ it spans.  In (b) the
curves differ by up to $74$~m/s and are drawn directly.  Line style, marker
and colour identify $l_1$ as in the legend.""".strip(), 'fig:fg')

NEW['three_d.eps'] = block('Fig09_DispersionTopology3D.eps', '0.63', r"""
The three dispersion branches of Fig.~\ref{fig:dispersion} drawn as space
curves in the coordinates (circumferential wavenumber $n$, angular frequency
$\omega$, phase velocity $c_p=\omega d/n$).  The viewing direction is chosen
so that no locus hides another.  Blue solid line with circles, fundamental;
orange dashed line with squares, first higher; green dash-dotted line with
triangles, second higher; the legend sits above the axes, outside the data
region.  Projecting each locus onto the $(\omega,c_p)$ plane recovers
Fig.~\ref{fig:dispersion}.""".strip(), 'fig:3d')

NEW['Fig08_surface_elasticity.eps'] = block('Fig10_SurfaceElasticity.eps', '1.00', r"""
Gurtin--Murdoch surface elasticity of the outer surface $r=d$.
(a) Phase velocity $c_p=\omega d/n$ of the second higher mode against
angular frequency $\omega$ for $1\leq n\leq20$ at five values of the surface
shear modulus $\mu_s$; the curves for $\mu_s=0$ and $5$~N/m coincide to
within $10^{-3}$~m/s and are noted as such rather than displaced.  Colour,
line style and marker identify $\mu_s$ as in the legend below the panels.
(b) The same comparison expressed as a departure: the largest relative change
of the roots of that mode over $1\leq n\leq20$, taken against the classical
surface $\mu_s=0$, against $\mu_s$ on logarithmic axes.  The dashed
horizontal marks a departure of one per cent and the dotted vertical the
value $\mu_s\simeq4\times10^{7}$~N/m at which it is first reached.  The
ordinate of (b) is $\max_n|\Delta\omega/\omega|$, not a phase
velocity.""".strip(), 'fig:surf')

NEW['Fig09_magnetoelectric.eps'] = block('Fig11_Magnetoelectric.eps', '1.00', r"""
Magnetoelectric coefficient $d_{11}$ of the MEE layer.  (a) Fundamental mode,
(b) second higher mode: phase velocity $c_p=\omega d/n$ against angular
frequency $\omega$ for $1\leq n\leq20$ at six values of $d_{11}$, every other
parameter at its default value; the legend below the panels gives the values
together with the colour, line style and marker of each curve.  In (a) the
inset plots the phase velocity at $n=1$ directly against $d_{11}$ and shows
the dependence to be non-monotone: the velocity falls to a minimum at
$d_{11}^{\ast}=2.674\times10^{-7}$~s/m, marked by the dotted vertical, and
rises again.  In (b) the six curves span less than $0.9$~m/s, which is
$0.01$\,\% of the value; they are drawn on one axis without vertical offset
and the spread is stated on the panel.""".strip(), 'fig:d11')

NEW['Fig10_mode_shapes.eps'] = block('Fig12_ModeShapes.eps', '1.00', r"""
Radial mode shapes at $n=1$ and the default parameter set: normalised
displacement magnitude $|u_z|/|u_z|_{\max}$ against radius, on a logarithmic
ordinate.  Panels: (a) fundamental, (b) first higher, (c) second higher mode;
the fourth cell carries the layer key.  The shaded bands are, from the inside
outwards, the functionally graded orthotropic (FGO), magneto-electro-elastic
(MEE) and piezomagnetic (PM) layers, and the dotted verticals mark
$r=a$, $b$, $c$ and $d$.  The steps at $r=b$ and $r=c$ are the displacement
jumps demanded by the spring--membrane conditions
Eqs.~\eqref{eq:BC2}--\eqref{eq:BC7}; they are part of the solution and not an
artefact of the plot.  Each panel carries the same ordinate range so that the
three modes can be compared directly.""".strip(), 'fig:modes')


def patch(path):
    s = open(path).read()
    if '{Fig01_Geometry.eps}' in s:
        print('  %s already patched - skipped' % path)
        return
    for old, new in NEW.items():
        i = s.find('{' + old + '}')
        assert i > 0, (path, old)
        start = s.rfind('\\begin{figure}', 0, i)
        end = s.find('\\end{figure}', i) + len('\\end{figure}')
        assert start > 0 and end > start, (path, old)
        oldblock = s[start:end]
        assert '\\caption' in oldblock, (path, old)
        s = s[:start] + new + s[end:]
        print('  %-40s %5d -> %5d chars' % (old, len(oldblock), len(new)))
    open(path, 'w').write(s)
    print('  wrote %s (%d bytes)' % (path, len(s)))


if __name__ == '__main__':
    for p in sys.argv[1:]:
        print(p)
        patch(p)
