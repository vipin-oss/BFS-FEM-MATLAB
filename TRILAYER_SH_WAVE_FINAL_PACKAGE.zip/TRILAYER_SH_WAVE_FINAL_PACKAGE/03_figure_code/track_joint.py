# -*- coding: utf-8 -*-
"""Phase 08 - joint one-to-one branch tracking.

Why this exists
---------------
Two trackers already in the project both fail on the same input:

  make_all_figures.track(C, seed)   nearest-neighbour continuation in n, tol=0.12.
      Fails when a branch moves more than 12 % between consecutive n
      (K_c = 1e12, first higher mode: -12.3 % from n=1 to n=2 -> 1 of 20 points).

  fix_figures.track_to(C, basefam, tol=0.35)
      Matches each family independently to the base branch, so two families can
      take the SAME root. At K_b = 1e12 it gave the fundamental and the first
      higher mode both 4725.84 m/s instead of 4725.84 and 8553.92 m/s.

What it does
------------
Seeds family k at the k-th lowest root at n = 1 (verified correct for every
cached set), then at each subsequent n solves a 3 x m linear-sum assignment
between the three expected frequencies and the roots actually found, minimising
the total |log(omega/omega_expected)|. The assignment is one-to-one by
construction, so branches cannot merge, and it follows a branch across a large
step as long as no other branch is closer to it.
"""
import numpy as np
from scipy.optimize import linear_sum_assignment

def track_joint(C, nf=3, tol=0.30, nmax=20):
    r1 = np.sort(np.asarray(C.get(1, []), dtype=float))
    r1 = r1[np.isfinite(r1)]
    if len(r1) < nf:
        raise ValueError('only %d roots at n=1' % len(r1))
    prev = [r1[k] for k in range(nf)]
    lastn = [1] * nf
    out = [{1: prev[k]} for k in range(nf)]
    for n in range(2, nmax + 1):
        rs = np.sort(np.asarray(C.get(n, []), dtype=float))
        rs = rs[np.isfinite(rs)]
        if not len(rs):
            for k in range(nf):
                out[k][n] = np.nan
            continue
        exp = np.array([prev[k] * n / lastn[k] for k in range(nf)])
        BIG = 1e6
        cost = np.full((nf, len(rs)), BIG)
        for k in range(nf):
            if np.isfinite(exp[k]) and exp[k] > 0:
                cost[k] = np.abs(np.log(rs / exp[k]))
        ri, ci = linear_sum_assignment(cost)
        taken = {}
        for k, j in zip(ri, ci):
            if cost[k, j] < np.log(1.0 + tol):
                taken[k] = rs[j]
        for k in range(nf):
            if k in taken:
                out[k][n] = taken[k]; prev[k] = taken[k]; lastn[k] = n
            else:
                out[k][n] = np.nan
    return out

def stats(branches, d=0.025):
    s = []
    for b in branches:
        ns = [n for n in sorted(b) if np.isfinite(b[n])]
        if len(ns) < 2:
            s.append((len(ns), float('nan'), b.get(1, np.nan) * d)); continue
        cp = np.array([b[n] * d / n for n in ns])
        s.append((len(ns), float(np.max(np.abs(np.diff(cp)) / cp[:-1]) * 100.0), cp[0]))
    return s
