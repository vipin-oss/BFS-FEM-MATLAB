"""
trilayer_sh.py
Independent re-implementation of the tri-layer cylindrical SH-wave dispersion
model of the manuscript, built directly from Appendix A (rows 1-12) and the
boundary conditions BC1-BC12.  Nothing here is taken from the authors' code
(no code was supplied with the source archive).

Geometry : a=0.010  b=0.015  c=0.020  d=0.025  m
Unknowns : X = [A1,B1, A2,B2, A3,B3, A4,B4, A5,B5, A6,B6]
           layer 1 FGO (Bessel order nu1), layer 2 MEE (order n),
           layer 3 PM  (order eta)
"""
import numpy as np
from scipy.special import jv, yv, jvp, yvp

A_R, B_R, C_R, D_R = 0.010, 0.015, 0.020, 0.025

# ---- material table (Table 3 of the manuscript) ----------------------------
MAT = dict(c44F=4.25e10, c55F=4.25e10, rhoF=5680.0,
           c44_2=4.415e10, rho2=5550.0,
           e15=5.8, q15=275.0, eps11=5.64e-9, mu11=2.975e-4,
           c44_3=5.90e11, rho3=9230.0, h15=167.66, mu3=3.976e-6)

# ---- parameters the manuscript does NOT fix -------------------------------
#   d11 : magnetoelectric coefficient - ABSENT from Table 3 (AD-02)
#   P   : default initial stress - not stated in the manuscript
DEFAULT = dict(l1=0.5, Kb=1e10, Kc=1e10, Tb=1e6, Tc=1e6,
               mu_s=5.0, rho_s=1e-7, P=1.18e11, d11=0.0)


def derived(m=MAT, d11=0.0):
    D = m['eps11'] * m['mu11'] - d11 ** 2
    alpha = (m['e15'] * m['mu11'] - m['q15'] * d11) / D
    beta = (m['q15'] * m['eps11'] - m['e15'] * d11) / D
    cbar2 = m['c44_2'] + (m['e15'] ** 2 * m['mu11'] + m['q15'] ** 2 * m['eps11']
                          - 2.0 * m['e15'] * m['q15'] * d11) / D
    cbar3 = m['c44_3'] + m['h15'] ** 2 / m['mu3']
    beta1 = np.sqrt(m['c44F'] / m['rhoF'])
    cbar = np.sqrt(m['c55F'] / m['c44F'])
    beta2 = np.sqrt(cbar2 / m['rho2'])
    beta3 = np.sqrt(cbar3 / m['rho3'])
    return dict(Delta=D, alpha=alpha, beta=beta, cbar2=cbar2, cbar3=cbar3,
                beta1=beta1, cbar=cbar, beta2=beta2, beta3=beta3)


def assemble(omega, n, p=None):
    """Return the 12x12 boundary-condition matrix M(omega,n)."""
    if p is None:
        p = DEFAULT
    q = derived(MAT, p['d11'])
    l1 = p['l1']
    a, b, c, d = A_R, B_R, C_R, D_R

    k1 = omega / q['beta1']
    k2 = omega / q['beta2']
    k3 = omega / q['beta3']
    nu1 = np.sqrt(q['cbar'] ** 2 * n * n + l1 * l1 / 4.0)
    eta = np.sqrt(n * n * (1.0 + p['P'] / q['cbar3']))

    Thb = p['Kb'] - p['Tb'] * n * n / b ** 2
    Thc = p['Kc'] - p['Tc'] * n * n / c ** 2
    Sd = p['rho_s'] * omega ** 2 - p['mu_s'] * n * n / d ** 2

    # FGO
    Ja, Ya = jv(nu1, k1 * a), yv(nu1, k1 * a)
    Jb, Yb = jv(nu1, k1 * b), yv(nu1, k1 * b)
    D1Ja = k1 * jvp(nu1, k1 * a, 1) - (l1 / (2 * a)) * Ja
    D1Ya = k1 * yvp(nu1, k1 * a, 1) - (l1 / (2 * a)) * Ya
    D1Jb = k1 * jvp(nu1, k1 * b, 1) - (l1 / (2 * b)) * Jb
    D1Yb = k1 * yvp(nu1, k1 * b, 1) - (l1 / (2 * b)) * Yb
    f1a = MAT['c44F'] * (a / b) ** l1 * a ** (-l1 / 2)
    f1b = MAT['c44F'] * b ** (-l1 / 2)
    gb = b ** (-l1 / 2)

    # MEE (order n)
    J2b, Y2b = jv(n, k2 * b), yv(n, k2 * b)
    J2c, Y2c = jv(n, k2 * c), yv(n, k2 * c)
    dJ2b, dY2b = k2 * jvp(n, k2 * b, 1), k2 * yvp(n, k2 * b, 1)
    dJ2c, dY2c = k2 * jvp(n, k2 * c, 1), k2 * yvp(n, k2 * c, 1)

    # PM (order eta)
    J3c, Y3c = jv(eta, k3 * c), yv(eta, k3 * c)
    J3d, Y3d = jv(eta, k3 * d), yv(eta, k3 * d)
    dJ3c, dY3c = k3 * jvp(eta, k3 * c, 1), k3 * yvp(eta, k3 * c, 1)
    dJ3d, dY3d = k3 * jvp(eta, k3 * d, 1), k3 * yvp(eta, k3 * d, 1)

    e15, q15 = MAT['e15'], MAT['q15']
    eps, mu11, d11 = MAT['eps11'], MAT['mu11'], p['d11']
    h15, mu3 = MAT['h15'], MAT['mu3']
    c2, c3 = q['cbar2'], q['cbar3']
    bn, bmn = b ** (n - 1), b ** (-n - 1)
    cn, cmn = c ** (n - 1), c ** (-n - 1)
    dn, dmn = d ** (n - 1), d ** (-n - 1)
    cpow, cnpow = c ** n, c ** (-n)

    M = np.zeros((12, 12), dtype=float)
    # 1  BC1  traction free at r=a
    M[0, 0] = f1a * D1Ja;  M[0, 1] = f1a * D1Ya
    # 2  BC2  sigma_rz^(1) = That_b (u2-u1) at r=b
    M[1, 0] = f1b * D1Jb + Thb * gb * Jb
    M[1, 1] = f1b * D1Yb + Thb * gb * Yb
    M[1, 2] = -Thb * J2b;  M[1, 3] = -Thb * Y2b
    # 3  BC3  sigma_rz^(2) = That_b (u2-u1) at r=b
    M[2, 0] = Thb * gb * Jb;  M[2, 1] = Thb * gb * Yb
    M[2, 2] = c2 * dJ2b - Thb * J2b;  M[2, 3] = c2 * dY2b - Thb * Y2b
    M[2, 4] = e15 * n * bn;  M[2, 5] = -e15 * n * bmn
    M[2, 6] = q15 * n * bn;  M[2, 7] = -q15 * n * bmn
    # 4  BC4  D_r^(2)=0 at r=b
    M[3, 4] = -eps * n * bn;   M[3, 5] = eps * n * bmn
    M[3, 6] = -d11 * n * bn;   M[3, 7] = d11 * n * bmn
    # 5  BC5  B_r^(2)=0 at r=b
    M[4, 4] = -d11 * n * bn;   M[4, 5] = d11 * n * bmn
    M[4, 6] = -mu11 * n * bn;  M[4, 7] = mu11 * n * bmn
    # 6  BC6  sigma_rz^(2) = That_c (u3-u2) at r=c
    M[5, 2] = c2 * dJ2c + Thc * J2c;  M[5, 3] = c2 * dY2c + Thc * Y2c
    M[5, 4] = e15 * n * cn;  M[5, 5] = -e15 * n * cmn
    M[5, 6] = q15 * n * cn;  M[5, 7] = -q15 * n * cmn
    M[5, 8] = -Thc * J3c;    M[5, 9] = -Thc * Y3c
    # 7  BC7  sigma_rz^(3) = That_c (u3-u2) at r=c
    M[6, 2] = Thc * J2c;  M[6, 3] = Thc * Y2c
    M[6, 8] = c3 * dJ3c - Thc * J3c;  M[6, 9] = c3 * dY3c - Thc * Y3c
    M[6, 10] = h15 * n * cn;  M[6, 11] = -h15 * n * cmn
    # 8  BC8  D_r^(2)=0 at r=c
    M[7, 4] = -eps * n * cn;  M[7, 5] = eps * n * cmn
    M[7, 6] = -d11 * n * cn;  M[7, 7] = d11 * n * cmn
    # 9  BC9  psi^(2)=psi^(3) at r=c
    M[8, 2] = q['beta'] * J2c;  M[8, 3] = q['beta'] * Y2c
    M[8, 6] = cpow;  M[8, 7] = cnpow
    M[8, 8] = -(h15 / mu3) * J3c;  M[8, 9] = -(h15 / mu3) * Y3c
    M[8, 10] = -cpow;  M[8, 11] = -cnpow
    # 10 BC10 B_r^(2)=B_r^(3) at r=c
    M[9, 4] = -d11 * n * cn;  M[9, 5] = d11 * n * cmn
    M[9, 6] = -mu11 * n * cn; M[9, 7] = mu11 * n * cmn
    M[9, 10] = mu3 * n * cn;  M[9, 11] = -mu3 * n * cmn
    # 11 BC11 Gurtin-Murdoch at r=d
    M[10, 8] = c3 * dJ3d - Sd * J3d;  M[10, 9] = c3 * dY3d - Sd * Y3d
    M[10, 10] = h15 * n * dn;  M[10, 11] = -h15 * n * dmn
    # 12 BC12 B_r^(3)=0 at r=d
    M[11, 10] = -mu3 * n * dn;  M[11, 11] = mu3 * n * dmn
    return M


def equilibrate(M, iters=30, tol=1e-12):
    """Successive row- and column-wise 2-norm scaling (paper's description)."""
    A = np.array(M, dtype=float)
    dr = np.ones(12); dc = np.ones(12)
    for _ in range(iters):
        rn = np.linalg.norm(A, axis=1); rn[rn == 0] = 1.0
        dr *= rn; A = A / rn[:, None]
        cn = np.linalg.norm(A, axis=0); cn[cn == 0] = 1.0
        dc *= cn; A = A / cn[None, :]
        if max(rn.max() / rn.min(), cn.max() / cn.min()) < 1 + tol:
            break
    return A, dr, dc


def smin(omega, n, p=None, equil=True):
    """Smallest singular value of M (equilibrated by default)."""
    M = assemble(omega, n, p)
    if equil:
        M, _, _ = equilibrate(M)
    return np.linalg.svd(M, compute_uv=False)[-1]


def diagnostics(omega, n, p=None):
    """Everything Table 1 reports, plus the scale-invariant quantities."""
    M = assemble(omega, n, p)
    Me, _, _ = equilibrate(M)
    s = np.linalg.svd(M, compute_uv=False)
    se = np.linalg.svd(Me, compute_uv=False)
    U, sv, Vt = np.linalg.svd(Me)
    X = Vt[-1]                                    # unit-norm right singular vector
    out = dict(omega=omega, n=n,
               res_unscaled=np.linalg.norm(M @ X),
               res_equil=np.linalg.norm(Me @ X),
               sigma_min=se[-1], sigma_11=se[-2], sigma_1=se[0],
               ratio=se[-2] / se[-1],
               cond_eq=se[0] / se[-1], cond_raw=s[0] / s[-1],
               rank_eq=int(np.sum(se > 12 * np.finfo(float).eps * se[0])),
               rank_raw=int(np.sum(s > 12 * np.finfo(float).eps * s[0])),
               rel_res=se[-1] / se[0])
    return out


if __name__ == '__main__':
    q = derived(MAT, 0.0)
    print("beta1 = %.6f   cbar = %.6f   beta2 = %.6f   beta3 = %.6f"
          % (q['beta1'], q['cbar'], q['beta2'], q['beta3']))
    print("cbar44^(2) = %.6e   cbar44^(3) = %.6e" % (q['cbar2'], q['cbar3']))
    for P in (0.0, 1.18e11, 2.36e11):
        p = dict(DEFAULT); p['P'] = P
        d = diagnostics(174001.2298, 1, p)
        print("P=%.3e -> sigma_min=%.4e  ratio=%.4e  cond_eq=%.4e  cond_raw=%.4e"
              % (P, d['sigma_min'], d['ratio'], d['cond_eq'], d['cond_raw']))
