# PHASE 15 — TARGETED FIGURE REDESIGN

**Status: COMPLETE (with one flagged numerical inconsistency in the running
text — AD-48, see §6).**

Scope fixed by the author's answers: (i) apply the design standard to **this
manuscript's twelve figures**; §5–§10 of the brief describe another paper's
Figures 3–8 and are **not** in scope; (ii) size every figure for a
**single column (~85 mm)**.

---

## 1. What was done

All twelve figures were **regenerated from the production data** by one new
generator, `04_CODE/make_figures_p15.py`, driven by one new style module,
`04_CODE/figstyle_p15.py`.  No figure was edited by hand, no axis range was
invented, and no data point was removed, smoothed, interpolated or displaced.

* **Data provenance (unchanged).**  `09_OUTPUTS/recomputed_figures/cache/roots_<tag>.json`
  and `continued_extreme.json`; the phase velocity is `c_p = ω·d/n`, exactly
  as in Phases 08–14.  Mode shapes come from the null vector of the
  equilibrated 12×12 boundary-condition matrix (`trilayer_sh.equilibrate`
  + SVD), the same construction validated in Phase 07b.
* **Reproducibility.**  `python3 make_figures_p15.py` regenerates all twelve
  EPS+PNG files into `09_OUTPUTS/regenerated_figures/`; they are then copied
  into `02_MANUSCRIPT/figures/`.  Data → script → figure, no manual step.
* **22 files became 12.**  The eight three-panel studies were previously
  three separate EPS files each, assembled inside the `.tex` with a `tabular`
  and hand-written `(a) (b) (c)` captions underneath.  Each is now a single
  EPS carrying its own panel labels, its own legend cell and its own insets.
  The 44 superseded files are kept in
  `09_OUTPUTS/superseded_figures_phase15/`.

## 2. The one coherent visual language (brief §1, §12–§15)

| Element | Setting |
|---|---|
| Typeface | STIX General (Times-compatible serif), **embedded as TrueType / Type 42** |
| Axis labels | 10 pt |
| Tick, legend, annotation | 8.5 pt |
| Panel labels `(a) (b) (c)` | bold 11 pt, always at the same relative position `(-0.135, 1.045)` |
| Main curve | 1.6 pt |
| Secondary / reference line | 1.0 pt (0.9 pt for grid-like guides) |
| Axes / ticks | 0.9 pt, ticks **inward**, top and right spines suppressed |
| Markers | 4.0 pt, white fill, 0.8 pt edge in the curve colour |
| Panel size | 66 × 54 mm inside full-width composites; 66–84 mm for single panels |
| Background | white; no box around legends; no 3-D pane fill |

**Font embedding was fixed as part of this phase.**  The previous figures
carried **Type 3** fonts (`ps.fonttype = 3`), which several publishers reject
outright.  Type 1 is not available from Matplotlib (`ps.fonttype` accepts only
3 and 42) and the only Times clone installed here (Nimbus Roman, CFF
outlines) produces a PostScript file Ghostscript cannot `definefont`.  STIX
General embeds cleanly as Type 42, carries the full regular / italic / bold /
bold-italic set, and is metrically and visually a Times companion, so it also
matches the Times body text of `elsarticle`.  Every resulting EPS was
verified with `ghostscript` and the final PDF with `pdffonts` (STIX General
present, **no Type 3**).

## 3. Colour, line style and marker (brief §13, §14)

Palette: Okabe–Ito blue / vermillion / bluish green / magenta / orange /
sky blue, plus a reference grey.  Two changes were made to the Okabe–Ito set
after a numerical check (CIE Lab, Machado *et al.* 2009 simulation at
severity 1.0):

* `CB[3]` reddish purple `#CC79A7` → **magenta `#BC5090`**: the purple and
  the blue separate by only ΔE ≈ 9 under deuteranopia and protanopia; the
  magenta raises the worst separation over the whole seven-colour set from
  9.1 to **12.5**.
* reference grey `#4D4D4D` → **`#666666`**: removes the second weak pair
  (vermillion / grey, ΔE 8.3) while keeping 5.7 : 1 contrast on white for
  8.5 pt annotation text.

Every curve is additionally separated by **line style** and **marker**
(`- ○`, `-- □`, `-. △`, `: ◇`, `-- ▽`, `(5,1.5) ⬠`), so each pair of curves
differs in **three** properties, not the two the brief requires.  Reference
lines (bulk speeds, the 1 % threshold, interface radii) are always thinner
and dashed or dotted.

## 4. Overlap, legends and axis hygiene (brief §2–§4, §11, §18–§19)

* **No legend ever sits over data.**  In the five three-panel studies the
  legend occupies the **fourth cell of the panel grid**; in Figures 10 and 11
  it occupies a **full-width row beneath the panels**; in Figure 9 it sits
  above the axes; Figures 1, 3 and 12 need none (direct labels / a layer key).
* **Curves that coincide are never separated artificially.**  Where the
  spread between curves falls below 3 % of the panel range the panel receives
  a **magnified inset** with its own ticks, its own ordinate range and a
  label giving the full-scale interval Δc_p it spans; where they coincide to
  machine precision a note says so.  Insets appear in Fig. 4(a), 4(b), 6(c),
  8(a), 8(c) and 11(a) — exactly the six panels where the measured spread is
  0.0005 – 0.04 m/s.
* **Axis audit.**  A `MaxNLocator(nbins=6)` was imposed on every linear axis
  (log axes are left to their decade locators): the ten-tick y-axes of the
  old figures are gone, no axis is forced through zero, tick values are plain
  integers or simple decimals, y-offsets are switched off, and log axes use
  `10^n` notation.  The ordinate range of each panel is set by the data with
  6 % padding — the exception being Figure 12, discussed below.
* **Dead space removed.**  Figure 12 previously plotted 14 decades, of which
  **nine were empty** (the smallest amplitude in the three panels is
  8.8 × 10⁻⁶, the old floor was 10⁻¹⁴).  Its ordinate now runs 2 × 10⁻⁶ to 5,
  which contains all the data and leaves no empty decade.

## 5. Verification

Programmatic QA on the 300 dpi rasterisation of every EPS (ink bounding box,
minimum 3 px required on all four sides) — **no figure is clipped**:

| Figure | size (mm) | margins T/L/B/R (mm) |
|---|---|---|
| 1 Geometry | 84 × 76 | 4.4 / 12.0 / 4.1 / 11.7 |
| 2 Root cloud | 84 × 78 | 4.9 / 4.9 / 8.2 / 2.8 |
| 3 Dispersion | 84 × 67 | 4.0 / 3.0 / 3.2 / 2.8 |
| 4 Initial stress | 170 × 146 | 2.9 / 5.6 / 6.3 / 4.7 |
| 5 Outer radius | 170 × 146 | 2.9 / 5.6 / 6.3 / 4.7 |
| 6 Interface `K_b` | 170 × 146 | 2.9 / 7.0 / 6.3 / 4.7 |
| 7 Interface `K_c` | 170 × 146 | 2.9 / 7.0 / 6.3 / 4.7 |
| 8 Grading index | 170 × 146 | 2.9 / 7.0 / 6.3 / 4.7 |
| 9 3-D topology | 107 × 80 | 11.7 / 16.1 / 14.7 / 10.0 |
| 10 Surface elasticity | 170 × 89 | 2.9 / 5.6 / 7.5 / 4.4 |
| 11 Magnetoelectric | 170 × 89 | 2.9 / 7.0 / 8.0 / 4.7 |
| 12 Mode shapes | 170 × 146 | 2.9 / 7.7 / 6.8 / 4.7 |

Also verified: every EPS opens in Ghostscript; every EPS `%%BoundingBox`
equals the intended print size to 0.3 mm (so `\includegraphics` scales
nothing); the compiled PDF contains **no Type 3** fonts; the build is
**41 pages, 0 errors, 0 undefined references, 0 undefined citations, 0 `??`,
0 Overfull, 0 Underfull**.

## 6. FLAGGED — numerical inconsistency found in the running text (AD-48)

`02_MANUSCRIPT/Paper_FINAL.tex`, Results, dispersion-characteristics
paragraph:

> "This mode is confined to the piezomagnetic layer (Sec. …), carrying
> $1.2\times10^{-9}$ of its amplitude there against $1.2\times10^{-14}$ in
> the graded layer."

Recomputing the second higher mode at `n = 1`, default parameters
(`l₁ = 1`, `K_b = K_c = 10¹⁰ N/m³`, `T_b = T_c = 10⁶ N/m`, `μ_s = 5 N/m`,
`P = 0`, `d₁₁ = 3.01329 × 10⁻⁸ s/m`) from the null vector of the
boundary-condition matrix — the residual of all twelve boundary conditions is
≤ 4 × 10⁻¹⁹ in relative terms — gives the layer maxima

| layer | fundamental | first higher | second higher |
|---|---|---|---|
| FGO (graded) | 1.64 × 10⁻² | **1.000** | 9.73 × 10⁻⁶ |
| MEE | **1.000** | 1.00 × 10⁻² | 2.67 × 10⁻³ |
| PM | 1.21 × 10⁻³ | 1.48 × 10⁻⁵ | **1.000** |

so the second higher mode carries **1.000** of its amplitude in the
piezomagnetic layer and **9.7 × 10⁻⁶** in the graded layer, not
1.2 × 10⁻⁹ and 1.2 × 10⁻¹⁴.  The same computation reproduces the
*independently quoted* fundamental-mode figures used elsewhere in the paper
(1.6 % in the graded layer, 0.12 % in the piezomagnetic layer), which
confirms the method.  The two quoted numbers appear to be the fundamental
mode's piezomagnetic fraction (1.2 × 10⁻³) with corrupted exponents, and the
old plot's ordinate floor (10⁻¹⁴).

**Per brief §23 the number was NOT changed.**  It is recorded as AD-48 and
needs the author's confirmation.  The corrected sentence would read:
"…carrying its entire amplitude there, against $9.7\times10^{-6}$ in the
graded layer."

No figure, table, equation or numerical value was altered in Phase 15 other
than the twelve captions and the twelve `\includegraphics` widths.

## 7. Sizing decision (AD-49)

Figures 1, 2, 3 are 84 mm wide and Figure 9 is 107 mm wide; these are
inserted at 0.50 and 0.63 `\textwidth`.  The eight composite figures are
170 mm wide and are inserted at 1.00 `\textwidth` = 170 mm, i.e. **at 1:1,
without rescaling**.  The single-column standard is met **per panel**: every
panel inside those composites is 66 mm wide with 10 pt axis labels and 8.5 pt
ticks, i.e. it is a column-width panel.  Stacking three such panels in one
85 mm column would make each figure about 200 mm tall and add roughly four
pages of near-empty figure space, so the composites are left spanning the
text block.  If the target journal is two-column, each composite splits into
two single-column rows with no redesign.

---

## 8. FINAL FIGURE-BY-FIGURE AUDIT (brief §23)

| Figure | Main problem in the old version | Change made | Scientific data changed? | Inset added? | Legend redesigned? | Final status |
|---|---|---|---|---|---|---|
| **1** Geometry (was `Geo.eps`) | Hand-drawn schematic; ad-hoc fonts; annotation strings strayed outside the frame | Redrawn programmatically: white ground, three layer fills, radii `r=a,b,c,d` labelled on one ray, layer names in the layer colour, two thin-leader callouts for the Gurtin–Murdoch surface and the spring–membrane interfaces, equal aspect, margins balanced to 0.3 mm | **NO** | no | n/a — direct labels | **PASS** |
| **2** Root cloud | The "all roots" scatter silently used Matplotlib's default **rainbow** cycle (ten hues); no indication of what the cloud is | Cloud forced to a single light grey; three branches in colour + line style + marker; β₁, β₂, β₃ reference lines with values (β₂ quoted at its d₁₁); italic note naming the untracked higher roots | **NO** | no | yes — moved below the panel, 2 columns, frameless | **PASS** |
| **3** Dispersion | Legend boxed inside the axes, over the curves | Legend removed; each branch **direct-labelled** at its right-hand end; β₃ line retained; x-ticks reduced to 0,2,4,6,8 | **NO** | no | yes — replaced by direct labels | **PASS** |
| **4** Initial stress | Three separate EPS assembled in a `tabular`; panel (a) and (b) curves indistinguishable and unexplained; ten y-ticks | One 2×2 composite: (a)(b) / (c)+legend; 66 mm panels; **magnified inset in (a) and (b)** (spread 0.008 and 0.0005 m/s); ≤7 y-ticks | **NO** | **yes — (a), (b)** | yes — own grid cell | **PASS** |
| **5** Outer radius | Same structural defects | One 2×2 composite; shared legend cell; no inset (curves differ by 1.4–2.2 × 10³ m/s) | **NO** | no | yes — own grid cell | **PASS** |
| **6** Interface stiffness `K_b` | Same; the second higher mode curves coincide to 0.04 m/s with no explanation | One 2×2 composite; **magnified inset in (c)** | **NO** | **yes — (c)** | yes — own grid cell | **PASS** |
| **7** Interface stiffness `K_c` | Same structural defects | One 2×2 composite; no inset (curves differ by 0.7–1.1 × 10³ m/s) | **NO** | no | yes — own grid cell | **PASS** |
| **8** Grading index `l₁` | Same; fundamental and second higher curves coincide with no explanation | One 2×2 composite; **magnified insets in (a) and (c)** (spread 0.042 and 0.011 m/s) | **NO** | **yes — (a), (c)** | yes — own grid cell | **PASS** |
| **9** 3-D topology | Legend over the data cube; cube squashed; no box aspect | Legend moved **above the axes**, 3 columns, frameless; `box_aspect (1.55, 1, 0.62)`; view chosen so no locus hides another; figure 107 × 80 mm | **NO** | no | yes — moved outside the data region | **PASS** |
| **10** Surface elasticity | Two panels, in-axes legend; μ_s = 0 and 5 N/m curves drawn on top of each other silently | 1×2 composite with a **full-width legend row** (5 entries); a leader line states that the two curves coincide; panel (b) log–log with the 1 % threshold and the 4 × 10⁷ N/m crossing marked | **NO** | no | yes — own row below the panels | **PASS** |
| **11** Magnetoelectric `d₁₁` | Same; the non-monotone minimum — the scientific point of the figure — invisible | 1×2 composite with a **full-width legend row** (6 entries); **inset in (a)** plotting c_p(n=1) directly against d₁₁ with a dotted vertical at d₁₁* = 2.674 × 10⁻⁷ s/m; spread stated on panel (b) | **NO** | **yes — (a)** | yes — own row below the panels | **PASS** |
| **12** Mode shapes | Ordinate spanned 14 decades of which 9 were empty; no layer key; the interface steps unexplained | Ordinate 2 × 10⁻⁶ – 5 (contains all the data); **layer key in the fourth cell**; note that the steps at r = b, c are the spring–membrane displacement jumps, with the equation reference; identical ordinate range in all three panels | **NO** | no | yes — layer-key cell | **PASS** |

**"Scientific data changed?" is NO for all twelve figures.**  Every figure is
a re-presentation of the same recomputed roots; no value was deleted,
smoothed, interpolated, re-normalised (other than the ordinate *range* of
Figure 12) or displaced.  The one numerical discrepancy found lies in the
running text, not in a figure, and is reported as AD-48 rather than changed.

---

## 9. COMPLIANCE MATRIX FOR BRIEF §1–§23

| § | Requirement | How it is met | Status |
|---|---|---|---|
| 1 | One coherent visual language | `04_CODE/figstyle_p15.py` is the single source: STIX General, 10 pt axis labels, 8.5 pt ticks/legend, bold 11 pt panel labels at a fixed relative position, 0.9 pt axes, inward ticks, 1.6/1.0/0.9 pt lines, 4.0 pt markers, LaTeX maths (`mathtext.fontset = stix`), SI units, frameless legends, white ground, no decoration | **done** |
| 2 | Curve overlap not solved by line width | Coincident curves get a **magnified inset** (Fig 4a, 4b, 6c, 8a, 8c, 11a) or a stated spread; every curve also differs in line style and marker. Nothing hidden, deleted or displaced | **done** |
| 3 | Peaks clear | No clipping anywhere (ink-bounding-box test, 300 dpi, min margin 2.8 mm); 6 % ordinate padding; the $d_{11}$ minimum is shown in its own inset with a dotted vertical; annotations sit in empty regions with thin leaders, never over curves | **done** |
| 4 | Legends | Legend occupies the **fourth grid cell** (Fig 4–8, 12), a **full-width row** (Fig 10, 11), or **above the axes** (Fig 9); Fig 1, 3, 12 use direct labels / a layer key. Short labels in the manuscript's own terminology | **done** |
| 5–10 | Figures 3–8 (mesh/direction study, wall-stress history, orientation sweep, pulse width, anisotropy ablation, thermal memory) | **OUT OF SCOPE** — these describe a different paper's figures. Confirmed by the author: apply the standard to *this* manuscript's twelve figures only | **n/a** |
| 11 | Axis design | `MaxNLocator(nbins=6)` on every linear axis; decade locators on log axes; tick-spacing test run on **every axis of every figure** — spacing ≥ label width + 1 mm everywhere, no overlaps; no axis forced to zero; integer ticks on the integer $n$ axis of Fig 9 (fixed in the final pass); plain tick values, no spurious decimals | **done** |
| 12 | Font and size | axis labels 10 pt, ticks/legend 8.5 pt, panel labels bold 11 pt, annotations ≥ 8 pt; all mathematical notation through one mathtext set | **done** |
| 13 | Line widths and markers | main 1.6, secondary/reference 1.0 and 0.9, axes 0.9, markers 4.0 pt with 0.8 pt edge — verified from the rendered artists, not just from rcParams | **done** |
| 14 | Colour | Okabe–Ito, no rainbow; two substitutions after a numerical colour-blind check (worst pair ΔE 9.1 → **12.5** under protan/deutan/tritan simulation); every curve differs by **three** properties (colour + line style + marker), so the set is grayscale-safe | **done** |
| 15 | Size and aspect | 84 / 107 / 170 mm; all panels 66 × 54 mm, aligned, equal, consistent label position; unused whitespace measured by the ink bounding box of every figure | **done** |
| 16 | Captions | All twelve rewritten: what is plotted, what each panel shows, what the line styles/markers/insets mean, and which parameter differs. No interpretation, no duplication of Results | **done** |
| 17 | Do not over-clean | No point removed, smoothed or interpolated; no peak moved. The only ordinate change is Fig 12, where 2 × 10⁻⁶ – 5 replaced 10⁻¹⁴ – 20, i.e. it removed **nine empty decades**, not data | **done** |
| 18 | Direct labels vs legends | Direct labels in Fig 1, 3; a legend only where the curve count makes labels impractical (Fig 2, 4–8, 10, 11); layer key instead of a legend in Fig 12 | **done** |
| 19 | Insets | Six insets, each with its own ticks, its own ordinate range, a short label giving the Δc_p it spans, the same line styles as the parent panel, and placed in the low-ink corner | **done** |
| 20 | No publication-unsuitable content | Source scanned for internal/debug/test/filename/development wording and every drawn string listed and inspected — **clean**. The one "internal" hit is the physics phrase "internal interfaces" in a code comment | **done** |
| 21 | Regenerate, do not edit | `04_CODE/make_figures_p15.py` reads the production cache and writes all twelve EPS+PNG; no manual or raster editing anywhere | **done** |
| 22 | Final visual QA | Manuscript compiled (41 pp, 0 errors/warnings); every figure checked for clipping, for tick collision, for Ghostscript validity, for `%%BoundingBox` = intended mm; PDF checked with `pdffonts` (no Type 3). Items 2–4 of §22 (human inspection at 100 % and at column size) were carried out **programmatically at 300 dpi** — the smallest drawn glyph is 8 pt and the tick-spacing test above is the quantitative equivalent | **done, method stated** |
| 23 | Audit table | §8 of this report | **done** |

---

## 10. SECOND AUDIT PASS — two defects found and fixed

The brief was re-run as a full audit (§1–§23).  Everything in §1–§23 was
already satisfied; the greyscale half of §22.13, which had only been checked
on the palette, exposed two real defects.

**(a) Figure 1 — the two inner layers were rendering white.**  The rings are
drawn as a filled disc punched by a white disc.  Every disc used `zorder=1`
and every knockout `zorder=2`, so the second and third discs were painted
*underneath* the previous knockout: only the outer (PM) ring was tinted.
Pixel census before the fix: FGO 46 px, MEE 171 px, PM 105 614 px.  The
z-orders now rise with each layer (`1+2k` / `2+2k`), giving
FGO 6.9 %, MEE 9.1 %, PM 11.9 % of the figure — the ratio 1 : 1.32 : 1.72
matches the annulus areas 393 : 550 : 707 mm².

**(b) The three layer tints were indistinguishable in greyscale.**  The old
tints `#DCE9F5 / #F7E3D0 / #DCEFE0` have luminances 0.801 / 0.793 / 0.823 and
print as one flat grey.  They are now `#EAF2FA / #F7E3D0 / #CFE3D4`, a ladder
at 0.879 / 0.793 / 0.730; the hues are unchanged, so the colour appearance is
the same and the bands separate in greyscale as well.

Both changes are presentational.  **No scientific data changed.**

After the fix: no clipping on any figure (min margin 2.8 mm), all twelve EPS
render in Ghostscript, manuscript rebuilt 41 pp with 0 errors / 0 undefined
references / 0 undefined citations / 0 Overfull / 0 Underfull, no Type 3
fonts.

## 11. HUMAN VISUAL-QA PROOF SHEET

`09_OUTPUTS/Figure_Proof_Sheet_Phase15.pdf` (12 pages, one per figure) shows,
for every figure:

* the EPS at **100 % of its natural size** (the size the manuscript inserts
  it), with the insertion fraction and the resulting reduction;
* the same file **reduced to an 85 mm column**, for the legibility check of
  §22.3;
* a **greyscale** copy at that column size, for §22.13.

This exists because the automated checks cannot substitute for a human eye on
§22 items 2–4 and 12.  Please look at it and tell me what you want changed.

## 12. CLEAN-ROOM REBUILD OF THE SHIPPED PACKAGE (delivery verification)

Before the submission bundle was zipped, the *shipped source* was rebuilt out of tree, from a
copy of `TRILAYER_SH_WAVE_FINAL_PACKAGE/01_manuscript/` placed in an empty directory, with no
access to the working tree:

```
latex Paper_FINAL ; bibtex Paper_FINAL ; latex x3 ; dvips -P pdf -q ; ps2pdf -dPDFSETTINGS=/prepress
```

Result:

| Check | Result |
|---|---|
| LaTeX errors | 0 |
| Undefined references | 0 |
| Undefined citations | 0 |
| `??` in output | 0 |
| Overfull boxes | 0 |
| Underfull boxes | 0 |
| Pages | 41 (DVI 310,492 bytes) |
| `pdftotext` diff vs shipped `Paper_FINAL.pdf` | **0 differing lines** |
| `pdffonts` | 31 embedded subsets, **no Type 3** |
| Ghostscript | renders all 41 pages |

Two facts follow. (i) The bundle is self-contained: the `.tex`, the `.bib` and the 12 EPS files in
`01_manuscript/figures/` are sufficient to regenerate the shipped PDF with no other dependency.
(ii) The shipped PDF is bit-for-bit reproducible in content from the shipped source.

One stale artefact was found and replaced during this check: `09_OUTPUTS/Paper_FINAL.pdf` and
`09_OUTPUTS/Paper_PHASE_15_compiled.pdf` (identical, 859,261 B, **40** pages) were a pre-redesign
build — they still carried the old Figure 1 geometry panel. Both were overwritten with the
current 41-page build (937,178 B). `Paper_PHASE_13_compiled.pdf` and `Paper_PHASE_14_compiled.pdf`
are intentionally left at their historical 40-page state.
