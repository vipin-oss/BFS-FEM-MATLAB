# Circumferential SH-Wave Dispersion in a Functionally Graded Smart
# Cylindrical Structure with Gurtin–Murdoch Surface Elasticity and
# Spring–Membrane Interfaces

**Final submission package — 2026-10-04**

This archive contains everything needed to compile the manuscript, to
regenerate every figure from the underlying numerical data, and to reproduce
the compiled PDF.

---

## 1. Contents

```
01_manuscript/
    Paper_FINAL.tex        the authoritative LaTeX source
    Paper_FINAL.pdf        the compiled manuscript (41 pages, A4)
    ascexmpl-new.bib       the bibliography
    figures/               12 figures as EPS (submission) + PNG (preview)

02_submission/
    cover_letter_FINAL.pdf / .tex      cover letter (2 pages)
    SUBMISSION_CHECKLIST.md            technical + scientific status,
                                       author actions, journal-format items

03_figure_code/
    figstyle_p15.py            the single visual language (fonts, sizes,
                               line widths, colour palette, grid geometry)
    make_figures_p15.py        regenerates all 12 figures from the data
    patch_figure_blocks_p15.py rewrites the 12 figure environments/captions
    make_proof_sheet_p15.py    builds the 100 %/column/greyscale proof sheet
    trilayer_sh.py             the physics: 12×12 boundary-condition matrix
    track_joint.py             branch continuation in the wavenumber

04_figure_data/
    roots_<tag>.json           recomputed roots, ω in rad/s, n = 1…20
    continued_extreme.json     continued branches at the extreme parameters
    flag_table_p08.txt         admissibility flags

05_reports/
    PHASE_15_FIGURE_REDESIGN.md        full figure-redesign report, the §23
                                       figure-by-figure audit table, and the
                                       §1–§23 compliance matrix
    Figure_Proof_Sheet_Phase15.pdf     each figure at 100 %, at an 85 mm
                                       column, and in greyscale
```

## 2. Building the manuscript

Requires TeX Live (`latex`, `bibtex`, `dvips`, `ps2pdf`) with `elsarticle`.
**Do not use `pdflatex`** — the twelve figures are EPS.

```bash
mkdir build && cd build
cp -r ../01_manuscript/* .
rm -f *.aux *.bbl *.blg *.dvi
latex   Paper_FINAL
bibtex  Paper_FINAL
latex   Paper_FINAL
latex   Paper_FINAL
latex   Paper_FINAL
dvips   -P pdf -q -o Paper_FINAL.ps Paper_FINAL.dvi
ps2pdf  -dPDFSETTINGS=/prepress Paper_FINAL.ps Paper_FINAL.pdf
```

Expected result: **41 pages, 0 errors, 0 undefined references, 0 undefined
citations, 0 Overfull, 0 Underfull boxes.**

## 3. Regenerating the figures

```bash
cd 03_figure_code
# point the loader at the data: put 04_figure_data/ where the cache is expected,
# then
python3 make_figures_p15.py
```

This rewrites all twelve EPS + PNG files. The workflow is
**data → plotting script → final figure**; no figure is edited by hand and
none is rasterised. To rewrite the figure environments and captions in the
LaTeX source:

```bash
python3 patch_figure_blocks_p15.py ../../01_manuscript/Paper_FINAL.tex
```

(the script is idempotent, and it must be applied to `Paper_FINAL.tex` and
`Paper_PHASE_07B.tex` together, since those two copies are kept identical).

## 4. Figure design (Phase 15)

| Item | Setting |
|---|---|
| Typeface | STIX General (Times-compatible serif), embedded as **TrueType / Type 42** — no Type 3 |
| Axis labels / ticks / legend / panel labels | 10 pt / 8.5 pt / 8.5 pt / bold 11 pt |
| Line widths | main 1.6 pt, reference 1.0 pt, axes 0.9 pt; markers 4.0 pt |
| Palette | Okabe–Ito, with two substitutions after a colour-blind check — worst pair ΔE 12.5 under protan/deutan/tritan simulation |
| Separation | every curve differs by **three** properties (colour + line style + marker), so the set is greyscale-safe |
| Sizes | single figures 84 mm and 107 mm; composites 170 mm; **every panel 66 × 54 mm** |
| Legends | always outside the data region: a dedicated grid cell, a full-width row, or above the axes |
| Close curves | magnified insets in Fig 4(a), 4(b), 6(c), 8(a), 8(c), 11(a) |
| Insertion | each figure is inserted at 1:1 — `0.50`, `0.63` or `1.00 \textwidth` — so nothing is rescaled |

## 5. Verification status

* No clipping: the ink bounding box of every figure has ≥ 2.8 mm on all four
  sides at 300 dpi.
* Every EPS opens in Ghostscript; each `%%BoundingBox` equals the intended
  print size, so `\includegraphics` rescales nothing.
* The compiled PDF contains no Type 3 fonts.
* Every axis passes a tick-spacing test (spacing ≥ rendered label width
  + 1 mm).
* The twelve EPS files in `01_manuscript/figures/` reproduce byte-for-byte
  from a fresh run of `make_figures_p15.py`.
* **Clean-room rebuild of this bundle.** The shipped `01_manuscript/` was
  copied to an empty directory and rebuilt with nothing else available:
  0 errors, 0 undefined references, 0 undefined citations, 0 `??`,
  0 Overfull, 0 Underfull, **41 pages**, no Type 3 fonts, and `pdftotext`
  of the result is **identical, line for line, to the shipped
  `Paper_FINAL.pdf`**. The bundle is therefore self-contained and its PDF
  is reproducible from its own source.

## 6. Open items — the author's decision is required

| ID | Item |
|---|---|
| **AD-01** | **The target journal has never been fixed (BLOCKING for submission).** The cover letter names *Composites Part B: Engineering*; the original `Final.tex` declared *Waves in Random and Complex Media*. Everything journal-dependent — spelling convention, reference style, figure widths, page limits — follows from this choice. |
| **AD-48** | One sentence in the Results is inconsistent with the recomputation and was **reported, not changed**. It states that the second higher mode carries "1.2 × 10⁻⁹ of its amplitude" in the piezomagnetic layer "against 1.2 × 10⁻¹⁴ in the graded layer". Recomputation (all twelve boundary conditions satisfied to ≤ 4 × 10⁻¹⁹ in relative terms) gives **1.000** in the piezomagnetic layer, 2.7 × 10⁻³ in the magneto-electro-elastic layer and **9.7 × 10⁻⁶** in the graded layer. The same method reproduces the paper's own, independently quoted fundamental-mode figures (1.6 % and 0.12 %). |
| **AD-49** | The eight composite figures span the 170 mm text block at 1:1 while every panel inside is 66 mm, i.e. one column. If the target journal is two-column, split each composite into two single-column rows; no redesign is needed. |

## 7. Scope note

The figure redesign applies to **this manuscript's twelve figures**. Sections
5–10 of the redesign brief describe a different paper's figures (peak wall
stress against radial clustering, hoop-stress time histories, ellipse
orientation sweeps, pulse-width results, anisotropy-ablation bars, thermal
memory) and are not part of this work.
