# Submission package

* `TorsionalWaveguide_FINAL.pdf` — compiled manuscript.
* `manuscript/` — LaTeX source (`TorsionalWaveguide_FINAL.tex`, Springer Nature `sn-jnl` class, `sn-mathphys-num` style), bibliography and the 14 figures. Compile with `pdflatex`, `bibtex`, `pdflatex`, `pdflatex`.
* `supplementary/code/` — Python code for all computed results and figures (see its README).
* `supplementary/data/` — computed data quoted in the paper.
