# Code for "Torsional Surface Waves in a Three-Layer Cylinder with a Drude Metamaterial Shell, Imperfect Interfaces and Surface Elasticity"

Python code that computes the dispersion curves and generates Figs. 2–15 of the paper.

```
pip install -r requirements.txt
python tests/test_regression.py     # < 1 min
python run_all.py output            # about 1 h, single core
```

| File | Content |
|---|---|
| `src/python/core.py` | Dimensionless 5×5 characteristic matrix (Sec. 4), exponentially scaled determinant, root search and branch tracking (Sec. 5) |
| `src/python/verification.py` | Two-medium model of Kiełczyński et al. (2025), welded / semi-infinite-shell / planar spring-interface limits, boundary-condition residuals (Sec. 6, Figs. 2–4) |
| `src/python/results_figures.py` | Figs. 5, 7, 8, 10, 13, 14 (dispersion, μ*_s map and sweeps, localization, velocities, surface sensitivity), the one-at-a-time sensitivity table (JSON) and an optional heat map of it |
| `src/python/parametric_figures.py` | Figs. 6, 9, 11, 12 (interface stiffness, geometry, radial profiles, displacement field) |
| `config/numerical_settings.json` | Scan and tracking settings (Sec. 5) |

Material parameters are set at the top of `core.py` (baseline material table of the paper). Each figure module also writes a JSON file with the key numbers quoted in the text.
