#!/usr/bin/env python3
"""Regenerate all computed figures (Figs. 2-15) and result files.

Usage:  python run_all.py [output_dir]      (default: ./output)
Run time is roughly one hour on a single core.
"""
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else HERE / "output"
OUT.mkdir(parents=True, exist_ok=True)
for module in ("verification.py", "results_figures.py", "parametric_figures.py"):
    print(f"running {module} ...", flush=True)
    subprocess.run([sys.executable, str(HERE / "src" / "python" / module), str(OUT)],
                   check=True, cwd=HERE / "src" / "python")
print(f"done; results in {OUT}")
