#!/usr/bin/env python3
"""Figures 6, 9, 11 and 12 of the manuscript (interface stiffness, geometry,
radial profiles and displacement field).

Usage:  python parametric_figures.py [output_dir]
"""
import json
import sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.special import iv, kv

import core

OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / "output"
OUT.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.size": 10, "axes.labelsize": 10, "legend.fontsize": 8,
                     "axes.titlesize": 10, "savefig.dpi": 300, "savefig.bbox": "tight"})
XI = np.linspace(0.05, 6.0, 300)
RES = {}


def branch(ka, kb, mus, alpha=0.5, beta=1.5, xi=XI):
    a0, b0 = core.alpha, core.beta
    core.alpha, core.beta = alpha, beta
    try:
        info, _ = core.track_physical_branch(ka, kb, mus, 0.0, xi)
    finally:
        core.alpha, core.beta = a0, b0
    om = np.full(len(xi), np.nan)
    idx = np.searchsorted(xi, info["xi"])
    om[idx] = np.where(info["ok_mask"], info["om"], np.nan)
    return om


def profile(xi, om, ka, kb, mus, n=400):
    M = core.Mmat(xi, om, ka, kb, mus, 0.0)
    X = np.linalg.svd(M)[2][-1]
    g = core.gammas2(xi, om, 0, 0, 0, 0)
    g1, g2, g3 = np.sqrt(g[0]), np.sqrt(g[1]), np.sqrt(g[2])
    a, b = core.alpha, core.beta
    r1, r2, r3 = np.linspace(0, a, n), np.linspace(a, 1, n), np.linspace(1, b, n)
    u1 = X[0]*iv(1, g1*r1); u2 = X[1]*iv(1, g2*r2) + X[2]*kv(1, g2*r2)
    u3 = X[3]*iv(1, g3*r3) + X[4]*kv(1, g3*r3)
    s = max(abs(u1).max(), abs(u2).max(), abs(u3).max())
    return (r1, u1/s), (r2, u2/s), (r3, u3/s)


def shade(ax, rmm):
    a, b, c = core.alpha*rmm, rmm, core.beta*rmm
    for lo, hi, col in [(0, a, "#dbe4f5"), (a, b, "#f5eed3"), (b, c, "#e3f2e3")]:
        ax.axvspan(lo, hi, color=col, zorder=0)
    for x in (a, b):
        ax.axvline(x, color="k", ls="--", lw=.8)


def fig_interfaces():
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 4))
    for k in [0.5, 2, 5, 20, 100]:
        a1.plot(XI, branch(k, 5.0, 1e-5), lw=1.8, label=rf"$k_a^*={k:g}$")
        a2.plot(XI, branch(5.0, k, 1e-5), lw=1.8, label=rf"$k_b^*={k:g}$")
    for a, t in [(a1, r"(a) $k_b^*=5$"), (a2, r"(b) $k_a^*=5$")]:
        a.set_xlim(0, 6); a.set_ylim(0, 0.23); a.set_xlabel(r"$\xi=kb$"); a.set_ylabel(r"$\Omega$")
        a.set_title(t, loc="left"); a.grid(ls=":", alpha=.6); a.legend(loc="lower right")
    fig.tight_layout(); fig.savefig(OUT/"fig_interface_stiffness_comparison.png"); plt.close(fig)


def fig_geometry():
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 4))
    for bb in [1.15, 1.30, 1.50, 2.00]:
        y = branch(5.0, 5.0, 1e-5, beta=bb)
        a1.plot(XI, y, lw=1.8, label=rf"$\beta={bb:.2f}$"); RES[f"beta{bb}_Om6"] = y[-1]
    for aa in [0.2, 0.5, 0.8]:
        y = branch(5.0, 5.0, 1e-5, alpha=aa)
        a2.plot(XI, y, lw=1.8, label=rf"$\alpha={aa:.2f}$"); RES[f"alpha{aa}_Om6"] = y[-1]
    for a, t in [(a1, r"(a) shell thickness, $\alpha=0.5$"), (a2, r"(b) core radius, $\beta=1.5$")]:
        a.set_xlim(0, 6); a.set_ylim(0, 0.4); a.set_xlabel(r"$\xi=kb$"); a.set_ylabel(r"$\Omega$")
        a.set_title(t, loc="left"); a.grid(ls=":", alpha=.6); a.legend(loc="upper right")
    fig.tight_layout(); fig.savefig(OUT/"fig_geometry_thickness.png"); plt.close(fig)


def fig_profiles():
    rmm = core.b*1e3
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 4))
    om = branch(5.0, 5.0, 1e-5)
    for x, st, lab in [(0.5077, "b-", r"$\xi=0.51$"), (5.0050, "r--", r"$\xi=5.01$")]:
        i = int(np.argmin(abs(XI - x)))
        for j, (r, u) in enumerate(profile(XI[i], om[i], 5.0, 5.0, 1e-5)):
            a1.plot(r*rmm, abs(u), st, lw=1.8, label=lab if j == 0 else None)
    for k, st in [(0.5, "b-"), (100, "r--")]:
        o = branch(k, k, 0.7)[-1]
        for j, (r, u) in enumerate(profile(6.0, o, k, k, 0.7)):
            a2.plot(r*rmm, abs(u), st, lw=1.8, label=rf"$k_a^*=k_b^*={k:g}$" if j == 0 else None)
    for a, t in [(a1, "(a) baseline"), (a2, r"(b) $\mu_s^*=0.7$, $\xi=6$")]:
        shade(a, rmm); a.set_xlim(0, core.beta*rmm); a.set_ylim(0, 1.08)
        a.set_xlabel(r"$r$ (mm)"); a.set_ylabel(r"$|u_\theta|/\max|u_\theta|$")
        a.set_title(t, loc="left"); a.legend(loc="upper left")
    fig.tight_layout(); fig.savefig(OUT/"fig_mode_shape_combined.png"); plt.close(fig)


def fig_field():
    rmm = core.b*1e3
    om = branch(5.0, 5.0, 1e-5)
    fig, axs = plt.subplots(1, 2, figsize=(10, 4))
    for ax, x, t in zip(axs, [0.5077, 5.0050], ["(a)", "(b)"]):
        i = int(np.argmin(abs(XI - x)))
        parts = profile(XI[i], om[i], 5.0, 5.0, 1e-5)
        r = np.concatenate([p[0] for p in parts]); u = np.concatenate([p[1] for p in parts])
        lam = 2*np.pi/XI[i]
        z = np.linspace(0, lam, 200)
        U = np.real(np.outer(np.exp(1j*XI[i]*z), u))
        m = abs(U).max()
        im = ax.pcolormesh(r*rmm, z, U, cmap="RdBu_r", vmin=-m, vmax=m, shading="auto")
        for xx in (core.alpha*rmm, rmm):
            ax.axvline(xx, color="k", ls="--", lw=.8)
        ax.set_xlabel(r"$r$ (mm)"); ax.set_ylabel(r"$z/b$")
        ax.set_title(rf"{t} $\xi={XI[i]:.4f}$, $\Omega={om[i]:.6f}$", loc="left")
        fig.colorbar(im, ax=ax, label=r"$u_\theta$ (normalized)")
    fig.tight_layout(); fig.savefig(OUT/"fig_field_journal.png"); plt.close(fig)


if __name__ == "__main__":
    fig_interfaces(); fig_geometry(); fig_profiles(); fig_field()
    (OUT/"parametric_figures.json").write_text(json.dumps(RES, indent=1, default=float))
    print(json.dumps(RES, indent=1, default=float))
