#!/usr/bin/env python3
"""Result figures 5, 7, 8, 10, 13, 14, 15 of the manuscript.

Branches are tracked with ``core.track_physical_branch`` (checked against an
independent dense root census, max difference 2e-14).  Group velocities and
parameter sensitivities use implicit differentiation of det M.

Usage:  python results_figures.py [output_dir]
"""
import json
import sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.optimize import brentq
from scipy.special import iv, kv

import core

OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / "output"
OUT.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.size": 10, "axes.labelsize": 10, "legend.fontsize": 8,
                     "axes.titlesize": 10, "savefig.dpi": 300, "savefig.bbox": "tight"})
XI = np.linspace(0.05, 6.0, 300)
BASE = dict(ka=5.0, kb=5.0, mus=1e-5)
RES = {}


def branch(p, xi=XI):
    info, _ = core.track_physical_branch(p["ka"], p["kb"], p["mus"], 0.0, xi)
    om = np.full(len(xi), np.nan)
    idx = np.searchsorted(xi, info["xi"])
    om[idx] = np.where(info["ok_mask"], info["om"], np.nan)
    return om


def detr(xi, om, p):
    return np.linalg.det(core.Mmat_stable(xi, om, p["ka"], p["kb"], p["mus"], 0.0))


def d_dxi(xi, om, p, h=1e-7):
    return -((detr(xi + h, om, p) - detr(xi - h, om, p))/(2*h)) / \
        ((detr(xi, om*(1 + h), p) - detr(xi, om*(1 - h), p))/(2*h*om))


def d_dmus(xi, om, p, h=1e-6):
    q = p["mus"]; hq = h*max(q, 1e-3)
    up, dn = dict(p, mus=q + hq), dict(p, mus=q - hq)
    return -((detr(xi, om, up) - detr(xi, om, dn))/(2*hq)) / \
        ((detr(xi, om*(1 + h), p) - detr(xi, om*(1 - h), p))/(2*h*om))


def lower_root(xi, p):
    g = np.geomspace(1e-9, 0.5*xi, 4000)
    v = np.array([core.Dfun(xi, o, p["ka"], p["kb"], p["mus"], 0.0) for o in g])
    for i in range(len(g) - 1):
        if np.isfinite(v[i]) and np.isfinite(v[i+1]) and np.signbit(v[i]) != np.signbit(v[i+1]):
            return brentq(lambda o: core.Dfun(xi, o, p["ka"], p["kb"], p["mus"], 0.0), g[i], g[i+1], xtol=1e-16)
    return np.nan


def shell_metrics(xi, om, p):
    M = core.Mmat(xi, om, p["ka"], p["kb"], p["mus"], 0.0)
    X = np.linalg.svd(M)[2][-1]
    g = core.gammas2(xi, om, 0, 0, 0, 0)
    g1, g2, g3 = np.sqrt(g[0]), np.sqrt(g[1]), np.sqrt(g[2])
    a, b = core.alpha, core.beta
    r1, r2, r3 = np.linspace(1e-6, a, 2001), np.linspace(a, 1, 2001), np.linspace(1, b, 2001)
    u1 = X[0]*iv(1, g1*r1); u2 = X[1]*iv(1, g2*r2) + X[2]*kv(1, g2*r2)
    u3 = X[3]*iv(1, g3*r3) + X[4]*kv(1, g3*r3)
    umax = max(abs(u1).max(), abs(u2).max(), abs(u3).max())
    twist0 = abs(X[0])*g1/2          # lim_{r->0} |u|/r
    return dict(Rcb=abs(u3[-1])/abs(u3[0]), Jb=100*abs(u3[0] - u2[-1])/umax,
                Ja=100*abs(u2[0] - u1[-1])/umax, L=(abs(u3[-1])/b)/twist0)


def rcb_free_shell(g, b):
    return (kv(2, b*g)*iv(1, b*g) + iv(2, b*g)*kv(1, b*g))/(kv(2, b*g)*iv(1, g) + iv(2, b*g)*kv(1, g))


# ------------------------------------------------------------ Fig. 5 dispersion
def fig_dispersion():
    om = branch(BASE)
    zg = [0.85179, 2.29458, 4.51960]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 4))
    a1.plot(XI, om, "b-", lw=2, label="Branch 1")
    a1.plot(XI, XI, "g--", lw=1, label=r"Bulk shear line $\Omega=\xi$")
    a1.plot(zg, np.interp(zg, XI, om), "ko", ms=4, label=r"$d\Omega/d\xi=0$")
    a1.set_xlim(0, 6); a1.set_ylim(0, 0.2)
    a1.set_xlabel(r"$\xi=kb$"); a1.set_ylabel(r"$\Omega$"); a1.set_title("(a)", loc="left")
    a1.grid(ls=":", alpha=.6); a1.legend(loc="lower right")
    for mus, st in [(1e-6, ":"), (1e-5, "-"), (1e-4, "--")]:
        xs = np.geomspace(0.02, 6, 60)
        y = [lower_root(x, dict(BASE, mus=mus)) for x in xs]
        a2.loglog(xs, y, st, lw=1.8, label=rf"Branch 2, $\mu_s^*=10^{{{int(np.log10(mus))}}}$")
    a2.set_xlabel(r"$\xi=kb$"); a2.set_ylabel(r"$\Omega$"); a2.set_title("(b)", loc="left")
    a2.grid(ls=":", alpha=.6, which="both"); a2.legend(loc="lower right")
    fig.tight_layout(); fig.savefig(OUT/"fig_dispersion_journal.png"); plt.close(fig)
    return om


# ------------------------------------------------------ Fig. 7 surface map
def fig_surface():
    mus_vals = np.linspace(0.0, 2.0, 41)
    xi = np.linspace(0.05, 6.0, 150)
    Z = np.array([branch(dict(BASE, mus=max(m, 1e-12) if m > 0 else 0.0), xi) for m in mus_vals])
    fig, ax = plt.subplots(figsize=(5.6, 4.2))
    cs = ax.contourf(xi, mus_vals, Z, levels=np.linspace(0, 1.0, 21), cmap="viridis")
    ax.contour(xi, mus_vals, Z, levels=np.arange(0.1, 1.0, 0.1), colors="w", linewidths=.5)
    fig.colorbar(cs, ax=ax, label=r"$\Omega$")
    ax.set_xlabel(r"$\xi=kb$"); ax.set_ylabel(r"$\mu_s^*$")
    fig.tight_layout(); fig.savefig(OUT/"fig_surface_journal.png"); plt.close(fig)


# --------------------------------------------------- Fig. 8 parametric sweeps
def fig_parametric():
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 4))
    for m in [0, 0.2, 0.5, 1.0, 2.0]:
        a1.plot(XI, branch(dict(BASE, mus=m)), lw=1.8, label=rf"$\mu_s^*={m:g}$")
    for k in [0.5, 2, 5, 20, 100]:
        a2.plot(XI, branch(dict(ka=k, kb=k, mus=0.7)), lw=1.8, label=rf"$k_a^*=k_b^*={k:g}$")
    for a, t in [(a1, "(a)"), (a2, "(b)")]:
        a.plot(XI, XI, "k:", lw=.8)
        a.set_xlim(0, 6); a.set_ylim(0, 1.05); a.set_xlabel(r"$\xi=kb$"); a.set_ylabel(r"$\Omega$")
        a.set_title(t, loc="left"); a.grid(ls=":", alpha=.6); a.legend(loc="lower right")
    fig.tight_layout(); fig.savefig(OUT/"fig_parametric_journal.png"); plt.close(fig)


# -------------------------------------------------- Fig. 10 localization
def fig_localization(om):
    m = [shell_metrics(x, o, BASE) for x, o in zip(XI, om)]
    R = np.array([q["Rcb"] for q in m])
    kp2 = core.r32*(core.Omega_p**2 - om**2)/core.s2_s0
    Rpred = rcb_free_shell(np.sqrt(XI**2 + kp2), core.beta)
    i = np.where(R < 1)[0][0]
    xt = brentq(lambda x: np.interp(x, XI, R) - 1, XI[i-1], XI[i])
    RES["xi_trans_interp"] = xt
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 4))
    a1.plot(XI, R, "b-", lw=2, label=r"$R_{cb}=|u_\theta(c)|/|u_\theta(b^+)|$")
    a1.plot(XI[::8], Rpred[::8], "ko", ms=3, mfc="none", label="Traction-free shell prediction")
    a1.axhline(1, color="r", ls="--", lw=1); a1.axvline(xt, color="0.5", ls=":", lw=1)
    a1.text(xt + 0.08, 1.3, rf"$\xi_{{\rm trans}}={xt:.3f}$")
    a1.set_xlim(0, 6); a1.set_ylim(0, 1.6); a1.set_xlabel(r"$\xi$"); a1.set_ylabel(r"$R_{cb}$")
    a1.set_title("(a)", loc="left"); a1.grid(ls=":", alpha=.6); a1.legend(loc="upper right")
    a2.plot(XI, [q["Jb"] for q in m], "r-", lw=2, label=r"$J_b$ (interface $r=b$)")
    a2.plot(XI, [q["Ja"] for q in m], "b--", lw=2, label=r"$J_a$ (interface $r=a$)")
    a2.set_xlim(0, 6); a2.set_ylim(0, 50); a2.set_xlabel(r"$\xi$"); a2.set_ylabel("Displacement jump (%)")
    a2.set_title("(b)", loc="left"); a2.grid(ls=":", alpha=.6); a2.legend(loc="upper left")
    fig.tight_layout(); fig.savefig(OUT/"fig_localization_transition.png"); plt.close(fig)


# -------------------------------------------------- Fig. 13 velocities
def fig_velocities(om):
    vg1 = np.array([d_dxi(x, o, BASE) for x, o in zip(XI, om)])*core.v2
    xs = np.linspace(0.05, 6, 120)
    o2 = np.array([lower_root(x, BASE) for x in xs])
    vg2 = np.array([d_dxi(x, o, BASE) for x, o in zip(xs, o2)])*core.v2
    RES["vg1_end"] = [vg1[0], vg1[-1]]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 4))
    a1.semilogy(XI, core.v2*om/XI, "b-", lw=2, label="Branch 1")
    a1.semilogy(xs, core.v2*o2/xs, "--", color="tab:orange", lw=2, label="Branch 2")
    a1.axhline(core.v2, color="g", ls=":", lw=1, label=r"$v_2$")
    a1.set_xlim(0, 6); a1.set_ylim(0.2, 2000); a1.set_xlabel(r"$\xi$"); a1.set_ylabel(r"$v_p$ (m/s)")
    a1.set_title("(a)", loc="left"); a1.grid(ls=":", alpha=.6, which="both"); a1.legend(loc="lower right", bbox_to_anchor=(1.0, 0.22))
    a2.plot(XI, vg1, "b-", lw=2, label="Branch 1")
    a2.plot(xs, vg2, "--", color="tab:orange", lw=2, label="Branch 2")
    a2.axhline(0, color="k", lw=.6)
    ins = a2.inset_axes([0.42, 0.42, 0.53, 0.45])
    ins.plot(XI, vg1, "b-", lw=1.5); ins.axhline(0, color="k", lw=.6)
    ins.set_xlim(0.6, 6); ins.set_ylim(-16, 6); ins.tick_params(labelsize=7); ins.grid(ls=":", alpha=.6)
    a2.set_xlim(0, 6); a2.set_xlabel(r"$\xi$"); a2.set_ylabel(r"$v_g$ (m/s)")
    a2.set_title("(b)", loc="left"); a2.grid(ls=":", alpha=.6); a2.legend(loc="lower left")
    fig.tight_layout(); fig.savefig(OUT/"fig_velocities_journal.png"); plt.close(fig)


# -------------------------------------------------- Fig. 14 surface sensitivity
def fig_sensing():
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 4))
    out = {}
    for m in [0.1, 0.3, 0.7, 1.2]:
        p = dict(BASE, mus=m); om = branch(p)
        S = np.array([d_dmus(x, o, p) if np.isfinite(o) else np.nan for x, o in zip(XI, om)])
        a1.plot(XI, S, lw=1.8, label=rf"$\mu_s^*={m:g}$")
        a2.plot(XI, m*S/om, lw=1.8, label=rf"$\mu_s^*={m:g}$")
        out[m] = [S[-1], m*S[-1]/om[-1]]
    RES["Srel_xi6"] = out
    a1.set_ylabel(r"$S_{\rm surface}=\partial\Omega/\partial\mu_s^*$"); a2.set_ylabel(r"$S_{\rm rel}$")
    for a, t in [(a1, "(a)"), (a2, "(b)")]:
        a.set_xlim(0, 6); a.set_xlabel(r"$\xi$"); a.set_title(t, loc="left"); a.grid(ls=":", alpha=.6)
        a.legend(loc="lower right")
    fig.tight_layout(); fig.savefig(OUT/"fig_sensing_framework.png"); plt.close(fig)


# -------------------------------------------------- Fig. 15 OAT matrix
def fig_oat():
    def Q(p):
        om = branch(p)[-1]; s = shell_metrics(6.0, om, p)
        return np.array([om, s["L"], s["Rcb"]])
    rows = []
    for key in ["mus", "ka", "kb"]:
        lo, hi = dict(BASE), dict(BASE); lo[key] *= 0.5; hi[key] *= 2
        rows.append((np.log(Q(hi)) - np.log(Q(lo)))/np.log(4))
    S = np.array(rows); RES["OAT"] = S.tolist()
    fig, ax = plt.subplots(figsize=(5.2, 3.2))
    im = ax.imshow(S, cmap="coolwarm", vmin=-0.65, vmax=0.65)
    for i in range(3):
        for j in range(3):
            ax.text(j, i, f"{round(S[i, j], 4) + 0.0:+.4f}".replace("+0.0000", "0.0000").replace("-0.0000", "0.0000"), ha="center", va="center", fontsize=9)
    ax.set_xticks(range(3), [r"$\Omega(6)$", r"$L(6)$", r"$R_{cb}(6)$"])
    ax.set_yticks(range(3), [r"$\mu_s^*$", r"$k_a^*$", r"$k_b^*$"])
    fig.colorbar(im, ax=ax, label=r"$S_{i,Q}$")
    fig.tight_layout(); fig.savefig(OUT/"fig_sensitivity_journal.png"); plt.close(fig)


if __name__ == "__main__":
    om = fig_dispersion()
    fig_localization(om); fig_velocities(om); fig_sensing(); fig_oat()
    fig_parametric(); fig_surface()
    (OUT/"results_figures.json").write_text(json.dumps(RES, indent=1, default=float))
    print(json.dumps(RES, indent=1, default=float))
