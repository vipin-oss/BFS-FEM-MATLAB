#!/usr/bin/env python3
"""Verification computations and figures (Figs. 2-4 of the manuscript).

Uses only the characteristic-matrix functions of ``core`` plus independent
reduced models:
  * the two-medium cylindrical dispersion equation of Kielczynski et al.
    (Sensors 25:143, 2025, Eq. 14);
  * the welded-interface limit (displacement and traction continuity);
  * the semi-infinite-shell limit (K_1 only in the shell);
  * the planar SH interface wave across a spring interface (large-xi limit).

Usage:  python verification.py [output_dir]
Writes fig_validation_benchmark.png, fig_validation_limits.png,
fig_convergence_residuals.png and verification_results.json.
"""
import json
import sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.optimize import brentq
from scipy.special import iv, kv, ive, kve

import core

OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / "output"
OUT.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.size": 10, "axes.labelsize": 10, "legend.fontsize": 8,
                     "axes.titlesize": 10, "savefig.dpi": 300, "savefig.bbox": "tight"})
BASE = dict(ka=5.0, kb=5.0, mus=1e-5)
RES = {}


# ----------------------------------------------------------------- helpers
def det(xi, om, p):
    return core.Dfun(xi, om, p["ka"], p["kb"], p["mus"], 0.0)


def sign_roots(fun, grid):
    v = np.array([fun(x) for x in grid])
    out = []
    for i in range(len(grid) - 1):
        if np.isfinite(v[i]) and np.isfinite(v[i + 1]) and np.signbit(v[i]) != np.signbit(v[i + 1]):
            try:
                out.append(brentq(fun, grid[i], grid[i + 1], xtol=1e-15, rtol=1e-15))
            except ValueError:  # bracket straddles a pole (NaN inside)
                pass
    return sorted(out, reverse=True)


def omega_grid(xi, lo=1e-6, n=4000):
    return np.unique(np.concatenate([np.geomspace(lo, 0.9999 * xi, n // 2),
                                     np.linspace(lo, 0.9999 * xi, n // 2)]))


def upper_root(xi, p):
    r = sign_roots(lambda o: det(xi, o, p), omega_grid(xi))
    return r[0] if (len(r) >= 2 or (r and r[0] / xi > 0.2)) else np.nan


def gam(xi, om):
    g = core.gammas2(xi, om, 0, 0, 0, 0)
    return None if g is None else (np.sqrt(g[0]), np.sqrt(g[1]), np.sqrt(g[2]), g[3])


def reduced_det(kind, xi, om, p=BASE):
    g = gam(xi, om)
    if g is None:
        return np.nan
    g1, g2, g3, m3 = g
    a, b, mus = core.alpha, core.beta, p["mus"]
    if kind == "welded":
        M = np.array([
            [iv(1, a*g1), -iv(1, a*g2), -kv(1, a*g2), 0, 0],
            [core.m1*g1*iv(2, a*g1), -g2*iv(2, a*g2), g2*kv(2, a*g2), 0, 0],
            [0, iv(1, g2), kv(1, g2), -iv(1, g3), -kv(1, g3)],
            [0, g2*iv(2, g2), -g2*kv(2, g2), -m3*g3*iv(2, g3), m3*g3*kv(2, g3)],
            [0, 0, 0, m3*g3*iv(2, b*g3) + mus*xi*xi*iv(1, b*g3),
             -m3*g3*kv(2, b*g3) + mus*xi*xi*kv(1, b*g3)]])
    elif kind == "semi":
        ka, kb = p["ka"], p["kb"]
        M = np.array([
            [core.m1*g1*iv(2, a*g1), -g2*iv(2, a*g2), g2*kv(2, a*g2), 0],
            [core.m1*g1*iv(2, a*g1) + ka*iv(1, a*g1), -ka*iv(1, a*g2), -ka*kv(1, a*g2), 0],
            [0, g2*iv(2, g2), -g2*kv(2, g2), m3*g3*kv(2, g3)],
            [0, g2*iv(2, g2) + kb*iv(1, g2), -g2*kv(2, g2) + kb*kv(1, g2), -kb*kv(1, g3)]])
    elif kind == "planar_spring":
        return g2 + m3*g3 + m3*g2*g3/p["kb"]
    M = M / np.max(np.abs(M), axis=1)[:, None]
    return np.linalg.det(M)


def reduced_upper(kind, xi, p=BASE, om_max=None):
    om_max = om_max or 0.9999 * xi
    grid = np.linspace(1e-4, min(om_max, 0.9999*xi), 3000)
    r = [x for x in sign_roots(lambda o: reduced_det(kind, xi, o, p), grid)
         if abs(x - core.Omega_p) > 1e-3]
    return r[0] if r else np.nan


def dOm_dxi(xi, om, p, h=1e-7):
    D = lambda x, o: np.linalg.det(core.Mmat_stable(x, o, p["ka"], p["kb"], p["mus"], 0.0))
    return -((D(xi + h, om) - D(xi - h, om)) / (2*h)) / ((D(xi, om*(1 + h)) - D(xi, om*(1 - h))) / (2*h*om))


def bc_residual(xi, om, p, h=1e-6):
    """Relative residual of the five BCs, evaluated by finite differences of
    the reconstructed displacement field (independent of the row algebra)."""
    M = core.Mmat(xi, om, p["ka"], p["kb"], p["mus"], 0.0)
    X = np.linalg.svd(M)[2][-1]
    g1, g2, g3, m3 = gam(xi, om)
    a, b = core.alpha, core.beta
    u1 = lambda r: X[0]*iv(1, g1*r)
    u2 = lambda r: X[1]*iv(1, g2*r) + X[2]*kv(1, g2*r)
    u3 = lambda r: X[3]*iv(1, g3*r) + X[4]*kv(1, g3*r)
    sig = lambda u, r, mod: mod*r*((u(r + h)/(r + h) - u(r - h)/(r - h))/(2*h))
    s1a, s2a, s2b, s3b, s3c = sig(u1, a, core.m1), sig(u2, a, 1.0), sig(u2, 1.0, 1.0), sig(u3, 1.0, m3), sig(u3, b, m3)
    res = [s1a - s2a, s1a - p["ka"]*(u2(a) - u1(a)), s2b - s3b,
           s2b - p["kb"]*(u3(1.0) - u2(1.0)), s3c + p["mus"]*xi*xi*u3(b)]
    scale = max(abs(s1a), abs(s2b), abs(s3c), abs(u3(b)), abs(u2(1.0)))
    nres = np.linalg.norm(M @ X) / np.linalg.norm(M, "fro")
    return float(np.max(np.abs(res)) / scale), float(nres)


# ------------------------------------------------ Fig. 2: two-medium benchmark
KP = dict(a=0.01, rho1=2650.0, s0=1.474e-11, wp=2*np.pi*1.0e6, rho2=1180.0, s2=70.03e-11)
V2K = 1/np.sqrt(KP["rho2"]*KP["s2"])


def kiel(w, k):
    s1 = KP["s0"]*(1 - (KP["wp"]/w)**2)
    q1, q2 = k*k - KP["rho1"]*w*w*s1, k*k - KP["rho2"]*w*w*KP["s2"]
    if q1 <= 0 or q2 <= 0 or s1 >= 0:
        return np.nan
    g1, g2, a = np.sqrt(q1), np.sqrt(q2), KP["a"]
    return kve(2, g2*a)/kve(1, g2*a) + (KP["s2"]/s1)*(g1/g2)*ive(2, g1*a)/ive(1, g1*a)


def kiel_k(f_khz):
    w = 2*np.pi*f_khz*1e3
    ks = np.geomspace(w/V2K*(1 + 1e-13), 8e4, 20000)
    r = sign_roots(lambda k: kiel(w, k), ks)
    return r[-1] if r else np.nan


def kiel_f(k):
    r = sign_roots(lambda f: kiel(2*np.pi*f*1e3, k), np.linspace(1.0, 149.9, 3000))
    return r[0] if r else np.nan


def kiel_vg(f_khz, h=1e-6):
    w, k = 2*np.pi*f_khz*1e3, kiel_k(f_khz)
    Fk = (kiel(w, k*(1 + h)) - kiel(w, k*(1 - h)))/(2*h*k)
    Fw = (kiel(w*(1 + h), k) - kiel(w*(1 - h), k))/(2*h*w)
    return -Fk/Fw


def benchmark():
    f_lo = brentq(lambda f: 1.0 if np.isnan(kiel_k(f)) else -1.0, 55.0, 65.0, xtol=1e-3)
    kmax = brentq(lambda k: (kiel_f(k*1.0001) - kiel_f(k*0.9999)), 5000, 10000, xtol=1e-3)
    fmax = kiel_f(kmax)
    fpl = KP["wp"]/np.sqrt(1 + KP["s2"]/KP["s0"])/(2*np.pi*1e3)
    rows = []
    for f in [75, 80, 90, 100, 110, 120, 130, 140, 144]:
        k = kiel_k(f); w = 2*np.pi*f*1e3
        rows.append([f, w/1e5, k, w/k, kiel_vg(f), w/k/V2K])
    RES["benchmark"] = dict(f_lower_khz=f_lo, k_fmax=kmax, f_max_khz=fmax, f_planar_khz=fpl,
                            f_at_k_1e5=kiel_f(1e5), table=rows, v2=V2K)
    kk = np.concatenate([np.geomspace(348.6, 2e4, 260)])
    ff = np.array([kiel_f(k) for k in kk])
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 4))
    a1.plot(kk, ff, "b-", lw=2, label="Two-medium model, Eq. (14) of [45]")
    a1.plot(kk, V2K*kk/(2*np.pi*1e3), "g--", lw=1, label=r"Bulk shear line of PMMA")
    a1.axhline(fmax, color="r", ls="--", lw=1, label=rf"Computed $f_{{\max}}={fmax:.2f}$ kHz")
    a1.axhline(146.0, color="0.4", ls=":", lw=1.2, label=r"Reported $f_{\max}\approx146$ kHz [45]")
    a1.axhline(fpl, color="k", ls="-.", lw=1, label=rf"Planar limit $f_{{\rm res}}={fpl:.2f}$ kHz")
    a1.set_xscale("log"); a1.set_xlim(300, 2e4); a1.set_ylim(55, 150)
    a1.set_xlabel(r"Wavenumber $k$ (rad/m)"); a1.set_ylabel(r"Frequency $f$ (kHz)")
    a1.set_title("(a)", loc="left"); a1.grid(ls=":", alpha=.6); a1.legend(loc="lower right")
    fr = np.linspace(f_lo + 0.05, fmax - 0.02, 220)
    kr = np.array([kiel_k(f) for f in fr]); vg = np.array([kiel_vg(f) for f in fr])
    a2.plot(fr, 2*np.pi*fr*1e3/kr, "b-", lw=2, label=r"Phase velocity $v_p$")
    a2.plot(fr, vg, "r--", lw=2, label=r"Group velocity $v_g$")
    a2.axhline(V2K, color="g", ls=":", lw=1, label=rf"$v_2={V2K:.1f}$ m/s")
    a2.set_xlim(55, 150); a2.set_ylim(0, 1200)
    a2.set_xlabel(r"Frequency $f$ (kHz)"); a2.set_ylabel("Velocity (m/s)")
    a2.set_title("(b)", loc="left"); a2.grid(ls=":", alpha=.6); a2.legend(loc="upper right")
    fig.tight_layout(); fig.savefig(OUT/"fig_validation_benchmark.png"); plt.close(fig)


# --------------------------------------------------- Fig. 3: limiting cases
def limits():
    xs = np.linspace(0.05, 6.0, 120)
    fig, ax = plt.subplots(1, 3, figsize=(13.5, 4))
    out = {}
    for bb, st in [(1.5, "-"), (2.0, "--"), (3.0, "-."), (5.0, ":")]:
        core.beta = bb
        y = [upper_root(x, BASE) for x in xs]
        ax[0].plot(xs, y, st, lw=1.6, label=rf"$\beta={bb:g}$")
        out[f"beta{bb}_Om6"] = y[-1]
    core.beta = 1.5
    ys = [reduced_upper("semi", x) for x in xs]
    ax[0].plot(xs, ys, "ko", ms=2.5, label="Semi-infinite shell (independent)")
    out["semi_Om6"] = ys[-1]
    for kk, st in [(5, "-"), (100, "--"), (1e3, "-."), (1e4, ":")]:
        p = dict(BASE, ka=kk, kb=kk)
        y = [upper_root(x, p) for x in xs]
        ax[1].plot(xs, y, st, lw=1.6, label=rf"$k_a^*=k_b^*={kk:g}$")
        out[f"k{kk:g}_Om6"] = y[-1]
    yw = [reduced_upper("welded", x) for x in xs]
    ax[1].plot(xs, yw, "ko", ms=2.5, label="Welded interfaces (independent)")
    out["welded_Om6"] = yw[-1]
    xl = np.geomspace(1, 100, 40)
    y5 = [sign_roots(lambda o: det(x, o, BASE), np.linspace(1e-3, min(0.9999*x, 1.99), 3000))[0] for x in xl]
    yp = [reduced_upper("planar_spring", x, om_max=1.99) for x in xl]
    ax[2].plot(xl, y5, "b-", lw=1.8, label="Three-layer cylinder (baseline)")
    ax[2].plot(xl, yp, "ko", ms=2.5, label="Planar spring interface (independent)")
    ax[2].set_xscale("log")
    out["large_xi"] = {f"{x:.3g}": [a, b] for x, a, b in zip(xl[::6], y5[::6], yp[::6])}
    for x in (20.0, 80.0):
        out[f"xi{x:g}"] = [sign_roots(lambda o: det(x, o, BASE), np.linspace(1e-3, 1.99, 3000))[0],
                           reduced_upper("planar_spring", x, om_max=1.99)]
    for i, (a, t) in enumerate(zip(ax, ["(a) Shell thickness", "(b) Interface stiffness", "(c) Large wavenumber"])):
        a.set_xlabel(r"$\xi=kb$"); a.set_ylabel(r"$\Omega$"); a.grid(ls=":", alpha=.6)
        a.set_title(t, loc="left"); a.legend(loc="lower right" if i < 2 else "upper right")
    ax[0].set_xlim(0, 6); ax[1].set_xlim(0, 6); ax[0].set_ylim(0, 0.2); ax[1].set_ylim(0, 0.25)
    fig.tight_layout(); fig.savefig(OUT/"fig_validation_limits.png"); plt.close(fig)
    RES["limits"] = out


# ------------------------------------------ Fig. 4: accuracy of computed roots
def accuracy():
    xs = np.linspace(0.05, 6.0, 300)
    om = np.array([upper_root(x, BASE) for x in xs])
    bc, nr = zip(*[bc_residual(x, o, BASE) for x, o in zip(xs, om)])
    vgi = np.array([dOm_dxi(x, o, BASE) for x, o in zip(xs, om)])*core.v2
    vgs = np.gradient(om, xs)*core.v2
    RES["accuracy"] = dict(bc_max=max(bc), nres_range=[min(nr), max(nr)],
                           vg_endpoint=[vgi[0], vgs[0], vgi[-1], vgs[-1]])
    np.savez(OUT/"baseline_branch.npz", xi=xs, Omega=om, vg_implicit=vgi)
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(10, 4))
    a1.semilogy(xs, bc, "b-", lw=1.5, label="Boundary conditions (field reconstruction)")
    a1.semilogy(xs, nr, "g-", lw=1.2, label=r"$\|\mathbf{M}\mathbf{X}\|_2/\|\mathbf{M}\|_F$")
    a1.set_xlabel(r"$\xi$"); a1.set_ylabel("Relative residual"); a1.set_xlim(0, 6)
    a1.set_title("(a)", loc="left"); a1.grid(ls=":", alpha=.6); a1.legend(loc="lower left")
    a2.plot(xs, vgi, "b-", lw=1.8, label="Implicit differentiation")
    a2.plot(xs[::6], vgs[::6], "ro", ms=3, mfc="none", label="Difference quotient of sampled branch")
    a2.axhline(0, color="k", lw=.6); a2.set_xlim(0, 6)
    a2.set_xlabel(r"$\xi$"); a2.set_ylabel(r"$v_g$ (m/s)"); a2.set_title("(b)", loc="left")
    a2.grid(ls=":", alpha=.6); a2.legend(loc="upper right")
    fig.tight_layout(); fig.savefig(OUT/"fig_convergence_residuals.png"); plt.close(fig)


if __name__ == "__main__":
    benchmark(); limits(); accuracy()
    (OUT/"verification_results.json").write_text(json.dumps(RES, indent=1, default=float))
    print(json.dumps(RES, indent=1, default=float))
