#!/usr/bin/env python3
"""Fast regression checks against values reported in the manuscript."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src" / "python"))
import numpy as np
import core
import verification as V

r = core.find_roots_at_xi(6.0, 5.0, 5.0, 1e-5, 0.0)
assert abs(r[0] - 0.162911) < 1e-6, r            # Table 5, Branch 1, xi = 6
assert abs(r[1] - 0.0024437) < 1e-6, r           # Table 5, Branch 2, xi = 6
assert abs(V.kiel_f(7291.9) - 145.02) < 0.01     # Sec. 6.1, f_max of two-medium model
bc, nres = V.bc_residual(6.0, r[0], V.BASE)
assert bc < 1e-7 and nres < 1e-12, (bc, nres)
print("REGRESSION_PASS", r[:2])
