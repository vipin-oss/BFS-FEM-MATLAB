# Computed data

| File | Content |
|---|---|
| `baseline_branch.npz` | Branch 1 for the baseline parameters: `xi`, `Omega`, `vg_implicit` (dimensionless dΩ/dξ × v₂ in m/s), 300 points on 0.05 ≤ ξ ≤ 6 |
| `verification_results.json` | Two-medium model of Kiełczyński et al. (2025) (f_max, planar limit, table of k, v_p, v_g), limiting cases, boundary-condition residuals |
| `results_figures.json` | Transition wavenumber, group velocities, relative surface sensitivities, one-at-a-time sensitivity matrix |
| `parametric_figures.json` | Ω(ξ = 6) for the shell-thickness and core-radius variations |
| `parametric_summary.json` | Values of the parametric summary table (ξ_on, Ω(6), v_p(6), ξ_tr, J_b(6)) and parameter sweeps |

All files are produced by the code in `../code` (`python run_all.py`).
