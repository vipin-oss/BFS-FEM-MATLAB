# Torsional Surface Waves in a Cylindrical Waveguide — Overleaf package

Self-contained package for the manuscript *"Torsional Surface Waves in a Cylindrical
Waveguide with Thermoelastic Core, Elastic Metamaterial Shell, and Gurtin–Murdoch
Surface Elasticity: Dispersion, Decoupling, and Sensing Analysis"* (Annu Rani, M. S. Barak).

## Contents

```
TorsionalWaveguide.tex      Main manuscript (Springer sn-jnl, sn-mathphys-num numbered style)
references.bib              Bibliography (BibTeX)
sn-jnl.cls, sn-*.bst        Springer Nature class + bibliography styles (bundled for portability)
figures/                    All 15 manuscript figures (PNG)
program/                    Reference solver + figure generators (Python & MATLAB)
  run_all.py / run_all.m    Top-level runners
  requirements.txt          Python dependencies (numpy, scipy, matplotlib)
  config/                   Numerical settings
  src/python, src/matlab    Core solvers
  scripts/python, scripts/matlab   Figure/analysis scripts
  tests/                    Regression & integrity tests
  utils/                    Helper utilities
```

## Compiling the manuscript

**On Overleaf:** set the main document to `TorsionalWaveguide.tex` and compile with
pdfLaTeX. (Overleaf's TeX Live includes `sn-jnl`; the bundled `.cls`/`.bst` are used as a
fallback.)

**Locally (TeX Live):**
```
pdflatex TorsionalWaveguide
bibtex   TorsionalWaveguide
pdflatex TorsionalWaveguide
pdflatex TorsionalWaveguide
```
If `sn-jnl` is not installed, the bundled `sn-jnl.cls` and `sn-*.bst` are used automatically
(compile in this directory).

## Running the reference program

Python (reference solver + figures):
```
cd program
pip install -r requirements.txt
python run_all.py
```
MATLAB mirror:
```
cd program
run_all
```
Generated figures are written under `03_DATA/generated/` (created on first run) and can be
promoted to `figures/` with `scripts/python/sync_outputs.py`. The manuscript figures in
`figures/` are the versions used in the paper.

## Notes
- The manuscript text contains no internal file paths; code paths are archive-relative and
  portable (override output locations with the `TORSIONAL_OUT` / `TORSIONAL_DATA` env vars).
- Python 3.11+, NumPy 2.x, SciPy 1.x, Matplotlib 3.x (or newer) recommended.
