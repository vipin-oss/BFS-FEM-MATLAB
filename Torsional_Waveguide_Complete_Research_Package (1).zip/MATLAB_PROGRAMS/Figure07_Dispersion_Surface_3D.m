%% =========================================================================
% FIGURE 07: 3D DISPERSION SURFACE OMEGA(xi, G)
% =========================================================================
% Manuscript Reference: Figure 7 (Section 4.4)
%
% Physical Phenomenon:
%   Generates a full 3D surface representation of the dispersion relation
%   as a simultaneous function of axial wavenumber xi and Gurtin-Murdoch
%   surface elasticity G = (mu_s* + tau_0*):
%     Omega = Omega(xi, G)
%
% Output: Generates EXACT Figure 7 (fig_surface_journal.png)
% =========================================================================

close all; clc;

fprintf('=================================================================\n');
fprintf('  REPRODUCING FIGURE 07: 3D DISPERSION SURFACE                   \n');
fprintf('=================================================================\n\n');

p_base = torsional_waveguide_core.get_default_parameters();
p_base.ka_star = 5.0;
p_base.kb_star = 5.0;

xi_grid = linspace(0.1, 6.0, 30);
G_vals  = linspace(0.0, 2.0, 20);

fprintf('Computing 2D mesh of eigenvalues Omega(xi, G)...\n');
Z_surface = NaN(length(G_vals), length(xi_grid));

for i = 1:length(G_vals)
    G = G_vals(i);
    p = p_base;
    p.mus_star = G * 0.7;
    p.tau0_star = G * 0.3;
    
    [~, om_b] = torsional_waveguide_core.track_branch_continuation(xi_grid, p, 1);
    Z_surface(i, :) = om_b;
end

%% Plot EXACT Figure 7 (matching 3D view and coloring)
fig = figure('Name', 'Figure 07 - 3D Dispersion Surface', 'Color', 'w', ...
             'Position', [150, 150, 640, 520]);

[X_mesh, G_mesh] = meshgrid(xi_grid, G_vals);

surf(X_mesh, G_mesh, Z_surface, 'EdgeColor', [0.25 0.25 0.25], 'LineWidth', 0.25);
shading interp;
colormap(parula(256));
view(42, 28);

cb = colorbar;
ylabel(cb, '\Omega', 'FontSize', 11, 'FontWeight', 'bold');

xlabel('\xi = kb', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('\mu_s^* + \tau_0^*', 'FontSize', 11, 'FontWeight', 'bold');
zlabel('\Omega', 'FontSize', 11, 'FontWeight', 'bold');
xlim([0, 6]);
ylim([0, 2]);
zlim([0, 1.0]);
grid on; box on;

saveas(fig, 'fig_surface_journal.png');
fprintf('Saved figure as: fig_surface_journal.png\n');
