%% =========================================================================
% FIGURE 08: COMBINED PARAMETRIC SWEEPS (SURFACE ELASTICITY & SPRINGS)
% =========================================================================
% Manuscript Reference: Figure 8 (Section 4.5)
%
% Physical Phenomena:
%   - Panel (a): Influence of Gurtin-Murdoch surface elasticity parameter
%     G = (mu_s* + tau_0*) in {0, 0.2, 0.5, 1, 2} at fixed ka* = kb* = 5.
%     Shows upward shift of dispersion branches due to surface stiffening.
%   - Panel (b): Influence of imperfect spring stiffness k* = ka* = kb*
%     in {0.5, 2, 5, 20, 100} at fixed G = 0.7.
%     Shows that compliant interfaces reduce cutoffs and confine waves.
%
% Output: Generates EXACT Figure 8 (fig_parametric_journal.png)
% =========================================================================

close all; clc;

fprintf('=================================================================\n');
fprintf('  REPRODUCING FIGURE 08: COMBINED PARAMETRIC SWEEPS              \n');
fprintf('=================================================================\n\n');

p_base = torsional_waveguide_core.get_default_parameters();
xi_vals = linspace(0.1, 6.0, 60);

colors = {[0 0.447 0.741], [0.85 0.325 0.098], [0.466 0.674 0.188], ...
          [0.929 0.694 0.125], [0.494 0.184 0.556]};

fig = figure('Name', 'Figure 08 - Parametric Sweeps', 'Color', 'w', ...
             'Position', [100, 100, 950, 420]);

%% --- Subplot (a): Surface Elasticity Sweep ---
subplot(1, 2, 1);
hold on;
plot([0, 6], [p_base.Omega_p, p_base.Omega_p], 'r:', 'LineWidth', 1.3, 'DisplayName', '\Omega_p (cutoff)');

surf_vals = [0.0, 0.2, 0.5, 1.0, 2.0];
fprintf('Panel (a): Tracking branches for G in {0, 0.2, 0.5, 1, 2}...\n');
for i = 1:length(surf_vals)
    G = surf_vals(i);
    p = p_base;
    p.mus_star = G * 0.7;
    p.tau0_star = G * 0.3;
    [~, om] = torsional_waveguide_core.track_branch_continuation(xi_vals, p, 1);
    
    plot(xi_vals, om, 'LineWidth', 1.8, 'Color', colors{i}, ...
         'DisplayName', sprintf('\\mu_s^* + \\tau_0^* = %g', G));
end

xlabel('\xi = kb', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('\Omega', 'FontSize', 11, 'FontWeight', 'bold');
title('(a) surface elasticity \mu_s^* + \tau_0^*', 'FontSize', 11, 'FontWeight', 'bold');
legend('Location', 'northwest', 'FontSize', 8.5);
grid on; box on;
xlim([0, 6]);
ylim([0, 2.6]);

%% --- Subplot (b): Spring Stiffness Sweep ---
subplot(1, 2, 2);
hold on;
plot([0, 6], [p_base.Omega_p, p_base.Omega_p], 'r:', 'LineWidth', 1.3, 'DisplayName', '\Omega_p (cutoff)');

k_vals = [0.5, 2.0, 5.0, 20.0, 100.0];
fprintf('Panel (b): Tracking branches for k* in {0.5, 2, 5, 20, 100}...\n');
for i = 1:length(k_vals)
    k = k_vals(i);
    p = p_base;
    p.mus_star = 0.5;
    p.tau0_star = 0.2;
    p.ka_star = k;
    p.kb_star = k;
    [~, om] = torsional_waveguide_core.track_branch_continuation(xi_vals, p, 1);
    
    plot(xi_vals, om, 'LineWidth', 1.8, 'Color', colors{i}, ...
         'DisplayName', sprintf('k_a^* = k_b^* = %g', k));
end

xlabel('\xi = kb', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('\Omega', 'FontSize', 11, 'FontWeight', 'bold');
title('(b) spring stiffness k_a^* = k_b^*', 'FontSize', 11, 'FontWeight', 'bold');
legend('Location', 'northwest', 'FontSize', 8.5);
grid on; box on;
xlim([0, 6]);
ylim([0, 2.6]);

saveas(fig, 'fig_parametric_journal.png');
fprintf('Saved figure as: fig_parametric_journal.png\n');
