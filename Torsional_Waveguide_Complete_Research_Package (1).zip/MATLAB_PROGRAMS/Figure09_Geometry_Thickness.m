%% =========================================================================
% FIGURE 09: GEOMETRIC SENSITIVITY: SHELL THICKNESS AND CORE RADIUS
% =========================================================================
% Manuscript Reference: Figure 9 (Section 4.5)
%
% Physical Problem:
%   Analyzes the influence of geometric proportions on torsional wave speed:
%     - Panel (a): Metamaterial shell thickness ratio beta = c/b in {1.15, 1.30, 1.50, 2.00}
%       showing that thicker metamaterial shells reduce the asymptotic plateau.
%     - Panel (b): Metallic core radius ratio alpha = a/b in {0.20, 0.50, 0.80}
%       showing the influence of core mass and inertia.
%
% Output: Generates EXACT Figure 9 (fig_geometry_thickness.png)
% =========================================================================

close all; clc;

fprintf('=================================================================\n');
fprintf('  REPRODUCING FIGURE 09: GEOMETRY & SHELL THICKNESS EFFECTS       \n');
fprintf('=================================================================\n\n');

p_base = torsional_waveguide_core.get_default_parameters();
xi_pts = linspace(0.2, 5.0, 40);

fig = figure('Name', 'Figure 09 - Geometric Sensitivity', 'Color', 'w', ...
             'Position', [100, 100, 950, 400]);

% --- Subplot (a): Metamaterial shell thickness beta = c/b ---
subplot(1, 2, 1);
hold on;
beta_vals = [1.15, 1.30, 1.50, 2.00];
colors_b = {[0 0.447 0.741], [0.85 0.325 0.098], [0.466 0.674 0.188], [0.494 0.184 0.556]};

fprintf('Panel (a): Sweeping shell thickness beta in {1.15, 1.30, 1.50, 2.00}...\n');
for i = 1:length(beta_vals)
    p = p_base;
    p.beta = beta_vals(i);
    p.c = p.beta * p.b;
    [~, om] = torsional_waveguide_core.track_branch_continuation(xi_pts, p, 1);
    
    d_pct = (p.beta - 1.0) * 100;
    plot(xi_pts, om, 'LineWidth', 1.8, 'Color', colors_b{i}, ...
         'DisplayName', sprintf('\\beta = c/b = %.2f (Shell d = %.0f%%b)', p.beta, d_pct));
end
xlabel('Dimensionless Wavenumber \xi', 'FontSize', 11);
ylabel('Dimensionless Frequency \Omega', 'FontSize', 11);
title('(a) Influence of Metamaterial Shell Thickness (\beta = c/b)', 'FontSize', 11, 'FontWeight', 'bold');
legend('Location', 'southeast', 'FontSize', 8.5);
grid on; box on;
xlim([0, 5]);
ylim([0, 0.22]);

% --- Subplot (b): Core radius ratio alpha = a/b ---
subplot(1, 2, 2);
hold on;
alpha_vals = [0.20, 0.50, 0.80];
colors_a = {[0 0.447 0.741], [0.85 0.325 0.098], [0.466 0.674 0.188]};

fprintf('Panel (b): Sweeping core ratio alpha in {0.20, 0.50, 0.80}...\n');
for i = 1:length(alpha_vals)
    p = p_base;
    p.alpha = alpha_vals(i);
    p.a = p.alpha * p.b;
    [~, om] = torsional_waveguide_core.track_branch_continuation(xi_pts, p, 1);
    
    plot(xi_pts, om, 'LineWidth', 1.8, 'Color', colors_a{i}, ...
         'DisplayName', sprintf('\\alpha = a/b = %.2f (Core radius)', p.alpha));
end
xlabel('Dimensionless Wavenumber \xi', 'FontSize', 11);
ylabel('Dimensionless Frequency \Omega', 'FontSize', 11);
title('(b) Influence of Core Radius Ratio (\alpha = a/b)', 'FontSize', 11, 'FontWeight', 'bold');
legend('Location', 'southeast', 'FontSize', 8.5);
grid on; box on;
xlim([0, 5]);
ylim([0, 0.22]);

sgtitle('Geometric Sensitivity: Metamaterial Shell Thickness and Core Radius', ...
        'FontSize', 12, 'FontWeight', 'bold');

saveas(fig, 'fig_geometry_thickness.png');
fprintf('Saved figure as: fig_geometry_thickness.png\n');
