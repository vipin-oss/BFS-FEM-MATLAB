%% =========================================================================
% FIGURE 10: OBJECTIVE WAVE LOCALIZATION METRICS & MODAL CROSSOVER
% =========================================================================
% Manuscript Reference: Figure 10 (Section 4.4)
%
% Physical Metrics Evaluated (FROM ZERO):
%   - Panel (a): Outer-to-inner amplitude ratio R_cb = |u_theta(c)| / |u_theta(b^+)|
%     demonstrating the modal transition across xi_trans ~ 1.45 from outer-surface
%     trapping (Regime 1, R_cb > 1) to internal interface guidance (Regime 3, R_cb < 1).
%   - Panel (b): Relative displacement discontinuities across spring interfaces:
%     Shear jump at r=b: [u_theta(b)] / max|u| * 100%
%     Shear jump at r=a: [u_theta(a)] / max|u| * 100%
%
% Output: Generates EXACT Figure 10 (fig_localization_transition.png)
% =========================================================================

close all; clc;

fprintf('=================================================================\n');
fprintf('  REPRODUCING FIGURE 10: OBJECTIVE WAVE LOCALIZATION METRICS     \n');
fprintf('=================================================================\n\n');

p = torsional_waveguide_core.get_default_parameters();
xi_vals = linspace(0.05, 6.0, 100);

fprintf('Tracking fundamental branch and computing localization metrics...\n');
[~, om_vals] = torsional_waveguide_core.track_branch_continuation(xi_vals, p, 1);

ratio_cb = NaN(size(xi_vals));
jump_b   = NaN(size(xi_vals));
jump_a   = NaN(size(xi_vals));

for i = 1:length(xi_vals)
    x = xi_vals(i);
    o = om_vals(i);
    if isnan(o), continue; end
    
    C = torsional_waveguide_core.solve_wave_field_constants(x, o, p);
    [g1, g2, g3, ~, ok] = torsional_waveguide_core.compute_wavenumbers(x, o, p);
    if ~ok, continue; end
    
    A1 = C(1); B2 = C(2); C2 = C(3); D3 = C(4); E3 = C(5);
    
    % Boundary displacements
    uc      = abs(D3 * besseli(1, g3 * p.beta) + E3 * besselk(1, g3 * p.beta));
    ub_plus = abs(D3 * besseli(1, g3 * 1.0)    + E3 * besselk(1, g3 * 1.0));
    ub_min  = abs(B2 * besseli(1, g2 * 1.0)    + C2 * besselk(1, g2 * 1.0));
    ua_plus = abs(B2 * besseli(1, g2 * p.alpha)+ C2 * besselk(1, g2 * p.alpha));
    ua_min  = abs(A1 * besseli(1, g1 * p.alpha));
    
    umax = max([uc, ub_plus, ub_min, ua_plus, ua_min]);
    
    ratio_cb(i) = uc / (ub_plus + 1e-18);
    jump_b(i)   = (abs(ub_plus - ub_min) / umax) * 100;
    jump_a(i)   = (abs(ua_plus - ua_min) / umax) * 100;
end

%% Plot EXACT Figure 10 (matching manuscript layout)
fig = figure('Name', 'Figure 10 - Localization Transition', 'Color', 'w', ...
             'Position', [100, 100, 950, 380]);

% --- Subplot (a): Outer-to-inner interface ratio |u(c)| / |u(b+)| ---
subplot(1, 2, 1);
hold on;

% Shaded regimes
patch([0, 1.45, 1.45, 0], [0, 0, 2.5, 2.5], [0.9 0.97 0.9], 'EdgeColor', 'none', ...
      'DisplayName', 'Regime 1: Outer-Surface Localized');
patch([1.45, 6.0, 6.0, 1.45], [0, 0, 2.5, 2.5], [1.0 0.95 0.88], 'EdgeColor', 'none', ...
      'DisplayName', 'Regime 3: Interface-Guided');

plot(xi_vals, ratio_cb, 'b-', 'LineWidth', 2.0, ...
     'DisplayName', 'Outer-to-inner interface ratio |u_\theta(c)| / |u_\theta(b^+)|');
plot([0, 6], [1.0, 1.0], 'r--', 'LineWidth', 1.4, ...
     'DisplayName', 'Crossover threshold = 1.0 (\xi_{trans} \approx 1.45)');

xlabel('Dimensionless Wavenumber \xi', 'FontSize', 11);
ylabel('Displacement Amplitude Ratio', 'FontSize', 11);
title('(a) Outer Surface Localization Metric vs Wavenumber', 'FontSize', 11, 'FontWeight', 'bold');
legend('Location', 'northeast', 'FontSize', 8.5);
grid on; box on;
xlim([0, 6]);
ylim([0, 2.5]);

% --- Subplot (b): Shear jump across springs ---
subplot(1, 2, 2);
plot(xi_vals, jump_b, 'r-', 'LineWidth', 2.0, ...
     'DisplayName', 'Shear jump across r=b ([u_\theta(b)]/max|u_\theta| \times 100%)');
hold on;
plot(xi_vals, jump_a, 'b--', 'LineWidth', 1.8, ...
     'DisplayName', 'Shear jump across r=a ([u_\theta(a)]/max|u_\theta| \times 100%)');

xlabel('Dimensionless Wavenumber \xi', 'FontSize', 11);
ylabel('Displacement Jump (% of peak amplitude)', 'FontSize', 11);
title('(b) Imperfect Interface Discontinuity Across Springs', 'FontSize', 11, 'FontWeight', 'bold');
legend('Location', 'east', 'FontSize', 8.5);
grid on; box on;
xlim([0, 6]);
ylim([0, 50]);

sgtitle('Objective Wave Localization Metrics and Modal Transition Crossover', ...
        'FontSize', 12, 'FontWeight', 'bold');

saveas(fig, 'fig_localization_transition.png');
fprintf('Saved figure as: fig_localization_transition.png\n');
