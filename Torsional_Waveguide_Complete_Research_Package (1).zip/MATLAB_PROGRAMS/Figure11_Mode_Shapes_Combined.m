%% =========================================================================
% FIGURE 11: RADIAL MODE SHAPES & INTERFACIAL DISPLACEMENT PROFILES
% =========================================================================
% Manuscript Reference: Figure 11 (Section 4.4)
%
% Physical Phenomena:
%   - Panel (a): Fundamental branch radial profile |u_theta(r)| at two
%     representative wavenumbers:
%       xi = 0.51 (long wavelength, field penetrates across all layers)
%       xi = 5.01 (short wavelength, field tightly confined near r=b+)
%   - Panel (b): Influence of interface spring stiffness at xi = 6.0:
%       k* = 0.5  (compliant interface isolates core completely)
%       k* = 100  (rigid interface allows smooth energy transfer)
%
% Output: Generates EXACT Figure 11 (fig_mode_shape_combined.png)
% =========================================================================

close all; clc;

fprintf('=================================================================\n');
fprintf('  REPRODUCING FIGURE 11: RADIAL MODE SHAPES & CONFINEMENT        \n');
fprintf('=================================================================\n\n');

p = torsional_waveguide_core.get_default_parameters();
a_mm = p.alpha * p.b * 1e3;  % ~0.175 mm
b_mm = 1.0 * p.b * 1e3;      % ~0.350 mm
c_mm = p.beta * p.b * 1e3;   % ~0.525 mm

fig = figure('Name', 'Figure 11 - Mode Shapes Combined', 'Color', 'w', ...
             'Position', [100, 100, 950, 420]);

%% Panel (a): Base case at xi = 0.51 and xi = 5.01
subplot(1, 2, 1);
hold on;
% Layer background color bands
patch([0, a_mm, a_mm, 0], [0, 0, 1.18, 1.18], [0.85 0.88 0.96], 'EdgeColor', 'none');
patch([a_mm, b_mm, b_mm, a_mm], [0, 0, 1.18, 1.18], [0.97 0.94 0.82], 'EdgeColor', 'none');
patch([b_mm, c_mm, c_mm, b_mm], [0, 0, 1.18, 1.18], [0.90 0.96 0.90], 'EdgeColor', 'none');

% Dashed boundary lines
plot([a_mm, a_mm], [0, 1.18], 'k--', 'LineWidth', 1.0);
plot([b_mm, b_mm], [0, 1.18], 'k--', 'LineWidth', 1.0);

fprintf('Solving mode profile for xi = 0.51...\n');
r_051 = torsional_waveguide_core.find_dispersion_roots(0.5077, p);
C_051 = torsional_waveguide_core.solve_wave_field_constants(0.5077, r_051(1), p);
[r_m, u_051, ~] = torsional_waveguide_core.compute_radial_profiles(0.5077, r_051(1), p, C_051, 600);
r_mm_axis = (r_m * p.b) * 1e3;
u_051_norm = abs(u_051) / max(abs(u_051));
plot(r_mm_axis, u_051_norm, 'Color', [0 0.447 0.741], 'LineWidth', 2.0, ...
     'DisplayName', '\xi = 0.51');

fprintf('Solving mode profile for xi = 5.01...\n');
r_501 = torsional_waveguide_core.find_dispersion_roots(5.005, p);
C_501 = torsional_waveguide_core.solve_wave_field_constants(5.005, r_501(1), p);
[~, u_501, ~] = torsional_waveguide_core.compute_radial_profiles(5.005, r_501(1), p, C_501, 600);
u_501_norm = abs(u_501) / max(abs(u_501));
plot(r_mm_axis, u_501_norm, 'Color', [0.85 0.325 0.098], 'LineWidth', 2.0, ...
     'DisplayName', '\xi = 5.01');

xlabel('r (mm)', 'FontSize', 11);
ylabel('|u_\theta| (normalized)', 'FontSize', 11);
title('(a) branch 1 (base case)', 'FontSize', 11, 'FontWeight', 'bold');
legend('Location', 'northwest', 'FontSize', 9);
xlim([0, c_mm]);
ylim([0, 1.18]);
box on;

%% Panel (b): k* sweep at xi = 6.0
subplot(1, 2, 2);
hold on;
% Layer background color bands
patch([0, a_mm, a_mm, 0], [0, 0, 1.18, 1.18], [0.85 0.88 0.96], 'EdgeColor', 'none');
patch([a_mm, b_mm, b_mm, a_mm], [0, 0, 1.18, 1.18], [0.97 0.94 0.82], 'EdgeColor', 'none');
patch([b_mm, c_mm, c_mm, b_mm], [0, 0, 1.18, 1.18], [0.90 0.96 0.90], 'EdgeColor', 'none');
plot([a_mm, a_mm], [0, 1.18], 'k--', 'LineWidth', 1.0);
plot([b_mm, b_mm], [0, 1.18], 'k--', 'LineWidth', 1.0);

% k* = 0.5 (compliant)
p_k05 = p; p_k05.mus_star = 0.5; p_k05.tau0_star = 0.2; p_k05.ka_star = 0.5; p_k05.kb_star = 0.5;
r_k05 = torsional_waveguide_core.find_dispersion_roots(6.0, p_k05);
C_k05 = torsional_waveguide_core.solve_wave_field_constants(6.0, r_k05(1), p_k05);
[~, u_k05, ~] = torsional_waveguide_core.compute_radial_profiles(6.0, r_k05(1), p_k05, C_k05, 600);
u_k05_norm = abs(u_k05) / max(abs(u_k05));
plot(r_mm_axis, u_k05_norm, 'Color', [0 0.447 0.741], 'LineWidth', 2.0);
idx_pts = 1:40:length(r_mm_axis);
plot(r_mm_axis(idx_pts), u_k05_norm(idx_pts), 'o', 'Color', [0 0.447 0.741], ...
     'MarkerFaceColor', 'w', 'MarkerSize', 6, 'LineWidth', 1.5, 'DisplayName', 'k^* = 0.5');

% k* = 100 (rigid)
p_k100 = p; p_k100.mus_star = 0.5; p_k100.tau0_star = 0.2; p_k100.ka_star = 100.0; p_k100.kb_star = 100.0;
r_k100 = torsional_waveguide_core.find_dispersion_roots(6.0, p_k100);
C_k100 = torsional_waveguide_core.solve_wave_field_constants(6.0, r_k100(1), p_k100);
[~, u_k100, ~] = torsional_waveguide_core.compute_radial_profiles(6.0, r_k100(1), p_k100, C_k100, 600);
u_k100_norm = abs(u_k100) / max(abs(u_k100));
plot(r_mm_axis, u_k100_norm, 'Color', [0.85 0.325 0.098], 'LineWidth', 2.0);
plot(r_mm_axis(idx_pts), u_k100_norm(idx_pts), 's', 'Color', [0.85 0.325 0.098], ...
     'MarkerFaceColor', 'w', 'MarkerSize', 6, 'LineWidth', 1.5, 'DisplayName', 'k^* = 100');

xlabel('r (mm)', 'FontSize', 11);
ylabel('|u_\theta| (normalized)', 'FontSize', 11);
title('(b) k^* sweep, \xi = 6', 'FontSize', 11, 'FontWeight', 'bold');
legend('Location', 'northwest', 'FontSize', 9);
xlim([0, c_mm]);
ylim([0, 1.18]);
box on;

saveas(fig, 'fig_mode_shape_combined.png');
fprintf('Saved figure as: fig_mode_shape_combined.png\n');
