%% =========================================================================
% FIGURE 12: 2D CROSS-SECTIONAL WAVE FIELD DISTRIBUTIONS Re[u_theta(r,z)]
% =========================================================================
% Manuscript Reference: Figure 12 (Section 4.4)
%
% Physical Phenomenon:
%   Visualizes the actual propagating wave field in the (r, z) plane:
%       u_theta(r, z) = Re{ u(r) * exp(i * xi * z/b) }
%   over exactly one axial wavelength z/b in [0, 2*pi/xi]:
%     - Panel (a): xi = 0.5077 (penetrating wave distributed across shell & core)
%     - Panel (b): xi = 5.0050 (tightly localized interface-guided wave at r=b)
%
% Output: Generates EXACT Figure 12 (fig_field_journal.png)
% =========================================================================

close all; clc;

fprintf('=================================================================\n');
fprintf('  REPRODUCING FIGURE 12: 2D WAVE FIELD DISTRIBUTIONS             \n');
fprintf('=================================================================\n\n');

p = torsional_waveguide_core.get_default_parameters();
a_mm = p.alpha * p.b * 1e3;
b_mm = 1.0 * p.b * 1e3;
c_mm = p.beta * p.b * 1e3;

points = [
    0.507692, 0.158897;
    5.005017, 0.164304
];

fig = figure('Name', 'Figure 12 - 2D Field Distributions', 'Color', 'w', ...
             'Position', [100, 100, 950, 420]);

for k = 1:2
    xi = points(k, 1);
    om = points(k, 2);
    
    fprintf('Computing 2D wavefield for panel (%c): xi = %.4f, Omega = %.6f...\n', ...
            char('a' + k - 1), xi, om);
        
    C = torsional_waveguide_core.solve_wave_field_constants(xi, om, p);
    [r_m, u_r, ~] = torsional_waveguide_core.compute_radial_profiles(xi, om, p, C, 200);
    r_mm = (r_m * p.b) * 1e3;
    
    % One axial wavelength: z/b in [0, 2*pi/xi]
    zb = linspace(0, 2 * pi / xi, 200);
    
    [R_grid, Z_grid] = meshgrid(r_mm, zb);
    
    % 2D wave field: Re[ u(r) * exp(i * xi * (z/b)) ]
    % Meshgrid: rows correspond to z, cols correspond to r
    U_field = zeros(size(R_grid));
    for iz = 1:length(zb)
        phase = cos(xi * zb(iz));
        U_field(iz, :) = u_r .* phase;
    end
    
    um = max(abs(U_field(:)));
    
    subplot(1, 2, k);
    pcolor(R_grid, Z_grid, U_field);
    shading interp;
    colormap(parula(256));
    caxis([-um, um]);
    hold on;
    
    % Layer boundary lines
    plot([a_mm, a_mm], [0, max(zb)], 'k--', 'LineWidth', 1.0);
    plot([b_mm, b_mm], [0, max(zb)], 'k--', 'LineWidth', 1.0);
    
    xlabel('r (mm)', 'FontSize', 11);
    ylabel('z/b (one wavelength)', 'FontSize', 11);
    title(sprintf('(%c) \\xi = %.4f, \\Omega = %.6f', char('a' + k - 1), xi, om), ...
          'FontSize', 11, 'FontWeight', 'bold');
      
    cb = colorbar;
    set(cb, 'Ticks', [-um, 0, um]);
    xlim([0, c_mm]);
    ylim([0, max(zb)]);
end

saveas(fig, 'fig_field_journal.png');
fprintf('Saved figure as: fig_field_journal.png\n');
