%% =========================================================================
% FIGURE 14: THEORETICAL SURFACE-STIFFNESS SENSITIVITY FRAMEWORK
% =========================================================================
% Manuscript Reference: Figure 14 (Section 5)
%
% Physical Application:
%   Quantifies the transduction capability of the waveguide for acoustic sensors:
%     - Panel (a): Absolute sensitivity S_surface = dOmega / d(mu_s* + tau_0*)
%       evaluating frequency response per unit surface stiffening.
%     - Panel (b): Normalized relative sensitivity S_rel = (G / Omega) * S_surface
%       demonstrating peak sensitivity at moderate wavenumbers where surface
%       traction coupling is optimal.
%
% Output: Generates EXACT Figure 14 (fig_sensing_framework.png)
% =========================================================================

close all; clc;

fprintf('=================================================================\n');
fprintf('  REPRODUCING FIGURE 14: SENSING FRAMEWORK & SENSITIVITY CURVES  \n');
fprintf('=================================================================\n\n');

p_base = torsional_waveguide_core.get_default_parameters();
xi_pts = linspace(0.1, 6.0, 50);

g_sweeps = [0.1, 0.3, 0.7, 1.2];
colors = {[0 0.447 0.741], [0.85 0.325 0.098], [0.466 0.674 0.188], [0.494 0.184 0.556]};

fig = figure('Name', 'Figure 14 - Sensing Framework', 'Color', 'w', ...
             'Position', [100, 100, 950, 400]);

subplot(1, 2, 1); hold on;
subplot(1, 2, 2); hold on;

dG = 0.02;
for i = 1:length(g_sweeps)
    g_val = g_sweeps(i);
    fprintf('Evaluating sensitivity for G = %g...\n', g_val);
    
    p_plus = p_base;
    p_plus.mus_star = (g_val + dG) * 0.7;
    p_plus.tau0_star = (g_val + dG) * 0.3;
    [~, om_plus] = torsional_waveguide_core.track_branch_continuation(xi_pts, p_plus, 1);
    
    p_minus = p_base;
    p_minus.mus_star = max(g_val - dG, 0) * 0.7;
    p_minus.tau0_star = max(g_val - dG, 0) * 0.3;
    [~, om_minus] = torsional_waveguide_core.track_branch_continuation(xi_pts, p_minus, 1);
    
    sens_abs = (om_plus - om_minus) / (2 * dG);
    sens_rel = (g_val ./ (om_plus + 1e-12)) .* sens_abs;
    
    % Panel (a)
    subplot(1, 2, 1);
    plot(xi_pts, sens_abs, 'LineWidth', 1.8, 'Color', colors{i}, ...
         'DisplayName', sprintf('\\mu_s^*+\\tau_0^* = %g', g_val));
     
    % Panel (b)
    subplot(1, 2, 2);
    plot(xi_pts, sens_rel, 'LineWidth', 1.8, 'Color', colors{i}, ...
         'DisplayName', sprintf('\\mu_s^*+\\tau_0^* = %g', g_val));
end

% Decorate Subplot (a)
subplot(1, 2, 1);
xlabel('Dimensionless Wavenumber \xi', 'FontSize', 11);
ylabel('Absolute Sensitivity S_{surface} = \partial\Omega / \partial(\mu_s^*+\tau_0^*)', 'FontSize', 10);
title('(a) Absolute Sensitivity to Surface Stiffening', 'FontSize', 11, 'FontWeight', 'bold');
legend('Location', 'northeast', 'FontSize', 8.5);
grid on; box on;
xlim([0, 6]);

% Decorate Subplot (b)
subplot(1, 2, 2);
xlabel('Dimensionless Wavenumber \xi', 'FontSize', 11);
ylabel('Normalized Relative Sensitivity S_{rel}', 'FontSize', 10);
title('(b) Normalized Relative Sensitivity vs Wavenumber', 'FontSize', 11, 'FontWeight', 'bold');
legend('Location', 'southeast', 'FontSize', 8.5);
grid on; box on;
xlim([0, 6]);

sgtitle('Theoretical Surface-Stiffness Sensitivity Framework for Acoustic Sensors', ...
        'FontSize', 12, 'FontWeight', 'bold');

saveas(fig, 'fig_sensing_framework.png');
fprintf('Saved figure as: fig_sensing_framework.png\n');
