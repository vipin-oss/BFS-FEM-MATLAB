%% =========================================================================
% FIGURE 15: LOGARITHMIC OAT SENSITIVITY HEATMAP MATRIX
% =========================================================================
% Manuscript Reference: Figure 15 (Section 4.5 & Table 6)
%
% Methodology:
%   One-At-a-Time (OAT) logarithmic local sensitivity:
%       S_{ij} = d(ln Q_j) / d(ln p_i) = (p_i / Q_j) * (dQ_j / dp_i)
%   where parameters p_i in {G, ka*, kb*} and metrics Q_j in {Omega(6), xi_c, vp(6), L}.
%
% Output: Generates EXACT Figure 15 (fig_sensitivity_journal.png)
% =========================================================================

close all; clc;

fprintf('=================================================================\n');
fprintf('  REPRODUCING FIGURE 15: LOGARITHMIC SENSITIVITY MATRIX          \n');
fprintf('=================================================================\n\n');

% Sensitivity matrix matching manuscript Table 6
S = [
    0.0000, 0.0000, 0.0000,  0.0000;
    0.0000, 0.0000, 0.0000, -0.6200;
    0.2400, 0.0000, 0.2400, -0.4800
];

row_labels = {'G = (\mu_s^* + \tau_0^*)', 'k_a^*', 'k_b^*'};
col_labels = {'\Omega(6)', '\xi_c', 'v_p(6)', 'L'};

fig = figure('Name', 'Figure 15 - Sensitivity Matrix', 'Color', 'w', ...
             'Position', [150, 150, 580, 360]);

% Custom Blue-White-Red Diverging Colormap
c_blue = [0.230, 0.299, 0.754];
c_white = [1.0, 1.0, 1.0];
c_red = [0.706, 0.016, 0.150];
n_half = 128;
r_map = [linspace(c_blue(1), c_white(1), n_half), linspace(c_white(1), c_red(1), n_half)];
g_map = [linspace(c_blue(2), c_white(2), n_half), linspace(c_white(2), c_red(2), n_half)];
b_map = [linspace(c_blue(3), c_white(3), n_half), linspace(c_white(3), c_red(3), n_half)];
custom_bwr = [r_map', g_map', b_map'];

imagesc(S);
colormap(custom_bwr);
caxis([-0.65, 0.65]);

cb = colorbar;
ylabel(cb, '\partialln Q / \partialln a_i', 'FontSize', 11, 'FontWeight', 'bold');

set(gca, 'XTick', 1:4, 'XTickLabel', col_labels, 'FontSize', 11, 'FontWeight', 'bold');
set(gca, 'YTick', 1:3, 'YTickLabel', row_labels, 'FontSize', 11, 'FontWeight', 'bold');

% Annotate cell values
for i = 1:3
    for j = 1:4
        val = S(i, j);
        txt_color = 'k';
        if abs(val) > 0.4
            txt_color = 'w';
        end
        text(j, i, sprintf('%.2f', val), 'HorizontalAlignment', 'center', ...
             'Color', txt_color, 'FontSize', 11, 'FontWeight', 'bold');
    end
end

% Draw grid separators
hold on;
for k = 0.5:1:4.5
    plot([k, k], [0.5, 3.5], 'Color', [0.8 0.8 0.8], 'LineWidth', 1.0);
end
for k = 0.5:1:3.5
    plot([0.5, 4.5], [k, k], 'Color', [0.8 0.8 0.8], 'LineWidth', 1.0);
end
box on;

saveas(fig, 'fig_sensitivity_journal.png');
fprintf('Saved figure as: fig_sensitivity_journal.png\n');
