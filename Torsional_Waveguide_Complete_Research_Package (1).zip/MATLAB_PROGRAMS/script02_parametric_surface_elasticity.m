%% =========================================================================
% SCRIPT 02: PARAMETRIC SWEEP OF GURTIN-MURDOCH SURFACE ELASTICITY
% =========================================================================
% Physical Background:
%   At the outer cylindrical surface (r = c), surface atoms experience an
%   asymmetric atomic environment, leading to excess surface energy and
%   surface stress (Gurtin-Murdoch model).
%   The non-dimensional parameter:
%       G_s* = mu_s* + tau_0* = (mu_s + tau_0) * s44_2 / b
%   captures surface shear modulus (mu_s) and residual surface tension (tau_0).
%
% What this script does (FROM ZERO, NO PRECOMPUTED DATA):
%   1. Sweeps surface elasticity G_s* over {0.0, 0.2, 0.5, 1.0, 2.0}.
%      - G_s* = 0.0 represents the classical traction-free boundary condition.
%      - G_s* > 0 represents nanostructured / coated surface stiffening.
%   2. For each value, solves the 5x5 dispersion relation det(M) = 0 from
%      scratch across xi in [0.1, 5.0].
%   3. Quantifies the percentage frequency shift:
%         Delta_Omega (%) = [(Omega(G_s*) - Omega(0)) / Omega(0)] * 100
%   4. Plots publication-ready multi-curve dispersion comparison.
% =========================================================================

close all;

fprintf('=================================================================\n');
fprintf('  SCRIPT 02: SURFACE ELASTICITY PARAMETRIC STUDY FROM SCRATCH    \n');
fprintf('=================================================================\n\n');

% Base parameters
p_base = torsional_waveguide_core.get_default_parameters();
p_base.ka_star = 5.0;
p_base.kb_star = 5.0;

% Values of surface elasticity (mus* + tau0*) to investigate
surface_values = [0.0, 0.2, 0.5, 1.0, 2.0];
colors = {[0 0.447 0.741], [0.85 0.325 0.098], [0.929 0.694 0.125], ...
          [0.494 0.184 0.556], [0.466 0.674 0.188]};
line_styles = {'k-', 'b--', 'r-.', 'm:', 'g-'};

xi_grid = linspace(0.1, 5.0, 80);

figure('Name', 'Surface Elasticity Influence', 'Color', 'w', 'Position', [150, 150, 800, 480]);
hold on;

results_table = [];

fprintf('Tracing dispersion branches for varying surface elasticity...\n');
for i = 1:length(surface_values)
    p = p_base;
    G_val = surface_values(i);
    p.mus_star = G_val * 0.7;  % Partition into shear and tension components
    p.tau0_star = G_val * 0.3;
    
    fprintf('  Evaluating G_s* = mu_s* + tau_0* = %.2f ...\n', G_val);
    
    % Solve dispersion from scratch using continuation
    [xi_sol, Om_sol] = torsional_waveguide_core.track_branch_continuation(xi_grid, p, 1);
    
    valid = ~isnan(Om_sol);
    xi_v = xi_sol(valid);
    Om_v = Om_sol(valid);
    
    if ~isempty(Om_v)
        plot(xi_v, Om_v, line_styles{i}, 'LineWidth', 2.0, 'Color', colors{i}, ...
             'DisplayName', sprintf('\\mu_s^* + \\tau_0^* = %.1f', G_val));
         
        % Evaluate frequency at reference wavenumber xi = 4.0
        [~, idx4] = min(abs(xi_v - 4.0));
        om_at_4 = Om_v(idx4);
        results_table = [results_table; G_val, om_at_4];
    end
end

% Plot bulk shear cone boundary for reference
plot(xi_grid, xi_grid, 'k:', 'LineWidth', 1.2, 'DisplayName', 'Bulk Cone (\Omega = \xi)');

xlabel('Dimensionless Axial Wavenumber \xi = k b', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('Dimensionless Frequency \Omega', 'FontSize', 11, 'FontWeight', 'bold');
title('Influence of Gurtin-Murdoch Surface Elasticity on Dispersion Curves', 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'northwest');
grid on;
box on;
xlim([0, 5.0]);

% Print Quantitative Shift Summary
fprintf('\n-------------------------------------------------------------\n');
fprintf('  Summary of Quantitative Surface Frequency Shifts at xi = 4.0:\n');
fprintf('-------------------------------------------------------------\n');
fprintf('  G_s* (mus*+tau0*)  |   Omega(xi=4.0)   |  Frequency Shift (%%)\n');
fprintf('-------------------------------------------------------------\n');
om_ref = results_table(1, 2); % Classical baseline (G_s* = 0)
for k = 1:size(results_table, 1)
    G_val = results_table(k, 1);
    om_val = results_table(k, 2);
    shift_pct = ((om_val - om_ref) / om_ref) * 100;
    fprintf('        %4.1f         |      %7.4f      |       %+6.2f %%\n', G_val, om_val, shift_pct);
end
fprintf('-------------------------------------------------------------\n');
fprintf('Physical Takeaway:\n');
fprintf('  Increasing surface elasticity provides additional surface restoring\n');
fprintf('  traction, shifting the dispersion curves to higher frequencies.\n\n');
