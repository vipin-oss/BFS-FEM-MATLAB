% =========================================================================
% TORSIONAL_WAVEGUIDE_CORE.M
%
% Core Mathematical and Numerical Library for:
% "Torsional Surface Waves in a Thermoelastic Cylinder Embedded in an
%  Elastic Metamaterial with Gurtin-Murdoch Surface Elasticity"
%
% This file contains all fundamental physics functions derived in the
% manuscript:
%  1. get_default_parameters()       : Physical and dimensionless parameters
%  2. compute_wavenumbers()          : Radial decay constants (gamma1, gamma2, gamma3)
%  3. compute_matrix_M()             : 5x5 boundary condition matrix
%  4. dispersion_determinant()       : Evaluates det(M(xi, Omega)) safely
%  5. find_dispersion_roots()        : Bracket scan + fzero root solver
%  6. track_branch_continuation()    : Predictor-corrector continuation
%  7. solve_wave_field_constants()   : SVD nullspace solution for {C1..C5}
%  8. compute_radial_profiles()      : Radial displacement u_theta(r) & stress
%
% All equations match the journal manuscript exactly.
% Compatible with MATLAB (R2018b+) and GNU Octave (9.0+).
% =========================================================================

classdef torsional_waveguide_core

    methods (Static)

        %% ----------------------------------------------------------------
        % 1. PHYSICAL AND DIMENSIONLESS PARAMETERS
        % ----------------------------------------------------------------
        function p = get_default_parameters()
            % Defines physical values from literature and calculates
            % dimensionless ratios matching the manuscript Section 2 & 4.
            
            % --- Core (Medium 1: Copper, generalized thermoelastic) ---
            % Note: Because torsional waves produce zero volumetric strain
            % (e = div(u) = 0), thermoelastic coupling vanishes identically.
            % Only mechanical shear modulus mu1 and density rho1 govern motion.
            p.mu1   = 3.86e10;       % Shear modulus (Pa)
            p.rho1  = 8954.0;        % Mass density (kg/m^3)
            
            % --- Intermediate Layer (Medium 2: PMMA, isotropic elastic) ---
            p.rho2  = 1180.0;        % Mass density (kg/m^3)
            p.s44_2 = 70.03e-11;     % Mechanical compliance (Pa^-1 = m*s^2/kg)
            
            % --- Outer Shell (Medium 3: ST-Quartz base Drude metamaterial) ---
            p.rho3  = 2650.0;        % Mass density (kg/m^3)
            p.s0    = 1.474e-11;     % High-frequency reference compliance (Pa^-1)
            p.fp    = 1.0e6;         % Metamaterial resonance/plasma frequency (Hz) = 1 MHz
            p.omega_p = 2 * pi * p.fp; % Angular plasma frequency (rad/s)
            
            % --- Geometry ---
            % Cylindrical boundaries: Core at r=a, Interface at r=b, Surface at r=c
            p.b = 0.35016e-3;        % Reference interface radius (m) ~ 0.35 mm
            p.alpha = 0.5;           % a/b ratio (Core radius a = 0.5 * b)
            p.beta  = 1.5;           % c/b ratio (Outer radius c = 1.5 * b)
            p.a = p.alpha * p.b;     % Inner core radius (m)
            p.c = p.beta * p.b;      % Outer cylinder radius (m)
            
            % --- Interface Springs (Imperfect bonding) ---
            % Spring stiffnesses ka, kb [N/m^3 = Pa/m]
            % Dimensionless stiffness: ka* = ka * b * s44_2
            p.ka_star = 5.0;         % Default moderate interface stiffness at r=a
            p.kb_star = 5.0;         % Default moderate interface stiffness at r=b
            p.ka = p.ka_star / (p.b * p.s44_2);
            p.kb = p.kb_star / (p.b * p.s44_2);
            
            % --- Gurtin-Murdoch Surface Elasticity at r=c ---
            % mu_s = surface shear modulus (N/m), tau0 = residual surface tension (N/m)
            p.mu_s = 5.0;            % (N/m)
            p.tau0 = 1.0;            % (N/m)
            p.mus_star  = (p.mu_s / p.b) * p.s44_2;  % Dimensionless surface shear modulus
            p.tau0_star = (p.tau0 / p.b) * p.s44_2;  % Dimensionless surface tension
            
            % --- Dimensionless Groups ---
            p.m1         = p.mu1 * p.s44_2;          % Shear modulus ratio (Core / Layer 2)
            p.rho1_ratio = p.rho1 / p.rho2;          % Density ratio rho1 / rho2
            p.rho3_ratio = p.rho3 / p.rho2;          % Density ratio rho3 / rho2
            p.s2_over_s0 = p.s44_2 / p.s0;           % Compliance contrast
            
            % Reference bulk shear velocity in Layer 2 (m/s):
            % v2 = sqrt(mu2 / rho2) = 1 / sqrt(rho2 * s44_2)
            p.v2 = 1.0 / sqrt(p.rho2 * p.s44_2);     % Bulk shear velocity ~ 1100.2 m/s
            
            % Dimensionless plasma frequency:
            p.Omega_p = p.omega_p * p.b * sqrt(p.rho2 * p.s44_2);
        end

        %% ----------------------------------------------------------------
        % 2. RADIAL WAVENUMBERS AND LOCAL METAMATERIAL COMPLIANCE
        % ----------------------------------------------------------------
        function [g1, g2, g3, m3, isValid] = compute_wavenumbers(xi, Omega, p)
            % Calculates the dimensionless radial decay parameters:
            %  gamma1* = sqrt(xi^2 - (rho1/rho2)*(Omega^2 / m1))
            %  gamma2* = sqrt(xi^2 - Omega^2)
            %  m3(Omega) = (s44_2 / s0) / (1 - Omega_p^2 / Omega^2)
            %  gamma3* = sqrt(xi^2 - (rho3/rho2)*(Omega^2 / m3(Omega)))
            
            g1 = 0; g2 = 0; g3 = 0; m3 = 0;
            isValid = false;
            
            % Avoid singularity near zero frequency
            if abs(Omega) < 1e-10
                return;
            end
            
            % Drude-type frequency-dependent metamaterial compliance:
            % s44_3(Omega) = s0 * [1 - (Omega_p / Omega)^2]
            % Below Omega_p, compliance becomes negative (effective mass/stiffness inversion)
            s44_ratio = 1.0 - (p.Omega_p^2) / (Omega^2);
            if abs(s44_ratio) < 1e-12
                return; % Metamaterial resonance singularity
            end
            
            % Dimensionless modulus contrast m3:
            m3 = p.s2_over_s0 / s44_ratio;
            
            % Squared radial decay constants:
            g1_sq = xi^2 - (p.rho1_ratio * Omega^2) / p.m1;
            g2_sq = xi^2 - Omega^2;
            g3_sq = xi^2 - (p.rho3_ratio * Omega^2) / m3;
            
            % For surface-guided (evanescent) waves, all decay parameters must be real:
            % g1_sq > 0, g2_sq > 0, g3_sq > 0
            if (g1_sq <= 0) || (g2_sq <= 0) || (g3_sq <= 0)
                return; % Leaky / radiating regime
            end
            
            g1 = sqrt(g1_sq);
            g2 = sqrt(g2_sq);
            g3 = sqrt(g3_sq);
            isValid = true;
        end

        %% ----------------------------------------------------------------
        % 3. 5x5 BOUNDARY CONDITION MATRIX M(xi, Omega)
        % ----------------------------------------------------------------
        function M = compute_matrix_M(xi, Omega, p)
            % Constructs the exact 5x5 boundary matrix derived from:
            % Row 1: Traction continuity across interface r = a
            % Row 2: Spring jump condition across interface r = a
            % Row 3: Traction continuity across interface r = b
            % Row 4: Spring jump condition across interface r = b
            % Row 5: Gurtin-Murdoch surface balance at outer radius r = c
            
            [g1, g2, g3, m3, isValid] = torsional_waveguide_core.compute_wavenumbers(xi, Omega, p);
            if ~isValid
                M = [];
                return;
            end
            
            alpha = p.alpha;
            beta  = p.beta;
            ka    = p.ka_star;
            kb    = p.kb_star;
            G_gm  = p.mus_star + p.tau0_star; % Total Gurtin-Murdoch surface factor
            m1    = p.m1;
            
            M = zeros(5, 5);
            
            % --- Row 1: Stress continuity at r = a (r* = alpha) ---
            % sigma_r_theta^(1)(a) = sigma_r_theta^(2)(a)
            M(1, 1) =  m1 * g1 * besseli(2, alpha * g1);
            M(1, 2) = -g2 * besseli(2, alpha * g2);
            M(1, 3) =  g2 * besselk(2, alpha * g2);
            
            % --- Row 2: Spring displacement jump at r = a ---
            % sigma_r_theta^(1)(a) = ka * [u_theta^(2)(a) - u_theta^(1)(a)]
            M(2, 1) =  m1 * g1 * besseli(2, alpha * g1) + ka * besseli(1, alpha * g1);
            M(2, 2) = -ka * besseli(1, alpha * g2);
            M(2, 3) = -ka * besselk(1, alpha * g2);
            
            % --- Row 3: Stress continuity at r = b (r* = 1.0) ---
            % sigma_r_theta^(2)(b) = sigma_r_theta^(3)(b)
            M(3, 2) =  g2 * besseli(2, g2);
            M(3, 3) = -g2 * besselk(2, g2);
            M(3, 4) = -m3 * g3 * besseli(2, g3);
            M(3, 5) =  m3 * g3 * besselk(2, g3);
            
            % --- Row 4: Spring displacement jump at r = b ---
            % sigma_r_theta^(2)(b) = kb * [u_theta^(3)(b) - u_theta^(2)(b)]
            M(4, 2) =  g2 * besseli(2, g2) + kb * besseli(1, g2);
            M(4, 3) = -g2 * besselk(2, g2) + kb * besselk(1, g2);
            M(4, 4) = -kb * besseli(1, g3);
            M(4, 5) = -kb * besselk(1, g3);
            
            % --- Row 5: Gurtin-Murdoch boundary condition at r = c (r* = beta) ---
            % sigma_r_theta^(3)(c) + (mu_s + tau_0) * d^2(u_theta^(3))/dz^2 = 0
            M(5, 4) =  m3 * g3 * besseli(2, beta * g3) + G_gm * (xi^2) * besseli(1, beta * g3);
            M(5, 5) = -m3 * g3 * besselk(2, beta * g3) + G_gm * (xi^2) * besselk(1, beta * g3);
        end

        %% ----------------------------------------------------------------
        % 4. DISPERSION DETERMINANT EVALUATION
        % ----------------------------------------------------------------
        function D = dispersion_determinant(xi, Omega, p)
            % Evaluates det(M(xi, Omega)) with physical guards.
            % Returns NaN if wave is non-evanescent or outside physical range.
            M = torsional_waveguide_core.compute_matrix_M(xi, Omega, p);
            if isempty(M)
                D = NaN;
                return;
            end
            
            det_val = det(M);
            if ~isreal(det_val) || ~isfinite(det_val)
                D = NaN;
            else
                D = det_val;
            end
        end

        %% ----------------------------------------------------------------
        % 5. ROOT FINDING AT A GIVEN WAVENUMBER xi
        % ----------------------------------------------------------------
        function roots = find_dispersion_roots(xi, p, ngrid, om_max)
            % Scans frequency Omega in (1e-4, om_max) to find all roots where
            % det(M(xi, Omega)) = 0.
            if nargin < 3 || isempty(ngrid), ngrid = 3000; end
            if nargin < 4 || isempty(om_max), om_max = 0.9999 * xi; end
            
            om_grid = linspace(1e-4, om_max, ngrid);
            d_vals = zeros(size(om_grid));
            for k = 1:length(om_grid)
                d_vals(k) = torsional_waveguide_core.dispersion_determinant(xi, om_grid(k), p);
            end
            
            roots = [];
            for k = 1:(length(om_grid) - 1)
                f1 = d_vals(k);
                f2 = d_vals(k + 1);
                
                % Check for finite, non-zero sign changes
                if isfinite(f1) && isfinite(f2) && (f1 * f2 < 0)
                    try
                        sol = fzero(@(om) torsional_waveguide_core.dispersion_determinant(xi, om, p), ...
                                    [om_grid(k), om_grid(k + 1)]);
                        if isempty(roots) || ~any(abs(roots - sol) < 1e-6)
                            roots(end + 1) = sol;
                        end
                    catch
                        % Skip singular / ill-conditioned bracket
                    end
                end
            end
            
            % Sort in descending order (highest Omega = fundamental physical branch)
            roots = sort(roots, 'descend');
        end

        %% ----------------------------------------------------------------
        % 6. PREDICTOR-CORRECTOR CONTINUATION
        % ----------------------------------------------------------------
        function [xi_out, Omega_out] = track_branch_continuation(xi_grid, p, branch_rank)
            % Tracks a dispersion branch smoothly across xi_grid using
            % linear predictor-corrector continuation.
            if nargin < 3, branch_rank = 1; end
            
            xi_out = xi_grid;
            Omega_out = NaN(size(xi_grid));
            
            % Seed root at initial xi
            r0 = torsional_waveguide_core.find_dispersion_roots(xi_grid(1), p);
            if length(r0) < branch_rank
                warning('Initial wavenumber xi=%.3f does not contain requested branch rank.', xi_grid(1));
                return;
            end
            
            Omega_out(1) = r0(branch_rank);
            prev = Omega_out(1);
            prev2 = prev;
            
            search_windows = [0.01, 0.02, 0.05, 0.10, 0.20, 0.35];
            
            for i = 2:length(xi_grid)
                xi = xi_grid(i);
                % Linear predictor from previous two converged points:
                pred = 2.0 * prev - prev2;
                
                found = false;
                for w = search_windows
                    lo = max(1e-4, pred - w);
                    hi = min(0.9999 * xi, pred + w);
                    if hi <= lo, continue; end
                    
                    sub_grid = linspace(lo, hi, 40);
                    sub_d = arrayfun(@(om) torsional_waveguide_core.dispersion_determinant(xi, om, p), sub_grid);
                    valid_mask = isfinite(sub_d);
                    sub_grid = sub_grid(valid_mask);
                    sub_d = sub_d(valid_mask);
                    
                    if length(sub_d) < 2, continue; end
                    
                    idx_cross = find(diff(sign(sub_d)) ~= 0);
                    if ~isempty(idx_cross)
                        try
                            j = idx_cross(1);
                            sol = fzero(@(om) torsional_waveguide_core.dispersion_determinant(xi, om, p), ...
                                        [sub_grid(j), sub_grid(j + 1)]);
                            Omega_out(i) = sol;
                            prev2 = prev;
                            prev = sol;
                            found = true;
                            break;
                        catch
                        end
                    end
                end
                
                if ~found
                    % Keep prev to attempt recovery on subsequent step
                    prev2 = prev;
                end
            end
        end

        %% ----------------------------------------------------------------
        % 7. WAVE FIELD INTEGRATION CONSTANTS (SVD NULLSPACE)
        % ----------------------------------------------------------------
        function C = solve_wave_field_constants(xi, Omega, p)
            % Solves [M]{C} = 0 for the 5 integration constants:
            %  C = [A1, B2, C2, D3, E3]^T
            % Uses Singular Value Decomposition (SVD) to find the right
            % singular vector corresponding to the minimum singular value.
            M = torsional_waveguide_core.compute_matrix_M(xi, Omega, p);
            if isempty(M)
                C = NaN(5, 1);
                return;
            end
            
            [~, ~, V] = svd(M);
            C = V(:, end); % Eigenvector associated with smallest singular value (nullspace)
            
            % Normalize so displacement at outer surface r = c is unity: u_theta(c) = 1
            [g1, g2, g3, m3, isValid] = torsional_waveguide_core.compute_wavenumbers(xi, Omega, p);
            if isValid
                u_surf = C(4) * besseli(1, p.beta * g3) + C(5) * besselk(1, p.beta * g3);
                if abs(u_surf) > 1e-12
                    C = C / u_surf;
                end
            end
        end

        %% ----------------------------------------------------------------
        % 8. RADIAL MODE PROFILES: DISPLACEMENT AND SHEAR STRESS
        % ----------------------------------------------------------------
        function [r_norm, u_theta, sigma_r_theta] = compute_radial_profiles(xi, Omega, p, C, n_points)
            % Computes radial displacement u_theta(r) and shear stress
            % sigma_r_theta(r) from r = 0 to r = c.
            if nargin < 5, n_points = 600; end
            
            [g1, g2, g3, m3, isValid] = torsional_waveguide_core.compute_wavenumbers(xi, Omega, p);
            if ~isValid
                r_norm = []; u_theta = []; sigma_r_theta = [];
                return;
            end
            
            alpha = p.alpha;
            beta  = p.beta;
            m1    = p.m1;
            
            % Generate piecewise radial grid:
            % Region 1: [0, alpha]
            % Region 2: [alpha, 1.0]
            % Region 3: [1.0, beta]
            n1 = round(n_points * (alpha / beta));
            n2 = round(n_points * ((1.0 - alpha) / beta));
            n3 = n_points - n1 - n2;
            
            r1 = linspace(1e-5, alpha, n1);
            r2 = linspace(alpha, 1.0, n2);
            r3 = linspace(1.0, beta, n3);
            
            r_norm = [r1, r2, r3];
            u_theta = zeros(size(r_norm));
            sigma_r_theta = zeros(size(r_norm));
            
            % --- Region 1: Core (0 < r* <= alpha) ---
            % u_theta^(1) = A1 * I1(gamma1* * r*)
            % sigma_r_theta^(1) = m1 * gamma1* * A1 * I2(gamma1* * r*)
            A1 = C(1);
            for k = 1:length(r1)
                r = r1(k);
                u_theta(k) = A1 * besseli(1, g1 * r);
                sigma_r_theta(k) = m1 * g1 * A1 * besseli(2, g1 * r);
            end
            
            % --- Region 2: Intermediate Layer (alpha <= r* <= 1.0) ---
            % u_theta^(2) = B2 * I1(gamma2* * r*) + C2 * K1(gamma2* * r*)
            % sigma_r_theta^(2) = gamma2* * [B2 * I2 - C2 * K2]
            B2 = C(2);
            C2 = C(3);
            idx_start2 = n1 + 1;
            for k = 1:length(r2)
                r = r2(k);
                idx = idx_start2 + k - 1;
                u_theta(idx) = B2 * besseli(1, g2 * r) + C2 * besselk(1, g2 * r);
                sigma_r_theta(idx) = g2 * (B2 * besseli(2, g2 * r) - C2 * besselk(2, g2 * r));
            end
            
            % --- Region 3: Metamaterial Outer Shell (1.0 <= r* <= beta) ---
            % u_theta^(3) = D3 * I1(gamma3* * r*) + E3 * K1(gamma3* * r*)
            % sigma_r_theta^(3) = m3 * gamma3* * [D3 * I2 - E3 * K2]
            D3 = C(4);
            E3 = C(5);
            idx_start3 = n1 + n2 + 1;
            for k = 1:length(r3)
                r = r3(k);
                idx = idx_start3 + k - 1;
                u_theta(idx) = D3 * besseli(1, g3 * r) + E3 * besselk(1, g3 * r);
                sigma_r_theta(idx) = m3 * g3 * (D3 * besseli(2, g3 * r) - E3 * besselk(2, g3 * r));
            end
        end

    end
end
