#!/usr/bin/env python3
"""core.py — shared dimensionless solver core for the Phase-6 verification
scripts (extracted verbatim from full_study.py; no behavioural change)."""
import numpy as np
from scipy.optimize import brentq
from scipy.special import iv, kv

# ----------------------------- parameters ------------------------------------
mu1   = 3.86e10
rho1  = 8954.0
rho2  = 1180.0
s44_2 = 70.03e-11
rho3  = 2650.0
s0    = 1.474e-11
fp    = 1.0e6
b     = 0.35016e-3
alpha = 0.5
beta  = 1.5

m1      = mu1*s44_2
r12     = rho1/rho2
r32     = rho3/rho2
s2_s0   = s44_2/s0
omega_p = 2.0*np.pi*fp
Omega_p = omega_p*b*np.sqrt(rho2*s44_2)
v2      = 1.0/np.sqrt(rho2*s44_2)

def gammas2(xi, om, ka, kb, mus, tau0):
    if abs(om) < 1e-10:
        return None
    den = 1.0 - (Omega_p**2)/(om**2)
    if abs(den) < 1e-12:
        return None
    m3 = s2_s0/den
    g12 = xi*xi - r12*om*om/m1
    g22 = xi*xi - om*om
    g32 = xi*xi - r32*om*om/m3
    if g12 <= 0 or g22 <= 0 or g32 <= 0:
        return None
    return g12, g22, g32, m3

def Mmat(xi, om, ka, kb, mus, tau0):
    """The manuscript 5x5 matrix (R1..R5 dimensionless) or None."""
    g = gammas2(xi, om, ka, kb, mus, tau0)
    if g is None:
        return None
    g12, g22, g32, m3 = g
    g1, g2, g3 = np.sqrt(g12), np.sqrt(g22), np.sqrt(g32)
    a, c, G = alpha, beta, mus + tau0
    M = np.zeros((5, 5))
    M[0, 0] = m1*g1*iv(2, a*g1)
    M[0, 1] = -g2*iv(2, a*g2)
    M[0, 2] = g2*kv(2, a*g2)
    M[1, 0] = m1*g1*iv(2, a*g1) + ka*iv(1, a*g1)
    M[1, 1] = -ka*iv(1, a*g2)
    M[1, 2] = -ka*kv(1, a*g2)
    M[2, 1] = g2*iv(2, g2)
    M[2, 2] = -g2*kv(2, g2)
    M[2, 3] = -m3*g3*iv(2, g3)
    M[2, 4] = m3*g3*kv(2, g3)
    M[3, 1] = g2*iv(2, g2) + kb*iv(1, g2)
    M[3, 2] = -g2*kv(2, g2) + kb*kv(1, g2)
    M[3, 3] = -kb*iv(1, g3)
    M[3, 4] = -kb*kv(1, g3)
    M[4, 3] = m3*g3*iv(2, c*g3) + G*xi*xi*iv(1, c*g3)
    M[4, 4] = -m3*g3*kv(2, c*g3) + G*xi*xi*kv(1, c*g3)
    return M

def Dfun(xi, om, ka, kb, mus, tau0):
    M = Mmat(xi, om, ka, kb, mus, tau0)
    if M is None:
        return np.nan
    d = np.linalg.det(M)
    return d if np.isfinite(d) else np.nan

def find_roots_at_xi(xi, ka, kb, mus, tau0, ngrid=4000, om_max=None):
    if om_max is None:
        om_max = 0.9999*xi
    grid = np.linspace(1e-4, om_max, ngrid)
    vals = [Dfun(xi, o, ka, kb, mus, tau0) for o in grid]
    roots = []
    for i in range(ngrid-1):
        f1, f2 = vals[i], vals[i+1]
        if np.isnan(f1) or np.isnan(f2) or f1 == 0.0:
            continue
        if f1*f2 < 0:
            try:
                r = brentq(lambda o: Dfun(xi, o, ka, kb, mus, tau0),
                            grid[i], grid[i+1], xtol=1e-13, rtol=1e-14, maxiter=200)
                if not any(abs(r-x) < 1e-7 for x in roots):
                    roots.append(r)
            except Exception:
                pass
    return sorted(roots, reverse=True)

def track_branch(ka, kb, mus, tau0, xi_grid, seed_xi, branch_rank,
                 windows=None, max_jump=0.30, verbose=False):
    if windows is None:
        windows = [0.01, 0.02, 0.05, 0.10, 0.20]
    info = dict(xi=[], om=[], ok_mask=[], jumps=[], loss_count=0, lost_at=None)
    prev = None; prev2 = None
    for xi in xi_grid:
        om = None
        if prev is None:
            roots = find_roots_at_xi(xi, ka, kb, mus, tau0)
            if branch_rank <= len(roots):
                om = roots[branch_rank-1]
        else:
            pred = prev if prev2 is None else 2.0*prev - prev2
            for w in windows:
                lo, hi = max(pred-w, 1e-8), min(pred+w, 0.9999*xi)
                if hi <= lo:
                    continue
                grid = np.linspace(lo, hi, 40)
                vals = [Dfun(xi, o, ka, kb, mus, tau0) for o in grid]
                found = False
                for i in range(len(grid)-1):
                    f1, f2 = vals[i], vals[i+1]
                    if np.isnan(f1) or np.isnan(f2) or f1*f2 >= 0:
                        continue
                    try:
                        r = brentq(lambda o: Dfun(xi, o, ka, kb, mus, tau0),
                                   grid[i], grid[i+1], xtol=1e-13, rtol=1e-14,
                                   maxiter=200)
                        if om is None or abs(r-pred) < abs(om-pred):
                            om = r
                        found = True
                    except Exception:
                        pass
                if found:
                    break
        if om is None:
            info["loss_count"] += 1
            if info["lost_at"] is None and info["loss_count"] > 25:
                info["lost_at"] = xi
            info["ok_mask"].append(False)
        else:
            if prev is not None and abs(om-prev) > max_jump*max(1.0, abs(prev)):
                info["jumps"].append((xi, prev, om))
            info["ok_mask"].append(True)
            prev2 = prev; prev = om
        info["xi"].append(xi)
        info["om"].append(om if om is not None else np.nan)
    info["xi"] = np.array(info["xi"])
    info["om"] = np.array(info["om"])
    info["ok_mask"] = np.array(info["ok_mask"])
    return info

def find_branch_onset(xi_lo, xi_hi, n, ka, kb, mus, tau0, rank, ngrid=4000):
    for xi in np.linspace(xi_lo, xi_hi, n):
        if len(find_roots_at_xi(xi, ka, kb, mus, tau0, ngrid=ngrid)) >= rank:
            return xi
    return None

def track_physical_branch(ka, kb, mus, tau0, xi_g, n_on=200):
    # Convention: find_roots_at_xi here (as in MATLAB) returns roots sorted
    # DESCENDING, so branch_rank 1 = highest Omega = the physical surface
    # branch. Verified: wherever two roots coexist, the HIGHEST is the
    # s->0+ continuous physical branch (the lower collapses to Omega -> 0
    # as (mus*+tau0*) -> 0). NOTE: track on a FINE grid (>= ~300 pts over
    # [0.05, 6]); coarse grids can silently switch to the spurious branch.
    roots0 = find_roots_at_xi(xi_g[0], ka, kb, mus, tau0)
    if len(roots0) >= 2 or (mus + tau0) < 1e-12:
        return track_branch(ka, kb, mus, tau0, xi_g, xi_g[0], 1), xi_g[0]
    xi_on = find_branch_onset(xi_g[0], min(xi_g[-1], 3.0), n_on,
                              ka, kb, mus, tau0, 2)
    if xi_on is None:
        return None, None
    g2 = xi_g[xi_g >= xi_on]
    return track_branch(ka, kb, mus, tau0, g2, xi_on, 1), xi_on
