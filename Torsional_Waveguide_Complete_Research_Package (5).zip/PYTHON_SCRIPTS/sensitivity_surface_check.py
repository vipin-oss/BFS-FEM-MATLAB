#!/usr/bin/env python3
"""sensitivity_surface_check.py — Python reference for the NEW Phase-9 content:
  (A) 12-cell logarithmic one-at-a-time sensitivity grid (base case),
  (B) 2D grid Omega(xi, G) for the 3D surface figure,
  (C) u_theta(r,z) field amplitudes for the two field panels.
All values cross-checked against the Octave/MATLAB package before finalizing.
"""
import numpy as np
import core as C
from mode_shape_check import mode_shape

V2 = C.v2                       # 1100.061 m/s
KA0, KB0 = 5.0, 5.0
MUS0 = 1.0e-5    # base: mu_s* = 1.0e-5
XI_G = np.linspace(0.05, 6.0, 300)

def run_branch(ka, kb, mus, tau0, xi_grid=XI_G):
    """Track branch 1 (rank 1 from seed 0.05); return (om_at_xi6, onset_xi, ok)."""
    b = C.track_branch(ka, kb, mus, tau0, xi_grid, xi_grid[0], 1)
    if not b["ok_mask"][-1]:
        return np.nan, np.nan, False
    om6 = b["om"][-1]
    # onset: first tracked grid point (mirrors the MATLAB console 'onset')
    onset = xi_grid[b["ok_mask"]][0]
    return om6, onset, True

def loc_factor(xi, om, ka, kb, mus, tau0):
    ms = mode_shape(xi, om, ka, kb, mus, tau0)
    u0 = abs(ms["u1"][0])          # first grid point r = 1e-4*b
    uc = abs(ms["u3"][-1])         # r = c
    if u0 == 0:
        return np.nan
    return uc / u0

def responses(ka, kb, mus, tau0):
    """Q = [Omega(6), xi_c, vp(6), loc(6)] at the tracked branch-1 point xi=6."""
    om6, onset, ok = run_branch(ka, kb, mus, tau0)
    if not ok:
        return dict(Q=[np.nan]*4, ok=False)
    lf = loc_factor(6.0, om6, ka, kb, mus, tau0)
    Q = [om6, onset, om6/6.0*V2, lf]
    if any(np.isnan(q) for q in Q):
        return dict(Q=Q, ok=False)
    return dict(Q=Q, ok=True)

print("=== (A) logarithmic one-at-a-time sensitivity (base case) ===")
print("perturbations: a- = 0.5a, a+ = 2a ;  S = [ln Q(a+) - ln Q(a-)] / ln 4")
print("responses:  Q1 = Omega(xi=6), Q2 = xi_c onset, Q3 = vp(xi=6), Q4 = loc factor |u(c)|/|u(0+)|")
base = responses(KA0, KB0, MUS0, 0.0)
print("base      :", dict(om6=base["Q"][0], onset=base["Q"][1],
                         vp6=base["Q"][2], loc6=base["Q"][3]), "ok=", base["ok"])

params = {
    "mu_s*": lambda f: (KA0, KB0, MUS0*f, 0.0),
    "ka*":   lambda f: (KA0*f, KB0, MUS0, 0.0),
    "kb*":   lambda f: (KA0, KB0*f, MUS0, 0.0),
}
names = ["Omega(xi=6)", "xi_c onset", "vp(xi=6)", "localization"]
S = {}
for pname, pf in params.items():
    m, p2 = responses(*pf(0.5)), responses(*pf(2.0))
    row = []
    for j in range(4):
        if m["ok"] and p2["ok"]:
            row.append((np.log(p2["Q"][j]) - np.log(m["Q"][j]))/np.log(4.0))
        else:
            row.append(np.nan)
    S[pname] = (row, m["ok"], p2["ok"], m["Q"], p2["Q"])
    print(f"\n{pname}:")
    print(f"  0.5x: ok={m['ok']}  Q={m['Q']}")
    print(f"  2x  : ok={p2['ok']}  Q={p2['Q']}")
    print(f"  S   : " + ", ".join(("%s=%.4f" % (n, s) if not np.isnan(s) else "%s=n/a" % n for n, s in zip(names, row))))

print("\n12-cell status grid (ok / n/a):")
for pname in params:
    row, m_ok, p_ok, _, _ = S[pname]
    print("  %-18s" % pname + "  " + "  ".join("ok" if not np.isnan(s) else "n/a" for s in row))

print("\n=== (B) Omega(xi, G) surface grid ===")
# track_physical_branch (MATLAB-identical selection rule) on a FINE 300-pt
# grid per row, then interpolate onto the 31-pt display grid (coarse grids
# can silently switch to the spurious surface-stiffness branch).
G_grid = np.linspace(0.0, 2.0, 21)
XI_S = np.linspace(0.05, 6.0, 31)
XI_F = np.linspace(0.05, 6.0, 300)
Z = np.full((len(G_grid), len(XI_S)), np.nan)
for i, G in enumerate(G_grid):
    b, on = C.track_physical_branch(KA0, KB0, G, 0.0, XI_F)
    if b is None:
        continue
    m = b["ok_mask"]
    Zi = np.interp(XI_S, b["xi"][m], b["om"][m])
    Zi[XI_S < b["xi"][m][0] - 1e-9] = np.nan   # no branch below onset
    Z[i, :] = Zi
# cross-check vs sweep-1 console values
for G, ref in [(0.0, 0.1629), (0.2, 0.3425), (0.5, 0.5296), (1.0, 0.7239), (2.0, 0.9627)]:
    i = int(np.argmin(np.abs(G_grid - G)))
    print(f"  G={G:4.2f}: Omega(xi=6) = {Z[i, -1]:.4f}   (sweep-1 ref {ref})")
# onset check vs sweep-1 console (grid-quantized: first 31-pt node >= true onset)
for G, ref in [(1.0, 0.3465), (2.0, 0.6133)]:
    i = int(np.argmin(np.abs(G_grid - G)))
    first_ok = np.where(~np.isnan(Z[i]))[0][0]
    print(f"  G={G:4.2f}: onset xi = {XI_S[first_ok]:.4f}   (sweep-1 ref {ref}, 31-pt grid)")
print("  maxZ =", round(float(np.nanmax(Z)), 6))
np.save("/tmp/omega_grid.npy", Z)
np.save("/tmp/omega_ggrid.npy", G_grid)
np.save("/tmp/omega_xgrid.npy", XI_S)

print("\n=== (C) u_theta(r,z) field amplitudes ===")
for xi, om, tag in [(0.507692, 0.158897, "panel a (small xi)"),
                    (5.005017, 0.164304, "panel b (large xi)")]:
    ms = mode_shape(xi, om, KA0, KB0, MUS0, TAU00)
    A1, B1, B2, C1, C2 = ms["v"]
    g1, g2, g3 = ms["g1"], ms["g2"], ms["g3"]
    b_, a_, c_ = C.b, C.alpha*C.b, C.beta*C.b
    r = np.linspace(1e-4*b_, c_, 300)
    rb = r/b_
    u = np.where(rb <= a_/b_,
                 A1*C.iv(1, g1*rb),
                 np.where(rb <= 1.0,
                          B1*C.iv(1, g2*rb) + B2*C.kv(1, g2*rb),
                          C1*C.iv(1, g3*rb) + C2*C.kv(1, g3*rb)))
    lam = 2.0*np.pi/xi            # one axial wavelength (dimensionless z/b)
    # exact interface values (grid can undersample the r=b jump peak):
    u0 = abs(A1*C.iv(1, g1*1e-4))                    # core, r = 1e-4 b  ~ 0+
    ua = abs(A1*C.iv(1, g1*(a_/b_)))                 # core side of r=a
    ub_el = abs(B1*C.iv(1, g2) + B2*C.kv(1, g2))     # elastic side of r=b
    ub_sh = abs(C1*C.iv(1, g3) + C2*C.kv(1, g3))     # shell side of r=b (peak candidate)
    uc = abs(C1*C.iv(1, g3*(c_/b_)) + C2*C.kv(1, g3*(c_/b_)))  # r = c
    umax = max(u0, ua, ub_el, ub_sh, uc, abs(u).max())
    print(f"{tag}: xi={xi}, Omega={om}")
    print(f"  exact |u(0+)| = {u0:.6e}  |u(a-) = {ua:.6e}  |u(b-) elastic = {ub_el:.6e}  |u(b+) shell = {ub_sh:.6e}  |u(c) = {uc:.6e}")
    print(f"  max|u(r)| = {umax:.6e}  -> caxis [-max, +max]")
    print(f"  wavelength z/b = 2*pi/xi = {lam:.4f}  (physical {lam*b_*1e3:.4f} mm)")
    print(f"  |u(c)|/|u(0+)| = {uc/u0:.4e}")
