# Torsional Surface Waves in a Cylindrical Waveguide: Complete Research & Computational Suite

**Manuscript Title:** *Torsional Surface Waves in a Thermoelastic Cylinder Embedded in an Elastic Metamaterial with Gurtin–Murdoch Surface Elasticity for Sensing Applications*  
**Authors:** Annu Rani & M.S. Barak  
**Target Venue:** Q1/Q2 SCI Applied Mechanics / Ultrasonics / Waves Journal (IF 3.0–5.0)  
**Deliverable Version:** Master Revision 2026

---

## 1. Overview of the Research Project

This package contains the complete research deliverable, including:
1. **The 28-Page Scientific Manuscript** written using the official Springer Nature template (`sn-jnl.cls`).
2. **From-Scratch Standalone MATLAB Programs** with a **1-to-1 exact correspondence** to every scientific figure in the manuscript (Figures 2 through 15).
3. **Complete Python Computational Engine** used for verification and high-resolution figure rendering.
4. **All 15 Publication-Quality Figures** (including the updated 3D waveguide schematic).
5. **Overleaf-Ready Source Package** for instantaneous one-click compilation.

---

## 2. 1-to-1 Correspondence: Manuscript Figures vs. MATLAB Scripts

Every figure in the manuscript (`paper_springer.pdf`) has an exact, dedicated MATLAB script in `MATLAB_PROGRAMS/` that computes the data **from zero (first principles)** and generates the **exact same figure** with identical axes, titles, legends, curves, and styling:

| Figure in Manuscript | Dedicated MATLAB Script | Physical Subject & Verification |
| :--- | :--- | :--- |
| **Figure 1** (`model.png`) | *Schematic Diagram* | 3D concentric cylinder waveguide geometry |
| **Figure 2** (`fig_validation_benchmark.png`) | `Figure02_Validation_Benchmark.m` | Kiełczyński et al. (2025) benchmark ($f_{\max} = 145.02\text{ kHz}, v_g = 0$) |
| **Figure 3** (`fig_validation_limits.png`) | `Figure03_Validation_Limits.m` | Planar SPP limit ($\xi \to \infty$), rigid/compliant springs, vanishing GM |
| **Figure 4** (`fig_convergence_residuals.png`) | `Figure04_Convergence_Residuals.m` | Grid convergence ($|\Omega_{600} - \Omega_{300}|$) and SVD residual norm |
| **Figure 5** (`fig_dispersion_journal.png`) | `Figure05_Dispersion_Spectrum.m` | Branch 1 (surface wave) & Branch 2 (secondary) with bulk cone |
| **Figure 6** (`fig_interface_stiffness_comparison.png`) | `Figure06_Interface_Stiffness.m` | Comparative sweep of core ($k_a^*$) vs shell ($k_b^*$) spring stiffness |
| **Figure 7** (`fig_surface_journal.png`) | `Figure07_Dispersion_Surface_3D.m` | 3D dispersion surface $\Omega(\xi, \mu_s^*)$ |
| **Figure 8** (`fig_parametric_journal.png`) | `Figure08_Parametric_Sweeps.m` | (a) Surface elasticity sweep $G \in \{0, 0.2, 0.5, 1, 2\}$, (b) Spring sweep $k^*$ |
| **Figure 9** (`fig_geometry_thickness.png`) | `Figure09_Geometry_Thickness.m` | (a) Shell thickness $\beta = c/b$, (b) Metallic core ratio $\alpha = a/b$ |
| **Figure 10** (`fig_localization_transition.png`) | `Figure10_Localization_Transition.m` | Localization ratio $R_{cb} = |u_\theta(c)|/|u_\theta(b^+)|$ ($\xi_{\text{trans}} = 1.496$) and spring jumps |
| **Figure 11** (`fig_mode_shape_combined.png`) | `Figure11_Mode_Shapes_Combined.m` | Radial profiles $\|u_\theta(r)\|$ at $\xi=0.51, 5.01$ and $k^*$ sweep at $\xi=6$ |
| **Figure 12** (`fig_field_journal.png`) | `Figure12_Field_Distribution_2D.m` | 2D wavefield contours $\text{Re}[u_\theta(r, z)]$ over one axial wavelength |
| **Figure 13** (`fig_velocities_journal.png`) | `Figure13_Velocities_Phase_Group.m` | (a) Phase velocity $v_p$, (b) Backward-wave group velocity $v_g$ (ZGV point) |
| **Figure 14** (`fig_sensing_framework.png`) | `Figure14_Sensing_Framework.m` | Absolute ($S_{\text{surface}}$) and relative ($S_{\text{rel}}$) sensing curves |
| **Figure 15** (`fig_sensitivity_journal.png`) | `Figure15_Sensitivity_Matrix.m` | 3x4 Logarithmic One-At-a-Time (OAT) sensitivity heatmap matrix |
| **ALL FIGURES** | `generate_all_manuscript_figures.m` | Master script that runs all 14 solvers and outputs all 14 figures |

---

## 3. Directory Structure

```
Torsional_Waveguide_Package/
│
├── README.md                          <-- Comprehensive documentation (Markdown)
├── README.txt                         <-- Plain-text documentation
│
├── MANUSCRIPT_PDF/
│   └── paper_springer.pdf             <-- Full 28-page compiled manuscript deliverable
│
├── LATEX_MANUSCRIPT/                  <-- Overleaf-ready LaTeX package
│   ├── paper_springer.tex             <-- Primary LaTeX source file
│   ├── tor_annu_refs.bib              <-- 50 verified bibliography entries
│   ├── paper_springer.bbl             <-- Pre-compiled BibTeX references
│   ├── sn-jnl.cls                     <-- Springer Nature document class
│   ├── *.bst                          <-- All 9 Springer bibliography style files
│   └── *.png                          <-- All 15 embedded figures
│
├── MATLAB_PROGRAMS/                   <-- EXACT 1-TO-1 FIGURE GENERATORS (FROM SCRATCH)
│   ├── torsional_waveguide_core.m     <-- Fundamental physics & numerical library
│   ├── Figure02_Validation_Benchmark.m          <-- Generates Figure 2 (Kiełczyński 2025)
│   ├── Figure03_Validation_Limits.m             <-- Generates Figure 3 (Planar SPP limit)
│   ├── Figure04_Convergence_Residuals.m         <-- Generates Figure 4 (Grid & SVD audit)
│   ├── Figure05_Dispersion_Spectrum.m           <-- Generates Figure 5 (Dispersion curves)
│   ├── Figure06_Interface_Stiffness.m           <-- Generates Figure 6 (ka* vs kb*)
│   ├── Figure07_Dispersion_Surface_3D.m         <-- Generates Figure 7 (3D surface plot)
│   ├── Figure08_Parametric_Sweeps.m             <-- Generates Figure 8 (Surface & spring sweeps)
│   ├── Figure09_Geometry_Thickness.m            <-- Generates Figure 9 (Shell & core geometry)
│   ├── Figure10_Localization_Transition.m       <-- Generates Figure 10 (R_cb & spring jumps)
│   ├── Figure11_Mode_Shapes_Combined.m          <-- Generates Figure 11 (Radial mode profiles)
│   ├── Figure12_Field_Distribution_2D.m         <-- Generates Figure 12 (2D field contours)
│   ├── Figure13_Velocities_Phase_Group.m        <-- Generates Figure 13 (v_p, v_g, ZGV point)
│   ├── Figure14_Sensing_Framework.m             <-- Generates Figure 14 (Sensing curves)
│   ├── Figure15_Sensitivity_Matrix.m            <-- Generates Figure 15 (OAT heatmap)
│   └── generate_all_manuscript_figures.m        <-- Master runner (generates all 14 figures)
│
├── PYTHON_SCRIPTS/                    <-- Full Python verification and plotting suite
│   ├── master_figure_generator.py     <-- Script that generates all 15 publication figures
│   ├── core.py                        <-- Shared dimensionless physics solver
│   └── full_study.py                  <-- Comprehensive parameter sweep engine
│
└── ALL_FIGURES/                       <-- High-resolution PNGs of all 15 figures
```

---

## 4. How to Run the MATLAB Codes

1. Open MATLAB (R2018b or newer) or GNU Octave (9.0+).
2. Set the current directory to the `MATLAB_PROGRAMS/` folder.
3. **To generate all 14 figures in sequence:**
   ```matlab
   generate_all_manuscript_figures
   ```
4. **To generate any specific figure:**
   Simply open and run the corresponding script (for example, run `Figure05_Dispersion_Spectrum` to generate Figure 5).
5. All figures will be displayed in figure windows and saved as `.png` files in the current directory matching the manuscript filenames (`fig_dispersion_journal.png`, `fig_velocities_journal.png`, etc.).

---

## 5. How to Compile in Overleaf

1. Go to [Overleaf.com](https://www.overleaf.com) and log in.
2. Click **New Project** $\to$ **Upload Project**.
3. Select the provided ZIP archive (or the `LATEX_MANUSCRIPT` folder).
4. Ensure the Overleaf compiler is set to **pdfLaTeX** (default).
5. Click **Recompile**.
   - Overleaf will compile `paper_springer.tex` directly into the 28-page publication PDF with 0 errors, 0 missing figures, and 50 formatted citations.
