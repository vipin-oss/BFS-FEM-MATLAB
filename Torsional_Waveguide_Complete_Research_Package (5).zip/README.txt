================================================================================
TORSIONAL SURFACE WAVES IN A CYLINDRICAL WAVEGUIDE: COMPLETE RESEARCH PACKAGE
================================================================================
Authors: Annu Rani & M.S. Barak
Target Venue: Q1/Q2 SCI Applied Mechanics / Ultrasonics / Waves Journal
Revision: Master 2026 Deliverable

--------------------------------------------------------------------------------
1. DIRECTORY STRUCTURE & 1-TO-1 FIGURE MAPPING
--------------------------------------------------------------------------------
Every single figure in the manuscript (Figures 2 to 15) has an EXACT, dedicated
from-scratch MATLAB script in the "MATLAB_PROGRAMS" directory:

  Manuscript Figure               Dedicated MATLAB Script
  ------------------------------------------------------------------------------
  Figure 02: Benchmark            Figure02_Validation_Benchmark.m
  Figure 03: Asymptotic Limits    Figure03_Validation_Limits.m
  Figure 04: Convergence/Residual Figure04_Convergence_Residuals.m
  Figure 05: Dispersion Spectrum  Figure05_Dispersion_Spectrum.m
  Figure 06: Interface Stiffness  Figure06_Interface_Stiffness.m
  Figure 07: 3D Dispersion Surf   Figure07_Dispersion_Surface_3D.m
  Figure 08: Parametric Sweeps    Figure08_Parametric_Sweeps.m
  Figure 09: Geometry Thickness   Figure09_Geometry_Thickness.m
  Figure 10: Localization Metric  Figure10_Localization_Transition.m
  Figure 11: Radial Mode Shapes   Figure11_Mode_Shapes_Combined.m
  Figure 12: 2D Field Contours    Figure12_Field_Distribution_2D.m
  Figure 13: Phase/Group Velocity Figure13_Velocities_Phase_Group.m
  Figure 14: Sensing Framework    Figure14_Sensing_Framework.m
  Figure 15: Sensitivity Matrix   Figure15_Sensitivity_Matrix.m
  ALL FIGURES MASTER RUNNER       generate_all_manuscript_figures.m

--------------------------------------------------------------------------------
2. HOW TO RUN IN MATLAB / OCTAVE
--------------------------------------------------------------------------------
1. Open MATLAB or GNU Octave.
2. Navigate to the "MATLAB_PROGRAMS" folder.
3. Type:
       generate_all_manuscript_figures
   to run the entire suite and output all 14 figures.
4. Or open and run any individual script (e.g. Figure05_Dispersion_Spectrum.m).

All programs calculate everything from first-principles (Bessel functions,
5x5 matrix determinant, continuation root finding, SVD nullspace) without
loading any precomputed data files.

--------------------------------------------------------------------------------
3. HOW TO COMPILE IN OVERLEAF
--------------------------------------------------------------------------------
1. Go to www.overleaf.com and log in.
2. Select "New Project" -> "Upload Project".
3. Upload this entire zip archive (or the contents of LATEX_MANUSCRIPT).
4. Set the compiler to "pdfLaTeX" in Menu settings.
5. Click "Recompile". The full 27-page PDF will be generated cleanly.
================================================================================
