# DIFF REPORT — Torsional Waveguide Package v2 (2026-09-21)

Every number below was re-derived by **fresh execution of the current solvers**
(`PYTHON_SCRIPTS/core.py`, cross-checked against `MATLAB_PROGRAMS/torsional_waveguide_core.m`
via `regen_all.py` sections S1–S12, `master_figure_generator.py`,
`benchmark_kielczynski.py`, `sensitivity_surface_check.py`, `make_journal_previews.py`).
No value was carried over from the previous package without re-execution.

Format: `OLD → NEW`, with the executing evidence in parentheses.

---

## A. Wording-only changes (no numerics)

1. **Localization metric wording** — "complete characterization of modal **energy migration**"
   → "complete characterization of modal **displacement localization**"
   (R_cb is a displacement-amplitude ratio, not an energy quantity).
2. **Surface-inertia sentence** — removed "as quantitatively proven in Section …".
   New text: "… $(\rho_s v_p^2)/\mu^s \ll 10^{-3}$); accordingly, **$\rho_s = 0$ is an
   assumption of the present formulation**."
3. Items left **untouched by explicit instruction**: the "zero interior local maxima" claim
   and the Gurtin–Murdoch $\mu_s$-alone surface formulation (both verified correct).

## B. Benchmark-validation tolerance wording

- "within $0.01\%$" → "within $0.02\%$" in **abstract**, **contributions list**, and
  **conclusions** (3 occurrences).
- Justification (printed by `benchmark_kielczynski.py`): current solver deviates from
  Kiełczyński et al. (2025) by at most **k = 0.009 %** and **vp = 0.018 %**, so 0.01 % was
  an over-statement of the achieved agreement.

## C. Benchmark table (validation section)

Published k and vp columns verified identical to source (unchanged). Updated cells
(`vg [m/s]` and `err_vp [%]`), rows by frequency [kHz]:

| f | vg OLD → NEW | err_vp OLD → NEW |
|---|---|---|
| 75  | 726.55 → 726.54 | 0.0010 → 0.0006 |
| 80  | 659.64 → 659.62 | 0.0050 → 0.0049 |
| 90  | 539.23 → 539.21 | 0.0000 → 0.0005 |
| 100 | 428.48 → 428.46 | 0.0035 → 0.0032 |
| 110 | 322.71 → 322.69 | 0.0065 → 0.0072 |
| 120 | 220.40 → 220.37 | 0.0030 → 0.0038 |
| 130 | 122.77 → 122.71 | 0.0019 → 0.0020 |
| 140 | 35.44 → 35.31  | 0.0138 → 0.0138 |
| 144 | 6.91 → 6.41    | 0.0173 → 0.0183 |

Body text item 3: "$726.55$ m/s … to $6.91$ m/s" → "$726.54$ m/s … to $6.41$ m/s".
(err_k column unchanged, max 0.0090 %.)

## D. Table 5, Branch-2 block (secondary interface mode)

| ξ OLD → NEW | Ω OLD → NEW | vp OLD → NEW | vg OLD → NEW |
|---|---|---|---|
| 0.1097 → 0.1296 | 0.000105 → 0.000113 | 1.05 → 0.96 | 1.05 → 0.96 |
| 0.5077 (same) | 0.000478 → 0.000436 | 1.04 → 0.95 | 1.00 → 0.91 |
| 1.0052 (same) | 0.000900 → 0.000822 | 0.99 → 0.90 | 0.86 → 0.79 |
| 2.0002 (same) | 0.001537 → 0.001403 | 0.85 → 0.77 | 0.56 → 0.51 |
| 6.0000 (same) | 0.002677 → 0.002444 | 0.49 → 0.45 | 0.21 → 0.19 |

Body: branch-2 cutoff "$\xi_c \approx 0.1056$" → "$\xi_c \approx 0.1143$" (regen S2).

## E. Plateau band and residual norm (Branch-1 discussion)

- Frequency band "$0.1622 \le \Omega \le 0.1643$" → "$0.1619 \le \Omega \le 0.1645$"
  (fine-grid extremal values of tracked branch).
- Residual norm text "$10^{-15}$–$10^{-14}$" → "$1.9\times10^{-17}$–$3.5\times10^{-14}$".

## F. Limiting-case checks (validation bullet items)

- Rigid interfaces: $\Omega(6)$: **0.1651 → 0.2247**.
- Compliant interfaces: $\Omega(6)$: **0.1082 → 0.0709**.

## G. Shell-interface ($k_b^*$) sweep sentence (Table 6 discussion)

- $\Omega(6)$ at $k_b^*=0.5$: **0.1082 → 0.0709**.
- $\Omega(6)$ at $k_b^*=100$: **0.1865 → 0.2198**.
- Frequency-shift headline: **72.3 % → 209.8 %** (=(0.2198−0.0709)/0.0709).
- $\Omega(6)$ at $k_b^*=5$ = 0.1629 unchanged (verified).

## H. Group-velocity / ZGV text

- "$v_g$ … to zero near $\xi \approx 0.95$" → "near $\xi \approx 0.85$".
- Negative-$v_g$ window "between $\xi \approx 1.0$ and $2.5$" → "between $\xi \approx 0.85$ and $2.3$".
- ZGV examples "$\xi \approx 0.95$ and $\xi \approx 2.7$" →
  "$\xi \approx 0.85$, $\xi \approx 2.29$, and $\xi \approx 4.52$".

## I. Table 7 (parametric summary), rows 2–12: Ω(6) / vp(6) [m/s] / ξ_trans / J_b [%]

| Row | OLD | NEW |
|---|---|---|
| 2 (kb=0.5)  | 0.1082 / 19.84 / 0.82 / 82.15 | 0.0709 / 13.01 / 1.50 / 90.15 |
| 3 (kb=20)   | 0.1804 / 33.08 / 1.68 / 12.30 | 0.2030 / 37.22 / 1.50 / 18.62 |
| 4 (kb=100)  | 0.1865 / 34.20 / 1.74 / 2.55  | 0.2198 / 40.30 / 1.50 / 4.37 |
| 5 (ka=0.5)  | 0.1629 / 29.87 / 1.50 / 41.92 | 0.1628 / 29.85 / 1.50 / 47.73 |
| 6 (ka=100)  | 0.1629 / 29.87 / 1.50 / 41.92 | 0.1631 / 29.90 / 1.50 / 47.89 |
| 7 (μs=0.2)  | 0.3425 / 62.80 / 2.85 / 18.64 | 0.3425 / 62.79 / >6.0 / 5.79 |
| 8 (μs=0.5)  | 0.5296 / 97.10 / 4.90 / 5.12  | 0.5296 / 97.10 / >6.0 / 4.95 |
| 9 (μs=0.7)  | 0.6152 / 112.80 / >6.0 / 0.41 | **0.6180 / 113.30** / >6.0 / 4.82 |
| 10 (μs=2.0) | 0.9627 / 176.51 / >6.0 / 0.08 | 0.9627 / 176.50 / >6.0 / 4.60 |
| 11 (β=1.15) | 0.1105 / 20.26 / 0.95 / 58.40 | 0.1969 / 36.10 / 3.33 / 47.78 |
| 12 (β=2.00) | 0.1648 / 30.22 / 1.52 / 39.80 | 0.1625 / 29.79 / 0.80 / 47.79 |

Row 1 (baseline) unchanged: 0.1629 / 29.87 / 1.4962 / 47.79.
- Row 9: the $\mu_s^*=0.7$ cell is the user-directed correction to **0.617963** (current
  solver); vp(6) must move with it for self-consistency: 112.80 → 113.30 (flagged per
  instruction). ξ_c = 0.180 unchanged (verified 0.1834 fine-grid onset).
- Rows 7–10: ξ_trans column now ">6.0" — with stiffened surfaces the displacement ratio
  R_cb stays above 1 across the whole tracked range (outer-surface localization persists),
  so no interior crossover exists (old 2.85/4.90 values came from the stale solver state).
- J_b values: old 82.15/12.30/2.55/41.92/… were produced by the buggy branch selector;
  current-code J_b at ξ=6 on the physical branch gives the NEW column
  (interface-side maximum equals full-domain maximum, verified pointwise).

## J. Localization discussion text

- Regime-3 jump: "$J_b = 41.92\%$" → "$J_b = 47.79\%$".
- $R_{cb} \approx 0.1604$ at ξ=5 **verified correct** against current code (0.1604 exact);
  unchanged.

## K. Geometry bullet (shell thickness) — narrative reversed by current code

OLD: "thin shell (β=1.15) **lowers** the plateau to Ω≈0.11 … rises and saturates near 0.165".
NEW: "thin shell (β=1.15) **raises** the plateau to Ω(6)≈0.197 (radial confinement stiffens
the shell resonance); β=1.30–2.00 converge to Ω(6)≈0.162–0.168 (0.1629 at β=1.50,
0.1625 at β=2.00)". (regen S6: β=1.15→0.196903, β=1.30→0.167532, β=2.00→0.162489.)

## L. Sensing-framework sentence

OLD: "$S_{\mathrm{surface}}$ reaches 0.35–0.40".
NEW: normalized relative sensitivity "$S_{\mathrm{rel}} \approx 0.42$–$0.47$ at ξ=6
(for μs* = 0.5–1.2)" (computed with `track_physical_branch`, dG=0.02:
S_rel(6) = 0.4885/0.4778/0.4647/0.4522/0.4234 for G = 0.1/0.3/0.5/0.7/1.2;
S_abs(6) = 1.19/0.66/0.49/0.40/0.28).

## M. OAT sensitivity table (Table at ξ=6)

- $k_a^*$ row, L column: −0.6255 → −0.6209 (caption −0.626 → −0.621).
- $k_b^*$ row: +0.2373 → +0.2378 (Ω and vp columns), −0.4787 → −0.4795
  (caption S≈0.237 → 0.238). μs* row unchanged.

## N. Figures — all regenerated from current code

Regenerated via `master_figure_generator.py` (writes ALL_FIGURES/) and
`sensitivity_surface_check.py` + `make_journal_previews.py` (writes journal previews):
fig_validation_benchmark, fig_validation_limits, fig_convergence_residuals,
fig_interface_stiffness_comparison, fig_geometry_thickness, fig_localization_transition,
fig_sensing_framework, fig_dispersion_journal, fig_surface_journal, fig_parametric_journal,
fig_field_journal, fig_mode_shape_combined, fig_velocities_journal, fig_sensitivity_journal.
Benchmark prints **f_max = 145.024 kHz at k ≈ 7278.5–7292 rad/m** (tex value 145.02 kHz kept;
tex k=7291.9 within grid resolution, unchanged).

### Branch-selection bugs fixed in the generators (cause of the stale figures)

1. `fig_geometry_thickness`: the old `track_geom` did a first-det-crossing scan over Ω,
   which latched onto the spurious low branch-2 root for β≠1.5. Replaced by continuation
   (`core.track_branch` rank-1 from ξ=0.05 with patched `core.alpha/core.beta`).
2. `fig_sensing_framework`: plain rank-1 seeding at ξ=0.1 latched the spurious branch for
   some μs* values. Replaced by `core.track_physical_branch` on a 300-pt grid.
3. `sensitivity_surface_check.py`: fixed `TAU00` NameError (baseline τ₀* = 2e-6).

## O. Checklist — every solver-dependent table/figure re-executed against current core.py

| Item | Evidence (regen_all.py section / script) | Status |
|---|---|---|
| Table 5 branch-1 (incl. ξ_tr=1.4962, γ²-min, conv 2.24e-6/2.28e-7) | S1/S3 | verified, unchanged |
| Table 5 branch-2 | S2 | **updated (D)** |
| Ω_max 0.1709 fine-grid | S1 | verified 0.170915, unchanged |
| Benchmark table + f_max | S4 + benchmark_kielczynski.py | **updated (C)** |
| Limiting rigid/soft | S5 | **updated (F)** |
| μs sweep Ω6/onsets + G=0.7 k-spread 2.97e-4 | S7/S8 | verified, unchanged |
| ka sweep (\|ΔΩ\|<0.001, spread 2.61e-4) | S9 | verified, unchanged |
| kb sweep + 209.8 % | S10 | **updated (G)** |
| Geometry β/α sweeps | S6 | **updated (K)** |
| Table 7 + J_b + R_cb | S10/S11/S12 | **updated (I, J)** |
| OAT matrix | S12 | **updated (M)** |
| Sensitivity curves | sensitivity_surface_check.py | **updated (L)** |
| Velocities/ZGV text | S4-vg supplement | **updated (H)** |
| Figs 1–15 | master_figure_generator.py + previews | **regenerated (N)** |
| PDF | tectonic 0.15.0, 0 LaTeX errors | **recompiled** |

## P. Numbers confirmed CORRECT and deliberately left unchanged

ξ_trans = 1.4962; Ω_max = 0.1709; vp(6) baseline = 29.87 m/s; convergence
2.24e-6 / 2.28e-7; μs sweep {0.1629, 0.3425, 0.5296, 0.6180, 0.7239, 0.9627};
R_cb(5.0) = 0.1604; regime ratios 1.38 / 1.45; "zero interior local maxima" claim;
G–M μs-alone formulation; benchmark k and vp columns; f_max = 145.02 kHz.
