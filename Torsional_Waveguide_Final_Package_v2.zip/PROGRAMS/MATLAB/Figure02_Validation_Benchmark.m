%% =========================================================================
% FIGURE 02: QUANTITATIVE BENCHMARK VALIDATION AGAINST KIEŁCZYŃSKI ET AL.
%            (Sensors 25:143, 2025)
% =========================================================================
% Manuscript Reference: Figure 2 and Table 2 (Section 4.1)
%
% Physical Problem:
%   Torsional surface waves in a two-medium cylindrical waveguide:
%     - Metamaterial core (0 <= r <= a, radius a = 1.0 cm = 0.01 m):
%       Drude compliance s44^(1)(w) = s0 * [1 - (wp / w)^2]
%       rho1 = 2650 kg/m^3, s0 = 1.474e-11 Pa^-1, fp = 1.0 MHz
%     - Conventional PMMA outer cladding (r > a, infinite):
%       rho2 = 1180 kg/m^3, s44^(2) = 70.03e-11 Pa^-1
%       Bulk shear velocity v2 = 1 / sqrt(rho2 * s44_2) = 1100.1 m/s
%
% Exact Dispersion Equation (Eq. (14) of Kiełczyński et al. 2025):
%   F_Kiel(w, k) = [K2(gamma2*a) / K1(gamma2*a)] + ...
%                  [s44^(2) / s44^(1)(w)] * (gamma1 / gamma2) * ...
%                  [I2(gamma1*a) / I1(gamma1*a)] = 0
%   Implemented in standalone function: kiel_dispersion_residual.m
% =========================================================================

close all; clc;

fprintf('==========================================================================\n');
fprintf('  FIGURE 02: KIEŁCZYŃSKI ET AL. (2025) REDUCED CYLINDRICAL BENCHMARK      \n');
fprintf('==========================================================================\n\n');

% Physical Parameters (Table 1 of Kiełczyński et al. 2025)
a = 0.01;              % Core radius (m) = 1.0 cm
rho1 = 2650.0;         % ST-Quartz metamaterial core density (kg/m^3)
s0   = 1.474e-11;      % High-frequency compliance (Pa^-1)
fp   = 1.0e6;          % Metamaterial resonance frequency = 1 MHz
wp   = 2 * pi * fp;    % Angular frequency (rad/s)

rho2 = 1180.0;         % PMMA cladding density (kg/m^3)
s44_2 = 70.03e-11;     % PMMA compliance (Pa^-1)
v2 = 1.0 / sqrt(rho2 * s44_2); % PMMA bulk shear velocity ~ 1100.1 m/s

%% ------------------------------------------------------------------------
% 1. SOLVE DIRECTLY AT THE EXACT 9 FREQUENCIES OF TABLE 2
% ------------------------------------------------------------------------
table_freqs_khz = [75.0, 80.0, 90.0, 100.0, 110.0, 120.0, 130.0, 140.0, 144.0];
n_table = length(table_freqs_khz);

k_tab  = zeros(n_table, 1);
vp_tab = zeros(n_table, 1);
vg_tab = zeros(n_table, 1);
w_tab  = zeros(n_table, 1);

fprintf('--- 1. Exact Numerical Reproduction of Table 2 ---\n');
fprintf('  f (kHz) | omega (10^5 rad/s) |   k (rad/m)  |  vp (m/s)  |  vg (m/s)  |  vp/v2  \n');
fprintf('------------------------------------------------------------------------------\n');

for i = 1:n_table
    f = table_freqs_khz(i);
    w = 2 * pi * f * 1e3;
    w_tab(i) = w;
    
    % Evanescent bound in PMMA: k > w / v2
    k_min = (w / v2) * 1.0005;
    
    % Solve for exact k at frequency f
    k_root = fzero(@(k_val) kiel_dispersion_residual(w, k_val, a, rho1, s0, wp, rho2, s44_2), ...
                   [k_min, 15000.0]);
    k_tab(i) = k_root;
    vp_tab(i) = w / k_root;
    
    % Compute group velocity vg = dw/dk via high-precision central difference
    df = 0.005; % kHz
    w_p = 2 * pi * (f + df) * 1e3;
    w_m = 2 * pi * (f - df) * 1e3;
    kp = fzero(@(k_val) kiel_dispersion_residual(w_p, k_val, a, rho1, s0, wp, rho2, s44_2), [(w_p/v2)*1.0005, 15000.0]);
    km = fzero(@(k_val) kiel_dispersion_residual(w_m, k_val, a, rho1, s0, wp, rho2, s44_2), [(w_m/v2)*1.0005, 15000.0]);
    vg_tab(i) = (w_p - w_m) / (kp - km);
    
    fprintf('   %5.1f  |      %7.4f       |  %10.4f  |   %7.2f  |   %6.2f   |  %6.4f \n', ...
            f, w*1e-5, k_tab(i), vp_tab(i), vg_tab(i), vp_tab(i)/v2);
end
fprintf('------------------------------------------------------------------------------\n\n');

%% ------------------------------------------------------------------------
% 2. COMPUTE THE EXACT HEADLINE CUTOFF FREQUENCY f_max (where vg = 0)
% ------------------------------------------------------------------------
fprintf('--- 2. Computing Exact Resonance Cutoff Frequency (vg -> 0) ---\n');
% Near resonance, the curve bends and df/dk -> 0.
% We parameterize by k and find the peak frequency f_max:
solve_f_given_k = @(k_in) fzero(@(f_trial) kiel_dispersion_residual(2*pi*f_trial*1e3, k_in, a, rho1, s0, wp, rho2, s44_2), [140.0, 145.5]);

% Find the peak using golden section / fminbnd on -f(k)
k_opt = fminbnd(@(k_in) -solve_f_given_k(k_in), 6000.0, 10000.0);
f_max_computed = solve_f_given_k(k_opt);

% Planar limit for comparison: s44^(1)(w) = -s44^(2) => f_planar = fp / sqrt(1 + s44_2/s0)
f_planar = (fp * 1e-3) / sqrt(1.0 + s44_2 / s0);

fprintf('  --> COMPUTED HEADLINE CUTOFF: f_max = %.3f kHz (at k = %.1f rad/m, vg = 0.00 m/s)\n', ...
        f_max_computed, k_opt);
fprintf('  --> Planar SPP Asymptotic Limit (k -> infty): f_planar = %.3f kHz\n', f_planar);
fprintf('  --> Curvature Stiffening Shift (Cylindrical vs Planar): Delta_f = +%.3f kHz (+%.2f%%)\n\n', ...
        f_max_computed - f_planar, ((f_max_computed - f_planar)/f_planar)*100);

%% ------------------------------------------------------------------------
% 3. DENSE GRID FOR PUBLICATION FIGURE 2
% ------------------------------------------------------------------------
fprintf('--- 3. Tracing Smooth Dense Grid for Figure 2 Curves ---\n');
% Phase 1: From 72.0 kHz to 144.5 kHz, trace k(f)
f1 = linspace(72.0, 144.5, 80);
k1 = zeros(size(f1));
prev_k = 428.0;
for j = 1:length(f1)
    wj = 2 * pi * f1(j) * 1e3;
    k_lo = max((wj / v2) * 1.0005, prev_k - 20);
    k_hi = prev_k + 800;
    while (kiel_dispersion_residual(wj, k_hi, a, rho1, s0, wp, rho2, s44_2) < 0) && (k_hi < 8000)
        k_hi = k_hi + 500;
    end
    k1(j) = fzero(@(k) kiel_dispersion_residual(wj, k, a, rho1, s0, wp, rho2, s44_2), [k_lo, k_hi]);
    prev_k = k1(j);
end

% Phase 2: Up to and around the resonance peak, trace f(k) from k1(end) to 8000 rad/m
k2 = linspace(k1(end), 8000, 35);
f2 = zeros(size(k2));
for j = 1:length(k2)
    f2(j) = fzero(@(f_trial) kiel_dispersion_residual(2*pi*f_trial*1e3, k2(j), a, rho1, s0, wp, rho2, s44_2), [144.0, 145.03]);
end

k_dense = [k1, k2(2:end)];
f_dense = [f1, f2(2:end)];
w_dense = 2 * pi * f_dense * 1e3;
vp_dense = w_dense ./ k_dense;

% Group velocity vg = dw/dk = 2*pi * df/dk
df_dk = gradient(f_dense, k_dense);
vg_dense = 2 * pi * df_dk * 1e3;

%% ------------------------------------------------------------------------
% 4. PLOT EXACT FIGURE 2
% ------------------------------------------------------------------------
fig = figure('Name', 'Figure 02 - Benchmark Validation', 'Color', 'w', ...
             'Position', [100, 100, 950, 380]);

% --- Subplot (a): Dispersion curve f(k) ---
subplot(1, 2, 1);
plot(k_dense, f_dense, 'b-', 'LineWidth', 2.2, 'DisplayName', 'Surface mode f(k) (Solver)');
hold on;
plot(k_tab, table_freqs_khz, 'bo', 'MarkerFaceColor', 'w', 'MarkerSize', 5, 'DisplayName', 'Table 2 Benchmark Points');

% Resonance cutoff using the computed headline frequency
plot([0, 3500], [f_max_computed, f_max_computed], 'r--', 'LineWidth', 1.5, ...
     'DisplayName', sprintf('Resonance cutoff f_{max} \\approx %.1f kHz', f_max_computed));
plot([0, 3500], [70.0, 70.0], ':', 'Color', [0.5 0.5 0.5], 'LineWidth', 1.5, ...
     'DisplayName', 'Lower cutoff \approx 70 kHz');

% Bulk shear line: f = (k * v2) / (2*pi*1e3)
k_bulk_line = linspace(0, 3500, 100);
f_bulk_line = (k_bulk_line * v2) / (2 * pi * 1e3);
plot(k_bulk_line, f_bulk_line, 'g--', 'LineWidth', 1.8, ...
     'DisplayName', sprintf('Bulk shear line (v_2 = %.1f m/s)', v2));

xlabel('Wavenumber k (rad/m)');
ylabel('Frequency f (kHz)');
title('(a) Dispersion curve f(k)', 'FontWeight', 'bold');
legend('Location', 'southeast');
grid on; box on;
xlim([0, 3500]);
ylim([50, 160]);

% --- Subplot (b): Phase and group velocities ---
subplot(1, 2, 2);
plot(f_dense, vp_dense, 'b-', 'LineWidth', 2.2, 'DisplayName', 'Phase velocity v_p');
hold on;
plot(f_dense, vg_dense, 'r--', 'LineWidth', 2.0, 'DisplayName', 'Group velocity v_g');
plot(table_freqs_khz, vp_tab, 'bo', 'MarkerFaceColor', 'w', 'MarkerSize', 4);
plot(table_freqs_khz, vg_tab, 'rs', 'MarkerFaceColor', 'w', 'MarkerSize', 4);
plot([70, 150], [v2, v2], 'g:', 'LineWidth', 1.5, ...
     'DisplayName', sprintf('Bulk shear velocity = %.1f m/s', v2));

xlabel('Frequency f (kHz)');
ylabel('Velocity (m/s)');
title('(b) Phase and group velocities', 'FontWeight', 'bold');
legend('Location', 'northeast');
grid on; box on;
xlim([70, 150]);
ylim([0, 1200]);

if exist('sgtitle', 'builtin') || exist('sgtitle', 'file')
    sgtitle('Quantitative Benchmark Validation against Kiełczyński et al., Sensors 25:143 (2025)', ...
            'FontSize', 12, 'FontWeight', 'bold');
end

saveas(fig, 'fig_validation_benchmark.png');
fprintf('Saved figure as: fig_validation_benchmark.png\n');
