function Figure03_Validation_Limits()
%% =========================================================================
% FIGURE 03: ASYMPTOTIC & LIMITING-CASE ANALYTICAL AND NUMERICAL VERIFICATION
% =========================================================================
% Manuscript Reference: Figure 3 (Section 4.1)
%
% Theoretical Limits Verified (FROM ZERO):
%   (a) Planar SPP Interface Limit (xi -> infty):
%       As waveguide radius grows, cylindrical curvature vanishes and the
%       boundary converges to a planar interface between the conventional
%       layer and metamaterial, governed by:
%           m3(Omega) * gamma3* + gamma2* = 0
%   (b) Vanishing Surface Elasticity Limit (mus* = 0):
%       The outer boundary condition reduces to classical traction-free state.
%   (c) Rigid Interface Limit (ka* = kb* = 1000):
%       Displacement step jumps vanish ([u_theta] -> 0), reproducing a welded
%       composite waveguide.
%   (d) Compliant Interface Limit (ka* = kb* = 0.5):
%       Soft boundary layer showing pronounced acoustic modal confinement.
%   (e) Stiff Surface Coating (mus* = 0.7):
%       Micro/nano-scale stiffening shifting cutoff upward.
%
% Output: Generates EXACT Figure 3 (fig_validation_limits.png)
% =========================================================================

close all; clc;

fprintf('=================================================================\n');
fprintf('  REPRODUCING FIGURE 03: LIMITING-CASE ANALYTICAL VERIFICATION   \n');
fprintf('=================================================================\n\n');

p = torsional_waveguide_core.get_default_parameters();
xi_pts = linspace(0.1, 6.0, 60);

%% 1. Baseline Full Cylindrical Model
fprintf('Solving baseline cylindrical model...\n');
[~, om_base] = torsional_waveguide_core.track_branch_continuation(xi_pts, p, 1);

%% 2. Independent Planar SPP Limit Equation: m3 * gamma3* + gamma2* = 0
fprintf('Solving independent planar SPP limit...\n');
planar_om = NaN(size(xi_pts));
for i = 1:length(xi_pts)
    xi = xi_pts(i);
    om_test = linspace(1e-4, min(0.999 * xi, p.Omega_p * 0.999), 300);
    for k = 1:(length(om_test) - 1)
        r1 = planar_spp_det(xi, om_test(k), p);
        r2 = planar_spp_det(xi, om_test(k+1), p);
        if isfinite(r1) && isfinite(r2) && (r1 * r2 < 0)
            try
                planar_om(i) = fzero(@(om) planar_spp_det(xi, om, p), [om_test(k), om_test(k+1)]);
                break;
            catch
            end
        end
    end
end

%% 3. Vanishing Surface Elasticity (mus* = 0)
fprintf('Solving vanishing surface elasticity limit...\n');
p_g0 = p; p_g0.mus_star = 0.0; p_g0.tau0_star = 0.0;
[~, om_g0] = torsional_waveguide_core.track_branch_continuation(xi_pts, p_g0, 1);

%% 4. Rigid Interfaces (ka* = kb* = 1000)
fprintf('Solving rigid interface limit...\n');
p_rigid = p; p_rigid.ka_star = 1000.0; p_rigid.kb_star = 1000.0;
[~, om_rigid] = torsional_waveguide_core.track_branch_continuation(xi_pts, p_rigid, 1);

%% 5. Compliant Interfaces (ka* = kb* = 0.5)
fprintf('Solving compliant interface limit...\n');
p_soft = p; p_soft.ka_star = 0.5; p_soft.kb_star = 0.5;
[~, om_soft] = torsional_waveguide_core.track_branch_continuation(xi_pts, p_soft, 1);

%% 6. Stiff Surface Coating (mus* = 0.7)
fprintf('Solving stiff surface coating limit...\n');
p_g07 = p; p_g07.mus_star = 0.7; p_g07.tau0_star = 0.0;
[~, om_g07] = torsional_waveguide_core.track_branch_continuation(xi_pts, p_g07, 1);

%% Plot EXACT Figure 3 (matching manuscript layout)
fig = figure('Name', 'Figure 03 - Limiting Cases', 'Color', 'w', ...
             'Position', [100, 100, 950, 400]);

% --- Subplot (a): Asymptotic & Planar SPP Limits ---
subplot(1, 2, 1);
plot(xi_pts, om_base, 'b-', 'LineWidth', 2.0, 'DisplayName', 'Full Cylindrical Model (Baseline)');
hold on;
plot(xi_pts, planar_om, 'k--', 'LineWidth', 1.8, 'DisplayName', 'Planar SPP Interface Limit (\xi \rightarrow \infty)');
plot(xi_pts, om_g0, 'g:', 'LineWidth', 1.8, 'DisplayName', 'Vanishing Surface Elasticity (\mu_s^* = 0)');

xlabel('Dimensionless Wavenumber \xi = kb');
ylabel('Dimensionless Frequency \Omega');
title('(a) Asymptotic & Planar SPP Limits', 'FontWeight', 'bold');
legend('Location', 'southeast');
grid on; box on;
xlim([0, 6]);
ylim([0, 0.25]);

% --- Subplot (b): Interface Compliance & Stiffened Coating Limits ---
subplot(1, 2, 2);
plot(xi_pts, om_rigid, 'm-', 'LineWidth', 2.0, 'DisplayName', 'Rigid Interfaces (k_a^* = k_b^* = 1000)');
hold on;
plot(xi_pts, om_base, 'b--', 'LineWidth', 1.8, 'DisplayName', 'Intermediate Springs (k_a^* = k_b^* = 5.0)');
plot(xi_pts, om_soft, 'r-.', 'LineWidth', 1.8, 'DisplayName', 'Compliant Springs (k_a^* = k_b^* = 0.5)');
plot(xi_pts, om_g07, 'c:', 'LineWidth', 2.0, 'DisplayName', 'Stiff Surface Coating (\mu_s^* = 0.7)');

xlabel('Dimensionless Wavenumber \xi = kb');
ylabel('Dimensionless Frequency \Omega');
title('(b) Interface Compliance & Stiffened Coating Limits', 'FontWeight', 'bold');
legend('Location', 'northwest');
grid on; box on;
xlim([0, 6]);
ylim([0, 0.7]);

if exist('sgtitle', 'builtin') || exist('sgtitle', 'file')
    sgtitle('Limiting-Case Analytical and Numerical Verification', 'FontWeight', 'bold');
end

saveas(fig, 'fig_validation_limits.png');
fprintf('Saved figure as: fig_validation_limits.png\n');

end

%% Helper: Planar SPP Residual
function res = planar_spp_det(xi, Omega, p)
    [~, g2, g3, m3, isValid] = torsional_waveguide_core.compute_wavenumbers(xi, Omega, p);
    if ~isValid
        res = NaN;
    else
        res = m3 * g3 + g2;
    end
end
