%% =========================================================================
% FIGURE 05: COMPLETE MULTI-BRANCH DISPERSION SPECTRUM
% =========================================================================
% Manuscript Reference: Figure 5 (Section 4.2)
%
% Physical Phenomenon:
%   Shows the dispersion curves of the new torsional elastic surface wave:
%     - Branch 1 (Fundamental Surface Mode): Emerges below the bulk shear line,
%       remains strictly within the evanescent metamaterial band Omega < Omega_p,
%       and reaches an asymptotic plateau near Omega ~ 0.164.
%     - Branch 2 (Secondary Guided Mode): Coexists at low frequencies near zero.
%     - Bulk shear cone: Omega = xi (waves below this line are evanescent).
%     - Metamaterial cutoff: Omega_p = 2.0 (resonant plasma threshold).
%
% Output: Generates EXACT Figure 5 (fig_dispersion_journal.png)
% =========================================================================

close all; clc;

fprintf('=================================================================\n');
fprintf('  REPRODUCING FIGURE 05: MULTI-BRANCH DISPERSION SPECTRUM        \n');
fprintf('=================================================================\n\n');

p = torsional_waveguide_core.get_default_parameters();
xi_vals = linspace(0.05, 6.0, 120);

fprintf('Tracking Branch 1 (Fundamental surface wave)...\n');
[~, om_b1] = torsional_waveguide_core.track_branch_continuation(xi_vals, p, 1);

fprintf('Tracking Branch 2 (Secondary mode)...\n');
[~, om_b2] = torsional_waveguide_core.track_branch_continuation(xi_vals, p, 2);

%% Plot EXACT Figure 5 (matching manuscript styling)
fig = figure('Name', 'Figure 05 - Dispersion Spectrum', 'Color', 'w', ...
             'Position', [150, 150, 560, 460]);
hold on;

% 1. Bulk shear cone: Omega = xi
plot([0, 6], [0, 6], 'k--', 'LineWidth', 1.3, 'DisplayName', '\Omega = \xi (bulk)');

% 2. Metamaterial plasma cutoff: Omega_p = 2.0
plot([0, 6], [p.Omega_p, p.Omega_p], 'r:', 'LineWidth', 1.4, 'DisplayName', '\Omega_p (cutoff)');

% 3. Branch 1: Blue line with open circles (markevery ~ 10 points)
valid1 = ~isnan(om_b1);
plot(xi_vals(valid1), om_b1(valid1), 'Color', [0 0.447 0.741], 'LineWidth', 1.8);
idx_mark1 = 1:10:length(xi_vals);
plot(xi_vals(idx_mark1), om_b1(idx_mark1), 'o', 'Color', [0 0.447 0.741], ...
     'MarkerFaceColor', 'w', 'MarkerSize', 6, 'LineWidth', 1.5, ...
     'DisplayName', 'branch 1 (surface wave)');

% 4. Branch 2: Orange line with open squares
valid2 = ~isnan(om_b2);
plot(xi_vals(valid2), om_b2(valid2), 'Color', [0.85 0.325 0.098], 'LineWidth', 1.8);
idx_mark2 = 1:10:length(xi_vals);
plot(xi_vals(idx_mark2), om_b2(idx_mark2), 's', 'Color', [0.85 0.325 0.098], ...
     'MarkerFaceColor', 'w', 'MarkerSize', 6, 'LineWidth', 1.5, ...
     'DisplayName', 'branch 2 (secondary)');

xlabel('\xi = kb', 'FontWeight', 'bold');
ylabel('\Omega = \omega b \surd(\rho_2 s_{44}^{(2)})', 'FontWeight', 'bold');
legend('Location', 'northeast');
grid on; box on;
xlim([0, 6]);
ylim([0, 2.6]);

saveas(fig, 'fig_dispersion_journal.png');
fprintf('Saved figure as: fig_dispersion_journal.png\n');
