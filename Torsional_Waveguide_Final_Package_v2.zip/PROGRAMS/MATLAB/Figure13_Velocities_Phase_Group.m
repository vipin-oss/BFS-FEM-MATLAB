%% =========================================================================
% FIGURE 13: PHASE AND GROUP VELOCITIES & BACKWARD-WAVE REGIME
% =========================================================================
% Manuscript Reference: Figure 13 (Section 4.3)
%
% Physical Phenomenon:
%   - Panel (a): Phase velocity vp = (Omega / xi) * v2 (m/s) for both
%     Branch 1 and Branch 2 compared against the bulk shear wave speed v2 = 1100.1 m/s.
%   - Panel (b): Group velocity vg = (dOmega / dxi) * v2 (m/s) demonstrating:
%       1. Sharp collapse from ~550 m/s to 0 m/s near xi ~ 0.8
%       2. A distinct negative group velocity (vg < 0) backward-wave regime!
%       3. Zero-group-velocity (ZGV) stationary acoustic trapping.
%
% Output: Generates EXACT Figure 13 (fig_velocities_journal.png)
% =========================================================================

close all; clc;

fprintf('=================================================================\n');
fprintf('  REPRODUCING FIGURE 13: PHASE AND GROUP VELOCITIES              \n');
fprintf('=================================================================\n\n');

p = torsional_waveguide_core.get_default_parameters();
xi_vals = linspace(0.05, 6.0, 120);

fprintf('Tracking Branch 1 and Branch 2 for velocity calculation...\n');
[~, om_b1] = torsional_waveguide_core.track_branch_continuation(xi_vals, p, 1);
[~, om_b2] = torsional_waveguide_core.track_branch_continuation(xi_vals, p, 2);

% Phase velocities
vp1 = (om_b1 ./ xi_vals) * p.v2;
vp2 = (om_b2 ./ xi_vals) * p.v2;

% Group velocities via central difference
dOm1_dxi = gradient(om_b1, xi_vals);
dOm2_dxi = gradient(om_b2, xi_vals);
vg1 = dOm1_dxi * p.v2;
vg2 = dOm2_dxi * p.v2;

%% Plot EXACT Figure 13 (matching manuscript layout)
fig = figure('Name', 'Figure 13 - Phase and Group Velocities', 'Color', 'w', ...
             'Position', [100, 100, 950, 420]);

% --- Subplot (a): Phase Velocity ---
subplot(1, 2, 1);
hold on;
plot([0, 6], [p.v2, p.v2], 'k--', 'LineWidth', 1.3, 'DisplayName', 'bulk v_2');

plot(xi_vals, vp1, 'Color', [0 0.447 0.741], 'LineWidth', 1.8);
idx_pts = 1:10:length(xi_vals);
plot(xi_vals(idx_pts), vp1(idx_pts), 'o', 'Color', [0 0.447 0.741], ...
     'MarkerFaceColor', 'w', 'MarkerSize', 6, 'LineWidth', 1.5, ...
     'DisplayName', 'branch 1 (surface wave)');

plot(xi_vals, vp2, 'Color', [0.85 0.325 0.098], 'LineWidth', 1.8);
plot(xi_vals(idx_pts), vp2(idx_pts), 's', 'Color', [0.85 0.325 0.098], ...
     'MarkerFaceColor', 'w', 'MarkerSize', 6, 'LineWidth', 1.5, ...
     'DisplayName', 'branch 2 (secondary)');

xlabel('\xi = kb', 'FontWeight', 'bold');
ylabel('v_p (m/s)', 'FontWeight', 'bold');
title('(a) phase velocity', 'FontWeight', 'bold');
legend('Location', 'northeast');
grid on; box on;
xlim([0, 6]);
ylim([-100, 1300]);
set(gca, 'YTick', [0, 300, 600, 900, 1200]);

% --- Subplot (b): Group Velocity ---
subplot(1, 2, 2);
hold on;
plot([0, 6], [p.v2, p.v2], 'k--', 'LineWidth', 1.3, 'DisplayName', 'bulk v_2');
plot([0, 6], [0, 0], 'k:', 'LineWidth', 1.0); % Zero line

plot(xi_vals, vg1, 'Color', [0 0.447 0.741], 'LineWidth', 1.8);
plot(xi_vals(idx_pts), vg1(idx_pts), 'o', 'Color', [0 0.447 0.741], ...
     'MarkerFaceColor', 'w', 'MarkerSize', 6, 'LineWidth', 1.5, ...
     'DisplayName', 'branch 1 (surface wave)');

plot(xi_vals, vg2, 'Color', [0.85 0.325 0.098], 'LineWidth', 1.8);
plot(xi_vals(idx_pts), vg2(idx_pts), 's', 'Color', [0.85 0.325 0.098], ...
     'MarkerFaceColor', 'w', 'MarkerSize', 6, 'LineWidth', 1.5, ...
     'DisplayName', 'branch 2 (secondary)');

xlabel('\xi = kb', 'FontWeight', 'bold');
ylabel('v_g (m/s)', 'FontWeight', 'bold');
title('(b) group velocity', 'FontWeight', 'bold');
legend('Location', 'northeast');
grid on; box on;
xlim([0, 6]);
ylim([-100, 1300]);
set(gca, 'YTick', [0, 300, 600, 900, 1200]);

saveas(fig, 'fig_velocities_journal.png');
fprintf('Saved figure as: fig_velocities_journal.png\n');
