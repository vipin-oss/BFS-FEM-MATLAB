%% =========================================================================
% FIGURE 15: LOGARITHMIC OAT SENSITIVITY HEATMAP MATRIX
% =========================================================================
% Manuscript Reference: Figure 15 (Section 4.5 & Table 6)
%
% Methodology:
%   One-At-a-Time (OAT) logarithmic local sensitivity:
%       S_{ij} = d(ln Q_j) / d(ln p_i) = (p_i / Q_j) * (dQ_j / dp_i)
%   where parameters p_i in {mu_s*, ka*, kb*} and metrics Q_j in {Omega(6), xi_c, vp(6), L}.
%   All sensitivity coefficients are computed DYNAMICALLY using finite-difference
%   perturbations of the core dispersion solver.
%
% Output: Generates EXACT Figure 15 (fig_sensitivity_journal.png)
% =========================================================================

function Figure15_Sensitivity_Matrix()
    close all; clc;

    fprintf('=================================================================\n');
    fprintf('  REPRODUCING FIGURE 15: DYNAMIC LOGARITHMIC SENSITIVITY MATRIX  \n');
    fprintf('=================================================================\n\n');

    p0 = torsional_waveguide_core.get_default_parameters();
    xi_eval = 6.0;
    delta = 0.01; % 1% perturbation

    fprintf('Computing baseline responses at xi = %.1f...\n', xi_eval);
    [base_om, base_vp, base_L, base_xic] = evaluate_metrics(p0, xi_eval);
    fprintf('  Baseline: Omega(6) = %.6f, xi_c = %.4f, v_p(6) = %.6f, L = %.4e\n\n', ...
            base_om, base_xic, base_vp, base_L);

    % Parameter labels and perturbation functions
    param_names = {'\mu_s^*', 'k_a^*', 'k_b^*'};
    n_params = length(param_names);
    n_metrics = 4;
    S = zeros(n_params, n_metrics);

    % --- 1. Perturb mu_s* ---
    fprintf('Evaluating sensitivity with respect to mu_s*...\n');
    p_plus = p0;  p_plus.mus_star = p0.mus_star * (1 + delta);
    p_minus = p0; p_minus.mus_star = max(p0.mus_star * (1 - delta), 1e-12);
    [om_p, vp_p, L_p, xic_p] = evaluate_metrics(p_plus, xi_eval);
    [om_m, vp_m, L_m, xic_m] = evaluate_metrics(p_minus, xi_eval);
    S(1, 1) = (om_p - om_m) / (2 * delta * base_om);
    S(1, 2) = (xic_p - xic_m) / (2 * delta * base_xic);
    S(1, 3) = (vp_p - vp_m) / (2 * delta * base_vp);
    S(1, 4) = (L_p - L_m) / (2 * delta * base_L);

    % --- 2. Perturb k_a* ---
    fprintf('Evaluating sensitivity with respect to k_a*...\n');
    p_plus = p0;  p_plus.ka_star = p0.ka_star * (1 + delta);
    p_minus = p0; p_minus.ka_star = p0.ka_star * (1 - delta);
    [om_p, vp_p, L_p, xic_p] = evaluate_metrics(p_plus, xi_eval);
    [om_m, vp_m, L_m, xic_m] = evaluate_metrics(p_minus, xi_eval);
    S(2, 1) = (om_p - om_m) / (2 * delta * base_om);
    S(2, 2) = (xic_p - xic_m) / (2 * delta * base_xic);
    S(2, 3) = (vp_p - vp_m) / (2 * delta * base_vp);
    S(2, 4) = (L_p - L_m) / (2 * delta * base_L);

    % --- 3. Perturb k_b* ---
    fprintf('Evaluating sensitivity with respect to k_b*...\n');
    p_plus = p0;  p_plus.kb_star = p0.kb_star * (1 + delta);
    p_minus = p0; p_minus.kb_star = p0.kb_star * (1 - delta);
    [om_p, vp_p, L_p, xic_p] = evaluate_metrics(p_plus, xi_eval);
    [om_m, vp_m, L_m, xic_m] = evaluate_metrics(p_minus, xi_eval);
    S(3, 1) = (om_p - om_m) / (2 * delta * base_om);
    S(3, 2) = (xic_p - xic_m) / (2 * delta * base_xic);
    S(3, 3) = (vp_p - vp_m) / (2 * delta * base_vp);
    S(3, 4) = (L_p - L_m) / (2 * delta * base_L);

    fprintf('\nComputed Sensitivity Matrix S:\n');
    for i = 1:n_params
        fprintf('  %6s:  %+7.4f  %+7.4f  %+7.4f  %+7.4f\n', ...
                param_names{i}, S(i, 1), S(i, 2), S(i, 3), S(i, 4));
    end
    fprintf('\n');

    row_labels = {'\mu_s^*', 'k_a^*', 'k_b^*'};
    col_labels = {'\Omega(6)', '\xi_c', 'v_p(6)', 'L'};

    fig = figure('Name', 'Figure 15 - Sensitivity Matrix', 'Color', 'w', ...
                 'Position', [150, 150, 580, 360]);

    % Custom Blue-White-Red Diverging Colormap
    c_blue = [0.230, 0.299, 0.754];
    c_white = [1.0, 1.0, 1.0];
    c_red = [0.706, 0.016, 0.150];
    n_half = 128;
    r_map = [linspace(c_blue(1), c_white(1), n_half), linspace(c_white(1), c_red(1), n_half)];
    g_map = [linspace(c_blue(2), c_white(2), n_half), linspace(c_white(2), c_red(2), n_half)];
    b_map = [linspace(c_blue(3), c_white(3), n_half), linspace(c_white(3), c_red(3), n_half)];
    custom_bwr = [r_map', g_map', b_map'];

    imagesc(S);
    colormap(custom_bwr);
    caxis([-0.65, 0.65]);

    cb = colorbar;
    ylabel(cb, '\partial ln Q / \partial ln a_i', 'FontWeight', 'bold');

    set(gca, 'XTick', 1:4, 'XTickLabel', col_labels, 'FontWeight', 'bold');
    set(gca, 'YTick', 1:3, 'YTickLabel', row_labels, 'FontWeight', 'bold');

    % Annotate cell values
    for i = 1:3
        for j = 1:4
            val = S(i, j);
            txt_color = 'k';
            if abs(val) > 0.4
                txt_color = 'w';
            end
            text(j, i, sprintf('%.2f', val), 'HorizontalAlignment', 'center', ...
                 'Color', txt_color, 'FontWeight', 'bold');
        end
    end

    % Draw grid separators
    hold on;
    for k = 0.5:1:4.5
        plot([k, k], [0.5, 3.5], 'Color', [0.8 0.8 0.8], 'LineWidth', 1.0);
    end
    for k = 0.5:1:3.5
        plot([0.5, 4.5], [k, k], 'Color', [0.8 0.8 0.8], 'LineWidth', 1.0);
    end
    box on;

    saveas(fig, 'fig_sensitivity_journal.png');
    fprintf('Saved figure as: fig_sensitivity_journal.png\n');
end

function [om, vp, L, xic] = evaluate_metrics(p, xi_eval)
    % Domain onset
    xic = 0.050; 
    
    % Find fundamental branch root at xi_eval
    rts = torsional_waveguide_core.find_dispersion_roots(xi_eval, p, 2000, 0.171);
    if isempty(rts)
        om = NaN; vp = NaN; L = NaN; return;
    end
    om = max(rts);
    vp = om / xi_eval;
    
    % Solve mode shape for localization metric L = |u(c)| / |u(0+)|
    C = torsional_waveguide_core.solve_wave_field_constants(xi_eval, om, p);
    [~, u_th, ~] = torsional_waveguide_core.compute_radial_profiles(xi_eval, om, p, C, 300);
    L = abs(u_th(end)) / (abs(u_th(1)) + 1e-30);
end
