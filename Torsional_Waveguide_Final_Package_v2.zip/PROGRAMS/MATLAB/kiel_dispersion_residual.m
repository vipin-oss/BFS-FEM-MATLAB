function res = kiel_dispersion_residual(w, k, a, rho1, s0, wp, rho2, s44_2)
% KIEL_DISPERSION_RESIDUAL
% Evaluates the exact dispersion residual of Kiełczyński et al. (Sensors 2025, 25:143):
%   F_Kiel(w, k) = [K2(gamma2*a) / K1(gamma2*a)] + ...
%                  [s44^(2) / s44^(1)(w)] * (gamma1 / gamma2) * ...
%                  [I2(gamma1*a) / I1(gamma1*a)] = 0
%
% Arguments:
%   w     : angular frequency (rad/s)
%   k     : axial wavenumber (rad/m)
%   a     : core radius (m) = 0.01 m
%   rho1  : ST-Quartz metamaterial core density (kg/m^3) = 2650
%   s0    : high-frequency metamaterial compliance (Pa^-1) = 1.474e-11
%   wp    : angular plasma frequency (rad/s) = 2*pi*1e6
%   rho2  : PMMA cladding density (kg/m^3) = 1180
%   s44_2 : PMMA shear compliance (Pa^-1) = 70.03e-11

    s1 = s0 * (1.0 - (wp / w)^2);
    g1_sq = k^2 - rho1 * (w^2) * s1;
    g2_sq = k^2 - rho2 * (w^2) * s44_2;
    
    if (g1_sq <= 0) || (g2_sq <= 0) || (s1 >= 0)
        res = NaN;
        return;
    end
    
    g1 = sqrt(g1_sq);
    g2 = sqrt(g2_sq);
    
    % Eq. (14) of Kiełczyński et al. (2025)
    term1 = besselk(2, g2 * a) / besselk(1, g2 * a);
    term2 = (s44_2 / s1) * (g1 / g2) * (besseli(2, g1 * a) / besseli(1, g1 * a));
    res = term1 + term2;
end
