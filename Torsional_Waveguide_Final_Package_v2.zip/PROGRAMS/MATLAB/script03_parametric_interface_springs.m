%% =========================================================================
% SCRIPT 03: PARAMETRIC SWEEP OF INTERFACE SPRING STIFFNESSES
% =========================================================================
% Physical Background:
%   Interfaces at r = a (core/intermediate layer) and r = b (intermediate/
%   metamaterial shell) are modeled with linear shear springs:
%       sigma_r_theta(a) = ka * [u_theta(a+) - u_theta(a-)]
%       sigma_r_theta(b) = kb * [u_theta(b+) - u_theta(b-)]
%   Dimensionless spring stiffness:
%       k* = k * b * s44_2
%   - k* -> infty represents a perfectly welded, rigid interface (continuous displacement).
%   - k* -> 0 represents a complete slip/debonded interface (zero stress transfer).
%   - Finite k* captures adhesive compliance, aging, micro-flaws, or boundary layers.
%
% What this script does (FROM ZERO, NO PRECOMPUTED DATA):
%   1. Sweeps interface stiffness k* = ka* = kb* in {0.5, 2.0, 5.0, 20.0, 100.0}.
%   2. Solves the 5x5 dispersion relation det(M) = 0 from scratch across xi.
%   3. Quantifies how compliant interfaces alter wave localization and cutoff.
%   4. Generates publication-ready comparative dispersion plots.
% =========================================================================

close all;

fprintf('=================================================================\n');
fprintf('  SCRIPT 03: INTERFACE SPRING STIFFNESS STUDY FROM SCRATCH       \n');
fprintf('=================================================================\n\n');

p_base = torsional_waveguide_core.get_default_parameters();
% Set fixed baseline surface elasticity
p_base.mus_star = 0.7;
p_base.tau0_star = 0.0;

spring_values = [0.5, 2.0, 5.0, 20.0, 100.0];
colors = {[0.85 0.325 0.098], [0.929 0.694 0.125], [0 0.447 0.741], ...
          [0.494 0.184 0.556], [0.466 0.674 0.188]};
line_styles = {'r:', 'm-.', 'b-', 'c--', 'k-'};

xi_grid = linspace(0.1, 5.0, 80);

figure('Name', 'Interface Spring Influence', 'Color', 'w', 'Position', [200, 200, 800, 480]);
hold on;

results_table = [];

fprintf('Tracing dispersion branches for varying interface stiffness...\n');
for i = 1:length(spring_values)
    p = p_base;
    k_val = spring_values(i);
    p.ka_star = k_val;
    p.kb_star = k_val;
    
    fprintf('  Evaluating ka* = kb* = %.1f ...\n', k_val);
    
    [xi_sol, Om_sol] = torsional_waveguide_core.track_branch_continuation(xi_grid, p, 1);
    
    valid = ~isnan(Om_sol);
    xi_v = xi_sol(valid);
    Om_v = Om_sol(valid);
    
    if ~isempty(Om_v)
        plot(xi_v, Om_v, line_styles{i}, 'LineWidth', 2.0, 'Color', colors{i}, ...
             'DisplayName', sprintf('k_a^* = k_b^* = %.1f', k_val));
         
        [~, idx4] = min(abs(xi_v - 4.0));
        om_at_4 = Om_v(idx4);
        results_table = [results_table; k_val, om_at_4];
    end
end

plot(xi_grid, xi_grid, 'k:', 'LineWidth', 1.2, 'DisplayName', 'Bulk Cone (\Omega = \xi)');

xlabel('Dimensionless Axial Wavenumber \xi = k b', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('Dimensionless Frequency \Omega', 'FontSize', 11, 'FontWeight', 'bold');
title('Influence of Interface Spring Compliance on Dispersion Curves', 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'northwest');
grid on;
box on;
xlim([0, 5.0]);

% Print Quantitative Summary
fprintf('\n-------------------------------------------------------------\n');
fprintf('  Summary of Interface Stiffness Effect at xi = 4.0:\n');
fprintf('-------------------------------------------------------------\n');
fprintf('  Spring Stiffness (k*) |   Omega(xi=4.0)   |  Interface Character\n');
fprintf('-------------------------------------------------------------\n');
for k = 1:size(results_table, 1)
    k_val = results_table(k, 1);
    om_val = results_table(k, 2);
    if k_val <= 1.0
        desc = 'Highly Compliant (Soft bond)';
    elseif k_val >= 50.0
        desc = 'Asymptotically Rigid (Near-welded)';
    else
        desc = 'Moderate Elastic Coupling';
    end
    fprintf('        %5.1f          |      %7.4f      |  %s\n', k_val, om_val, desc);
end
fprintf('-------------------------------------------------------------\n');
fprintf('Physical Takeaway:\n');
fprintf('  More compliant springs (lower k*) isolate the outer metamaterial\n');
fprintf('  shell from the core, concentrating acoustic energy at the outer shell.\n\n');
