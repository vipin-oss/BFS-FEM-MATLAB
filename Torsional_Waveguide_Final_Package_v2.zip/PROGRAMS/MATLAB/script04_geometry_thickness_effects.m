%% =========================================================================
% SCRIPT 04: WAVEGUIDE GEOMETRY & SHELL THICKNESS EFFECTS
% =========================================================================
% Physical Background:
%   The geometry of the cylindrical waveguide is defined by:
%     - Core radius: a (dimensionless ratio alpha = a/b < 1)
%     - Intermediate layer outer radius: b (reference length scale)
%     - Outer metamaterial shell radius: c (ratio beta = c/b > 1)
%   Outer shell dimensionless thickness is Delta* = (c - b)/b = beta - 1.
%
% What this script does (FROM ZERO, NO PRECOMPUTED DATA):
%   1. Subplot 1: Sweeps shell thickness beta in {1.2, 1.4, 1.6, 1.8, 2.0}
%      at fixed core ratio alpha = 0.5.
%   2. Subplot 2: Sweeps core ratio alpha in {0.3, 0.5, 0.7}
%      at fixed shell ratio beta = 1.5.
%   3. Solves the 5x5 dispersion relation from scratch for every case.
%   4. Demonstrates how geometric tuning serves as an acoustic filter.
% =========================================================================

close all;

fprintf('=================================================================\n');
fprintf('  SCRIPT 04: GEOMETRY AND SHELL THICKNESS EFFECTS FROM SCRATCH   \n');
fprintf('=================================================================\n\n');

p_base = torsional_waveguide_core.get_default_parameters();
p_base.ka_star = 5.0;
p_base.kb_star = 5.0;
p_base.mus_star = 0.7;
p_base.tau0_star = 0.0;

xi_grid = linspace(0.1, 4.5, 60);

figure('Name', 'Geometric Parametric Effects', 'Color', 'w', 'Position', [100, 100, 950, 420]);

%% Panel (a): Shell Thickness Sweep (beta = c/b)
subplot(1, 2, 1);
hold on;
beta_vals = [1.2, 1.4, 1.6, 1.8, 2.0];
colors_beta = {[0.2 0.2 0.2], [0 0.447 0.741], [0.85 0.325 0.098], [0.494 0.184 0.556], [0.466 0.674 0.188]};

fprintf('--- Sweeping Metamaterial Shell Thickness beta = c/b ---\n');
for i = 1:length(beta_vals)
    p = p_base;
    p.beta = beta_vals(i);
    p.c = p.beta * p.b;
    
    fprintf('  Solving for beta = %.1f (shell thickness = %.1f * b)...\n', p.beta, p.beta - 1.0);
    [xi_sol, Om_sol] = torsional_waveguide_core.track_branch_continuation(xi_grid, p, 1);
    
    valid = ~isnan(Om_sol);
    if any(valid)
        plot(xi_sol(valid), Om_sol(valid), 'LineWidth', 2.0, 'Color', colors_beta{i}, ...
             'DisplayName', sprintf('\\beta = %.1f (\\Delta^* = %.1f)', p.beta, p.beta - 1.0));
    end
end

plot(xi_grid, xi_grid, 'k:', 'LineWidth', 1.2, 'DisplayName', 'Bulk Cone');
xlabel('Dimensionless Axial Wavenumber \xi = k b', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('Dimensionless Frequency \Omega', 'FontSize', 11, 'FontWeight', 'bold');
title('(a) Metamaterial Shell Thickness (\beta = c/b)', 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'northwest');
grid on; box on; xlim([0, 4.5]);

%% Panel (b): Core Radius Ratio Sweep (alpha = a/b)
subplot(1, 2, 2);
hold on;
alpha_vals = [0.3, 0.5, 0.7];
colors_alpha = {[0 0.5 0], [0 0.2 0.8], [0.8 0 0]};

fprintf('\n--- Sweeping Core Radius Ratio alpha = a/b ---\n');
for i = 1:length(alpha_vals)
    p = p_base;
    p.alpha = alpha_vals(i);
    p.a = p.alpha * p.b;
    
    fprintf('  Solving for alpha = %.2f (core radius a = %.2f * b)...\n', p.alpha, p.alpha);
    [xi_sol, Om_sol] = torsional_waveguide_core.track_branch_continuation(xi_grid, p, 1);
    
    valid = ~isnan(Om_sol);
    if any(valid)
        plot(xi_sol(valid), Om_sol(valid), 'LineWidth', 2.0, 'Color', colors_alpha{i}, ...
             'DisplayName', sprintf('\\alpha = %.2f', p.alpha));
    end
end

plot(xi_grid, xi_grid, 'k:', 'LineWidth', 1.2, 'DisplayName', 'Bulk Cone');
xlabel('Dimensionless Axial Wavenumber \xi = k b', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('Dimensionless Frequency \Omega', 'FontSize', 11, 'FontWeight', 'bold');
title('(b) Metallic Core Ratio (\alpha = a/b)', 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'northwest');
grid on; box on; xlim([0, 4.5]);

fprintf('\nGeometric parametric analysis finished successfully.\n');
