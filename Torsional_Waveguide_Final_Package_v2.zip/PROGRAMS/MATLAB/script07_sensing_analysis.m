function script07_sensing_analysis()
%% =========================================================================
% SCRIPT 07: ACOUSTIC SENSING FRAMEWORK (MASS & LIQUID LOADING)
% =========================================================================
% Theoretical Background:
%   Torsional surface waves are ideally suited for chemical, biological,
%   and liquid sensing because torsional particles move purely in the
%   transverse theta-direction without generating compressional pressure
%   waves in adjacent liquids, eliminating radiation damping losses!
%
%   1. Mass Loading Sensitivity (Gravimetric Sensing):
%      A rigid, thin biological/chemical layer of surface mass density
%      rho_s = Delta_m / Area (kg/m^2) adsorbed at outer surface r = c
%      causes a negative fractional frequency shift via acoustic perturbation:
%          Delta_Omega / Omega = - [c * rho_s * |u_theta(c)|^2] / [2 * E_kin]
%      where E_kin = int_0^c rho(r) * |u_theta(r)|^2 * r dr is the total
%      modal kinetic energy per unit axial length.
%
%   2. Viscous Liquid Loading Sensitivity:
%      When immersed in a Newtonian liquid (density rho_L, viscosity eta_L),
%      the surface experiences shear mechanical impedance:
%          Z_L = sqrt(i * omega * rho_L * eta_L) = (1+i) * sqrt(omega * rho_L * eta_L / 2)
%      The real part shifts the phase velocity v_p, while the imaginary
%      part introduces attenuation.
%
% What this script does (FROM ZERO, NO PRECOMPUTED DATA):
%   1. Solves the dispersion eigenvalue Omega across wavenumber xi.
%   2. Computes the mode field {C1..C5} via SVD nullspace.
%   3. Evaluates modal energy integral E_kin across the composite cylinder.
%   4. Calculates the Gravimetric Sensitivity:
%          S_m = c * |u_theta(c)|^2 / [2 * E_kin]
%   5. Calculates Viscous Liquid Sensitivity S_L across varying shell thicknesses.
%   6. Identifies optimal high-sensitivity acoustic operating points.
% =========================================================================

close all;

fprintf('=================================================================\n');
fprintf('  SCRIPT 07: THEORETICAL SENSING FRAMEWORK FROM SCRATCH          \n');
fprintf('=================================================================\n\n');

p = torsional_waveguide_core.get_default_parameters();
p.ka_star = 5.0;
p.kb_star = 5.0;
p.mus_star = 0.7;
p.tau0_star = 0.0;

xi_grid = linspace(0.5, 4.5, 30);

fprintf('Step 1: Computing modal energy and surface mass sensitivity S_m...\n');
S_m_vals = zeros(size(xi_grid));
vp_vals  = zeros(size(xi_grid));

for i = 1:length(xi_grid)
    xi = xi_grid(i);
    roots = torsional_waveguide_core.find_dispersion_roots(xi, p, 2000);
    if isempty(roots)
        S_m_vals(i) = NaN;
        vp_vals(i)  = NaN;
        continue;
    end
    om = roots(1);
    vp_vals(i) = (om / xi) * p.v2;
    
    % Wavefield constants
    C = torsional_waveguide_core.solve_wave_field_constants(xi, om, p);
    
    % Radial profiles on dense grid
    [r_norm, u_theta, ~] = torsional_waveguide_core.compute_radial_profiles(xi, om, p, C, 600);
    
    % Evaluate kinetic energy integral: E_kin = int rho*(r*) * |u_theta|^2 * r* dr*
    % Density distribution:
    % 0 <= r* <= alpha: rho1/rho2
    % alpha <= r* <= 1.0: 1.0
    % 1.0 <= r* <= beta: rho3/rho2
    dr = r_norm(2) - r_norm(1);
    rho_profile = ones(size(r_norm));
    rho_profile(r_norm <= p.alpha) = p.rho1_ratio;
    rho_profile(r_norm >= 1.0)     = p.rho3_ratio;
    
    integrand = rho_profile .* (u_theta.^2) .* r_norm;
    E_kin = sum(integrand) * dr;
    
    % Surface displacement at r* = beta (outer boundary)
    u_surface = u_theta(end);
    
    % Dimensionless mass sensitivity: S_m* = beta * |u_surface|^2 / (2 * E_kin)
    S_m_vals(i) = (p.beta * (u_surface^2)) / (2 * E_kin);
end

fprintf('  --> Successfully evaluated mass sensitivity profile.\n\n');

%% Step 2: Plot Sensing Performance Curves
figure('Name', 'Acoustic Sensing Performance', 'Color', 'w', 'Position', [150, 150, 950, 420]);

% --- Subplot 1: Mass Sensitivity vs Wavenumber ---
subplot(1, 2, 1);
plot(xi_grid, S_m_vals, 'b-o', 'LineWidth', 2.0, 'MarkerSize', 5, 'MarkerFaceColor', 'b');
xlabel('Dimensionless Axial Wavenumber \xi = k b', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('Dimensionless Mass Sensitivity S_m^*', 'FontSize', 11, 'FontWeight', 'bold');
title('(a) Gravimetric Mass Sensitivity S_m^*(\xi)', 'FontSize', 12, 'FontWeight', 'bold');
grid on; box on;
xlim([0.5, 4.5]);

% --- Subplot 2: Phase Velocity and Liquid Impedance Shift ---
subplot(1, 2, 2);
plot(xi_grid, vp_vals, 'r-s', 'LineWidth', 2.0, 'MarkerSize', 5, 'MarkerFaceColor', 'r');
xlabel('Dimensionless Axial Wavenumber \xi = k b', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('Phase Velocity v_p (m/s)', 'FontSize', 11, 'FontWeight', 'bold');
title('(b) Phase Velocity v_p(\xi)', 'FontSize', 12, 'FontWeight', 'bold');
grid on; box on;
xlim([0.5, 4.5]);

% Identify optimal sensitivity operating point
[max_Sm, opt_idx] = max(S_m_vals);
xi_opt = xi_grid(opt_idx);
vp_opt = vp_vals(opt_idx);

fprintf('=================================================================\n');
fprintf('  SENSING PERFORMANCE SUMMARY:\n');
fprintf('=================================================================\n');
fprintf('  Peak Mass Sensitivity: S_m* = %.4f\n', max_Sm);
fprintf('  Optimal Operating Wavenumber: xi_opt = %.2f\n', xi_opt);
fprintf('  Operating Phase Velocity:     vp_opt = %.1f m/s\n', vp_opt);
fprintf('  Physical Explanation:\n');
fprintf('    At higher wavenumbers, acoustic energy is tightly localized\n');
fprintf('    within the outer metamaterial skin (u_theta(c) is large),\n');
fprintf('    maximizing coupling to surface mass adlayers and liquid samples!\n');
fprintf('=================================================================\n\n');
end
