#!/usr/bin/env python3
"""endpoint_max_check.py — DEFINITIVE check of the manuscript claim (line 781):

    "|u_theta(r)| exhibits zero interior local maxima in the open shell
     interval r in (b, c) (n_max = 0) ... the spatial maximum is strictly
     confined to the shell boundaries."

The check does EXACTLY four things and nothing else:
  (1) find a root (xi, Omega);
  (2) build the null-space eigenvector v (last right singular vector of M);
  (3) evaluate |u(r)| as a PLAIN ARRAY OF NUMBERS on a fine grid in [b, c]
      (r* = r/b in [1.0, 1.5]);
  (4) locate the largest value of that plain array by literal comparison
      (np.argmax) and count interior local maxima with a literal 3-point
      comparison u[i] > u[i-1] and u[i] > u[i+1] on interior indices only.

No derivative test. No sign interpretation. No complex-phase reasoning.
Baseline parameters: ka*=kb*=5, mu_s*=1e-5, tau0*=2e-6.
(Note: tau0 does not enter the matrix M at all -- it cancels identically in
the Gurtin-Murdoch relation -- so tau0*=2e-6 and 0 are numerically identical.)
"""
import sys
import numpy as np
from scipy.special import iv, kv
import core as C

KA, KB, MUS, TAU0 = 5.0, 5.0, 1.0e-5, 2.0e-6
NR = 20001                       # fine grid over [b, c]
R = np.linspace(1.0, C.beta, NR)  # r* = r/b in [1.0, 1.5]


def u3_array(xi, om):
    """Steps (2)+(3): null-space eigenvector -> plain |u(r*)| array on [b,c]."""
    M = C.Mmat(xi, om, KA, KB, MUS, TAU0)
    assert M is not None
    U, s, Vh = np.linalg.svd(M)
    v = Vh[-1]                                  # unit-norm null vector
    A1, B1, B2, C1, C2 = v
    g3 = np.sqrt(C.gammas2(xi, om, KA, KB, MUS, TAU0)[2])
    u = np.abs(C1*iv(1, g3*R) + C2*kv(1, g3*R))  # plain array of magnitudes
    detM = abs(np.linalg.det(M))
    resid = np.linalg.norm(M @ v)/np.linalg.norm(M, 'fro')
    return u, detM, resid


def interior_extrema(u):
    """Literal 3-point comparison on interior indices only."""
    imax = np.where((u[1:-1] > u[:-2]) & (u[1:-1] > u[2:]))[0] + 1
    imin = np.where((u[1:-1] < u[:-2]) & (u[1:-1] < u[2:]))[0] + 1
    return imax, imin


def audit_point(xi, om, tag, verbose=False):
    u, detM, resid = u3_array(xi, om)
    imax, imin = interior_extrema(u)
    iam = int(np.argmax(u))                     # step (4): literal argmax
    at = ("LEFT endpoint r*=1.0000 (r=b+)" if iam == 0 else
          "RIGHT endpoint r*=1.5000 (r=c)" if iam == NR-1 else
          "INTERIOR r*=%.4f  <-- VIOLATION" % R[iam])
    print("  %-14s |det(M)|=%.2e resid=%.2e | argmax |u|=%.6f at %s | "
          "interior maxima=%d  interior minima=%d"
          % (tag, detM, resid, u[iam], at, len(imax), len(imin)), flush=True)
    return len(imax), (iam == 0 or iam == NR-1), u, imax, imin


print("=" * 78)
print("(1) CLAIMED COUNTEREXAMPLE: xi = 1.00518395 (tracked 300-pt grid node)")
print("=" * 78)
xi_c = 1.00518395
roots = C.find_roots_at_xi(xi_c, KA, KB, MUS, TAU0)   # fresh full-scan root
print("  full-scan roots at xi=%.8f (descending): %s"
      % (xi_c, ["%.9f" % r for r in roots]))
om_c = roots[0]
u, detM, resid = u3_array(xi_c, om_c)
print("  root used: Omega=%.9f   |det(M)|=%.3e  resid=%.3e" % (om_c, detM, resid))
print("  plain |u(r*)| array at the r* values from the disputed table:")
for rs in [1.0000, 1.0050, 1.0100, 1.0131, 1.0150, 1.0300, 1.1000, 1.5000]:
    i = int(np.argmin(np.abs(R - rs)))
    print("      r*=%.4f   |u(r)|=%.6f" % (R[i], u[i]))
imax, imin = interior_extrema(u)
print("  interior local maxima indices:", list(imax),
      "-> r* =", ["%.4f" % R[i] for i in imax])
print("  interior local minima indices:", list(imin),
      "-> r* =", ["%.4f" % R[i] for i in imin])
iam = int(np.argmax(u))
print("  argmax of the plain array: |u|=%.6f at r*=%.4f  (%s endpoint)"
      % (u[iam], R[iam], "left (b+)" if iam == 0 else
         "right (c)" if iam == NR-1 else "INTERIOR <-- VIOLATION"))

print()
print("=" * 78)
print("(2) SYSTEMATIC AUDIT: every point of the tracked branch-1 grid,")
print("    xi in [0.05, 6.0] (300 points, exactly the manuscript Table 5 grid)")
print("=" * 78)
xi_grid = np.linspace(0.05, 6.0, 300)
b1 = C.track_branch(KA, KB, MUS, TAU0, xi_grid, 0.05, 1)
ok = b1["ok_mask"]
print("  tracked: %d/%d points, jumps=%d" % (ok.sum(), len(ok), len(b1["jumps"])))

n_viol_max = 0
n_viol_argmax = 0
transition_xi = None
prev_side = None
sample = {0.05, 0.1, 0.5, 1.0, 1.00518395, 1.5, 2.0, 3.0, 4.0, 5.0, 6.0}
for xi, om in zip(b1["xi"][ok], b1["om"][ok]):
    u, detM, resid = u3_array(xi, om)
    imax, imin = interior_extrema(u)
    iam = int(np.argmax(u))
    endpoint = (iam == 0 or iam == NR-1)
    if len(imax) > 0:
        n_viol_max += 1
        print("  VIOLATION interior max at xi=%.6f: r*=%s"
              % (xi, ["%.4f" % R[i] for i in imax]))
    if not endpoint:
        n_viol_argmax += 1
        print("  VIOLATION argmax interior at xi=%.6f: r*=%.4f" % (xi, R[iam]))
    side = "b+" if iam == 0 else "c"
    if prev_side is not None and side != prev_side and transition_xi is None:
        transition_xi = xi
    prev_side = side
    if any(abs(xi - s) < 1e-9 for s in sample):
        audit_point(xi, om, "xi=%.6f" % xi)

print()
print("  ---- audit summary over all %d tracked points ----" % ok.sum())
print("  points with an interior local maximum of |u| in (b,c): %d" % n_viol_max)
print("  points whose plain-array argmax is NOT an endpoint   : %d" % n_viol_argmax)
if transition_xi is not None:
    print("  global-max side transition (c -> b+) first occurs at xi ~ %.4f"
          % transition_xi)

print()
print("VERDICT: %s"
      % ("CLAIM CONFIRMED -- zero interior local maxima in (b,c) at every "
         "audited xi; argmax always at r=b+ or r=c."
         if (n_viol_max == 0 and n_viol_argmax == 0)
         else "CLAIM VIOLATED -- see violations above."))
