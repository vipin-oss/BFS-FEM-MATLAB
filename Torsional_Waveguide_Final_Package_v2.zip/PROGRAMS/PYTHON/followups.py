#!/usr/bin/env python3
"""followups.py — (A) clean same-abscissa baseline comparison (fixes the
grid-offset artifact of the first scoping_check run), and (B) provenance
tests for the Table-7 row-9 values (Omega(6)=0.6152, xi_c=0.180) at mu_s*=0.7.
"""
import numpy as np
from scipy.optimize import brentq
import core as C

XI300 = np.linspace(0.05, 6.0, 300)

print("=" * 74)
print("(A) BASELINE via track_physical_branch vs direct continuation,")
print("    compared at the SAME xi (both curves interpolated at identical")
print("    abscissae -- the previous table mixed node values with interp).")
print("=" * 74)
cur, cur_on = C.track_physical_branch(5.0, 5.0, 1e-5, 2e-6, XI300)
b1 = C.track_branch(5.0, 5.0, 1e-5, 2e-6, XI300, 0.05, 1)
okc, ok1 = cur["ok_mask"], b1["ok_mask"]
xc, oc = cur["xi"][okc], cur["om"][okc]
x1, o1 = b1["xi"][ok1], b1["om"][ok1]
print("  current track_physical_branch: onset=%.4f" % cur_on)
print("        xi      Omega_direct   Omega_tpb      |diff|   (same abscissa)")
for xr in [0.05, 0.1, 0.1241, 0.2, 0.5, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0]:
    od = float(np.interp(xr, x1, o1))
    if xr >= xc[0] - 1e-12:
        ocv = float(np.interp(xr, xc, oc))
        print("      %7.4f   %.9f   %.9f   %.2e" % (xr, od, ocv, abs(od-ocv)))
    else:
        print("      %7.4f   %.9f   (xi < onset %.4f: not covered)" % (xr, od, cur_on))
# exact shared-node comparison
common = np.isin(np.round(x1, 12), np.round(xc, 12))
d = np.abs(np.interp(xc, x1, o1) - oc)
print("  shared-node comparison over %d nodes: max|dOmega| = %.3e" % (len(xc), d.max()))

print()
print("=" * 74)
print("(B) Table-7 row 9 provenance: manuscript says Omega(6)=0.6152, xi_c=0.180")
print("    for mu_s*=0.7 (ka=kb=5, tau0=0). Current code gives 0.617963/0.1834.")
print("=" * 74)
# exact root at xi=6, G=0.7 (independent of any tracking)
f = lambda o: C.Dfun(6.0, o, 5.0, 5.0, 0.7, 0.0)
om6 = brentq(f, 0.55, 0.70, xtol=1e-14, rtol=8.9e-16)
print("  exact root at xi=6, G=0.7:            Omega = %.9f  (|det|=%.2e)"
      % (om6, abs(f(om6))))
# hypothesis 1: 0.6152 = Omega at some xi < 6 on the G=0.7 curve
print("  Omega(xi) on the tracked G=0.7 physical branch:")
b, on = C.track_physical_branch(5.0, 5.0, 0.7, 0.0, XI300)
ok = b["ok_mask"]
for xs in [4.0, 5.0, 5.8, 5.9, 5.95, 6.0]:
    print("      xi=%.2f  Omega=%.6f" % (xs, float(np.interp(xs, b["xi"][ok], b["om"][ok]))))
try:
    xi_hit = brentq(lambda x: float(np.interp(x, b["xi"][ok], b["om"][ok])) - 0.6152,
                    4.0, 6.0, xtol=1e-10)
    print("  -> 0.6152 equals Omega(xi*) at xi* = %.6f" % xi_hit)
except ValueError:
    print("  -> 0.6152 is NOT attained anywhere on the G=0.7 curve for xi in [4,6]")
# hypothesis 2: 0.6152 = Omega(6) at a slightly different G
g_hit = brentq(lambda G: brentq(lambda o: C.Dfun(6.0, o, 5.0, 5.0, G, 0.0),
                                0.5, 0.75, xtol=1e-13) - 0.6152, 0.6, 0.7, xtol=1e-8)
print("  -> 0.6152 equals Omega(xi=6) at G = %.6f" % g_hit)
# hypothesis 3: true (fine-grid) onset at G=0.7
def n_roots(xi, G, n=6000):
    return len(C.find_roots_at_xi(xi, 5.0, 5.0, G, 0.0, ngrid=n))
lo, hi = 0.15, 0.19
for _ in range(40):
    mid = 0.5*(lo+hi)
    if n_roots(mid, 0.7) >= 2:
        hi = mid
    else:
        lo = mid
print("  true rank-2 onset at G=0.7 (bisection, 6000-pt scans): xi_on in [%.6f, %.6f]"
      % (lo, hi))
print("  -> manuscript 0.180 is consistent with the TRUE onset (~0.180x), while the")
print("     shipped n_on=200 search on [0.05,3] quantizes it to 0.1834.")
print("DONE followups")
