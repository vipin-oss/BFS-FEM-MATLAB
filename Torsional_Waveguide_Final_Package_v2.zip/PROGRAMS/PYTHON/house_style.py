#!/usr/bin/env python3
"""house_style.py — the ONE shared visual theme for every journal figure.

Every figure-producing script in this package (make_journal_previews.py,
make_mode_previews.py) imports its styling from this single module so that
all figures are provably produced from the same code path: same serif
font family, same absolute font sizes (chosen for the actual print sizes
of the single-column manuscript, \\textwidth = 6.06 in), same palette,
same line/marker/legend/grid conventions.

Print-size basis (measured from the compiled PDF):
    0.95\\textwidth = 5.76 in   (two-panel figures)
    0.90\\textwidth = 5.45 in   (single figures)
    0.80\\textwidth = 4.85 in   (heatmap)
    0.70\\textwidth = 4.24 in   (3D surface)
"""
import numpy as np
import matplotlib
from matplotlib.colors import LinearSegmentedColormap

from parula_anchors import PARULA_ANCHORS

# ---- real MATLAB parula(256) (piecewise-linear control-point definition)
PARULA = LinearSegmentedColormap.from_list("parula", PARULA_ANCHORS, N=256)

# ---- palette (MATLAB default lines colors; consistent everywhere)
BLUE   = (0.000, 0.447, 0.741)
ORANGE = (0.850, 0.325, 0.098)
GREEN  = (0.466, 0.674, 0.188)
RED    = (0.850, 0.325, 0.098)   # reserved: use PURPLE as 5th
PURPLE = (0.494, 0.184, 0.556)
PALETTE5 = [BLUE, ORANGE, GREEN, (0.929, 0.694, 0.125), PURPLE]

# layer shading (three-layer structure; used by every mode-shape panel)
REGION_CORE  = (0.85, 0.88, 0.96)
REGION_ELAST = (0.97, 0.94, 0.82)
REGION_SHELL = (0.90, 0.96, 0.90)

# layer interfaces in mm (b = 0.35016 mm scale)
A_MM = 0.17508
B_MM = 0.35016
C_MM = 0.52524


def setup():
    """Apply the shared rcParams. Call once at import time in each script."""
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "font.family": "serif", "font.serif": ["DejaVu Serif"], "font.size": 10,
        "axes.linewidth": 0.8, "axes.grid": True, "grid.linewidth": 0.4,
        "xtick.direction": "in", "ytick.direction": "in",
        "xtick.labelsize": 9, "ytick.labelsize": 9,
        "axes.titlesize": 10.5,
        "legend.fontsize": 8.5,
        "figure.dpi": 150, "savefig.dpi": 300,
    })


def apply(ax, grid=True):
    """House style for one 2D axes: grid + box, spine/tick sizes."""
    import matplotlib.pyplot as plt
    if grid:
        ax.grid(True, linewidth=0.4)
    for s in ax.spines.values():
        s.set_linewidth(0.8)
    ax.tick_params(labelsize=9)
    return ax


def open_line(ax, x, y, color, mk, **kw):
    """Continuous line + sparse open markers (every 25th point of a
    300-point tracked branch = 12 representative markers)."""
    return ax.plot(x, y, color=color, linewidth=1.5, marker=mk, markevery=25,
                   markerfacecolor="w", markersize=5, **kw)


def layer_regions(ax, a_mm=A_MM, b_mm=B_MM, c_mm=C_MM):
    """Three-layer background shading + dashed boundary lines at
    r = a, b, c (shared by every radial mode-shape panel)."""
    ax.axvspan(0, a_mm, color=REGION_CORE, lw=0, zorder=0)
    ax.axvspan(a_mm, b_mm, color=REGION_ELAST, lw=0, zorder=0)
    ax.axvspan(b_mm, c_mm, color=REGION_SHELL, lw=0, zorder=0)
    for xj in (a_mm, b_mm, c_mm):
        ax.axvline(xj, color="k", ls="--", lw=0.8, zorder=1)


def panel_title(ax, s):
    ax.set_title(s, fontsize=10.5)


def legend_box(ax, loc="upper right", fontsize=8.5):
    return ax.legend(loc=loc, frameon=True, fontsize=fontsize,
                     handlelength=1.8, handletextpad=0.5,
                     labelspacing=0.4, borderpad=0.5)
