#!/usr/bin/env python3
"""mode_shape_check.py — mode-shape / displacement-decay verification.

Mirrors the planned MATLAB dispersion_core.mode_shape exactly:
  * build M (manuscript R1..R5) at a (xi, Omega) root,
  * null vector v = last right singular vector of M (unit norm),
  * reconstruct u1 = A1 I1(g1 r/b), u2 = B1 I1(g2 r/b)+B2 K1(g2 r/b),
    u3 = C1 I1(g3 r/b)+C2 K1(g3 r/b)   (r/b in [0,1,beta]),
  * diagnostics: |u| at 0+, a-, a+, b-, b+, c; localization factor
    |u(c)|/|u(0+)|; interface jumps; normalized-profile comparison.
"""
import numpy as np
from scipy.special import iv, kv
import core as C

KA, KB, MUS, TAU0 = 5.0, 5.0, 1.0e-5, 2.0e-6   # base parameter set

def mode_shape(xi, om, ka, kb, mus, tau0, nr=60):
    M = C.Mmat(xi, om, ka, kb, mus, tau0)
    assert M is not None, "(xi, Omega) not in evanescent regime"
    U, s, Vh = np.linalg.svd(M)
    v = Vh[-1].copy()
    A1, B1, B2, C1, C2 = v
    g = C.gammas2(xi, om, ka, kb, mus, tau0)
    g1, g2, g3 = np.sqrt(g[0]), np.sqrt(g[1]), np.sqrt(g[2])
    r1 = np.linspace(1e-4, C.alpha, nr)          # dimensionless r/b
    r2 = np.linspace(C.alpha, 1.0, nr)
    r3 = np.linspace(1.0, C.beta, nr)
    u1 = A1*iv(1, g1*r1)
    u2 = B1*iv(1, g2*r2) + B2*kv(1, g2*r2)
    u3 = C1*iv(1, g3*r3) + C2*kv(1, g3*r3)
    diag = dict(
        smin_s2=s[-1]/s[-2],
        resid=float(np.linalg.norm(M@v)/np.linalg.norm(M, 'fro')),
        u_0p   = abs(A1*iv(1, g1*1e-8)),         # r/b = 1e-8  (~0+, analytic)
        u_0p_g = abs(u1[0]),                     # first grid point (r/b = 1e-4)
        u_am   = abs(u1[-1]),                    # r=a-
        u_ap   = abs(u2[0]),                     # r=a+
        u_bm   = abs(u2[-1]),                    # r=b-
        u_bp   = abs(u3[0]),                     # r=b+
        u_c    = abs(u3[-1]),                    # r=c
    )
    diag["loc_factor"] = diag["u_c"]/diag["u_0p_g"]
    diag["loc_factor_analytic"] = diag["u_c"]/diag["u_0p"]
    umax = max(abs(u1).max(), abs(u2).max(), abs(u3).max())
    diag["umax"] = umax
    diag["jump_a"] = abs(u2[0]-u1[-1])/umax
    diag["jump_b"] = abs(u3[0]-u2[-1])/umax
    return dict(v=v, g1=g1, g2=g2, g3=g3, r1=r1, r2=r2, r3=r3,
                u1=u1, u2=u2, u3=u3, diag=diag)

def report(name, ms, show_u=True):
    d = ms["diag"]
    print("  %-4s smin/s2=%.2e  resid=%.2e  max|u|=%.4e" % (name, d["smin_s2"], d["resid"], d["umax"]))
    if show_u:
        print("  %-4s |u|: 0+(1e-4)=%.3e  0+(1e-8)=%.3e  a-=%.3e  a+=%.3e  b-=%.3e  b+=%.3e  c=%.3e"
              % (name, d["u_0p_g"], d["u_0p"], d["u_am"], d["u_ap"], d["u_bm"], d["u_bp"], d["u_c"]))
    print("  %-4s loc(grid)=%.3e  loc(analytic)=%.3e   jump_a=%.3e  jump_b=%.3e"
          % (name, d["loc_factor"], d["loc_factor_analytic"], d["jump_a"], d["jump_b"]))

# ------------------------------------------------------------------ cases ----
print("=== mode-shape verification (Python reference) ===")
print("b=%.6e m  a=%.6e mm  b_phys=%.6e mm  c=%.6e mm"
      % (C.b, C.alpha*C.b*1e3, C.b*1e3, C.beta*C.b*1e3))

# (A) base branch 1 at exact full-scan roots
print("\n--- (A) base case, branch 1, full-scan roots ---")
for xi in [0.5, 1.0, 5.0]:
    om = C.find_roots_at_xi(xi, KA, KB, MUS, TAU0)[0]
    ms = mode_shape(xi, om, KA, KB, MUS, TAU0)
    report("xi=%.1f" % xi, ms)
    peak3 = np.abs(ms["u3"]).max()
    print("        u3(b+)...u3(c): %.3e -> %.3e   (peak in region 3 at c: %s)"
          % (abs(ms["u3"][0]), abs(ms["u3"][-1]),
             abs(ms["u3"]).argmax() == len(ms["u3"])-1))

# (B) base branch 1 at the TRACKED branch points (300-pt grid, as MATLAB)
print("\n--- (B) base case, branch 1, tracked points (300-pt grid) ---")
xi_grid = np.linspace(0.05, 6.0, 300)
b1 = C.track_branch(KA, KB, MUS, TAU0, xi_grid, 0.05, 1)
ok = b1["ok_mask"]
xig, omg = b1["xi"][ok], b1["om"][ok]
for target in [0.5, 5.0]:
    i = int(np.argmin(np.abs(xig - target)))
    ms = mode_shape(xig[i], omg[i], KA, KB, MUS, TAU0)
    report("xi=%.4f" % xig[i], ms)
    print("        TRACKED POINT xi=%.6f Omega=%.6f" % (xig[i], omg[i]))

# (C) sweep-2 pair: mus*=0.5 tau0*=0.2, k*=0.5 vs k*=100 at xi=6
print("\n--- (C) sweep 2, k*=0.5 vs k*=100 (mus*=0.5, tau0*=0.2, xi=6) ---")
ms_lo = ms_hi = None
for ksv in [0.5, 100.0]:
    om = C.find_roots_at_xi(6.0, ksv, ksv, 0.5, 0.2)[0]   # physical (upper) branch
    ms = mode_shape(6.0, om, ksv, ksv, 0.5, 0.2)
    report("k*=%g" % ksv, ms)
    print("        full-scan root Omega=%.6f" % om)
    if ksv == 0.5:
        ms_lo = ms
    else:
        ms_hi = ms

# normalized-profile comparison
def norm_u(ms):
    uu = np.concatenate([ms["u1"], ms["u2"], ms["u3"]])
    rr = np.concatenate([ms["r1"], ms["r2"], ms["r3"]])
    return rr, np.abs(uu)/np.abs(uu).max()

rl, ul = norm_u(ms_lo)
rh, uh = norm_u(ms_hi)
# Both k* cases live on the identical r/b grid, so compare pointwise.
# (An np.interp pass over rounded coordinates would create a duplicate
# abscissa at r/b = 1.0 (b- and b+) and bleed the shell-side value into
# the elastic side — pointwise comparison avoids that artifact.)
assert np.array_equal(rl, rh), "grids must be identical"
du = np.abs(ul - uh)
print("\n  normalized-profile difference k*=0.5 vs k*=100: max |du| = %.4f  "
      "(pointwise on the common 180-pt grid)" % du.max())
m1r = rl <= C.alpha + 1e-12
m2r = (rl > C.alpha + 1e-12) & (rl <= 1.0 + 1e-12)
m3r = rl > 1.0 + 1e-12
print("  per-region max |du_norm|:  core=%.2e   elastic=%.2e   shell=%.2e"
      % (du[m1r].max(), du[m2r].max(), du[m3r].max()))
i = int(du.argmax())
print("  max difference at r/b = %.4f (elastic side of the r=b spring interface)" % rl[i])

print("\nDONE mode_shape_check")
