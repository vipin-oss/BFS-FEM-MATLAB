#!/usr/bin/env python3
"""regen_all.py — full regeneration audit of EVERY solver-dependent number in
paper_springer.tex against the CURRENT core.py. Prints OLD(tex) vs NEW for each.
"""
import numpy as np
from scipy.optimize import brentq
from scipy.special import iv, kv
import core as C

V2 = C.v2
XI300 = np.linspace(0.05, 6.0, 300)
XI60 = np.linspace(0.1, 6.0, 60)

def Mmat_g(xi, om, ka, kb, mus, alpha, beta):
    g = C.gammas2(xi, om, ka, kb, mus, 0.0)
    g1, g2, g3 = np.sqrt(g[0]), np.sqrt(g[1]), np.sqrt(g[2])
    m3 = g[3]
    M = np.zeros((5, 5))
    M[0, 0] = C.m1*g1*iv(2, alpha*g1)
    M[0, 1] = -g2*iv(2, alpha*g2);  M[0, 2] = g2*kv(2, alpha*g2)
    M[1, 0] = C.m1*g1*iv(2, alpha*g1) + ka*iv(1, alpha*g1)
    M[1, 1] = -ka*iv(1, alpha*g2);  M[1, 2] = -ka*kv(1, alpha*g2)
    M[2, 1] = g2*iv(2, g2);         M[2, 2] = -g2*kv(2, g2)
    M[2, 3] = -m3*g3*iv(2, g3);     M[2, 4] = m3*g3*kv(2, g3)
    M[3, 1] = g2*iv(2, g2) + kb*iv(1, g2)
    M[3, 2] = -g2*kv(2, g2) + kb*kv(1, g2)
    M[3, 3] = -kb*iv(1, g3);        M[3, 4] = -kb*kv(1, g3)
    M[4, 3] = m3*g3*iv(2, beta*g3) + mus*xi*xi*iv(1, beta*g3)
    M[4, 4] = -m3*g3*kv(2, beta*g3) + mus*xi*xi*kv(1, beta*g3)
    return M

def metrics(xi, om, ka, kb, mus, tau0, alpha=0.5, beta=1.5, nr=1001):
    """mode-shape metrics with explicit geometry (no global patching)."""
    g = C.gammas2(xi, om, ka, kb, mus, tau0)
    M = Mmat_g(xi, om, ka, kb, mus, alpha, beta)
    g1, g2, g3 = np.sqrt(g[0]), np.sqrt(g[1]), np.sqrt(g[2])
    U, s, Vh = np.linalg.svd(M)
    A1, B1, B2, C1, C2 = Vh[-1]
    uc  = abs(C1*iv(1, g3*beta) + C2*kv(1, g3*beta))
    ubp = abs(C1*iv(1, g3) + C2*kv(1, g3))
    ubm = abs(B1*iv(1, g2) + B2*kv(1, g2))
    uap = abs(B1*iv(1, g2*alpha) + B2*kv(1, g2*alpha))
    uam = abs(A1*iv(1, g1*alpha))
    u0p = abs(A1*iv(1, g1*1e-4))
    r1 = np.linspace(1e-4, alpha, nr); r2 = np.linspace(alpha, 1.0, nr); r3 = np.linspace(1.0, beta, nr)
    umax_full = max(np.abs(A1*iv(1, g1*r1)).max(), np.abs(B1*iv(1, g2*r2)+B2*kv(1, g2*r2)).max(),
                    np.abs(C1*iv(1, g3*r3)+C2*kv(1, g3*r3)).max())
    umax_if = max(uc, ubp, ubm, uap, uam)
    return dict(uc=uc, ubp=ubp, ubm=ubm, u0p=u0p, Rcb=uc/ubp,
                Jb_if=abs(ubp-ubm)/umax_if*100, Jb_full=abs(ubp-ubm)/umax_full*100,
                L=uc/u0p)

def track(ka, kb, mus, tau0, xi_g=XI300, beta=None, alpha=None):
    oa, ob = C.alpha, C.beta
    if alpha is not None: C.alpha = alpha
    if beta is not None: C.beta = beta
    b = C.track_branch(ka, kb, mus, tau0, xi_g, xi_g[0], 1)
    C.alpha, C.beta = oa, ob
    return b

P = lambda *a: print(*a, flush=True)

# ============================================================= S1 baseline
P("="*92); P("S1  BASELINE branch 1 (Table 5, velocities, localization, plateau, gammas)")
b1 = track(5.0, 5.0, 1e-5, 2e-6)
ok = b1["ok_mask"]; x1, o1 = b1["xi"][ok], b1["om"][ok]
P("  tracked %d/%d; nodes vs Table 5:" % (ok.sum(), len(ok)))
for xr in [0.05, 0.1097, 0.2092, 0.5077, 1.0052, 2.0002, 2.9952, 3.9901, 5.005, 6.0]:
    i = int(np.argmin(np.abs(x1-xr)))
    vp = o1[i]/x1[i]*V2
    vg = np.gradient(o1, x1)[i]*V2
    P("    xi=%6.4f  Om=%.6f  vp=%7.2f  vg=%7.2f" % (x1[i], o1[i], vp, vg))
bfine = track(5.0, 5.0, 1e-5, 2e-6, np.linspace(0.05, 6.0, 3000))
okf = bfine["ok_mask"]; xf, of = bfine["xi"][okf], bfine["om"][okf]
imax = int(np.argmax(of))
P("  fine-grid max Omega = %.6f at xi=%.4f   (tex says 0.1709 near xi=1.0)" % (of[imax], xf[imax]))
m2 = of[xf >= 2.0]
P("  plateau band xi>=2: [%.4f, %.4f]  (tex 0.1622..0.1643)" % (m2.min(), m2.max()))
gm = [C.gammas2(x, o, 5, 5, 1e-5, 2e-6) for x, o in zip(x1, o1)]
P("  min gamma^2: g1=%.4e g2=%.4e g3=%.4e  (tex 2.32e-3,1.87e-3,0.192)"
  % (min(g[0] for g in gm), min(g[1] for g in gm), min(g[2] for g in gm)))
rcb = np.array([metrics(x, o, 5, 5, 1e-5, 2e-6)["Rcb"] for x, o in zip(x1, o1)])
icr = np.where(rcb < 1.0)[0]
xi_tr = float(np.interp(1.0, [rcb[icr[0]], rcb[icr[0]-1]], [x1[icr[0]], x1[icr[0]-1]]))
P("  xi_trans (interp Rcb=1) = %.4f  (tex 1.4962 / 1.496)" % xi_tr)
i51 = int(np.argmin(np.abs(x1-0.5077))); i5 = int(np.argmin(np.abs(x1-5.005)))
P("  Rcb(0.5077)=%.4f (tex 1.38); max Rcb(xi<xi_tr)=%.4f (tex ~1.45); Rcb(5.005)=%.4f (tex 0.1604); Rcb(6)=%.4f (tex 0.0946)"
  % (rcb[i51], rcb[x1 < xi_tr].max(), rcb[i5], rcb[-1]))
m6 = metrics(6.0, o1[-1], 5, 5, 1e-5, 2e-6)
P("  J_b(6): iface-max=%.2f  full-max=%.2f   (tex 41.92);  L(6)=|u(c)|/|u(0+)|=%.4e"
  % (m6["Jb_if"], m6["Jb_full"], m6["L"]))
P("  vp(0.05)=%.2f vp(6)=%.2f  (tex 552.55 / 29.87)" % (o1[0]/x1[0]*V2, o1[-1]/6*V2))

# ============================================================= S2 branch 2
P("="*92); P("S2  BRANCH 2 rows (Table 5 lower block)")
xi_on2 = C.find_branch_onset(0.05, 0.5, 90, 5.0, 5.0, 1e-5, 2e-6, 2)
g2 = XI300[XI300 >= xi_on2]
b2 = C.track_branch(5.0, 5.0, 1e-5, 2e-6, g2, xi_on2, 2)
ok2 = b2["ok_mask"]; x2, o2 = b2["xi"][ok2], b2["om"][ok2]
for xr in [0.1097, 0.5077, 1.0052, 2.0002, 6.0]:
    i = int(np.argmin(np.abs(x2-xr)))
    P("    xi=%6.4f  Om2=%.6f  vp=%5.2f  (tex %.6f)" % (x2[i], o2[i], o2[i]/x2[i]*V2,
       {0.1097:0.000105, 0.5077:0.000478, 1.0052:0.000900, 2.0002:0.001537, 6.0:0.002677}[xr]))
lo, hi = 0.05, 0.3
for _ in range(45):
    mid = 0.5*(lo+hi)
    rr = C.find_roots_at_xi(mid, 5.0, 5.0, 1e-5, 2e-6)
    if len(rr) >= 2 and rr[-1] > 1e-4: hi = mid
    else: lo = mid
P("  branch-2 cutoff (2nd root above scan floor): xi in [%.4f, %.4f]  (tex 0.1056)" % (lo, hi))

# ============================================================= S3 convergence
P("="*92); P("S3  CONVERGENCE (tex: max<2.24e-6, mean 2.28e-7)")
b600 = C.track_branch(5.0, 5.0, 1e-5, 2e-6, np.linspace(0.05, 6, 600), 0.05, 1,
                      windows=[0.005, 0.01, 0.02, 0.05, 0.10])
okc, ok6 = b1["ok_mask"], b600["ok_mask"]
d = np.abs(o1 - np.interp(x1, b600["xi"][ok6], b600["om"][ok6]))
P("  300-vs-600 max=%.3e mean=%.3e" % (d.max(), d.mean()))
res = []
for x, o in zip(x1, o1):
    M = C.Mmat(x, o, 5, 5, 1e-5, 2e-6)
    v = np.linalg.svd(M)[2][-1]
    res.append(np.linalg.norm(M @ v))
P("  residual ||MX||2 range: [%.2e, %.2e]  (tex 1e-15..1e-14)" % (min(res), max(res)))

# ============================================================= S4 benchmark
P("="*92); P("S4  BENCHMARK (tab:validation_benchmark)")
import benchmark_kielczynski as BK
def kroot(w):
    return brentq(lambda kk: BK.kiel_dispersion_residual(w, kk), w/V2*1.0001, w/V2*12.0)
freqs = np.array([75., 80., 90., 100., 110., 120., 130., 140., 144.])
pub_k = np.array([453.6, 499.0, 604.4, 735.0, 903.5, 1138.0, 1515.7, 2426.9, 3907.6])
pub_vp = np.array([1038.8, 1007.3, 935.6, 854.9, 765.0, 662.6, 538.9, 362.5, 231.5])
pub_vg = np.array([726.6, 659.6, 539.2, 428.5, 322.7, 220.4, 122.8, 35.4, 6.9])
for f, pk, pv, pg in zip(freqs, pub_k, pub_vp, pub_vg):
    w = 2*np.pi*f*1e3
    k = kroot(w)
    vp = w/k
    wm, wp_ = 2*np.pi*(f-0.5)*1e3, 2*np.pi*(f+0.5)*1e3
    vg = (wp_-wm)/(kroot(wp_)-kroot(wm))
    P("  f=%5.1f: k=%.4f err_k=%.4f%%  vp=%.2f err_vp=%.4f%%  vg=%.2f (pub %.1f/%.1f/%.1f)"
      % (f, k, abs(k-pk)/pk*100, vp, abs(vp-pv)/pv*100, vg, pk, pv, pg))
lo, hi = 144.0, 146.0
for _ in range(40):
    mid = 0.5*(lo+hi)
    try:
        kroot(2*np.pi*mid*1e3); lo = mid
    except ValueError:
        hi = mid
km = kroot(2*np.pi*lo*1e3)
P("  f_max ~ %.2f kHz, k(f_max) ~ %.1f  (tex 145.02 / 7291.9)" % (lo, km))

# ============================================================= S5 limiting
P("="*92); P("S5  LIMITING CASES (tex: rigid 0.1651, soft 0.1082)")
for lab, ka, kb in [("rigid(1000,1000)", 1000., 1000.), ("soft(0.5,0.5)", 0.5, 0.5),
                    ("kb=0.5", 5.0, 0.5), ("kb=100", 5.0, 100.)]:
    b = C.track_branch(ka, kb, 1e-5, 2e-6, XI60, 0.1, 1)
    P("  %-16s Om6=%.6f" % (lab, b["om"][b["ok_mask"]][-1]))

# ============================================================= S6 ka/kb sweeps
P("="*92); P("S6  ka / kb SWEEPS (tex body: 0.1082/0.1629/0.1865, 72.3%; ka |dOm|<0.001)")
kbv = {}
for kb in [0.5, 2.0, 5.0, 20.0, 100.0]:
    b = track(5.0, kb, 1e-5, 2e-6)
    kbv[kb] = b["om"][b["ok_mask"]][-1]
    P("  kb=%6.1f Om6=%.6f" % (kb, kbv[kb]))
P("  kb shift 0.5->100 = %.1f%%  (tex 72.3%%)" % ((kbv[100.]-kbv[0.5])/kbv[0.5]*100))
kav = {}
for ka in [0.5, 2.0, 5.0, 20.0, 100.0]:
    b = track(ka, 5.0, 1e-5, 2e-6)
    kav[ka] = b["om"][b["ok_mask"]][-1]
    P("  ka=%6.1f Om6=%.6f" % (ka, kav[ka]))
P("  ka spread = %.2e  (tex <0.001)" % (max(kav.values())-min(kav.values())))

# ============================================================= S7 mu sweep
P("="*92); P("S7  mu_s* SWEEP (tex: 0.1629/0.3425/0.5296/0.7239/0.9627; onsets 0.05/0.05/0.05/0.3465/0.6133)")
for G in [0.0, 0.2, 0.5, 0.7, 1.0, 2.0]:
    bi, on = C.track_physical_branch(5.0, 5.0, G, 0.0, XI300)
    P("  G=%.1f onset=%.4f Om6=%.6f" % (G, on, bi["om"][bi["ok_mask"]][-1]))

# ============================================================= S8 G=0.7 k sweep
P("="*92); P("S8  G=0.7 k-sweep spread (tex: <5e-4)")
sv = []
for k in [0.5, 2.0, 5.0, 20.0, 100.0]:
    b, on = C.track_physical_branch(k, k, 0.7, 0.0, XI300)
    sv.append(b["om"][b["ok_mask"]][-1])
P("  Om6 range [%.6f, %.6f], spread %.2e" % (min(sv), max(sv), max(sv)-min(sv)))

# ============================================================= S9 geometry
P("="*92); P("S9  GEOMETRY (tex body: beta=1.15 -> ~0.11, beta=2 -> ~0.165; alpha |dOm|<0.002; rows 11-12: 0.1105/0.1648)")
for bv in [1.15, 1.30, 1.50, 2.00]:
    b = track(5.0, 5.0, 1e-5, 2e-6, beta=bv)
    okb = b["ok_mask"]
    P("  beta=%.2f Om6=%.6f  (row: %s)" % (bv, b["om"][okb][-1], {1.15:"0.1105", 2.00:"0.1648"}.get(bv, "-")))
for av in [0.20, 0.50, 0.80]:
    b = track(5.0, 5.0, 1e-5, 2e-6, alpha=av)
    P("  alpha=%.2f Om6=%.6f" % (av, b["om"][b["ok_mask"]][-1]))

# ============================================================= S10 Table 7 rows
P("="*92); P("S10  TABLE 7 full regeneration (xi_c, Om6, vp6, xi_tr, J_b)")
rows = [
 ("1 baseline", dict(ka=5, kb=5, mus=1e-5, tau0=2e-6)),
 ("2 kb=0.5", dict(ka=5, kb=0.5, mus=1e-5, tau0=2e-6)),
 ("3 kb=20", dict(ka=5, kb=20., mus=1e-5, tau0=2e-6)),
 ("4 kb=100", dict(ka=5, kb=100., mus=1e-5, tau0=2e-6)),
 ("5 ka=0.5", dict(ka=0.5, kb=5, mus=1e-5, tau0=2e-6)),
 ("6 ka=100", dict(ka=100., kb=5, mus=1e-5, tau0=2e-6)),
 ("7 G=0.2", dict(ka=5, kb=5, mus=0.2, tau0=0.)),
 ("8 G=0.5", dict(ka=5, kb=5, mus=0.5, tau0=0.)),
 ("9 G=0.7", dict(ka=5, kb=5, mus=0.7, tau0=0.)),
 ("10 G=2.0", dict(ka=5, kb=5, mus=2.0, tau0=0.)),
 ("11 beta=1.15", dict(ka=5, kb=5, mus=1e-5, tau0=2e-6, beta=1.15)),
 ("12 beta=2.0", dict(ka=5, kb=5, mus=1e-5, tau0=2e-6, beta=2.0)),
]
for name, kw in rows:
    beta = kw.pop("beta", None)
    if kw["mus"] >= 0.2:
        b, _on = C.track_physical_branch(kw["ka"], kw["kb"], kw["mus"], kw["tau0"], XI300)
    else:
        b = track(kw["ka"], kw["kb"], kw["mus"], kw["tau0"], beta=beta)
    okb = b["ok_mask"]; xb, ob = b["xi"][okb], b["om"][okb]
    m6x = metrics(6.0, ob[-1], kw["ka"], kw["kb"], kw["mus"], kw["tau0"], beta=beta if beta else 1.5)
    rcbx = np.array([metrics(x, o, kw["ka"], kw["kb"], kw["mus"], kw["tau0"], beta=beta if beta else 1.5)["Rcb"]
                     for x, o in zip(xb, ob)])
    ic = np.where(rcbx < 1.0)[0]
    xtr = float(np.interp(1.0, [rcbx[ic[0]], rcbx[ic[0]-1]], [xb[ic[0]], xb[ic[0]-1]])) if len(ic) and ic[0] > 0 else np.nan
    P("  %-13s Om6=%.6f vp6=%7.2f xi_tr=%s Jb_if=%6.2f Rcb6=%.4f"
      % (name, ob[-1], ob[-1]/6*V2, ("%.4f" % xtr) if not np.isnan(xtr) else ">6.0  ",
         m6x["Jb_if"], rcbx[-1]))

# ============================================================= S11 OAT
P("="*92); P("S11  OAT sensitivity (tex: mus[0,0,0,2e-4,2e-4]; ka[4e-4,0,4e-4,-0.6255,-0]; kb[0.2373,0,0.2373,-0.4787,-1e-4])")
def Q(ka, kb, mus):
    b = C.track_branch(ka, kb, mus, 0.0, XI300, 0.05, 1)
    okq = b["ok_mask"]
    om6 = b["om"][okq][-1]
    m = metrics(6.0, om6, ka, kb, mus, 0.0)
    return np.array([om6, 0.05, om6/6*V2, m["L"], m["Rcb"]])
base = Q(5, 5, 1e-5)
for pname, pf in [("mus", lambda f: (5, 5, 1e-5*f)), ("ka", lambda f: (5*f, 5, 1e-5)),
                  ("kb", lambda f: (5, 5*f, 1e-5))]:
    qm, qp = Q(*pf(0.5)), Q(*pf(2.0))
    S = (np.log(qp) - np.log(qm))/np.log(4)
    P("  %-4s S = [%s]" % (pname, ", ".join("%+.4f" % s for s in S)))

# ============================================================= S12 velocities/ZGV
P("="*92); P("S12  VELOCITIES / ZGV (tex: vg=0 near 0.95 and 2.7; vg(1.0052)=-10.29)")
vgf = np.gradient(of, xf)*V2
sgn = np.sign(vgf)
zc = [float(np.interp(0, [vgf[i+1], vgf[i]], [xf[i+1], xf[i]]))
      for i in range(len(xf)-1) if sgn[i]*sgn[i+1] < 0]
P("  ZGV crossings at xi = %s" % ", ".join("%.3f" % z for z in zc))
i = int(np.argmin(np.abs(xf-1.0052)))
P("  vg(1.0052)=%.2f  (tex -10.29); vg(0.05)=%.2f (tex 540.41)" % (vgf[i], vgf[0]))
P("DONE regen_all")
