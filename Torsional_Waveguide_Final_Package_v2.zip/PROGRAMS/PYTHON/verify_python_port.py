"""Python port of the MATLAB dispersion solver -- used to VERIFY the MATLAB
package numerics before delivery (identical algorithm & parameters).

Implements the manuscript's verified 5x5 non-dimensional dispersion matrix
(Eqs. N1-N5) with continuation-based branch tracking.
"""
import numpy as np
from scipy.special import iv, kv
from scipy.optimize import brentq

# ---------------- parameters (identical to main_dispersion.m) ---------------
mu1, rho1 = 3.86e10, 8954.0
rho2, s44_2 = 1180.0, 70.03e-11
rho3, s0, fp = 2650.0, 1.474e-11, 1e6
omega_p = 2*np.pi*fp
b = 0.35016e-3
alpha, beta = 0.5, 1.5
ka_star = kb_star = 5.0
mu_s, tau0 = 5.0, 1.0

m1 = mu1*s44_2
mus_star = (mu_s/b)*s44_2
tau0_star = (tau0/b)*s44_2
r12, r32, s2_s0 = rho1/rho2, rho3/rho2, s44_2/s0
Omega_p = omega_p*b*np.sqrt(rho2*s44_2)
v2 = 1.0/np.sqrt(rho2*s44_2)   # m/s reference shear speed (layer 2)

P = dict(alpha=alpha, beta=beta, m1=m1, r12=r12, r32=r32, s2_s0=s2_s0,
         Omega_p=Omega_p, ka=ka_star, kb=kb_star, mus=mus_star, tau0=tau0_star)
print("m1=%.5f  r12=%.5f  r32=%.5f  s2/s0=%.4f  Omega_p=%.5f  v2=%.1f m/s"
      % (m1, r12, r32, s2_s0, Omega_p, v2))
print("mus*=%.3e tau0*=%.3e  (mus*+tau0*)=%.3e" % (mus_star, tau0_star, mus_star+tau0_star))


def gammas2(xi, Om):
    """Return (g1^2, g2^2, g3^2) or None if outside evanescent/m3-valid range."""
    if abs(Om) < 1e-10:
        return None
    s43_over_s0 = 1.0 - (P['Omega_p']**2)/(Om**2)
    if abs(s43_over_s0) < 1e-12:
        return None
    m3 = P['s2_s0']/s43_over_s0
    g12 = xi**2 - P['r12']*Om**2/P['m1']
    g22 = xi**2 - Om**2
    g32 = xi**2 - P['r32']*Om**2/m3
    if g12 <= 0 or g22 <= 0 or g32 <= 0:
        return None
    return g12, g22, g32, m3


def Dfun(xi, Om):
    """det(M) of the manuscript's 5x5 (N1-N5); NaN where not evanescent."""
    g = gammas2(xi, Om)
    if g is None:
        return np.nan
    g12, g22, g32, m3 = g
    g1, g2, g3 = np.sqrt(g12), np.sqrt(g22), np.sqrt(g32)
    a, c, m1, ka, kb = P['alpha'], P['beta'], P['m1'], P['ka'], P['kb']
    G = P['mus']
    M = np.zeros((5, 5))
    M[0, 0] = m1*g1*iv(2, a*g1)
    M[0, 1] = -g2*iv(2, a*g2)
    M[0, 2] = g2*kv(2, a*g2)
    M[1, 0] = m1*g1*iv(2, a*g1) + ka*iv(1, a*g1)
    M[1, 1] = -ka*iv(1, a*g2)
    M[1, 2] = -ka*kv(1, a*g2)
    M[2, 1] = g2*iv(2, g2)
    M[2, 2] = -g2*kv(2, g2)
    M[2, 3] = -m3*g3*iv(2, g3)
    M[2, 4] = m3*g3*kv(2, g3)
    M[3, 1] = g2*iv(2, g2) + kb*iv(1, g2)
    M[3, 2] = -g2*kv(2, g2) + kb*kv(1, g2)
    M[3, 3] = -kb*iv(1, g3)
    M[3, 4] = -kb*kv(1, g3)
    M[4, 3] = m3*g3*iv(2, c*g3) + G*xi**2*iv(1, c*g3)
    M[4, 4] = -m3*g3*kv(2, c*g3) + G*xi**2*kv(1, c*g3)
    d = np.linalg.det(M)
    if not np.isfinite(d):
        return np.nan
    return d


def find_roots_at_xi(xi, ngrid=4000):
    """All evanescent-admissible real roots at a given xi, sorted descending."""
    grid = np.linspace(1e-4, xi*0.9999, ngrid)
    vals = np.array([Dfun(xi, o) for o in grid])
    ok = np.isfinite(vals)
    grid, vals = grid[ok], vals[ok]
    if len(vals) < 2:
        return []
    sw = np.where(np.diff(np.sign(vals)) != 0)[0]
    roots = []
    for j in sw:
        try:
            r = brentq(lambda o: Dfun(xi, o), grid[j], grid[j+1], xtol=1e-13, rtol=1e-14)
            roots.append(r)
        except Exception:
            pass
    return sorted(roots, reverse=True)


def track_branch(xi_vals, branch_rank=1, widths=(0.01, 0.02, 0.05, 0.1, 0.2),
                 max_jump=0.3, verbose=False):
    """Continuation with linear-extrapolation predictor. Returns (Omega, info)."""
    Omega = np.full(len(xi_vals), np.nan)
    info = dict(jumps=[], lost_at=None)
    xi0 = xi_vals[0]
    roots0 = find_roots_at_xi(xi0)
    if len(roots0) < branch_rank:
        info['lost_at'] = xi0
        return Omega, info
    prev2 = prev = roots0[branch_rank-1]
    Omega[0] = prev
    consec_loss = 0
    for i in range(1, len(xi_vals)):
        xi = xi_vals[i]
        pred = prev if i == 1 else 2.0*prev - prev2     # linear extrapolation
        found = None
        for w in widths:
            lo, hi = max(1e-4, pred - w), min(xi*0.9999, pred + w)
            if hi <= lo:
                continue
            ng = np.linspace(lo, hi, 40)
            vv = np.array([Dfun(xi, o) for o in ng])
            ok = np.isfinite(vv)
            ng, vv = ng[ok], vv[ok]
            if len(vv) < 2:
                continue
            sgc = np.where(np.diff(np.sign(vv)) != 0)[0]
            if len(sgc) == 0:
                continue
            j = sgc[0]
            try:
                r = brentq(lambda o: Dfun(xi, o), ng[j], ng[j+1], xtol=1e-13, rtol=1e-14)
                found = r
                break
            except Exception:
                continue
        if found is None:
            consec_loss += 1
            if consec_loss > 25 and info['lost_at'] is None:
                info['lost_at'] = xi
                if verbose:
                    print("  branch %d LOST at xi=%.3f" % (branch_rank, xi))
            break
        if abs(found - prev) > max_jump:
            info['jumps'].append((xi, prev, found))
            if verbose:
                print("  branch %d JUMP at xi=%.3f: %.5f -> %.5f"
                      % (branch_rank, xi, prev, found))
        consec_loss = 0
        prev2, prev = prev, found
        Omega[i] = prev
    return Omega, info


if __name__ == '__main__':
    # ---------- branch inventory at seed ----------
    for xi_t in (0.05, 0.1, 0.2, 0.5):
        r = find_roots_at_xi(xi_t)
        print("roots at xi=%.2f: %s" % (xi_t, ["%.6f" % x for x in r]))

    xi_vals = np.linspace(0.05, 6, 300)
    sols = {}
    for rank in (1, 2, 3):
        om, info = track_branch(xi_vals, branch_rank=rank, verbose=True)
        sols[rank] = om
        v = ~np.isnan(om)
        print("branch %d: tracked %.0f/%d points, range [%.5f, %.5f], "
              "jumps=%d, lost_at=%s"
              % (rank, v.sum(), len(xi_vals),
                 om[v].min() if v.any() else float('nan'),
                 om[v].max() if v.any() else float('nan'),
                 len(info['jumps']), info['lost_at']))
