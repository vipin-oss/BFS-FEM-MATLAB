"""Definitive check of the B5 -> R5/N5 expansion in the manuscript.

B5:  sigma_rtheta^(3)(c) = (1/s44_3) * r*d/dr[u_theta(r)/r] |_{r=c}
     = -(mu_s + tau0) * k^2 * u_theta(c)

u_theta(r) = f(r) e^{i(kz-omega t)},  f(r) = C1 I1(g r) + C2 K1(g r)

Key identity used (torsional stress removes the 1/c pieces EXACTLY):
  r * d/dr[ I1(g r) / r ] = g * I2(g r)
  r * d/dr[ K1(g r) / r ] = -g * K2(g r)
because  I1'(x) = I2(x) + I1(x)/x  and  K1'(x) = -K2(x) + K1(x)/x,
and  g/x = 1/r  at x = g r.  =>  the +/- I1,K1 / c terms cancel.

So sigma_rtheta^(3)(c) * s44_3 = C1 * g * I2(g c) - C2 * g * K2(g c)
= exactly the paper's printed R5/N5 C1/C2 coefficients.  CONFIRMED below.
"""
import numpy as np
from scipy.special import iv, kv
i1 = lambda x: iv(1, x); k1 = lambda x: kv(1, x)
i2 = lambda x: iv(2, x); k2 = lambda x: kv(2, x)

g, c = 1.7, 2.5
x = g * c
h = 1e-7 * g * c

# derivative identities (numeric vs analytic)
dI1_num = (i1(g*(c+h)) - i1(g*(c-h))) / (2*h)
dK1_num = (k1(g*(c+h)) - k1(g*(c-h))) / (2*h)
print("d/dr I1: numeric %.12e  identity g(I2+I1/x) %.12e  diff %.2e"
      % (dI1_num, g*(i2(x)+i1(x)/x), dI1_num - g*(i2(x)+i1(x)/x)))
print("d/dr K1: numeric %.12e  identity g(-K2+K1/x) %.12e  diff %.2e"
      % (dK1_num, g*(-k2(x)+k1(x)/x), dK1_num - g*(-k2(x)+k1(x)/x)))

# the cancellation identity
C1, C2 = 1.0, 0.7
lhs_full = (i1(g*(c+h)) * C1 + k1(g*(c+h)) * C2) / (c+h)
rhs_full = (i1(g*(c-h)) * C1 + k1(g*(c-h)) * C2) / (c-h)
# r * d/dr [ f(r)/r ] via central difference of f/r
F = lambda r: (C1*i1(g*r) + C2*k1(g*r))/r
rd = c * (F(c+h) - F(c-h)) / (2*h)
paper = C1*g*i2(x) - C2*g*k2(x)
print("\nr*d/dr[f/r] at c: numeric %.12e  paper R5 form C1*g*I2 - C2*g*K2 %.12e  diff %.2e"
      % (rd, paper, rd - paper))
print("\nCONCLUSION: paper's R5/N5 expansion of B5 is CORRECT (1/c terms cancel).")
