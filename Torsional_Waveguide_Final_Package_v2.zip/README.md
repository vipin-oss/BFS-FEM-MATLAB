# Torsional Waveguide Final Package — v2 (corrected, 2026-09-21)

Complete research package for the manuscript
*"Torsional surface waves in a core–shell cylinder with Gurtin–Murdoch surface
elasticity and imperfect interfaces"* (Springer `sn-jnl` format).

**v2 supersedes v1.** See `DIFF_REPORT.md` for the full old→new table of every
number that changed, the evidence (fresh solver executions), and the checklist of
every solver-dependent table/figure re-verified against the current code.
All values in v2 were regenerated from `PROGRAMS/PYTHON/core.py`
(cross-checked against `PROGRAMS/MATLAB/torsional_waveguide_core.m`); no number was
carried over from v1 without re-execution. The manuscript PDF in `OVERLEAF/` was
recompiled from the corrected `.tex` (tectonic 0.15.0, zero LaTeX errors).

## Contents

```
OVERLEAF/            Upload-ready LaTeX source
  paper_springer.tex   corrected manuscript (v2)
  paper_springer.pdf   recompiled PDF
  *.png                all 15 figures, regenerated from current code
  sn-jnl.cls, *.bst, tor_annu_refs.bib, *.bbl/.aux/.log/.out
PROGRAMS/
  MATLAB/            Figure02–Figure15 scripts, script01–script07,
                     torsional_waveguide_core.m, run_all / generate_all drivers
  PYTHON/            core.py (reference solver), master_figure_generator.py,
                     benchmark_kielczynski.py, sensitivity_surface_check.py,
                     make_journal_previews.py, regen_all.py (full v1→v2 audit),
                     plus verification utilities
ALL_FIGURES/         every regenerated figure PNG (master + journal previews)
README.md            this file
DIFF_REPORT.md       old→new diff for every changed number + regeneration checklist
```

## Reproducing everything from scratch

1. Python figures and tables:
   `python3 PROGRAMS/PYTHON/master_figure_generator.py`
   (writes ALL_FIGURES/), then
   `python3 PROGRAMS/PYTHON/sensitivity_surface_check.py` and
   `python3 PROGRAMS/PYTHON/make_journal_previews.py`.
2. Full numeric audit vs the manuscript: `python3 PROGRAMS/PYTHON/regen_all.py`.
3. MATLAB equivalents: `run_all_matlab_simulations.m` / `generate_all_manuscript_figures.m`
   (requires MATLAB with the Symbolic/MathWorks toolboxes used in v1).
4. PDF: compile `OVERLEAF/paper_springer.tex` with pdfLaTeX/BibTeX (or tectonic).

## Notes on v2 code fixes

- `master_figure_generator.py`: geometry panel now tracks the physical branch by
  continuation (the old first-crossing scan latched the spurious branch-2 root);
  sensing panel now uses `core.track_physical_branch`.
- `sensitivity_surface_check.py`: fixed undefined `TAU00` (baseline τ₀* = 2e-6).
- Wordings corrected per author instruction: "modal displacement localization"
  (R_cb is a displacement-amplitude ratio) and ρs = 0 stated explicitly as an
  assumption of the formulation.
