# DIFF REPORT — Torsional Waveguide Package v5 (2026-09-21; rounds 2-5 consolidated)

Every number below was re-derived by **fresh execution of the current solvers**
(`PYTHON_SCRIPTS/core.py`, cross-checked against `MATLAB_PROGRAMS/torsional_waveguide_core.m`
via `regen_all.py` sections S1–S12, `master_figure_generator.py`,
`benchmark_kielczynski.py`, `sensitivity_surface_check.py`, `make_journal_previews.py`).
No value was carried over from the previous package without re-execution.

Format: `OLD → NEW`, with the executing evidence in parentheses.

---

## A. Wording-only changes (no numerics)

1. **Localization metric wording** — "complete characterization of modal **energy migration**"
   → "complete characterization of modal **displacement localization**"
   (R_cb is a displacement-amplitude ratio, not an energy quantity).
2. **Surface-inertia sentence** — removed "as quantitatively proven in Section …".
   New text: "… $(\rho_s v_p^2)/\mu^s \ll 10^{-3}$); accordingly, **$\rho_s = 0$ is an
   assumption of the present formulation**."
3. Items left **untouched by explicit instruction**: the "zero interior local maxima" claim
   and the Gurtin–Murdoch $\mu_s$-alone surface formulation (both verified correct).

## B. Benchmark-validation tolerance wording

- "within $0.01\%$" → "within $0.02\%$" in **abstract**, **contributions list**, and
  **conclusions** (3 occurrences).
- Justification (printed by `benchmark_kielczynski.py`): current solver deviates from
  Kiełczyński et al. (2025) by at most **k = 0.009 %** and **vp = 0.018 %**, so 0.01 % was
  an over-statement of the achieved agreement.

## C. Benchmark table (validation section)

Published k and vp columns verified identical to source (unchanged). Updated cells
(`vg [m/s]` and `err_vp [%]`), rows by frequency [kHz]:

| f | vg OLD → NEW | err_vp OLD → NEW |
|---|---|---|
| 75  | 726.55 → 726.54 | 0.0010 → 0.0006 |
| 80  | 659.64 → 659.62 | 0.0050 → 0.0049 |
| 90  | 539.23 → 539.21 | 0.0000 → 0.0005 |
| 100 | 428.48 → 428.46 | 0.0035 → 0.0032 |
| 110 | 322.71 → 322.69 | 0.0065 → 0.0072 |
| 120 | 220.40 → 220.37 | 0.0030 → 0.0038 |
| 130 | 122.77 → 122.71 | 0.0019 → 0.0020 |
| 140 | 35.44 → 35.31  | 0.0138 → 0.0138 |
| 144 | 6.91 → 6.41    | 0.0173 → 0.0183 |

Body text item 3: "$726.55$ m/s … to $6.91$ m/s" → "$726.54$ m/s … to $6.41$ m/s".
(err_k column unchanged, max 0.0090 %.)

## D. Table 5, Branch-2 block (secondary interface mode)

| ξ OLD → NEW | Ω OLD → NEW | vp OLD → NEW | vg OLD → NEW |
|---|---|---|---|
| 0.1097 → 0.1296 | 0.000105 → 0.000113 | 1.05 → 0.96 | 1.05 → 0.96 |
| 0.5077 (same) | 0.000478 → 0.000436 | 1.04 → 0.95 | 1.00 → 0.91 |
| 1.0052 (same) | 0.000900 → 0.000822 | 0.99 → 0.90 | 0.86 → 0.79 |
| 2.0002 (same) | 0.001537 → 0.001403 | 0.85 → 0.77 | 0.56 → 0.51 |
| 6.0000 (same) | 0.002677 → 0.002444 | 0.49 → 0.45 | 0.21 → 0.19 |

Body: branch-2 cutoff "$\xi_c \approx 0.1056$" → "$\xi_c \approx 0.1143$" (regen S2).

## E. Plateau band and residual norm (Branch-1 discussion)

- Frequency band "$0.1622 \le \Omega \le 0.1643$" → "$0.1619 \le \Omega \le 0.1645$"
  (fine-grid extremal values of tracked branch).
- Residual norm text "$10^{-15}$–$10^{-14}$" → "$1.9\times10^{-17}$–$3.5\times10^{-14}$".

## F. Limiting-case checks (validation bullet items)

- Rigid interfaces: $\Omega(6)$: **0.1651 → 0.2247**.
- Compliant interfaces: $\Omega(6)$: **0.1082 → 0.0709**.

## G. Shell-interface ($k_b^*$) sweep sentence (Table 6 discussion)

- $\Omega(6)$ at $k_b^*=0.5$: **0.1082 → 0.0709**.
- $\Omega(6)$ at $k_b^*=100$: **0.1865 → 0.2198**.
- Frequency-shift headline: **72.3 % → 209.8 %** (=(0.2198−0.0709)/0.0709).
- $\Omega(6)$ at $k_b^*=5$ = 0.1629 unchanged (verified).

## H. Group-velocity / ZGV text

- "$v_g$ … to zero near $\xi \approx 0.95$" → "near $\xi \approx 0.85$".
- Negative-$v_g$ window "between $\xi \approx 1.0$ and $2.5$" → "between $\xi \approx 0.85$ and $2.3$".
- ZGV examples "$\xi \approx 0.95$ and $\xi \approx 2.7$" →
  "$\xi \approx 0.85$, $\xi \approx 2.29$, and $\xi \approx 4.52$".

## I. Table 7 (parametric summary), rows 2–12: Ω(6) / vp(6) [m/s] / ξ_trans / J_b [%]

| Row | OLD | NEW |
|---|---|---|
| 2 (kb=0.5)  | 0.1082 / 19.84 / 0.82 / 82.15 | 0.0709 / 13.01 / 1.50 / 90.15 |
| 3 (kb=20)   | 0.1804 / 33.08 / 1.68 / 12.30 | 0.2030 / 37.22 / 1.50 / 18.62 |
| 4 (kb=100)  | 0.1865 / 34.20 / 1.74 / 2.55  | 0.2198 / 40.30 / 1.50 / 4.37 |
| 5 (ka=0.5)  | 0.1629 / 29.87 / 1.50 / 41.92 | 0.1628 / 29.85 / 1.50 / 47.73 |
| 6 (ka=100)  | 0.1629 / 29.87 / 1.50 / 41.92 | 0.1631 / 29.90 / 1.50 / 47.89 |
| 7 (μs=0.2)  | 0.3425 / 62.80 / 2.85 / 18.64 | 0.3425 / 62.79 / >6.0 / 5.79 |
| 8 (μs=0.5)  | 0.5296 / 97.10 / 4.90 / 5.12  | 0.5296 / 97.10 / >6.0 / 4.95 |
| 9 (μs=0.7)  | 0.6152 / 112.80 / >6.0 / 0.41 | **0.6180 / 113.30** / >6.0 / 4.82 |
| 10 (μs=2.0) | 0.9627 / 176.51 / >6.0 / 0.08 | 0.9627 / 176.50 / >6.0 / 4.60 |
| 11 (β=1.15) | 0.1105 / 20.26 / 0.95 / 58.40 | 0.1969 / 36.10 / 3.33 / 47.78 |
| 12 (β=2.00) | 0.1648 / 30.22 / 1.52 / 39.80 | 0.1625 / 29.79 / 0.80 / 47.79 |

Row 1 (baseline) unchanged: 0.1629 / 29.87 / 1.4962 / 47.79.
- Row 9: the $\mu_s^*=0.7$ cell is the user-directed correction to **0.617963** (current
  solver); vp(6) must move with it for self-consistency: 112.80 → 113.30 (flagged per
  instruction). ξ_c = 0.180 unchanged (verified 0.1834 fine-grid onset).
- Rows 7–10: ξ_trans column now ">6.0" — with stiffened surfaces the displacement ratio
  R_cb stays above 1 across the whole tracked range (outer-surface localization persists),
  so no interior crossover exists (old 2.85/4.90 values came from the stale solver state).
- J_b values: old 82.15/12.30/2.55/41.92/… were produced by the buggy branch selector;
  current-code J_b at ξ=6 on the physical branch gives the NEW column
  (interface-side maximum equals full-domain maximum, verified pointwise).

## J. Localization discussion text

- Regime-3 jump: "$J_b = 41.92\%$" → "$J_b = 47.79\%$".
- $R_{cb} \approx 0.1604$ at ξ=5 **verified correct** against current code (0.1604 exact);
  unchanged.

## K. Geometry bullet (shell thickness) — narrative reversed by current code

OLD: "thin shell (β=1.15) **lowers** the plateau to Ω≈0.11 … rises and saturates near 0.165".
NEW: "thin shell (β=1.15) **raises** the plateau to Ω(6)≈0.197 (radial confinement stiffens
the shell resonance); β=1.30–2.00 converge to Ω(6)≈0.162–0.168 (0.1629 at β=1.50,
0.1625 at β=2.00)". (regen S6: β=1.15→0.196903, β=1.30→0.167532, β=2.00→0.162489.)

## L. Sensing-framework sentence

OLD: "$S_{\mathrm{surface}}$ reaches 0.35–0.40".
NEW: normalized relative sensitivity "$S_{\mathrm{rel}} \approx 0.42$–$0.47$ at ξ=6
(for μs* = 0.5–1.2)" (computed with `track_physical_branch`, dG=0.02:
S_rel(6) = 0.4885/0.4778/0.4647/0.4522/0.4234 for G = 0.1/0.3/0.5/0.7/1.2;
S_abs(6) = 1.19/0.66/0.49/0.40/0.28).

## M. OAT sensitivity table (Table at ξ=6)

- $k_a^*$ row, L column: −0.6255 → −0.6209 (caption −0.626 → −0.621).
- $k_b^*$ row: +0.2373 → +0.2378 (Ω and vp columns), −0.4787 → −0.4795
  (caption S≈0.237 → 0.238). μs* row unchanged.

## N. Figures — all regenerated from current code

Regenerated via `master_figure_generator.py` (writes ALL_FIGURES/) and
`sensitivity_surface_check.py` + `make_journal_previews.py` (writes journal previews):
fig_validation_benchmark, fig_validation_limits, fig_convergence_residuals,
fig_interface_stiffness_comparison, fig_geometry_thickness, fig_localization_transition,
fig_sensing_framework, fig_dispersion_journal, fig_surface_journal, fig_parametric_journal,
fig_field_journal, fig_mode_shape_combined, fig_velocities_journal, fig_sensitivity_journal.
Benchmark prints **f_max = 145.024 kHz at k ≈ 7278.5–7292 rad/m** (tex value 145.02 kHz kept;
tex k=7291.9 within grid resolution, unchanged).

### Branch-selection bugs fixed in the generators (cause of the stale figures)

1. `fig_geometry_thickness`: the old `track_geom` did a first-det-crossing scan over Ω,
   which latched onto the spurious low branch-2 root for β≠1.5. Replaced by continuation
   (`core.track_branch` rank-1 from ξ=0.05 with patched `core.alpha/core.beta`).
2. `fig_sensing_framework`: plain rank-1 seeding at ξ=0.1 latched the spurious branch for
   some μs* values. Replaced by `core.track_physical_branch` on a 300-pt grid.
3. `sensitivity_surface_check.py`: fixed `TAU00` NameError (baseline τ₀* = 2e-6).

## O. Checklist — every solver-dependent table/figure re-executed against current core.py

| Item | Evidence (regen_all.py section / script) | Status |
|---|---|---|
| Table 5 branch-1 (incl. ξ_tr=1.4962, γ²-min, conv 2.24e-6/2.28e-7) | S1/S3 | verified, unchanged |
| Table 5 branch-2 | S2 | **updated (D)** |
| Ω_max 0.1709 fine-grid | S1 | verified 0.170915, unchanged |
| Benchmark table + f_max | S4 + benchmark_kielczynski.py | **updated (C)** |
| Limiting rigid/soft | S5 | **updated (F)** |
| μs sweep Ω6/onsets + G=0.7 k-spread 2.97e-4 | S7/S8 | verified, unchanged |
| ka sweep (\|ΔΩ\|<0.001, spread 2.61e-4) | S9 | verified, unchanged |
| kb sweep + 209.8 % | S10 | **updated (G)** |
| Geometry β/α sweeps | S6 | **updated (K)** |
| Table 7 + J_b + R_cb | S10/S11/S12 | **updated (I, J)** |
| OAT matrix | S12 | **updated (M)** |
| Sensitivity curves | sensitivity_surface_check.py | **updated (L)** |
| Velocities/ZGV text | S4-vg supplement | **updated (H)** |
| Figs 1–15 | master_figure_generator.py + previews | **regenerated (N)** |
| PDF | tectonic 0.15.0, 0 LaTeX errors | **recompiled** |

## P. Numbers confirmed CORRECT and deliberately left unchanged

ξ_trans = 1.4962; Ω_max = 0.1709; vp(6) baseline = 29.87 m/s; convergence
2.24e-6 / 2.28e-7; μs sweep {0.1629, 0.3425, 0.5296, 0.6180, 0.7239, 0.9627};
R_cb(5.0) = 0.1604; regime ratios 1.38 / 1.45; "zero interior local maxima" claim;
G–M μs-alone formulation; benchmark k and vp columns; f_max = 145.02 kHz.

---

# ADDENDUM — Round 3 corrections (2026-09-21, items 1–24)

Every item below was independently re-executed before editing (fresh SVD/root
solves from `core.py`; citations cross-checked against Crossref and nature.com).

## Group A — numerical
1. Table 7 row 1 J_b: 41.92 → **47.79** (fresh J_b(6)=47.7899; matches §8.2 prose).
2. Conclusions item 5: 72% → **209.8%** shift.
3. Benchmark item 1: k(f_max) 7291.9 → **7278.5 rad/m** (value printed by
   benchmark_kielczynski.py); f_max 145.02 kHz unchanged.

## Group B — range-scoped overclaims
4. §7.2 k_a* bullet + Table-6 caption: claim now scoped to the plateau
   (|ΔΩ|<3e-4 at ξ=6; full-range max |ΔΩ| = 0.0396 at ξ≈0.75).
5. §7.4 α bullet: scoped to plateau (|ΔΩ|<4e-4 at ξ=6; full-range max 0.180 at ξ≈0.43).

## Group C — wording
6. Table 1: "Strict grid independence" → "Grid-refinement convergence".
7. §6.3: "fully converged" → "sufficiently converged relative to the 600-point
   refinement (within 2.24e-6)".
8. §10.3: "R_cb ~ 2 in Regime 1" → "R_cb > 1 in Regime 1, reaching ~1.45 near the
   long-wavelength end".
9. §8: "rigorously confirms … complete characterization" → "confirms, over the
   investigated parameter range, … unambiguous characterization".
10. Abstract: "backward-wave anomalous dispersion (v_g<0) across the resonance
    plateau" → "backward-wave intervals characterized by negative group velocity in
    the resonance/plateau region" (v_g alternates sign across the plateau).
11. §9.2: "wavepackets are trapped and energy propagation ceases" → "the group
    velocity vanishes, indicating zero-group-velocity (ZGV) states".
12. §3.2: standalone inequality (ρs vp²)/μˢ ≪ 1e-3 removed (no ρ_s value is given
    anywhere); kept "ρ_s = 0 is an assumption of the present formulation".
13. §10.1: S_m restated as first-order/qualitative measure (mass-loaded eigenproblem
    with s44(3)(ω) not solved).
14. Benchmark claim (abstract/contributions/conclusions): now "reproducing the
    published tabulated wavenumbers and phase velocities within 0.02%, with the
    reported cylindrical cutoff frequency also recovered consistently";
    "in precise agreement" → "consistent with the published values".
15. μs*=0.7 anchoring claims (contributions, Fig-sweeps caption, §7.3, §8, §10):
    scoped to "the investigated portion of the physical branch (onset ξ~0.18 to ξ=6)";
    "eliminates sensitivity" → "strongly suppresses".
16. §7.4: causal "radial confinement stiffens the shell resonance" → descriptive
    "the thinner-shell configuration produces a higher plateau frequency".

## Group D — bibliography (verified via Crossref / nature.com)
17. ref45 title → "New Torsional Surface Elastic Waves in Cylindrical Metamaterial
    Waveguides for Sensing Applications", Sensors 25(1), 143 (2025), 10.3390/s25010143.
18. ref15 replaced → Kiełczyński, "New Shear Horizontal (SH) Surface-Plasmon-
    Polariton-like Elastic Surface Waves for Sensing Applications", Sensors 23(24),
    9879 (2023), 10.3390/s23249879 (old DOI 10.3390/app13042299 belonged to an
    unrelated paper — confirmed via Crossref).
19. ref20 title → "A holey-structured metamaterial for acoustic deep-subwavelength
    imaging", Nature Physics 7, 52–55 (2011) — verified directly on nature.com
    before editing; bogus issue number removed.
20. ref51 fixed and now cited in §10.3 viscosity paragraph: Kanazawa & Gordon,
    "Frequency of a quartz microbalance in contact with liquid", Anal. Chem. 57(8),
    1770–1771 (1985), DOI 10.1021/ac00285a062 (old DOI 10.1021/ac00285a058 belonged
    to a different paper — confirmed via Crossref).

## Group E — reproducibility hygiene
21. regen_all.py / followups.py / scoping_check.py: all hard-coded expectations
    updated to current values (47.79; branch-2 rows 0.000113/…/0.002444; cutoff
    0.1143; 7278.5; rigid 0.2247/soft 0.0709; kb 209.8%; geometry 0.1969/0.1625;
    row-9 0.617963). All three re-ran to completion, exit 0, every printed
    comparison now agrees (MATCH) with fresh computation.
22. benchmark_kielczynski.py: os.makedirs(out_dir, exist_ok=True) added — no longer
    exits 1 when the target directory is absent.
23. run_all_matlab_simulations.m / generate_all_manuscript_figures.m: failures are
    now collected and reported as "COMPLETED WITH N FAILURE(S)" listing failed
    modules; success message only printed when zero failures. (MATLAB not available
    in this environment — change is textual and follows the existing try/catch
    structure; not executed here.)
24. 14 book entries (ref1–6, 16, 23, 33, 34, 46–49) converted @article → @book with
    publisher/address(/edition/note) fields.

## Round-3 verification evidence
- Grep over tex for "72%", "72.3", "41.92", "7291.9", "R_{cb}\sim 2", "fully
  converged", "Strict grid", "rigorously confirms", "trapped", "precise agreement",
  "virtually zero", "0.6152", "0.1105", "0.1648", "0.1082", "0.1865", "0.1651",
  "≪10^{-3}": zero stale instances (remaining "metamaterial core" / "rigorously"
  hits in the PDF are legitimate body text: ST-quartz benchmark core; "rigorously
  retaining both modified Bessel functions").
- regen_all.py, followups.py, scoping_check.py: exit 0; outputs show fresh values
  matching every printed expectation (e.g. J_b 47.79==47.79; kb shift 209.8%==209.8%;
  scoping rows all MATCH incl. 0.6180).
- tectonic recompile: 0 LaTeX errors; compiled PDF reference list contains the four
  corrected entries (verified by text extraction, case-insensitive).

## Addendum 2 — MATLAB/Python figure equivalence (user query: "same graphs?")

Question checked by reading every Figure*.m tracking call:

- `torsional_waveguide_core.track_branch_continuation` seeds rank-1 at the first
  grid point that has >=1 root. For stiff-surface parameters the physical branch
  only coexists (as the HIGHEST root) beyond its onset, and there is a branch
  crossing region near xi~0.1-0.2, so grids starting at xi=0.1 latched the wrong
  branch (Figure08 panels, Figure14) — MATLAB would NOT have reproduced the
  corrected Python figures.
- Fixes applied:
  * `torsional_waveguide_core.m`: new `track_physical_branch()` — exact mirror of
    Python `core.track_physical_branch` (rank-1 from seed when >=2 roots or
    mus*<1e-12; else onset search for the 2nd root and re-seed).
  * Figure08/Figure14 grids changed xi=0.1 -> xi=0.05 (300 pts), i.e. seeded before
    the crossing region, same convention as the Python figures.
  * Figure08/09/14 plot the returned x-vector; Figure14 aligns the two tracked
    branches onto the common grid via ismember (onset re-seeding returns a
    shorter grid).
- Verification: the new MATLAB algorithm was emulated line-for-line in Python
  against `core.py`: Figure14 S_abs(6) = 1.1943/0.6629/0.3992/0.2762 (diff 0.00e+00
  vs the Python figure) and Figure08 panel-a Om6 = 0.162911/0.342475/0.529592/
  0.723920/0.962696 (identical to Table 7). Figure09 beta/alpha curves match the
  regenerated geometry figure at their xi grids.
- Caveat: MATLAB/Octave is not installed in this sandbox, so the .m edits were
  verified by algorithm emulation and structure/syntax parity with the existing
  file, not by executing MATLAB.

## Addendum 3 — MATLAB figure mismatch fixes (user-ran screenshots)

User ran the MATLAB suite; Figures 3, 5, 7, 8 did not match the manuscript.
Root causes and fixes (all in PROGRAMS/MATLAB):

- Fig 3 (limits): mu_s*=0.7 curve used rank-1 continuation seeded at xi=0.1 ->
  latched spurious branch. Now track_physical_branch, grid seeded at 0.05.
- Fig 5 (dispersion): branch-1 predictor-corrector on a 120-pt grid jumped to the
  spurious root in the steep crossing region; branch-2 then absorbed the plateau.
  Now branch 1 = track_physical_branch on 300-pt grid; branch 2 = rank-2
  continuation (unchanged); both match manuscript (emulated: b1 Om6=0.162911,
  b2 Om6=0.002444).
- Fig 7 (3D surface): per-row rank-1 from xi=0.1 latched spurious branch for
  mu_s*>=~0.2 (fold + capped height). Now per-row track_physical_branch seeded
  0.05 with NaN alignment into the mesh.
- Fig 8: already fixed in v3; the user's run predates that package.
- Additionally hardened: track_physical_branch now falls back to rank-1
  continuation when no two-root onset exists (single-branch parameter sets such
  as rigid/welded interfaces) instead of returning NaN; Figures 4, 6, 10, 13 and
  scripts 01-04, 06 switched to the same physical-branch tracker with 0.05 seeds.
- Emulation check of the exact MATLAB algorithm: rigid 0.224716, soft 0.070941,
  G=0 0.162911, base 0.162911, ka100 0.163077, kb100 0.219829, G=2 0.962696 —
  all identical to the regenerated manuscript values.
- Caveat unchanged: MATLAB not executable in this sandbox; .m changes verified by
  algorithm emulation + structural parity. Re-run generate_all_manuscript_figures.m
  with this package.

## Addendum 4 — Final cleanup pass (round 5)

Section A (tex/script):
1. L518 "reflects the geometric stiffening induced by cylindrical boundary
   curvature" -> "represents the frequency shift between the finite cylindrical
   configuration and the planar asymptotic limit."
2. Abstract anchoring claim scoped: "...over the investigated portion of the
   physical branch."
3. Conclusions anchoring claim scoped: "...across the investigated portion of
   the physical branch, from its modal onset to xi=6."
4. All "millimeter-scale/scale(s)" -> "sub-millimeter-..." (5 lines now
   sub-millimeter; zero bare "millimeter scale" remain).
5. L690 "physically measured atomistic..." -> "chosen to represent a weak
   surface-elasticity regime at the present sub-millimeter scale."
6. Absolute output paths removed: benchmark_kielczynski.py and
   make_journal_previews.py now derive OUT from __file__ (script_dir/../ALL_FIGURES)
   + makedirs. Fresh-clone test: copied PYTHON_SCRIPTS to /tmp/fresh_clone and ran
   benchmark, sensitivity_surface_check, make_journal_previews there — all wrote
   to /tmp/fresh_clone/ALL_FIGURES successfully.

Section B:
7. "topological structure" -> "dispersion characteristics".
8. "indispensable physical prerequisite" sentence -> "this negative-compliance
   regime provides the effective material condition underlying the evanescent
   SPP-like torsional surface states obtained in the present model."
9. make_journal_previews.py TAU00 = 2.0e-6 with the requested comment.
10/11. README/DIFF version refs: user's literal mapping said v3; since this
   release is v5, refs were set to v5 to avoid re-introducing staleness
   ("corrected manuscript (v5)", "full v1->v5 audit", "Notes on code fixes
   (v1-v5)", DIFF title "Package v5 (rounds 2-5 consolidated)"). Flagged
   deliberately as a deviation from the literal strings.
12. regen_all.py + followups.py re-run to full completion, exit 0 (full console
   output in the round-5 summary message).
13. Post-edit greps all clean (geometric stiffening / millimeter-scale /
   physically measured atomistic / topological structure / indispensable
   physical prerequisite / investigated spectrum: zero hits); tectonic
   recompile: 0 LaTeX errors.
Also: regen_all.py print-header labels refreshed (plateau band, residual range,
OAT header, ZGV header) so the audit script itself carries no stale strings.

Section C — Python<->MATLAB parity audit (read-and-compare, this round):

| Python file | MATLAB equivalent | Key value/logic compared | Match |
|---|---|---|---|
| core.py Mmat | torsional_waveguide_core.m compute_matrix_M | all 25 nonzero entries term-for-term; row-5 mu_s-alone G*xi^2*I1/K1, tau0 absent | Y |
| core.py track_physical_branch | core.m track_physical_branch (+fallback) | seed convention, rank-2 onset, single-branch fallback | Y |
| benchmark_kielczynski.py | kiel_dispersion_residual.m + Figure02 | identical residual terms/constants; f_max via k-parametrized peak search (=> k=7278.5 logic) | Y |
| sensitivity_surface_check.py OAT | Figure15_Sensitivity_Matrix.m | both fully dynamic (no hard-coded S); same baseline ka=kb=5, mus*=1e-5; tau0 from physical default | Y |
| (stale values sweep) | all *.m | grep 0.6152/41.92/72.3/7291.9/0.1082/0.1865/0.1105/0.1648/0.1651//home/user/TAU00: zero hits | Y |
| master_figure_generator.py R2 branch fixes | Figure03/05/06/07/08/09/10/13/14 + scripts 01-06 | physical-branch tracker + 0.05 seeds everywhere; no first-crossing scan or bare rank-1 seed remains | Y |

Newly found Python-fixed/MATLAB-missed gaps in THIS round: NONE (the last such
gaps — Figures 3/5/7 and scripts — were closed in the v4 round and re-confirmed
here by direct read).

## Addendum 5 — round 6 cleanup
1. benchmark_kielczynski.py print label "Curvature Stiffening Shift" ->
   "Finite-Cylinder Frequency Shift" (matches neutral tex wording; script
   re-run, label prints correctly).
2. full_study.py: option (b) — LEGACY banner added; not part of pipeline
   (consumes external matlab_pkg results; superseded by
   master_figure_generator.py). Listed in README "Legacy scripts".
3. make_mode_previews.py: option (b) — same treatment (superseded by
   make_journal_previews.py).
4. Tex: Sec 7.3 achievability claim -> "illustrative theoretical ... regime
   for parametric exploration"; Sec 11.2 -> "motivate future experimental
   investigation of the strong-surface-elasticity regime."
5. Conclusions backward-wave wording aligned with abstract.
6. (optional, applied) Table 7 row-1 label -> "Baseline (mu_s*=1.0e-5, k*=5)".
Grep: "Curvature Stiffening" zero hits in PYTHON; "/home/user" only in the two
README-listed legacy files. Tectonic recompile: 0 LaTeX errors.
