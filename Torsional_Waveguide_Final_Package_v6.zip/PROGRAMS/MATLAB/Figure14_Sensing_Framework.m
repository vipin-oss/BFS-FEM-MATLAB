%% =========================================================================
% FIGURE 14: THEORETICAL SURFACE-STIFFNESS SENSITIVITY FRAMEWORK
% =========================================================================
% Manuscript Reference: Figure 14 (Section 5)
%
% Physical Application:
%   Quantifies the transduction capability of the waveguide for acoustic sensors:
%     - Panel (a): Absolute sensitivity S_surface = dOmega / d(mu_s* + tau_0*)
%       evaluating frequency response per unit surface stiffening.
%     - Panel (b): Normalized relative sensitivity S_rel = (G / Omega) * S_surface
%       demonstrating peak sensitivity at moderate wavenumbers where surface
%       traction coupling is optimal.
%
% Output: Generates EXACT Figure 14 (fig_sensing_framework.png)
% =========================================================================

close all; clc;

fprintf('=================================================================\n');
fprintf('  REPRODUCING FIGURE 14: SENSING FRAMEWORK & SENSITIVITY CURVES  \n');
fprintf('=================================================================\n\n');

p_base = torsional_waveguide_core.get_default_parameters();
xi_pts = linspace(0.05, 6.0, 300);  % seed at 0.05: the physical branch must be
% captured before the xi~0.1-0.2 crossing region (same convention as Python core)

g_sweeps = [0.1, 0.3, 0.7, 1.2];
colors = {[0 0.447 0.741], [0.85 0.325 0.098], [0.466 0.674 0.188], [0.494 0.184 0.556]};

fig = figure('Name', 'Figure 14 - Sensing Framework', 'Color', 'w', ...
             'Position', [100, 100, 950, 400]);

subplot(1, 2, 1); hold on;
subplot(1, 2, 2); hold on;

dG = 0.02;
for i = 1:length(g_sweeps)
    g_val = g_sweeps(i);
    fprintf('Evaluating sensitivity for mu_s* = %g...\n', g_val);
    
    p_plus = p_base;
    p_plus.mus_star = g_val + dG;
    p_plus.tau0_star = 0.0;
    [xp, om_plus_r] = torsional_waveguide_core.track_physical_branch(xi_pts, p_plus);
    
    p_minus = p_base;
    p_minus.mus_star = max(g_val - dG, 0);
    p_minus.tau0_star = 0.0;
    [xm, om_minus_r] = torsional_waveguide_core.track_physical_branch(xi_pts, p_minus);

    % Align both tracked branches onto xi_pts (onset re-seeding can return a
    % shorter grid); untracked prefix stays NaN.
    om_plus  = NaN(size(xi_pts));
    om_minus = NaN(size(xi_pts));
    [~, lp] = ismember(xp, xi_pts); om_plus(lp > 0)  = om_plus_r(lp > 0);
    [~, lm] = ismember(xm, xi_pts); om_minus(lm > 0) = om_minus_r(lm > 0);

    sens_abs = (om_plus - om_minus) / (2 * dG);
    sens_rel = (g_val ./ (om_plus + 1e-12)) .* sens_abs;
    
    % Panel (a)
    subplot(1, 2, 1);
    plot(xi_pts, sens_abs, 'LineWidth', 1.8, 'Color', colors{i}, ...
         'DisplayName', sprintf('\\mu_s^*+\\tau_0^* = %g', g_val));
     
    % Panel (b)
    subplot(1, 2, 2);
    plot(xi_pts, sens_rel, 'LineWidth', 1.8, 'Color', colors{i}, ...
         'DisplayName', sprintf('\\mu_s^*+\\tau_0^* = %g', g_val));
end

% Decorate Subplot (a)
subplot(1, 2, 1);
xlabel('Dimensionless Wavenumber \xi');
ylabel('Absolute Sensitivity S_{surface} = \partial\Omega / \partial(\mu_s^*)');
title('(a) Absolute Sensitivity to Surface Stiffening', 'FontWeight', 'bold');
legend('Location', 'northeast');
grid on; box on;
xlim([0, 6]);

% Decorate Subplot (b)
subplot(1, 2, 2);
xlabel('Dimensionless Wavenumber \xi');
ylabel('Normalized Relative Sensitivity S_{rel}');
title('(b) Normalized Relative Sensitivity vs Wavenumber', 'FontWeight', 'bold');
legend('Location', 'southeast');
grid on; box on;
xlim([0, 6]);

if exist('sgtitle', 'builtin') || exist('sgtitle', 'file')
    sgtitle('Theoretical Surface-Stiffness Sensitivity Framework for Acoustic Sensors', ...
        'FontSize', 12, 'FontWeight', 'bold');
end

saveas(fig, 'fig_sensing_framework.png');
fprintf('Saved figure as: fig_sensing_framework.png\n');
