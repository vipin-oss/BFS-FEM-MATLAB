%% =========================================================================
% GENERATE_ALL_MANUSCRIPT_FIGURES.M
% =========================================================================
% Master Runner: Generates ALL 14 Scientific Figures Appearing in the
% Journal Manuscript "Torsional Surface Waves in a Thermoelastic Cylinder..."
%
% This script executes the exact from-scratch mathematical solvers for
% Figures 2 through 15:
%   - Figure 02: Quantitative Benchmark Validation (Kiełczyński et al. 2025)
%   - Figure 03: Limiting-Case Analytical & Numerical Verification
%   - Figure 04: Numerical Robustness, Convergence, & SVD Residuals
%   - Figure 05: Multi-Branch Dispersion Spectrum
%   - Figure 06: Interface Stiffness Comparison (Core ka* vs Shell kb*)
%   - Figure 07: 3D Dispersion Surface Omega(xi, G)
%   - Figure 08: Parametric Sweeps (Surface Elasticity & Springs)
%   - Figure 09: Geometric Sensitivity (Shell Thickness & Core Radius)
%   - Figure 10: Objective Wave Localization Metrics & Transition Crossover
%   - Figure 11: Radial Mode Shapes & Interfacial Displacement Step Jumps
%   - Figure 12: 2D Cross-Sectional Wave Field Distributions Re[u_theta(r,z)]
%   - Figure 13: Phase and Group Velocities & Backward-Wave Regime
%   - Figure 14: Theoretical Sensing Framework & Sensitivity Curves
%   - Figure 15: Logarithmic OAT Sensitivity Heatmap Matrix
%
% All figures are saved as PNG files with identical names and layouts
% to those in the manuscript.
% =========================================================================

close all; clc;

fprintf('==========================================================================\n');
fprintf('  REPRODUCING ALL 14 MANUSCRIPT FIGURES FROM SCRATCH (MATLAB / OCTAVE)    \n');
fprintf('==========================================================================\n\n');

figure_scripts = {
    'Figure02_Validation_Benchmark', ...
    'Figure03_Validation_Limits', ...
    'Figure04_Convergence_Residuals', ...
    'Figure05_Dispersion_Spectrum', ...
    'Figure06_Interface_Stiffness', ...
    'Figure07_Dispersion_Surface_3D', ...
    'Figure08_Parametric_Sweeps', ...
    'Figure09_Geometry_Thickness', ...
    'Figure10_Localization_Transition', ...
    'Figure11_Mode_Shapes_Combined', ...
    'Figure12_Field_Distribution_2D', ...
    'Figure13_Velocities_Phase_Group', ...
    'Figure14_Sensing_Framework', ...
    'Figure15_Sensitivity_Matrix'
};

t_start_all = tic;
failed_figs = {};

for k = 1:length(figure_scripts)
    s_name = figure_scripts{k};
    fprintf('\n>>> [%d/14] Running %s.m ...\n', k, s_name);
    t_single = tic;
    try
        run(s_name);
        fprintf('>>> [%d/14] %s finished in %.2f seconds.\n', k, s_name, toc(t_single));
    catch ME
        failed_figs{end+1} = s_name; %#ok<AGROW>
        fprintf('>>> Error in %s: %s\n', s_name, ME.message);
    end
end

fprintf('\n==========================================================================\n');
if isempty(failed_figs)
    fprintf('  ALL 14 FIGURES GENERATED WITHOUT ERRORS IN %.2f SECONDS.               \n', toc(t_start_all));
else
    fprintf('  COMPLETED WITH %d FAILURE(S) IN %.2f SECONDS. FAILED FIGURE SCRIPTS:   \n', numel(failed_figs), toc(t_start_all));
    for j = 1:numel(failed_figs)
        fprintf('    - %s\n', failed_figs{j});
    end
end
fprintf('==========================================================================\n');
