%% =========================================================================
% SCRIPT 01: DISPERSION RELATION, PHASE & GROUP VELOCITIES
% =========================================================================
% Problem:
%   Torsional surface waves propagating in a three-layer cylindrical
%   waveguide consisting of:
%     - Core (0 < r < a): Thermoelastic copper (isochoric, uncoupled)
%     - Intermediate layer (a < r < b): PMMA polymer
%     - Metamaterial shell (b < r < c): Drude-type ST-Quartz metamaterial
%     - Surface elasticity at r = c (Gurtin-Murdoch model)
%     - Imperfect spring interfaces at r = a and r = b
%
% What this script does (FROM ZERO, NO PRECOMPUTED DATA):
%   1. Loads the physical and dimensionless parameter structure.
%   2. Discretizes the dimensionless axial wavenumber xi = k*b.
%   3. Evaluates the 5x5 boundary condition determinant det(M(xi, Omega)).
%   4. Solves for the eigenfrequencies Omega(xi) using root finding and
%      predictor-corrector continuation.
%   5. Calculates Phase Velocity:  v_p = (Omega / xi) * v2  (m/s)
%   6. Calculates Group Velocity:  v_g = (dOmega / dxi) * v2 (m/s)
%   7. Identifies the Backward-Wave regime (v_g < 0) and Zero-Group-Velocity
%      (ZGV) point where energy velocity vanishes.
%   8. Plots publication-quality figures and prints numerical benchmarks.
% =========================================================================

close all;

fprintf('=================================================================\n');
fprintf('  SCRIPT 01: SOLVING TORSIONAL WAVEGUIDE DISPERSION FROM SCRATCH \n');
fprintf('=================================================================\n\n');

%% Step 1: Initialize Parameters
% Load default physical and dimensionless parameters defined in the manuscript
p = torsional_waveguide_core.get_default_parameters();

fprintf('Material Properties & Dimensionless Groups:\n');
fprintf('  Core (Copper):       mu1 = %.2e Pa, rho1 = %.1f kg/m^3 (m1 = %.2f)\n', p.mu1, p.rho1, p.m1);
fprintf('  Layer 2 (PMMA):      s44 = %.2e Pa^-1, rho2 = %.1f kg/m^3 (v2 = %.1f m/s)\n', p.s44_2, p.rho2, p.v2);
fprintf('  Layer 3 (Meta):      s0  = %.2e Pa^-1, rho3 = %.1f kg/m^3, fp = %.1f MHz\n', p.s0, p.rho3, p.fp*1e-6);
fprintf('  Geometry Ratios:     alpha = a/b = %.2f, beta = c/b = %.2f (b = %.2f mm)\n', p.alpha, p.beta, p.b*1e3);
fprintf('  Spring Stiffnesses:  ka* = %.2f, kb* = %.2f\n', p.ka_star, p.kb_star);
fprintf('  Surface Elasticity:  mus* = %.2e, tau0* = %.2e\n\n', p.mus_star, p.tau0_star);

%% Step 2: Define Wavenumber Grid
% xi = k * b represents the dimensionless wavenumber along the cylinder axis (z)
% We sweep from long waves (xi = 0.1) to short waves (xi = 5.0)
n_points = 100;
xi_vals = linspace(0.05, 5.0, n_points);

fprintf('Step 2: Tracking fundamental surface-wave branch across %d wavenumber points...\n', n_points);

%% Step 3: Solve Dispersion Equation from Scratch
% We trace the fundamental guided mode by continuation
[xi_sol, Omega_sol] = torsional_waveguide_core.track_physical_branch(xi_vals, p);

% Filter valid converged points
valid_mask = ~isnan(Omega_sol);
xi_valid   = xi_sol(valid_mask);
Omega_valid = Omega_sol(valid_mask);

if isempty(xi_valid)
    error('No dispersion roots found! Please verify parameter range.');
end

fprintf('  --> Successfully traced %d converged eigenfrequency points.\n\n', length(xi_valid));

%% Step 4: Calculate Velocities
% Dimensional phase velocity: v_p = (Omega / xi) * v2
vp_dim = (Omega_valid ./ xi_valid) * p.v2;

% Dimensional group velocity: v_g = (dOmega / dxi) * v2
% Computed via central numerical differences across the converged wavenumber points
dOmega_dxi = gradient(Omega_valid, xi_valid);
vg_dim = dOmega_dxi * p.v2;

% Detect Zero-Group-Velocity (ZGV) and Backward-Wave transitions:
% Backward wave occurs when phase velocity and group velocity have opposite signs
% (or here, when v_g < 0 while v_p > 0).
zgv_idx = find(diff(sign(vg_dim)) ~= 0);
if ~isempty(zgv_idx)
    xi_zgv = xi_valid(zgv_idx(1));
    Om_zgv = Omega_valid(zgv_idx(1));
    fprintf('  [CRITICAL FEATURE FOUND]: Zero-Group-Velocity (ZGV) point at:\n');
    fprintf('     Wavenumber xi_ZGV = %.4f (k = %.2f rad/mm)\n', xi_zgv, xi_zgv / (p.b*1e3));
    fprintf('     Frequency  Om_ZGV = %.4f (f = %.2f kHz)\n', Om_zgv, (Om_zgv / (2*pi*p.b*sqrt(p.rho2*p.s44_2)))*1e-3);
    fprintf('     Physical Significance: Group velocity vanishes (v_g = 0),\n');
    fprintf('     leading to stationary acoustic wave trapping and high-Q resonance.\n\n');
end

%% Step 5: Plot Publication-Quality Results
figure('Name', 'Dispersion and Velocity Curves', 'Color', 'w', 'Position', [100, 100, 950, 420]);

% --- Subplot 1: Dispersion Curve Omega(xi) ---
subplot(1, 2, 1);
plot(xi_valid, Omega_valid, 'b-', 'LineWidth', 2.2, 'DisplayName', 'Torsional Surface Wave (Mode 1)');
hold on;
plot(xi_vals, xi_vals, 'k--', 'LineWidth', 1.2, 'DisplayName', 'Bulk Shear Cone (\Omega = \xi)');

% Highlight evanescent region
fill([xi_vals, fliplr(xi_vals)], [xi_vals, zeros(size(xi_vals))], [0.9 0.95 1.0], ...
     'EdgeColor', 'none', 'FaceAlpha', 0.5, 'DisplayName', 'Guided Wave Regime (\gamma_2^{*2} > 0)');

xlabel('Dimensionless Axial Wavenumber \xi = k b', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('Dimensionless Frequency \Omega', 'FontSize', 11, 'FontWeight', 'bold');
title('(a) Dispersion Characteristic \Omega(\xi)', 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'northwest');
grid on;
box on;
xlim([0, 5.0]);
ylim([0, max(Omega_valid)*1.15]);

% --- Subplot 2: Phase and Group Velocities ---
subplot(1, 2, 2);
plot(xi_valid, vp_dim, 'r-', 'LineWidth', 2.2, 'DisplayName', 'Phase Velocity v_p');
hold on;
plot(xi_valid, vg_dim, 'Color', [0.1 0.6 0.2], 'LineWidth', 2.0, 'DisplayName', 'Group Velocity v_g');
plot([0, 5], [0, 0], 'k:', 'LineWidth', 1.2, 'DisplayName', 'Zero Velocity Baseline');
plot([0, 5], [p.v2, p.v2], 'm--', 'LineWidth', 1.2, 'DisplayName', sprintf('Bulk Speed v_2 = %.0f m/s', p.v2));

xlabel('Dimensionless Axial Wavenumber \xi = k b', 'FontSize', 11, 'FontWeight', 'bold');
ylabel('Wave Velocity (m/s)', 'FontSize', 11, 'FontWeight', 'bold');
title('(b) Phase & Group Velocities (m/s)', 'FontSize', 12, 'FontWeight', 'bold');
legend('Location', 'best');
grid on;
box on;
xlim([0, 5.0]);

fprintf('Execution finished successfully. Figures generated.\n');
