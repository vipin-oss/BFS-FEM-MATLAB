# LEGACY / OPTIONAL — NOT PART OF THE CURRENT REPRODUCIBILITY PIPELINE.
# Superseded by master_figure_generator.py (with sensitivity_surface_check.py
# and make_journal_previews.py for the journal previews). This script reads and
# writes files under an external matlab_pkg results directory that is not
# shipped in the package; kept for provenance only. See README "Legacy
# scripts" section.
# -*- coding: utf-8 -*-
"""
full_study.py — complete numerical study for the Phase-6 MATLAB package.
Self-contained mirror of the (planned) MATLAB dispersion_core.m + main scripts.
Generates: preview figures (a)-(d), results_table.csv, convergence check,
branch inventory, diagnostics (Omega_p crossing, evanescent checks).
"""
import numpy as np
from scipy.optimize import brentq
from scipy.special import iv, kv
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import csv

# ----------------------------- parameters ------------------------------------
mu1   = 3.86e10    # Pa
rho1  = 8954.0
rho2  = 1180.0
s44_2 = 70.03e-11
rho3  = 2650.0
s0    = 1.474e-11
fp    = 1.0e6
b     = 0.35016e-3
alpha = 0.5
beta  = 1.5
ka_s  = 5.0
kb_s  = 5.0
mus_s = 1.0e-5
tau0_s = 2.0e-6

m1      = mu1*s44_2
r12     = rho1/rho2
r32     = rho3/rho2
s2_s0   = s44_2/s0
omega_p = 2.0*np.pi*fp
Omega_p = omega_p*b*np.sqrt(rho2*s44_2)
v2      = 1.0/np.sqrt(rho2*s44_2)

print("m1=%.6f r12=%.5f r32=%.5f s2/s0=%.4f Omega_p=%.6f v2=%.3f"
      % (m1, r12, r32, s2_s0, Omega_p, v2))
print("mus*=%.3e tau0*=%.3e" % (mus_s, tau0_s))

# ----------------------------- core solver -----------------------------------
# VERIFIED: this M is EXACTLY main_dispersion_orig.m / verify_python_port.py
# (= manuscript N1-N5 in I2/K2 traction form). Do NOT alter.
def gammas2(xi, om, ka, kb, mus, tau0):
    """Return (g1^2, g2^2, g3^2, m3) or None if outside evanescent/m3-valid range."""
    if abs(om) < 1e-10:
        return None
    s43_over_s0 = 1.0 - (Omega_p**2)/(om**2)
    if abs(s43_over_s0) < 1e-12:
        return None
    m3 = s2_s0/s43_over_s0
    g12 = xi*xi - r12*om*om/m1
    g22 = xi*xi - om*om
    g32 = xi*xi - r32*om*om/m3
    if g12 <= 0 or g22 <= 0 or g32 <= 0:
        return None
    return g12, g22, g32, m3

def Dfun(xi, om, ka, kb, mus, tau0):
    g = gammas2(xi, om, ka, kb, mus, tau0)
    if g is None:
        return np.nan
    g12, g22, g32, m3 = g
    g1, g2, g3 = np.sqrt(g12), np.sqrt(g22), np.sqrt(g32)
    a, c, G = alpha, beta, mus
    M = np.zeros((5, 5))
    M[0, 0] = m1*g1*iv(2, a*g1)
    M[0, 1] = -g2*iv(2, a*g2)
    M[0, 2] = g2*kv(2, a*g2)
    M[1, 0] = m1*g1*iv(2, a*g1) + ka*iv(1, a*g1)
    M[1, 1] = -ka*iv(1, a*g2)
    M[1, 2] = -ka*kv(1, a*g2)
    M[2, 1] = g2*iv(2, g2)
    M[2, 2] = -g2*kv(2, g2)
    M[2, 3] = -m3*g3*iv(2, g3)
    M[2, 4] = m3*g3*kv(2, g3)
    M[3, 1] = g2*iv(2, g2) + kb*iv(1, g2)
    M[3, 2] = -g2*kv(2, g2) + kb*kv(1, g2)
    M[3, 3] = -kb*iv(1, g3)
    M[3, 4] = -kb*kv(1, g3)
    M[4, 3] = m3*g3*iv(2, c*g3) + G*xi*xi*iv(1, c*g3)
    M[4, 4] = -m3*g3*kv(2, c*g3) + G*xi*xi*kv(1, c*g3)
    d = np.linalg.det(M)
    if not np.isfinite(d):
        return np.nan
    return d

def find_roots_at_xi(xi, ka, kb, mus, tau0, ngrid=4000, om_max=None):
    if om_max is None:
        om_max = 0.9999*xi
    grid = np.linspace(1e-4, om_max, ngrid)
    vals = [Dfun(xi, o, ka, kb, mus, tau0) for o in grid]
    roots = []
    for i in range(ngrid-1):
        f1, f2 = vals[i], vals[i+1]
        if np.isnan(f1) or np.isnan(f2) or f1 == 0.0:
            continue
        if f1*f2 < 0:
            try:
                r = brentq(lambda o: Dfun(xi, o, ka, kb, mus, tau0),
                            grid[i], grid[i+1], xtol=1e-13, rtol=1e-14, maxiter=200)
                if not any(abs(r-x) < 1e-7 for x in roots):
                    roots.append(r)
            except Exception:
                pass
    return sorted(roots, reverse=True)

def track_branch(ka, kb, mus, tau0, xi_grid, seed_xi, branch_rank,
                 windows=None, max_jump=0.30, verbose=False):
    """Continuation with linear-extrapolation predictor; reports jumps/loss."""
    if windows is None:
        windows = [0.01, 0.02, 0.05, 0.10, 0.20]
    info = dict(xi=[], om=[], ok_mask=[], jumps=[], loss_count=0, lost_at=None)
    prev = None; prev2 = None
    for xi in xi_grid:
        om = None
        if prev is None:
            roots = find_roots_at_xi(xi, ka, kb, mus, tau0)
            if branch_rank <= len(roots):
                om = roots[branch_rank-1]
        else:
            pred = prev if prev2 is None else 2.0*prev - prev2
            for w in windows:
                lo, hi = max(pred-w, 1e-8), min(pred+w, 0.9999*xi)
                if hi <= lo:
                    continue
                grid = np.linspace(lo, hi, 40)
                vals = [Dfun(xi, o, ka, kb, mus, tau0) for o in grid]
                found = False
                for i in range(len(grid)-1):
                    f1, f2 = vals[i], vals[i+1]
                    if np.isnan(f1) or np.isnan(f2) or f1*f2 >= 0:
                        continue
                    try:
                        r = brentq(lambda o: Dfun(xi, o, ka, kb, mus, tau0),
                                   grid[i], grid[i+1], xtol=1e-13, rtol=1e-14,
                                   maxiter=200)
                        if om is None or abs(r-pred) < abs(om-pred):
                            om = r
                        found = True
                    except Exception:
                        pass
                if found:
                    break
        if om is None:
            info["loss_count"] += 1
            if info["lost_at"] is None and info["loss_count"] > 25:
                info["lost_at"] = xi
            if verbose:
                print("  xi=%.4f: NO ROOT (loss %d)" % (xi, info["loss_count"]))
            info["ok_mask"].append(False)
        else:
            if prev is not None and abs(om-prev) > max_jump*max(1.0, abs(prev)):
                info["jumps"].append((xi, prev, om))
                if verbose:
                    print("  xi=%.4f: JUMP %.6f -> %.6f" % (xi, prev, om))
            info["ok_mask"].append(True)
            prev2 = prev; prev = om
        info["xi"].append(xi)
        info["om"].append(om if om is not None else np.nan)
    info["xi"] = np.array(info["xi"])
    info["om"] = np.array(info["om"])
    info["ok_mask"] = np.array(info["ok_mask"])
    return info

def find_branch_onset(xi_lo, xi_hi, n, ka, kb, mus, tau0, rank):
    """Smallest xi in [xi_lo,xi_hi] where at least `rank` roots exist."""
    for xi in np.linspace(xi_lo, xi_hi, n):
        if len(find_roots_at_xi(xi, ka, kb, mus, tau0)) >= rank:
            return xi
    return None

# ----------------------------- main study ------------------------------------
xi_min, xi_max, n_xi = 0.05, 6.0, 300
xi_grid = np.linspace(xi_min, xi_max, n_xi)

print("\n--- multi-branch tracking (fundamental + onsets) ---")
branches = {}
b1 = track_branch(ka_s, kb_s, mus_s, tau0_s, xi_grid, xi_min, 1)
branches[1] = b1
print("branch 1: %d/%d tracked, jumps=%d, lost_at=%s" %
      (b1["ok_mask"].sum(), len(b1["xi"]), len(b1["jumps"]), b1["lost_at"]))

xi_on2 = find_branch_onset(xi_min, 0.5, 90, ka_s, kb_s, mus_s, tau0_s, 2)
print("branch 2 onset xi ~ %.4f" % (xi_on2 if xi_on2 else -1))
if xi_on2 is not None:
    grid2 = xi_grid[xi_grid >= xi_on2]
    b2 = track_branch(ka_s, kb_s, mus_s, tau0_s, grid2, xi_on2, 2)
    branches[2] = b2
    print("branch 2: %d/%d tracked, jumps=%d, lost_at=%s" %
          (b2["ok_mask"].sum(), len(b2["xi"]), len(b2["jumps"]), b2["lost_at"]))

xi_on3 = find_branch_onset(0.5, 10.0, 95, ka_s, kb_s, mus_s, tau0_s, 3)
print("branch 3 onset xi in (0.5,10]: %s" % (xi_on3 if xi_on3 else "NOT FOUND"))

# ---- diagnostics (a): Omega_p crossing ----
print("\n--- diagnostic (a): Omega vs Omega_p ---")
for k, binfo in branches.items():
    ok = binfo["ok_mask"]
    om = binfo["om"][ok]
    if len(om):
        print("branch %d: max Omega = %.6f (Omega_p = %.6f) -> crosses: %s" %
              (k, om.max(), Omega_p, bool(om.max() > Omega_p)))

# ---- diagnostics (b): evanescent conditions ----
print("\n--- diagnostic (b): evanescent checks (min of each gamma^2) ---")
for k, binfo in branches.items():
    ok = binfo["ok_mask"]
    g1m, g2m, g3m = np.inf, np.inf, np.inf
    for xi, om in zip(binfo["xi"][ok], binfo["om"][ok]):
        g = gammas2(xi, om, ka_s, kb_s, mus_s, tau0_s)
        if g is not None:
            g1m = min(g1m, g[0]); g2m = min(g2m, g[1]); g3m = min(g3m, g[2])
    print("branch %d: min g1^2=%.4e  min g2^2=%.4e  min g3^2=%.4e  (all >0: %s)" %
          (k, g1m, g2m, g3m, bool(g1m>0 and g2m>0 and g3m>0)))

# ---- diagnostic (c): convergence ----
print("\n--- diagnostic (c): convergence ---")
xi_fine = np.linspace(xi_min, xi_max, 600)
b1f = track_branch(ka_s, kb_s, mus_s, tau0_s, xi_fine, xi_min, 1,
                   windows=[0.005, 0.01, 0.02, 0.05, 0.10])
ok = b1["ok_mask"]; okf = b1f["ok_mask"]
om_fine_at_coarse = np.interp(b1["xi"][ok], b1f["xi"][okf], b1f["om"][okf])
dOm = np.abs(b1["om"][ok] - om_fine_at_coarse)
print("branch 1: 300-pt vs 600-pt(+tight windows): max |dOmega| = %.3e" % dOm.max())
print("  => unchanged beyond plotting resolution: %s" % bool(dOm.max() < 1e-3))

# ----------------------------- table ------------------------------------------
print("\n--- results table ---")
xi_rep = [0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0]
rows = []
for k, binfo in branches.items():
    ok = binfo["ok_mask"]
    xig, omg = binfo["xi"][ok], binfo["om"][ok]
    if len(xig) < 3:
        continue
    vp = omg/xig*v2
    dOm_dxi = np.gradient(omg, xig)
    vg = dOm_dxi*v2
    for xr in xi_rep:
        i = int(np.argmin(np.abs(xig-xr)))
        if abs(xig[i]-xr) > 0.05:
            continue
        om = omg[i]
        rows.append([k, xig[i], om, vp[i], vg[i],
                     "metamaterial (Omega<Omega_p)" if om < Omega_p
                     else "conventional (Omega>Omega_p)"])
hdr = ["branch", "xi", "Omega", "vp_m_s", "vg_m_s", "regime"]
with open("/home/user/matlab_pkg/results_table.csv", "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(hdr)
    w.writerows(rows)
for r in rows:
    print("br%d  xi=%6.3f  Om=%.6f  vp=%10.4f  vg=%12.6f  %s" %
          (r[0], r[1], r[2], r[3], r[4], r[5]))

# ----------------------------- figures ----------------------------------------
fig, ax = plt.subplots(figsize=(3.5, 2.8), dpi=150)
for k, binfo in branches.items():
    ok = binfo["ok_mask"]
    lbl = "branch 1 (fundamental)" if k == 1 else "branch 2"
    ax.plot(binfo["xi"][ok], binfo["om"][ok], "b-", lw=1.6, label=lbl)
xx = np.linspace(0, 6, 2)
ax.plot(xx, xx, "k--", lw=1, label=r"bulk $\Omega=\xi$")
ax.axhline(Omega_p, color="r", ls=":", lw=1.2, label=r"$\Omega_p$ (cutoff)")
ax.set_xlabel(r"$\xi = kb$"); ax.set_ylabel(r"$\Omega = \omega b\sqrt{\rho_2 s_{44}^{(2)}}$")
ax.set_xlim(0, 6); ax.set_ylim(0, 2.5)
ax.grid(alpha=0.3); ax.legend(fontsize=8)
fig.tight_layout()
fig.savefig("/home/user/matlab_pkg/preview_a.png")

fig, ax = plt.subplots(figsize=(3.5, 2.8), dpi=150)
for k, binfo in branches.items():
    ok = binfo["ok_mask"]
    xig, omg = binfo["xi"][ok], binfo["om"][ok]
    ax.plot(xig, omg/xig*v2, "b-", lw=1.6,
            label="branch %d" % k)
ax.plot([0,6],[0,6], "k--", lw=1, label="bulk v2")
ax.set_xlabel(r"$\xi$"); ax.set_ylabel(r"$v_p$ (m/s)")
ax.set_xlim(0,6); ax.set_ylim(0, 1200)
ax.grid(alpha=0.3); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig("/home/user/matlab_pkg/preview_b.png")

fig, ax = plt.subplots(figsize=(3.5, 2.8), dpi=150)
for k, binfo in branches.items():
    ok = binfo["ok_mask"]
    xig, omg = binfo["xi"][ok], binfo["om"][ok]
    vg = np.gradient(omg, xig)*v2
    ax.plot(xig, vg, "b-", lw=1.6, label="branch %d" % k)
ax.plot([0,6],[0,6], "k--", lw=1, label="bulk v2")
ax.set_xlabel(r"$\xi$"); ax.set_ylabel(r"$v_g$ (m/s)")
ax.set_xlim(0,6); ax.set_ylim(-200, 1400)
ax.grid(alpha=0.3); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig("/home/user/matlab_pkg/preview_c.png")

# PHYSICAL branch = the one continuous with the s=0 fundamental as s->0+
# (verified: upper root -> 0.025114 at xi=0.05 as s->0; lower root -> 0).
# If seed has >=2 roots, rank 1 IS the physical branch; if seed has 1 root
# (spurious low-freq mode only), find the physical branch's onset xi_c.
def track_physical_branch(ka, kb, mus, tau0, xi_g, n_on=200):
    roots0 = find_roots_at_xi(xi_g[0], ka, kb, mus, tau0)
    # s=0: single root at seed IS the physical branch (no 2nd branch exists)
    if len(roots0) >= 2 or mus < 1e-12:
        return track_branch(ka, kb, mus, tau0, xi_g, xi_g[0], 1), xi_g[0]
    xi_on = find_branch_onset(xi_g[0], min(xi_g[-1], 3.0), n_on,
                              ka, kb, mus, tau0, 2)
    if xi_on is None:
        return None, None
    g2 = xi_g[xi_g >= xi_on]
    return track_branch(ka, kb, mus, tau0, g2, xi_on, 1), xi_on

surf_vals = [0.0, 0.2, 0.5, 1.0, 2.0]
fig, ax = plt.subplots(figsize=(3.5, 2.8), dpi=150)
xi_g = np.linspace(xi_min, xi_max, 200)
print("\n--- sweep 1: surface elasticity (physical branch) ---")
for s in surf_vals:
    bi, on = track_physical_branch(ka_s, kb_s, s, 0.0, xi_g)
    ok = bi["ok_mask"]
    lbl = r"$\mu_s^* = %s$" % s
    if on > xi_min + 1e-9:
        lbl += " (onset %.2f)" % on
    ax.plot(bi["xi"][ok], bi["om"][ok], lw=1.5, label=lbl)
    print("s=%.1f onset=%.4f end_Omega=%.4f jumps=%d" %
          (s, on, bi["om"][ok][-1], len(bi["jumps"])))
ax.axhline(Omega_p, color="r", ls=":", lw=1, label=r"$\Omega_p$")
ax.set_xlabel(r"$\xi$"); ax.set_ylabel(r"$\Omega$")
ax.set_xlim(0,6); ax.set_ylim(0,2.5)
ax.grid(alpha=0.3); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig("/home/user/matlab_pkg/preview_d1.png")

k_vals = [0.5, 2.0, 5.0, 20.0, 100.0]
fig, ax = plt.subplots(figsize=(3.5, 2.8), dpi=150)
print("--- sweep 2: spring stiffness (physical branch) ---")
for ksv in k_vals:
    bi, on = track_physical_branch(ksv, ksv, 0.5, 0.2, xi_g)
    ok = bi["ok_mask"]
    lbl = r"$k_a^*=k_b^* = %s$" % ksv
    if on > xi_min + 1e-9:
        lbl += " (onset %.2f)" % on
    ax.plot(bi["xi"][ok], bi["om"][ok], lw=1.5, label=lbl)
    print("k*=%.4g onset=%.4f end_Omega=%.4f jumps=%d" %
          (ksv, on, bi["om"][ok][-1], len(bi["jumps"])))
ax.axhline(Omega_p, color="r", ls=":", lw=1, label=r"$\Omega_p$")
ax.set_xlabel(r"$\xi$"); ax.set_ylabel(r"$\Omega$")
ax.set_xlim(0,6); ax.set_ylim(0,2.5)
ax.grid(alpha=0.3); ax.legend(fontsize=8)
fig.tight_layout(); fig.savefig("/home/user/matlab_pkg/preview_d2.png")

print("\nfigures: preview_a.png preview_b.png preview_c.png preview_d1.png preview_d2.png")
print("DONE")
