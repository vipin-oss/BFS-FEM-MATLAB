#!/usr/bin/env python3
"""make_journal_previews.py — ALL journal figures from ONE shared code path.

Every figure (and its styling) comes from house_style.py, so the 7 figures
are provably consistent (font family, absolute font sizes, palette, line/
marker/legend/grid conventions). Canvas sizes are the ACTUAL print widths
(single-column manuscript, \\textwidth = 6.06 in):
    0.95\\textwidth = 5.76 in (two-panel), 0.90 = 5.45, 0.80 = 4.85,
    0.70\\textwidth = 4.24 in (3D surface).

Figures produced (the paper's complete data-figure set):
    1. fig_dispersion_journal.png      4.2 two-series line+marker
    2. fig_velocities_journal.png      4.3 1x2 (a) vp (b) vg
    3. fig_mode_shape_combined.png     4.4 1x2 (a) base (b) k* at xi=6
    4. fig_field_journal.png           4.4 1x2 Re[u(r,z)] at two xi
    5. fig_surface_journal.png         4.4 3D Omega(xi, G)
    6. fig_sensitivity_journal.png     4.5 3x4 log-OAT heatmap
    7. fig_parametric_journal.png      4.5 1x2 (a) G sweep (b) k* sweep
"""
import os
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

import house_style as H
import core as C
from mode_shape_check import mode_shape

H.setup()
PARULA = H.PARULA
BLUE, ORANGE = H.BLUE, H.ORANGE
A_MM, B_MM, C_MM = H.A_MM, H.B_MM, H.C_MM
V2 = C.v2

OUT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                   '..', 'ALL_FIGURES'))
os.makedirs(OUT, exist_ok=True)
KA0, KB0, MUS0 = 5.0, 5.0, 1.0e-5
TAU00 = 2.0e-6  # baseline tau0* = 2e-6; cancels from torsional incremental traction per the corrected G-M formulation.
XI_F = np.linspace(0.05, 6.0, 300)

# ---------------------------------------------------------------- branches
b1 = C.track_branch(KA0, KB0, MUS0, TAU00, XI_F, XI_F[0], 1)
b2 = C.track_branch(KA0, KB0, MUS0, TAU00, XI_F, XI_F[0], 2)
m1, m2 = b1["ok_mask"], b2["ok_mask"]

def base_profile(target_xi):
    """normalized |u(r)| of the base branch at the tracked point nearest
    target_xi (mm grid, normalized to max = 1)."""
    xip, omp = b1["xi"][m1], b1["om"][m1]
    i = int(np.argmin(np.abs(xip - target_xi)))
    xi, om = xip[i], omp[i]
    ms = mode_shape(xi, om, KA0, KB0, MUS0, TAU00)
    b_ = C.b
    r = np.concatenate([np.linspace(1e-4, C.alpha, 60)*b_,
                        np.linspace(C.alpha, 1.0, 60)*b_,
                        np.linspace(1.0, C.beta, 60)*b_])*1e3
    A1, B1, B2, C1, C2 = ms["v"]; g1, g2, g3 = ms["g1"], ms["g2"], ms["g3"]
    rb = (r*1e-3)/b_
    u = np.abs(np.where(rb <= C.alpha, A1*C.iv(1, g1*rb),
        np.where(rb <= 1.0, B1*C.iv(1, g2*rb)+B2*C.kv(1, g2*rb),
                          C1*C.iv(1, g3*rb)+C2*C.kv(1, g3*rb))))
    return r, u/u.max(), xi

def spring_profile(k):
    """normalized |u(r)| at xi = 6 for ka*=kb*=k with O(1) GM
    (mus*=0.7, tau0*=0.0)."""
    b, on = C.track_physical_branch(k, k, 0.7, 0.0, XI_F)
    om = b["om"][b["ok_mask"]][-1]; xi = b["xi"][b["ok_mask"]][-1]
    ms = mode_shape(xi, om, k, k, 0.7, 0.0)
    b_ = C.b
    r = np.concatenate([np.linspace(1e-4, C.alpha, 60)*b_,
                        np.linspace(C.alpha, 1.0, 60)*b_,
                        np.linspace(1.0, C.beta, 60)*b_])*1e3
    A1, B1, B2, C1, C2 = ms["v"]; g1, g2, g3 = ms["g1"], ms["g2"], ms["g3"]
    rb = (r*1e-3)/b_
    u = np.abs(np.where(rb <= C.alpha, A1*C.iv(1, g1*rb),
        np.where(rb <= 1.0, B1*C.iv(1, g2*rb)+B2*C.kv(1, g2*rb),
                          C1*C.iv(1, g3*rb)+C2*C.kv(1, g3*rb))))
    return r, u/u.max()

# ---------------------------------------------------------------- 1. dispersion
fig, ax = plt.subplots(figsize=(5.45, 4.4))
ax.plot([0, 6], [0, 6], "k--", lw=1.2)
ax.plot([0, 6], [C.Omega_p]*2, "r:", lw=1.2)
H.open_line(ax, b1["xi"][m1], b1["om"][m1], BLUE, "o")
H.open_line(ax, b2["xi"][m2], b2["om"][m2], ORANGE, "s")
ax.set_xlim(0, 6); ax.set_ylim(0, 2.6)
ax.set_xlabel(r"$\xi = kb$"); ax.set_ylabel(r"$\Omega = \omega b\sqrt{\rho_2 s_{44}^{(2)}}$")
handles = [plt.Line2D([], [], color="k", ls="--", lw=1.2),
           plt.Line2D([], [], color="r", ls=":", lw=1.2),
           plt.Line2D([], [], color=BLUE, lw=1.5, marker="o", mfc="w", ms=5),
           plt.Line2D([], [], color=ORANGE, lw=1.5, marker="s", mfc="w", ms=5)]
ax.legend(handles,
          [r"$\Omega=\xi$ (bulk)", r"$\Omega_p$ (cutoff)", "branch 1 (surface wave)", "branch 2 (secondary)"],
          loc="upper right", frameon=True, fontsize=8.5,
          handlelength=1.8, handletextpad=0.5, labelspacing=0.4, borderpad=0.5)
H.apply(ax)
fig.tight_layout(); fig.savefig(f"{OUT}/fig_dispersion_journal.png"); plt.close(fig)

# ---------------------------------------------------------------- 2. velocities 1x2
fig, axs = plt.subplots(1, 2, figsize=(5.76, 2.9))
vp1 = b1["om"][m1]/b1["xi"][m1]*V2
vp2 = b2["om"][m2]/b2["xi"][m2]*V2
def vg(om, xi):
    n = len(om); d = np.zeros(n)
    d[0] = (om[1]-om[0])/(xi[1]-xi[0]); d[-1] = (om[-1]-om[-2])/(xi[-1]-xi[-2])
    d[1:-1] = (om[2:]-om[:-2])/(xi[2:]-xi[:-2])
    return d*V2
vg1, vg2 = vg(b1["om"][m1], b1["xi"][m1]), vg(b2["om"][m2], b2["xi"][m2])
for ax, vv1, vv2, lab, ttl in (
        (axs[0], vp1, vp2, r"$v_p$ (m/s)", r"(a) phase velocity"),
        (axs[1], vg1, vg2, r"$v_g$ (m/s)", r"(b) group velocity")):
    H.open_line(ax, b1["xi"][m1], vv1, BLUE, "o")
    H.open_line(ax, b2["xi"][m2], vv2, ORANGE, "s")
    ax.plot([0, 6], [V2]*2, "k--", lw=1.2)
    ax.set_xlim(0, 6)
    ax.set_ylim(-100, 1300)            # room above the v2 = 1100 m/s line
    ax.set_yticks([0, 300, 600, 900, 1200])
    ax.set_xlabel(r"$\xi = kb$"); ax.set_ylabel(lab)
    H.panel_title(ax, ttl)
    H.apply(ax)
handles = [plt.Line2D([], [], color=BLUE, lw=1.5, marker="o", mfc="w", ms=5),
           plt.Line2D([], [], color=ORANGE, lw=1.5, marker="s", mfc="w", ms=5),
           plt.Line2D([], [], color="k", ls="--", lw=1.2)]
fig.legend(handles, ["branch 1 (surface wave)", "branch 2 (secondary)", r"bulk $v_2$"],
           loc="lower center", ncol=3, frameon=True, fontsize=8.5,
           bbox_to_anchor=(0.5, -0.04), handlelength=1.8)
fig.tight_layout(rect=[0, 0.10, 1, 1])
fig.savefig(f"{OUT}/fig_velocities_journal.png"); plt.close(fig)

# ---------------------------------------------------------------- 3. mode shape 1x2 combined
fig, axs = plt.subplots(1, 2, figsize=(5.76, 2.9))
# panel (a): base case at the two representative xi
ra, ua, xia = base_profile(0.507692)
rb, ub, xib = base_profile(5.005017)
ax = axs[0]
ax.plot(ra, ua, color=BLUE, lw=1.6, label=r"$\xi = %.2f$" % xia)
ax.plot(rb, ub, color=ORANGE, lw=1.6, label=r"$\xi = %.2f$" % xib)
H.layer_regions(ax)
ax.set_xlim(0, C_MM); ax.set_ylim(0, 1.18)
ax.set_xlabel("r (mm)"); ax.set_ylabel(r"$|u_\theta|$ (normalized)")
H.panel_title(ax, r"(a) branch 1 (base case)")
H.legend_box(ax, "upper left")
H.apply(ax, grid=False)
# panel (b): spring-stiffness comparison at xi = 6
rk5, uk5 = spring_profile(0.5)
rk100, uk100 = spring_profile(100.0)
ax = axs[1]
ax.plot(rk5, uk5, color=BLUE, lw=1.6, marker="o", markevery=12, mfc="w", ms=5, label=r"$k^* = 0.5$")
ax.plot(rk100, uk100, color=ORANGE, lw=1.6, marker="s", markevery=12, mfc="w", ms=5, label=r"$k^* = 100$")
H.layer_regions(ax)
ax.set_xlim(0, C_MM); ax.set_ylim(0, 1.18)
ax.set_xlabel("r (mm)"); ax.set_ylabel(r"$|u_\theta|$ (normalized)")
H.panel_title(ax, r"(b) $k^*$ sweep, $\xi = 6$")
H.legend_box(ax, "upper left")
H.apply(ax, grid=False)
fig.tight_layout()
fig.savefig(f"{OUT}/fig_mode_shape_combined.png"); plt.close(fig)

# ---------------------------------------------------------------- 4. field 1x2
def field(xi, om):
    ms = mode_shape(xi, om, KA0, KB0, MUS0, TAU00)
    A1, B1, B2, C1, C2 = ms["v"]
    g1, g2, g3 = ms["g1"], ms["g2"], ms["g3"]
    b_ = C.b
    r = np.linspace(1e-4*b_, C.beta*b_, 200); rbb = r/b_
    u = np.where(rbb <= C.alpha, A1*C.iv(1, g1*rbb),
        np.where(rbb <= 1.0, B1*C.iv(1, g2*rbb)+B2*C.kv(1, g2*rbb),
                          C1*C.iv(1, g3*rbb)+C2*C.kv(1, g3*rbb)))
    zb = np.linspace(0, 2*np.pi/xi, 256)
    F = (np.exp(1j*xi*zb[:, None]) * u[None, :]).real   # (nz, nr)
    return r*1e3, zb, F, np.abs(u).max()

fig, axs = plt.subplots(1, 2, figsize=(5.45, 2.85))
info = []
for ax, xi, om, ttl in ((axs[0], 0.507692, 0.158897, r"(a) $\xi=0.5077,\ \Omega=0.158897$"),
                        (axs[1], 5.005017, 0.164304, r"(b) $\xi=5.0050,\ \Omega=0.164304$")):
    r, zb, U, um = field(xi, om)
    R, Z = np.meshgrid(r, zb)
    pc = ax.pcolormesh(R, Z, U, shading="auto", cmap=PARULA)
    pc.set_clim(-um, um)
    # layer-boundary lines at r = a and r = b (shared convention)
    ax.axvline(A_MM, color="k", ls="--", lw=0.8)
    ax.axvline(B_MM, color="k", ls="--", lw=0.8)
    ax.set_xlim(0, C_MM)
    ax.set_xlabel("r (mm)"); ax.set_ylabel("z/b (one wavelength)")
    H.panel_title(ax, ttl)
    ax.grid(False)
    H.apply(ax, grid=False)
    cb = fig.colorbar(pc, ax=ax, pad=0.02)
    cb.set_ticks([-um, 0, um]); cb.ax.tick_params(labelsize=7.5)
    info.append(um)
fig.tight_layout()
fig.savefig(f"{OUT}/fig_field_journal.png"); plt.close(fig)
print("field max|u|: %.4f / %.4f  ratio %.2f" % (info[0], info[1], info[0]/info[1]))

# ---------------------------------------------------------------- 5. surface 3D
try:
    Zs = np.load("/tmp/omega_grid.npy"); Gg = np.load("/tmp/omega_ggrid.npy"); Xg = np.load("/tmp/omega_xgrid.npy")
except FileNotFoundError:
    print("surface grid npy missing (rerun sensitivity_surface_check.py)"); Zs = None
if Zs is not None:
    fig = plt.figure(figsize=(4.24, 3.6))
    ax3 = fig.add_subplot(111, projection="3d")
    # (preview-only: matplotlib's painter's algorithm artifacts on large
    # flat sheets at elev=28 -> preview uses elev=45; MATLAB keeps
    # the reference-convention view(42, 28))
    Xg2 = np.linspace(Xg[0], Xg[-1], 121)
    Gg2 = np.linspace(Gg[0], Gg[-1], 81)
    on21 = np.array([Xg[int(np.argmax(~np.isnan(Zs[i])))] if np.any(~np.isnan(Zs[i])) else np.nan
                     for i in range(len(Gg))])
    on_f = np.interp(Gg2, Gg, on21)
    yi = np.interp(Gg2, Gg, np.arange(len(Gg)))
    xi = np.interp(Xg2, Xg, np.arange(len(Xg)))
    Zf = np.full((len(Gg2), len(Xg2)), np.nan)
    for i in range(len(Gg2)):
        for j in range(len(Xg2)):
            x0 = int(np.floor(xi[j])); x1 = min(x0 + 1, len(Xg) - 1)
            y0 = int(np.floor(yi[i])); y1 = min(y0 + 1, len(Gg) - 1)
            tx = xi[j] - x0; ty = yi[i] - y0
            v = ((1 - tx) * (1 - ty) * Zs[y0, x0] + tx * (1 - ty) * Zs[y0, x1]
                 + (1 - tx) * ty * Zs[y1, x0] + tx * ty * Zs[y1, x1])
            if not np.isnan(v):
                Zf[i, j] = v
    Zf[Xg2[None, :] < on_f[:, None]] = np.nan
    Xf2, Gf2 = np.meshgrid(Xg2, Gg2)
    s = ax3.plot_surface(Xf2, Gf2, Zf, cmap=PARULA, linewidth=0.25,
                         edgecolor=(0.25, 0.25, 0.25, 0.30), antialiased=True)
    s.set_clim(0, np.nanmax(Zf))
    fig.colorbar(s, ax=ax3, fraction=0.046, pad=0.10)
    ax3.view_init(elev=45, azim=42)
    ax3.set_xlim(Xg[0], Xg[-1]); ax3.set_ylim(Gg[0], Gg[-1]); ax3.set_zlim(0, 1.0)
    ax3.set_xticks([0, 2, 4, 6]); ax3.set_yticks([0, 1, 2]); ax3.set_zticks([0, 0.5, 1.0])
    ax3.tick_params(labelsize=7.5)
    ax3.set_xlabel(r"$\xi = kb$", fontsize=9)
    ax3.set_ylabel(r"$\mu_s^*$", fontsize=9)
    # explicit margins: the 3D z-axis label sits left of the z-axis; a
    # tight-bbox save clips it (mpl 3.13 quirk), so save the full canvas.
    ax3.set_position([0.16, 0.06, 0.66, 0.88])
    fig.canvas.draw()
    # manual 2D z-label (mpl 3D zlabel rotates the glyph the wrong way):
    # upright Omega, reads bottom-to-top like a standard y-axis label.
    fig.text(0.055, 0.47, r"$\Omega$", rotation=90, ha="center", va="center", fontsize=10)
    fig.savefig(f"{OUT}/fig_surface_journal.png"); plt.close(fig)

# ---------------------------------------------------------------- 6. sensitivity heatmap
S = np.array([[0.0000, 0.0000, 0.0000, 0.0002],
              [0.0004, 0.0000, 0.0004, -0.6209],
              [0.2378, 0.0000, 0.2378, -0.4795]])
rows = [r"$\mu_s^*$", r"$k_a^*$", r"$k_b^*$"]
cols = [r"$\Omega(6)$", r"$\xi_c$", r"$v_p(6)$", r"$L$"]
cB, cR = np.array([0.230, 0.299, 0.754]), np.array([0.706, 0.016, 0.150])
cmap = LinearSegmentedColormap.from_list("bwr", [cB, (1, 1, 1), cR], N=256)
cmax = np.abs(S).max()
fig, ax = plt.subplots(figsize=(4.85, 2.95))
im = ax.imshow(S, cmap=cmap, vmin=-cmax, vmax=cmax, aspect="auto")
for i in range(3):
    for j in range(4):
        ax.text(j, i, f"{S[i, j]:.2f}", ha="center", va="center", fontsize=9,
                color="w" if abs(S[i, j]) > 0.55*cmax else "k", fontweight="bold")
for j in range(5): ax.axvline(j-0.5, color=(0.75,)*3, lw=0.6)
for i in range(4): ax.axhline(i-0.5, color=(0.75,)*3, lw=0.6)
# imshow row/column CENTERS are at 0..n-1
ax.set_xticks([0, 1, 2, 3], cols, fontsize=9)
ax.set_yticks([0, 1, 2], rows, fontsize=9)
H.apply(ax, grid=False)
cb = fig.colorbar(im, ax=ax, pad=0.02); cb.set_label(r"$\partial\ln Q / \partial\ln a_i$", fontsize=9.5)
cb.ax.tick_params(labelsize=7.5)
fig.tight_layout(); fig.savefig(f"{OUT}/fig_sensitivity_journal.png"); plt.close(fig)

# ---------------------------------------------------------------- 7. parametric sweeps 1x2
def sweep_curve(track_fn):
    b, on = track_fn()
    omk = b["ok_mask"]
    return b["xi"][omk], b["om"][omk], (on if on > XI_F[0] + 1e-9 else None)

fig, axs = plt.subplots(1, 2, figsize=(5.76, 2.9))
# panel (a): surface-elasticity sweep (ka* = kb* = 5, G free O(1))
for ax, ttl, sweep in (
        (axs[0], r"(a) surface elasticity $\mu_s^*$",
         [(G, lambda G=G: C.track_physical_branch(KA0, KB0, G, 0.0, XI_F), r"$\mu_s^* = %g$" % G) for G in (0.0, 0.2, 0.5, 1.0, 2.0)]),
        (axs[1], r"(b) spring stiffness $k_a^*=k_b^*$",
         [(k, lambda k=k: C.track_physical_branch(k, k, 0.7, 0.0, XI_F), r"$k_a^*=k_b^* = %g$" % k) for k in (0.5, 2.0, 5.0, 20.0, 100.0)])):
    for cidx, (_, fn, lab) in enumerate(sweep):
        xs, os_, onset = sweep_curve(fn)
        ax.plot(xs, os_, color=H.PALETTE5[cidx], lw=1.5)
        if onset is not None:
            lab = lab + " (onset %.2f)" % onset
        ax.plot([], [], color=H.PALETTE5[cidx], lw=1.5, label=lab)
    ax.plot([0, 6], [C.Omega_p]*2, "r:", lw=1.2)
    ax.plot([], [], color="r", ls=":", lw=1.2, label=r"$\Omega_p$ (cutoff)")
    ax.set_xlim(0, 6); ax.set_ylim(0, 2.6)
    ax.set_xlabel(r"$\xi = kb$"); ax.set_ylabel(r"$\Omega$")
    H.panel_title(ax, ttl)
    H.legend_box(ax, "upper left", fontsize=8)
    H.apply(ax)
fig.tight_layout()
fig.savefig(f"{OUT}/fig_parametric_journal.png"); plt.close(fig)

print("previews written to", OUT)
