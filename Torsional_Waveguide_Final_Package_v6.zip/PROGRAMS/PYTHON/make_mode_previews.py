# LEGACY / OPTIONAL — NOT PART OF THE CURRENT REPRODUCIBILITY PIPELINE.
# Superseded by make_journal_previews.py / master_figure_generator.py. Writes
# into an external matlab_pkg/reference_preview directory that is not shipped;
# kept for provenance only. See README "Legacy scripts" section.
"""make_mode_previews.py — matplotlib renderings of fig_mode_shape and
fig_mode_shape_springs_comparison (same curves the MATLAB code produces)."""
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import house_style as H
import core as C
from mode_shape_check import mode_shape, KA, KB, MUS, TAU0
H.setup()
BLUE, ORANGE = H.BLUE, H.ORANGE

def profile_ms(ms):
    # mode_shape_check.mode_shape stores r in dimensionless r/b units;
    # convert to physical mm (b = 0.35016 mm) for the plot axis.
    u = np.abs(np.concatenate([ms["u1"], ms["u2"], ms["u3"]]))
    r = np.concatenate([ms["r1"], ms["r2"], ms["r3"]])
    return r*C.b*1e3, u/u.max()

def style(ax, p, title):
    H.layer_regions(ax)
    ax.set_xlim(0, p["beta"]*p["b"]*1e3); ax.set_ylim(0, 1.18)
    ax.set_xlabel("r (mm)"); ax.set_ylabel(r"$|u_{\theta}|$ (normalized)")
    H.panel_title(ax, title); H.legend_box(ax, "upper left")
    H.apply(ax, grid=False)

P = dict(alpha=C.alpha, b=C.b, beta=C.beta)

# ---- figure (e): base branch at two representative points ----
xi_grid = np.linspace(0.05, 6.0, 300)
b1 = C.track_branch(KA, KB, MUS, TAU0, xi_grid, 0.05, 1)
ok = b1["ok_mask"]
xig, omg = b1["xi"][ok], b1["om"][ok]
pts = []
for target in (0.5, 5.0):
    i = int(np.argmin(np.abs(xig - target)))
    ms = mode_shape(xig[i], omg[i], KA, KB, MUS, TAU0)
    r, u = profile_ms(ms)
    pts.append((r, u, r"$\xi$ = %.2f" % xig[i]))
fig, ax = plt.subplots(figsize=(3.5, 2.8), dpi=150)
colors = ["tab:blue", "tab:red"]
for (r, u, lbl), c in zip(pts, colors):
    ax.plot(r, u, color=c, lw=1.8, label=lbl)
style(ax, P, "mode shape, branch 1 (base case)")
fig.tight_layout()
fig.savefig("/home/user/matlab_pkg/reference_preview/preview_e.png")

# ---- figure (d3): k*=0.5 vs k*=100 at xi=6 ----
fig, ax = plt.subplots(figsize=(3.5, 2.8), dpi=150)
for ksv, c in zip((0.5, 100.0), ("tab:blue", "tab:red")):
    om = C.find_roots_at_xi(6.0, ksv, ksv, 0.5, 0.2)[0]
    ms = mode_shape(6.0, om, ksv, ksv, 0.5, 0.2)
    r, u = profile_ms(ms)
    ax.plot(r, u, color=c, lw=1.8, label="k* = %g" % ksv)
style(ax, P, r"mode shape, $\xi$ = 6, $k^*$ = 0.5 vs 100")
fig.tight_layout()
fig.savefig("/home/user/matlab_pkg/reference_preview/preview_d3.png")
print("previews written")
