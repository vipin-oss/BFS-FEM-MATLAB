#!/usr/bin/env python3
"""scoping_check.py — ACTION-ITEM execution for the track_physical_branch()
routing condition   `len(roots0) >= 2 or mus < 1e-12`.

For EVERY call site in the codebase (inventory printed below), this script
EXECUTES:
  * find_roots_at_xi at the seed xi  -> which code path the condition takes,
  * the CURRENT track_physical_branch (as shipped),
  * the DIRECT rank-1 continuation track_branch (what a "fixed" condition
    len(roots0) >= 1 would do, since track_physical_branch_fixed degenerates
    to exactly that call whenever any root exists at the seed),
and prints onset / Omega(xi=6) / max|dOmega| before-vs-after, plus the
manuscript reference values where they exist.

Baseline parameters (Table 5): ka*=kb*=5, mu_s*=1e-5, tau0*=2e-6.
Note: tau0 does not appear anywhere in Mmat (Gurtin-Murdoch cancellation),
so tau0*=2e-6 and tau0*=0 are numerically identical.
"""
import numpy as np
import core as C

XI300 = np.linspace(0.05, 6.0, 300)
XI200 = np.linspace(0.05, 6.0, 200)     # full_study.py sweep grid


def track_physical_branch_fixed(ka, kb, mus, tau0, xi_g, n_on=200):
    """Variant with the previously-suggested fix: len(roots0) >= 1."""
    roots0 = C.find_roots_at_xi(xi_g[0], ka, kb, mus, tau0)
    if len(roots0) >= 1 or mus < 1e-12:
        return C.track_branch(ka, kb, mus, tau0, xi_g, xi_g[0], 1), xi_g[0]
    xi_on = C.find_branch_onset(xi_g[0], min(xi_g[-1], 3.0), n_on,
                                ka, kb, mus, tau0, 2)
    if xi_on is None:
        return None, None
    g2 = xi_g[xi_g >= xi_on]
    return C.track_branch(ka, kb, mus, tau0, g2, xi_on, 1), xi_on


def compare(label, ka, kb, mus, tau0, xi_g, ref_om6=None, ref_onset=None):
    roots0 = C.find_roots_at_xi(xi_g[0], ka, kb, mus, tau0)
    cond = (len(roots0) >= 2) or (mus < 1e-12)
    print("  %-34s seed roots=%d %s -> condition=%s -> %s"
          % (label, len(roots0),
             "[" + ",".join("%.6f" % r for r in roots0) + "]",
             cond,
             "DIRECT rank-1" if cond else "ONSET-SEARCH(rank2)"))
    cur, cur_on = C.track_physical_branch(ka, kb, mus, tau0, xi_g)
    fix, fix_on = track_physical_branch_fixed(ka, kb, mus, tau0, xi_g)
    okc, okf = cur["ok_mask"], fix["ok_mask"]
    om6c = cur["om"][okc][-1] if okc.any() else np.nan
    om6f = fix["om"][okf][-1] if okf.any() else np.nan
    # max |dOmega| on the common tracked domain
    common = (xi_g >= cur["xi"][okc][0] - 1e-12) & okf
    if common.any():
        d = np.abs(np.interp(xi_g[common], cur["xi"][okc], cur["om"][okc])
                   - fix["om"][common])
        dmax = float(np.nanmax(d))
    else:
        dmax = np.nan
    line = ("      current: onset=%.4f  Omega(6)=%.6f  |  fixed(>=1): "
            "onset=%.4f  Omega(6)=%.6f  |  max|dOmega|_common=%.3e"
            % (cur_on, om6c, fix_on, om6f, dmax))
    if ref_om6 is not None:
        line += "  |  manuscript Omega(6)=%.4f%s" % (
            ref_om6, "  MATCH" if abs(om6c - ref_om6) < 5e-5 else "  <-- MISMATCH")
    if ref_onset is not None:
        line += "  onset_ref=%.4f%s" % (
            ref_onset, " MATCH" if abs(cur_on - ref_onset) < 5e-5 else " <-- MISMATCH")
    print(line, flush=True)
    return dict(roots0=len(roots0), cond=cond, om6c=om6c, om6f=om6f,
                onset_c=cur_on, onset_f=fix_on, dmax=dmax)


print("=" * 78)
print("PART 0 — the user's premise, re-executed")
print("=" * 78)
r0 = C.find_roots_at_xi(0.05, 5.0, 5.0, 1e-5, 2e-6)
print("  find_roots_at_xi(0.05, ka=5, kb=5, mus=1e-5, tau0=2e-6) -> %d root(s): %s"
      % (len(r0), ["%.9f" % x for x in r0]))
print("  condition (len(roots0)>=2 or mus<1e-12) = %s  -> %s"
      % ((len(r0) >= 2 or 1e-5 < 1e-12),
         "DIRECT rank-1" if (len(r0) >= 2 or 1e-5 < 1e-12)
         else "ONSET-SEARCH(rank 2)  [the disputed routing]"))

print()
print("=" * 78)
print("PART 1 — BASELINE (mus*=1e-5, tau0*=2e-6) through track_physical_branch")
print("         vs the direct rank-1 continuation that full_study.py actually uses")
print("=" * 78)
res_base = compare("baseline (hypothetical call)", 5.0, 5.0, 1e-5, 2e-6, XI300)
cur, cur_on = C.track_physical_branch(5.0, 5.0, 1e-5, 2e-6, XI300)
b1 = C.track_branch(5.0, 5.0, 1e-5, 2e-6, XI300, 0.05, 1)
okc, ok1 = cur["ok_mask"], b1["ok_mask"]
xc, oc = cur["xi"][okc], cur["om"][okc]
x1, o1 = b1["xi"][ok1], b1["om"][ok1]
print("      Table-5-style point-by-point (BOTH curves interpolated at the SAME xi):")
print("        xi      Omega_direct   Omega_tpb(cur)      diff")
for xr in [0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0]:
    od = float(np.interp(xr, x1, o1))
    if xr >= xc[0] - 1e-12:
        ocv = float(np.interp(xr, xc, oc))
        print("      %6.2f    %.9f    %.9f   %.2e" % (xr, od, ocv, abs(od-ocv)))
    else:
        print("      %6.2f    %.9f    (not covered: xi < onset %.4f)"
              % (xr, od, cur_on))
print("      shared-node max|dOmega| over %d nodes: %.3e"
      % (len(xc), float(np.abs(np.interp(xc, x1, o1) - oc).max())))
print("      NOTE: the onset-search path does NOT return onset=0.05 for the "
      "baseline;")
print("      it returns the rank-2 onset (branch-2 appearance), %.4f." % cur_on)

print()
print("=" * 78)
print("PART 2 — EVERY ACTUAL call site of track_physical_branch in the codebase")
print("=" * 78)
print("""  Inventory (grep, Python + MATLAB):
   P1 full_study.py:321  sweep-1 preview_d1   (5,5,G,0.0)   G in {0,0.2,0.5,1,2}   200-pt grid
   P2 full_study.py:339  sweep-2 preview_d2   (k,k,0.5,0.2) k in {0.5,2,5,20,100}  200-pt grid
   P3 make_journal_previews.py:66  spring_profile  (k,k,0.7,0.0)                   300-pt grid
   P4 make_journal_previews.py:280 fig7(a)    (5,5,G,0.0)   G in {0,0.2,0.5,1,2}   300-pt grid
   P5 make_journal_previews.py:282 fig7(b)    (k,k,0.7,0.0) k in {0.5,2,5,20,100}  300-pt grid
   P6 master_figure_generator.py:60           (5,5,0.7,0.0)                        60-pt grid [0.1,6]
   P7 sensitivity_surface_check.py:88  surface (5,5,G,0.0)  G in linspace(0,2,21)  300-pt grid
   MATLAB: NO track_physical_branch equivalent exists. The MATLAB selection rule
   (torsional_waveguide_core.m, track_branch_continuation, ~lines 262-278) is
   rank-driven: it scans for the first xi with length(roots)>=branch_rank and
   takes roots(branch_rank) -- for rank 1 this is always the direct continuation,
   with no mus-based special case anywhere.
   NONE of P1..P7 uses the baseline mus*=1e-5, tau0*=2e-6.""")

sweep1_refs = {0.0: (0.1629, 0.05), 0.2: (0.3425, 0.05), 0.5: (0.5296, 0.05),
               1.0: (0.7239, 0.3465), 2.0: (0.9627, 0.6133)}
print("\n  --- P1/P4: mu_s* sweep, (ka,kb)=(5,5), tau0=0 ---")
for G in [0.0, 0.2, 0.5, 1.0, 2.0]:
    ref = sweep1_refs[G]
    compare("G=%.1f (200-pt full_study grid)" % G, 5.0, 5.0, G, 0.0, XI200,
            ref_om6=ref[0], ref_onset=ref[1])

print("\n  --- P2: spring sweep, (k,k), mus=0.5, tau0=0.2 (200-pt grid) ---")
for k in [0.5, 2.0, 5.0, 20.0, 100.0]:
    compare("k=%.4g mus=0.5 tau0=0.2" % k, k, k, 0.5, 0.2, XI200)

print("\n  --- P3/P5/P6: spring sweep / strong-GM curve, (k,k), mus=0.7, tau0=0 ---")
for k in [0.5, 2.0, 5.0, 20.0, 100.0]:
    compare("k=%.4g mus=0.7 (300-pt grid)" % k, k, k, 0.7, 0.0, XI300)
compare("k=5 mus=0.7 (60-pt master grid)", 5.0, 5.0, 0.7, 0.0,
        np.linspace(0.1, 6.0, 60))

print()
print("=" * 78)
print("PART 3 — P7: sensitivity surface grid, G in linspace(0,2,21), 300-pt rows")
print("         (this is the call site feeding the 3D Omega(xi,G) surface figure)")
print("=" * 78)
G_grid = np.linspace(0.0, 2.0, 21)
rows = []
for G in G_grid:
    r0 = C.find_roots_at_xi(0.05, 5.0, 5.0, G, 0.0)
    cond = (len(r0) >= 2) or (G < 1e-12)
    if cond:
        # current == fixed == direct: identical code path by construction.
        b, on = C.track_physical_branch(5.0, 5.0, G, 0.0, XI300)
        om6 = b["om"][b["ok_mask"]][-1]
        print("  G=%.2f seed roots=%d -> DIRECT (same code as fixed)  "
              "onset=%.4f Omega(6)=%.6f" % (G, len(r0), on, om6))
        rows.append((G, len(r0), "direct", on, om6, 0.0))
    else:
        cur, on_c = C.track_physical_branch(5.0, 5.0, G, 0.0, XI300)
        fix, on_f = track_physical_branch_fixed(5.0, 5.0, G, 0.0, XI300)
        okc, okf = cur["ok_mask"], fix["ok_mask"]
        om6c, om6f = cur["om"][okc][-1], fix["om"][okf][-1]
        common = (XI300 >= cur["xi"][okc][0] - 1e-12) & okf
        d = np.abs(np.interp(XI300[common], cur["xi"][okc], cur["om"][okc])
                   - fix["om"][common])
        print("  G=%.2f seed roots=%d -> ONSET-SEARCH  current: onset=%.4f "
              "Omega(6)=%.6f | fixed: onset=%.4f Omega(6)=%.6f | "
              "max|dOmega|_common=%.3e" % (G, len(r0), on_c, om6c, on_f,
                                           om6f, float(np.nanmax(d))))
        rows.append((G, len(r0), "onset", on_c, om6c, float(np.nanmax(d))))

print("\n  cross-check vs sensitivity_surface_check.py / Table-7 references:")
for G, ref in [(0.0, 0.1629), (0.2, 0.3425), (0.5, 0.5296), (0.7, 0.617963),
               (1.0, 0.7239), (2.0, 0.9627)]:
    row = [r for r in rows if abs(r[0]-G) < 1e-12][0]
    print("    G=%.1f: onset=%.4f  Omega(6)=%.4f (ref %.4f)  %s"
          % (G, row[3], row[4], ref,
             "MATCH" if abs(row[4]-ref) < 5e-5 else "MISMATCH"))

print("\nDONE scoping_check")
