# G1_INDEPENDENT_AUDIT.md — Independent Mathematical Audit of PHASE1_DERIVATION_RECORD.md
### MGT Thermoelasticity C¹ BFS-FEM · Phase 1 · AUDIT ONLY
**Date:** 2026-09-25 · **Audited artifact:** `PHASE1_DERIVATION_RECORD.md` (created 2026-09-25; md5 `cf4f185d3eefe878d908a8d2293f2435`, audited **in place, unmodified**).
**Authority:** `Blueprint_Complete_MGT_BFS-FEM.md` (FROZEN v1.0) — sole scientific authority. `BLUEPRINT_FREEZE_RECORD.md`, `PHASE1_SOURCE_LOCK.md`, `PHASE1_TRACEABILITY.md`, `PHASE1_EXECUTION_BASELINE.md` — read only, not modified.
**Method statement:** every conclusion below rests on (i) an independent re-derivation from the source-locked equations printed in `src_audit/nik.txt` (Nikolarakis Eqs. (1),(2),(3),(5),(10),(11) + parameter line + figure legends) and the source-locked law register (`PHASE1_SOURCE_LOCK.md` S5/S6), and (ii) an independent SymPy/symbolic dimensional check. The earlier G1 SymPy run is cited only as corroboration, never as the basis of a conclusion.

---
## 1. EXECUTIVE CONCLUSION

The derivation record's **physics is correct**: the MGT first-order state form, the coupling signs, the nondimensionalization, the benchmark specialization, the limit ladder, and the Hermite/Lagrange basis properties were **independently re-derived this turn and all reproduce**. No sign error, no coefficient error, no BC/IC error, no limit-ladder error was found, and the C¹/C⁰ statements remain consistent with frozen J.1(A).

**However, the record contains one load-bearing dimensional inconsistency that was not caught by the five G1 symbolic checks:** the record repeatedly defines the dimensionless rate coefficient as **`κ̂ = k*/k` and labels it "dimensionless"** (lines 79, 112–116), used in the implementation-form MGT energy equation (line 79) and in the DR#4 dimensional audit conclusion (line 120). Independent dimensional analysis proves **`k*/k` has units of inverse time (T⁻¹), not 1**; the dimensionless rate coefficient is **`κ̂ = k*·t*/k = k*/(ρ c V²)`**. This falsifies the record's DR#4 "all dimensionless groups are unit-free" audit and violates the frozen G1 gate "dimensional audit clean" (`PHASE1_EXECUTION_BASELINE.md` §1, §9).

Per the audit's hard-stop list (**"dimensional inconsistency"**) the correct classification is **BLOCKED**. The physics results all carry through (the limits κ̂→0 are statements about the physical k*, and the benchmark uses κ̂=0), but the **record as written** is not dimensionally clean and must not proceed to pilot on this defect. Per instructions, the defect is **reported, not repaired**: `PHASE1_DERIVATION_RECORD.md` is left unmodified, and no corrected derivation is produced.

---
## 2. DR#1–DR#11 AUDIT TABLE

| DR | Item | Independent audit conclusion |
|---|---|---|
| DR#1 | MGT first-order state form | **PASS.** State `(u,p,θ,φ,ψ)`, φ=θ̇, ψ̇=θ is a full but minimal first-order embedding; substituting back reproduces the MGT energy equation exactly (audit §3). τ̂→0 singular-limit handling is correct. |
| DR#2 | Coupling terms/signs | **PASS.** All eight signs independently confirmed against `nik.txt` Eqs. (1),(2) (audit §4). |
| DR#3 | Nondimensionalization | **PASS.** General + benchmark schemes both reproduced; equivalence verified (audit §6–§7). |
| DR#4 | Symbol register + dimensional audit | **BLOCKED.** `κ̂ = k*/k` claimed dimensionless (lines 79, 112, 116, 120) is **false** — k*/k has units T⁻¹ (audit §6). Also omits the q̃ definition. This is the single blocking defect. |
| DR#5 | C¹ cubic Hermite | **PASS WITH MINOR ISSUE.** Basis correct and independently verified (Kronecker, cubic reproduction incl. `h`-scaling). "Derivative cards" are claimed in the table but not printed in §4.1. |
| DR#6 | C⁰ Lagrange reference | **PASS WITH MINOR ISSUE.** Linear printed and verified; the "quadratic 3-node" is claimed but not printed. |
| DR#7 | Weak form + continuity requirement | **PASS.** IBP reduces uₓₓ, θₓₓ, ψₓₓ to first derivatives ⇒ H¹ ⇒ C⁰ sufficient; C¹ not necessary. Consistent with frozen J.1(A). (Boundary-term derivation omitted — see audit §10, minor.) |
| DR#8 | Element matrices + quadrature | **PASS.** Structure follows from the weak form; 4-pt Gauss exact for degree ≤ 6 (audit §11). K_ψψ block inherits the κ̂ definition defect (cross-ref DR#4). |
| DR#9 | Time integration | **PASS.** p∈{1,2} correctly left open (D1); no later equation assumes a specific p (audit §12). |
| DR#10 | Heaviside BC realization | **PASS.** 1-step closure consistent with frozen K.13/K.4; ramp variant labeled. |
| DR#11 | Patch test (JV4) | **PASS.** All five exactness states independently verified (audit §10). |

---
## 3. MGT INDEPENDENT DERIVATION AUDIT (highest priority)

**Start from source-locked equations and derive the recorded equation; cite the record's result only for comparison.**

**Constitutive/energy inputs (independently assembled).**
- Momentum (Nikolarakis Eq. (1), homogeneous layer): `∂/∂x[(λ+2μ)uₓ − βθ] = ρü`.
- LS energy (Nikolarakis Eq. (1)): `−t₀(ρcθ̈ + T₀βüₓ) − (ρcθ̇ + T₀βu̇ₓ) = ∂/∂x(−kθₓ)`. Multiplying by (−1): `t₀(ρcθ̈ + T₀βüₓ) + (ρcθ̇ + T₀βu̇ₓ) = kθₓₓ` (k const.). This is the form the record prints (line 52) — an exact ×(−1) mirror of the source, signs preserved.
- MGT flux law (source-locked S6; conventional pairing, ψ thermal displacement, ψ̇=θ): `τq̇ + q = −(kθₓ + k*ψₓ)`, GN-III base `q = −(kθₓ + k*ψₓ)`.

**Independent derivation of the MGT energy equation.** Energy balance `ρcθ̇ + βT₀u̇ₓ = −qₓ`; substituting its time derivative and itself into `τq̇ₓ + qₓ = −(kθₓₓ + k*ψₓₓ)`:

`τ(ρcθ̈ + βT₀üₓ) + (ρcθ̇ + βT₀u̇ₓ) = kθₓₓ + k*ψₓₓ`,  ψ̇ = θ.

This is **exactly** record line 70 `[D]`. **Highest-order time derivative:** θ̈ (second order in θ in the written form; the system is the blueprint's "third-order-in-time" structure because eliminating ψ by one differentiation produces τρcθ̈̇). **Coefficients:** all ρc, βT₀, tau, k, k* correct. **Signs:** correct after the ×(−1) mirror.

**Introduction of the auxiliary variables (independent).** p=u̇; φ=θ̇; ψ already first-order via ψ̇=θ. Then `[I]` (record lines 76–80) converts to:
- `u̇ = p`
- `ṗ = ũₓₓ − θ̃ₓ` (momentum, c̃E²=1)
- `θ̇ = φ`
- `τ̂φ̇ = θ̃ₓₓ + κ̂ψ̃ₓₓ − φ − ξ(τ̂ṗₓ + pₓ)`
- `ψ̇ = θ` (normalized: `ψ̃̇ = θ̃`, verified below)

**Equivalence check (audit §3B):** substituting φ=θ̇, p=u̇, ψ̇=θ into the state system returns `τ(θ̈+ξüₓ) + (θ̇+ξu̇ₓ) = θₓₓ + κ̂ψₓₓ` with `ü = uₓₓ − θₓ` — i.e. exactly the derived MGT equation. **The state formulation is exactly equivalent to the original MGT equation. ✓**

**One finding on this section:** the `κ̂` coefficient is correct **only under** κ̂ = k*·t*/k (dimensionless). Under the record's own stated definition κ̂ = k*/k (line 79), the term κ̂ψ̃ₓₓ carries units of inverse time and the equation is not dimensionally balanced. See audit §6 (BLOCKER) and §17.

---
## 4. COUPLING-SIGN TABLE (audit §4)

Source column = sign as it appears in `nik.txt` Eqs. (1),(2) after the legitimate ×(−1) mirror of the printed energy equation (mirror noted per row). Independent derivation = my re-derivation this turn.

| Term | Source sign | Independent derivation | Record | Status |
|---|---|---|---|---|
| Momentum: elastic stiffness + (λ+2μ)uₓₓ | + | + | `+ũₓₓ` (line 90/77) | **MATCH** |
| Momentum: thermal coupling − βθₓ | − (σ=(λ+2μ)uₓ−βθ, Eq. 2) | − | `−θ̃ₓ` (line 90/77) | **MATCH** |
| Momentum: inertia ρü vs stiffness | equality | equality | `ṗ = ũₓₓ − θ̃ₓ` | **MATCH** |
| Energy: thermal inertia +t₀ρcθ̈ | + after ×(−1) mirror | + | `+τ̂φ̇`/`t̃₀θ̃̈` | **MATCH** (mirror) |
| Energy: coupling inertia +t₀T₀βüₓ | + after ×(−1) mirror | + | `+τ̂ξṗₓ` | **MATCH** (mirror) |
| Energy: dissipation +ρcθ̇ | + after ×(−1) mirror | + | `−φ` moved to RHS ⇒ consistent | **MATCH** (mirror) |
| Energy: coupling dissipation +T₀βu̇ₓ | + after ×(−1) mirror | + | `+ξpₓ` | **MATCH** (mirror) |
| Energy: conduction (const k) −kθₓₓ | RHS `kθₓₓ` | RHS positive | `= θ̃ₓₓ` (line 177) | **MATCH** |
| Weak form: −θₓ coupling block | — | derives `⟨Nᵢ(θ) N'ⱼ(u)⟩` | `C_uθ` (line 153) | **MATCH** |
| Weak form: ξpₓ/ṗₓ coupling block | — | derives `⟨…N'…⟩` from ξ terms | line 153 | **MATCH** |

**No unexplained sign discrepancy.** The only convention step is the global ×(−1) of the printed energy equation — an equivalence, explicitly traceable, and the record's line 52 matches it exactly.

---
## 5. BOUNDARY-CONDITION & INITIAL-CONDITION AUDIT

**Essential BCs (source Eq. (11)):**
- `θ̃(0,t̃) = H(t̃)` ✓ — printed verbatim; record line 178 ✓.
- `ũ(L̃,t̃) = 0` ✓ — printed verbatim; record line 178 ✓.

**Natural BCs (source Eq. (11)):**
- `σ̃ₓₓ(0,t̃) = 0`. Independent: σ̃ = ũₓ − θ̃ (source Eq. (5) homogeneous) ⇒ σ̃ₓₓ(0)=0 ⇔ ũₓ(0) = θ̃(0) = H(t̃) = 1. Record line 180 states exactly this ✓. It is the **traction natural BC of the momentum equation**.
- `q̃ₓ(L̃,t̃) = 0`. Independent: q̃ = −θ̃ₓ (source Eq. (5) homogeneous, k=k_m) ⇒ θ̃ₓ(L̃)=0. Record line 178/180 states exactly this ✓. It is the **flux natural BC of the energy equation**.

**Weak-form consistency (audit §5 requirement — "verify the weak form actually produces the stated natural boundary terms"):**
- Momentum weak form: `∫w(ũₓₓ − θ̃ₓ − ü̃) = 0` → IBP → boundary term `[w(ũₓ − θ̃)]₀^L = [w σ̃]₀^L`. At x̃=0 the term is `w·σ̃ₓₓ(0)`; setting σ̃ₓₓ(0)=0 (natural) removes it; at x̃=L ũ is essential. **The record's implicit claim is CORRECT**, and σ̃ₓₓ(0)=0 indeed emerges as the natural BC.
- Energy/heat weak form: IBP of θ̃ₓₓ yields `[v θ̃ₓ]₀^L`; at x̃=L, θ̃ₓ(L̃)=0 (natural, q̃=0); at x̃=0 θ̃ essential. **Correct.**
- **Minor issue (finding W.2, non-blocking):** the record asserts this ("Boundary terms must yield the natural BCs…" appears in `PHASE1_EXECUTION_BASELINE` and is implied at line 139) but **does not print the boundary-term derivation** anywhere in the record. The statement is true; the derivation is missing. Not an error; a completeness gap.

**Auxiliary-variable conditions introduced by the state form (audit §5b):**
- p=u̇: BCs on p follow from ũ's BCs (e.g., no new BC at x̃=L beyond ũ(L̃)=0; p(x̃,0)=0 from quiescence). ✓
- φ=θ̇: no new BC; φ(x̃,0)=0 from quiescence. ✓
- ψ: enters only through ψₓₓ and ψ̇=θ; ψₓₓ is determined given θ (up to a spatial linear part absorbed by ψₓ BCs implicitly) — no additional *boundary* condition is introduced beyond those of θ. ✓
- **No additional BCs are silently created**, and none are missing.

**Initial conditions (audit §6):**
| State | Source IC | Follows from | Record |
|---|---|---|---|
| ũ(x̃,0)=0 | printed | — | ✓ (line 179) |
| u̇̃(x̃,0)=0 | printed | — | ✓ |
| θ̃(x̃,0)=0 | printed | — | ✓ |
| θ̃̇(x̃,0)=0 | printed | — | ✓ |
| p(x̃,0)=u̇(x̃,0)=0 | — | quiescent IC + definition p=u̇ | ✓ (unique) |
| φ(x̃,0)=θ̇(x̃,0)=0 | — | quiescent IC + definition φ=θ̇ | ✓ (unique) |
| ψ̃(x̃,0)=0 | — | **gauge choice** (any constant works; ψₓₓ annihilates the constant) | recorded as `ψ̃≡0` (line 179) — **correct but not labeled as a gauge choice** (minor) |

**No IC is silently invented.** The only note: ψ̃(x̃,0)=0 is a legitimate *gauge* (ψ only appears under ∂ₓₓ or ∂ₜ), and the record states it without labeling it a gauge — minor presentation point. It is immaterial for the κ̂=0 benchmark branch (ψ decouples).

---
## 6. NONDIMENSIONALIZATION AUDIT (audit §7 — full dimensional reasoning)

Independent dimensional analysis from the source-locked definitions (`nik.txt` Eqs. (3),(10), homogeneous material index). Base dimensions M, L, T, Θ.

Definitions: [q] = M·T⁻³; [θ]=Θ; [ψ]=Θ·T (ψ̇=θ); [grad θ]=Θ/L; [grad ψ]=Θ·T/L.

| Quantity | Independent dimensional result | Record | Status |
|---|---|---|---|
| k (on θₓ) | [q]/[Θ/L] = M·L·T⁻³·Θ⁻¹ = W/(m·K) ✓ | line 112 W/(m·K) | **MATCH** |
| k* (on ψₓ) | [q]/[Θ·T/L] = M·L·T⁻⁴·Θ⁻¹ | line 112 lists k* as W/(m·K) | **MISMATCH → see row below** |
| **k*/k** | **(M L T⁻⁴ Θ⁻¹)/(M L T⁻³ Θ⁻¹) = T⁻¹** | **line 116 "κ̂ = k*/k … dimensionless … 1"** | **FALSE (BLOCKER B-1)** |
| Dimensionless rate coefficient | **k*·t*/k = k*/(ρc V²) = 1** (computed) | not stated as such | **needed** |
| x̃ = x/l, with l = k/(c√(ρ(λ+2μ))) | L ✓ | ✓ | MATCH |
| t̃ = Vt/l, V = √((λ+2μ)/ρ) | dimensionless ✓ | ✓ | MATCH |
| θ̃ = (T−T₀)/T₀ | dimensionless ✓ | ✓ | MATCH |
| ũ = (λ+2μ)u/(lβT₀) | dimensionless ✓ | ✓ | MATCH |
| σ̃ = σ/(βT₀) | dimensionless ✓ | ✓ | MATCH |
| c̃E² = ρV²/(λ+2μ) | 1 ✓ (=1 with Eq. (10)) | ✓ | MATCH |
| c̃K² = k/(ρc l V) | 1 ✓ (=1 with Eq. (10)) | ✓ | MATCH |
| t̃₀ = Vt₀/l | 1 (dimensionless) ✓ | ✓ | MATCH |
| τ̂ = τ/t* | 1 (dimensionless) ✓ | ✓ | MATCH |
| ξ = β²T₀/(ρc(λ+2μ)) | 1 ✓ | ✓ (line 115) | MATCH |
| ψ̃ = ψ/(T₀·t*) , ψ* = T₀·(l/V) = Θ·T | dimensionless ✓ (verified) | implied | consistent |
| **q̃ = q·l/(k·T₀)** (= −θ̃ₓ, source Eq. (5) homogeneous) | dimensionless ✓ | **omitted from record's §3.3 scheme list** | **MISSING (minor W.1)** |

**Conclusion of §6:** the record's nondimensionalization is correct **except** the definition κ̂ = k*/k "dimensionless". The two coefficients k and k* are **different physical species** (differ by a factor of time), so their ratio has units. Because the record's DR#4 "Dimensional audit … all dimensionless groups are unit-free" (line 120) states the contrary, **DR#4 is not clean** and the frozen G1 gate "dimensional audit clean" is not met. This is a convention-independent fact (it holds under either the benchmark pairing or the ZAMM-literal pairing of the two coefficients).

*Note:* the mistake is **units-only**. Every *limit* statement (κ̂→0 ⇔ k*→0) is a statement about the physical coefficient k* and is unaffected; the benchmark (κ̂=0) is unaffected.

---
## 7. BENCHMARK SPECIALIZATION AUDIT (audit §8 — independent, not the old SymPy run)

Starting from the **general** `[I]` state model and applying the frozen specialization **κ̂=0, c̃E=1, c̃K=1, ξ=0.05, t̃₀=1** (record line 173), eliminating the auxiliary variables:

**GENERAL MODEL** (audit §3) → **set κ̂=0 (k*=0), c̃E=c̃K=1** →
- momentum: `ü̃ = ũₓₓ − θ̃ₓ`
- energy: `t̃₀(θ̃̈ + ξũ̈ₓ) + (θ̃̇ + ξũ̇ₓ) = θ̃ₓₓ` → **set t̃₀=1, ξ=0.05**.

**BENCHMARK EQUATION (source, `nik.txt` Eq. (11)):**
- `∂/∂x̃(∂ũ/∂x̃ − θ̃) = (1/c̃E²)ü̃` — with c̃E=1: `ü̃ = ũₓₓ − θ̃ₓ`. **EXACT. ✓**
- `−(t̃₀/c̃K²)(θ̃̈ + ξ∂ü̃/∂x̃) − (1/c̃K²)(θ̃̇ + ξ∂u̇̃/∂x̃) = ∂/∂x̃(−∂θ̃/∂x̃)` — multiply by (−c̃K²), c̃K=1: `t̃₀(θ̃̈+ξũ̈ₓ) + (θ̃̇+ξũ̇ₓ) = θ̃ₓₓ`. **EXACT. ✓**

`GENERAL MODEL → SPECIALIZATION → BENCHMARK EQUATION` is **coefficient-by-coefficient, including all signs and the t̃₀/ξ placement, exact.** The earlier CHK-B is corroborated, and this audit's independent reduction stands on its own. The record's §5 equations (lines 176–177) and BC/IC/instants (lines 178–180) are **exactly** the source-locked benchmark, unaltered.

---
## 8. LIMIT-LADDER AUDIT (audit §9 — independent, with order-of-limits stated)

All limits are on the physical coefficients (k, k*, τ); the κ̂-naming defect of §6 does not enter the limit statements.

| Reduction | Parameter substitution | Resulting equation (indep.) | Target | Verdict |
|---|---|---|---|---|
| MGT → LS | k*→0 (τ, k retained) | `τ(ρcθ̈+βT₀üₓ)+(ρcθ̇+βT₀u̇ₓ) = kθₓₓ` | LS (Nikolarakis Eq. (1)) | **EXACT** (single limit) |
| MGT → GN-III | τ→0 (k, k* retained) | `(ρcθ̇+βT₀u̇ₓ) = kθₓₓ + k*ψₓₓ`, ψ̇=θ | GN-III | **EXACT** (single limit) |
| MGT → GN-II | τ→0 **and** k→0 (simultaneous) | `(ρcθ̇+βT₀u̇ₓ) = k*ψₓₓ` (⇒ hyperbolic θ̈=k*θₓₓ on differentiation) | GN-II (no dissipation, no lag) | **EXACT** (two simultaneous limits — stated here explicitly) |
| MGT → CTE | τ→0 **and** k*→0 (simultaneous) | `(ρcθ̇+βT₀u̇ₓ) = kθₓₓ` | Classical coupled (CTE) | **EXACT** (two simultaneous limits — stated explicitly) |

**Order-of-limits:** LS and GN-III are single-parameter limits. GN-II and CTE each require **two simultaneous limits**; the record's CHK-C line lists them as compound substitutions, which is correct, though the record does not explicitly say "simultaneous". This is a presentation nicety, not an error.

**CTE note (audit §9 last bullet):** the frozen benchmark's CTE (B1) is reached by **t̃₀→0 on the LS equation** (a different route: LS → CTE), whereas the record's CHK-C reaches CTE by **(τ→0, k*→0) on MGT**. Both routes land on the **identical** classical coupled equation `(ρcθ̇+βT₀u̇ₓ)=kθₓₓ` — verified here — so there is **no conflict** between the two CTE pictures, and the CTE limit is **uniquely established** from the source-locked equations (not OPEN).

---
## 9. C¹/C⁰ AUDIT (audit §10)

Independently: the weak form (audit §10) requires only H¹ regularity ⇒ **C⁰ is sufficient; C¹ is NOT mathematically necessary.** The record states exactly this (line 139, §4.3) and frames C¹'s value as (i) higher-order approximation, (ii) direct continuous σ̃ recovery — both labeled "hypothesized/empirical/tobe measured (J.4)", and adds "no continuity advantage to ψ beyond θ" (ψ = time-integral of θ). **The record introduces no C¹-superiority claim and remains consistent with the frozen position** ("C¹ necessity is NOT established mathematically; any C¹ advantage must be measured empirically" — frozen J.1(A)). **PASS.**

---
## 10. WEAK-FORM AUDIT (audit §12) + PATCH-TEST AUDIT (DR#11)

**Independent weak form.** Multiply momentum by w, energy by v, integrate, IBP once:
- momentum: `∫(−wₓ(ũₓ−θ̃) − wü̃) + [wσ̃]₀^L = 0` — second derivatives reduced to first; boundary term = traction (σ̃(0) natural, ũ(L) essential).
- energy: conduction/rate terms `∫(−vₓθ̃ₓ …) + [vθ̃ₓ]₀^L` — boundary term = flux (θ̃ₓ(L̃) natural, θ̃(0) essential).
- ψ-term `κ̂ψₓₓ`: same IBP; no new regularity demand.

**Continuity requirement:** every trial/test function needs at most H¹ ⇒ **C⁰ sufficient** — matches record line 139. **Signs and consistency with §5's essential/natural split all confirmed.** The record does not go beyond this, and **does not confuse "C¹ convenient" with "C¹ required"** (it explicitly separates them in §4.3). The sole gap is that the record **does not print** the boundary terms derived above (implied, correct, unshown) — folded into finding W.2.

**Patch test (DR#11) — independent check of the record's five states (line 165):**
- rigid translation (u=const, θ=0): σ̃ = ũₓ−θ̃ = 0 ✓
- uniform strain (u∝x̃, θ=0): σ̃ = const ✓
- constant temperature (θ=const, u≡0): σ̃ = −θ̃ ✓
- linear temperature, ξ=0 (θ∝x̃): θ̃ₓₓ=0, q̃=−θ̃ₓ=const ✓ (conduction patch)
- quiescent coupled: u=θ=0 under zero BC is the fixed point ✓
- Hermite cubic reproduction ⇒ element-level patch exactness ✓ (independently re-verified, §11).

All **PASS.**

---
## 11. HERMITE/LAGRANGE BASIS AUDIT + MATRIX/QUADRATURE AUDIT (audit §11, §13)

**Cubic Hermite (independent SymPy verification):** with `N₁=1−3ζ²+2ζ³, N₂=ζ−2ζ²+ζ³, N₃=3ζ²−2ζ³, N₄=−ζ²+ζ³`:
- value Kronecker: N(0)=(1,0,0,0), N(1)=(0,0,1,0) ✓
- derivative Kronecker: N′(0)=(0,1,0,0), N′(1)=(0,0,0,1) ✓
- value POU: N₁+N₃=1 ✓ (slope pair N₂+N₄ ≠ 1 — correctly **not** a POU; record never claims POU for slope DOFs)
- exact cubic reproduction: `N₁y₀ + N₂y′₀ + N₃y₁ + N₄y′₁ − f = 0` for any cubic, and with the physical `h`-scaling `N₁ŷ₁ + hN₂ŷ′₁ + N₃ŷ₂ + hN₄ŷ′₂ − g = 0` ✓ (both independently verified).

Record's basis (line 129–130) is **exact**. (Minor: "derivative cards" claimed in the DR#5 table row but not printed.)

**C⁰ reference:** linear `L₁=1−ζ, L₂=ζ` (POU and Kronecker verified); quadratic (3-node) claimed but not printed — minor completeness point (properties standard; not re-derived here beyond the documented claim, per the "do not expand scope" instruction).

**Matrix structure (audit §13):** the stated blocks follow from the weak form: M_uu∝⟨NᵢNⱼ⟩; M_θθ∝τ̂⟨NᵢNⱼ⟩ (from τ̂φ̇); identity links for (u,p) and (ψ,θ); K_uu, K_θθ ∝⟨N′ᵢN′ⱼ⟩; K_ψψ∝κ̂⟨N′ᵢN′ⱼ⟩; C_uθ∝⟨NᵢN′ⱼ⟩. **Consistent** (no solver implemented, and none was; audit only). The K_ψψ block is dimensionally mis-stated only via the κ̂ definition (cross-ref B-1).

**Quadrature:** integrands are products of cubics → max degree: ⟨NᵢNⱼ⟩=6, ⟨N′ᵢN′ⱼ⟩=4, ⟨NᵢN′ⱼ⟩=5 ⇒ **4-point Gauss (exact to degree 7) is sufficient.** Record line 155 correct. ✓

---
## 12. TIME-INTEGRATION AUDIT + D2/D3 DECISION AUDIT (audit §14, §15)

- **D1:** record keeps p∈{1,2} open and labels it `OPEN — IMPLEMENTATION DECISION REQUIRED` (line 191). No equation in the record assumes p=1 or p=2; all G1 results are order-agnostic. **No hidden choice. PASS.**
- **D2:** record correctly separates **mathematical state requirements** (the 5-field state is forced by the three second-order-in-θ/one-first-order-ψ structure) from the **implementation choice** of *condensing* ψ out when κ̂=0 (ψ then decouples). The words "NARROWED, partially determined … local implementation choice" (line 192) are an accurate description, not an overclaim. **PASS.**
- **D3:** left open ("fixed when J.4 (Phase 5) is designed", line 193). No arbitrary DOF-parity metric silently fixed. **PASS.**

---
## 13. PROVENANCE AUDIT (audit §16)

| Record equation/label | Line | Verdict |
|---|---|---|
| `[S]` GN-III / MGT flux law | 44–45 | **PARTIALLY JUSTIFIED.** Derived from S6 (ZAMM) *but* re-paired to the benchmark/GN-1993 convention; the record itself discloses this (coefficient-assignment note, line 57) and registers `VERIFY-G1-S1`. The `[S]` tag overstates "verbatim" given the disclosed re-pairing. **Not a blocker** (disclosed, physics fixed by CHK-B), but the tag should read "convention-adjusted, VERIFY-G1-S1". |
| `[S]` momentum + LS energy | 51–52 | **JUSTIFIED.** Verbatim from Nikolarakis Eq. (1) in homogeneous form; line 52 is the exact ×(−1) mirror of the printed equation (signs preserved). ✓ |
| `[S]` benchmark normalization (Eqs. 3, 10) | 100 | **JUSTIFIED.** ✓ |
| `[D]` MGT energy equation | 70 | **JUSTIFIED** (independently reproduced, §3). ✓ |
| `[I]` state form | 76–80 | **JUSTIFIED as implementation form**, except the κ̂ definition inside it (B-1). |
| `[S]` β = (3λ+2μ)α_T | 110 | **OVERSTATED.** `nik.txt` only states "β is the thermal constant"; the formula (3λ+2μ)α_T is standard text knowledge, not printed in any locked source. Harmless (β is eliminated from the dimensionless benchmark via ξ, which *is* source-printed), but the `[S]` tag is not justified — should be "standard definition, non-load-bearing". **Minor.**
| `[S]` ψ "via ZAMM/benchmark family" | 108 | **LOOSE.** ψ (thermal displacement, ᾰ=θ) appears in S6 (ZAMM, as α); it does **not** appear in the LS benchmark (S1). Units K·s are definitional (ᾰ=θ). Recommend re-tagging to S6 only. **Minor.** |
| `[S]` ξ, c̃E, c̃K, t̃₀ | 115–118 | **JUSTIFIED** (source Eq. (3)). ✓ |
| `[D]` §5 benchmark specialization | 176–177 | **JUSTIFIED** (independently reproduced, §7). ✓ |

**No source claim is made for an unobtained source** (Quintanilla 2019 S4 correctly kept OPEN-preferred; the derivation openly uses OA S5/S6 per the frozen reconstruction route). **No inferred coefficient is presented as established**, *except* the single dimensionally false κ̂ definition (B-1) and the decorative β formula (minor).

---
## 14. SYMBOLIC-CHECK INDEPENDENCE AUDIT (audit §17)

| Check | What it verifies | Independent of the derivation? | Evidence | Classification |
|---|---|---|---|---|
| CHK-A (c̃E²=c̃K²=1) | benchmark normalization from source Eqs. (3)+(10) | **Yes** — checks source transcription, not the MGT derivation | independent re-derivation above (§6) confirms | INDEPENDENT VERIFICATION (source-scoped) |
| CHK-B (Eq. (11) reproduced) | derived general model → source Eq. (11), coefficient-by-coefficient | **Yes** — cross-checks the derived model against the source independently | independent reduction (§7) reconfirms | INDEPENDENT VERIFICATION (strong) |
| CHK-C (limit ladder) | flux-law-level limit reductions | **Yes** — algebraic closure of the ladder | independent ladder table (§8) reconfirms all four | INDEPENDENT VERIFICATION (algebraic) |
| CHK-D (Hermite) | basis Kronecker / cubic reproduction | **Yes** — standalone basis property, orthogonal to the PDE derivation | independent re-run (§11) reconfirms | INDEPENDENT VERIFICATION |
| CHK-E (ξ dimensionless) | dimensionless consistency of ξ only | **Partially** — narrow; dimension-checks one group | independent (§6) reconfirms ξ | INDEPENDENT but **INCOMPLETE** |

**Decisive observation:** the five checks are genuine verification (not validation) and none merely echoes the derivation — **but their dimensional coverage was only ξ**. **None checked κ̂**, so the record's false "κ̂ = k*/k dimensionless" claim passed straight through to DR#4. This audit adds the missing check: **k*/k = T⁻¹** (demonstrated in §6). The earlier pass was therefore *necessary but not sufficient* for the frozen "dimensional audit clean" gate.

---
## 15. ALL OPEN ISSUES

| ID | Severity | Description | What resolves it |
|---|---|---|---|
| **B-1** | **BLOCKER** | κ̂ = k*/k stated "dimensionless" (record lines 79, 116, and DR#4 conclusion line 120). Independent dimensional analysis: **k*/k = T⁻¹**. The dimensionless rate coefficient is κ̂ = k*·t*/k = k*/(ρc V²). | Redefine κ̂ with its reference time scale (a mechanical, units-only correction in a *future* task; NOT performed here — audit only). Also restate the k* units row (line 112) from W/(m·K) to M·L·T⁻⁴·Θ⁻¹ and re-run the DR#4 linedimensional audit. |
| W-1 | Minor | q̃ (normalized heat flux) definition omitted from the §3.3 scheme list; it is used (correctly) at line 178 via q̃=−θ̃ₓ. | Add `q̃ = q·l/(k·T₀)` (source Eq. (5) homogeneous) to the register. |
| W-2 | Minor | Weak-form natural-BC (traction/flux) terms are asserted but not derived in the record. | Print the two boundary-term identities (audit §10) in the record. |
| W-3 | Minor | ψ̃(x̃,0)=0 is a gauge choice, not labeled as such. | Label gauge; state ψ enters only via ∂ₓₓ and ∂ₜ. |
| W-4 | Minor | "Derivative cards" (DR#5) and the quadratic Lagrange node positions (DR#6) claimed but not printed. | Print N′₁…N′₄ and the 3-node positions. |
| W-5 | Minor | `[S]` tag overstatement: β=(3λ+2μ)α_T (standard text, not source); ψ "via benchmark family" (S1 is LS, no ψ); GN-III law re-paired yet tagged [S]. | Re-tag as convention-adjusted / standard-definition per §13. |
| W-6 | Minor | Tilde discipline: line 80 prints `ψ̇ = θ̃` (dimensional ψ̇ vs. normalized θ̃); the `[I]` block drops tildes on dots. Verified correct as `ψ̃̇ = θ̃`. | Apply uniform tilde notation in the `[I]` block. |
| OPEN-S4 / VERIFY-G1-S1 / D1 / D3 | PRE-EXISTING (correctly recorded) | L̃ confirmation; ZAMM pairing; time order; DOF parity — all correctly left open in the record and in `PHASE1_TRACEABILITY.md` §5. | Per their recorded owners; none is newly introduced by this audit. |

---
## 16. BLOCKING ISSUES

**Exactly one blocking issue — B-1 (dimensional inconsistency in the record's κ̂ definition).**

- **Location:** `PHASE1_DERIVATION_RECORD.md` line 79 (`…κ̂ = k*/k dimensionless…`), line 116 (register: `κ̂ = k*/k | … | 1`), and the DR#4 conclusion line 120 ("all dimensionless groups are unit-free").
- **Mathematical issue:** the two coefficients k (temperature-gradient) and k* (thermal-displacement-gradient) are different physical species; their ratio has units of **inverse time**. The record both uses κ̂ inside the state equation and declares it dimensionless — an internal contradiction that is *precisely* the "dimensional inconsistency" named in the audit's hard-stop list.
- **What is needed to resolve it:** (1) replace κ̂=k*/k with the dimensionless definition κ̂ = k*·t*/k (equivalently k*/(ρc V²)); (2) correct the k* units entry; (3) re-verify the DR#4 dimensional audit line. This is a **units/notation correction of the record**, not a change to any physical equation or to the frozen Blueprint (the Blueprint itself calls κ̂ a "rate-coefficient" without asserting its units, so the Blueprint is **not** implicated). Per this audit's rules the correction is **not performed here**.
- **Scope of the damage (important for triage):** none of the *physics* results are invalidated — the state form, signs, benchmark reproduction, and all four limits are statements about the physical coefficients and remain exactly correct; the benchmark itself uses κ̂=0. The defect is confined to the record's dimensional bookkeeping for the κ̂≠0 (GN-III/MGT) branch.

---
## 17. EXACT RECOMMENDATION FOR NEXT STEP

1. **Do NOT start the pilot.** The record is not dimensionally clean; the frozen G1 gate ("dimensional audit clean") is not met.
2. **Next permitted action (in the next task, not this one):** apply the mechanical correction **B-1** to `PHASE1_DERIVATION_RECORD.md` (κ̂ definition + k* units + DR#4 re-audit) together with the minor items W-1…W-6, then **re-run the DR#4 dimensional audit** and **re-audit G1**. This correction touches no physical equation, no source-locked content, and no frozen authority.
3. After a clean re-audit, the next step may be the Phase-1 pilot — **only then**, and only if the re-audit returns PASS / PASS WITH OPEN NON-BLOCKING ITEMS.

---
## FILES, STATUS, AND FINAL DISCIPLINE (audit §20 + final report)

- **Files created:** `G1_INDEPENDENT_AUDIT.md` (this report).
- **Files modified:** **none.**
- **Files untouched (md5 verified):** `Blueprint_Complete_MGT_BFS-FEM.md`, `BLUEPRINT_FREEZE_RECORD.md`, `PHASE1_SOURCE_LOCK.md`, `PHASE1_TRACEABILITY.md`, `PHASE1_EXECUTION_BASELINE.md`, **`PHASE1_DERIVATION_RECORD.md`** (audited, left byte-identical).
- **Audit status:** **BLOCKED** — one hard-stop condition present (dimensional inconsistency, B-1).
- **Blocking issues:** B-1 only.
- **Non-blocking OPEN items:** W-1…W-6, plus the pre-existing VERIFY-G1-S1, OPEN-S4, D1, D3 (all correctly recorded and non-blocking).
- **Validation claims:** none made. **Novelty claims:** none made. **Tolerance fixing:** none. **D1/D2/D3:** none chosen. **Frozen Blueprint:** unmodified. **Derivation record:** unmodified. **Pilot:** NOT started.
- **Was the next permitted action the Phase-1 pilot?** **No.** The next permitted action is the mechanical correction + re-audit of the record; the pilot is gated behind that.

### Final line
G1 AUDIT BLOCKED — MATHEMATICAL ISSUES MUST BE RESOLVED BEFORE PILOT
