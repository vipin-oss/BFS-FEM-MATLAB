# G1_INDEPENDENT_AUDIT_R2.md — Re-Audit after κ̂ Correction (Round 2)
### MGT Thermoelasticity C¹ BFS-FEM · Phase 1 · AUDIT ONLY
**Date:** 2026-09-25 · **Round:** R2 (follows `G1_INDEPENDENT_AUDIT.md`, which found BLOCKER B-1 + W-1…W-6)
**Re-audited artifact:** `PHASE1_DERIVATION_RECORD.md` (corrected this task; post-correction line count 338; this report is a *fresh independent re-audit*, not a re-statement of R1).
**Protected files:** `Blueprint_Complete_MGT_BFS-FEM.md`, `BLUEPRINT_FREEZE_RECORD.md`, `PHASE1_SOURCE_LOCK.md`, `PHASE1_TRACEABILITY.md`, `PHASE1_EXECUTION_BASELINE.md`, `SOURCE_PROVENANCE_AUDIT.md`, `G1_INDEPENDENT_AUDIT.md` — all untouched.

---
## 1. PREVIOUS BLOCKER

R1 audit (`G1_INDEPENDENT_AUDIT.md`) classified G1 **BLOCKED** on exactly one item, **B-1**:
> The record defined the dimensionless rate coefficient as `κ̂ = k*/k` and labeled it "dimensionless" (record lines 79, 112–116, 120). Independent dimensional analysis showed `k*/k` has units of inverse time (T⁻¹), not 1 — a "dimensional inconsistency" hard-stop.

plus six minors **W-1…W-6** (q̃ missing; natural-BC terms asserted-not-derived; ψ̃(0)=0 not labeled gauge; derivative-cards/quadratic-nodes claimed-not-printed; `[S]` provenance overstatements; tilde discipline on `ψ̇=θ̃`).

---
## 2. INDEPENDENT VERIFICATION OF THE BLOCKER (re-performed this round, fresh script)

Dimension vectors (M, L, T, Θ); physical facts stated independently: [q]=M·T⁻³; [θ]=Θ; ψ̇=θ ⇒ [ψ]=Θ·T; [ψₓ]=Θ·T/L; [θₓ]=Θ/L.

- `[k] = [q]/[θₓ] = (M·T⁻³)/(Θ·L⁻¹) = M·L·T⁻³·Θ⁻¹ = W/(m·K)` ✓
- `[k*] = [q]/[ψₓ] = (M·T⁻³)/(Θ·T·L⁻¹) = M·L·T⁻⁴·Θ⁻¹ = W/(m·K·s)` ✓
- **`[k*/k] = (M L T⁻⁴ Θ⁻¹)/(M L T⁻³ Θ⁻¹) = T⁻¹`** — **B-1 CONFIRMED**: the R1 record's `κ̂ = k*/k` is *not* dimensionless.

The R1 audit's blocker is therefore independently confirmed — the correction task was warranted.

---
## 3. CORRECTED DIMENSIONAL DERIVATION (independent)

Derive the dimensionless rate coefficient from the dimensional governing equation and the reference scales — not from the previous audit's suggestion.

**Step 1 (units).** As in §2: `[k]=W/(m·K)`, `[k*]=W/(m·K·s)`.

**Step 2 (reference time scale).** The one physically present in the lodgest-consistent scaling (benchmark Eq. (10)) is
`t* = l/V`, with `V=√((λ+2μ)/ρ)`, `l = k/(c√(ρ(λ+2μ)))`, and the identity `t* = l/V = k/(ρcV²)` (units s; verified: [k/(ρcV²)] = (M L T⁻³ Θ⁻¹)/((M L⁻³)(L² T⁻² Θ⁻¹)(L² T⁻²)) = T¹).

**Step 3 (nondimensionalize the k*-flux channel).** The dimensional channel is `q*ₓ = −k*ψₓₓ`. With `x = l·x̃`, `ψ = (T₀·t*)·ψ̃` (this scale is fixed by `ψ̇=θ: [ψ]=K·s`):
`ψₓₓ = (T₀ t*/l²)·ψ̃ₓ̃ₓ̃` ⇒ after normalizing the whole energy equation by the conduction normalization factor, the coefficient multiplying `ψ̃ₓ̃ₓ̃` is
`k*·(l/V)/k = k*·t*/k`, and by the Step-2 identity `= k*/(ρcV²)`.

**Step 4 (final, derived).**
```
[D]  κ̂ = k*·t*/k = k*/(ρcV²)      (dimensionless — verified: all base dimensions cancel; result = 1)
```
So the correct expression is **`k*·t*/k`** (equivalently `k*/(ρcV²)`), **not** `k*/k`, and not any other expression. The `t*` factor is not decorative: it is the reference time scale that converts the thermal-displacement-gradient conductivity into a rate coefficient consistent with the relaxation-time (lag) framework.

**Independent term-by-term re-derivation of the corrected nondimensional MGT energy equation** (fresh symbolic check, atomic dimensionless derivatives Θ_TT, U_XTT, …, normalized by l²/(kT₀)):

| nondim derivative | coefficient | interpretation |
|---|---|---|
| Θ_TT | `τ·ρcV²/k = τ/t* = τ̂` | dimensionless lag (thermal inertia) |
| U_XTT | `τ·β²T₀/(k·ρ)·… = ξ·τ̂` | thermoelastic-inertia coupling |
| Θ_T | `1` | dissipation |
| U_XT | `ξ` | thermoelastic-rate coupling |
| Θ_XX | `−1` | conduction |
| Ψ_XX | `−k*/(ρcV²) = −κ̂` | **rate channel — κ̂ as derived** |

The corrected `[I]` state equation `τ̂φ̃̇ = θ̃ₓₓ + κ̂ψ̃ₓₓ − φ̃ − ξ(τ̂p̃̇ₓ + p̃ₓ)` with `κ̂ = k*·t*/k` is the **exact nondimensionalization** of the dimensional MGT energy equation. **CONFIRMED TERM-BY-TERM.**

---
## 4. PROPAGATION OF CORRECTION

Every `κ̂`/`k*`/`k` occurrence was located and corrected in `PHASE1_DERIVATION_RECORD.md` (and only there):

| Location | Before (R1) | After (R2) |
|---|---|---|
| §3.1 `[I]` state energy eq. | `κ̂ = k*/k dimensionless` | `κ̂ = k*·t*/k` (dimensionless); tilded state fields |
| §3.3 nondim block | no q̃/ψ̃/κ̂ derivation | q̃, ψ̃ scales added; κ̂ derived from `k*ψₓₓ` |
| §3.4 register: k* row | `W/(m·K)` | `W/(m·K·s) = kg·m⁻¹·s⁻⁴·K⁻¹` |
| §3.4 register: κ̂ row | `k*/k … 1` | `κ̂ = k*·t*/k = k*/(ρcV²) … 1` `[D]` |
| §3.4 audit conclusion | "all groups unit-free" (false under R1 κ̂) | re-derived; **clean** after R2 |
| §4.4 K_ψψ block | `∝κ̂⟨N′ᵢN′ⱼ⟩` | unchanged (inherits corrected dimensionless κ̂) |
| §5 benchmark | `κ̂ = 0` | `κ̂ = 0 ⇔ k* = 0` (now an *iff*) |
| §2/§3.2/§7 | CHK-* refs | Chk-N refs; β flagged standard-definition |
| §9 checks | A–E only | Chk-1…Chk-6 (+ missing κ̂ check) |
| appended | — | `## G1 CORRECTION RECORD` |

**No unrelated changes.** Protected files untouched.

---
## 5. W-1 … W-6 RESOLUTION

- **W-1 (q̃):** `q̃ = q·l/(k·T₀) ⇒ q̃ = −θ̃ₓ̃` derived and added (§3.3, §3.4); dimensionless (verified).
- **W-2 (natural BCs):** full IBP derivation added (§4.3). Boundary terms `[w(ũₓ−θ̃)]₀^L̃` (traction natural ⇒ `σ̃ₓₓ(0)=0 ⇔ ũₓ(0)=θ̃(0)`) and `[v(θ̃ₓ+κ̂ψ̃ₓ)]₀^L̃` (flux natural ⇒ `θ̃ₓ(L̃)=0 ⇔ q̃ₓ(L̃)=0` under κ̂=0) — now derived, with the GN-III generalization `θ̃ₓ+κ̂ψ̃ₓ = prescribed` noted. Verified against source Eq. (11) BC set and Blueprint §2.3/§2.5.
- **W-3 (ψ̃(0)=0):** resolved as a **gauge choice** (ψ enters only via ∂ₓₓ and ∂ₜ; any constant is annihilated). Labeled as gauge/immaterial under κ̂=0 in §5.
- **W-4 (cards/quadratic):** derivative cards now *printed* (§4.1; they are the O(δx) part of the C¹ requirement — cf. Blueprint §2.11.d); the quadratic-node claim was **removed and deferred** to G1-code (§4.2, §7.4) rather than having positions invented here. No unsupported definition remains.
- **W-5 (provenance):** β formula flagged "standard text definition, NOT source-printed" (`[S]` removed); ψ provenance narrowed to ZAMM S6 (α̇=θ); GN-III law noted as convention-adjusted (`VERIFY-G1-S1`); κ̂ re-tagged `[D]`.
- **W-6 (notation):** state block now fully tilded (`ũ, p̃, θ̃, φ̃, ψ̃`; dots = ∂/∂t̃); `ψ̇=θ̃` replaced by the consistent pair `ψ̃ = ψ/(T₀·t*)`, `ψ̃̇ = θ̃`.

---
## 6. DR#1–DR#11 RE-AUDIT

| DR | Item | Verdict | Basis |
|---|---|---|---|
| DR#1 | MGT first-order state form | **PASS** | `(ũ,p̃,θ̃,φ̃,ψ̃)` minimal exact embedding; back-substitution (φ=θ̇,p=ũ̇,ψ̇=θ) returns the MGT equation exactly (R1 §3 + unchanged here; the κ̂ term is now dimensional). |
| DR#2 | Coupling signs | **PASS** | momentum `−θ̃ₓ`, energy `+ξp̃ₓ`, `+τ̂ξp̃̇ₓ` — all confirmed vs source Eq. (1)/(2) (R1 sign table; untouched by R2). |
| DR#3 | Nondimensionalization | **PASS** | q̃, ψ̃, κ̂ scales now derived; benchmark scale eqs reproduced (Chk-1). |
| DR#4 | Symbol register + dimensional audit | **PASS (was BLOCKED)** | κ̂ redefined dimensionless; k* units fixed; q̃/t*/ψ̃ rows added; audit clean (Chk-6). |
| DR#5 | C¹ Hermite + derivative cards | **PASS** | basis + cards printed; Kronecker/POU/cubic reproduction (Chk-5). |
| DR#6 | C⁰ Lagrange (linear printed; quadratic deferred) | **PASS** | linear POU/Kronecker stated and trivially true; no unverified claim remains. |
| DR#7 | Weak form + continuity | **PASS** | natural-BC terms now derived; C⁰ sufficient / C¹ not necessary — consistent with J.1(A). |
| DR#8 | Element matrices + quadrature | **PASS** | blocks follow the weak form (incl. K_ψψ∝κ̂ with dimensionless κ̂); 4-pt Gauss exact for degree ≤ 6. |
| DR#9 | Time integration | **PASS** | p∈{1,2} open (D1); no hidden order assumed. |
| DR#10 | Heaviside realization | **PASS** | 1-step closure consistent with frozen K.13/K.4. |
| DR#11 | Patch test | **PASS** | five exactness states correct; Hermite cubic reproduction supports it. |

---
## 7. BENCHMARK VERIFICATION (fresh, independent)

**General model (corrected) → specialization `κ̂=0 ⇔ k*=0`, `c̃E=c̃K=1`, `ξ=0.05`, `t̃₀=τ̂=1` → benchmark Eq. (11).**
Independently recomputed this round: our energy equation `t̃₀(θ̃̈+ξũ̈ₓ)+(θ̃̇+ξũ̇ₓ)=θ̃ₓₓ` is identical to the source's printed `−(t̃₀/c̃K²)(θ̃̈+ξ∂ü̃/∂x̃)−(1/c̃K²)(θ̃̇+ξ∂u̇̃/∂x̃)=∂/∂x̃(−∂θ̃/∂x̃)` with c̃K=1 **up to the single global sign mirror ×(−1)**; momentum `ü̃=ũₓₓ−θ̃ₓ` matches `∂/∂x̃(∂ũ/∂x̃−θ̃)=(1/c̃E²)ü̃` at c̃E=1. Every coefficient, sign, derivative order, and parameter was checked — all match. The κ̂ correction has **zero effect** on the LS benchmark region (κ̂=0 ⇒ the ψ̃-channel drops out).

---
## 8. LIMIT-LADDER VERIFICATION (fresh)

| Limit | parameter substitution | resulting equation | verdict |
|---|---|---|---|
| MGT → LS | `k*→0` (single) | LS energy eq. | EXACT |
| MGT → GN-III | `τ→0` (single) | GN-III | EXACT |
| MGT → CTE | `τ→0` **and** `k*→0` (simultaneous) | classical coupled | EXACT |
| MGT → GN-II | `τ→0` **and** `k→0` (simultaneous) | pure rate channel | EXACT |

**κ̂-correction effect on ladder: NONE** — every limit is a statement about the physical coefficients (k*, k, τ); the redefinition of κ̂ is units-only bookkeeping. (The κ̂=0 LS limit stays exact: κ̂=0 ⇔ k*=0.)

---
## 9. FEM FORMULATION VERIFICATION

- **C¹ Hermite:** basis, derivative cards, Kronecker, value-POU, exact-cubic reproduction ✓ (independent check).
- **C⁰ Lagrange:** linear POU/Kronecker ✓; quadratic deferral is honest.
- **Weak form:** IBP + boundary terms derived ✓; H¹ sufficiency ⇒ C⁰ sufficient ✓; no C¹-necessity or superiority claim (consistent with frozen J.1(A)).
- **Matrices/quadrature:** block structure consistent with the weak form; 4-point Gauss exact ✓.
- **D1/D2/D3:** D1 OPEN (p∈{1,2}); D2 narrowed (ψ̃ decouples at κ̂=0 — correctly a "local implementation choice"); D3 OPEN. **No decision invented.** Consistent with the frozen `PHASE1_TRACEABILITY.md` §5 anchors.

---
## 10. PROVENANCE VERIFICATION

- `[S]` tags now genuinely source-backed (Nikolarakis Eqs. (1)–(11); no unobtained source claimed; Quintanilla still OPEN-preferred, derivation via OA S5/S6 per frozen reconstruction).
- `[D]` tags now mark genuinely derived material (MGT energy eq., weak form, κ̂, dimensionless scales).
- `[I]` tags mark implementation choices (state form, quadrature, Heaviside closure).
- Previously overstated tags corrected: β (standard text), ψ (S6 only), GN-III law (convention-adjusted, VERIFY-G1-S1 pending).
- **No derived material labeled source-derived; no missing source replaced by general knowledge.**

---
## 11. SYMBOLIC-CHECK VERIFICATION

| Chk | Content | Independent? | R2 status |
|---|---|---|---|
| Chk-1 (= CHK-A) | c̃E²=c̃K²=1 from source Eqs.(3)+(10) | yes (source transcription) | PASS |
| Chk-2 (= CHK-B) | general model → Eq.(11) | yes (fresh re-check this round, §7) | PASS |
| Chk-3 (= CHK-E ext.) | ξ, q̃, ψ̃, τ̂, t̃₀ dimensionless | yes | PASS |
| Chk-4 (= CHK-C) | limit ladder exact | yes (fresh, §8) | PASS |
| Chk-5 (= CHK-D) | Hermite properties | yes | PASS |
| **Chk-6 (NEW, R2)** | **units of k, k*, t*, κ̂, q̃ — κ̂ dimensionless** | **yes (new independent script, §2–§3)** | **PASS** |

The R1 gap — that CHK-E tested only ξ and never κ̂ — is closed by Chk-6. No check merely re-evaluates the record's own formula: Chk-6 was driven independently from the dimensional governing equation, and the term-by-term nondimensionalization (§3) was an independent reconstruction.

---
## 12. REMAINING OPEN ITEMS

All **non-blocking**, and all pre-existing/anchored in the frozen authority:
1. **D1** — time-integrator order p∈{1,2} (frozen leaves it open).
2. **D3** — DOF-parity metric (Phase-5/J.4).
3. **D2** — ψ̃ elimination for κ̂=0 branch (local implementation choice).
4. **VERIFY-G1-S1** — ZAMM conductivity-pairing re-confirmation at code time.
5. **OPEN-S4** — benchmark L̃=1 digitization confirmation (Phase-3).
6. **C⁰-quadratic node positions** — deferred to G1-code.

None of these is a mathematical defect in the derivation; each has a frozen anchor (§5 traceability), and none blocks the pilot gate G1.

---
## 13. FINAL G1 GATE

- Dimensional audit: **clean** (Chk-6).
- Limit ladder: **exact** (Chk-4).
- Patch-test basis exactness: **verified** (Chk-5; run at G2a per frozen plan — the symbolic exactness is established here).
- Benchmark specialization: **exact** (Chk-2).
- State-form equivalence: **exact**.
- Blocker B-1: **resolved**; minors W-1…W-6: **resolved**.

Per `PHASE1_EXECUTION_BASELINE.md` §9 (G1 = "symbolic limit-ladder exact; patch test passes; dimensional audit clean"), the derivation record now satisfies the G1 gate. The open items are implementation decisions the frozen authority itself leaves open, not unresolved mathematics.

**Files modified:** `PHASE1_DERIVATION_RECORD.md` (only).
**Files created:** `G1_INDEPENDENT_AUDIT_R2.md` (this report).
**Protected files unchanged (md5 verified):** `Blueprint_Complete_MGT_BFS-FEM.md` 902990bd…, `BLUEPRINT_FREEZE_RECORD.md` 4a6d83c4…, `PHASE1_SOURCE_LOCK.md` f5fd8952…, `PHASE1_TRACEABILITY.md` 0131ec7a…, `PHASE1_EXECUTION_BASELINE.md` fd241617…, `SOURCE_PROVENANCE_AUDIT.md` 84bbadae…, `G1_INDEPENDENT_AUDIT.md` 6675c796….
**No pilot, no production FEM, no validation, no novelty claims, no tolerance fixing, no Blueprint modification.** — all complied with.

**Next permitted action:** the Phase-1 pilot (per `PHASE1_EXECUTION_BASELINE.md` §6), beginning with the smallest pilot — 1-D homogeneous LS-layer thermal shock (benchmark Eq. 11). **Not executed here.**

### Final line
G1 AUDIT PASS WITH OPEN NON-BLOCKING ITEMS — READY FOR PILOT
