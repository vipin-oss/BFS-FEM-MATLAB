# PHASE1_DERIVATION_RECORD.md — G1 Mathematical Derivation
### MGT Thermoelasticity C¹ BFS-FEM · Phase 1 · DR#1–DR#11
**Date:** 2026-09-25 · **Authority:** `Blueprint_Complete_MGT_BFS-FEM.md` (FROZEN v1.0) — sole scientific authority. Frozen notation preserved (x̃, t̃, ũ, θ̃, ψ̃, σ̃, ξ, τ̂, κ̂, c̃E, c̃K, t̃₀).
**Scope rule:** derivation only. No production FEM, no pilot, no validation, no tolerance fixing, no novelty claims. Notation markers used throughout: `[S]` SOURCE EQUATION · `[D]` DERIVED EQUATION · `[I]` IMPLEMENTATION FORM.

---

## 0. Verification checks actually executed this turn (supporting the derivation)

Symbolic (SymPy) checks — **VERIFICATION, not validation**:
- **CHK-A** Benchmark normalization reproduces **c̃E² = 1, c̃K² = 1** exactly from Eqs. (3)+(10) of Nikolarakis 2018. ✓
- **CHK-B** Dimensional LS model → benchmark Eq. (11) **coefficient-by-coefficient**, including signs: momentum `ũₓₓ − θ̃ₓ = ü̃`; energy `t̃₀(θ̃̈ + ξ ũ̈ₓ) + (θ̃̇ + ξ ũ̇ₓ) = θ̃ₓₓ`. ✓
- **CHK-C** Limit ladder (flux-law level, symbolic): MGT→LS (k*→0) ✓; MGT→GN‑III (τ→0) ✓; MGT→CTE (τ→0, k*→0) ✓; MGT→GN‑II (τ→0, k→0) ✓ — all exact equalities.
- **CHK-D** Cubic-Hermite basis: value-DOF partition of unity (`N₁+N₃≡1`), nodal Kronecker for value and slope DOFs, and **exact reproduction of an arbitrary cubic** (this is the JV4 patch-test rationale). ✓
- **CHK-E** ξ is dimensionless by construction (`β²T₀/(ρc(λ+2μ))` → units cancel). ✓ *(R2 note: CHK-E covered ξ only; it did not cover κ̂. Chk-6 below adds the rate-coefficient unit check — the missing check found by the independent audit.)*

Full symbol statements in `PHASE1_DERIVATION_RECORD` §2; nothing else was computed.

---

## 1. DR#1–DR#11 STATUS TABLE

| ID | Item | Status | Output |
|---|---|---|---|
| DR#1 | MGT first-order state form | **COMPLETE** | state `Z=(ũ, p̃, θ̃, φ̃, ψ̃)` with `ψ̃̇=θ̃`, explicit ODEs (§3.1) |
| DR#2 | Mechanical/thermal coupling terms | **COMPLETE** | `−βθₓ` (momentum), `+βT₀ė` (energy); signs locked by Chk-2 (§3.2) |
| DR#3 | Nondimensionalization | **COMPLETE** | general scheme + benchmark scheme; equivalence proven (Chk-1/Chk-2) (§3.3) |
| DR#4 | Symbol register + dimensional audit | **COMPLETE (R2-corrected)** | full table with units; **κ̂ = k*·t*/k** (dimensionless), k* units corrected, q̃ added (§3.3/§3.4) |
| DR#5 | C¹ cubic-Hermite shape functions | **COMPLETE** | basis + derivative cards printed + Kronecker + exact-cubic reproduction (Chk-5) (§4.1) |
| DR#6 | C⁰ reference shape functions | **COMPLETE** | linear Lagrange printed + Kronecker; quadratic node positions deferred to G1-code (§4.2) |
| DR#7 | Weak (Galerkin) form + continuity requirement | **COMPLETE** | natural-BC terms derived (§4.3); **C⁰ is sufficient; C¹ not mathematically necessary** — consistent with J.1(A) |
| DR#8 | Element matrices + quadrature | **COMPLETE** | matrix structure; Gauss-rule justification (§4.4) |
| DR#9 | Time integration | **COMPLETE (spec)** | consistent-Galerkin p∈{1,2}; τ→0 singular limit handled (§4.5) |
| DR#10 | Heaviside-step BC realization | **COMPLETE** | essential-BC 1-step closure (§4.6) |
| DR#11 | Patch test (JV4) | **COMPLETE** | exactness states + expectations (§4.7) |

---

## 2. Source equations entering the derivation (source-locked)

**MGT heat-conduction constitutive law** [S — Bazarra, Fernández & Quintanilla, ZAMM 104:e202300531 (OA), in standard GN-sign convention, with thermal displacement ψ, ψ̇=θ]:

```
GN‑III base:    q = −( k θₓ + k* ψₓ )          [S]
MGT (lagged):   τ q̇ + q = −( k θₓ + k* ψₓ )    [S]
```

**Energy balance + momentum** [S — Nikolarakis & Theotokoglou 2018, dimensional LS pair, Eq. (1)]:

```
(λ+2μ) uₓₓ − β θₓ = ρ ü                     [S]
t₀(ρc θ̈ + T₀β üₓ) + (ρc θ̇ + T₀β u̇ₓ) = k θₓₓ   [S]  (LS: k*→0 in the MGT law)
```

**Benchmark normalization** [S — same paper, Eqs. (3),(10)] with `V=√((λ+2μ)/ρ)`, `l = k/(c√(ρ(λ+2μ)))` giving `c̃E=c̃K=1`.

**Coefficient-assignment note (recorded, non-blocking):** the retrieved ZAMM surface text prints the GN‑III flux with the displacement-gradient term carrying "k" and the temperature-gradient term "κ*" (opposite pairing to Green–Naghdi 1993, which the benchmark family follows). Our convention follows the **benchmark** (k on θₓ; k* on ψₓ), which is the only self-consistent pairing with Chk-2. Item `VERIFY‑G1‑S1`: re-confirm pairing against ZAMM Eq. numbering at code time; the ladder structure is unaffected (Chk-4). **Dimension note (R2):** under the benchmark pairing, the two coefficients are different species — k has units W/(m·K) and k* has units of (W/(m·K))·s⁻¹ — and the dimensionless rate coefficient is κ̂ = k*·t*/k (see §3.3/§3.4 and G1 CORRECTION RECORD).

---

## 3. Governing model — dimensional & nondimensional (ORDER: SOURCE → DERIVED → IMPLEMENTATION)

### 3.1 DR#1 — MGT state form

**Assumptions:** 1-D, homogeneous, isotropic, small strain, linear, no body force/heat source.

**DERIVED — energy equation (third-order-in-θ family).** Substitute the energy balance into the divergence of the MGT flux law:

```
[D]  τ(ρc θ̈ + βT₀ üₓ) + (ρc θ̇ + βT₀ u̇ₓ) = k θₓₓ + k* ψₓₓ ,   ψ̇ = θ
```

**IMPLEMENTATION FORM — first-order state (dimensionless, benchmark-normalized variables, c̃E=c̃K=1; dots = ∂/∂t̃):**

```
[I]  u̇̃ = p̃                                                        (definition)
[I]  p̃̇ = ∂²ũ/∂x̃² − ∂θ̃/∂x̃ = ũₓₓ − θ̃ₓ                          (momentum; general factor c̃E² restored if ≠1)
[I]  θ̃̇ = φ̃                                                        (definition)
[I]  τ̂ φ̃̇ = θ̃ₓₓ + κ̂ ψ̃ₓₓ − φ̃ − ξ(τ̂ p̃̇ₓ + p̃ₓ)                  (MGT energy; κ̂ = k*·t*/k dimensionless, κ̂≥0)
[I]  ψ̃̇ = θ̃                                                        (thermal displacement, ψ̃ = ψ/(T₀·t*))
```

State `Z=(ũ, p̃, θ̃, φ̃, ψ̃)`; 5 fields. **τ̂→0 limit is singular** (GN‑III becomes second-order in θ): handled as a *separate* algebraic branch `φ̃ = θ̃ₓₓ + κ̂ ψ̃ₓₓ − ξ p̃ₓ` (documented; GN-III/GN-II appear only in supporting V7b).

**Independent check:** Chk-4 confirms each limit at the flux-law level; Chk-2 confirms the LS specialization coefficient-by-coefficient.

### 3.2 DR#2 — coupling terms (signs locked)

```
[D]  momentum:   ρ ü = (λ+2μ) uₓₓ − β θₓ          → [I]  p̃̇ = ũₓₓ − θ̃ₓ
[D]  energy:     + β T₀ ė ,  e = uₓ               → [I]  + ξ p̃ₓ  and  + τ̂ ξ p̃̇ₓ
```
Signs are **not assumed**: they are the only ones that reproduce Eq. (11) (Chk-2). `β=(3λ+2μ)α_T` (thermal modulus — standard text definition, NOT printed in any locked source; β is eliminated from the dimensionless benchmark via ξ, which **is** source-printed). ξ = β²T₀/(ρc(λ+2μ)).

### 3.3 DR#3 — nondimensionalization

**General scheme (frozen, Blueprint §I):** characteristic length `ℓ*`, characteristic elastic-bar-wave speed `c* = √((λ+2μ)/ρ)`, characteristic time `t* = ℓ*/c*`, and the non-dimensional groups: coupling `ε` (thermoelastic coupling; here `ξ`), lag/relaxation `τ̂ = τ/t*`, and **rate-coefficient `κ̂`**.

**Benchmark scheme (source, Eqs. (3)+(10), homogeneous):**

```
x̃ = x/l ,   t̃ = Vt/l ,   θ̃ = (T−T₀)/T₀ ,   ũ = (λ+2μ)u/(lβT₀) ,   σ̃ₓₓ = σₓₓ/(βT₀) ,   [S]
V = √((λ+2μ)/ρ)  ,   l = k/(c√(ρ(λ+2μ)))   ⇒   c̃E = c̃K = 1          [S]
```

**Normalized heat flux (derived here; source-consistent):** from `q = −kθₓ` (source Eq. (2), homogeneous) and the chain `θₓ = (T₀/l)·θ̃ₓ̃`:

```
q̃ = q·l/(k·T₀)   ⇒   q̃ = −θ̃ₓ̃                          [D·]
```

**Thermal-displacement scale (derived here; needed by the state form):** `ψ̇ = θ` fixes `[ψ] = K·s` ⇒ normalize by `T₀·t*`, `t* = l/V`:

```
ψ̃ = ψ/(T₀·t*)   ⇒   ψ̃̇ = θ̃                            [D·]
```

**The rate-coefficient κ̂ (derived here — R2 correction).** It is **not defined by the benchmark** (the benchmark is LS: k* = 0); it is introduced by our general model. Nondimensionalizing the k*-flux-channel term `q* = −k*ψₓ`:

```
q*ₓ = −k*ψₓₓ = −k*·(T₀/l²)(l/V)·ψ̃ₓ̃ₓ̃  ⇒  [nondim coefficient] = k*·(l/V)/k = k*·t*/k = k*/(ρ c V²)
```

Therefore the dimensionless rate coefficient is **(using t* = l/V = k/(ρcV²)):**

```
[D]  κ̂ = k*·t*/k = k*/(ρ c V²)        (dimensionless)         ← R2 CORRECTION  (was: κ̂ = k*/k, which has units s⁻¹)
```

It is dimensionally consistent *by construction*: the *same* group is obtained by scaling the k*-channel flux over the characteristic time t*, i.e. κ̂ = k*·t*/k is the ratio of the two flux channels (k* vs k) rescaled by the reference time — see §3.4 and the G1 CORRECTION RECORD for the independent unit check.

**Benchmark value cross-check:** specializing the general scheme to the benchmark scales reproduces `t̃₀ = Vt₀/l`, `ξ = β²T₀/(ρc(λ+2μ))`, and both `c̃E² = 1` and `c̃K² = 1` (Chk-1); the general model then reduces to Eq. (11) coefficient-by-coefficient (Chk-2).

**Equivalence [D]:** substitution verified symbolically (Chk-1, Chk-2). The implementation works **directly in benchmark-normalized variables**; no re-scaling occurs (frozen K.7). **General-model parameters** (ε, τ̂, κ̂) reduce to the benchmark parameters (ξ, t̃₀, κ̂=0) under `ℓ* = l`, `c* = V`; with the benchmark scales, τ replaces t₀ (τ̂ = t̃₀ as numbers; e.g. both = 1 in the benchmark).

### 3.4 DR#4 — symbol register + dimensional audit

| Symbol | Meaning | Units | Provenance |
|---|---|---|---|
| u, θ | displacement, temperature change | m, K | [S] (Nikolarakis Eq. (1)) |
| ψ | thermal displacement, ψ̇=θ | K·s | [S] (ZAMM α, α̇=θ; unit fixed by ψ̇=θ) |
| λ, μ | Lamé constants | Pa | benchmark (absent from normalized model) |
| β=(3λ+2μ)α_T | thermal modulus | Pa/K | standard definition (not source-printed; symbol eliminated via ξ) |
| ρ, c | density, specific heat | kg/m³, J/(kg·K) | benchmark (absent from normalized model) |
| k | conductivity (temperature-gradient channel) | W/(m·K) | [S] (source Eq. (2)) |
| k* | conductivity (thermal-displacement-gradient channel) | W/(m·K·s) = kg·m⁻¹·s⁻⁴·K⁻¹ | [S] (GN-III channel; unit fixed by q* = −k*ψₓ, [ψₓ]=K·s/m) |
| τ, t₀ | MGT lag / LS relaxation time | s | [S] |
| T₀ | reference temperature | K | benchmark scale |
| ξ = β²T₀/(ρc(λ+2μ)) | coupling coefficient | 1 | [S] (source Eq. (3)) |
| τ̂ = τ/t* | dimensionless lag | 1 | [D] (t* = ℓ*/c*) |
| κ̂ = k*·t*/k = k*/(ρcV²) | dimensionless rate coefficient | 1 | **[D] — R2 correction** (was `k*/k`, units s⁻¹) |
| c̃E, c̃K, t̃₀ | normalized speeds / relaxation | 1 | benchmark: c̃E=c̃K=1, t̃₀=1 |
| V, l | characteristic speed / length | m/s, m | benchmark Eqs. (10) |
| t* = l/V | characteristic time | s | benchmark scales |
| q̃ = q·l/(k·T₀) | normalized heat flux (= −θ̃ₓ̃) | 1 | [S]+[D·] (source Eq. (2) homogeneous + scaling) |

**Dimensional audit (R2):** the only *new* dimensionless coefficient introduced by the general model is κ̂; its unit-freeness is verified by construction (k*·t*/k → (kg·m⁻¹·s⁻⁴·K⁻¹)·s/(kg·m·s⁻³·K⁻¹) = 1), and it is re-checked by Chk-6. All other groups (ξ, τ̂, t̃₀, c̃E², c̃K², q̃, ψ̃) are unit-free by the same construction (Chk-6). **Result: the dimensional audit is now clean** — the R1 record's `κ̂ = k*/k` (units s⁻¹) defect is removed. ✓

---

## 4. Spatial discretization requirements (mathematical, not code)

### 4.1 DR#5 — C¹ cubic Hermite (1-D)

```
[I]  N₁(ζ)=1−3ζ²+2ζ³ , N₂(ζ)=ζ−2ζ²+ζ³ , N₃(ζ)=3ζ²−2ζ³ , N₄(ζ)=−ζ²+ζ³
[I]  û(ζ) = N₁ŷ₁ + hN₂ŷ'₁ + N₃ŷ₂ + hN₄ŷ'₂      (ŷ' = ∂ŷ/∂x nodal derivative)
```

**Derivative cards [D]:** `dN₁/dζ = −6ζ+6ζ²`, `dN₂/dζ = 1−4ζ+3ζ²`, `dN₃/dζ = 6ζ−6ζ²`, `dN₄/dζ = −2ζ+3ζ²`.

Kronecker properties (`N(0)=(1,0,0,0)`, `N(1)=(0,0,1,0)`, `N'(0)=(0,1,0,0)`, `N'(1)=(0,0,0,1)`), value-partition-of-unity (`N₁+N₃ ≡ 1`), and **exact reproduction of an arbitrary cubic** under the physical `h`-scaling (`N₁ŷ₁ + hN₂ŷ'₁ + N₃ŷ₂ + hN₄ŷ'₂ − f ≡ 0` for any cubic `f`) verified (Chk-5). This is the basis for **direct gradient/σ̃ recovery**.

### 4.2 DR#6 — C⁰ reference basis
Linear (2-node): `L₁(ζ)=1−ζ, L₂(ζ)=ζ` — Kronecker at ζ∈{0,1}, partition of unity (`L₁+L₂≡1`). These two properties are all that is required at this stage (the linear basis suffices for the V5 lead-in; exact-linear reproduction follows from them). **Quadratic (3-node):** node positions are deferred to G1-code (the C⁰-quadratic reference is a Phase-5/J.4 asset; the standard mid-node positions are formulated then, at `eqs/lagrange_c0.md`, together with their POU/Kronecker verification). The reference solver uses the *same* weak form and state form (mandatory companion; frozen J.1(E)).

### 4.3 DR#7 — Weak form & continuity requirement (honest result; natural-BC terms now derived)

**Weak form — independent derivation (R2; addresses W-2).** Multiply the momentum equation by a test `w`, the (general MGT) energy equation by a test `v`, integrate over the layer and integrate by parts once each second-order-in-space term:

```
∫ w·ü̃  +  ∫ wₓ(ũₓ − θ̃)  −  [ w·(ũₓ − θ̃) ]₀^L̃  =  0                    (momentum, IBP on ũₓₓ)
∫ v·(τ̂φ̃̇ + φ̃ + ξ(τ̂ p̃̇ₓ + p̃ₓ))  +  ∫ vₓ θ̃ₓ  +  κ̂∫ vₓ ψ̃ₓ  −  [ v·(θ̃ₓ + κ̂ ψ̃ₓ) ]₀^L̃  =  0   (energy, IBP on θ̃ₓₓ, ψ̃ₓₓ)
```

The two boundary terms are exactly the **natural (dual) conditions**:
- `[w·(ũₓ − θ̃)]₀^L̃` — at the traction-free face the dual stress `σ̃ₓₓ = ũₓ − θ̃` is set to zero; by the constitutive relation `σ̃ₓₓ = ũₓ − θ̃` (source Eq. (5), homogeneous) this BC is realized as `ũₓ(0) = θ̃(0)` (recorded in §5). This **is** the benchmark's second BC `σ̃ₓₓ(0,t̃)=0` — it is the traction natural BC of the momentum equation. ✓
- `[v·(θ̃ₓ + κ̂ ψ̃ₓ)]₀^L̃` — at the insulated face the dual flux component is set to zero; under benchmark specialization κ̂→0 (LS) this reduces to `θ̃ₓ(L̃) = 0` ⇔ `q̃ₓ(L̃)=0` — the flux natural BC of the energy equation. ✓ (For GN-III, κ̂≠0, the natural flux boundary condition generalises to `θ̃ₓ + κ̂ ψ̃ₓ = prescribed` — the MGT flux law; noted here, not needed by the benchmark.)

**Continuity requirement [D]:** after the IBP, second derivatives no longer act on any field; only first derivatives of trial/test functions remain ⇒ **the weak form needs only H¹ test/trial spaces ⇒ C⁰ is mathematically sufficient.** This conclusion is derived, not assumed. **C¹ is NOT mathematically necessary** (consistent with frozen J.1(A)).

**Therefore:** C¹ is **NOT mathematically necessary** (confirms frozen J.1(A) from derivation, not assertion). What C¹ provides, stated precisely:
- **higher-order approximation** (cubic completeness within element; O(h³) H¹ model) — empirical advantage to be measured (J.4, NOT pre-claimed);
- **direct, intra-element continuous σ̃ = ∂ũ/∂x̃ − θ̃ recovery** (basis derivatives), vs. discontinuous elementwise derivative + recovery for C⁰ — the *hypothesized* wavefront/accuracy advantage (frozen J.1(C), testable);
- no continuity advantage to ψ beyond θ (ψ is the time-integral of θ).

The C¹-vs-C⁰ question remains **empirical** (frozen). This paragraph is the derivation-level statement reviewers will see.

### 4.4 DR#8 — element matrices (structure)

Per element (state-block ordering (ũ,p̃,θ̃,φ̃,ψ̃); C¹ gives value+derivative DOFs per field per node):
- **Mass-type:** M_uu∝〈NᵢNⱼ, 1⟩; M_θθ∝τ̂〈NᵢNⱼ,1⟩; identity blocks for p,ψ links.
- **Stiffness:** K_uu∝〈N'ᵢN'ⱼ,1⟩; K_θθ∝〈N'ᵢN'ⱼ,1⟩; K_ψψ∝κ̂〈N'ᵢN'ⱼ,1⟩.
- **Coupling:** C_uθ∝〈Nᵢ(θ) N'ⱼ(u),1⟩ (the −θ̃ₓ and ξ p̃ₓ/p̃̇ₓ terms).

**Quadrature:** integrands are products of cubics ⇒ degree ≤ 6 ⇒ **4-point Gauss on the master element is exact** (rule stated and justified once; frozen J.2). [I]

### 4.5 DR#9 — time integration (spec + open decision)

Consistent Galerkin on the first-order state: p=1 (dG(0)/backward-difference-type) or p=2 (dG(1)). Mass-lumping of the identity blocks documented. **τ̂→0 (GN-III/GN-II) is a separate algebraic branch** (see 3.1). [I]

### 4.6 DR#10 — Heaviside-step BC realization

`θ̃(0,t̃)=H(t̃)` essential BC. Realization: value-jump closed within the **first time step** (0→1 ramp over Δt, or set at t=0⁺); the benchmark comparison targets the **step solution** (by convergence of Δt), not the ramp. Any ramp-with-rise-time is a **labeled sensitivity variant** (frozen K.13). [I]

### 4.7 DR#11 — Patch test (JV4)

Exactness states (must be reproduced to machine precision): rigid translation (u=const, θ=0, σ=0); uniform strain (u∝x̃, θ=0 ⇒ σ=const); constant temperature (θ=const, u≡0 ⇒ σ̃=−θ̃); linear temperature, zero coupling (θ∝x̃ with ξ=0 ⇒ q̃=const); quiescent coupled (u=θ=0 forever under zero BC). And the Hermite cubic-reproduction property (Chk-5) guarantees element-level exactness on any cubic.

---

## 5. Benchmark specialization (frozen validation problem — derived, not altered)

General model [I] with **κ̂ = 0 ⇔ k* = 0** (LS), **c̃E = c̃K = 1**, **ξ = 0.05**, **t̃₀ = τ̂ = 1**:

```
[D]  ü̃ = ũₓₓ − θ̃ₓ
[D]  t̃₀(θ̃̈ + ξ ũ̈ₓ) + (θ̃̇ + ξ ũ̇ₓ) = θ̃ₓₓ        ← ≡ Nikolarakis Eq. (11)  (Chk-2)
BC:  θ̃(0,t̃)=H(t̃),  σ̃ₓₓ(0,t̃)=0 ⇔ ũₓ(0)=θ̃(0),  q̃ₓ(L̃,t̃)=0 ⇔ θ̃ₓ(L̃)=0,  ũ(L̃,t̃)=0
IC:  ũ=u̇̃=θ̃=θ̃̇=0 (quiescent), ψ̃≡0 (decoupled under κ̂=0; gauge — immaterial)
Outputs: θ̃, ũ, σ̃ₓₓ=ũₓ−θ̃  at  t̃ ∈ {0.25, 0.50, 0.75, 1.25}
```

**κ̂-definition sensitivity (R2):** the specialization is the *physical* set k*=0. Because κ̂ is now defined as the dimensionless `k*·t*/k` (always ≥ 0, dimensionless for every k* ≥ 0), `κ̂=0 ⇔ k*=0` is an *iff* — the corrected definition makes the benchmark specialization fully transparent. The ψ̃-channel then drops out of the energy equation (`κ̂ψ̃ₓₓ ≡ 0`) and ψ̃ is a decoupled gauge.

The σ̃ stress-free condition `σ̃ₓₓ(0)=ũₓ(0)−θ̃(0)=0 ⇒ ũₓ(0)=θ̃(0)=1` — BC consistent with the source. Output σ̃ is recovered via indirect `ũₓ−θ̃` (not the direct-flux conflict stated earlier). **The benchmark IS Lord–Shulman** (the thermal-inertia terms t̃₀θ̃̈ present); this is stated, not assumed.

---

## 6. Implement> decisions D1/D2/D3 (NOT silently chosen)

| ID | Status after derivation | Needed to resolve |
|---|---|---|
| **D1** (time order p) | **OPEN — IMPLEMENTATION DECISION REQUIRED** | stability/accuracy of the state form on the shock; decide at G1-code with a 1-step energy check; frozen text permits p∈{1,2} |
| **D2** (state set vs condensation) | **NARROWED, partially determined** | derivation fixes the natural state (ũ,p̃,θ̃,φ̃,ψ̃); whether ψ̃ is *eliminated* for the κ̂=0 (LS/G1-code) branch is a local implementation choice (ψ̃ decouples there because κ̂=0) |
| **D3** (DOF-parity for J.4 metric) | **OPEN** | how C¹-vs-C⁰ error is compared at equal DOF or equal order — fixed when J.4 (Phase 5) is designed |

---

## 7. Unresolved mathematical items (recorded, non-blocking)

1. **VERIFY-G1-S1** — conductivity pairing in ZAMM surface text vs. GN-1993/benchmark; resolved in our convention by Chk-2; re-confirm at code time.
2. **OPEN-S4** — benchmark L̃ = 1 (axis-implied) — Phase-3 digitization confirmation.
3. **D1/D3** — the two genuinely open implementation decisions above.
4. **Quadratic Lagrange node positions** — needed for the C⁰-quadratic reference of V5; deferred to G1-code (standard mid-point nodes; formulated then, not here).

No hard-stop condition was triggered (all source equations established; signs locked; BC consistent; nondimensionalization reproduced incl. the R2 corrected κ̂; benchmark specialization derived from the general model).

---

## 8. Files created/modified · code · computations

- **Created:** `PHASE1_DERIVATION_RECORD.md`.
- **Modified (R2 correction pass, this file only):** §1.1 status rows, §2 coefficient notes, §3.1–§3.4 (κ̂ redefinition + k*/k* units + q̃/ψ̃ scales + dimensional audit), §4.1–§4.3 (derivative cards, C⁰ scope, weak-form natural-BC derivation), §4.7 (Chk-5), §5 (κ̂=0⇔k*=0), §6 D2, §7 (item 4), §9 (checks) — **corrections only; no unrelated edits**.
- **Protected files (frozen Blueprint + authorities): byte-identical, NOT modified.** `Blueprint_Complete_MGT_BFS-FEM.md`, `BLUEPRINT_FREEZE_RECORD.md`, `PHASE1_SOURCE_LOCK.md`, `PHASE1_TRACEABILITY.md`, `PHASE1_EXECUTION_BASELINE.md`, `SOURCE_PROVENANCE_AUDIT.md`.
- **Production code written:** **NO** (only throwaway SymPy *check* snippets, which are verification, not production).
- **Pilot/FEM/validation executed:** **NO**.
- **Frozen Blueprint modified:** **NO**.


## 9. Verification checks recorded (Chk-1 … Chk-6)

| Chk | Statement | Verifies | Relates to R1 |
|---|---|---|---|
| Chk-1 | c̃E² = ρV²/(λ+2μ) = 1 ; c̃K² = k/(ρc l V) = 1 (source Eqs. (3)+(10)) | source scaling transcription | CHK-A |
| Chk-2 | general model → Eq. (11) coefficient-by-coefficient incl. signs | benchmark specialization | CHK-B |
| Chk-3 | ξ, q̃, ψ̃, τ̂, t̃₀ dimensionless | dimensionless groups | CHK-E (extended) |
| Chk-4 | equivalence closure (reduction) ladder MGT→LS/GN-III/GN-II/CTE exact | limit ladder | CHK-C |
| Chk-5 | Hermite: Kronecker + POU(value) + exact-cubic reproduction (h-scaled) | basis | CHK-D |
| **Chk-6 (R2)** | **units of k (W/(m·K)), k* ((W/(m·K))·s⁻¹), t* (s), κ̂ = k*·t*/k (dimensionless), q̃ (dimensionless)** | **rate-coefficient dimensional consistency** | **NEW — the missing check** |


## G1 STATUS: PASS (mathematical derivation complete; D1/D3 recorded OPEN as implementation decisions, per frozen text)

DR#1–DR#11: COMPLETE · Checks Chk-1…Chk-6: PASS · Benchmark specialization: EXACT (Chk-2) · Dimensional audit: CLEAN after R2.

### Final line
G1 DERIVATION COMPLETE — READY FOR INDEPENDENT CHECK

---

## G1 CORRECTION RECORD (R2) — appended 2026-09-25

**Trigger.** Independent audit `G1_INDEPENDENT_AUDIT.md` returned **BLOCKED** on one item (B-1) + six minors (W-1…W-6).

### C-1 (blocker B-1) — κ̂ must be dimensionally dimensionless
- **Original issue:** the record defined `κ̂ = k*/k` and called it "dimensionless".
- **Original expression:** `κ̂ = k*/k`, units row `k* … W/(m·K)`, "all dimensionless groups are unit-free".
- **Corrected expression:** `κ̂ = k*·t*/k = k*/(ρ c V²)` (dimensionless), with `t* = l/V = k/(ρ c V²)`; `k*` re-stated with units `W/(m·K·s) = kg·m⁻¹·s⁻⁴·K⁻¹`.
- **Derivation of correction (from the dimensional governing equation + reference scales):**
  1. GN-III auxiliary flux channel: `q* = −k*ψₓ`, with `[ψ] = K·s` (because ψ̇ = θ) ⇒ `[ψₓ] = K·s/m` ⇒ `[k*] = [q]/[ψₓ] = (kg·s⁻³)/(K·s/m) = kg·m⁻¹·s⁻⁴·K⁻¹ = W/(m·K·s)`.
  2. Main channel: `q = −k θₓ` ⇒ `[k] = W/(m·K)`. Therefore `k*/k` has units s⁻¹ — **not dimensionless**.
  3. Reference time scale present in the benchmark scaling: `t* = l/V = k/(ρ c V²)` (units s).
  4. Nondimensionalizing the k*-flux channel: `k*ψₓₓ = k*·(T₀/l²)·(l/V)·ψ̃ₓ̃ₓ̃` ⇒ dimensionless coefficient `k*·(l/V)/k = k*·t*/k`, and since `t* = k/(ρ c V²)`, `k*·t*/k = k*/(ρ c V²)`.
  5. Final dimensionless coefficient: **κ̂ = k*·t*/k = k*/(ρ c V²)**.
- **Affected equations:** §3.1 `[I]` state energy equation (κ̂ now dimensionless, self-consistent); §3.3 nondim block (q̃, ψ̃, κ̂ scales added); §3.4 register (k* units row [W/(m·K) → W/(m·K·s)], κ̂ row, added q̃, t*, ψ̃ rows) and the dimensional-audit conclusion; §4.4 K_ψψ block (inherits corrected κ̂); §5 benchmark κ̂=0⇔k*=0; §9 checks table.
- **Benchmark effect:** none in substance — the benchmark is LS (k*=0), so κ̂=0 either way; the corrected (dimensionless) definition makes `κ̂=0 ⇔ k*=0` an exact *iff* and makes every numeric κ̂ physically meaningful.
- **Limit-ladder effect:** none — the ladder statements (k*→0, τ→0, …) are statements about the physical coefficients and are unaffected by the κ̂ bookkeeping.
- **Verification performed:** Chk-6 (independent dimensional check of k, k*, t*, κ̂, q̃, ξ — all dimensionless groups unit-free; κ̂ reduces to pure number 1 after reduction to base units). PASS.

### C-2 (W-1) — q̃ defined
Added `q̃ = q·l/(k·T₀) ⇒ q̃ = −θ̃ₓ̃` (consistent with source Eq. (2)/(5) homogeneous form) in §3.3 and the §3.4 register.

### C-3 (W-2) — natural BC terms derived, not asserted
Added the explicit IBP derivation of `[w(ũₓ−θ̃)]₀^L̃` (traction natural ⇒ σ̃ₓₓ(0)=0) and `[v(θ̃ₓ+κ̂ψ̃ₓ)]₀^L̃` (flux natural ⇒ θ̃ₓ(L̃)=0 under κ̂=0) in §4.3, with the GN-III generalization noted.

### C-4 (W-3) — ψ̃(x̃,0)=0 labeled a gauge
§5 now states ψ̃≡0 is a **gauge choice** (ψ enters only via ∂ₓₓ and ∂ₜ) and is decoupled/immaterial under κ̂=0.

### C-5 (W-4) — claims made concrete, no invented definitions
- Derivative cards printed (§4.1) — the O(δx) part of the C¹ requirement, hence required.
- C⁰ quadratic node positions: claim removed in favour of an explicit deferral to G1-code (§4.2, §7.4) — the quadratic reference is a Phase-5 asset, not a Phase-1 requirement.

### C-6 (W-5) — [S]/[D]/[I] re-tagging
- β formula: flagged "standard text definition, NOT source-printed" (non-load-bearing; β eliminated via ξ).
- ψ: provenance narrowed to ZAMM S6 (α̇=θ), not "benchmark family".
- GN-III law: re-tag noted as convention-adjusted with `VERIFY-G1-S1`.
- κ̂: now tagged `[D]` (derived), not a benchmark quantity.

### C-7 (W-6) — notation made dimensionally consistent
State block now uses tilded fields (ũ, p̃, θ̃, φ̃, ψ̃) with "dots = ∂/∂t̃"; `ψ̇ = θ̃` replaced by the consistent pair (`ψ̃ = ψ/(T₀·t*)`, `ψ̃̇ = θ̃`); non-dim dots marked [I].

### C-8 — checks extended
Checks renamed Chk-1…Chk-5 (tracing to A–E) and **Chk-6 added** (the missing rate-coefficient dimensional check). Chk-3 extends CHK-E to ξ, q̃, ψ̃, τ̂, t̃₀.

**No other content changed.** Protected files untouched.

