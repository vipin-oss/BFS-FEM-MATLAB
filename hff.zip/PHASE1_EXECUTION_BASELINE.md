# PHASE1_EXECUTION_BASELINE.md
### Phase-1 setup/verification baseline (traceable, source-locked, mathematically ready)
**Phase:** 1 · **Date:** 2026-09-25 (UTC 12:54 freeze; Phase-1 baseline ~13:05Z) · **Authorities:** `Blueprint_Complete_MGT_BFS-FEM.md` (FROZEN v1.0), `BLUEPRINT_FREEZE_RECORD.md`, `PRE_FREEZE_AUDIT.md`, `SOURCE_PROVENANCE_AUDIT.md`.

---

## 1. Phase-1 objective (frozen)

Establish a fully traceable, source-locked, mathematically ready **baseline** before any production numerical computation. Phase 1 (frozen) = derive (SymPy) the MGT state form, limit ladder, BFS C¹ element, C⁰ reference, assembly, time schemes. **Exit gate G1:** symbolic identities exact; patch test passes; dimensional audit clean.

---

## 2. Implementation contract (NOT yet implemented — contract fixed here)

| Axis | Requirement (frozen anchor) |
|---|---|
| Unknown fields | u (displacement), θ (temperature change), ψ (thermal-displacement history, ψ̇=θ) [Blueprint §I] |
| Spatial discretization | C¹ cubic Hermite (1-D) / BFS bicubic (2-D, Phase 8) [J.1/J.2] |
| C¹ interpolation | value + gradient nodal DOFs; basis + derivative cards [J.2] |
| C⁰ reference | linear + quadratic Lagrange — hard companion for V5/J.4 [J.1(E)] |
| Time integration | consistent Galerkin, order p∈{1,2} — **p OPEN (D1)** [J.1] |
| Assembly | element matrices with exact Gauss rules; quadrature justification [J.2] |
| BC | θ̃(0,t̃)=H(t̃) 1-step closure; σ̃ₓₓ(0)=0 natural; q̃ₓ(L̃)=0 natural; ũ(L̃)=0 essential [J.2/K.4] |
| IC | quiescent [K.4/S1] |
| Solver | linear-algebra consistency checks first; no eigensolver until Phase 4A needs (this is NOT the Bloch problem) |
| Convergence quantities | L²/H¹ spatial orders; time order [J.3/Part III §4] |
| Outputs | θ̃, ũ, σ̃ₓₓ = ∂ũ/∂x̃ − θ̃ [K.8] |
| Dim/ND handling | solve benchmark in its own dimensionless variables [K.7] |

---

## 3. Validation hierarchy preserved (frozen)

- **MANDATORY:** V1 (manufactured), V2 (time order), **V3** (external Nikolarakis benchmark), **V5** (C⁰ cross-validation), **V6** (MGT→LS identity).
- **SUPPORTING:** V4 (digitized Bagri), V7 (CTE limit), V7b (GN-III steady), V8 (Boley–Tolins), V9 (Bazarra cross-check), V10/JV5 (elastic dispersion).
- **Distinctions kept:** external validation ≠ internal model-reduction verification ≠ convergence verification ≠ parameter sensitivity. Model limits and in-house sweeps are **not** external validation.
- **V3 not executed in Phase 1** (frozen Phase 3); Phase 1 has no benchmark claims.

---

## 4. Tolerances — status and what future data they need

The 1 %/2 %/5 % bands remain **PROVISIONAL — TO BE FIXED AFTER CONVERGENCE / ERROR CHARACTERIZATION**. This turn determines only the evidence needed later:

| Tolerance | Future evidence required to fix it |
|---|---|
| 1 % (C¹ vs C⁰, in-house) | measured self-convergence error of the finer solver (from V1/V5 h-and-Δt halving), Richardson-extrapolated |
| 2 % (vs Nikolarakis FEM) | V1/V5 measured self-convergence of OUR solver at the benchmark's resolution (1000 el / 1250 steps analogue) |
| 5 % (digitized series) | digitization-extraction uncertainty measured at execution (Fig grid tick coarseness) |

None is adjusted now. No tolerance is "chosen to pass."

---

## 5. Novelty — status

**NOT claimed established.** All "first…"/"no … exists" statements remain **PROVISIONAL — TO BE ESTABLISHED BY SYSTEMATIC LITERATURE REVIEW**. The review is a scheduled Phase-1 sub-task (P1.0); it was **not** executed this turn (this turn = source-lock + baseline only). Frozen Blueprint Part I §H and Part IV §C wording governs.

---

## 6. Pilot / cost / checkpoint plan (defined; NOT launched)

| Item | Plan |
|---|---|
| Smallest meaningful pilot (post-G1) | 1-D **homogeneous LS-layer thermal shock** (benchmark Eq. 11, ξ=0.05, t̃₀=1) as the first C¹ state-form solve — it is simultaneously V3's problem and the V5/V6 cross-check bed |
| Expected cost | seconds-to-minutes, single core (target n≤1000 C¹ elements, Δt per shockscale) |
| Memory/storage | negligible (state-form matrices; n≤1000 → ≲1 MB); none exotic |
| Checkpoint | per-time-horizon state snapshots (HDF5/npz) with run manifest |
| Resumability | resume from last checkpoint + full manifest (git commit, params SHA, env versions) |
| Naming | `run/YYYYMMDDTHHMMSSZ-case-<id>/raw`, `<id> = G1-patch | pilot-LS | …` |
| Determinism | fixed seeds; recorded SymPy/NumPy/SciPy versions; identical env output |
| Failure/restart | restart from checkpoint or from zero (cheap); failed-run logs retained in `audit/` |

**This turn:** pilot NOT launched (G1 derivations not yet done; big-run never authorized).

---

## 7. Git / reproducibility status (inspected — read-only)

- **Git:** `/home/user` (this workspace) is **not a git repository** — no branch, no HEAD, no working tree here. **No commit SHA is fabricated.**
- **Project repository (`vipin-oss/BFS-FEM-MATLAB`, read-only GitHub API):** default branch `main`; HEAD `376f08291a30e6e7fff605d354354222953d2d22` ("Add files via upload", 2026-09-25T08:38Z); pushed_at 2026-09-25T11:53Z. Branches: `main`, `audit/stage-1-5-6-completion`, `phase-1-symbolic`. Paper-9 phase directory structure exists (`paper9/{plan,eqs,params,bench,analytic,solver,verification,validation,results,figures,tables,latex,bib,audit,release}`).
- **Frozen Blueprint in repo?** Not present (searched `main` recursively).
- **Phase-1 branch in repo?** No dedicated `phase-1` branch exists among the three listed.
- **Recommendation (external, no credentials touched):** under the project workflow, add the frozen documents + these three Phase-1 files to the repo; create a `phase-1` branch for derivation work if the existing workflow allows. **Not attempted here** (no credentials; task = inspect only).

---

## 8. Hard stop conditions applied this turn

1. Quintanilla 2019 full text missing → **did not stop**: frozen authority authorizes OA reconstruction (S5/S6). Recorded in `PHASE1_SOURCE_LOCK.md` §2.
2. Bagri 2006 original missing → **did not stop**: benchmark executable via S1; OPEN-provenance recorded.
3. Benchmark unambiguous (Eq. 11) → OK.
4. Parameter provenance: Zhan & Wei values **carry a documented provenance gap** → recorded; **out of scope for THIS blueprint** (adjacent Paper-9); frozen status preserved.
5. Implementation choices D1/D2/D3 materially affect the science and are unspecified by the frozen text → **flag: OPEN — IMPLEMENTATION DECISION REQUIRED** (listed in `PHASE1_TRACEABILITY.md` §5); NOT silently resolved.
6. Repository state → prevents in-repo commit flow here; documented; no fabrication.

---

## 9. Phase-1 gate (G1) definition reminder

G1 (frozen): symbolic limit-ladder returns **exact** reductions; **patch test passes** (machine precision); **dimensional audit clean**. → none of these has been run yet; they are the *rest of Phase 1*, not this baseline.

---

## 10. Files created / modified this turn

- `PHASE1_SOURCE_LOCK.md` (created)
- `PHASE1_TRACEABILITY.md` (created)
- `PHASE1_EXECUTION_BASELINE.md` (created)
- `src_audit/` notes and `src_audit/nik_page*.png` (temporary scratch, from earlier audits — not part of the deliverable set)
- **Frozen Blueprint and all previous authority files: UNMODIFIED.**

---

## 11. Computation executed this turn?

**Yes, minimal and non-scientific:** text/token checks against locally held authority PDF; portfolio workbook parse; DOI resolution (HTTP status queries). **No FEM code, no derivation, no eigensolver, no production/validation run.**

## 12. Production FEM / validation started?

**No.**

---

## 13. Phase-1 status

**PASS WITH OPEN ITEMS** (baseline established; open items are tracked and non-scientific/derivation-scoped; see `PHASE1_TRACEABILITY.md` §5 and `PHASE1_SOURCE_LOCK.md` §3).

---

### Final line
PHASE 1 READY FOR PILOT
