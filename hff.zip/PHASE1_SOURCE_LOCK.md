# PHASE1_SOURCE_LOCK.md
### Phase-1 source lock and provenance register (MGT Thermoelasticity C¹ BFS-FEM)
**Phase:** 1 (setup/verification baseline) · **Date:** 2026-09-25 · **Authority:** `Blueprint_Complete_MGT_BFS-FEM.md` (FROZEN v1.0), `BLUEPRINT_FREEZE_RECORD.md`, `PRE_FREEZE_AUDIT.md`, `SOURCE_PROVENANCE_AUDIT.md`.

**Rule:** no source is marked VERIFIED merely because it exists. Status reflects (i) accessibility and (ii) actual verification of the relevant content performed to date. No missing equation/parameter/table/value is filled from general knowledge.

---

## 1. Source register (status-verified this Phase-1 turn)

| # | Source | Exact role | Section/Eq/Table used | Accessible? | Content verified? | Pri/Sec | STATUS |
|---|---|---|---|---|---|---|---|
| S1 | Nikolarakis & Theotokoglou (2018), *Math. Probl. Eng.* 2018:7371016, DOI 10.1155/2018/7371016 | **Primary benchmark** (LS layer thermal shock; printed IBVP + published FEM curves) | §4.1, Eq.(11) (IBVP), Eqs.(2),(3),(5),(10) (constitutive/normalization), Figs 2–4 (targets), "1000 elements/1250 steps" | YES — full 12-page PDF held locally (`src_audit/nik_wb.pdf`, text `nik.txt`) | YES — all benchmark tokens re-checked against local text this turn (parameters ξ=0.05, t̃₀=1, c̃E=c̃K=1; BC θ̃(0)=H(t̃), σ̃ₓₓ(0)=0, q̃ₓ(L̃)=0, ũ(L̃)=0; IC quiescent; 4 instants) | Primary | **VERIFIED** |
| S2 | Bagri, Taheri, Eslami & Fariborz (2006), *J. Thermal Stresses* 29(4):359–370, DOI 10.1080/01495730500360492 | Ancestor benchmark (LS layer) — provenance + second data series ("[26]") | its normalized IBVP/params as transcribed in Nikolarakis §4.1 | No (T&F paywall) | Partially — via S1's verbatim transcription only | Primary | **PARTIALLY-VERIFIED** (non-blocking; original PDF = OPEN-provenance) |
| S3 | Boley & Tolins (1962), *J. Appl. Mech.* 29(4):637–646, DOI 10.1115/1.3640647 | **Optional** independent CTE half-space anchor (K.2) | figure set of classical coupled half-space | No (ASME paywall) | No | Primary | **OPEN** — (optional; NOT on the mandatory chain) |
| S4 | Quintanilla (2019), *Math. Mech. Solids* 24:4020–4031, DOI 10.1177/1081286519862007 | Canonical MGT model definition (named in Blueprint Part I §I) | full model equations | No (SAGE paywall) | No (full text) | Primary | **PARTIALLY-VERIFIED** (existence + citation verified; content via OA derivatives S5/S6; full text = OPEN-preferred) |
| S5 | Abouelregal et al. (2020), *Materials* 13:4463, DOI 10.3390/ma13194463 | **Reduction table** cross-reference (CTE/LS/GN-II/GN-III limits) | "Special Cases" list | YES (MDPI open access) | YES — reduction ladder captured | Secondary (re-statement) | **VERIFIED** |
| S6 | Bazarra, Fernández & Quintanilla (2024), *ZAMM* 104:e202300531, DOI 10.1002/zamm.202300531 | **MGT heat-conduction constitutive law** (GN-III + lag) + prior C⁰-FEM/implicit-Euler art | Intro Eq. (GN-III: qᵢ=κᵢⱼα,ⱼ+κ*ᵢⱼθ,ⱼ) and Eq. (2) (MGT: τq̇ᵢ+qᵢ=…); abstract (FEM, implicit Euler, linear convergence, 1-D) | YES (Wiley open access) | YES — law captured this turn | Primary-quality (same origin group) | **VERIFIED** |
| S7 | Bazarra, Fernández & Quintanilla (2022), *J. Comput. Appl. Math.* 409:114181, DOI 10.1016/j.cam.2022.114181 | Prior MGT thermoelasticity FEM (gap anchor; 1-D C⁰ linear) | a-priori error/FEM (cited for gap only) | No (Elsevier paywall) | Metadata only | Primary | **PARTIALLY-VERIFIED** — used for **gap documentation only** |
| S8 | Author portfolio workbook `Vipin_Research_Papers_06-Aug_2026.xlsx` (local) | Portfolio themes, foundations (MGT precedent), JV5 dispersion anchors | 48 rows, parsed locally | YES (local) | YES — 52 rows parsed; 48 publications | Primary (author's own) | **VERIFIED** |
| S9 | Zhan & Wei (2010), *Acta Mech. Solida Sin.* 23(2):181–188, DOI 10.1016/S0894-9166(10)60020-1 | **ADJACENT — Paper 9 Case-C only; NOT used by this Blueprint** | Table 1 (epoxy ρ/μ) | Paper: yes (SD record); Table 1: no | Partially — see `SOURCE_PROVENANCE_AUDIT.md` | — | **PARTIALLY-VERIFIED — values NOT upgraded** (ρ=1142 kg/m³, μ=1.48e9 Pa remain source-unverified) |
| S10 | Lord & Shulman (1967); Green & Naghdi (1993); Biot (1956) | Classical model definitions re-expressed inside S4–S6 and the benchmark Eq.(11) | — (no direct copy needed) | — | Via S1/S5/S6 | Secondary | **NOT REQUIRED for derivation** (framed via S5/S6; cited in manuscript only) |

**DOI resolution performed this turn (HTTP status):** S4=403(paywall), S1=403 (full text held locally anyway), S2=403, S3=403, S5/S6/S7/S9 resolve.

---

## 2. Recorded conflict / resolution (no guess)

**Tension in the frozen authority:** Blueprint Part I §I says MGT coefficients are "re-derived in Phase 1 from Quintanilla (2019)"; but Part II §7 and Part I §U (both frozen) authorize reconstruction from **open-access** derivatives (Bazarra et al. ZAMM 2024 — law; Abouelregal et al. 2020 — reduction table), and mark Quintanilla 2019 as "preferred (not blocking)".

**RESOLUTION (recorded, traced to the frozen authority):** derive the MGT state form from **S6 (OA, same MGT origin group, law verbatim)** and cross-check the limit ladder against **S5 (OA reduction table)**; **S4 remains OPEN-preferred** for canonical citation and is NOT required for the derivation. This follows the frozen Part II §7 items 4–5 literally; it is not a reinterpretation.

---

## 3. OPEN — REQUIRED SOURCE (exact items, non-blocking unless noted)

- **OPEN-S1:** Quintanilla (2019) full text (canonical citation; derivation uses S5+S6).
- **OPEN-S2:** Bagri et al. (2006) original PDF (confirm L̃ and the "[26]" series identity — provenance strengthening; benchmark is executable without it).
- **OPEN-S3:** Boley & Tolins (1962) figure set (only if the optional K.2 independent CTE anchor is exercised; otherwise dropped).
- **OPEN-S4 (minor, Phase-3 task, not a source):** numeric L̃ confirmation for Nikolarakis §4.1 (axis-implied = 1) — confirmed at digitization.

None of the above blocks Phase-1 derivation or the mandatory benchmark chain.

---

## 4. Status guardrails carried into execution

- Zhan & Wei (2010): **Table-1 values remain SOURCE-PARTIALLY-VERIFIED; ρ=1142 kg/m³ and μ=1.48e9 Pa are NOT upgraded** without direct evidence (SOURCE_PROVENANCE_AUDIT classification C).
- Verification ≠ validation ≠ model-reduction ≠ sensitivity (frozen distinctions preserved).
- Provisional tolerances (1%/2%/5%) NOT fixed here.
- Novelty claims remain PROVISIONAL — TO BE ESTABLISHED BY SYSTEMATIC LITERATURE REVIEW (Phase-1 sub-task P1.0, scheduled, not executed this turn).
