# PHASE1_TRACEABILITY.md
### Mathematical traceability map: Blueprint requirement → source → implementation object
**Phase:** 1 · **Date:** 2026-09-25 · **Authorities:** Frozen Blueprint Part I §I–§J; Part III §2 (formulation specification). **No full derivation yet** (G1 exit). This map fixes what MUST be derived later and from where.

**Legend.** `[S]` = source/document (status per PHASE1_SOURCE_LOCK §1); `[DR]` = explicit derivation responsibility planned (not filled from general knowledge); `[TBD]` = must be fixed by a documented decision (not silently chosen).

---

## 1. Governing model objects

| # | Blueprint requirement | Source / derivation | Planned implementation object | Status |
|---|---|---|---|---|
| M1 | Isotropic 1-D momentum + thermoelastic coupling (Navier + `−γ θₓ`) | Benchmark Eq.(11) first equation `∂(∂ũ/∂x̃ − θ̃)/∂x̃ = ü̃/c̃E²` [S1] | `eqs/momentum_1d.md` | **VERIFIED** (benchmark form) |
| M2 | LS energy equation (one relaxation time) | Benchmark Eq.(11) second equation [S1]; classical origin [S10 via S1] | `eqs/ls_energy_1d.md` | **VERIFIED** |
| M3 | MGT heat-conduction constitutive law (GN-III + lag) | Bazarra ZAMM 2024 Eq.(2): `τq̇ᵢ + qᵢ = κᵢⱼ α,ⱼ + κ*ᵢⱼ θ,ⱼ` [S6]; canonical citation Q2019 [S4, OPEN-preferred] | `eqs/mgt_energy_1d.md` | **VERIFIED (via OA S6)** |
| M4 | GN-III base law (α = thermal displacement, `α̇ = θ`) | Bazarra ZAMM 2024 Intro Eq. [S6] | `eqs/gn3_base.md` | **VERIFIED** |
| M5 | Limit ladder CTE/LS/GN-III/GN-II | Abouelregal 2020 "Special Cases" [S5]; machine-checked in Phase 2 (G1b) | `eqs/ladder.md` | **PARTIALLY-VERIFIED → Phase-2 exact check** |
| M6 | State/first-order form `Z = (u, u̇, θ, ψ, ψ̇-type)` (ψ̇=θ) | [DR#1] from M1+M3 (third-order-in-time pattern) — Blueprint §I | `eqs/state_form.md` | [DR#1] — Phase-1 derivation task |
| M7 | Coupling term `−γ∂θ/∂x` in momentum; `γT₀∂e/∂t` in energy (dimensional) | [DR#2] from M1–M3 vs benchmark normalized pair M1/M2 | `eqs/coupling.md` | [DR#2] |
| M8 | Constitutive stress σ and heat flux q | Benchmark Eq.(5): σ̃=∂ũ/∂x̃−θ̃, q̃=−∂θ̃/∂x̃ [S1] | `eqs/constitutive.md` | **VERIFIED** |
| M9 | Non-dimensionalization (ℓ*, c*, t*, ε, τ̂, κ̂) | Blueprint §I scheme; benchmark's own scheme [S1 Eq.(3),(10)] | `eqs/nondim.md` | [DR#3] + benchmark scheme VERIFIED |
| M10 | Boundary/initial conditions | Benchmark Eq.(11) [S1] B4C | `eqs/bc_ic.md` | **VERIFIED** |
| M11 | Material parameters | benchmark dimensionless (ξ=0.05, t̃₀=1, c̃E=c̃K=1, L̃=1) [S1]; Zhan & Wei NOT used | `eqs/params.md` | **VERIFIED** (Z&W classified out-of-scope) |
| M12 | Symbol register + dimensional audit | [DR#4] (G1 requirement) | `eqs/symbol_register.md` | [DR#4] |

**Objective status:** every object has a VERIFIED source or an explicit [DR]. **No unsupported equation.** The genuinely new derivation (state form of the MGT third-order system) is an explicitly owned [DR], not a silent fill.

---

## 2. Benchmark objects

| # | Object | Source | Verified | Notes |
|---|---|---|---|---|
| B1 | LS-layer IBVP (normalized) | S1 §4.1 Eq.(11) | YES | printed verbatim |
| B2 | Parameters ξ=0.05, t̃₀=1, c̃E=c̃K=1 | S1 | YES | token-checked vs local PDF |
| B3 | BC set (θ̃ H-step; σ̃=0; q̃=0; ũ=0) + quiescent IC | S1 | YES | token-checked |
| B4 | Output quantities θ̃, ũ, σ̃ₓₓ at t̃=0.25,0.50,0.75,1.25 | S1 Figs 2–4 | YES (figures; digitization = Phase-3) | |
| B5 | L̃ value | S1 axis span | PARTIAL — confirm at digitization (Phase-3, not a Phase-1 blocker) | |
| B6 | Two published target series (authors' FEM + Bagri "[26]") | S1 | YES (existence); Bagri-specific = S2 provenance OPEN | |

---

## 3. Method objects (Phase-1 derivation scope)

| # | Object | Authority | Status |
|---|---|---|---|
| N1 | C¹ cubic-Hermite shape functions + derivative cards | Blueprint J.2 | [DR#5] |
| N2 | C⁰ linear/quadratic shape functions (reference solver) | Blueprint J.1(E) | [DR#6] |
| N3 | Weak (Galerkin) form on C¹ spaces | Blueprint J.2 | [DR#7] |
| N4 | Element matrices + Gauss-rule justification | Blueprint J.2 | [DR#8] |
| N5 | State-form time scheme (consistent, p∈{1,2}) | Blueprint J.1 | [DR#9] + **OPEN — IMPLEMENTATION DECISION (p=1 vs p=2)** |
| N6 | Heaviside-step nodal prescription (1-step closure) | Blueprint J.2 (frozen wording) | [DR#10] |
| N7 | Patch test (JV4) | Blueprint J.3 | [DR#11] |

---

## 4. Instant vs. full derivation scope (this turn)

- **Executed this turn:** source-status verification only (source lock).
- **Deferred to the rest of Phase 1 (G1 work):** [DR#1–DR#11], i.e. all derivations and patch test.
- **Not started:** any production FEM/validation. No equation was silently fixed.

---

## 5. Decisions left open (recorded, NOT silently chosen)

| ID | Decision | Frozen anchor | Affects |
|---|---|---|---|
| D1 | Time-integrator order p ∈ {1,2} | Blueprint J.1 "p∈{1,2}" | state-form stiffness/accuracy — **OPEN** |
| D2 | Full state-variable set vs. condensed second-order-in-θ form of MGT | Blueprint §I "Z=(u,u̇,θ,ψ,ψ̇-type)… exact set fixed in Phase 1" | implementation object M6 — **OPEN** |
| D3 | First-derivative DOF duplication for C¹ vs. C⁰ reference parity in DOF counting (J.4 metric) | Blueprint J.4 | efficiency study — **OPEN** (flagged, not blinding) |

Each is a documented Phase-1 derivation-time decision with an explicit frozen anchor to decide it against.
