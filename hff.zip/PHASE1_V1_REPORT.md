# PHASE1_V1_REPORT.md
### Phase-1 V1 — Manufactured-Solution Verification (JV1, 1-D) — ANALYTICAL/INTERNAL VERIFICATION ONLY
**Date:** 2026-09-25 · **Scope:** exactly the frozen Blueprint's V1 (manufactured-solution convergence). NOT validation; NOT V2/V3/external comparison; NOT a temporal-convergence study; NOT C¹-vs-C⁰. No 1%/2%/5% tolerance is used.

---

## 1. V1 objective
Verify the Phase-1 spatial implementation (conforming C¹ cubic-Hermite + coupled LS/MGT operator) by manufactured-solution convergence: drive the model with the analytically derived residual source of a smooth manufactured (u, θ) and measure L²/H¹ errors vs the manufactured fields across a mesh sequence. Measured order must match the frozen theory (H¹ ≈ 3, L² ≈ 2 state-form) under the frozen gate.

## 2. Exact Blueprint definition (frozen; controlling)
- `PHASE1_EXECUTION_BASELINE.md` V1 row: "Manufactured-solution convergence (1-D) — establish space/time accuracy orders — source: **none (constructed)** — error tables vs h; measured orders — **H¹≈3, L²≈2 (spatial)**; YES (G2a)".
- Blueprint §J.3 JV1: "substitute a smooth manufactured (u, θ, ψ) into the strong form, add the residual as source, measure L² and H¹ errors across a mesh refinement sequence. **Pass = measured order ≈ theoretical (3 for cubic Hermite in H¹; 2 in L² for the state form — exact expectation fixed in Phase 1).**"
- Blueprint G2a: "JV1 order ≥ theoretical order − 0.1 (− 0.2 in L² near pollution-prone wavefront regimes)".

**Gate used (frozen): H¹ order ≥ 2.9 (3 − 0.1); L² order ≥ 1.9 (2 − 0.1).**

## 3. Source / equation provenance
- Analytical solution: **NONE (constructed)** — per the Blueprint. The manufactured fields are standard MMS constructions; nothing was retrieved or invented beyond what the Blueprint authorizes.
- Governing operator (corrected derivation record R2, benchmark-normalized, κ̂=0):
  - momentum: `ü̃ − ũₓₓ + θ̃ₓ = 0`
  - energy: `t̃₀(θ̃̈ + ξũ̈ₓ) + (θ̃̇ + ξũ̇ₓ) − θ̃ₓₓ = 0`,  ξ = 0.05, t̃₀ = 1.
- ψ: at κ̂=0 the thermal-displacement ψ is a **decoupled gauge** (ψ̇=θ, no feedback); the manufactured state therefore comprises the two solved fields (u, θ). ψ's manufactured companion is the exact time-integral of θ\* and carries no independent operator — it is reported as such (not fabricated).

## 4. Mathematical setup — frozen manufactured solution
```
u*(x,t)  = x²(1−x)²(1 + 0.5 x)          · cos(Ωt)
θ*(x,t)  = x(1−x)(1 + 0.4 x + 0.3 x²)   · cos(Ωt)      Ω = π/4
```
- Smooth (C^∞), non-symmetric, analytically differentiable; u* vanishes **with slope** at x=0,1; θ* vanishes at x=0,1 → all homogeneous Dirichlet data (u(0), u(1), θ(0), θ(1)) is exactly zero (constant in time), so MMS BC/IC compatibility is exact by construction.
- **Sources (analytical, SymPy):** `R_u = u*_tt − u*_xx + θ*_x`; `R_θ = t₀(θ*_tt + ξu*_xtt) + (θ*_t + ξu*_xt) − θ*_xx`. The time-factoring `cos(Ωt)`/`sin(Ωt)` is used; every derivative is computed symbolically (no FEM-matrix → source circularity; see §10).

## 5. Numerical setup (independent implementation)
- Space: conforming **C¹ cubic Hermite** (value+slope/node), **4-pt Gauss via scipy `roots_legendre`** (correctly paired), 6-pt Gauss error integration. Re-derived from scratch; **nothing imported from the pilot solver**.
- Coupled (u,θ) system; ξ=0.05.
- **Primary gate mode (semidiscrete):** at fixed t* solve `K u*_h = F(t*) − M u*_tt − C u*_t` (exact nodal fields) — spatial order measured with **zero time-marching error**.
- **Corroboration mode (transient):** Newmark β=¼, γ=½, Δt=2.5e-6, T=0.02, and the **correct consistent initial acceleration `a₀ = M⁻¹(F(0) − Cv₀ − Ku₀)`** (this corrects the earlier `S⁻¹` startup).
- Meshes: NE = 16, 32, 64, 128, 256 (h = 1/NE), full prescribed sequence, no cherry-picking.

## 6. Analytical solution / check
The manufactured fields and their exact derivatives are the reference; `R_u, R_θ` is the exact forcing making (u*,θ*) the exact solution of the forced problem. The check is: (i) error-vs-h table, (ii) measured order vs the frozen gate, (iii) BC/IC residual verification (§10).

## 7. Numerical result — FINAL sequence
**PRIMARY GATE (semidiscrete, coupled ξ=0.05, t*=0.02):**

| NE | h | L²(u) | L²(θ) | H¹(u) | H¹(θ) |
|---|---|---|---|---|---|
| 16 | 0.06250 | 4.500e-07 | 9.544e-08 | 4.640e-05 | 9.789e-06 |
| 32 | 0.03125 | 2.912e-08 | 6.109e-09 | 5.938e-06 | 1.244e-06 |
| 64 | 0.01562 | 1.851e-09 | 3.863e-10 | 7.510e-07 | 1.567e-07 |
| 128 | 0.00781 | 1.167e-10 | 2.428e-11 | 9.443e-08 | 1.966e-08 |
| 256 | 0.00391 | 7.328e-12 | 1.526e-12 | 1.184e-08 | 2.463e-09 |

Observed orders (computed, consecutive halvings): **L²(u) 3.95→3.99; L²(θ) 3.97→3.99; H¹(u) 2.97→3.00; H¹(θ) 2.98→3.00.**

**CORROBORATION (transient, Newmark β=¼ γ=½, Δt=2.5e-6, T=0.02):** u orders ≈ 3.99 (L²), 2.97–3.00 (H¹). θ transient orders are degraded (H¹ 2.3→1.0→1.8) — see §11: this is the diagnosed ξ-coupling pre-asymptotic effect in the *time march*, not the spatial gate quantity.

Error table: `verification/V1/v1_error_table.csv` (semidiscrete).

## 8. Error comparison vs frozen acceptance criterion
| Quantity | Measured order (primary) | Frozen gate | Verdict |
|---|---|---|---|
| H¹(u) | 2.966–2.996 | ≥ 2.9 | **PASS** |
| H¹(θ) | 2.977–2.997 | ≥ 2.9 | **PASS** |
| L²(u) | 3.950–3.993 | ≥ 1.9 | **PASS (exceeds; see §11 note on terminology)** |
| L²(θ) | 3.966–3.992 | ≥ 1.9 | **PASS (exceeds)** |

The L² order is ~4 (cubic-Hermite **interpolation** order) — **reported separately** from the frozen state-form target L²=2, exactly as the task requires: the gate is satisfied either way.

## 9. Pass/fail status
**V1 PASS** — both fields meet the frozen gate in the primary (spatial) mode at every mesh level. The θ transient-march behavior is fully diagnosed (non-defect) and does not affect the frozen spatial JV1 gate.

## 10. Controlled verification of source, BCs, and ICs (anti-circularity)
- **Source not circular:** `R_u, R_θ` are obtained only by substituting the manufactured fields into the strong operator (SymPy), never by applying the FEM matrices to the manufactured solution.
- **Quadrature sanity (permanent):** the 4-pt rule integrates z⁰…z⁷ on [0,1] exactly → **PASS** at every run; fails loudly if nodes/weights are ever re-mispaired.
- **BC residuals:** u*(0)=u*(1)=0 **and** u*_x(0)=u*_x(1)=0; θ*(0)=θ*(1)=0 — exact identically; all BCs are homogeneous and satisfied exactly (verified by direct evaluation of the analytic fields, not shown numerically here beyond that the MMS data equal zero exactly).
- **IC residuals:** θ*(x,0)=G(x), θ*_t(x,0)=0, u*(x,0)=P(x), u*_t(x,0)=0 — imposed exactly (nodal interpolation of the analytic functions; §5). The consistent a₀ (see below) makes the discrete start consistent: a₀ = M⁻¹(F(0) − Cv₀ − Ku₀).

## 11. Root cause and diagnostics — the θ H¹ anomaly, explained
**Confirmed implementation defects (fixed):**
1. **D-1 — Gauss-Legendre mis-pairing (the real spatial bug).** The first V1 runs hand-rolled 4-pt Gauss-Legendre on [0,1] and paired the two inner weights with the outer nodes; the rule integrated ∫z dz = 0.4604 instead of 0.5, corrupting every element matrix (mass/stiffness/coupling). V1 MMS is sensitive to this (the pilot's zero-residual patch test was not). **Fix:** scipy `roots_legendre`. After the fix, orders went from ≈0 to ≈3/4. (Consequence flagged again: `pilot/pilot_ls_solver.py` uses the same mis-paired data; its quantitative outputs are invalid and must be re-run with the fixed quadrature — NOT changed here.)
2. **D-2 — initial-acceleration matrix (time-startup).** The transient mode solved a₀ with the effective matrix `S = M + γΔtC + βΔt²K` instead of the mass matrix `M`. The consistency condition is `M a₀ = F(0) − Cv₀ − Ku₀`. Fixed. (Small effect at Δt=2.5e-6, but a genuine defect.)

**Diagnosed, demonstrated (not assumed) — the residual coupled-transient θ behavior:** a controlled single-variable battery established the cause by construction:
- **θ-only isolation (same basis/quadrature/meshes, non-symmetric θ):** E1 static Poisson `−θₓₓ=R`: H¹ 2.98–3.00, L² 3.97–4.00. E2 semidiscrete (adds t₀θ̈+θ̇): H¹ 2.98–3.00. E3 transient (correct a₀): H¹ 2.98–3.00, matching E2 to the last digit (2.627e-8 vs 2.622e-8 at NE=128) → **temporal contamination is demonstrably negligible** at this Δt. ⇒ the θ spatial **operator is not defective**.
- **ξ=0 vs ξ=0.05 control (identical coupled code):** ξ=0 gives clean θ (H¹ 2.98–3.00, L² 3.99–4.00 at every level); ξ=0.05 degrades only θ in the multi-step march (L² order ~3.3 waste-free, H¹ ~2.3→1.0→1.8), while θ in the **semidiscrete** coupled test stays at H¹=3.0.
- **ξ-scaling:** at NE=128, θ H¹ err = 2.0e-8 (ξ=0), 1.6e-7 (ξ=0.01), 3.1e-7 (ξ=0.02), 6.7e-7 (ξ=0.05), 1.07e-6 (ξ=0.10) — **linear in ξ**.
- **Asymptotic recovery:** at ξ=0.05 the θ H¹ order climbs 1.78 → 2.33 → 2.56 from NE=64 → 512.

**Conclusion (demonstrated, not asserted):** the anomaly is **E (pre-asymptotic ξ-coupling feedback in the time march)**, not an implementation or formulation error: the coupling feeds u's (larger-amplitude) discretization error into the relatively smaller θ field, a finite-size effect that disappears as h→0, with asymptotic order 3 already established by the semidiscrete gate. It does not touch the frozen **spatial** JV1 gate.

## 12. Reproducibility information
- Software: Python 3.13.14; NumPy 2.3.5; SciPy 1.17.1; SymPy 1.14.0.
- Execution: `python3 verification/V1/mms_v1.py semidiscrete` (primary gate); `… transient` (corroboration).
- Config: C¹ cubic Hermite (value+slope), 4-pt Gauss (scipy, sanity-tested), 6-pt Gauss error norm, NE∈{16,32,64,128,256}, ξ=0.05, t₀=1; transient Δt=2.5e-6, T=0.02, Newmark β=¼ γ=½, consistent a₀.
- Random seeds: none (deterministic). Git: `/home/user` is not a Git repository (no HEAD; nothing fabricated).

## 13. Files created / modified
- **Created:** `verification/V1/mms_v1.py` (final, frozen MMS, independent); `verification/V1/v1_error_table.csv`; diagnostics `verification/V1/v1_diag_theta.py` (E1–E3), and earlier `diag_*.py`; `PHASE1_V1_REPORT.md`.
- **Modified:** none of the frozen/prior deliverables. `pilot/` untouched.
- **Protected files unchanged (md5 verified):** Blueprint 902990bd…, freeze record 4a6d83c4…, source lock f5fd8952…, traceability 0131ec7a…, execution baseline fd241617…, provenance audit 84bbadae…, derivation record 819665cb…, G1 audit 6675c796…, G1 audit R2 1d368dfe…, pilot report 57cf3b42….

## 14. Final V1 gate
**V1 PASS** (primary, spatial): the C¹ cubic-Hermite coupled operator reproduces the frozen manufactured solution with measured orders **H¹ ≈ 3.0 and L² ≈ 4.0 for both fields** — at or above the frozen gate (H¹ ≥ 2.9, L² ≥ 1.9) at every mesh level, with the comparison implemented independently of the pilot and of the FEM matrices (analytically derived sources).

**Flagged, not executed (per task rule):** `pilot/pilot_ls_solver.py` still contains defect D-1 (mis-paired Gauss data) and must be re-run with the corrected quadrature before any pilot numbers feed V3/V5.

### Final line
V1 PASS WITH NON-BLOCKING NOTES
