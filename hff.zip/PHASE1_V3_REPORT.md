# PHASE 1 — V3: External Validation vs Published Nikolarakis–Theotokoglou FEM Curves

**Date:** 2026-09-26 · **Status line at end of this file.**
**Task executed:** V3 comparison only, per frozen Blueprint §K/§4.5 and the approved V3 specification. No Blueprint modification. No V4. No solver modification mid-comparison (one defect in the *new comparison driver* was found and fixed before any result was issued — see §7).

---

## 1. PROVENANCE CLASSES (never to be confused)

| Class | Object | Provenance / location |
|---|---|---|
| **P1. Published benchmark source** | Nikolarakis & Theotokoglou (2018), *Math. Probl. Eng.* 2018:7371016, DOI 10.1155/2018/7371016 — the IBVP (Eq. 11), parameters (c̃E=c̃K=1, ξ=0.05, t̃₀=1, L̃=1), BCs/ICs, and Figures 2–4 | `src_audit/nik_wb.pdf` (publisher PDF, lawfully obtained; sha256 in `verification/V3/v3_run_manifest.json`) |
| **P2. Extracted published curve data (targets)** | 12 FEM polylines (θ̃, ũ, σ̃ₓₓ × t̃=0.25/0.50/0.75/1.25) recovered from the PDF's vector layer; [26]-Bagri markers kept separate; TARGET-EXTRACTION PASS + package audit PASS | `verification/V3/targets/*.csv` + `v3_targets_fem.json` (per-file sha256 in manifest); extractor `v3_extract_targets.py` — NOT used to build any field in this report beyond loading these files |
| **P3. Our FEM calculation** | C¹ cubic-Hermite (BFS p=2) + Newmark(β=¼,γ=½) + 4-pt Gauss, verified primitives imported from `verification/V1/mms_v1.py`; benchmark driver `verification/V3/v3_fem_ls.py`; Richardson-converged field R | `v3_results.json` + manifest |
| **P4. Extraction uncertainty** | x̃ ±0.0025; ỹ ±0.0084 (θ), ±0.0049 (u), ±0.0161 (σ) | recorded in `v3_targets_fem.json` / package audit |
| **P5. Calculated comparison errors** | everything in §4 tables below | computed in this run from P2 vs P3 only |

No P3/P5 number was used to alter P2; no P2 value was corrected, shifted, smoothed, rescaled, or clipped at any point.

## 2. SOLVER CONFIGURATION & NUMERICAL CREDIBILITY (directive 5)

* **Model:** normalized LS IBVP exactly as transcribed (frozen Blueprint §3): momentum `u_tt = u_xx − θ_x`; energy `t₀(θ_tt + ξ u_xtt) + (θ_t + ξ u_xt) = θ_xx`; σ = u_x − θ; q = −θ_x; ξ=0.05, t₀=1, cE=cK=L=1, κ̂=0 (θ̃(0,t̃)=H(t̃) sharp step at t̃=0⁺; σ(0)=0 and q(1)=0 natural; u(1)=0 essential; quiescent ICs).
* **Scheme:** conforming C¹ cubic Hermite on both fields (value+physical-slope DOFs; 4·(NE+1)); Newmark average-acceleration (β=¼, γ=½), consistent a0 = M⁻¹(−K_fp u_p); 4-pt Gauss per element (permanently sanity-guarded: exact through degree 7).
* **Runs:** (512, Δt=6.25e-4, 2000 steps, 2052 DOFs) · (1024, 3.125e-4, 4000, 4100) · (2048, 1.5625e-4, 8000, 8196). Direct sparse LU — no iterative tolerance; final-step relative residuals 4.9e-22 / 1.4e-22 / 1.7e-23. No NaN/Inf. Conditioning (power-iteration 2-norm estimates of S): 6.3e7 / 2.5e8 / 1.0e9. CFL ≤ 0.32.
* **Converged field for comparison:** R = fine + (fine−mid)/3 (h and Δt both halved, p=2). Blueprint rule honored: tolerance applied only to the Richardson-converged solution.
* **Convergence evidence (measured, not assumed):**
  – u: max |Δ| fine↔mid = 9.0e-4…1.24e-3 over the four instants; mid↔coarse up to 1.9e-3 → shrinking; Richardson correction on u ≤ 4.1e-4.
  – θ: in smooth intervals (|x−x_f|>0.05): fine↔mid ≤ 6e-3 (e.g. 0.0018@x=0.05, 0.0002@0.10, t=0.25); inside ±0.03 of the true jump the pointwise L∞ difference does **not** shrink (0.204 vs 0.207) — the expected non-uniform convergence of ANY nodal field at a discontinuity (Gibbs); reported as-is, not hidden.
  – σ: same front-band behavior (Δ ≈ 0.73–0.87 at the jump zone); smooth zone ≤ 2e-2.
  – Richardson correction |R−fine| away from fronts: θ ≤ 1e-3; its front-band values (up to 6.8e-2 for θ, 2.7e-1 for σ) show extrapolation amplifies jump-zone noise — front-zone numbers in this report are therefore explicitly labeled as scheme-signature-dominated.
* **Independent verification of the driver:** at (NE=100, Δt=0.0025) the driver's state vector matches the previously validated pilot state to **4.7e-11** (max over all 404 DOFs); node-gather exactness guard PASSES; the pilot profile cross-check (θ(0.25)=0.3975, u(0.25)=0.0498) reproduces the pilot's own saved profile to 4 decimals.

## 3. COMPARISON PROCEDURE (frozen before evaluation)

Evaluate our continuous FE field (θ, u from Hermite elements; σ = du/dx − θ from the same elements) **at the stored target nodes**; targets never resampled. Denominator for rel L∞ = max|target| over in-domain nodes (curve-normalized). Trapezoidal rel L2 on the target grid. Target nodes outside [0,1] (sub-pixel plot-edge artifacts) excluded and counted. Gate set excludes nodes within ±0.001 (one published element) of the a-priori front x_f = t̃ (t̃≤1) or 2−t̃ (t̃=1.25) — resolution-based §4.5 justification, declared before running; raw and wider-band (±0.002/0.004) values also reported. σ split: pointwise relative only where |target| ≥ 0.0644 (= 4·ỹ-unc); near-zero region reported in absolute units only.

## 4. THE 12 COMPARISONS (frozen gate: ≤ 2% rel L∞, curve-normalized, gate set)

| comparison | nG | abs L∞ | **rel L∞ %** | rel L2 % | x̃@max | tgt@max | FEM@max | raw rel % | ±0.002 / ±0.004 band | ≤1-unc nodes | gate |
|---|---|---|---|---|---|---|---|---|---|---|---|
| θ̃ 0.25 | 497 | 0.3889 | **39.27** | 6.48 | 0.221 | 0.6786 | 1.0675 | 39.27 | 39.27 / 39.27 | 79% | FAIL |
| θ̃ 0.50 | 380 | 0.3294 | **33.30** | 5.12 | 0.444 | 0.6229 | 0.9524 | 33.30 | 33.30 / 33.30 | 33% | FAIL |
| θ̃ 0.75 | 487 | 0.3206 | **32.71** | 4.65 | 0.668 | 0.5506 | 0.8712 | 32.71 | 32.71 / 32.71 | 51% | FAIL |
| θ̃ 1.25 | 497 | 0.3063 | **25.16** | 3.57 | 0.886 | 1.0600 | 1.3663 | 25.16 | 25.16 / 25.16 | 42% | FAIL |
| ũ 0.25 | 499 | 0.0089 | **7.59** | 14.67 | 0.280 | 0.0092 | 0.0003 | 7.59 | 7.59 / 7.59 | 86% | FAIL |
| ũ 0.50 | 346 | 0.0104 | **4.47** | 5.57 | 0.558 | 0.0113 | 0.0009 | 4.47 | 4.47 / 4.47 | 48% | FAIL |
| ũ 0.75 | 499 | 0.0112 | **3.28** | 3.35 | 0.838 | 0.0120 | 0.0008 | 3.28 | 3.28 / 3.28 | 46% | FAIL |
| ũ 1.25 | 500 | 0.0127 | **2.33** | 1.46 | 0.883 | −0.1475 | −0.1602 | 2.33 | 2.33 / 2.33 | 89% | FAIL |
| σ̃ 0.25 | 498 | 1.4186 | **67.81** | 27.19 | 0.222 | −0.8370 | +0.5816 | 67.81 | 67.81 / 67.81 | 7% | FAIL |
| σ̃ 0.50 | 450 | 1.3745 | **69.59** | 21.89 | 0.556 | −1.1945 | −2.5691 | 69.59 | 69.59 / 69.59 | 25% | FAIL |
| σ̃ 0.75 | 496 | 1.3372 | **71.53** | 19.74 | 0.834 | −1.1855 | −2.5226 | 71.53 | 71.53 / 71.53 | 25% | FAIL |
| σ̃ 1.25 | 496 | 1.2371 | **75.62** | 17.76 | 0.607 | −0.9746 | −2.2117 | 75.62 | 75.62 / 75.62 | 19% | FAIL |

**Gate result: 0/12 ≤ 2%.** (1–3 out-of-domain nodes excluded per comparison; 0–2 gate nodes excluded inside the ±0.001 band.)

**σ̃ region split (directive 3):**

| σ̃ | resolved n | curve-rel % (resolved zone) | max pointwise-rel % | near-zero n | abs L∞ | ×ỹ-unc | mean abs |
|---|---|---|---|---|---|---|---|
| 0.25 | 41 | 67.81 | 225.9 | 458 | 0.1649 | 10.2 | 0.0211 |
| 0.50 | 136 | 69.59 | 384.9 | 315 | 0.2358 | 14.6 | 0.0257 |
| 0.75 | 156 | 71.53 | 427.2 | 342 | 0.2143 | 13.3 | 0.0248 |
| 1.25 | 277 | 75.62 | 366.0 | 221 | 0.3196 | 19.8 | 0.0265 |

Near-zero σ differences of 0.16–0.32 (10–20× ỹ-unc) are dominated by our jump-zone shoulder oscillation and the published curve's own −0.019 baseline; no percentage was computed there (per directive).

**Peaks:** θ̃(0.25) our 1.0675@0.221 vs tgt 0.9903@0.009 (jump shoulder, see §5); ũ peak our −0.1194@0.001 vs tgt −0.1173@0.010 (**1.8%**); ũ(1.25) our −0.5399 vs tgt −0.5427 (**0.5%**); σ̃ plunge-node agreement at the front (e.g. t=0.25: ours −2.0719 vs target −2.0826 at x̃=0.25 = **0.5%**).

## 5. DIAGNOSIS OF THE DISAGREEMENT (directive 6 — run before any status; nothing tuned)

**5.1 Where the errors live.** Every gate-exceeding point at |x−x_f|>0.05 traces to one of three structures:
1. **Jump-shoulder oscillation (both curves).** The IBVP has a true discontinuity propagating on x̃=t̃ (reflected to x̃=2−t̃ after t̃=1). The published curve carries a strong *undershoot* into the plunge (θ̃@0.25: 0.679 at x̃=0.222 vs its own decay line ≈0.89); our converged curve carries a *Gibbs overshoot* (1.00–1.07 there). Two different dispersive signatures at an unresolvable jump produce 0.3–1.4 absolute differences — while at the plunge nodes themselves the two curves **agree to 0.0002 (θ̃@0.25) and 0.5% (σ̃ spike)**. The transition zone is ~0.05–0.14 wide (far beyond any element-width exclusion), and its shape is scheme-specific by construction.
2. **Extraction baseline offsets at the level of ±(1–1.2)× ỹ-uncertainty** (u tail +0.0048, σ tail −0.019, θ tail +0.0047 — sub-pixel plotting baselines certified in the package audit). For u, whose peak is only 0.117 at t̃=0.25, a 0.0048–0.0089 tail difference *alone* is 4–8% of the curve norm: the t̃≤0.75 u gate exceedances are at the 1.8–2.3× ỹ-unc level — sub-two-pixel, mixing the published curve's baseline offset with its front-side kink; the t̃=1.25 u maximum (2.6×unc) sits at the wall corner below.
3. **Front–boundary corner events.** The most consequential structured disagreement is at the corner (x̃=1, t̃=1) where the front passes the insulated wall and the reflected θ̃-peak forms: at t̃=1.25 our converged post-reflection peak is 1.366 near x̃=0.89 vs the published 1.218 (@x̃≈0.93) — peak *location* agrees to ≤0.04, *amplitude* differs by ~12%, and the same corner drives the σ̃ t̃=1.25 maximum at x̃=0.607 and the ũ one at 0.883. This is a second singular event (front×boundary interaction) where the two discretizations leave different pointwise signatures; at that location our adjacent-level difference ratio (0.0206 mid↔coarse vs 0.0057 fine↔mid at x̃=1, ratio 3.6) indicates OUR value is near its converged limit while the published value carries the dissipation/dispersion of a 1000-element, CFL≈1 linear scheme — i.e. evidence that the published curve is under-resolved there, but that adjudication belongs to V5, not to this gate.
4. **Our boundary-corner nodal σ (x̃≲0.01):** the sudden step at the incompatible traction-free corner gives a level-oscillating nodal value (σ(0.001): −0.089/0.116/0.024/0.063 at NE=512/1024/2048/1000). Pointwise L∞ at a singular corner is the least favorable norm; flagged honestly, not corrected.

**5.2 Control experiment (resolution attribution).** Running the **same solver at the paper's own stated discretization (1000 elements / 1250 steps)** does NOT reproduce the published curves' front zone either: rel L∞ remains 2.05–46% (vs 2.3–75.6% for R), and even the control differs from the published curve by ~15–37% at t̃=0.25–0.75 away from the front. Conclusion: the published front/transient structure is specific to *their* discretization (linear elements at CFL≈1); it is not an IBVP-level property any independent code can be expected to reproduce pointwise, and matching it would require adopting their scheme — outside V3's mandate.

**5.3 What the benchmark DID confirm (physics-level agreement).**
* Front positions and arrival: |x̃_f^ours − t̃| ≤ 3.2e-3 across fields (front-50% crossings).
* Jump amplitude at the plunge node: θ̃ 0.3951 vs 0.3953 (t̃=0.25); σ̃ −2.072 vs −2.083 (0.5%).
* Smooth decay of θ̃: our R matches the published slope (−0.474 vs −0.49/unit) and value within 0.008–0.014 (≈1.0–1.4%) across 0 ≤ x̃ ≤ 0.2 at t̃=0.25 and across the whole domain at t̃=1.25 to ≤1.1% except the reflected-jump complex.
* ũ peak amplitudes: 1.8% (t̃=0.25) and 0.5% (t̃=1.25); 0.0–0.1% at 0.50/0.75.
* Both wavefronts cross x̃=1 at t̃=1 (Blueprint K.6 self-check) — confirmed in our field and in the published curve's structure.

**5.4 What is ruled in/out as causes.**
* **Ruled out (ours):** model/operator/assembly — V1 spatial-order and V2 temporal-order gates verify this exact operator and scheme; driver state ≡ validated pilot state to 4.7e-11; quadrature guard passes; BC pins hold (θ(0)≡1.0000, u(1)≡0.0000 exactly); no instability (relres ~1e-22, no NaN, CFL ≤ 0.32).
* **Ruled out (targets):** extraction integrity — the package passed the independent read-only audit (tick residuals ≤0.13 px, [26] separation, uniqueness, time assignment); no target was modified here.
* **Ruled in:** (i) pointwise-L∞-at-a-discontinuity non-robustness of BOTH curves (dominant for θ̃ and σ̃), (ii) sub-pixel extraction offsets (dominant for ũ), (iii) our corner-node σ oscillation (local, x̃≲0.01).
* **Not pursued (would be tuning):** ramping the step, artificial damping, mesh/Δt chosen to imitate the published oscillation, shifting/clipping targets, or redefining the band after seeing results.

## 6. GATE APPLICATION

Frozen criterion (Blueprint §4.5, provisional-fixed at ≤2%): measured on the Richardson-converged solution, curve-normalized relative L∞, exactly as pre-declared in §3: **0/12 comparisons ≤ 2%** → the criterion **fails**. Per Blueprint line: "the failure is reported, not masked." No tolerance, criterion, band definition, parameter, or target was altered to change that verdict.

## 7. PROCESS INTEGRITY NOTES

* One defect was found **during setup of this run**: the new driver's FE-evaluator used an element-contiguous DOF gather, while the global layout is node-interleaved (θ sits between the u-dofs of successive nodes). It was caught by cross-checking the driver state against the saved pilot state, fixed by adding a permanent node-gather exactness guard + pilot-profile cross-check (both printed at every run), and **no gate decision had been issued under the defective evaluator** (its output was nonsense ~4000 and was discarded as such). The solver itself was never modified.
* All target/protected artifacts verified unchanged at run time: `v3_extract_targets.py` md5 385ee62d…, `v3_targets_fem.json` md5 abe150d5…, 12 CSVs md5 set 53e03ca9… (aggregate), **Blueprint md5 `00e200c117fe627c5a19a3492499e875`** (recorded post-amendment value) — confirmed after this run.

## 8. DELIVERABLES

* `PHASE1_V3_REPORT.md` (this file)
* `verification/V3/v3_results.json` — machine-readable results of all 12 comparisons (metrics, band splits, σ regions, peaks/fronts, self-convergence, gate flags)
* `verification/V3/v3_fem_ls.py` — reproducible V3 comparison (solver + metrics; rerun: `python3 verification/V3/v3_fem_ls.py`)
* `verification/V3/v3_diagnose.py` + `v3_diagnostics.json` — control-run/band diagnostics of §5
* `verification/V3/v3_run_manifest.json` — audit/provenance record (per-file target sha256, solver config, library versions, wall time, "no target modification" attestation)

## 9. DECISION ITEMS FOR THE OWNER (not executed — none is within this task's authority)

1. V5 (in-house C⁰ reference of the same IBVP, ≤1%) is the Blueprint's load-bearing internal cross-check and is unaffected by the published-curve front issue; it is the natural next gate-relevant run **if authorized**.
2. Whether the external metric should, per §4.5's own "source's published resolution" rationale, be re-fixed at some larger documented shock-zone exclusion is an **owner/criterion decision**, not permitted here — and would in any case still be dominated by structure 5.1(1) at its measured amplitude.
3. Per Blueprint Section V: "If any gate fails, the paper is downgraded, not written" — V3's failure path belongs to that decision framework.

---

**STATUS: V3 FAIL** — the frozen ≤2% relative-L∞ criterion is not met (0/12), and the failure is fully diagnosed above: it is the pointwise-comparison-at-a-propagating-discontinuity signature (opposite front-shoulder oscillations of the two schemes, plus sub-pixel extraction offsets and a singular corner node), not a demonstrable model or implementation error — our smooth-region reproduction of the published benchmark is 0.5–1.8% (peaks) and ≤1.4% (θ̃ decay). Stopping here per directive: no parameter/mesh/BC/target/criterion tuning, no solver modification, no V4.
