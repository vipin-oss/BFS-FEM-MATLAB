# PRE-FREEZE AUDIT — Record & Amendments
### Five-issue final audit of `Blueprint_Complete_MGT_BFS-FEM.md`
**Date:** 2026-09-25 · **Scope:** the five mandated issues only. Direction unchanged. No production runs, no code, no full-model derivation, no automatic freeze.

---

## A. ISSUES FOUND (all five audits, itemized)

### Issue 1 — Priority/novelty claims — **FOUND & FIXED**
- Unsupportable-at-blueprint-stage claims found: "first in the literature" (H.1), "first single-code demonstration" (H.2), "First reproducible … dataset" (H.4), plus the "No C¹ … exists"/"never been targeted"/"no … dataset exists" gap statements in E and in reviewer-objection Q.1.
- **Fix:** every such claim converted to **provisional wording** — "*proposed as a first-in-literature contribution; to be established by systematic literature review (Phase 1)*" (H, E, Q.1, one-paragraph summary). Ambition unchanged.

### Issue 2 — Validation tolerances — **FOUND & FIXED**
- The 1%/2%/5% bands were presented as fixed standards; worst instance: "2% is the code-to-code level the author's paper-9 workflow already locks" (ValFeas §4.5) — a prior-workflow citation used as scientific justification, which is **not** valid.
- **Fix:** 1% and 2% re-labeled **PROVISIONAL — to be fixed after Phase 1–3 convergence/error characterization**; their *directional* basis restated (agreement of two Richardson-converged discretizations) but no standard claimed; the paper-9 reference deleted. 5% retains a real pre-execution basis (source axis-tick coarseness ⇒ ±3–5% extraction uncertainty) but is hardened only after digitization is executed. Blueprint K.11 and ValFeas §4.5 updated in agreement; Phase obligation recorded.

### Issue 3 — Parameter-point logic — **FOUND & FIXED**
- Two category errors existed: (a) model-reduction limits (MGT→LS/GN-III/CTE, §4.7) were treated as "additional parameter points" along external validation; (b) ValFeas §4.6/4.7 & blueprint K/V described an in-house perturbation without labeling it as sensitivity.
- **Fix:** sharp four-way classification adopted and enforced: **external validation** (published targets only: V3 primary; V4 corroborative; optional V8/V9), **internal model-reduction verification** (CTE limit, MGT→LS identity, GN-III steady state — probes our ladder, not the benchmark), **convergence verification** (V1/V2/JV), **parameter sensitivity/robustness** (ramp-rise-time, ξ/t̃₀ perturbations, run **only** against our C⁰ reference, labeled as such). Blueprint K.13 rewritten; §4.7 rewritten; no invented external parameter points remain.

### Issue 4 — V4/Bagri digitization gate — **FOUND & FIXED**
- V4 (digitized Bagri "[26]" series) was listed mandatory in the hard gate (G3 = V3+v4+V5…). Audit confirms it should **not** gate submission: the primary published IBVP + the published Nikolarakis numerical solution (V3) already give an independent, reproducible benchmark; the Bagri series is the *same* IBVP derived by digitization and therefore corroborative-only.
- **Fix:** **V4 = supporting/corroborative, not a submission gate.** Scientific reason recorded: no submission should depend on digitization (which carries legend/axis/L̃-identity fragility) when the underlying IBVP + an independent published solution exist. Mandatory set revised to **{V1, V2, V3, V5, V6}**; V4 still recommended in Phase 3, downgraded (never fabricated) if digitization is unusable.

### Issue 5 — C¹/BFS scientific justification — **FOUND & FIXED**
- Blueprint had an over-strong C¹ justification (including "makes the stiffness assembly exact") implying near-necessity.
- **Fix (J.1 rewritten as an A–E decomposition):**
  - **A — mathematical necessity of C¹: NO.** C⁰ conforming Galerkin is mathematically sufficient (Bazarra et al. 2022 used it); this honesty is itself part of the paper's value.
  - **B — higher-order approximation advantage:** design intent (O(h³) vs O(h)), to be measured.
  - **C — wavefront accuracy advantage: PROVISIONAL hypothesis**, tested by J.4.
  - **D — efficiency/DOF advantage: PROVISIONAL**, reported as error-vs-DOF curves.
  - **E — C⁰ sufficiency: YES** (per A); a C⁰ reference (linear + quadratic) is a hard companion.
  - **Fallback stated:** if C¹ shows no advantage, paper still stands on correctness/completeness contribution + benchmark-ladder reproduction, **without** superiority claims.

### Issue 6 — Consistency cleaning (collateral, from the five audits) — **FOUND & FIXED**
- Blueprint §J.3 verification suite used labels V1–V6 that collide with the validation-package labels V1–V10 → renumbered **JV1–JV6** (with JV5 ≡ V10), and every cross-reference updated (§K.12, §T·G2a, §N, Q.3, U).
- Stale "ramp-rise used by the benchmark itself" line corrected to Heaviside-step (the source's actual BC).

---

## B. CORRECTIONS APPLIED (file map)

| File | What changed |
|---|---|
| `Research_Blueprint_MGT_Thermoelasticity_BFS-FEM.md` | H (provisional novelty), E (provisional gap), J.1 (A–E justification), J.2/J (step BC), J.3→JV renumber + cross-refs, K.11 (provisional tolerances), K.13 (re-classification), T (revised package/gates), V (revised GO), Q.1/Q.3, B (external-evidence wording), one-paragraph summary |
| `VALIDATION_FEASIBILITY_AUDIT.md` | §4.5 (provisional tolerances, paper-9 ref removed), §4.7 (re-classification), §5 (V4 downgrade + why + revised mandatory set), §6 stop-conditions aligned, §7 consistency note, amendment list + final decision text |
| `SOURCE_LOCK_AUDIT.md` | §7 acceptance-tolerance cell aligned (V4 supporting; 2% provisional) |
| `Blueprint_Complete_MGT_BFS-FEM.md` | **regenerated from the three sources above** — identical content, single file |

---

## C. REVISED WORDING OF CHANGED CLAIMS (exact)

**Novelty (H.1):** "C¹-conforming BFS finite elements for MGT thermoelasticity — *proposed as a first-in-literature contribution; to be established by systematic literature review (Phase 1).*"

**Novelty (H.2):** "Unified CTE/LS/GN-II/GN-III/MGT reduction demonstrated in one code … — *proposed as a first single-code demonstration; to be established by systematic literature review (Phase 1).*"

**Novelty (H.4):** "A reproducible (script-regenerable) MGT transient dataset with full time history … *Proposed as a first such dataset; to be established by systematic literature review (Phase 1).*"

**Gap (E, representative):** "No C¹-conforming spatial discretization for MGT thermoelasticity has been found to date — *to be established by systematic literature review.*"

**Tolerance (K.11/§4.5, representative):** the 1%/2% bands are "**PROVISIONAL — to be fixed after convergence/error characterization**" with directional basis stated; the prior-workflow citation removed; 5% is a source-resolution band hardened after digitization execution.

**Validation hierarchy (K.13/§4.7, representative):** "External validation = published targets only … Model-reduction limits and parameter sweeps count as verification/sensitivity, **not** as additional external-validation points."

**C¹ justification (J.1):** "**(A) Mathematical necessity of C¹ continuity — NO … C¹ is not required for well-posedness … (E) C⁰ sufficiency — YES …** if C¹ shows no advantage the paper stands on correctness/completeness + benchmark-ladder reproduction, without any superiority claim."

---

## D. REVISED MANDATORY / SUPPORTING VALIDATION HIERARCHY

| Tier | Items | Gate |
|---|---|---|
| **Mandatory — convergence/verification** | V1 (manufactured, JV1), V2 (time order, JV2) | G2a |
| **Mandatory — external validation** | **V3** — LS benchmark vs published Nikolarakis FEM (12 comparisons, 4 instants × 3 fields) | **G3** |
| **Mandatory — internal cross-validation** | **V5** — C¹ vs in-house C⁰ reference on the same IBVP (≤ provisional 1%) | **G3** |
| **Mandatory — model-reduction identity** | **V6** — MGT→LS (κ̂→0) machine-exact | G3/G4a |
| **Supporting/corroborative** | **V4** (digitized Bagri series, ≤5% digitization band), V7 (CTE limit), V7b (GN-III steady state), V10/JV5 (elastic dispersion), V8 (Boley–Tolins, optional), V9 (Bazarra, optional) | never a submission gate |

---

## E. REVISED GO/NO-GO STATUS

**GO — CONDITIONAL (BLUEPRINT READY FOR EXECUTION).**

The direction is feasible and the external validation chain is executable (obtained open-access benchmark + model-reduction identities), the scientific posture is now non-presumptive (provisional novelty claims, provisional tolerances, C¹ as tested hypothesis), and the validation gate is clean (external published benchmark + internal cross-validation + model-reduction identity; digitization and internal limits are explicitly non-gating).

**Conditions that remain (all Phase-1–3 tasks, none a freeze blocker):** Phase-1 literature review converts provisional priority/gap claims to firm (or withdrawn) manuscript statements; Phase-1–3 convergence/error characterization fixes the provisional 1%/2% tolerances; V4 is executed but never gates submission.

**Freeze status:** **not applied automatically** — awaiting your explicit instruction.

---

## F. FINAL STATEMENT

**All five mandated audits are genuinely closed** (issues found, fixed, and recorded above with exact wording). On the standing instruction that a freeze requires your authorization, the blueprint **has not been frozen**; it is

## “FINAL — BLUEPRINT READY FOR EXECUTION”

subject only to your explicit freeze instruction and to the Phase-1–3 conditions recorded in Section E (provisional→fixed tolerance conversion and literature-review confirmation of the provisional novelty/gap claims — both execution-phase tasks, not pre-freeze blockers).
