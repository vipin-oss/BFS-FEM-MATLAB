# RESEARCH BLUEPRINT
### A C¹ Finite‑Element Method for Transient Moore–Gibson–Thompson (MGT) Thermoelasticity, with Unified Reduction to CTE / LS / GN‑III and Reproduced Published Benchmarks

**Target journal:** *International Journal of Numerical Methods for Heat & Fluid Flow* (Emerald)
**Intended scientific bar:** *International Journal of Heat and Mass Transfer*–calibre verification/validation rigor
**Prepared:** 2026‑09‑25
**Status:** BLUEPRINT — for approval before execution. **OPEN** items are flagged and itemized in Section U.

---

## A. PORTFOLIO ANALYSIS

**Source reviewed:** `Vipin_Research_Papers_06-Aug_2026.xlsx` (48 rows; 2022–2026; SCI/Scopus/WOS). Bibliographic use only — no paper PDFs were supplied in this task, so all portfolio statements below are based on titles, journals and DOIs, not on the internal derivations of those papers. Nothing below assumes I can read an old paper's equations.

### A.1 Established themes (frequency across the 48 titles)

| Theme | Count | Representative works |
|---|---|---|
| Plane-wave reflection/transmission & **energy ratios at interfaces** | ~26 | #2, #4, #6, #7, #9, #10, #11, #16, #17, #18, #32, #35… |
| **Memory-dependent derivative (MDD)** heat conduction | ~14 | #2, #7, #12, #13, #17, #21, #22, #23, #26, #37, #45… |
| **Fractional / fractional-MGT / higher-order** derivative models | ~10 | #13, #19, #21, #22, #23, #26, #28, #30, #36, #48… |
| **Piezo- / photo- / semiconductor / hygro-** multiphysics | ~16 | #12, #13, #17, #19, #21, #26, #29, #34, #37, #40, #42, #45, #48… |
| **Double porosity / voids / liquid-saturated** | ~10 | #1, #3, #4, #8, #20, #24, #25, #32, #33… |
| **Nonlocality (Eringen / strain-gradient / Klein–Gordon nonlocal)** | ~10 | #3, #10, #14, #17, #26, #35, #44, #45, #48… |
| **MGT (Moore–Gibson–Thompson)** | ~8 | #12, #17, #21, #26, #34, #35, #37, #43 |
| Functionally graded / layered waveguides / moving-load dynamics | ~8 | #25, #29, #31, #38, #39, #40, #42, #46 |

### A.2 Methods and theories used repeatedly
1. **Normal-mode / plane-wave analysis** as the near-universal skeleton: assume `exp[i(kx−ωt)]`, substitute, get a secular equation, solve for wave speeds/attenuation, then compute **amplitude ratios and energy ratios** (energy-balance check = "sum of ratios = 1") at interfaces.
2. **MDD, fractional (Caputo/Rabotnov kernel), higher-order memory** grafted onto LS/MGT heat conduction.
3. **Two-temperature / hyperbolic two-temperature** variants.
4. **Nested model hierarchies** (LS ⊂ MGT ⊂ higher-order) exploited to *plot* the effect of each extra parameter.
5. Validation in the portfolio sense is overwhelmingly **self-consistency** (energy-balance = 1; limiting-case overlap between two of the author's own curves) — not reproduction of external numerical benchmarks.

### A.3 Material/model classes already studied
Rotating/micropolar/pre-stressed thermoelastic solids; double-porous and liquid-saturated solids; orthotropic/monoclinic piezo‑, photo‑, flexo‑, magneto‑, semiconductor media; voids; functionally graded and layered waveguides; nano-beams/plates; irregular/fractured seabed.

### A.4 Wave/heat-transfer features already present
P/SV/SH and quasi- waves; Rayleigh and surface waves; reflection/refraction; dispersion and damping; rotation; initial stress; porosity; memory/fractional heat lag; photo-carrier diffusion; hygrothermal diffusion.

### A.5 Areas where a new paper would be *merely incremental* (reject on sight)
- Any "old model + one new effect + same secular-equation + same energy-ratio plots" recipe (an explicit instruction in Part 13, and the dominant pattern in A.1–A.2).
- "MGT + one more fractional parameter" — already done (#13, #19, #21, #22, #23, #26, #48).
- "MGT + voids / rotation / initial stress / double porosity" — already done (#17, #33, #34, #35, #43…).
- Any title-level rearrangement of an existing energy-ratio paper.

### A.6 Areas where a *genuinely stronger* extension is possible (the gap)
The portfolio is, without exception, **frequency-domain wave kinematics**. What is **completely absent** is:
1. **Any time-domain, initial-boundary-value (transient) computation** — with the sole exception of a first "spherical cavity" dynamic-response paper (#43), still transform-based.
2. **Any genuine volumetric numerical PDE solution (FEM/FVM/spectral)** in the entire portfolio.
3. **Any external, published-benchmark validation** (all checks are internal energy-balance).
4. **Any hyperbolic MGT thermoelasticity solved by a spatial discretization with provable accuracy** — the only rigorous FEM for MGT thermoelasticity in existence (Bazarra et al., *J. Comput. Appl. Math.*, 2022) is **1-D** and uses **linear elements + first-order**(in time) implicit Euler.

This room — *numerical method for MGT thermoelasticity in space+time, with formal verification and external validation* — is where a new, defensible contribution actually lives. It also happens to be the *"Numerical Methods for Heat & Fluid Flow"* niche: **"Numerical Methods" is in the journal's name**, and the portfolio has never delivered one.

### A.7 Which previous papers are the methodological foundations
- **#12, #13, #17, #21, #26, #34, #37** (MGT + MDD/fractional): credibility to frame a rigorous MGT study; authors' own MGT modelling is established precedent.
- **#39/#42** (SH-wave/dynamic response with interfacial discontinuity, *Appl. Math. Modelling*): closest in style to a computed dynamic response.
- **#48** (dispersion + damping of Rayleigh-type waves in fractional piezo-thermo-electric): the *dispersion* anchor for the elastic-above-MGT crosscheck (F).

### A.8 Which papers are reusable validation strategies
None contain an *external* benchmark. They do, however, provide the **in-house convergence targets and the elastic/Rayleigh dispersion anchors** used in Verification Suite V (Section J.3).

### A.9 Directions too close to existing publications (novelty-weak)
Everything in A.5, plus: finite/transformed "half-space under moving loads" MGT analytics (already the subject of the 2025 *International Communications in Heat and Mass Transfer* paper found in the literature scan and of #43/#46-type works). Any of these would be a recipe change, not a method change.

### A.10 Known companion constraint (avoids an internal collision)
The author's own GitHub (`BFS-FEM-MATLAB/paper9`) already contains a **locked blueprint for a *strain-gradient* phononic band-gap paper** using **bicubic BFS/Bogner–Fox–Schmit C¹ elements**, whose scope **explicitly excludes** thermal coupling, fractional/memory models and transients, and which targets *Int. J. Mechanical Sciences*. The blueprint below deliberately shares only the *element technology* (BFS C¹), not the physics: **thermal coupling, transient loads, MGT/LS/GN-III model reductions, and published-benchmark validation are the differentiators.** This is an intentional, citable synergy, not a duplication.

---

## B. TARGET JOURNAL AND QUALITY BAR

*International Journal of Numerical Methods for Heat & Fluid Flow* (HFF) positioning, and the specific HFF fit of this proposal:

1. **"Numerical Methods" is the journal's core mandate** — the portfolio has *five* HFF papers (10.1108/hff‑04‑2023‑0208; 10.1108/hff‑11‑2022‑0654; 10.1108/hff‑04‑2022‑0259; 10.1108/hff‑10‑2023‑0615; 10.1108/hff‑07‑2023‑0380, and 2025–26 additions #31, #34, #35, #48) and — from their titles — not one contributes a computational method. A method paper fills the author's own journal-shaped gap.
2. Heat-transfer relevance is direct (hyperbolic heat conduction; second sound; thermal shock).
3. The paper will carry verification (manufactured solutions, convergence) and validation (reproduced literature) at the level HFF reviewers and IJHMT reviewers expect.
4. Every claimed number will be reproducible from version-controlled scripts with recorded environments (Part 10 requirement).

**Demonstrating the bar (not asserting it):** the proposal reaches the Q1 standard only if the four **Sections N–O gates** pass — (i) manufactured-solution convergence with computed order of accuracy matching theory; (ii) exact travelling-wave reproduction; (iii) *external* benchmark reproduction within the tolerance in K.11/K§4.5, evaluated at **the four published instants × three fields (12 comparisons)** — the external-evidence floor, with any additional parameter points classified per K.13/§4.7 (sensitivity vs. corroboration); and (iv) a parameter sweep with physically interpretable, energy-consistent results. If any gate fails, the paper is *downgraded, not written* (Section V).

---

## C. VALIDATION-FIRST FILTER (applied before selecting the direction)

The filter was applied to every candidate. Two benchmark pathways were checked for hard availability:

1. **Path M (model-reduction to a published transverse model)** — the historical check case for generalized-thermoelasticity codes:
   - Sternberg & Chakravorty (1959) → classical (Fourier) coupled thermoelasticity half-space (Danilovskaya-type);
   - Boley & Tolins (1962), *J. Appl. Mech.* 29:637–646, step temperature on the coupled half-space — "curves in convenient form for program testing";
   - Bagri, Taheri, Eslami & Fariborz (2006), *J. Thermal Stresses* 29(4):359–370, "Generalized coupled thermoelasticity of a layer," DOI 10.1080/01495730500360492 — **generalized (LS) finite layer, thermal shock, Laplace-domain analytic + numerical inversion**, referenced by Nikolarakis & Theotokoglou (2018, DOI 10.1155/2018/7371016) *exactly as a code-verification benchmark*;
   - Nikolarakis & Theotokoglou (2018), open-access Hindawi/Wiley, **MATLAB FEM (Newmark), 1000 linear elements, 1250 steps**, homogeneous case reproduces Bagri et al. — this paper is **obtainable in full**, states its own discretization, and provides numerically reproducible target curves.
2. **Path Q (parameter-reduction to quintessential published results)**:
   - Quintanilla (2019), *Math. Mech. Solids* 24:4020–4031, 10.1177/1081286519862007 — MGT=GN-III+Lag; LS, GN-III, GN-II, CTE as exact sub-models (confirmed by multiple independent secondary sources listing the reduction table);
   - Bazarra, Fernández & Quintanilla (2022), *J. Comput. Appl. Math.* 409:114181, DOI 10.1016/j.cam.2022.114181 — **the only a-priori-error FEM for MGT thermoelasticity** (1-D, linear elements, implicit Euler); provides the "method gap" anchor and a 1-D cross-check target (primary role is *gap documentation*; its published figures, if only figures, would be digitized as a secondary cross-check marked as such).

**Outcome:** both published sets of target *equations* are reducible from the proposed model; the **open-access** Nikolarakis–Theotokoglou paper provides a whole-paper reproducible external target for the LS case; Path Q provides the MGT/GN-III ping-points. The three *external* validation layers (K) all rest on obtainable published units. **The filter passes.** The only genuinely PROPRIETARY items are the *Springer/Elsevier paywalled figures*, handled in K.11/U.

---

## D. CANDIDATE DIRECTIONS (generated from the portfolio)

### Candidate D1 — "MGT reflection/transmission at a piezo-semiconductor interface with memory-dependent derivative" (portfolio-extension style)
1/2/3/… — **Eliminated.** This is the author's dominant *existing* pattern (title-level parameter addition; energy-ratio plots; internal-only validation). Fails Part 12 and Part 13 outright. No methodological contribution.

### Candidate D2 — "Fractional-MGT photo-thermoelastic Rayleigh wave in a rotated voided medium"
**Eliminated.** Same failure as D1: novelty is one more parameter/local effect in a Fourier-domain secular equation. The screening found no obtainable external benchmark for the photo/void couplings, so validation would collapse to self-consistency. Violates the hard filter (Part 3).

### Candidate D3 — "IGA/B-spline planar FEM for 2-D transient memory-dependent dual-phase-lag thermoelasticity"
**Eliminated in the shortlist.** Attractive *methodology* (higher-order smooth basis, 2-D transient), but **validation-fatal**: MDD/DPL benchmark data consists of transform-inverted, non-reproducible or paywalled figures only; no open, reproducible external target exists. Risky time-integration blends (delay + higher-order terms) with no cross-checkable anchor means the "can you actually validate it?" question answers *no*. Per the instruction, a direction whose validation depends on unavailable/reconstructable-uncertain data is rejected regardless of method elegance.

### Candidate D4 — "C¹ (BFS) FEM for the **Moore-Gibson-Thompson thermoelasticity** of a finite domain: manufactured-solution verification + thermal-shock validation + GN-III→MGT closure" *(SELECTED — see E)*
**Survived screening.** Reasons (positive, concrete):
- The governing model (Quintanilla 2019 MGT) is *newer and less stiff to discretize* than MDD/DPL: it is a **third-order-in-time PDE with a precisely known reduction ladder** (CTE/LS/GN-II/GN-III), giving an *exact* cross-check ladder to published classical/LS results — the single most important property for the validation-first filter.
- Only **one** prior FEM exists for MGT thermoelasticity (Bazarra et al. 2022, 1-D linear elements, first-order-in-time), so a **C¹ spatial discretization with provable order is a real gap**, not a re-labelling.
- The BFS element is **already the author's own tool** (BFS-FEM-MATLAB), which makes the numerical-method claim credible and executable, *without* being the same physics as the pending strain-gradient paper.
- Validation is *external and obtainable* (K.1/K.2/K.3), at three distinct points in parameter space, plus an independent elastic-wave cross-check (F).

### Candidate D5 — "FEM for 2-D photo-thermoelastic (semiconductor) coupled plasma-heat-elastic transient"
**Eliminated.** Strongest heat-transfer pedigree in the portfolio, but (a) the plasma-carrier transport adds a stiff advection-like operator with **no openly published, reproducible 2-D transient benchmark**; (b) the author already dominates photo-thermoelastic *wave* papers, so a transient version would still look like "same family + transient"; (c) validation would again be internal-only. Fails the hard filter.

---

## E. FINAL SELECTED RESEARCH DIRECTION & EXACT RESEARCH GAP

**Direction (one sentence):** Develop, verify, and externally validate a **conforming C¹ finite-element method in space** (BFS/Bogner–Fox–Schmit bicubic) **for the transient Moore–Gibson–Thompson thermoelasticity equations**, and use it to (i) reproduce published classical/LS generalized-thermoelasticity thermal-shock benchmarks through exact model reduction, and (ii) produce *first, reproducible, full-history* 1-D/2-D MGT transient solutions including the GN-III→MGT thermal-history-lag effect.

**Exact gap (as it must be written in the Introduction — provisional gap statements, to be confirmed by Phase-1 literature review):**
> Each "no … exists" statement below is the *hypothesized* gap. At Blueprint stage they are held as **provisional gap claims (to be established by systematic literature review in Phase 1)** and only become firm Introduction text once the Phase-1 review documents each absence.
1. MGT thermoelasticity has an exact well-posedness and existence theory (Quintanilla 2019) and a **single** fully-analyzed FEM documented in the screening so far (Bazarra, Fernández, Quintanilla 2022 — 1-D, C⁰ linear elements, implicit Euler, first-order convergence). *No C¹-conforming spatial discretization for MGT thermoelasticity has been found to date — to be established by systematic literature review.*
2. Consequently, *no MGT transient solution with an a-priori accuracy certificate and an externally reproduced benchmark across the CTE/LS/GN-III ladder has been found — to be established by systematic literature review.*
3. The generalized-thermoelasticity literature's standard verification cases (Sternberg–Chakravorty; Boley–Tolins; Bagri et al. 2006; Nikolarakis–Theotokoglou 2018) have — *to be established by review* — not been targeted by a spatial C¹ method; i.e., no published C¹-vs-C⁰ comparison for *thermal* (as opposed to strain-gradient elastic) wavefronts is known at this stage.
4. The published MGT results that do exist are overwhelmingly transform-domain, semi-analytic, and non-reproducible (paywalled figures); *no version-controlled, script-rerunnable MGT transient dataset is known at this stage — to be established by review.*

**Why this clears the novelty tests (Part 12):**
- Not "changing a material." The model (MGT) and the loads (thermal shock) are fixed; the *contribution* is the discretization + the verifiable accuracy + the published-benchmark reproduction + the first rerunnable MGT transient dataset.
- Not "adding one more fractional parameter." *No* fractional or MDD knob is introduced (deliberately — a `C¹∩time-shock` method must be proven clean first).
- The method removes a documented limitation: C⁰ linear elements resolve thermal wavefronts only with heavy refining; a C¹ method is hypothesized (and will be *demonstrated*, not assumed) to capture `θₓ`-driven thermoelastic coupling with higher order and fewer DOF — a measurable accuracy/efficiency claim that Section J.4 tests head-to-head against C⁰.

---

## F. PROPOSED TITLE

**"A conforming C¹ finite-element method for transient Moore–Gibson–Thompson thermoelasticity: verification via manufactured solutions and validation against classical and Lord–Shulman thermal-shock benchmarks"**

Reserve alternatives (editorial, unranked): "High-order C¹-compatible finite elements for hyperbolic (MGT) thermoelastic transients with unified CTE/LS/GN-III reduction"; or, if the 2-D extension is carried through, append "in one and two dimensions."

---

## G. RESEARCH OBJECTIVES

**O1 (Model).** Recast isotropic homogeneous MGT thermoelasticity (Quintanilla 2019 form) in a first-order-in-time state form `Ż = A Z` for the coupled `(displacement u, temperature θ, flux‑memory ψ=θ̇ history)` system, and write its **Galerkin weak form** with an explicit statement of the function spaces (continuity requirements) required by the `ψ`-carrying (third-in-time) energy structure.

**O2 (Method).** Construct the C¹-conf-interconforming BFS bicubic element for the resulting system, with a rigorous interpolation-error and quadrature plan (Section I/J).

**O3 (Verification).** Verify the method by (i) manufactured-solution convergence with **measured order of accuracy** matching theory in space and time; (ii) reproduction of an *exact* travelling thermoelastic wave mode (independent of any literature).

**O4 (Validation — external, hard gate).** Reproduce, with quantified error:
- the **Sternberg–Chakravorty / Boley–Tolins classical coupled half-space** solution (step surface temperature),
- the **Bagri et al. (2006)/Nikolarakis–Theotokoglou (2018) Lord–Shulman layer** thermal-shock results,
- the **GN-III, LS, GN-II, CTE** reductions of the MGT model (exact parameter limits),

each at prescribed non-dimensional input (K), with tolerances in K.11.

**O5 (Innovation).** Produce the **first published, fully rerunnable MGT transient dataset** for a finite 1-D layer (and, if Phase 9 is entered, a 2-D rectangle), documenting the *history-lag* effect of MGT versus GN-III and LS — a physical result of the kind HFF/IJHMT readers can use.

**O6 (Reproducibility).** Ship every number behind a Git tag with a run manifest (parameters, mesh, Δt, environment, hashes), so a reviewer can rerun the exact reported values (Part 10).

---

## H. CORE NOVELTY CLAIMS (audited, and restricted to what the computation will prove)

> **Priority-claim discipline (added at pre-freeze audit):** statements of literary priority ("first …", "no X exists …" are made **provisional at Blueprint stage** — each is marked *(to be established by systematic literature review in Phase 1)* and will be elevated to a firm claim in the manuscript **only** when the Phase-1 review documents the absence case-by-case. The research ambition is unchanged; only unsupported-at-this-stage priority wording is downgraded.)

1. **C¹-conforming BFS finite elements for MGT thermoelasticity** — *proposed as a first-in-literature contribution; to be established by systematic literature review (Phase 1).* Currently supported: only one FEM for MGT thermoelasticity is documented (Bazarra et al. 2022 — 1-D, C⁰-linear, implicit Euler); no C¹ treatment for it has been found in the screening searches to date. *(Novelty of method — provable by literature review, not by results.)*
2. **Unified CTE/LS/GN-II/GN-III/MGT reduction demonstrated in one code** and shown to collapse onto published benchmark solutions — *proposed as a first single-code demonstration; to be established by systematic literature review (Phase 1).*
3. **Measured convergence order** for a hyperbolic coupled thermoelastic system with a third-order-in-time heat law, reported with the same rigor used in strain-gradient C¹ papers. *(This is a verifiability claim, not a priority claim.)*
4. **A reproducible (script-regenerable) MGT transient dataset with full time history**, including the GN-III→MGT lag effect, with quantitative comparison to published data where available. *Proposed as a first such dataset; to be established by systematic literature review (Phase 1).*
5. (Conditional) **Accuracy/efficiency evidence of C¹ vs. C⁰** on thermal-wavefront problems with a documented metric and mesh family — stated as a *testable hypothesis*, not a presupposed superiority (see J.1).

*Explicitly NOT claimed:* any new constitutive physics, any fractional/memory/nonlocal extension, any new analytical solution, or any superiority of C¹ over C⁰ beyond what the convergence/error tables actually show.

---

## I. GOVERNING MATHEMATICAL FRAMEWORK

*(Sketch only, per instructions — no derivation. Written to be turned into equations during execution.)*

**State.** Isotropic homogeneous thermoelastic solid; small strain, linear.
Unknowns: displacement `u(x,t)`, temperature change `θ(x,t)`; additionally the thermal-history/augmenting variable `ψ(x,t)` (≡ the time-history-carrying thermal displacement, with `ψ̇ = θ`) when writing the MGT law in first-order form.

**MGT heat conduction (Quintanilla 2019).** The heat flux constitutive law adds a relaxation/lag to the **Green–Naghdi type III** energy-flux term, yielding a **third-order-in-time energy equation** of the symbolic form
  `a θ̈₊t… + b θ̈ + (GN-III energy-flux terms) + (stiffness-rate terms) = 0`
whose precise coefficients are re-derived in Phase 1 from Quintanilla (2019) and cross-checked against the independent reduction table reproduced by Abouelregal et al., *Materials* 2020, 13:4463 (OPEN — Section U).
**Unified limit ladder (claimed properties to be implemented and *tested*, not asserted):**
- CTE (Biot/Fourier coupled) → obtained in an appropriate limit of the relaxation/lag and rate-coefficient parameters;
- **LS** → MGT with the GN-III rate-coefficient set to zero;
- **GN-III** → MGT with zero lag;
- **GN-II** → rate-coefficient and lag jointly in the non-dissipative limit.
Each limit must be *machine-checked* in Phase 2 (G1b: symbolic substitution in SymPy returning exact equality, plus a dimensional audit).

**Elastic side.** Standard linear-elastic dynamic thermoelasticity (Navier operator + thermoelastic coupling term `−γ θₓ…` in 1-D / the 2-D analogue in plane strain). No porosity, no voids, no piezo terms — deliberately minimal so that *every* term is benchmarked.

**State/first-order form.** Because MGT is third-order-in-time, the state is `Z = (u, u̇, θ, ψ, ψ̇-type block)` (exact set fixed in Phase 1). The resulting first-order system is integrated with a **consistent (Galerkin) time discretization of order p** (`p∈{1,2}`) — explicit statement of which term the time-integration "lumps" and why; the hypoelastic/thermal-state mass matrix singularity is handled by the standard state-form rearrangement, documented, not papered over.

**Non-dimensionalization.** Fixed scheme (identical for FEM and all benchmarks, required for K.7): characteristic length `ℓ*` (layer/half-space penetration length), characteristic speed `c*` (elastic bar-wave speed), characteristic time `t* = ℓ*/c*`, and the non-dimensional groups: coupling coefficient `ε` (thermoelastic coupling), lag/relaxation `τ̂`, and rate-coefficient `κ̂`. Full symbol register in `eqs/` with a **dimensional audit (G1/G1b)**.

**Regularity/continuity requirement (the methodological heart).** The weak form is set up so that the `ψ`-equation's natural space forces the **temperature/flux-history field to be continuous with continuous first derivatives across elements (C¹)**, and the displacement likewise; this is the *stated justification* for BFS elements rather than linear elements. (Phase 1 proves which coupling term drives this requirement; if it turns out C⁰ suffices, the method section is reported honestly with C¹ retained as a higher-order choice — see J.3 note and Section V.)

**Boundary conditions supported.** Prescribed surface temperature or heat flux (thermal shock: Heaviside and ramp-with-rise-time), traction-free or fixed mechanical face, insulated/perturbed opposite face, axial symmetry in 2-D. Perfectly standard so they coincide with the benchmark papers.

---

## J. NUMERICAL METHODOLOGY

### J.1 Method choice and scientific justification (C¹ vs. C⁰ — strengthened, non-presumptive)

The role of C¹ continuity in the MGT problem is *decomposed* so no advantage is assumed:

- **(A) Mathematical necessity of C¹ continuity — NO, not strictly.** The consistent weak form of the MGT thermoelastic state system is a first-order-in-time system whose spatial operators are of second order at most; a **C⁰ conforming Galerkin discretization is mathematically sufficient**, exactly as Bazarra et al. (2022) used in 1-D. C¹ is therefore **not required for well-posedness**; it is a deliberate higher-order choice. *This honesty is itself part of the paper's value: it prevents an oversold "C¹ is required" story.*
- **(B) Higher-order approximation advantage — YES, but as design intent, to be measured.** Cubic-Hermite/BFS elements carry value-and-gradient DOFs and an H¹ error model of O(h³) versus O(h) for C⁰-linear; this is the *hypothesized* advantage and is tested, not asserted (J.3 V1 + J.4).
- **(C) Numerical accuracy / wavefront advantage — PROVISIONAL.** Hypothesis: C¹ captures the `θₓ`-driven thermoelastic coupling and the sharp second-sound wavefront with higher order for a given DOF count, and yields smooth `∂θ̃/∂x̃`, `∂ũ/∂x̃` (hence `σ̃ₓₓ`) recovery directly from the basis without post-processing. The benchmark (a propagating + reflecting thermal/elastic wavefront) is precisely the regime where this should matter; the evidence is the J.4 head-to-head.
- **(D) Computational efficiency / DOF advantage — PROVISIONAL.** C¹ elements use more DOF/element but are hypothesized to need fewer elements for a target error. Reported as error-vs-DOF curves, not assumed.
- **(E) C⁰ sufficiency — YES, C⁰ is mathematically sufficient** (see A); consequently a **C⁰ reference solver (linear and quadratic) is built and is a hard companion**, and the paper's fallback is explicit: **if C¹ shows no demonstrated advantage on the measured metrics, the paper still stands as (i) the first C¹ discretization of MGT thermoelasticity (a completeness/conformity contribution with verified correctness), and (ii) the first reproduction of the classical/LS benchmark ladder by a gradient-capable scheme — without any superiority claim.** The numerical-method contribution therefore does not hinge on C¹ "winning".

**Time: Galerkin/consistent (p=1 backward-difference-type or p=2) time integration on the first-order state form**, with the time-step restriction stated and the a-priori estimate's time order measured in J.3. The shock load is applied as the benchmark's **Heaviside step** by nodal prescription (one-step discrete closure); the benchmark comparison targets the step solution itself (K.4); any ramp-rise regularization is a labeled sensitivity variant only — this is a hard rule.

### J.2 Continuity, interpolation order, formulations, boundary treatment
- **Continuity:** C¹ across element interfaces for the temperature/flux-history (and displacement) DOFs (value + first derivative nodal DOFs in 1-D; value + ∂/∂x, ∂/∂y, ∂²/∂x∂y in 2-D BFS → the 4×4=16-DOF-per-field rectangle).
- **Interpolation order:** cubic (bi-cubic in 2-D); shape functions and derivative cards in `solver/`.
- **Formulation:** Galerkin weak form stated on its C¹ function spaces; after substitution into the first-order state system, element matrices (mass/thermal-state mass, conduction-stiffness with rate-coefficient, thermoelastic coupling, elastic stiffness) are derived in `eqs/` with a **quadrature-order justification** (integrands are low-order polynomials → exact Gauss rules; one rule documented, not varied across runs).
- **Boundary treatment:** essential (temperature) nodes fixed; natural (heat flux / traction) BCs assembled from the weak form; thermal-shock **step H(t̃)** applied by nodal prescription (one-step discrete closure of the step — the publication target is the step itself); any ramp-rise regularization is run *only* as a labeled sensitivity variant, not as the benchmark comparison.
- **2-D:** C¹ Bézier/BFS rectangle patches; plane strain; axial symmetry as the benchmark-reduction geometry if a symmetric reduction is used; otherwise plane-strain full rectangles.

### J.3 Verification suite (JV) — all computed before any benchmark claim
> **Numbering note (pre-freeze audit):** these are the *verification* items, labeled **JV1–JV6** to avoid collision with the *validation* package numbering **V1–V10** used in §K/`VALIDATION_FEASIBILITY_AUDIT.md` §5. Mapping is stated where the two overlap (JV5 ≡ V10; the JV items feed gate G2a).
- **JV1 Manufactured solution (1-D & 2-D):** substitute a smooth manufactured `(u, θ, ψ)` into the strong form, add the residual as source, and measure the L² and H¹ errors vs. the manufactured fields across a mesh refinement sequence. **Pass = measured order ≈ theoretical order (3 for cubic Hermite in H¹; 2 in L² for the state form — exact expectation fixed in Phase 1 and recorded before running).**
- **JV2 Time order:** manufactured evolution; halve Δt; measured order ≈ p.
- **JV3 Exact travelling thermoelastic wave:** for the classical/LS limiting parameters where the linear coupled system admits the textbook plane thermoelastic wave, inject the exact `exp[i(kx−ωt)]` mode on a patch and require reproduction to round-off/`10⁻¹⁰`-scale; catches sign errors in the coupling term.
- **JV4 Patch test:** rigid-body + linear-temperature + constant-gradient states reproduced exactly (zero spurious energy).
- **JV5 Elastic dispersion cross-check (independent of the benchmarks; ≡ V10 of the validation package):** set coupling = 0 and compare the computed bar-mode velocity and the Rayleigh-type surface wave (if 2-D) against the closed-form elastic dispersion the author already computes in portfolio papers (#48 family) — a *different physics* cross-check.
- **JV6 Energy/entropy consistency:** the discrete counterpart of the MGT energy identity is monitored; for the dissipative limits, monotone decay; for GN-II limit, conserved.

### J.4 Accuracy/efficiency comparison (C¹ vs. C⁰) — the hypothesis test
Same problem, same Δt: C¹ BFS vs. C⁰ linear (and C⁰ quadratic) reference elements; report error vs. DOF (or CPU) at a fixed target error. This is the *test* of hypotheses (B)–(D) in J.1 and produces the measurable claim in H.5. **If C¹ shows no demonstrated advantage on the measured metrics, the paper reports the null result honestly and stands on H.1–H.4 (correctness + completeness of a C¹ discretization + the benchmark-ladder reproduction), with no superiority claim.** This is the honest-contingency rule (Section V).

---

## K. VALIDATION ARCHITECTURE

### K.1 Primary benchmark
**Lord–Shulman generalized-thermoelasticity thermal shock of a finite layer** — the canonical test case for generalized-thermoelasticity codes.
**Source (reproducible, obtainable):** A. M. Nikolarakis & E. E. Theotokoglou, "Transient Analysis of a Functionally Graded Ceramic/Metal Layer considering Lord‑Shulman Theory," *Mathematical Problems in Engineering* **2018**, 7371016, DOI 10.1155/2018/7371016 (open access, Hindawi/Wiley). This paper (i) states **its own FEM** (MATLAB, Newmark, 1000 linear elements, 1250 time steps — itself reproducible), and (ii) in its verification section reproduces the classical numerical results of **Bagri, Taheri, Eslami & Fariborz 2006** for a homogeneous layer. So a single open paper chains two independent published datasets.
**Secondary source for the same physics:** Bagri, Taheri, Eslami, Fariborz, "Generalized coupled thermoelasticity of a layer," *J. Thermal Stresses* 29(4):359–370 (2006), DOI 10.1080/01495730500360492 (paywalled — figures through Nikolarakis's reproduction).

### K.2 Classical-limit benchmark (OPTIONAL — additional, non-load-bearing)
**[AUDIT-CORRECTED]** The CTE reduction (B1) is **internally anchored** by taking t̃₀→0 in the *same* Eq. (11) IBVP and cross-checking against our own C⁰ reference solver — no external source required. As an *optional* independent published anchor, **Sternberg & Chakravorty (1959)** and **Boley & Tolins (1962), "Transient coupled thermoelastic boundary value problems in the half-space," J. Appl. Mech. 29:637–646** (DOI 10.1115/1.3640647) — step-temperature coupled (Fourier) half-space, explicitly published "for program testing" — may be added **only if lawfully obtained** (ASME paywalled). Reached by **reducing MGT→CTE** and running a deep domain whose reflection does not enter the comparison window.
*Figures paywalled → digitization plan in K.11/U, applied only if the source is lawfully in hand; otherwise this layer is dropped with the claims downgraded accordingly (Section V).*

### K.3 Model-reduction ping-points (analytic-symbolic, exact)
Reproduce the symbolic reductions of the MGT model and match the corresponding published *model-definition* results:
- **GN-III, LS, GN-II, CTE** limits (Quintanilla 2019, DOI 10.1177/1081286519862007; reduction table independently reproduced in Abouelregal et al. 2020, *Materials* 13:4463), including the known *a-priori* fact that **MGT≡GN-III+Lag** and its consequence that the *steady-state* MGT solution must match the GN-III steady state.
- Independent 1-D **cross-check against Bazarra et al. (2022)** MGT FEM (linear elements) — same parameters, compare fields at fixed station; if only figures are available, digitize and label the comparison accordingly (K.11).

### K.4 Boundary conditions (per benchmark)
- LS layer (K.1): **[AUDIT-CORRECTED]** per the printed benchmark IBVP (Nikolarakis §4.1, Eq. 11) — `θ̃(0,t̃)=H(t̃)` (**Heaviside step** thermal shock), `σ̃ₓₓ(0,t̃)=0` (traction-free upper face), `q̃ₓ(L̃,t̃)=0` (insulated lower face), `ũ(L̃,t̃)=0` (fixed lower face); quiescent initial conditions. The step is represented numerically by the benchmark's own prescription (sharp step; if regularization is needed for numerics it is disclosed, and the "true" comparison remains the step solution by convergence).
- Classical half-space (K.2, optional): step/ramp surface temperature, traction-free surface, quiescent initial state.

### K.5 Geometry
- Benchmark-reduction geometry: 1-D layer of thickness `L` (matches K.1); for K.2 a finite depth `D` chosen so reflections from the far face do not enter the comparison window.
- 2-D extension: unit square / rectangle in plane strain (validation only after 1-D gates pass).

### K.6 Material/physical parameters
**[AUDIT-CORRECTED]** The primary benchmark (K.1) is **fully dimensionless** — it is defined by the normalized IBVP (Nikolarakis–Theotokoglou §4.1, Eq. 11) with parameters **c̃E = 1, c̃K = 1, ξ = 0.05, t̃₀ = 1, L̃ = 1**, and requires **no material table**. (The ZrO₂/Ti‑6Al‑4V table in Nikolarakis belongs to the §4.2 FGM case, which is *out of scope*.) Dimensional material data enter only if a re-dimensionalization exercise or the optional Boley–Tolins CTE anchor is added, in which case values are taken verbatim from the cited source — never guessed. **No guessed parameters (Part 3 rule).**

### K.7 Dimensionless parameters
**[AUDIT-VERIFIED]** The primary benchmark is solved directly in its own normalized variables — the verified set is **c̃E = 1, c̃K = 1, ξ = 0.05, t̃₀ = 1, L̃ = 1** (Nikolarakis §4.1, Eq. 11 and its parameter line). Solving in the benchmark's own dimensionless system eliminates re-scaling risk entirely; reproducing this benchmark requires **no dimensional material constants**. Internal sanity check available from the definitions: thermal wave speed c̃K/√(t̃₀) = 1 and elastic speed c̃E = 1, so both wavefronts reach x̃ = 1 at t̃ = 1 — the comparison times 0.25/0.50/0.75/1.25 bracket the transit and the reflection, giving a physics-based self-check independent of the published figures.

### K.8 Quantities compared
Non-dimensional temperature field `θ(x,t)`; displacement `u(x,t)`; stress `σ(x,t)` — at the benchmark's reported instants and stations.

### K.9 Numerical resolution (benchmark runs)
- Sweep `h` and `Δt` to reach the benchmark's own resolution (1000 C⁰ elements / 1250 steps in the LS case) *and beyond*; the convergence-extrapolated value (Richardson) is the device's *own* "exact" target, so the comparison is FEM-vs-FEM with both converged, *plus* FEM-vs-published for the paper figures.
- Platform statement: state-form FEAs of this size are **runs of seconds-to-minutes**. **No cluster needed**; every value reproducibly rerunnable locally (Part 10).

### K.10 Convergence/error strategy (validated quantities)
Standard: `ε_h → 0` with `h→0` at fixed Δt; `ε_Δt→0` at fixed fine h; Richardson extrapolation for the reference; error in L² and L∞ at comparison instants.

### K.11 Error metrics, tolerance, and the digitization question
- **Metrics:** relative L² and L∞ errors vs. the published/reproduced reference curves at each comparison instant; plus peak-value and wavefront-arrival-time differences (the physical quantities a heat-transfer reviewer cares about).
- **Tolerances — provisional status (pre-freeze audit):** the quantitative acceptance bands (1%/2%/5%) are **PROVISIONAL — to be fixed after convergence/error characterization in Phases 1–3**. Their *directional* basis at Blueprint stage is stated below; **no tolerance may be presented as an established standard, and none is chosen to force a pass:**
  - **≤1% (C¹ vs. in-house C⁰, same IBVP):** provisional bound set by residual discretization/extrapolation error expected from two Richardson-converged discretizations; replaced by the *measured* self-convergence error of the finer solver once V1/V5 exist.
  - **≤2% (vs. Nikolarakis FEM):** provisional code-to-code agreement level expected between two independently converged discretizations of one IBVP at the source's published resolution — *same verification philosophy as, but not justified by, prior workflows;* the number itself is re-fixed from V1/V5 measured self-convergence.
  - **≤5% (vs. digitized series):** provisional bound set by the ±3–5% coordinate-extraction uncertainty of the published figures. This is a **source-resolution limit** (its basis is the printed axis-tick coarseness), and it hardens to a firm band only after digitization is executed and its uncertainty measured.
- **Digitization (when a figure is the only source — K.2 Boley–Tolins, K.3 Bazarra supplementary):** digitize with WebPlotDigitizer (n ≥ 30 points/curve), report the digitizer + extraction uncertainty, and **do not** present a digitized-only match as exact. It is scientifically defensible *only as a secondary confirmation*, with the primary validation carried by the reproducible open-access K.1 chain. If a source forbids/prevents usable digitization, that layer is dropped from claims and the item is marked OPEN.
- **Tolerance rationale is fixed by `VALIDATION_FEASIBILITY_AUDIT.md` §4.5:** every tolerance there is tied to a stated source-resolution or convergence reason (digitization uncertainty, Richardson-extrapolation error, or mesh/Δt convergence); **no tolerance is chosen to force a pass.**

### K.12 Independent cross-check (beyond the primary benchmark)
The JV5 (≡ V10) elastic-limit dispersion comparison (different physics, closed-form, comes from the author's own verified portfolio methods) — serves as an *independent* check that the elastic operator and time integrator are right, decoupled from any thermoelasticity benchmark ambiguity.

### K.13 Beyond the primary benchmark — SENSITIVITY / ROBUSTNESS, explicitly NOT external validation
The parameter-space work is re-labeled so its type is never inflated:
- **Internal model-reduction verification (V):** CTE limit (t̃₀→0), MGT→LS identity (κ̂→0), GN-III⇔MGT steady state — these probe the *correctness of our model ladder*, not the published benchmark.
- **Sensitivity / robustness study (R):** a GN-III & MGT long-history study and a ramp-rise-time sweep (two rise times) around the benchmark's Heaviside step — a small-parameter perturbation of the *same* IBVP, run **only against our C⁰ reference** (no published target exists for these parameters), labeled as sensitivity, never as external validation.
- **External validation (A):** only the *published* benchmark reproduction (K.1/V3), plus any *independent published* source actually obtained (K.2/K.3 optional). Additional external parameter points are added **only when a published target exists** — no published target is ever invented or inferred.

*(This re-labeling implements the pre-freeze audit's parameter-point logic: convergence verification ≠ internal model-reduction ≠ sensitivity ≠ external validation.)*

---

## L. REQUIRED BENCHMARK PAPERS / FILES

**[AUDIT-CORRECTED — post-source-lock re-prioritization. See SOURCE_LOCK_AUDIT.md §8 for the authoritative list.]**

**PRIMARY (obtained & verified — no action needed, not blocking):**
1. Nikolarakis & Theotokoglou (2018), *Math. Probl. Eng.* 2018:7371016, DOI 10.1155/2018/7371016 — **obtained in full (12-page PDF)**; prints the complete LS-layer benchmark IBVP, parameters (c̃E=c̃K=1, ξ=0.05, t̃₀=1), BCs/ICs and the target figures (Figs 2–4). *(Primary external validation. Definition of the benchmark, not merely a figure.)*

**MODEL DEFINITION (reconstructable — preferred, not blocking):**
2. Quintanilla (2019), *Math. Mech. Solids* 24:4020–4031, DOI 10.1177/1081286519862007 — MGT model (paywalled; reconstruct from OA derivatives + the author's own MGT papers; ladder machine-verified in Phase 2).
3. Abouelregal et al., *Materials* 2020, 13:4463 (OA) — reduction-table cross-reference, confirmatory only.

**OPTIONAL PROVENANCE / OPTIONAL CTE ANCHOR (non-load-bearing):**
4. Bagri, Taheri, Eslami & Fariborz (2006), *J. Thermal Stresses* 29(4):359–370, DOI 10.1080/01495730500360492 — original PDF preferred to confirm L̃ and the "[26]" data identity; **the benchmark IBVP is already transcribed verbatim inside Nikolarakis §4.1, so the chain is executable without it.**
5. Boley & Tolins (1962), *J. Appl. Mech.* 29:637–646, DOI 10.1115/1.3640647 — figure set for the classical half-space; **used only if lawfully obtained**, for the optional K.2 anchor.

**GAP DOCUMENTATION (metadata verified):**
6. Bazarra, Fernández & Quintanilla (2022), *J. Comput. Appl. Math.* 409:114181, DOI 10.1016/j.cam.2022.114181 — the sole prior MGT FEM (1-D, C⁰); cited for gap framing, not used as a benchmark.

**OPEN — REQUIRED SOURCE (may be supplied to strengthen provenance; NONE is load-bearing):**
- **[OPEN‑1]** Bagri et al. (2006) original PDF (preferred provenance; see item 4).
- **[OPEN‑2]** Boley & Tolins (1962) lawfully obtained figure set (only if the optional independent published CTE anchor is desired).
- **[OPEN‑3]** Quintanilla (2019) original PDF (canonical MGT equations; otherwise reconstructed from OA derivatives + author's own MGT papers).
- **[OPEN‑4]** Author's own PDFs of the portfolio elastic/Rayleigh-dispersion anchor papers used for JV5 ≡ V10 (e.g. #48) — to reuse *verified* closed forms.

*(If any OPEN item stays unobtainable, the affected layer is dropped and the claims downgraded — see V — never replaced by an invented or guessed value.)*

---

## M. PARAMETER / DATA REQUIREMENTS

- **Benchmark transcription `params/bench_*.yaml`:** the K.1 benchmark is dimensionless and fixed — **c̃E = 1, c̃K = 1, ξ = 0.05, t̃₀ = 1, L̃ = 1** — transcribed from Nikolarakis §4.1 with source line cited; hardness-flag = locked. Optional K.2 (Boley–Tolins) parameters are added only from a lawfully obtained source.
- **Model parameters `params/model.yaml`:** dimensionless first — ξ (coupling), τ̂ (lag), κ̂ (GN-III rate-coefficient), t̃₀ — locked to the reduction ladder; dimensional (E, ν, ρ, cε, k, α, T₀) are optional and taken only from cited sources (no guessed values).
- **Study parameters `params/cases.yaml`:** coupling ξ, non-dimensional lag τ̂, non-dimensional rate-coefficient κ̂, shock rise time; each sweep kept *within model-reduction-admissible ranges* so every curve remains cross-checkable against a limit.
- **Discretization `params/mesh.yaml`:** mesh sequence, Δt sequence, quadrature rule, solver tolerances; locked before production.

---

## N. EXPECTED COMPUTATIONS

| ID | Computation | Purpose | Scale |
|---|---|---|---|
| N1 | Manufactured-solution convergence (1-D, 2-D) | V1/V2 — order of accuracy | minutes |
| N2 | Exact travelling-wave reproduction | V3 | seconds |
| N3 | Patch test | V4 | seconds |
| N4 | Elastic dispersion cross-check | JV5 ≡ V10 | minutes |
| N5 | **LS layer thermal shock (K.1)** — h,Δt sweeps + Richardson reference | Primary validation | minutes per run |
| N6 | **Classical half-space (K.2)** — deep-domain, reflection-window trade-off | Secondary validation | minutes |
| N7 | GN-III/MGT long-history + steady-state match (K.3) | Model-reduction validation | minutes |
| N8 | C¹-vs-C⁰ accuracy/efficiency sweep | H.5 claim | minutes |
| N9 | 2-D rectangle MGT transient (conditional, Phase 9) | O5 innovation in 2-D | hours (single node) |

All runs are single-node; the largest (N9) is an hours-scale parametric sweep, not an HPC obligation.

---

## O. CONVERGENCE AND ERROR STRATEGY (consolidated)

1. **Spatial:** h-refinement at fixed Δt; reported L²/H¹ errors; measured order vs. theoretical.
2. **Temporal:** Δt-refinement at fine h; measured order vs. p.
3. **Joint:** Richardson extrapolation as the device's reference "truth" for benchmark comparison; wavefront-arrival and peak-value errors reported separately (the quantities a reviewer will look at).
4. **Benchmark error:** relative L∞/L² vs. published (digitization-adjusted) at comparison instants; single-number summary + curve overlays.
5. Every table carries the mesh/Δt footprint that produced it (reproducibility).

---

## P. EXPECTED FIGURES AND TABLES

**Figures**
- F1: MGT vs. LS vs. GN-III vs. CTE — temperature profiles at fixed instants (1-D layer, thermal shock) — the novel physics figure.
- F2: Displacement and stress counterparts (the IJHMT-expected thermoelastic trio).
- F3: **Validation overlay**: FEM (C¹, Richardson-extrapolated) vs. Nikolarakis/Bagri LS curves, with the ≤2%/≤5% band drawn.
- F4: Classical half-space overlay vs. Boley–Tolins (digitized, labeled as such).
- F5: Convergence plots (h and Δt) with fitted slopes vs. theoretical lines.
- F6: Exact travelling-wave reproduction error (V3).
- F7: C¹-vs-C⁰ error-vs-DOF (efficiency) curves.
- F8: GN-III→MGT history-lag effect (flashback: how the lag reshapes the wavefront in time) — the physical-interpretation figure.
- F9 (conditional): 2-D temperature/stress snapshots (wavefront map in the rectangle).

**Tables**
- T1: Model reduction dictionary (parameter limits → CTE/LS/GN-II/GN-III/MGT) with source citations.
- T2: Benchmark parameter transcription (values + provenance).
- T3: Convergence/error tables (h, Δt, order, L²/H¹/L∞).
- T4: Benchmark error summary (per quantity, per instant, tolerance met: YES/NO).
- T5: C¹-vs-C⁰ efficiency numbers.
- T6: DOF/CPU/resolution footprint of every published figure (reproducibility ledger).

---

## Q. EXPECTED REVIEWER OBJECTIONS AND MITIGATION

1. *"What is new? MGT is published; FEM is old."* → The gap is specific and **literature-review-sourced at Phase 1**: only one FEM for MGT thermoelasticity is documented to date (1-D, C⁰, first-order-in-time); *no C¹-conforming discretization and no published external-benchmark reproduction across the CTE/LS/GN-III ladder have been found — established by the Phase-1 review, not asserted a priori.* Cite the gap precisely (E); claim only what the convergence/validation tables prove (H).
2. *"Why C¹? Thermoelasticity is classically solved with C⁰ elements."* → Provide the weak-form continuity argument (I/J.1) *and* the head-to-head C¹-vs-C⁰ numbers (J.4/F7); if C¹ loses, report the null result (the paper still clears H.1–H.4).
3. *"Your validation is against 2018/2006 numerics — is that a benchmark?"* → It is the *community-standard* verification case for generalized-thermoelasticity codes (it is used as such by the benchmark papers themselves); add the model-reduction ping-points (GN-III/MGT steady-state; LS/CTE limits) and the independent elastic cross-check (JV5 ≡ V10). Digitization uncertainty is disclosed, not hidden.
4. *"You only validated the LS limit, not MGT itself."* → Correct and *stated*. The MGT-specific confirmation is (a) exact mode/steady-state identities (K.3), (b) the Bazarra 1-D MGT FEM cross-check (K.3), and (c) manufactured-solution verification of the full MGT operator. The word "validated" is used only for what is actually reproduced.
5. *"Applications? This is symbolic."* → Tie to second-sound/hyperbolic-heat regimes, thermal shock of coatings/targets, and the pulse-echo "GN-III history-lag" observable; keep it to what the model shows (Part 13 discipline).
6. *"Reproducibility?"* → Full Git + run-manifest pipeline (R); every table cell regenerable.

---

## R. REPRODUCIBILITY / GIT STRUCTURE

Modeled on the author's existing `paper9` layout (reused so the team already knows it):

```
mgt_fem/
  plan/         # this blueprint + locked gates + change record
  eqs/          # SymPy derivations, symbol register, dimensional audit
  analytic/     # exact-mode, model-reduction (limit-ladder) checks
  params/       # bench_*.yaml, model.yaml, cases.yaml, mesh.yaml (all locked)
  solver/       # BFS C1 element, state assembly, time integrator, C0 reference
  validation/   # K.1–K.3 benchmark drivers + digitization inputs
  verification/ # JV1–JV6 verification tests
  results/raw|processed/   # never-edited raw; processed = derived
  figures/gen|out/         # gen = scripts (regenerate only); out = PDFs
  tables/gen|out/
  audit/        # run manifests: git commit, params snapshot, hashes, env versions
  latex/ bib/ release/
```

**Run discipline:** every expensive run gets (1) pilot (coarse mesh/Δt) → cost report; (2) checkpoint/resume (all transient states dumped per K snapshots; long sweeps resumable); (3) manifest (run id, commit, parameter SHA, library versions, output hashes). Failed/completed runs both log to `audit/` — raw data never edited. Target: `git clone && make all` reproduces every reported number with an environment frozen in `audit/env.yaml`.

---

## S. EXECUTION PHASES (with locked gates)

- **Phase 0 — Blueprint lock.** Read+approve this document. Lock the exact wording of objectives/claims. Exit: user signature.
- **Phase 1 — Model & solver build.** Derive (SymPy) the MGT state form; limit ladder; BFS C¹ element; C⁰ reference; assembly; time schemes. Exit (G1): symbolic identities exact; patch test passes; dimensional audit clean.
- **Phase 2 — Analytic checks.** Exact travelling wave; steady-state & GN-III↔MGT identities; limit-ladder machine-checks. Exit (G1b): two independent routes agree (SymPy vs hand-coded).
- **Phase 4A — Verification.** JV1–JV6 (manufactured solution, time order, travelling wave, patch test, elastic-dispersion cross-check, energy/entropy consistency) with prescribed tolerances. Exit (G2a): all pass.
- **Phase 3 — Validation.** K.1 LS layer; K.2 classical half-space; K.3 reductions + Bazarra cross-check; digitization with stated uncertainty. Exit (G3): K-tolerances met (≤2% reproduced; ≤5% digitized); T4 filled.
- **Phase 4B — Sensitivity/convergence sweep.** Ramp-rise-time sweep; coupling/lag/rate-coefficient sweeps (each within admissible reduction range). Exit (G4): physically monotone, energy-consistent, explainable.
- **Phase 5 — C¹-vs-C⁰ efficiency study.** Exit: measurable claim or honest null.
- **Phase 6 — Manuscript data freeze.** All figures/tables regenerated from `processed/`.
- **Phase 7 — Internal QC/audit.** Rebuild-from-clone test; provenance file.
- **Phase 8 — (Conditional) 2-D extension.** Entered only if Phases 1–5 support it (N9, F9); a 2-D MGT shock with C¹ BFS patches; verified with V1/V2 in 2-D and reduced to the 1-D benchmark by a slice/average.
- **Phase 9 — Pre-submission.** Journal-format compliance; claims audit vs. H.

---

## T. ACCEPTANCE CRITERIA PER PHASE (go/no-go)

- Phase 0: blueprint locked; OPEN list acknowledged.
- G1: symbolic limit-ladder returns *exact* reductions; bold numerical patch test to machine precision.
- G2a: JV1 order ≥ theoretical order − 0.1 (− 0.2 in L² near pollution-prone wavefront regimes, flagged); JV3 error < 10⁻⁹; JV4 exact; JV5 match to in-house closed forms ≤ 0.5%.
- **G3 (hard):** external validation V3 (Nikolarakis benchmark, 12 comparisons, ≤ provisional 2%) + internal cross-validation V5 (C⁰ reference, ≤ provisional 1%) + model-reduction identity V6 — provisional tolerances fixed in Phase 1–3 (K.11); V4 (digitized Bagri) and the CTE/GN-III model limits are NOT submission gates; *without G3 the paper is not submitted.*
- G4: sweeps physical and reproducible.
- G5: efficiency study measured, claim written from data.
- G6/G7: full regenerate-from-clone passes; audit complete.
- G8 (conditional): 2-D verified and reduced to 1-D benchmark.
- G9: no unsupported novelty statement survives the claims audit.

**Binding minimum validation package:** the mandatory set is **V1–V6** of `VALIDATION_FEASIBILITY_AUDIT.md` §5 (as revised at pre-freeze audit: mandatory = **V1, V2, V3, V5, V6**; **V4 is supporting/corroborative, not a submission gate**). Gate mapping: V1–V2 → G2a; V3 + V5 (+ V6) → G3; V6 → G4a. Supporting items V4, V7, V7b, V8, V9, V10 feed G3/G4 only as their sources/conditions are met; no optional item is a submission gate.

## U. OPEN ITEMS THAT MUST BE SUPPLIED BEFORE EXECUTION

**[AUDIT-CORRECTED — re-prioritized after the source-lock audit. NONE of the following is load-bearing for the primary validation chain; they are provenance/optional-anchor items.]**

1. **[OPEN‑1] (preferred)** Bagri et al. (2006), *J. Thermal Stresses* 29(4):359–370, original PDF — to confirm L̃ and the "[26]" data identity. **Not blocking:** its IBVP + parameters are transcribed verbatim inside Nikolarakis §4.1 (obtained).
2. **[OPEN‑2] (optional)** Boley & Tolins (1962) figure set, lawfully obtained — only if an independent *published* CTE anchor (K.2) is desired; the CTE reduction is otherwise internally anchored (t̃₀→0 + C⁰ reference solver).
3. **[OPEN‑3] (preferred)** Quintanilla (2019), *Math. Mech. Solids* 24:4020–4031, original PDF — canonical MGT equations; otherwise reconstructed from OA derivatives + the author's own MGT papers and machine-verified (Phase 2).
4. **[OPEN‑4]** The author's own PDFs of the portfolio elastic/Rayleigh-dispersion anchor papers used in JV5 ≡ V10 (to reuse *verified* closed forms).
5. **[OPEN‑5]** (Logistics) Confirmation the execution environment can run the Python stack from `audit/env.yaml` (no MATLAB assumed — the author's paper-9 precedent already standardized Python).

Each OPEN item, if absent at its phase gate, forces the corresponding *downgrade* (never a substitution with guessed data); the blueprint explicitly forbids proceeding on invented values.

---

## V. FINAL GO/NO-GO ASSESSMENT

**GO — conditional.** The direction is feasible *now* on its primary validation chain (K.1 open-access LS benchmark, whose complete IBVP is printed in the obtained PDF + model-reduction identities K.3), and the numerical method is well-posed, low-risk, and locally reproducible.

**The conditionality is two honest gates, not two hopes:**
1. **G3 must close** — the external validation gate (V3 against Nikolarakis's published FEM, at the four published instants × three fields) **plus** the internal cross-validation V5 (C⁰ reference) **plus** the model-reduction identity V6 — each against the provisional tolerances that will be *fixed* in Phase 1–3 from measured convergence (they are not fixed here) — or the paper is not submitted (downgrade to a methods preprint/workshop note is the fallback, not a re-scoped claim). Model-reduction limits and parameter sweeps count as verification/sensitivity, **not** as additional external-validation points (K.13).
2. **The C¹-efficiency claim (H.5) is contingent** — if the data do not show C¹ beating C⁰ on the chosen metric, that claim is removed and the paper stands on H.1–H.4, which do not depend on it (J.1(E)/(J.4)).

Nothing in the direction depends on an assumption that a benchmark "will become available later": the primary chain is obtained and documented today (SOURCE_LOCK_AUDIT.md), and the remaining OPEN items degrade gracefully rather than block the core.

---

### One-paragraph summary for the author
Your portfolio proves you own the MGT-thermoelasticity *physics* and the interaction of it with piezo/photo/porous effects — but every one of the 48 papers is a frequency-domain wave-kinematics/energy-ratio study with internal-only validation, and none of them contain a real numerical PDE method. The one thing the target journal's name demands — *numerical methods for heat flow* — is the one thing you have not published. This blueprint turns your existing BFS C¹ element into what is **proposed as the first C¹-conforming FEM for transient Moore–Gibson–Thompson thermoelasticity** (priority claims to be established by Phase-1 literature review), verified by manufactured solutions and exact waves, validated by reproducing the Lord–Shulman layer thermal-shock benchmark (Nikolarakis 2018, open-access, fully printed IBVP) through exact model reduction, and shipped as a **fully rerunnable MGT transient dataset**, with the GN-III→MGT history-lag effect interpreted physically. Its scientific posture is explicitly non-presumptive: C¹ is treated as a *tested* advantage against a C⁰ reference (not assumed), tolerances are fixed from measured convergence (not pre-declared), and the external benchmark — not internal limits and not digitization — is the hard validation gate. It is small enough to be scoped to one clear paper, rigorous enough to survive an IJHMT-grade reviewer asking "where is the novelty, how was it verified, how was the benchmark reproduced, and can I rerun your numbers" — and every one of those four questions is closed by design, not by hope.
