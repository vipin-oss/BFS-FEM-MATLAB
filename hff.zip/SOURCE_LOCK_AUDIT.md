# SOURCE-LOCK AUDIT — MGT Thermoelasticity C¹ BFS-FEM Blueprint
### Validation-chain executability check against the actual source documents

**Date:** 2026-09-25
**Scope:** Only the four proposed validation anchors are audited. No manuscript, no model derivation, no production code, no large computation, no Paper‑9 changes, no invented data.
**Method:** Each source was opened/retrieved where possible and checked field-by-field (A–P). Paywalled sources were checked via DOI resolution, publisher abstract, and independent OA secondary documents that reproduce their content. Classification keys: **AVAILABLE · PARTIALLY AVAILABLE · OPEN — REQUIRED SOURCE · NOT SUITABLE.**

---

## 1. EXECUTIVE CONCLUSION

**The proposed validation chain IS executable from documented, lawful sources — with the hierarchy *simplified* rather than weakened.**

Decisive finding: the primary benchmark is **not** a digitization-dependent figure set. The open-access **Nikolarakis & Theotokoglou (2018)** paper (§4.1) prints, in full symbol form, the exact **Lord–Shulman thermal-shock initial–boundary-value problem** it solves to verify its own FEM — and states explicitly that this IBVP and its parameters are "the normalized form … considered in [Bagri et al. 2006]." In other words:

> **The benchmark is defined by a fully printed equation set (IBVP) + dimensionless parameters, which any independent code can re-solve.** The published figures serve only as the *overlay target* for the comparison, not as the *definition* of the benchmark.

This reverses the risk posture of the entire blueprint: the highest-wall item is not "can we read a paywalled graph" but "can we solve a printed, fully parameterized IBVP" — which is exactly what a C¹ FEM exists to do.

Residual soft points (do not block, but must be closed inside Phase 3): the numeric value of L̃ (layer thickness) in §4.1 is implied (=1) by the figure axes rather than printed; and the figure axes have coarse ticks, so the digitized overlay carries ~3–5% extraction uncertainty. Both are handled below.

---

## 2. SOURCE-BY-SOURCE AUDIT

### SOURCE 1 — Nikolarakis & Theotokoglou (2018) — **AVAILABLE** ✅

| Field | Finding (verified from the source) |
|---|---|
| **A. Identity** | A. M. Nikolarakis, E. E. Theotokoglou, "Transient Analysis of a Functionally Graded Ceramic/Metal Layer considering Lord‑Shulman Theory," *Mathematical Problems in Engineering*, vol. 2018, Art. ID 7371016, 11 pp., published 28 May 2018, DOI 10.1155/2018/7371016. CC-BY open access. |
| **B. Obtainability** | **Full 12-page PDF obtained** (Wayback capture of `downloads.hindawi.com/journals/mpe/2018/7371016.pdf`, timestamp 2023-08-12; live Wiley page also open). Text extracted cleanly; equations, tables, figures all present. |
| **C. Geometry** | 1-D layer, thickness L, `0 ≤ x ≤ L` (normalized `0 ≤ x̃ ≤ L̃`). Upper face at x̃=0 (thermal shock), lower face at x̃=L̃. |
| **D. Model** | Lord–Shulman generalized thermoelasticity, homogeneous in the §4.1 verification case. Governing pair printed (their Eq. 1): momentum `∂/∂x[(λ+2μ)∂u/∂x − βθ] = ρü`; LS energy `−t₀(ρc θ̈ + T₀β ∂ü/∂x) − (ρc θ̇ + T₀β ∂u̇/∂x) = ∂/∂x(−k ∂θ/∂x)`. Normalized form (their Eq. 4) and stress/heat-flux (Eq. 5) also printed. |
| **E. LS/CTE/GN-III/MGT relevance** | **LS relevance: direct and central (primary benchmark is LS).** CTE relevance: direct — the LS energy equation collapses to classical Fourier coupled thermoelasticity when t̃₀→0, giving the B1 (CTE) reduction on the *same* IBVP. GN-III/MGT: not present in this paper (it is an LS-only benchmark), correctly used only as the B2 layer of the chain. |
| **F. Boundary conditions (§4.1)** | `θ̃(0,t̃) = H(t̃)` (thermal shock at upper surface), `σ̃ₓₓ(0,t̃) = 0` (traction-free upper), `q̃ₓ(L̃,t̃) = 0` (insulated lower), `ũ(L̃,t̃) = 0` (fixed lower). |
| **G. Initial conditions** | `ũ(x̃,0)=0`, `u̇̃(x̃,0)=0`, `θ̃(x̃,0)=0`, `θ̃̇(x̃,0)=0` — quiescent. |
| **H. Material parameters** | **None needed.** The §4.1 benchmark is defined purely by the dimensionless parameters (J below). Table 1 (ZrO₂/Ti‑6Al‑4V data: E, ν, α, k, ρ, c) belongs only to the §4.2 FGM case, which is **out of scope**. → Blueprint K.6 "copper" is a leftover and is corrected. |
| **I. Dimensionless variables** | Printed (their Eq. 3): x̃=x/l, t̃=Vt/l, θ̃=(T−T₀)/T₀, ũ=(λₘ+2μₘ)u/(lβₘT₀), σ̃ₓₓ=σₓₓ/(βₘT₀), t̃₀=Vt₀/l, c̃E=((λ+2μ)/(ρV²))^{1/2}, c̃K=(k/(ρc·l·V))^{1/2}, ξ=β²T₀/(ρc(λ+2μ)). With l=kₘ/[cₘ(ρₘ(λₘ+2μₘ))^{1/2}], V=((λₘ+2μₘ)/ρₘ)^{1/2} (their Eq. 10), giving c̃E=c̃K=1. |
| **J. Plotted/output quantities** | Normalized temperature change θ̃(x̃), normalized displacement ũ(x̃), normalized stress σ̃ₓₓ(x̃) — each at **t̃ = 0.25, 0.50, 0.75, 1.25** (Figures 2–4), each figure overlaying the authors' own FEM result *and* "data based on results obtained in [26]" (= Bagri et al. 2006). |
| **K. Benchmark parameters** | **c̃E = 1, c̃K = 1, ξ = 0.05, t̃₀ = 1** — stated verbatim. Cross-check: t̃₀=1 puts the shock at the relaxation-timescale, i.e. the strong second-sound regime; sound choice for hyperbolic-wavefront validation. |
| **L. Reproducible from printed info?** | **Yes, fully.** Eq. 11 IBVP + parameters + BCs/ICs are complete; the FEM itself (weak form Eq. 6, element matrices Eq. 8, Newmark, linear shape functions) is specified; resolution stated: **1000 elements, 1250 time steps**. This is a self-contained, re-solvable benchmark. |
| **M. Tabulated data?** | **No** numeric tables published; results are figures only. (Not a problem — see §5.) |
| **N. Digitization** | Feasible: **Figures 2–4**, quantities/axes above. Grid ticks are coarse (θ̃ axis to 0.5; σ̃ₓₓ axis to 0.5 over range −2.5…0.5; x̃ axis to 0.2). Estimated extraction uncertainty **±3–5%**. Method: WebPlotDigitizer, ≥25 points/curve, axes auto-calibrated from the printed tick values; uncertainty propagated into the acceptance band. |
| **O. Suitable for C¹ BFS validation?** | **Yes — ideal.** Boundary values, gradients and wavefront locations are all exercised; the smooth C¹ field can be compared against two independent published datasets (Nikolarakis FEM + overlaid Bagri points) plus the self-consistent check of our own C¹ vs. a C⁰ linear reproduction of the same IBVP. |
| **P. Mismatch vs blueprint** | One correction: blueprint implied benchmark values would be transcribed from "material tables"; in fact the benchmark is **fully dimensionless** (no material table). Also blueprint's L̃ was left unspecified — here it is the layer thickness; §4.2 analog sets L̃=1, and Figures 2–4 span x̃∈[0,1], consistent with **L̃=1** for §4.1 too (to be confirmed on digitization — minor). |

**Verdict: AVAILABLE. This is the primary external validation.**

---

### SOURCE 2 — Bagri, Taheri, Eslami & Fariborz (2006) — **PARTIALLY AVAILABLE** 🟡 (role downgraded from "required" to "preferred provenance")

| Field | Finding |
|---|---|
| **A. Identity** | A. Bagri, H. Taheri, M. R. Eslami, S. Fariborz (also cited as [26] / "S. J. Fariborz"), "Generalized coupled thermoelasticity of a layer," *Journal of Thermal Stresses* **29**(4):359–370 (2006), DOI 10.1080/01495730500360492. |
| **B. Obtainability** | **Not obtained.** T&F paywalled (DOI resolves to tandfonline 403). No lawful OA copy found in this audit. |
| **C. Geometry** | Homogeneous isotropic thermoelastic **layer**; sudden temperature applied to a boundary (from abstract + Nikolarakis §4.1). |
| **D. Model** | Unified generalized (LS/GL/GN) thermoelasticity solved **in Laplace domain with numerical inversion** (abstract + multiple citations). The LS specialization is the benchmark. |
| **E. Relevance** | **LS: direct** — its LS-layer transient is the ancestor reference, and it is the source of the ξ=0.05 / second-sound parameter set. |
| **F/G/K** | **Recovered indirectly, verbatim, through Nikolarakis §4.1**, which prints "the normalized form of the IBVP" and states "the normalized parameters considered in [26] are c̃E=1, c̃K=1, ξ=0.05, t̃₀=1." The Bagri BC/IC set is thereby the one quoted under Source 1 (fields F, G). |
| **H–I** | Non-dimensional (same scheme as Source 1, which Nikolarakis adopted from the Eslami-school convention). |
| **J** | θ̃, ũ, σ̃ₓₓ vs x̃ at discrete times — the **same four instants appear as "t=…[26]" series overlaid on Nikolarakis Figures 2–4**. |
| **L–M** | **Cannot be independently re-derived** without the original (its Laplace-domain closed form requires the paper). Availability of numeric tables in the original is unknown. |
| **N** | Original figures not obtained → cannot be digitized directly; the Bagri *data points* are instead digitized **through the Nikolarakis figure overlays** (labeled "[26]"). |
| **O/P** | Suitable as a **second independent data series** for the *same* IBVP. Blueprint's interpretation ("ancestor benchmark; validate against its numbers") is **correct in substance**, but the blueprint understated that the IBVP is already transcribed inside the open-access Nikolarakis paper. → **The chain remains executable even if Bagri 2006 is never obtained.** |

**Verdict: PARTIALLY AVAILABLE. Principal value (the IBVP + parameters) already secured via Source 1. Original PDF is a preferred, non-blocking, provenance item.**

---

### SOURCE 3 — Boley & Tolins (1962) — **OPEN — REQUIRED SOURCE** 🔴 (optional secondary; not on the critical path)

| Field | Finding |
|---|---|
| **A. Identity** | B. A. Boley, I. S. Tolins, "Transient Coupled Thermoelastic Boundary Value Problems in the Half-Space," *Journal of Applied Mechanics* (ASME) **29**(4):637–646 (1962), DOI 10.1115/1.3640647. |
| **B. Obtainability** | **Not lawfully obtained.** ASME digital collection = "Available to Purchase" / "only available via PDF" (paywall). (A shadow-library copy exists but is **excluded** on provenance grounds — will not be used.) |
| **C. Geometry** | Thermoelastic **half-space**; step time-variations of strain, temperature, or stress uniformly applied to the free surface (includes the coupled Danilovskaya problem). |
| **D. Model** | **Classical coupled (Fourier) thermoelasticity** — i.e., the CTE limit, *not* LS/MGT. |
| **E. Relevance** | CTE reduction target (B1) for the classical side of the ladder. Verified from the ASME abstract + multiple independent secondary citations. |
| **F–M** | BC/IC, scalings, plotted quantities, parameter values, and whether any tabulated numbers exist are **all unobtainable without the PDF**. Only the abstract-level description above is verified. |
| **N** | Digitization not yet assessable (no figure in hand). The 1991 *Acta Mechanica* companion ("Analytical study of the thermal shock problem of a half-space with various thermoelastic models," 89:73–92, six models, "curves … in a very handy form for program testing") could serve the same role **if legitimately obtained** — equally paywalled; treat identically. |
| **O/P** | Suitable in principle as an independent CTE check, **but the K.2 layer is NON-BLOCKING**: the CTE reduction (B1) is already internally anchored by t̃₀→0 of the *same* Eq. (11) IBVP, and can be cross-checked by our own C⁰ reference solver. Boley–Tolins would only add a *second* published CTE source. |

**Verdict: OPEN — REQUIRED SOURCE only if the paper wishes to give the CTE reduction an independent published anchor. Blueprint must mark K.2 as optional/additional, not load-bearing.**

---

### SOURCE 4 — Quintanilla (2019) — **PARTIALLY AVAILABLE** 🟡 (model definition; reconstructable from lawful OA derivatives)

| Field | Finding |
|---|---|
| **A. Identity** | R. Quintanilla, "Moore–Gibson–Thompson thermoelasticity," *Mathematics and Mechanics of Solids* **24**(12):4020–4031 (2019), DOI **10.1177/1081286519862007**. ⚠️ **The DOI `10.1177/1081286518812004` used in the draft blueprint is WRONG (404). Corrected below.** |
| **B. Obtainability** | Original paywalled (SAGE 403). **Not obtained.** |
| **C–G** | Geometry/model/BC fields = the source's *general theory* (well-posedness, uniqueness, decay) — not a benchmark case. The **MGT heat-conduction law** itself is now reproduced verbatim in **open-access** papers by the same group that cite Quintanilla 2019, e.g. Bazarra et al., *ZAMM* 2024 (OA): heat flux `τq̇ᵢ + qᵢ = κᵢⱼα,ⱼ + κ*ᵢⱼθ,ⱼ` (α = thermal displacement), giving the third-order-in-time energy equation `c(τθ̈ + θ̇) = (κ α,j),i…`; the **MGT = GN‑III + lag** identity and the limits **MGT→LS (κ*→0), MGT→GN‑III (τ→0), →GN‑II, →CTE** are stated in OA secondary reproductions (Abouelregal et al., *Materials* 2020, 13:4463) and match the author's own published MGT portfolio papers (#12, #17, #21, #26, #34, #37 — which the author holds in full). |
| **E. Relevance** | **Confirmed as claimed:** MGT is "GN-III modified by a relaxation (lag) parameter," with LS, GN-III, GN-II, CTE as exact sub-cases. The blueprint's reduction-ladder claim is **accurate**, though the ladder must be *machine-verified* in Phase 2 (as already required), since it is being assembled from OA derivatives rather than the original text. |
| **H–M** | Not applicable (no benchmark data in this source). |
| **N–P** | Not applicable. Blueprint used this source correctly as the *model definition*, not as a benchmark; the only audit-required change is the DOI and the note that the thermoelastic coupling terms must be cross-checked against the author's own MGT papers rather than assumed from the rigid-solid ZAMM version. |

**Verdict: PARTIALLY AVAILABLE. The MGT model is lawful-reconstructable; original PDF is preferred (not blocking). DOI corrected.**

---

## 3. EXACT BENCHMARK SPECIFICATIONS (as now locked for execution)

### PRIMARY BENCHMARK (B2/B4) — Lord–Shulman thermal shock of a homogeneous layer
- **IBVP (normalized), verbatim from Nikolarakis & Theotokoglou (2018), §4.1, Eq. (11):**
  - `∂/∂x̃( ∂ũ/∂x̃ − θ̃ ) = (1/c̃E²) ü̃`
  - `−(t̃₀/c̃K²)( θ̃̈ + ξ ∂ü̃/∂x̃ ) − (1/c̃K²)( θ̃̇ + ξ ∂u̇̃/∂x̃ ) = ∂/∂x̃(−∂θ̃/∂x̃)`
  - domain `0 < x̃ < L̃`, `0 < t̃ < ∞`
- **IC:** ũ(x̃,0)=0, u̇̃(x̃,0)=0, θ̃(x̃,0)=0, θ̃̇(x̃,0)=0.
- **BC:** θ̃(0,t̃)=H(t̃); σ̃ₓₓ(0,t̃)=0; q̃ₓ(L̃,t̃)=0; ũ(L̃,t̃)=0.
- **Parameters:** c̃E = 1, c̃K = 1, **ξ = 0.05, t̃₀ = 1**; L̃ = 1 (values on 0≤x̃≤1 per Figures 2–4; confirm on digitization).
- **Outputs to reproduce:** θ̃(x̃), ũ(x̃), σ̃ₓₓ(x̃) at t̃ ∈ {0.25, 0.50, 0.75, 1.25}.
- **Two independent published target datasets:** (a) Nikolarakis FEM (linear elements, Newmark, 1000 elem / 1250 steps); (b) Bagri et al. [26] data points overlaid on the same figures.

### SECONDARY (optional) — Classical CTE half-space: Boley–Tolins (1962) — **OPEN**, non-blocking.

---

## 4. AVAILABLE vs MISSING INFORMATION (summary matrix)

| Item | Status |
|---|---|
| Primary benchmark IBVP (equations, BC, IC) | AVAILABLE (printed in OA PDF) |
| Primary benchmark parameters (ξ=0.05, t̃₀=1, c̃E=c̃K=1) | AVAILABLE (printed) |
| Primary benchmark target curves (θ̃, ũ, σ̃ₓₓ @ 4 instants) | AVAILABLE as figures → digitize (Figs 2–4) |
| Primary benchmark tabulated numeric data | NOT AVAILABLE (figures only) — digitization required for overlay |
| L̃ numeric value (§4.1) | IMPLIED = 1 (axis span); confirm on digitization |
| MGT model equations (Quintanilla) | PARTIALLY AVAILABLE (OA derivatives + author's own MGT papers) |
| Bagri (2006) original PDF | OPEN (paywalled) — non-blocking (IBVP already transcribed) |
| Boley–Tolins (1962) PDF | OPEN (paywalled) — optional, non-blocking |
| Bazarra et al. (2022) 1-D MGT FEM (a-priori errors) | OPEN (Elsevier paywalled); metadata verified; used only for gap documentation |

---

## 5. PROPOSED VALIDATION HIERARCHY (revised — cleaner than the draft)

The four-source structure is **supported and simplified**. The executable chain is now:

- **B1 — Classical (CTE) limit:** `t̃₀ → 0` in the *same* Eq. (11) IBVP ⇒ classical coupled Fourier thermoelasticity. Internally anchored (self-consistent with LS at long time), plus the *optional* Boley–Tolins published anchor if lawfully obtained.
- **B2 — Lord–Shulman reduction:** the primary benchmark *is* LS — Eq. (11) with ξ=0.05, t̃₀=1 — validated against **two published datasets** (Nikolarakis FEM; Bagri overlaid points).
- **B3 — MGT calculation:** the MGT heat law replaces the LS energy equation on the *same* geometry/BC/IC; **the zero-lag limit must machine-reproduce B2** (exact equality check in Phase 2), and **GN-III ⇔ MGT with τ→0** provides the intermediate identity.
- **B4 — Published transient benchmark:** Nikolarakis & Theotokoglou (2018) — **fully documented, fully obtained, fully re-solvable.**

This hierarchy is *stronger* than the draft's, because the benchmark is now defined by a printed IBVP rather than by a figure: our C¹ FEM independently solves the IBVP, and the published figures are the overlay target, not the definition.

---

## 6. BENCHMARK REPRODUCIBILITY RISK

| Risk | Likelihood | Mitigation |
|---|---|---|
| Paywalled Bagri/Boley–Tolins originals unobtainable | Medium | Non-blocking: IBVP already transcribed via Nikolarakis; CTE reduction internally anchored. |
| Nikolarakis Newmark parameters (α,δ, unconditional-stability choice) not stated | High | Irrelevant to correctness: both solvers must converge to the *same IBVP solution*; we target the converged solution, not their discretization error. Cross-check via our own C⁰ reference solver. |
| L̃ ambiguity in §4.1 | Low | Axis span gives L̃=1; confirmed at digitization; if L̃ differs, δL̃ enters as a documented correction, not a failure. |
| Digitization uncertainty of Figs 2–4 | Certain (coarse ticks) | Treated as a *published* tolerance (≤5%), not hidden; primary acceptance stays on values we compute + their converged limit (≤2% internal). |
| MGT coupling assembled from OA derivatives mis-transcribed | Low–Medium | Phase 2 machine-checks the ladder symbolically (exact limit equality), independent of any single source. |

---

## 7. DIGITIZATION REQUIREMENTS (explicit)

| Item | Spec |
|---|---|
| Target figures | Nikolarakis & Theotokoglou (2018), **Figs 2 (temperature), 3 (displacement), 4 (stress)** |
| Quantities | θ̃(x̃), ũ(x̃), σ̃ₓₓ(x̃) |
| Axes | x̃ ∈ [0,1] (ticks 0.2); θ̃ ∈ [0,1] (ticks 0.5); ũ ∈ [−0.6,+0.3]; σ̃ₓₓ ∈ [−2.5,+0.5] |
| Parameter sets (series) | t̃ = 0.25, 0.50, 0.75, 1.25, each in the authors' series **and** the "[26]" (Bagri) series |
| Tool/method | WebPlotDigitizer; axes calibrated on printed tick labels; ≥25 points per curve; two independent extraction passes, mean used |
| Uncertainty estimate | ±3–5% (from tick coarseness); entered into the acceptance band and disclosed in the manuscript |
| Acceptance tolerance | **Digitized-series comparisons are SUPPORTING (V4, not a submission gate);** their band is ≤5% relative L∞, set by the digitization uncertainty and fixed once extraction is executed. The hard gate is our ≤2%-class comparison to the converged reference, with that 2% held **PROVISIONAL — fixed after Phase 1–3 convergence/error characterization** (see VALIDATION_FEASIBILITY_AUDIT §4.5). |

---

## 8. EXACT "OPEN — REQUIRED SOURCE" LIST (post-audit, re-prioritized)

**Non-blocking but preferred (provenance strengthening only):**
1. **Bagri, Taheri, Eslami, Fariborz (2006)**, *J. Thermal Stresses* 29(4):359–370, DOI 10.1080/01495730500360492 — original PDF (to verify L̃, the printed IBVP, and the "[26]" data identity). *Chain is executable without it.*
2. **Quintanilla (2019)**, *Math. Mech. Solids* 24:4020–4031, DOI 10.1177/1081286519862007 — original PDF (canonical MGT equations; otherwise assembled from OA derivatives + the author's own MGT papers).
3. **Boley & Tolins (1962)**, *J. Appl. Mech.* 29(4):637–646, DOI 10.1115/1.3640647 — lawfully obtained figure set **only if** an independent published CTE anchor is desired (optional K.2).

**Optional (already OA-verifiable, no action):**
4. Bazarra et al., *ZAMM* 2024 (OA) — MGT heat-conduction law (supporting model reconstruction).
5. Abouelregal et al., *Materials* 2020, 13:4463 (OA) — reduction-table cross-reference.
6. Bazarra, Fernández, Quintanilla (2022), *J. Comput. Appl. Math.* 409:114181, DOI 10.1016/j.cam.2022.114181 — 1-D MGT FEM; used for **gap documentation** only (metadata verified; PDF paywalled).

---

## 9. GO/NO-GO RECOMMENDATION FOR BLUEPRINT FREEZE

**ALLOW FREEZE — with the three mandatory amendments (all applied).** *Post-script: the later five-issue pre-freeze audit (`PRE_FREEZE_AUDIT.md`) closed with **FINAL — BLUEPRINT READY FOR EXECUTION** (freeze not applied automatically). This §9's recommendations were all implemented and remain valid.*

Rationale: the primary validation chain requires **no further source material to be executable** — the benchmark IBVP, parameters, BCs/ICs, outputs, and both target datasets are all documented in an open-access paper that is now locally held. The OPEN items are (i) optional external anchors for the CTE layer and (ii) provenance-preferred originals, none of which are load-bearing. The only intra-execution confirmations (L̃ value; digitization execution) are Phase-3 tasks, not freeze-blockers.

**Mandatory amendments to the existing blueprint (factual corrections only):**
1. **DOI correction** — Quintanilla (2019): `10.1177/1081286518812004` → **`10.1177/1081286519862007`** (three occurrences).
2. **K.6 correction** — the primary benchmark is **fully dimensionless** (defined by ξ=0.05, t̃₀=1, c̃E=c̃K=1, L̃=1). Remove the residual "copper / benchmark material table" language for the homogeneous case; material tables belong to the out-of-scope §4.2 FGM case.
3. **Validation-hierarchy revision (K, L, U)** — adopt the B1–B4 hierarchy of §5 above; reclassify Bagri (2006) and Boley–Tolins (1962) from "required anchor" to **optional provenance / optional CTE anchor**; tighten the digitization spec to §7 (Figs 2–4, stated quantities/axes/series/uncertainty/≤5% tolerance).

**What the freeze does NOT require:** any new source material. The author proceeds to Phase 0 lock on this audited basis.
