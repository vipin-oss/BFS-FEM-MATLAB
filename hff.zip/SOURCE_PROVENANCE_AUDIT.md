# SOURCE_PROVENANCE_AUDIT
### Paper 9 · Case-C production parameters attributed to Zhan & Wei (2010)

**Audit date:** 2026-09-25 · **Status: verification only** — no repository file, manuscript, code, YAML, figure, test, or package was modified.

---

## 1. Scope and method

Task was to verify the Case-C production parameters `rho = 1142 kg/m³` and `mu = 1.48e9 Pa` against the cited source, Zhan, Z. & Wei, P. (2010), "Influences of anisotropy on band gaps of 2D phononic crystal," *Acta Mechanica Solida Sinica*, 23, 181–188, DOI 10.1016/S0894-9166(10)60020-1.

**Method:** (i) located the Paper 9 parameter record in the repository; (ii) independently located the 2010 paper via its publisher record (ScienceDirect DOI landing page, which is authoritative); (iii) attempted to access the paper's Table 1; (iv) checked for any secondary source that reproduces the material table; (v) checked internal consistency of the Paper 9 values only as a plausibility signal (not as verification).

No value was inferred from approximate literature, ResearchGate metadata, or citing papers.

---

## 2. Findings — Paper 9 parameter record

**File:** `paper9/params/params_master.yaml` — located on branch **`phase-1-symbolic`** (NOT `main`).

> **Path note:** the task referenced `PROGRAM/params_master.yaml`. No `PROGRAM/` directory exists anywhere in the repository (all three branches were enumerated via the GitHub API). The actual parameter registry is `paper9/params/params_master.yaml`. This is a path-name discrepancy, not a missing file.

**Exact record (provenance tag/comment attached):**

```yaml
rho_matrix:
  value: 1142.0
  unit: "kg/m^3"
  tag: "[A]"
  source: "Zhan & Wei (2010) Table 1 (Epoxy matrix)"
  locked_in_phase: "P11"
  verified_by: "Case C convergence"
  description: "Mass density of Epoxy matrix"

mu_matrix:
  value: 1.48e9
  unit: "Pa"
  tag: "[A]"
  source: "Zhan & Wei (2010) Table 1 (Epoxy matrix)"
  locked_in_phase: "P11"
  verified_by: "Case C convergence"
  description: "Shear modulus of Epoxy matrix"
```

Also attributed to the same "Zhan & Wei (2010) Table 1" in the same file: `lambda_matrix = 4.57e9 Pa` (Epoxy), `rho_inclusion = 6333.0 kg/m³`, `mu_inclusion = 3.70e10 Pa`, `lambda_inclusion = 9.50e10 Pa` (YBCO inclusion), plus `c_t_matrix = 1138.4 m/s` ("Derived: sqrt(mu_matrix / rho_matrix)") and `omega0_caseC = 3576.4 rad/s` ("Derived: π·c_t_matrix / Lcell").

**Key observation on `verified_by`:** the provenance for these rows states verification by **"Case C convergence"** — i.e., a *numerical convergence* check of the solver on these inputs, **not** a source/table re-verification. The file itself carries a tag-convention note (in its P12A block) stating that the "[A]" tag is used under a "live convention" meaning "anchor-published or derived-from-published" and that a "documented drift" of the tag semantics exists with a "PI decision pending". So the provenance metadata is internally flagged, not silently asserted.

---

## 3. Findings — the 2010 Zhan & Wei paper

**Paper existence: VERIFIED.** Publisher record located directly at:

- ScienceDirect / Elsevier: "Influences of anisotropy on band gaps of 2D phononic crystal," Zhengqiang Zhan, Peijun Wei, *Acta Mechanica Solida Sinica*, Volume 23, Issue 2, April 2010, Pages 181–188, DOI 10.1016/S0894-9166(10)60020-1, PII S0894916610600201.

The abstract (from the publisher page) confirms the numerical example is **"YBCO/Epoxy composites"** with **orthotropic cylindrical YBCO fillers in an isotropic epoxy host**, square and triangular lattices, plane-wave-expansion method. This directly matches the Paper 9 attribution of "Epoxy matrix" and "YBCO inclusion."

**Table 1 access: NOT AVAILABLE.** The full text and Table 1 are behind the Elsevier paywall ("Access through your organization"). No lawful open-access full text, no open Table 1, and no secondary paper that reproduces Zhan & Wei's Table 1 was found. Extensive search (including a targeted "1142 / 6333 / 1.48" parameter search) returned nothing usable.

Therefore, per the task's own rule ("Do NOT infer equivalence from approximate values, secondary citations, ResearchGate metadata, or other papers"), the exact Table 1 values **cannot be verified** in this audit.

---

## 4. Value-by-value status

| Value | Status against original Table 1 |
|---|---|
| rho = 1142 kg/m³ (Epoxy matrix) | **NOT VERIFIED** (Table 1 paywalled) |
| mu = 1.48e9 Pa (Epoxy matrix) | **NOT VERIFIED** (Table 1 paywalled) |

**Transformation check:** The Paper 9 values are entered **directly** (SI units, kg/m³ and Pa), consistent with a direct copy from the paper's table — no unit conversion and no derivation is claimed or documented for `rho_matrix`/`mu_matrix`. (The derived quantities `c_t_matrix` and `omega0_caseC` are explicitly tagged as derived, and they are internally consistent: √(1.48e9/1142) = 1138.4 m/s, as recorded.)

**Plausibility (NOT verification):** the set ρ=1142 kg/m³, μ=1.48e9 Pa, λ=4.57e9 Pa is internally consistent with a typical epoxy (λ/(2(λ+μ)) ⇒ ν ≈ 0.38, E ≈ 4 GPa). This only means the values form a self-consistent isotropic pair; it does **not** confirm the original table.

**Paper 9's own governance note (relevant):** the project's `P5_PARAMETER_LOCK_REQUEST.md` (§3.2) already flags "Case C materials (blocks S2, TV6/TV14) … are not found in the available sources. No value is invented; the Case-C baseline cannot run until this is locked," and the CALC master plan carries TV6 ("Case H/C production parameters") and TV14 ("Case-C reference phase mu, rho, L") as open items. So the Case-C provenance question is already acknowledged as open inside the project, and the production values were entered under a lock-in phase P11 with source-verification not yet completed.

---

## 5. Scientific impact

**MINOR** (not NONE, not MAJOR). The Case-C two-phase band-gap results are conditioned on these material inputs; since the exact Table 1 could not be re-opened, the Case-C *production* numbers remain externally unconfirmed until the original table is obtained. The impact is **limited** because (i) the values form an internally consistent isotropic pair, (ii) the paper's own TV6/TV14 flags already mark this provenance open, and (iii) the Case-C machinery/solver verification does not depend on the exact material values.

---

## 6. SOURCE-VERIFICATION-STATUS

**SOURCE-VERIFICATION-STATUS = PARTIALLY-VERIFIED**

Exactly what remains unverified: whether Zhan & Wei (2010) **Table 1** explicitly prints `rho = 1142 kg/m³` and `mu = 1.48e9 Pa` (and λ = 4.57e9 Pa) for the epoxy matrix, together with the table number and page of those values. Resolving this requires lawful access to the Elsevier full text (DOI 10.1016/S0894-9166(10)60020-1, PII S0894916610600201, Vol. 23, Issue 2, pp. 181–188).

---

## FINAL OUTPUT (per requested format)

**SOURCE_PROVENANCE_AUDIT**

- **Reference:** Zhan, Z. & Wei, P. (2010), "Influences of anisotropy on band gaps of 2D phononic crystal," Acta Mech. Solida Sin. 23(2):181–188, DOI 10.1016/S0894-9166(10)60020-1.
- **Paper existence: VERIFIED** (Elsevier/ScienceDirect publisher record; authors Zhengqiang Zhan & Peijun Wei; YBCO/Epoxy example confirmed).
- **Table 1 access: NOT AVAILABLE** (Elsevier paywall; no lawful OA full text; no secondary reproduction of the table found).
- **rho = 1142 kg/m³: NOT VERIFIED** against the original Table 1.
- **mu = 1.48e9 Pa: NOT VERIFIED** against the original Table 1.
- **Transformation required: NO** — Paper 9 enters the values directly in SI units (direct-copy claim); no conversion/derivation documented for these two rows; derived rows (c_t, ω0) are internally consistent.
- **Production-input provenance:** entered in `paper9/params/params_master.yaml` (branch `phase-1-symbolic`) with tag `[A]`, source "Zhan & Wei (2010) Table 1 (Epoxy matrix)", lock phase P11, `verified_by: "Case C convergence"` — i.e. **attributed to the source with a convergence-only verification, not a source re-verification**; plausibility-only internal consistency (ν≈0.38, E≈4 GPa, c_t=1138 m/s) present; the project's own TV6/TV14 item already flags Case-C material provenance as open. (Note: no `PROGRAM/` path exists; the file is at `paper9/params/params_master.yaml`.)
- **Scientific impact: MINOR** (Case-C production results externally unconfirmed until Table 1 is re-opened; already internally flagged).
- **Final classification: C — SOURCE-PARTIALLY-VERIFIED** (paper genuine and attribution plausible; exact Table-1 values cannot be independently verified from accessible sources).
