# VALIDATION FEASIBILITY AUDIT
### Executable, publication-grade check of the validation architecture
**Audited document:** `Research_Blueprint_MGT_Thermoelasticity_BFS-FEM.md` (post source-lock)
**Date:** 2026-09-25 · **Basis for every claim:** the obtained Nikolarakis & Theotokoglou (2018) OA PDF (text extracted locally) and the verified source-lock record (`SOURCE_LOCK_AUDIT.md`).

Rules honored: no invented equations/parameters/constants/BCs/normalizations/values; no author-held data requested; optional sources not turned into blockers; no production runs; Paper 9 untouched; no manuscript; no scope expansion. Validation remains a mandatory gate.

---

## 1. PRIMARY EXTERNAL BENCHMARK — IMPLEMENTATION-COMPLETENESS CHECK

**Verdict up front: the benchmark is fully specified for independent implementation. The three residual ambiguities (below) are cosmetic and have documented resolutions; none blocks execution.**

### 1.1 Geometry / domain
**SPECIFIED.** Homogeneous isotropic layer, `0 ≤ x̃ ≤ L̃`, L̃ = L/l (normalized thickness). Value of L̃ in §4.1 is not printed in the IBVP line but the Figures 2–4 x̃-axes run 0 → 1 with ticks of 0.2, and §4.2 (the sibling case) states its own L̃ = 1. **Resolution:** L̃ = 1 is the operative value; re-confirmed during digitization (Phase 3). If a discrepancy appeared (it will not, given the axis span), it is a documented parameter change, not a validation failure.

### 1.2 Governing equations
**SPECIFIED — verbatim, in normalized form (their Eq. 11):**
- Momentum: `∂/∂x̃( ∂ũ/∂x̃ − θ̃ ) = (1/c̃E²) ü̃`
- Energy (Lord–Shulman): `−(t̃₀/c̃K²)( θ̃̈ + ξ ∂ü̃/∂x̃ ) − (1/c̃K²)( θ̃̇ + ξ ∂u̇̃/∂x̃ ) = ∂/∂x̃(−∂θ̃/∂x̃)`

This is the **one-relaxation-time (LS) coupled system**: the thermal inertia is carried by the t̃₀(θ̃̈ + ξ ∂ü̃/∂x̃) terms.

### 1.3 Constitutive relations
**SPECIFIED (their Eqs. 2, 5):** `σₓₓ = (λ+2μ)∂u/∂x − βθ` → normalized `σ̃ₓₓ = ∂ũ/∂x̃ − θ̃` (homogeneous case); `qₓ = −k ∂θ/∂x` → `q̃ₓ = −∂θ̃/∂x̃`.

### 1.4 Thermal relaxation model
**SPECIFIED.** Lord–Shulman only (the benchmark *is* LS; there is no GN-III/MGT term inside this benchmark — that is correct: LS is *its own* exact limit of the proposed MGT model, per the reduction ladder). The relaxation parameter is t̃₀ = 1.

### 1.5 Initial conditions
**SPECIFIED:** `ũ(x̃,0)=0`, `u̇̃(x̃,0)=0`, `θ̃(x̃,0)=0`, `θ̃̇(x̃,0)=0` — quiescent.

### 1.6 Boundary conditions
**SPECIFIED (4 conditions):**
1. `θ̃(0,t̃) = H(t̃)` — Heaviside step thermal shock at the top face;
2. `σ̃ₓₓ(0,t̃) = 0` — traction-free top face;
3. `q̃ₓ(L̃,t̃) = 0` — insulated bottom face;
4. `ũ(L̃,t̃) = 0` — fixed bottom face.

### 1.7 Dimensionless parameters
**SPECIFIED, verified verbatim:** `c̃E = 1, c̃K = 1, ξ = 0.05, t̃₀ = 1`.

### 1.8 Normalization / scaling
**SPECIFIED (their Eqs. 3, 10).** The benchmark is solved *directly in normalized variables*, so **no dimensional material constants are required at all** to reproduce it. (The blueprint's earlier "copper/material table" language was already removed in the source-lock pass — this audit confirms that removal is correct.) Physical sanity I built into the normalized definitions: elastic wave speed = c̃E = 1 and thermal wave speed = c̃K/√(t̃₀) = 1, hence both fronts traverse the layer (L̃=1) in unit time; the comparison instants 0.25/0.50/0.75/1.25 bracket transit (1.0) and the reflected return — an independent physics self-check that needs no published figure.

### 1.9 Output quantities
**SPECIFIED:** normalized temperature θ̃(x̃), displacement ũ(x̃), stress σ̃ₓₓ(x̃), at four instants.

### 1.10 Four comparison times
**SPECIFIED, verbatim (Figs 2–4 legend):** `t̃ = 0.25, 0.50, 0.75, 1.25`.

### 1.11 Spatial coordinate/range
**SPECIFIED:** `x̃ ∈ [0,1]`, ticks every 0.2.

### 1.12 Numerical comparison procedure
**SPECIFIED by us (design, defensible):** solve the *same* normalized IBVP with the C¹ BFS code until its own convergence (Richardson), then overlay:
(i) our converged field vs. the **Nikolarakis FEM result** (which in-turn matches Bagri); and
(ii) our converged field vs. the **"[26]" (Bagri) data series** digitized from the same figures.
Two independent published solutions of the same IBVP ⇒ a genuine cross-method comparison (their C⁰-linear + Newmark vs. our C¹ + consistent time integration), not a self-comparison in disguise.

### 1.13 Still-missing / ambiguous (complete list — short)
| # | Item | Nature | Resolution |
|---|---|---|---|
| A1 | Numeric value of L̃ in §4.1 | Implied by axis span (=1); not printed | Confirm at digitization; axis-bound proof already in hand |
| A2 | Nikolarakis's Newmark (α,δ) and step Δt | Not stated (only "1000 elements, 1250 steps") | Irrelevant to correctness: both codes converge to the same IBVP solution; we target the converged solution, not their transient error |
| A3 | Figure line-styles/legend mapping between the two series | Figures only | Resolved at digitization by legend text ("t=0.25" vs "t=0.25[26]") |
| A4 | Whether Bagri used the exact same L̃ | Very likely (same IBVP) | Proven by curve match at ψ-procedure time; not needed a-priori |

**Nothing in A1–A4 authorizes inventing a value.** Each is either proven from the document itself (A1) or handled as a documented procedure (A2–A4).

---

## 2. BFS-FEM EXECUTABILITY — WHAT THE FORMULATION MUST CONTAIN

*(No derivation here — this is the required-content specification for Phase 1, stated so another AI can build it.)*

### 2.1 Unknown fields / DOFs
Two primary fields in 1-D benchmark reproduction: displacement `ũ` and temperature change `θ̃` (stress is post-processed). To represent the **MGT** heat law (whose highest time-derivative order exceeds that of LS/GN-III), the first-order-in-time *state* form introduces an auxiliary thermal-flux-history variable `ψ̃` (thermal-displacement-type, `ψ̃̇ = θ̃`). Exact state vector fixed in Phase 1 (see 2.11 list of what "must be derived later").

### 2.2 Interpolation requirements
- **1-D benchmark runs:** cubic Hermite (C¹) on each element ⇒ `{field, ∂field/∂x̃}` DOFs per node. This is the C¹ pillar the paper claims.
- The **C⁰ linear reference solver** for V5/lead-in: linear Lagrange on `{ũ, θ̃}` — for the *same* IBVP, so the LS benchmark is reproducible with two independent discretizations in-house before any published comparison.
- **2-D (Phase 8, conditional):** bicubic BFS on rectangles (16 DOF/field/cell).

### 2.3 Weak-form requirements
A Galerkin weak form on C¹ spaces for the state system; stated continuity requirement is part of the paper's method contribution (blueprint §I/J.1). Boundary terms must yield the natural BCs (traction, prescribed flux) exactly; essential BCs (θ̃(0)=H(t̃), ũ(L̃)=0) by nodal prescription.

### 2.4 Element matrices / operators
From the benchmark's own normalized form, the needed operators are (labels from Nikolarakis's Eq. 8, recomputed with our basis):
thermal-state mass (the t̃₀ θ̃̈ term), thermoelastic-coupling inertia/damping (the ξ ∂ü̃/∂x̃ and ξ ∂u̇̃/∂x̃ terms), conduction stiffness (−∂²θ̃/∂x̃²), elastic stiffness (∂²ũ/∂x̃²), thermal-stress coupling stiffness (−∂θ̃/∂x̃), and the LS relaxation-augmented mass/damping entries. Quadrature rule documented once (G1).

### 2.5 Boundary-condition implementation
- `θ̃(0,t̃)=H(t̃)`: essential Dirichlet, ramped-over-one-step in discrete time (documented closure of the discontinuous input; the *published* benchmark is the same step, so convergence to the step is what is reported — a regularization-vs-convergence statement, not a modification of the physics).
- `σ̃ₓₓ(0,t̃)=0`: natural (reduces to ∂ũ/∂x̃ = θ̃ at x̃=0 via the constitutive relation).
- `q̃ₓ(L̃,t̃)=0 ⇔ ∂θ̃/∂x̃(L̃)=0`: natural.
- `ũ(L̃,t̃)=0`: essential.

### 2.6 Transient time integration
Consistent (Galerkin) time discretization of order p ∈ {1,2} on the first-order state system; time-step sequence halved for the measured convergence order. Newmark as a *reproducibility* option only if we wish to mirror the benchmark code — not required for validity.

### 2.7 Treatment of the LS relaxation term
The t̃₀ (θ̃̈ + ξ ∂ü̃/∂x̃) inertia is naturally assembled into the state-form mass matrix (it *is* the LS distinctive term). In the state form this is a first-order-in-time contribution (mass matrix on θ̇-related state), no special treatment beyond exact assembly.

### 2.8 Treatment of the MGT relaxation term
The MGT heat law adds a **third-order-in-time** term (highest order). In the state/first-order form this is absorbed by the auxiliary variable ψ̃ and its coupling; the element-level consequence is a **non-standard "thermal-state" mass block** that must be assembled exactly and its singularity (if any) handled by the documented state-form rearrangement (blueprint §I). **This is the precise reason a C¹ discretization and careful state form are the contribution, and it is exactly what must be derived in Phase 1, machine-checked against the LS limit (Ex. 2.11c), and verified by manufactured solutions.**

### 2.9 Recovery of θ̃, ũ, σ̃
`θ̃` and `ũ` are direct nodal fields (plus derivative DOFs); `σ̃ₓₓ = ∂ũ/∂x̃ − θ̃` is computed from the same basis at quadrature points and interpolated — a smooth C¹ recovery is the expected accuracy advantage over C⁰ linear (which recovers σ̃ by differentiation of C⁰ fields).

### 2.10 Mesh / time-step convergence requirements (recursive, binding)
- Fixed Δt, h → h/2: measure L² and H¹ orders for θ̃, ũ; expect cubic-Hermite H¹ order ≈ 3 (standard; the *measured* order is what passes G2a, not the textbook value).
- Fixed fine h, Δt → Δt/2: measured time order ≈ p.
- Richardson extrapolation over the finest pair ⇒ the device's reference solution used for all quantitative comparisons.
- Report every validated quantity with its (h,Δt) footprint (reproducibility ledger).

### 2.11 What must be derived later (explicit Phase-1 list — NOT derived now)
a) exact state vector and first-order state form of the MGT thermoelastic system (including ψ̃);
b) the unified parameter dictionary τ̂/κ̂ and the exact symbolic limits: **CTE ← t̃₀→0 (LS); LS ← κ̂→0 (MGT); GN-III ← τ̂→0 (MGT); GN-II** (both) — with the MGT energy equation's coefficient correspondence to the LS benchmark energy equation;
c) proof that at τ̂=0 the MGT system *reduces exactly* to the benchmark's Eq. (11) — the load-bearing G4a identity;
d) C¹ Hermite/BFS shape functions and derivative cards;
e) element matrices and quadrature rule with justification;
f) time-discretization matrices and stability/consistency statement;
g) weak BC assembly for the four benchmark BCs.

---

## 3. VALIDATION LADDER — CLASSIFICATION (rule: external benchmark is irreducible; internal limits supplement, never replace)

| Level | Description | Class | Rationale |
|---|---|---|---|
| **L1 — Classical CTE limit** (t̃₀→0 on the *same* Eq. 11 IBVP) | self-consistency limit | **B — mandatory internal limiting-case verification** | Errors in the relaxation-term assembly surface here; but it is our-own-solution-only, so it cannot substitute for external comparison |
| **L2 — Lord–Shulman benchmark** (Eq. 11, ξ=0.05, t̃₀=1) | full reproduction vs. two published datasets | **A — mandatory publication validation** | External, open-access, two independent published solution series; the paper's validation centerpiece |
| **L3 — MGT → LS limit** (κ̂→0 ⇒ Eq. 11) | exact model reduction | **A — mandatory (as an identity, hard), else B** | *The* load-bearing test that our MGT operator is correctly built → G4a; its "mandatory" status is as an internal identity, NOT as an external benchmark (external = L2/L4) |
| **L4 — Published transient comparison** (Nikolarakis + overlaid Bagri) | overlay vs. digitized published curves | **A — mandatory publication validation** | At least one external overlay is non-negotiable; two series exist on one figure set |
| **L5 — GN-III ⇔ MGT(τ̂→0) steady-state + history** | model identity | **B — mandatory internal limiting-case verification** | Verifies the rate-coefficient term (κ̂) independently of L3 |
| **L6 — Boley–Tolins (1962) CTE half-space** | independent *published* CTE anchor | **D — optional** | Only if lawfully obtained; the CTE limit is already externally irrelevant-internal-verified via L1; adds a second published source, but is not load-bearing |
| **L7 — Bazarra et al. (2022) 1-D MGT FEM cross-check** | independent published MGT method | **C — useful supporting** | Consistently validates the *MGT-specific* terms against a peer method; only if its figures/data are lawfully obtained (else gap-documentation only) |
| **L8 — Elastic/V5 dispersion cross-check** | independent physics | **B — mandatory internal verification** | Catches operator errors in the elastic block; not a thermoelastic benchmark |
| **L9 — MGT transient dataset + GN-III history-lag** | novel result | **C → A once G4a/G3 pass: it is the O5 publication output** | Not "validation" in the comparison sense; it is the deliverable the validated solver enables |

**Statement satisfying the instruction:** the external benchmark (L2+L4) is *never* replaced by internal limiting cases (L1/L3/L5). Internals prove the *operator assembly*; the external reproduction proves the *solution* to a community-standard problem.

---

## 4. NUMERICAL COMPARISON STANDARD (fixed, defensible — no slack-tolerance engineering)

### 4.1 Comparison quantities
θ̃(x̃), ũ(x̃), σ̃ₓₓ(x̃) at t̃ ∈ {0.25, 0.50, 0.75, 1.25}; plus the two physical proxies reviewers will look at: **wavefront location** and **peak value** of each field at each instant.

### 4.2 Error metrics
- **Relative L∞ (max-norm)** over the sampled x̃ for each field/instant — primary metric.
- **Relative L²** over x̃ — secondary smoothness metric.
- **Peak-error** (percent) and **wavefront-position error** (Δx̃) — physical, reported alongside.

### 4.3 Spatial/time sampling
- Spatial: evaluate both our field and the digitized series on the **digitization grid** (≥25 points/curve, common x̃ = same source grid) to avoid interpolation bias; our field is evaluated at those x̃ exactly (analytic element maps on the same axes).
- Temporal: exactly the four published instants, no interpolation in time of the digitalized series (they are instant-slices already).

### 4.4 Digitization treatment (the honest path)
- Tool WebPlotDigitizer; axes calibrated on printed ticks (x̃ to 0.2, θ̃ to 0.5, σ̃ₓₓ to 0.5, ũ to 0.1); ≥25 points/curve; two independent passes, mean taken.
- **Published-coordinate extraction uncertainty: ±3–5%** (tick coarseness; measured at phase time and reported in the manuscript).
- This uncertainty is carried **into the acceptance band** for any published-overlay comparison, and the comparison is labeled "digitized published data" — never presented as exact.

### 4.5 Acceptable tolerance — provisional status; each direction justified, NO established-standard claim
> **Pre-freeze audit rule:** a tolerance is **PROVISIONAL — to be fixed after convergence/error characterization** unless its numerical basis can be stated *now*. None of the numbers below is presented as an established scientific standard, and none is chosen to force a pass (a prior project's tolerance is **not** a scientific justification).

| Target | Tolerance | Status + basis |
|---|---|---|
| Our converged C¹ vs. our converged C⁰ (same IBVP, in-house) | ≤ **1%** relative L∞ | **PROVISIONAL.** Directional basis: two Richardson-converged discretizations of one IBVP should agree to (fine-mesh) self-error. Replaced in Phase 3 by the *measured* self-convergence error from V5. |
| Our converged C¹ vs. **Nikolarakis FEM** (published) | ≤ **2%** | **PROVISIONAL.** Directional basis: code-to-code agreement level expected at the source's published resolution (1000 el / 1250 steps). Re-fixed in Phase 3 from the V1/V5 measured self-convergence of our own solver. |
| Our C¹ vs. **digitized "[26]" Bagri series** | ≤ **5%** | **Basis is solid at Blueprint stage (source-resolution limit):** set by the ±3–5% coordinate-extraction uncertainty from the printed axis-tick coarseness; firm band fixed after digitization is executed and its uncertainty measured. (Supporting comparison, not a gate — see §5 V4.) |
| Time-convergence order | measured ≈ p (≥ p−0.1) | Definitional (consistency). |
| Space H¹ order (cubic Hermite) | measured ≈ 3 (≥ 2.9 on smooth data; stated relaxation admitted near the shock) | Approximation theory (cubic Hermite). |

**Post-Phase-1/3 obligation (recorded in §S/T):** convert every PROVISIONAL tolerance into a fixed, manuscript-stated value backed by the measured convergence/error data, before any claim of benchmark agreement.

### 4.6 Mesh / time-step convergence (binding, feeds every external tolerance)
h-sequence and Δt-sequence both halved; the external tolerances in 4.5 apply **only to the Richardson-converged solution**; a tolerance is never "met" by an unconverged coarse mesh.

### 4.7 Minimum number of parameter/time cases — re-classified (external ≠ internal ≠ sensitivity)
- **Time cases (external evidence floor):** all four instants, ×3 fields = **12 primary external comparisons** (each with L∞ + L² + peak/wavefront) — against the *published Nikolarakis FEM* (V3).
- **External parameter points:** the benchmark parameter set is fixed by the source (ξ=0.05, t̃₀=1). **No additional external parameter point exists** beyond the corroborative second published series (Bagri "[26]", V4, same parameters, obtained by digitization) and any *actually obtained* independent published source (e.g., Boley–Tolins). We do **not** manufacture external parameter points.
- **Internal model-reduction verification (NOT external validation):** the CTE limit (t̃₀→0), MGT→LS identity (κ̂→0), GN-III⇔MGT steady-state — these add parameter *checks* of our own ladder, counted as verification, never as external-validation points.
- **Sensitivity / robustness (explicitly labeled):** an in-house perturbation (e.g. ξ=0.10 or t̃₀=0.5) run *only* against our C⁰ reference — labeled a sensitivity study, **not** an external validation case.

This satisfies "not one convenient point" **honestly**: the external floor is 12 comparisons at the published parameter set (plus the corroborative second series when V4 is executed); model limits and parameter sweeps are *verification* and *sensitivity* respectively, and are reported under those names in the manuscript.

---

## 5. MINIMUM VALIDATION PACKAGE (the credibility floor)

| ID | Item | Purpose | Source | Required output | Pass criterion | Mandatory? |
|---|---|---|---|---|---|---|
| **V1** | Manufactured-solution convergence (1-D) | establish space/time accuracy orders | none (constructed) | error tables vs h and Δt; measured orders | H¹≈3, L²≈2 (spatial); ≈p (temporal); orders within stated bands | **YES** (G2a) |
| **V2** | Exact travelling thermoelastic wave (1-D) | catch sign/coupling bugs | closed-form (derived in-house from the benchmark's linearized dispersion) | field vs exact to <10⁻⁹ | residual < 10⁻⁹ | **YES** (G2a) |
| **V3** | **LS benchmark vs Nikolarakis FEM overlay** | external publication validation (primary) | Nikolarakis 2018 Figs 2–4 | 12 overlay comparisons (3 fields × 4 instants) | ≤ 2% relative L∞ (4.5) | **YES** (G3) |
| **V4** | **LS benchmark vs digitized Bagri "[26]" series** | **supporting corroborative validation** (second independent published dataset, derivative of the same digitization act) | same figures (Nikolarakis Figs 2–4, "[26]" series) | 12 comparisons vs "[26]" series | ≤ 5% relative L∞ (digitization band) | **SUPPORT — NOT a submission gate (pre-freeze audit, issue # 4)** |
| **V5** | **In-house C⁰ reference reproduction of Eq. 11** | prove our C¹ result is independent of discretization & cross-check V3/V4 | our own C⁰ solver | 12 comparisons C¹-vs-C⁰ | ≤ 1% relative L∞ | **YES** (G3 — this is the load-bearing internal cross-check) |
| **V6** | **MGT→LS reduction identity** (κ̂→0 machine-exact) | prove the MGT operator is correctly built | Symbolic (SymPy) + numeric | exact symbolic equality; and MGT(κ̂→0) numerical match to V3 fields | identity exact; ≤ 0.1% numeric | **YES** (G3/G4a — the *only* bridge that lets the MGT paper claim the LS benchmark) |
| **V7** | CTE limit (t̃₀→0) + ramp-rise-time sweep | self-consistency of relaxation assembly | same IBVP | CTE fields + 2 rise-time cases vs C⁰ | physical & converged | Support (B) |
| **V7b** | GN-III ⇔ MGT(τ̂→0) steady-state identity | verify rate-coefficient term | model ladder | steady-state match | ≤ 0.5% | Support (B) |
| **V8** | Boley–Tolins CTE half-space overlay | independent published CTE anchor | **only if lawfully obtained** | θ̃, σ̃ₓₓ overlays | ≤ 5% (digitized) | **Optional** (D) |
| **V9** | Bazarra 2022 1-D MGT cross-check | independent published MGT method | **only if figures/data in hand** | selected field comparisons | ≤ 5% (digitized) | **Optional** (C) |
| **V10** | Elastic dispersion cross-check (V5 of blueprint) | independent physics verification | author's verified portfolio closed forms | dispersion match | ≤ 0.5% | Support (B) |

**Revised mandatory set = {V1, V2, V3, V5, V6}.** V4 is **supporting/corroborative** (not a hard gate). Everything else (V4, V7, V7b, V8, V9, V10) is supporting/optional and explicitly no-submission-gate.

**Why V4 was moved off the hard gate (pre-freeze audit, issue #4):** the primary external benchmark is *already* a fully printed, reproducible IBVP (V3) with an independently published numerical solution. The digitized Bagri "[26]" series is the **same IBVP** derived through digitization, so it corroborates V3 but adds fragility (extraction uncertainty, legend-identity resolution, L̃ confirmation) without adding a genuinely independent data source. The project must never make submission depend on digitization when the underlying published IBVP + an independent published numerical solution already provide a reproducible benchmark. V4 remains recommended: run it in Phase 3, report it as "corroborative (digitized)", and downgrade it (never fabricate) if digitization is unusable.

---

## 6. FAILURE / STOP CONDITIONS (pre-production halts)

The project **stops before writing** if any of these occurs:
1. **Missing benchmark information** — any field in §1.13 list A1–A4 that turns out irrecoverable (none is expected to).
2. **Irreconcilable BC mismatch** — e.g. the stress-free top is discovered to be inconsistent with the printed constitutive relation in a way that changes the solution materially (not expected; the relation is printed and consistent).
3. **Inability to recover the LS limit** — V6 fails: the MGT system does not symbolically/numerically reduce to Eq. (11) at κ̂→0. (This is a code/model bug, not a "re-scope".)
4. **Failed mesh/time convergence** — V1 measured orders fall below the stated bands after the documented bug-fix loop.
5. **Benchmark error above the (Phase-3-fixed) tolerance** — V3 vs. Nikolarakis exceeds the tolerance fixed in Phase 3 from measured convergence (and V4, if executed, exceeds the digitization band) after convergence is established and the published resolution verified; the failure is reported, not masked.
6. **Inconsistent normalization** — the four published instants show a systematic shift (e.g. wavefront offsets equal to a scaling error); treated as a real defect and fixed, with the fix recorded.
7. **Digitization unusable** — figures unreadable/broken → V4 is **skipped** (it is supporting, not a gate; the primary V3 gate is unaffected) and the corroborative claim is simply not made (never a fabricated substitute).
8. **C¹-efficiency null (H.5)** — the efficiency claim is dropped; the paper continues on H.1–H.4 (this halts only the claim, not the paper).

Each halt has a defined, recorded disposition; none creates a covert re-scoping.

---

## 7. BLUEPRINT CONSISTENCY CHECK

| Axis | Finding |
|---|---|
| Novelty (H.1–H.5) | Unchanged: C¹ BFS for transient MGT; unified ladder; first reproducible MGT transient. Validation strengthening does **not** dilute it — V6 sharpens the MGT→LS claim into a machine-exact identity. |
| Target journal level | The mandatory package (manufactured solutions + two published datasets + exact model reduction + C⁰ cross-validation + tolerance-with-justification) is exactly the IJHMT-adjacent bar. No arbitrary slacking. |
| BFS method contribution | Preserved and now *de-risked*: the C¹ formulation must reproduce a standard C⁰ benchmark (V3/V4) *and* beat/equal a C⁰ reference (V5) — the method's claims are tested, not assumed. |
| Portfolio fit | Consistent with the source-lock conclusions: first transient numerical PDE + first external benchmark in the author's corpus; no collision with Paper 9 (different physics). |
| Source-lock status | No new OPEN items introduced. The two remaining "preferred" originals (Bagri 2006, Quintanilla 2019) remain non-blocking; the benchmark is executable from the obtained OA source. |

No contradiction found after the pre-freeze audit corrections. Aligned items: tolerances are now **PROVISIONAL** (fixed in Phase 1–3) everywhere they appear (§4.5, blueprint K.11); the **mandatory set is V1, V2, V3, V5, V6** with **V4 supporting**; parameter work is re-classified as **external validation / internal model-reduction verification / sensitivity** (blueprint K.13, §4.7); priority claims are **provisional pending literature review** (blueprint H); C¹ is positioned as **hypothesized advantage, not necessity** (blueprint J.1). No residual contradiction between V1–V6, K, T, U, V, H, and the validation terminology.

---

## 8. FINAL DECISION

# ✅ VALIDATION-READY — WITH MINOR FIXES (fixed)

*This section post-dates the Placement verification. The five-issue pre-freeze audit (`PRE_FREEZE_AUDIT.md`) closed all five issues with corrections to this document and the Master Blueprint. This document's corrected state: provisional tolerances (§4.5), V4 supporting (not a gate), mandatory = {V1, V2, V3, V5, V6}, parameter-point classification (§4.7). Final consolidated status: see `PRE_FREEZE_AUDIT.md` — **FINAL — BLUEPRINT READY FOR EXECUTION** (freeze not applied automatically).*
