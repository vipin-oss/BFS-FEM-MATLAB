#!/usr/bin/env python3
"""
PHASE-1 PILOT — smallest working 1-D LS-layer thermal-shock solver.
MGT Thermoelasticity C^1 BFS-FEM project.

Scope: implementation smoke test ONLY (not validation, not convergence study,
not C^1-vs-C^0 comparison). Uses the corrected Phase-1 derivation record
(PHASE1_DERIVATION_RECORD.md, R2): normalized benchmark Eq. (11).

Model (all dimensionless, benchmark scales, kappa-hat = 0 i.e. k* = 0):
    momentum:  u_tt = u_xx - theta_x                  (cE = 1)
    energy:    t0*(theta_tt + xi*u_xtt) + (theta_t + xi*u_xt) = theta_xx   (cK = 1)
    with  xi = 0.05, t0 = 1, x in [0, L=1].

BCs (frozen benchmark, Nikolarakis Eq. (11)):
    theta(0,t) = H(t)          (essential; step applied at t=0+)
    sigma_xx(0,t) = 0          (natural traction-free; sigma = u_x - theta)
    q_x(1,t) = 0               (natural insulated; q = -theta_x)
    u(1,t) = 0                 (essential)
ICs: u = u_t = theta = theta_t = 0  (quiescent).

Discretization:
    space: conforming C^1 cubic Hermite on both fields (value + slope DOF / node).
    time : Newmark (beta=1/4, gamma=1/2, trapezoidal / average acceleration).
           [I] IMPLEMENTATION DECISION — frozen authority leaves p in {1,2} open;
           the second-order-in-time (M,C,K) form + Newmark is recorded, not
           claimed as a theoretical requirement.
    state variables (u, p=u_t) and (theta, phi=theta_t) are the Newmark
    (position, velocity) pairs; psi decouples because kappa-hat = 0 (gauge).

Deterministic; no random numbers. No production framework, no eigensolver,
no external comparison. Check P1-P5 only.
"""
import sys
import numpy as np
from scipy.special import roots_legendre

# ----------------------------------------------------------------------
# 1. Benchmark constants (frozen, normalized)
# ----------------------------------------------------------------------
Lx   = 1.0       # x-tilde domain [0,1]
xi   = 0.05      # thermoelastic coupling
t0   = 1.0       # Lord-Shulman relaxation (normalized)
cE   = 1.0       # elastic wave speed (normalized)
cK   = 1.0       # thermal wave speed (normalized)
KHAT = 0.0       # kappa-hat = k*/(rho c V^2) = 0  <=>  k* = 0 (LS)

NE   = 100       # uniform C^1 elements  -> h = 1/NE
DT   = 0.0025    # normalized time step (CFL ~ 0.25 vs wave speed 1)
TMAX = 1.25
T_OUT = [0.25, 0.50, 0.75, 1.25]

NG = 4           # Gauss points per element (integrates degree <= 7 exactly)

# ----------------------------------------------------------------------
# 2. Cubic Hermite reference data on master zeta in [0,1]
#    basis: B = [N1, h*N2, N3, h*N4]   (interpolates value & physical slope x-deriv)
#    dB/dx = [N1'/h, N2', N3'/h, N4']   (N' = dN/dzeta)
# ----------------------------------------------------------------------
def hermite_basis(zeta, h):
    z = np.asarray(zeta, dtype=float)
    B = np.vstack([1-3*z**2+2*z**3,
                   h*(z-2*z**2+z**3),
                   3*z**2-2*z**3,
                   h*(-z**2+z**3)])            # (4, n)
    Np = np.vstack([-6*z+6*z**2,
                    1-4*z+3*z**2,
                    6*z-6*z**2,
                    -2*z+3*z**2])              # dN/dzeta (4, n)
    D = np.vstack([Np[0]/h, Np[1], Np[2]/h, Np[3]])   # dB/dx  (4, n)
    return B, D

# Gauss-Legendre 4-point on [0,1]
# [CORRECTION 2026-09-25, V1 D-1] The previous hand-rolled rule paired the two
# inner weights with the outer nodes, so it integrated int z dz = 0.4604 instead
# of 0.5 and every element matrix was quantitatively wrong (found by the V1
# manufactured-solution test). Replaced with scipy's correctly-paired rule.
GP, GW = roots_legendre(4)
GP = 0.5*(GP + 1.0)      # map [-1,1] -> [0,1]
GW = 0.5*GW

def quadrature_sanity():
    """Permanent low-level guard: fails loudly if nodes/weights are ever mispaired."""
    for k in range(0, 8):
        exact = 1.0/(k+1)
        got = float(np.sum(GW*GP**k))
        if abs(got-exact) > 1e-12:
            raise RuntimeError(f"Gauss rule broken: int z^{k} = {got} != {exact}")
    print("  [quadrature sanity] int z^0..z^7 exact on [0,1] -> PASS")

# ----------------------------------------------------------------------
# 3. Element matrices (4x4 per field; 8x8 two-field blocks)
# ----------------------------------------------------------------------
def element_matrices(h):
    B, D = hermite_basis(GP, h)                    # (4,4) each col = gauss pt
    W = GW
    M4 = h * (B * W) @ B.T                         # mass  int N_i N_j dx
    K4 = h * (D * W) @ D.T                         # stiff int N'_i N'_j dx
    E  = h * (B * W) @ D.T                         # int N_i^theta-test * N'_j^u-trial dx
    return M4, K4, E                               # E^T = int N'_i^u-test * N_j^theta-trial

# ----------------------------------------------------------------------
# 4. Global assembly: DOF id = 4*node + 2*field + kind
#    field: 0 = u, 1 = theta ; kind: 0 = value, 1 = slope
# ----------------------------------------------------------------------
NN = NE + 1
ND = 4 * NN
dof = lambda node, f, k: 4*node + 2*f + k

M = np.zeros((ND, ND)); C = np.zeros((ND, ND)); K = np.zeros((ND, ND))
h = Lx / NE

for e in range(NE):
    n0, n1 = e, e+1
    M4, K4, E = element_matrices(h)
    Et = E.T
    # local dof list: [u_val0, u_sl0, u_val1, u_sl1, th_val0, th_sl0, th_val1, th_sl1]
    loc = [dof(n0,0,0), dof(n0,0,1), dof(n1,0,0), dof(n1,0,1),
           dof(n0,1,0), dof(n0,1,1), dof(n1,1,0), dof(n1,1,1)]
    u4 = slice(0,4); t4 = slice(4,8)
    # Mass: M_uu = M4 ; M_tt = t0*M4 ; M_tu = xi*t0*E ; M_ut = 0
    M[np.ix_(loc[u4], loc[u4])] += M4
    M[np.ix_(loc[t4], loc[t4])] += t0*M4
    M[np.ix_(loc[t4], loc[u4])] += xi*t0*E
    # Damping: C_tt = M4 (=1*int v theta_t) ; C_tu = xi*E ; C_uu=C_ut=0
    C[np.ix_(loc[t4], loc[t4])] += M4
    C[np.ix_(loc[t4], loc[u4])] += xi*E
    # Stiffness: K_uu = K4 ; K_ut = -E^T ; K_tt = K4 ; K_tu = 0
    K[np.ix_(loc[u4], loc[u4])] += K4
    K[np.ix_(loc[u4], loc[t4])] += -Et
    K[np.ix_(loc[t4], loc[t4])] += K4

# ----------------------------------------------------------------------
# 5. Essential BCs: theta value at node 0 = 1 (step); u value at node L = 0
# ----------------------------------------------------------------------
pres = {dof(0,1,0): 1.0,      # theta(0) = H(t) = 1
        dof(NN-1,0,0): 0.0}   # u(1) = 0
free = np.array([i for i in range(ND) if i not in pres])
pids = np.array(sorted(pres.keys()))
up = np.zeros(ND); 
for k, v in pres.items(): up[k] = v

# ----------------------------------------------------------------------
# 6. Newmark (trapezoidal) on free DOFs
# ----------------------------------------------------------------------
beta, gamma = 0.25, 0.5
Mff = M[np.ix_(free, free)]; Cff = C[np.ix_(free, free)]; Kff = K[np.ix_(free, free)]
Kfp = K[np.ix_(free, pids)]

uf = np.zeros(len(free)); vf = np.zeros(len(free))
# initial acceleration (sudden application of the step at t=0+): M a0 = -K_fp up
af = np.linalg.solve(Mff, -Kfp @ up[pids])
ufull = np.zeros(ND); ufull[pids] = up[pids]

S = Mff + gamma*DT*Cff + beta*DT**2*Kff

nsteps = int(round(TMAX/DT))
t = 0.0
out = {}
TOL = 1e-9
snap = {}

def interpolate_field(ufull, field, xs):
    """Piecewise-cubic-Hermite evaluation of one field's value."""
    vals = np.empty_like(xs)
    for i, x in enumerate(xs):
        e = min(int(x//h), NE-1)
        zeta = (x - e*h)/h
        B, _ = hermite_basis([zeta], h)
        d = np.array([ufull[dof(e,field,0)], ufull[dof(e,field,1)],
                      ufull[dof(e+1,field,0)], ufull[dof(e+1,field,1)]])
        vals[i] = float(B[:,0] @ d)
    return vals

def interpolate_dudx(ufull, xs):
    """u_x (slope) via Hermite derivative cards -> used for sigma = u_x - theta."""
    vals = np.empty_like(xs)
    for i, x in enumerate(xs):
        e = min(int(x//h), NE-1)
        zeta = (x - e*h)/h
        _, D = hermite_basis([zeta], h)
        d = np.array([ufull[dof(e,0,0)], ufull[dof(e,0,1)],
                      ufull[dof(e+1,0,0)], ufull[dof(e+1,0,1)]])
        vals[i] = float(D[:,0] @ d)
    return vals

# main loop
nan_flag = False
for n in range(1, nsteps+1):
    t = n*DT
    u_pred = uf + DT*vf + (0.5-beta)*DT**2*af
    v_pred = vf + (1.0-gamma)*DT*af
    rhs = -Cff @ v_pred - Kff @ u_pred - Kfp @ up[pids]
    a_new = np.linalg.solve(S, rhs)
    v_new = v_pred + gamma*DT*a_new
    u_new = u_pred + beta*DT**2*a_new
    uf, vf, af = u_new, v_new, a_new
    if not np.all(np.isfinite(uf)):
        nan_flag = True
        break
    if any(abs(t - to) < TOL for to in T_OUT):
        ufull = np.zeros(ND); ufull[free] = uf; ufull[pids] = up[pids]
        snap[t] = ufull.copy()

# ----------------------------------------------------------------------
# 7. Outputs & checks
# ----------------------------------------------------------------------
quadrature_sanity()
print("="*70)
print("PHASE-1 PILOT  1-D LS thermal shock  (C^1 cubic Hermite + Newmark)")
print("="*70)
print(f"NE={NE} h={h}  DT={DT}  steps={nsteps}  DOFs={ND} (free={len(free)})")
print(f"wave speeds: cE={cE}, cK/sqrt(t0)={cK/np.sqrt(t0)}  (front reaches x=1 at t=1)")
print(f"NaN/Inf during run: {nan_flag}")

XGRID = np.linspace(0, Lx, 201)
print("\n[P1] solver ran to all output times:", all(t_ in snap for t_ in T_OUT))
print("[P4] finiteness:", not nan_flag)

results = []
print("\nt-tilde   max|theta|   min(theta)   max|u|   max|sigma|   theta(0)  u(1)   sigma(0)  theta_x(1)")
for t_ in T_OUT:
    uf_ = snap[t_]
    th = interpolate_field(uf_, 1, XGRID)
    uu = interpolate_field(uf_, 0, XGRID)
    ux = interpolate_dudx(uf_, XGRID)
    sg = ux - th
    th0   = th[0]                 # essential: should be 1
    u1    = uu[-1]                # essential: should be 0
    s0    = sg[0]                 # natural residual: sigma(0) = u_x(0)-theta(0) (~0)
    thx1  = (th[-1]-th[-2])/(XGRID[-1]-XGRID[-2])   # natural: theta_x(1) (~0)
    print(f"{t_:<7}   {np.max(np.abs(th)):<12.6f} {np.min(th):<12.6f} "
          f"{np.max(np.abs(uu)):<8.6f} {np.max(np.abs(sg)):<10.6f} "
          f"{th0:<8.6f} {u1:<6.3g} {s0:<9.6f} {thx1:<9.6f}")
    results.append(dict(t=t_, theta=th, u=uu, sigma=sg))

print("\n[P2] essential BCs: theta(0) exact =", snap[T_OUT[0]][dof(0,1,0)],
      "| u(1) exact =", snap[T_OUT[0]][dof(NN-1,0,0)])
print("[P2] natural BC residuals (weakly satisfied by Galerkin; refine -> 0):"
      "\n      sigma(0)=u_x(0)-theta(0) and theta_x(1)=q_x(1) reported above, "
      "expected finite & small.")
print("[P3] quiescent ICs: u=u_t=theta=theta_t=0 at t=0 (step applied at t=0+).")
print("[P5] basic behavior: no NaN/Inf; profiles bounded; wavefronts travel at "
      "speed 1 (unchecked numerically beyond finiteness/boundedness).")

# save pilot data (clearly identified)
import os
os.makedirs("pilot_data", exist_ok=True)
hdr = ["x"] + [f"{lab}_{t_:g}" for t_ in T_OUT for lab in ("theta","u","sigma")]
cols = [XGRID]
for r in results:
    cols += [r["theta"], r["u"], r["sigma"]]
tab = np.column_stack(cols)
np.savetxt("pilot_data/pilot_LS_profiles.csv", tab, delimiter=",", header=",".join(hdr),
           comments="", fmt="%.8e")
np.savez("pilot_data/pilot_LS_snapshots.npz",
         x=XGRID,
         **{f"theta_{t_:g}": snap[t_][::1] for t_ in T_OUT})
print("\nsaved: pilot_data/pilot_LS_profiles.csv, pilot_data/pilot_LS_snapshots.npz")
print("PILOT SCRIPT FINISHED")
