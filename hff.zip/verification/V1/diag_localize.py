#!/usr/bin/env python3
# V1 diagnostic — localize the theta H1-order anomaly. Correct, fast, time-factored.
# Cases: (A) static coupled  (B) transient xi=0 (decoupled)  (C) transient xi=0.05
import numpy as np, sympy as sp
from scipy.special import roots_legendre
from scipy.linalg import lu_factor, lu_solve

# ---- shared ----
LX=1.0; T0=1.0
xS,tS = sp.symbols('x t', real=True); OMf=(np.pi/4.0); OM=sp.pi/4
P = xS**2*(1-xS)**2*(1+sp.Rational(1,2)*xS)          # u* spatial part (deg 5)
G = xS*(1-xS)*(1+sp.Rational(2,5)*xS+sp.Rational(3,10)*xS**2)  # theta* spatial (deg 4)

fp = sp.lambdify(xS,P,'numpy'); fp_x=sp.lambdify(xS,P.diff(xS,1),'numpy'); fp_xx=sp.lambdify(xS,P.diff(xS,2),'numpy')
fg = sp.lambdify(xS,G,'numpy'); fg_x=sp.lambdify(xS,G.diff(xS,1),'numpy'); fg_xx=sp.lambdify(xS,G.diff(xS,2),'numpy')

def hermite(z,h):
    z=np.asarray(z,float)
    B=np.vstack([1-3*z**2+2*z**3, h*(z-2*z**2+z**3), 3*z**2-2*z**3, h*(-z**2+z**3)])
    D=np.vstack([(-6*z+6*z**2)/h, 1-4*z+3*z**2, (6*z-6*z**2)/h, -2*z+3*z**2])
    return B,D
GP,GW=roots_legendre(4); GP=0.5*(GP+1); GW=0.5*GW

def assemble(NE):
    h=1.0/NE; NN=NE+1; ND=4*NN; dof=lambda n,f,k:4*n+2*f+k
    B4,D4=hermite(GP,h); M4=h*(B4*GW)@B4.T; K4=h*(D4*GW)@D4.T; E=h*(B4*GW)@D4.T
    MM=np.zeros((ND,ND)); CC=np.zeros((ND,ND)); KK=np.zeros((ND,ND))
    for e in range(NE):
        loc=[dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1),
             dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]
        u4=slice(0,4); t4=slice(4,8)
        MM[np.ix_(loc[u4],loc[u4])]+=M4
        MM[np.ix_(loc[t4],loc[t4])]+=T0*M4
        MM[np.ix_(loc[t4],loc[u4])]+=XI*T0*E      # XI set by caller
        CC[np.ix_(loc[t4],loc[t4])]+=M4
        CC[np.ix_(loc[t4],loc[u4])]+=XI*E
        KK[np.ix_(loc[u4],loc[u4])]+=K4
        KK[np.ix_(loc[u4],loc[t4])]+=-E.T
        KK[np.ix_(loc[t4],loc[t4])]+=K4
    pres={dof(0,0,0):0.0,dof(NE,0,0):0.0,dof(0,1,0):0.0,dof(NE,1,0):0.0}
    free=np.array([i for i in range(ND) if i not in pres]); pids=np.array(sorted(pres))
    return h,NN,ND,dof,MM,CC,KK,free,pids,B4,D4

def intvec(NE,h,ND,dof,B4, gfun):
    F=np.zeros(ND)
    for e in range(NE):
        xa=e*h+GP*h
        gu=gfun(xa); gt=gfun(xa)
        F[[dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1)]]+=h*(B4*GW)@gu
        F[[dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]]+=h*(B4*GW)@gt
    return F

def errs(sol,NE,h,dof):
    z6,w6=roots_legendre(6); zg=0.5*(z6+1); wg=0.5*w6; B6,D6=hermite(zg,h)
    e2u=e2t=e1u=e1t=0.0; cnt=0
    for e in range(NE):
        xa=e*h+zg*h
        du=np.array([sol[dof(e,0,0)],sol[dof(e,0,1)],sol[dof(e+1,0,0)],sol[dof(e+1,0,1)]])
        dt=np.array([sol[dof(e,1,0)],sol[dof(e,1,1)],sol[dof(e+1,1,0)],sol[dof(e+1,1,1)]])
        e2u+=h*np.sum(wg*(B6.T@du-fp(xa))**2); e1u+=h*np.sum(wg*(D6.T@du-fp_x(xa))**2)
        e2t+=h*np.sum(wg*(B6.T@dt-fg(xa))**2); e1t+=h*np.sum(wg*(D6.T@dt-fg_x(xa))**2)
    return np.sqrt(e2u),np.sqrt(e2t),np.sqrt(e1u),np.sqrt(e1t)

def orders(rows):
    return [np.log(rows[k]/rows[k+1])/np.log(2) for k in range(len(rows)-1)]

def show(name,L):
    print(f"  -- {name} --")
    for r in L: print(f"     NE={r[0]:3d}: L2u={r[1]:.3e} L2th={r[2]:.3e} H1u={r[3]:.3e} H1th={r[4]:.3e}")
    for lab,col in [("L2u",1),("L2th",2),("H1u",3),("H1th",4)]:
        print(f"     {lab} orders: {['%.2f'%o for o in orders([r[col] for r in L])]}")

def icvecs(NE,h,NN,dof,deriv0=False):
    u0=np.zeros(4*NN); v0=np.zeros(4*NN)
    xs=np.linspace(0,1,NN)
    for i,x in enumerate(xs):
        u0[dof(i,0,0)]=float(fp(x)*1.0); u0[dof(i,0,1)]=float(fp_x(x))
        u0[dof(i,1,0)]=float(fg(x)*1.0); u0[dof(i,1,1)]=float(fg_x(x))
        # cos(OM t) -> time derivs zero at t=0
    return u0,v0

def run_case(xi, LEVELS, TEND, DT, static=False):
    res=[]
    for NE in LEVELS:
        global XI
        XI=xi
        h,NN,ND,dof,MM,CC,KK,free,pids,B4,D4 = assemble(NE)
        Mff=MM[np.ix_(free,free)]; Cff=CC[np.ix_(free,free)]; Kff=KK[np.ix_(free,free)]; Kfp=KK[np.ix_(free,pids)]
        up=np.zeros(ND)
        if static:
            # static source: R_u = -p'' + g',  R_th = -g''
            Ru = sp.lambdify(xS, -P.diff(xS,2)+G.diff(xS,1),'numpy')
            Rt = sp.lambdify(xS, -G.diff(xS,2),'numpy')
            F=np.zeros(ND)
            for e in range(NE):
                xa=e*h+GP*h
                F[[dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1)]]+=h*(B4*GW)@Ru(xa)
                F[[dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]]+=h*(B4*GW)@Rt(xa)
            sol=np.zeros(ND); sol[free]=np.linalg.solve(Kff, F[free])
        else:
            # time-factored sources for R_u = [-w^2 p - p'' + g'] cos ; (no sin)
            # R_t = [t0(-w^2 g - xi w^2 g_x... wait u_xtt = -w^2 p_x cos
            Ruc = sp.lambdify(xS, -(OM**2)*P - P.diff(xS,2) + G.diff(xS,1),'numpy')   # cos part (u)
            # R_t:  t0( -w^2 g - xi w^2 p_x ) - g''   [cos];  (-w g - xi w p_x) [sin]
            Rtc = sp.lambdify(xS, T0*(-(OM**2)*G - XI*(OM**2)*P.diff(xS,1)) - G.diff(xS,2),'numpy')
            Rts = sp.lambdify(xS, -OM*G - XI*OM*P.diff(xS,1),'numpy')
            Fc=np.zeros(ND); Fs=np.zeros(ND)
            for e in range(NE):
                xa=e*h+GP*h
                Fc[[dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1)]]+=h*(B4*GW)@Ruc(xa)
                Fc[[dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]]+=h*(B4*GW)@Rtc(xa)
                Fs[[dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]]+=h*(B4*GW)@Rts(xa)
            u0,v0 = icvecs(NE,h,NN,dof)
            uf=u0[free].copy(); vf=v0[free].copy()
            beta,gamma=0.25,0.5
            S=Mff+gamma*DT*Cff+beta*DT**2*Kff
            lu=lu_factor(S)
            F0=Fc+Fs            # up is all-zero (all prescribed values are 0)
            af=lu_solve(lu, F0[free]-Cff@vf-Kff@uf)
            nsteps=int(round(TEND/DT))
            for n in range(1,nsteps+1):
                t=n*DT
                upr=uf+DT*vf+(0.5-beta)*DT**2*af; vpr=vf+(1-gamma)*DT*af
                Fn=Fc*np.cos(OMf*t)+Fs*np.sin(OMf*t)
                an=lu_solve(lu, Fn[free]-Cff@vpr-Kff@upr-Kfp@up[pids])
                vn=vpr+gamma*DT*an; un=upr+beta*DT**2*an
                uf,vf,af=un,vn,an
            sol=np.zeros(ND); sol[free]=uf
        res.append((NE,)+errs(sol,NE,h,dof))
    return res

LEVELS=[16,32,64,128]
print("(A) STATIC coupled (xi=0.05)  — pure spatial operator")
show("A", run_case(0.05, LEVELS, 0, 0, static=True))
print("\n(B) TRANSIENT xi=0 (decoupled)  DT=1e-5 TEND=0.02")
show("B", run_case(0.0, LEVELS, 0.02, 1e-5))
print("\n(C) TRANSIENT xi=0.05 (coupled)  DT=1e-5 TEND=0.02")
show("C", run_case(0.05, LEVELS, 0.02, 1e-5))
