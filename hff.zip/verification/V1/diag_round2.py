#!/usr/bin/env python3
# V1 diagnostic round 2 — (D) temporal-floor sweep at fixed mesh; (E) transient
# coupled spatial sweep with time-converged DT, extended to NE=256.
import numpy as np, sympy as sp
from scipy.special import roots_legendre
from scipy.linalg import lu_factor, lu_solve

LX=1.0; T0=1.0; OMf=np.pi/4.0; OM=sp.pi/4
xS,tS = sp.symbols('x t', real=True)
P = xS**2*(1-xS)**2*(1+sp.Rational(1,2)*xS)
G = xS*(1-xS)*(1+sp.Rational(2,5)*xS+sp.Rational(3,10)*xS**2)
fp=sp.lambdify(xS,P,'numpy'); fp_x=sp.lambdify(xS,P.diff(xS,1),'numpy')
fg=sp.lambdify(xS,G,'numpy'); fg_x=sp.lambdify(xS,G.diff(xS,1),'numpy')

def hermite(z,h):
    z=np.asarray(z,float)
    B=np.vstack([1-3*z**2+2*z**3,h*(z-2*z**2+z**3),3*z**2-2*z**3,h*(-z**2+z**3)])
    D=np.vstack([(-6*z+6*z**2)/h,1-4*z+3*z**2,(6*z-6*z**2)/h,-2*z+3*z**2])
    return B,D
GP,GW=roots_legendre(4); GP=0.5*(GP+1); GW=0.5*GW

XI_VAL=0.05
def assemble(NE):
    global XI_VAL
    xi=XI_VAL
    h=1.0/NE; NN=NE+1; ND=4*NN; dof=lambda n,f,k:4*n+2*f+k
    B4,D4=hermite(GP,h); M4=h*(B4*GW)@B4.T; K4=h*(D4*GW)@D4.T; E=h*(B4*GW)@D4.T
    MM=np.zeros((ND,ND)); CC=np.zeros((ND,ND)); KK=np.zeros((ND,ND))
    for e in range(NE):
        loc=[dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1),
             dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]
        u4=slice(0,4); t4=slice(4,8)
        MM[np.ix_(loc[u4],loc[u4])]+=M4
        MM[np.ix_(loc[t4],loc[t4])]+=T0*M4
        MM[np.ix_(loc[t4],loc[u4])]+=xi*T0*E
        CC[np.ix_(loc[t4],loc[t4])]+=M4
        CC[np.ix_(loc[t4],loc[u4])]+=xi*E
        KK[np.ix_(loc[u4],loc[u4])]+=K4
        KK[np.ix_(loc[u4],loc[t4])]+=-E.T
        KK[np.ix_(loc[t4],loc[t4])]+=K4
    pres={dof(0,0,0):0.0,dof(NE,0,0):0.0,dof(0,1,0):0.0,dof(NE,1,0):0.0}
    free=np.array([i for i in range(ND) if i not in pres]); pids=np.array(sorted(pres))
    return h,NN,ND,dof,MM,CC,KK,free,pids,B4,D4

def errs(sol,NE,h,dof,tt):
    z6,w6=roots_legendre(6); zg=0.5*(z6+1); wg=0.5*w6; B6,D6=hermite(zg,h)
    cu=cs=np.cos(OMf*tt)
    e2u=e2t=e1u=e1t=0.0
    for e in range(NE):
        xa=e*h+zg*h
        du=np.array([sol[dof(e,0,0)],sol[dof(e,0,1)],sol[dof(e+1,0,0)],sol[dof(e+1,0,1)]])
        dt=np.array([sol[dof(e,1,0)],sol[dof(e,1,1)],sol[dof(e+1,1,0)],sol[dof(e+1,1,1)]])
        e2u+=h*np.sum(wg*(B6.T@du-fp(xa)*cu)**2); e1u+=h*np.sum(wg*(D6.T@du-fp_x(xa)*cu)**2)
        e2t+=h*np.sum(wg*(B6.T@dt-fg(xa)*cu)**2); e1t+=h*np.sum(wg*(D6.T@dt-fg_x(xa)*cu)**2)
    return np.sqrt(e2u),np.sqrt(e2t),np.sqrt(e1u),np.sqrt(e1t)

def transient(NE,DT,TEND):
    h,NN,ND,dof,MM,CC,KK,free,pids,B4,D4 = assemble(NE)
    Mff=MM[np.ix_(free,free)]; Cff=CC[np.ix_(free,free)]; Kff=KK[np.ix_(free,free)]; Kfp=KK[np.ix_(free,pids)]
    Ruc=sp.lambdify(xS, -(OM**2)*P - P.diff(xS,2) + G.diff(xS,1),'numpy')
    Rtc=sp.lambdify(xS, T0*(-(OM**2)*G - XI_VAL*(OM**2)*P.diff(xS,1)) - G.diff(xS,2),'numpy')
    Rts=sp.lambdify(xS, -OM*G - XI_VAL*OM*P.diff(xS,1),'numpy')
    Fc=np.zeros(ND); Fs=np.zeros(ND)
    for e in range(NE):
        xa=e*h+GP*h
        Fc[[dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1)]]+=h*(B4*GW)@Ruc(xa)
        Fc[[dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]]+=h*(B4*GW)@Rtc(xa)
        Fs[[dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]]+=h*(B4*GW)@Rts(xa)
    u0=np.zeros(ND); v0=np.zeros(ND)
    xs=np.linspace(0,1,NN)
    for i,x in enumerate(xs):
        u0[dof(i,0,0)]=fp(x); u0[dof(i,0,1)]=fp_x(x)
        u0[dof(i,1,0)]=fg(x); u0[dof(i,1,1)]=fg_x(x)
    uf=u0[free].copy(); vf=v0[free].copy()
    beta,gamma=0.25,0.5
    S=Mff+gamma*DT*Cff+beta*DT**2*Kff
    lu=lu_factor(S)
    af=lu_solve(lu,(Fc+Fs)[free]-Cff@vf-Kff@uf-Kfp@u0[pids])
    nsteps=int(round(TEND/DT))
    for n in range(1,nsteps+1):
        t=n*DT
        upr=uf+DT*vf+0.25*DT**2*af; vpr=vf+0.5*DT*af
        Fn=Fc*np.cos(OMf*t)+Fs*np.sin(OMf*t)
        an=lu_solve(lu, Fn[free]-Cff@vpr-Kff@upr-Kfp@u0[pids])
        vn=vpr+0.5*DT*an; un=upr+0.25*DT**2*an
        uf,vf,af=un,vn,an
    sol=np.zeros(ND); sol[free]=uf
    return errs(sol,NE,h,dof,TEND)

print("(D) TEMPORAL FLOOR at fixed NE=64 (coupled xi=0.05), TEND=0.02 :")
prev=None
for DT in [2e-4,1e-4,5e-5,2.5e-5,1.25e-5,6.25e-6,3.125e-6]:
    L2u,L2t,H1u,H1t = transient(64,DT,0.02)
    o='' if prev is None else f"  H1th order(DT): {np.log(prev/H1t)/np.log(2):.2f}"
    print(f"  DT={DT:.2g}: L2u={L2u:.3e} L2th={L2t:.3e} H1u={H1u:.3e} H1th={H1t:.3e}{o}")
    prev=H1t

print("\n(E) TRANSIENT SPATIAL sweep (coupled xi=0.05), TEND=0.02, DT=3.125e-6 :")
rows=[]
for NE in [16,32,64,128,256]:
    L2u,L2t,H1u,H1t = transient(NE,3.125e-6,0.02); rows.append((NE,L2u,L2t,H1u,H1t))
    print(f"  NE={NE:3d}: L2u={L2u:.3e} L2th={L2t:.3e} H1u={H1u:.3e} H1th={H1t:.3e}")
for lab,col in [("L2u",1),("L2th",2),("H1u",3),("H1th",4)]:
    o=[np.log(rows[k][col]/rows[k+1][col])/np.log(2) for k in range(len(rows)-1)]
    print(f"  {lab} orders: {['%.2f'%x for x in o]}")
