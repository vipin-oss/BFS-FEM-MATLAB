#!/usr/bin/env python3
# Final V1 diagnosis: (F) 1-step Newmark consistency; (G) theta-only transient with correct F0.
import numpy as np, sympy as sp
from scipy.special import roots_legendre
from scipy.linalg import lu_factor, lu_solve

T0=1.0; XI=0.05; OMf=np.pi/4.0; OM=sp.pi/4; TEND=0.02
xS,tS=sp.symbols('x t', real=True)
P=xS**2*(1-xS)**2*(1+sp.Rational(1,2)*xS)
G=xS*(1-xS)*(1+sp.Rational(2,5)*xS+sp.Rational(3,10)*xS**2)
fp=sp.lambdify(xS,P,'numpy'); fpx=sp.lambdify(xS,P.diff(xS,1),'numpy')
fg=sp.lambdify(xS,G,'numpy'); fgx=sp.lambdify(xS,G.diff(xS,1),'numpy')

def hermite(z,h):
    z=np.asarray(z,float)
    B=np.vstack([1-3*z**2+2*z**3,h*(z-2*z**2+z**3),3*z**2-2*z**3,h*(-z**2+z**3)])
    D=np.vstack([(-6*z+6*z**2)/h,1-4*z+3*z**2,(6*z-6*z**2)/h,-2*z+3*z**2])
    return B,D
GP,GW=roots_legendre(4); GP=0.5*(GP+1); GW=0.5*GW

def step_err(NE,DT, field):
    # one Newmark step from exact ICs; compare to exact field at t=DT
    h=1./NE; NN=NE+1; ND=4*NN; dof=lambda n,f,k:4*n+2*f+k
    B4,D4=hermite(GP,h); M4=h*(B4*GW)@B4.T; K4=h*(D4*GW)@D4.T; E=h*(B4*GW)@D4.T
    MM=np.zeros((ND,ND)); CC=np.zeros((ND,ND)); KK=np.zeros((ND,ND))
    for e in range(NE):
        loc=[dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1),
             dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]
        u4=slice(0,4); t4=slice(4,8)
        MM[np.ix_(loc[u4],loc[u4])]+=M4; MM[np.ix_(loc[t4],loc[t4])]+=T0*M4; MM[np.ix_(loc[t4],loc[u4])]+=XI*T0*E
        CC[np.ix_(loc[t4],loc[t4])]+=M4; CC[np.ix_(loc[t4],loc[u4])]+=XI*E
        KK[np.ix_(loc[u4],loc[u4])]+=K4; KK[np.ix_(loc[u4],loc[t4])]+=-E.T; KK[np.ix_(loc[t4],loc[t4])]+=K4
    Ruc=sp.lambdify(xS, -OM**2*P - P.diff(xS,2) + G.diff(xS,1),'numpy')
    Rtc=sp.lambdify(xS, T0*(-OM**2*G - XI*OM**2*P.diff(xS,1)) - G.diff(xS,2),'numpy')
    Rts=sp.lambdify(xS, -OM*G - XI*OM*P.diff(xS,1),'numpy')
    Fc=np.zeros(ND); Fs=np.zeros(ND)
    for e in range(NE):
        xa=e*h+GP*h
        Fc[[dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1)]]+=h*(B4*GW)@Ruc(xa)
        Fc[[dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]]+=h*(B4*GW)@Rtc(xa)
        Fs[[dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]]+=h*(B4*GW)@Rts(xa)
    u0=np.zeros(ND); v0=np.zeros(ND)
    xs=np.linspace(0,1,NN)
    for i,x in enumerate(xs):
        u0[dof(i,0,0)]=fp(x); u0[dof(i,0,1)]=fpx(x)
        u0[dof(i,1,0)]=fg(x); u0[dof(i,1,1)]=fgx(x)
    pres={dof(0,0,0):0.0,dof(NE,0,0):0.0,dof(0,1,0):0.0,dof(NE,1,0):0.0}
    free=np.array([i for i in range(ND) if i not in pres]); pids=np.array(sorted(pres))
    up=np.zeros(ND); up[pids]=u0[pids]
    uf=u0[free].copy(); vf=v0[free].copy()
    Mff=MM[np.ix_(free,free)]; Cff=CC[np.ix_(free,free)]; Kff=KK[np.ix_(free,free)]; Kfp=KK[np.ix_(free,pids)]
    beta,gamma=0.25,0.5
    S=Mff+gamma*DT*Cff+beta*DT**2*Kff
    lu=lu_factor(S)
    F0=Fc  # F(t=0)
    af=lu_solve(lu, F0[free]-Cff@vf-Kff@uf-Kfp@up[pids])
    # one step to t=DT
    upr=uf+DT*vf+0.25*DT**2*af; vpr=vf+0.5*DT*af
    Fn=Fc*np.cos(OMf*DT)+Fs*np.sin(OMf*DT)
    an=lu_solve(lu, Fn[free]-Cff@vpr-Kff@upr-Kfp@up[pids])
    vn=vpr+0.5*DT*an; un=upr+0.25*DT**2*an
    sol=np.zeros(ND); sol[free]=un
    z6,w6=roots_legendre(6); zg=0.5*(z6+1); wg=0.5*w6; B6,D6=hermite(zg,h)
    c1=np.cos(OMf*DT); s1=np.sin(OMf*DT)
    e2=e1=0.0
    for e in range(NE):
        xa=e*h+zg*h
        d=np.array([sol[dof(e,field,0)],sol[dof(e,field,1)],sol[dof(e+1,field,0)],sol[dof(e+1,field,1)]])
        if field==0:
            ex=fp(xa)*c1; exx=fpx(xa)*c1
        else:
            ex=fg(xa)*c1; exx=fgx(xa)*c1
        e2+=h*np.sum(wg*(B6.T@d-ex)**2); e1+=h*np.sum(wg*(D6.T@d-exx)**2)
    return np.sqrt(e2),np.sqrt(e1)

print("(F) 1-step error (u and theta), NE=64, DT halving — expect order 2 (trapezoid)")
for fld,nm in [(0,'u  '),(1,'th ')]:
    prev=None
    for DT in [4e-4,2e-4,1e-4,5e-5,2.5e-5]:
        l2,h1=step_err(64,DT,fld)
        o='' if prev is None else f"  order: {np.log(prev/l2)/np.log(2):.2f}"
        print(f"   {nm} DT={DT:.2g}: L2={l2:.3e}{o}")
        prev=l2
