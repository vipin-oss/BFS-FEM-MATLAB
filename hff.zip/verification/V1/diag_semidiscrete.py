#!/usr/bin/env python3
# V1 decisive diagnostic: SEMIDISCRETE (spatial-only) coupled operator test.
# At fixed t*, the exact semidiscrete relation is  K u* = F(t*) - M u''(t*) - C u'(t*).
# Solving this linear system isolates the SPATIAL error of the full coupled operator
# (including the xi coupling in M and C), with zero time-marching error.
import numpy as np, sympy as sp
from scipy.special import roots_legendre

T0=1.0; XI=0.05; OMf=np.pi/4.0; OM=sp.pi/4; tstar=0.02
xS,tS=sp.symbols('x t', real=True)
P=xS**2*(1-xS)**2*(1+sp.Rational(1,2)*xS)
G=xS*(1-xS)*(1+sp.Rational(2,5)*xS+sp.Rational(3,10)*xS**2)
fp=sp.lambdify(xS,P,'numpy'); fp_x=sp.lambdify(xS,P.diff(xS,1),'numpy')
fg=sp.lambdify(xS,G,'numpy'); fg_x=sp.lambdify(xS,G.diff(xS,1),'numpy')

def hermite(z,h):
    z=np.asarray(z,float)
    B=np.vstack([1-3*z**2+2*z**3,h*(z-2*z**2+z**3),3*z**2-2*z**3,h*(-z**2+z**3)])
    D=np.vstack([(-6*z+6*z**2)/h,1-4*z+3*z**2,(6*z-6*z**2)/h,-2*z+3*z**2])
    return B,D
GP,GW=roots_legendre(4); GP=0.5*(GP+1); GW=0.5*GW

# exact strong residuals at t*:
# R_u = u_tt - u_xx + th_x  =  -w^2 P cos - P'' cos + G' cos
ctl=np.cos(OMf*tstar); stl=np.sin(OMf*tstar)
Ruc=sp.lambdify(xS, -OM**2*P - P.diff(xS,2) + G.diff(xS,1),'numpy')         # *cos
Rtc=sp.lambdify(xS, T0*(-OM**2*G - XI*OM**2*P.diff(xS,1)) - G.diff(xS,2),'numpy')  # *cos
Rts=sp.lambdify(xS, -OM*G - XI*OM*P.diff(xS,1),'numpy')                      # *sin
# M u''(t*) + C u'(t*) exact vectors:
# u'' = -w^2 P cos ; th'' = -w^2 G cos ; u' = -w P sin ; th' = -w G sin
# the x-derivative-coupled mass term M_θu uses u_xtt = -w^2 P' cos... it contributes via
# the ASSEMBLED M applied to the exact acceleration vector. So build exact nodal vectors.

def build_exact_vectors(NE):
    h=1./NE; NN=NE+1; ND=4*NN; dof=lambda n,f,k:4*n+2*f+k
    u=np.zeros(ND); v=np.zeros(ND); a=np.zeros(ND)
    xs=np.linspace(0,1,NN)
    Px=sp.lambdify(xS,P.diff(xS,1),'numpy'); Gx=sp.lambdify(xS,G.diff(xS,1),'numpy')
    for i,x in enumerate(xs):
        u[dof(i,0,0)]=fp(x)*ctl;   u[dof(i,0,1)]=Px(x)*ctl
        u[dof(i,1,0)]=fg(x)*ctl;   u[dof(i,1,1)]=Gx(x)*ctl
        v[dof(i,0,0)]=-OMf*fp(x)*stl;  v[dof(i,0,1)]=-OMf*Px(x)*stl
        v[dof(i,1,0)]=-OMf*fg(x)*stl;  v[dof(i,1,1)]=-OMf*Gx(x)*stl
        a[dof(i,0,0)]=-OMf**2*fp(x)*ctl; a[dof(i,0,1)]=-OMf**2*Px(x)*ctl
        a[dof(i,1,0)]=-OMf**2*fg(x)*ctl; a[dof(i,1,1)]=-OMf**2*Gx(x)*ctl
    return u,v,a

def semidiscrete_errs(NE):
    h=1./NE; NN=NE+1; ND=4*NN; dof=lambda n,f,k:4*n+2*f+k
    B4,D4=hermite(GP,h); M4=h*(B4*GW)@B4.T; K4=h*(D4*GW)@D4.T; E=h*(B4*GW)@D4.T
    MM=np.zeros((ND,ND)); CC=np.zeros((ND,ND)); KK=np.zeros((ND,ND))
    for e in range(NE):
        loc=[dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1),
             dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]
        u4=slice(0,4); t4=slice(4,8)
        MM[np.ix_(loc[u4],loc[u4])]+=M4
        MM[np.ix_(loc[t4],loc[t4])]+=T0*M4
        MM[np.ix_(loc[t4],loc[u4])]+=XI*T0*E
        CC[np.ix_(loc[t4],loc[t4])]+=M4
        CC[np.ix_(loc[t4],loc[u4])]+=XI*E
        KK[np.ix_(loc[u4],loc[u4])]+=K4
        KK[np.ix_(loc[u4],loc[t4])]+=-E.T
        KK[np.ix_(loc[t4],loc[t4])]+=K4
    # force vector
    Fc=np.zeros(ND); Fs=np.zeros(ND)
    for e in range(NE):
        xa=e*h+GP*h
        Fc[[dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1)]]+=h*(B4*GW)@Ruc(xa)
        Fc[[dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]]+=h*(B4*GW)@Rtc(xa)
        Fs[[dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]]+=h*(B4*GW)@Rts(xa)
    ue,ve,ae = build_exact_vectors(NE)
    RHS = Fc*ctl + Fs*stl - MM@ae - CC@ve
    # prescribed values zero -> solve free rows
    pres={dof(0,0,0):0.0,dof(NE,0,0):0.0,dof(0,1,0):0.0,dof(NE,1,0):0.0}
    free=np.array([i for i in range(ND) if i not in pres])
    sol=np.zeros(ND); sol[free]=np.linalg.solve(KK[np.ix_(free,free)], RHS[free])
    # errors vs u*(t*),th*(t*)
    z6,w6=roots_legendre(6); zg=0.5*(z6+1); wg=0.5*w6; B6,D6=hermite(zg,h)
    e2u=e2t=e1u=e1t=0.0
    for e in range(NE):
        xa=e*h+zg*h
        du=np.array([sol[dof(e,0,0)],sol[dof(e,0,1)],sol[dof(e+1,0,0)],sol[dof(e+1,0,1)]])
        dt=np.array([sol[dof(e,1,0)],sol[dof(e,1,1)],sol[dof(e+1,1,0)],sol[dof(e+1,1,1)]])
        e2u+=h*np.sum(wg*(B6.T@du-fp(xa)*ctl)**2); e1u+=h*np.sum(wg*(D6.T@du-fp_x(xa)*ctl)**2)
        e2t+=h*np.sum(wg*(B6.T@dt-fg(xa)*ctl)**2); e1t+=h*np.sum(wg*(D6.T@dt-fg_x(xa)*ctl)**2)
    return np.sqrt(e2u),np.sqrt(e2t),np.sqrt(e1u),np.sqrt(e1t)

print("SEMIDISCRETE coupled (xi=0.05) at t*=0.02 — spatial-only")
rows=[]
for NE in [16,32,64,128,256]:
    r=semidiscrete_errs(NE); rows.append((NE,)+r)
    print(f"  NE={NE:3d}: L2u={r[0]:.3e} L2th={r[1]:.3e} H1u={r[2]:.3e} H1th={r[3]:.3e}")
for lab,col in [("L2u",1),("L2th",2),("H1u",3),("H1th",4)]:
    o=[np.log(rows[k][col]/rows[k+1][col])/np.log(2) for k in range(len(rows)-1)]
    print(f"  {lab} orders: {['%.2f'%x for x in o]}")
