#!/usr/bin/env python3
# Diag: theta-ONLY LS equation order (xi=0 decoupling). Excludes u DOFs from the system.
import numpy as np, sympy as sp
from scipy.special import roots_legendre
import sympy as sp

T0 = 1.0
xS,tS = sp.symbols('x t', real=True); OM = sp.pi/4
ThE = (xS*(1-xS)*(1+sp.Rational(2,5)*xS+sp.Rational(3,10)*xS**2))*sp.cos(OM*tS)
RtT = T0*ThE.diff(tS,2) + ThE.diff(tS,1) - ThE.diff(xS,2)
fRtT=sp.lambdify((xS,tS),RtT,'numpy'); fThT=sp.lambdify((xS,tS),ThE,'numpy')
fThxT=sp.lambdify((xS,tS),ThE.diff(xS,1),'numpy'); fThxtT=sp.lambdify((xS,tS),ThE.diff(xS,1).diff(tS,1),'numpy')

def hermite(zeta,h):
    z=np.asarray(zeta,float)
    B=np.vstack([1-3*z**2+2*z**3, h*(z-2*z**2+z**3), 3*z**2-2*z**3, h*(-z**2+z**3)])
    D=np.vstack([(-6*z+6*z**2)/h, 1-4*z+3*z**2, (6*z-6*z**2)/h, -2*z+3*z**2])
    return B,D
GP,GW = roots_legendre(4); GP=0.5*(GP+1); GW=0.5*GW

def th_only(NE,DT,TEND):
    h=1.0/NE; NN=NE+1
    # theta DOFs only: 2*n + (0 value,1 slope)
    thdof=lambda n,k: 2*n+k
    NT=2*NN
    B4,D4=hermite(GP,h); M4=h*(B4*GW)@B4.T; K4=h*(D4*GW)@D4.T
    MM=np.zeros((NT,NT)); CC=np.zeros((NT,NT)); KK=np.zeros((NT,NT))
    for e in range(NE):
        loc=[thdof(e,0),thdof(e,1),thdof(e+1,0),thdof(e+1,1)]
        MM[np.ix_(loc,loc)]+=T0*M4; CC[np.ix_(loc,loc)]+=M4; KK[np.ix_(loc,loc)]+=K4
    pres={thdof(0,0):0.0, thdof(NE,0):0.0}
    free=np.array([i for i in range(NT) if i not in pres])
    u0=np.zeros(NT); v0=np.zeros(NT)
    xs=np.linspace(0,1,NN)
    for i,x in enumerate(xs):
        u0[thdof(i,0)]=float(fThT(x,0)); u0[thdof(i,1)]=float(fThxT(x,0))
        v0[thdof(i,1)]=float(fThxtT(x,0))
    uf=u0[free].copy(); vf=v0[free].copy()
    S=MM[np.ix_(free,free)]+0.5*DT*CC[np.ix_(free,free)]+0.25*DT**2*KK[np.ix_(free,free)]
    from scipy.linalg import lu_factor,lu_solve
    lu=lu_factor(S)
    Mff=MM[np.ix_(free,free)]; Cff=CC[np.ix_(free,free)]; Kff=KK[np.ix_(free,free)]
    def Fvec(t):
        F=np.zeros(NT)
        for e in range(NE):
            xa=e*h+GP*h
            F[[thdof(e,0),thdof(e,1),thdof(e+1,0),thdof(e+1,1)]] += h*(B4*GW)@fRtT(xa,t)
        return F
    F0=Fvec(0.0)
    af=lu_solve(lu, F0[free]-Cff@vf-Kff@uf)
    nsteps=int(round(TEND/DT))
    for n in range(1,nsteps+1):
        t=n*DT
        upn=uf+DT*vf+0.25*DT**2*af; vpn=vf+0.5*DT*af
        an=lu_solve(lu, Fvec(t)[free]-Cff@vpn-Kff@upn)
        vn=vpn+0.5*DT*an; un=upn+0.25*DT**2*an
        uf,vf,af=un,vn,an
    sol=np.zeros(NT); sol[free]=uf
    z6,w6=roots_legendre(6); zg=0.5*(z6+1); wg=0.5*w6; B6,D6=hermite(zg,h)
    e2=e1=0.0
    for e in range(NE):
        xa=e*h+zg*h
        d=np.array([sol[thdof(e,0)],sol[thdof(e,1)],sol[thdof(e+1,0)],sol[thdof(e+1,1)]])
        e2+=h*np.sum(wg*(B6.T@d-fThT(xa,TEND))**2)
        e1+=h*np.sum(wg*(D6.T@d-fThxT(xa,TEND))**2)
    return float(np.sqrt(e2)), float(np.sqrt(e1))

print("theta-ONLY LS (xi=0, t0=1)  DT=2.5e-6  TEND=0.05")
res=[]
for NE in [16,32,64,128,256]:
    l2,h1=th_only(NE,2.5e-6,0.05); res.append((NE,l2,h1))
    print(f"  NE={NE:3d}: L2={l2:.3e}  H1={h1:.3e}")
print("orders:")
for k in range(len(res)-1):
    print(f"   {res[k][0]:3d}->{res[k+1][0]:3d}: L2={np.log(res[k][1]/res[k+1][1])/np.log(2):.3f}  H1={np.log(res[k][2]/res[k+1][2])/np.log(2):.3f}")
