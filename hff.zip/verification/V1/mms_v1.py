#!/usr/bin/env python3
"""
PHASE-1 V1 — Manufactured-Solution Verification (JV1, 1-D) — FINAL (frozen MMS).
MGT Thermoelasticity C^1 BFS-FEM project.

Authority: frozen Blueprint J.3 JV1 / validation V1:
  "substitute a smooth manufactured (u, theta, psi) into the strong form, add the
   residual as source, and measure the L2 and H1 errors vs the manufactured fields
   across a mesh refinement sequence. Pass = measured order ~ theoretical
   (3 for cubic Hermite in H1; 2 in L2 for the state form)."
Source: NONE (constructed) — PHASE1_EXECUTION_BASELINE V1 row.
Gate (frozen G2a): measured order >= theoretical - 0.1  (H1: >= 2.9 ; L2: >= 1.9,
with the -0.2 L2 band for pollution-prone regimes noted in the Blueprint).

SCOPE: ANALYTICAL/INTERNAL VERIFICATION ONLY. Not validation, not V2/V3, not a
temporal-convergence study.

FROZEN MANUFACTURED FIELDS (smooth, non-symmetric, analytically differentiable;
homogeneous Dirichlet data exactly 0):
    u*(x,t)  = x^2 (1-x)^2 (1 + 0.5 x)            * cos(OM t)
    th*(x,t) = x (1-x) (1 + 0.4 x + 0.3 x^2)       * cos(OM t)
    OM = pi/4  (slow time variation so V1 isolates SPATIAL order)
Properties: u* vanishes with slope at x=0,1 ; th* vanishes at x=0,1.
psi: at kappa-hat=0 (LS) psi is a DECOUPLED gauge (psi_t = theta); it does not feed
back and is not part of the solved two-field state; its manufactured value would be
the time-integral of th* and its error is dictated by th. (Documented; not fabricated.)

GOVERNING OPERATOR (benchmark-normalized, kappa-hat=0; corrected derivation record R2):
    momentum:  u_tt - u_xx + theta_x = 0
    energy:    t0(theta_tt + xi u_xtt) + (theta_t + xi u_xt) - theta_xx = 0
    xi = 0.05, t0 = 1.
Manufactured sources (analytical, SymPy):
    R_u = u*_tt - u*_xx + th*_x
    R_th = t0(th*_tt + xi u*_xtt) + (th*_t + xi u*_xt) - th*_xx

PRIMARY GATE MODE ("semidiscrete"): at fixed t*, solve the exact spatial identity
    K u*_h = F(t*) - M u*_tt* - C u*_t*   (exact nodal fields)
This measures the SPATIAL order of the full coupled operator with ZERO time-marching
error (standard MMS spatial-order test for a coupled second-order system).
CORROBORATION MODE ("transient"): Newmark (beta=1/4, gamma=1/2), correct consistent
initial acceleration a0 = M^{-1}(F0 - C v0 - K u0), fixed DT below the spatial error.

INDEPENDENT IMPLEMENTATION: Hermite basis, element matrices, assembly, and error
integration are re-derived here from scratch; NOTHING is imported from the pilot.

PERMANENT QUADRATURE SANITY TEST: the 4-pt Gauss rule must integrate z^0..z^7 on [0,1]
exactly (guards the confirmed nodes/weights mis-pairing defect from ever returning
silently). Printed at every run.
"""
import numpy as np
import sympy as sp
import sys
from scipy.special import roots_legendre
from scipy.linalg import lu_factor, lu_solve

# ---------------- model constants (frozen) ----------------
Lx = 0.0         # unused sentinel (domain is [0,1])
T0 = 1.0
XI = 0.05
OM  = sp.pi/4
OMf = float(OM)

# ---------------- frozen manufactured fields ----------------
xS, tS = sp.symbols('x t', real=True)
P = xS**2*(1-xS)**2*(1 + sp.Rational(1,2)*xS)                     # u* spatial part (deg 5)
G = xS*(1-xS)*(1 + sp.Rational(2,5)*xS + sp.Rational(3,10)*xS**2) # th* spatial part (deg 4)
fp   = sp.lambdify(xS, P, 'numpy')
fpx  = sp.lambdify(xS, P.diff(xS,1), 'numpy')
fg   = sp.lambdify(xS, G, 'numpy')
fgx  = sp.lambdify(xS, G.diff(xS,1), 'numpy')

# manufactured residual sources (cos part Rc, sin part Rs):
Ruc = sp.lambdify(xS, -(OM**2)*P - P.diff(xS,2) + G.diff(xS,1), 'numpy')
Rtc = sp.lambdify(xS, T0*(-(OM**2)*G - XI*(OM**2)*P.diff(xS,1)) - G.diff(xS,2), 'numpy')
Rts = sp.lambdify(xS, -OM*G - XI*OM*P.diff(xS,1), 'numpy')

# ---------------- quadrature sanity (permanent) ----------------
GP, GW = roots_legendre(4)
GP = 0.5*(GP + 1.0)
GW = 0.5*GW

def quadrature_sanity():
    ok = True
    for k in range(0, 8):
        exact = 1.0/(k+1)
        got = float(np.sum(GW*GP**k))
        if abs(got-exact) > 1e-12:
            ok = False
            print(f"  [FAIL] 4-pt Gauss: int z^{k} = {got:.6e} (exact {exact})")
    print("  [quadrature sanity] int z^0..z^7 exact on [0,1] ->", "PASS" if ok else "FAIL")
    return ok

# ---------------- Hermite ----------------
def hermite(z,h):
    z = np.asarray(z,float)
    B = np.vstack([1-3*z**2+2*z**3, h*(z-2*z**2+z**3), 3*z**2-2*z**3, h*(-z**2+z**3)])
    D = np.vstack([(-6*z+6*z**2)/h, 1-4*z+3*z**2, (6*z-6*z**2)/h, -2*z+3*z**2])
    return B,D

# ---------------- coupled assembly ----------------
def assemble(NE):
    h = 1.0/NE; NN = NE+1; ND = 4*NN
    dof = lambda n,f,k: 4*n+2*f+k
    B4,D4 = hermite(GP,h)
    M4 = h*(B4*GW)@B4.T          # int Ni Nj
    K4 = h*(D4*GW)@D4.T          # int Ni' Nj'
    E  = h*(B4*GW)@D4.T          # int Ni(theta-test) Nj'(u-trial)
    MM = np.zeros((ND,ND)); CC = np.zeros((ND,ND)); KK = np.zeros((ND,ND))
    for e in range(NE):
        loc = [dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1),
               dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]
        u4 = slice(0,4); t4 = slice(4,8)
        MM[np.ix_(loc[u4],loc[u4])] += M4
        MM[np.ix_(loc[t4],loc[t4])] += T0*M4
        MM[np.ix_(loc[t4],loc[u4])] += XI*T0*E
        CC[np.ix_(loc[t4],loc[t4])] += M4
        CC[np.ix_(loc[t4],loc[u4])] += XI*E
        KK[np.ix_(loc[u4],loc[u4])] += K4
        KK[np.ix_(loc[u4],loc[t4])] += -E.T
        KK[np.ix_(loc[t4],loc[t4])] += K4
    pres = {dof(0,0,0):0.0, dof(NE,0,0):0.0, dof(0,1,0):0.0, dof(NE,1,0):0.0}
    free = np.array([i for i in range(ND) if i not in pres])
    pids = np.array(sorted(pres))
    return h,NN,ND,dof,MM,CC,KK,free,pids,B4

def residual_vectors(NE,h,dof,B4):
    ND = 4*(NE+1)
    Fc = np.zeros(ND); Fs = np.zeros(ND)
    for e in range(NE):
        xa = e*h + GP*h
        u = [dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1)]
        t = [dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]
        Fc[u] += h*(B4*GW)@Ruc(xa); Fs[u] += 0.0
        Fc[t] += h*(B4*GW)@Rtc(xa); Fs[t] += h*(B4*GW)@Rts(xa)
    return Fc,Fs

def exact_nodal(NE,t):
    h = 1.0/NE; NN = NE+1; ND = 4*NN
    dof = lambda n,f,k: 4*n+2*f+k
    c = np.cos(OMf*t); s = np.sin(OMf*t)
    y = np.zeros(ND); v = np.zeros(ND); a = np.zeros(ND)
    xs = np.linspace(0,1,NN)
    for i,x in enumerate(xs):
        y[dof(i,0,0)] = fp(x)*c;  y[dof(i,0,1)] = fpx(x)*c
        y[dof(i,1,0)] = fg(x)*c;  y[dof(i,1,1)] = fgx(x)*c
        v[dof(i,0,0)] = -OMf*fp(x)*s;  v[dof(i,0,1)] = -OMf*fpx(x)*s
        v[dof(i,1,0)] = -OMf*fg(x)*s;  v[dof(i,1,1)] = -OMf*fgx(x)*s
        a[dof(i,0,0)] = -OMf**2*fp(x)*c; a[dof(i,0,1)] = -OMf**2*fpx(x)*c
        a[dof(i,1,0)] = -OMf**2*fg(x)*c; a[dof(i,1,1)] = -OMf**2*fgx(x)*c
    return y,v,a

def norms(sol,NE,h,dof,tscale):
    z6,w6 = roots_legendre(6); zg = 0.5*(z6+1); wg = 0.5*w6; B6,D6 = hermite(zg,h)
    cu = np.cos(OMf*tscale)
    e2u=e2t=e1u=e1t = 0.0
    for e in range(NE):
        xa = e*h + zg*h
        du = np.array([sol[dof(e,0,0)],sol[dof(e,0,1)],sol[dof(e+1,0,0)],sol[dof(e+1,0,1)]])
        dt = np.array([sol[dof(e,1,0)],sol[dof(e,1,1)],sol[dof(e+1,1,0)],sol[dof(e+1,1,1)]])
        e2u += h*np.sum(wg*(B6.T@du - fp(xa)*cu)**2)
        e1u += h*np.sum(wg*(D6.T@du - fpx(xa)*cu)**2)
        e2t += h*np.sum(wg*(B6.T@dt - fg(xa)*cu)**2)
        e1t += h*np.sum(wg*(D6.T@dt - fgx(xa)*cu)**2)
    return float(np.sqrt(e2u)),float(np.sqrt(e2t)),float(np.sqrt(e1u)),float(np.sqrt(e1t))

def orders(v):
    return [np.log(v[k]/v[k+1])/np.log(2) for k in range(len(v)-1)]

# ---------------- semidiscrete (gate) ----------------
def run_semidiscrete(LEVELS, tstar):
    rows = []
    for NE in LEVELS:
        h,NN,ND,dof,MM,CC,KK,free,pids,B4 = assemble(NE)
        Fc,Fs = residual_vectors(NE,h,dof,B4)
        ye,ve,ae = exact_nodal(NE,tstar)
        c = np.cos(OMf*tstar); s = np.sin(OMf*tstar)
        RHS = Fc*c + Fs*s - MM@ae - CC@ve
        sol = np.zeros(ND)
        sol[free] = np.linalg.solve(KK[np.ix_(free,free)], RHS[free])
        rows.append((NE,)+norms(sol,NE,h,dof,tstar))
    return rows

# ---------------- transient (corroboration) ----------------
def run_transient(LEVELS, DT, TEND):
    rows = []
    for NE in LEVELS:
        h,NN,ND,dof,MM,CC,KK,free,pids,B4 = assemble(NE)
        Fc,Fs = residual_vectors(NE,h,dof,B4)
        u0,v0,a0e = exact_nodal(NE,0.0)
        up = np.zeros(ND); up[pids] = u0[pids]
        uf = u0[free].copy(); vf = v0[free].copy()
        Mff=MM[np.ix_(free,free)]; Cff=CC[np.ix_(free,free)]; Kff=KK[np.ix_(free,free)]; Kfp=KK[np.ix_(free,pids)]
        # CORRECT consistent initial acceleration: M a0 = F(0) - C v0 - K u0
        af = lu_solve(lu_factor(Mff), Fc[free] - Cff@vf - Kff@uf - Kfp@up[pids])
        beta,gamma = 0.25,0.5
        S = Mff + gamma*DT*Cff + beta*DT**2*Kff
        luS = lu_factor(S)
        nsteps = int(round(TEND/DT))
        for n in range(1,nsteps+1):
            t = n*DT
            upr = uf + DT*vf + 0.25*DT**2*af
            vpr = vf + 0.5*DT*af
            Fn = Fc*np.cos(OMf*t) + Fs*np.sin(OMf*t)
            an = lu_solve(luS, Fn[free] - Cff@vpr - Kff@upr - Kfp@up[pids])
            vn = vpr + 0.5*DT*an; un = upr + 0.25*DT**2*an
            uf,vf,af = un,vn,an
        sol = np.zeros(ND); sol[free] = uf
        rows.append((NE,)+norms(sol,NE,h,dof,TEND))
    return rows

def print_table(title, rows):
    print(title)
    print("   "+" | ".join(f"{c:>10}" for c in ["NE","h","L2(u)","L2(th)","H1(u)","H1(th)"]))
    for r in rows:
        print("   "+" | ".join([f"{r[0]:>10d}", f"{1/r[0]:.5f}"] +
              [f"{r[k]:.3e}" for k in (1,2,3,4)]))
    for lab,col in [("L2(u)",1),("L2(th)",2),("H1(u)",3),("H1(th)",4)]:
        o = orders([r[col] for r in rows])
        print(f"      {lab} orders: {['%.3f'%x for x in o]}")

if __name__ == "__main__":
    ok = quadrature_sanity()
    LEVELS = [16,32,64,128,256]
    mode = sys.argv[1] if len(sys.argv)>1 else "semidiscrete"
    if mode == "semidiscrete":
        tstar = 0.02
        rows = run_semidiscrete(LEVELS, tstar)
        print(f"\nV1 PRIMARY GATE (semidiscrete, coupled xi=0.05, t*={tstar}):")
        print_table("", rows)
        with open("verification/V1/v1_error_table.csv","w") as f:
            f.write("NE,h,L2_u,L2_theta,H1_u,H1_theta\n")
            for r in rows: f.write("%d,%.6f,%.6e,%.6e,%.6e,%.6e\n"%(r[0],1/r[0],r[1],r[2],r[3],r[4]))
        print("\n  -> verification/V1/v1_error_table.csv written.")
        print("  frozen gate: H1 >= 3-0.1 = 2.9 ; L2 >= 2-0.1 = 1.9 (state-form target L2=2)")
    elif mode == "transient":
        DT = 2.5e-6; TEND = 0.02
        rows = run_transient([16,32,64,128], DT, TEND)
        print(f"\nV1 CORROBORATION (transient, Newmark beta=0.25 gamma=0.5, DT={DT}, TEND={TEND}):")
        print_table("", rows)
    else:
        raise SystemExit("unknown mode")
