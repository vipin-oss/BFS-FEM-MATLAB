#!/usr/bin/env python3
"""
V1 controlled diagnostic — θ-only experiments (NO coupling), non-symmetric manufactured θ.
Purpose: determine whether the θ spatial operator itself achieves the frozen orders
(H1=3, L2=2 state-form gate), and whether temporal contamination explains the earlier
coupled-transient θ anomaly. Single-variable progression:
   E1: static Poisson            (stiffness + quadrature + source + Dirichlet BC)
   E2: harmonic semidiscrete     (adds mass t0*th_tt + damping th_t)
   E3: harmonic transient        (adds Newmark march; CORRECT a0 = M^{-1}(F0 - C v0 - K u0))
Everything uses the same C^1 Hermite basis and the same correctly-paired 4-pt Gauss.
"""
import numpy as np, sympy as sp
from scipy.special import roots_legendre
from scipy.linalg import lu_factor, lu_solve

T0 = 1.0
OM = sp.pi/4
OMf = float(OM)

xS, tS = sp.symbols('x t', real=True)
# Non-symmetric manufactured theta: degree-4 polynomial, homogeneous Dirichlet.
G = xS*(1-xS)*(1 + sp.Rational(9,10)*xS - sp.Rational(2,5)*xS**2)
fg   = sp.lambdify(xS, G, 'numpy')
fgx  = sp.lambdify(xS, G.diff(xS,1), 'numpy')
fGpp = sp.lambdify(xS, G.diff(xS,2), 'numpy')

# ---------------- quadrature sanity test (permanent, low-level) ----------------
def quadrature_sanity():
    """Fail loudly if the 4-pt rule cannot integrate polynomials up to degree 7."""
    ok = True
    for k in range(0, 8):
        exact = 1.0/(k+1)
        got = float(np.sum(GW*GP**k))
        if abs(got-exact) > 1e-12:
            ok = False; print(f"  [FAIL] int z^{k} = {got:.6e} != {exact}")
    print(f"  quadrature sanity: integrate z^0..z^7 exact -> {'PASS' if ok else 'FAIL'}")
    return ok

# ---------------- Hermite + Gauss ----------------
def hermite(z,h):
    z = np.asarray(z,float)
    B = np.vstack([1-3*z**2+2*z**3, h*(z-2*z**2+z**3), 3*z**2-2*z**3, h*(-z**2+z**3)])
    D = np.vstack([(-6*z+6*z**2)/h, 1-4*z+3*z**2, (6*z-6*z**2)/h, -2*z+3*z**2])
    return B,D
GP,GW = roots_legendre(4); GP = 0.5*(GP+1.0); GW = 0.5*GW

# ---------------- scalar theta system (2 DOF/node: value, slope) ----------------
def build(NE):
    h = 1.0/NE; NN = NE+1; NT = 2*NN
    dof = lambda n,k: 2*n+k
    B4,D4 = hermite(GP,h)
    M4 = h*(B4*GW)@B4.T          # int N_i N_j      (mass)
    C4 = M4                      # int N_i N_j      (damping th_t)
    K4 = h*(D4*GW)@D4.T          # int N'i N'j      (stiffness)
    MM = np.zeros((NT,NT)); CC = np.zeros((NT,NT)); KK = np.zeros((NT,NT))
    for e in range(NE):
        loc=[dof(e,0),dof(e,1),dof(e+1,0),dof(e+1,1)]
        MM[np.ix_(loc,loc)] += T0*M4
        CC[np.ix_(loc,loc)] += C4
        KK[np.ix_(loc,loc)] += K4
    pres = {dof(0,0):0.0, dof(NE,0):0.0}
    free = np.array([i for i in range(NT) if i not in pres]); pids=np.array(sorted(pres))
    return h,NN,NT,dof,MM,CC,KK,free,pids,B4

def intvec(NE,h,dof,B4, gfun):
    F = np.zeros(2*(NE+1))
    for e in range(NE):
        xa = e*h + GP*h
        F[[dof(e,0),dof(e,1),dof(e+1,0),dof(e+1,1)]] += h*(B4*GW)@gfun(xa)
    return F

def nodal(fx, t, NE, dof):
    y = np.zeros(2*(NE+1))
    xs = np.linspace(0,1,NE+1)
    for i,x in enumerate(xs):
        y[dof(i,0)] = float(fx(x,t)); y[dof(i,1)] = float(fx(x,t))  # (value, slope) same func: pass scalar
    return y

def norms(sol, NE, h, dof, t, fscale=lambda x:1.0):
    z6,w6 = roots_legendre(6); zg=0.5*(z6+1); wg=0.5*w6; B6,D6 = hermite(zg,h)
    e2=e1=0.0
    for e in range(NE):
        xa = e*h + zg*h
        d = np.array([sol[dof(e,0)],sol[dof(e,1)],sol[dof(e+1,0)],sol[dof(e+1,1)]])
        e2 += h*np.sum(wg*(B6.T@d - fg(xa)*fscale(xa))**2)
        e1 += h*np.sum(wg*(D6.T@d - fgx(xa)*fscale(xa))**2)
    return float(np.sqrt(e2)), float(np.sqrt(e1))

def orders(v):
    return [np.log(v[k]/v[k+1])/np.log(2) for k in range(len(v)-1)]

# ---------- E1: static Poisson  -th_xx = R ----------
def E1(LEVELS):
    print("\n[E1] STATIC Poisson:  -th_xx = R , R = -G''  (Dirichlet th(0)=th(1)=0)")
    R = sp.lambdify(xS, -G.diff(xS,2), 'numpy')
    rows=[]
    for NE in LEVELS:
        h,NN,NT,dof,MM,CC,KK,free,pids,B4 = build(NE)
        F = intvec(NE,h,dof,B4, R)
        sol = np.zeros(NT); sol[free] = np.linalg.solve(KK[np.ix_(free,free)], F[free])
        L2,H1 = norms(sol,NE,h,dof,0.0)
        rows.append((NE,L2,H1)); print(f"  NE={NE:4d}: L2={L2:.3e}  H1={H1:.3e}")
    print("  orders  L2:", ['%.2f'%o for o in orders([r[1] for r in rows])],
          " H1:", ['%.2f'%o for o in orders([r[2] for r in rows])])
    return rows

# ---------- E2: harmonic semidiscrete ----------
def E2(LEVELS, tstar=0.02):
    print(f"\n[E2] HARMONIC semidiscrete:  t0 th_tt + th_t - th_xx = R  at t*={tstar}")
    # R(x,t) = -w^2 G cos - ... : R = t0*(-w^2 G c) + (-w G s) ... separate cos/sin acts:
    # th*(x,t)=G(x)cos(wt) -> th_tt=-w^2 G c ; th_t=-w G s ; -th_xx = -G'' c
    Rc = sp.lambdify(xS, T0*(-OM**2)*G - G.diff(xS,2), 'numpy')    # cos part
    Rs = sp.lambdify(xS, -OM*G, 'numpy')                            # sin part
    c = np.cos(OMf*tstar); s = np.sin(OMf*tstar)
    rows=[]
    for NE in LEVELS:
        h,NN,NT,dof,MM,CC,KK,free,pids,B4 = build(NE)
        Fc = intvec(NE,h,dof,B4, Rc); Fs = intvec(NE,h,dof,B4, Rs)
        # exact nodal theta, th_t, th_tt at t*
        yb = np.zeros(NT); vb = np.zeros(NT); ab = np.zeros(NT)   # theta* (no x-deriv needed for M,C)
        xs = np.linspace(0,1,NE+1)
        for i,x in enumerate(xs):
            yb[dof(i,0)] = fg(x)*c;            yb[dof(i,1)] = fgx(x)*c
            vb[dof(i,0)] = -OMf*fg(x)*s;       vb[dof(i,1)] = -OMf*fgx(x)*s
            ab[dof(i,0)] = -OMf**2*fg(x)*c;    ab[dof(i,1)] = -OMf**2*fgx(x)*c
        RHS = Fc*c + Fs*s - MM@ab - CC@vb
        sol = np.zeros(NT); sol[free] = np.linalg.solve(KK[np.ix_(free,free)], RHS[free])
        L2,H1 = norms(sol,NE,h,dof,tstar, fscale=lambda x:np.cos(OMf*tstar)*np.ones_like(x))
        rows.append((NE,L2,H1)); print(f"  NE={NE:4d}: L2={L2:.3e}  H1={H1:.3e}")
    print("  orders  L2:", ['%.2f'%o for o in orders([r[1] for r in rows])],
          " H1:", ['%.2f'%o for o in orders([r[2] for r in rows])])
    return rows

# ---------- E3: harmonic transient (CORRECT a0) ----------
def E3(LEVELS, DT, TEND=0.02):
    print(f"\n[E3] HARMONIC transient (Newmark beta=1/4,gamma=1/2), DT={DT}, TEND={TEND}")
    Rc = sp.lambdify(xS, T0*(-OM**2)*G - G.diff(xS,2), 'numpy')
    Rs = sp.lambdify(xS, -OM*G, 'numpy')
    rows=[]
    for NE in LEVELS:
        h,NN,NT,dof,MM,CC,KK,free,pids,B4 = build(NE)
        Fc = intvec(NE,h,dof,B4, Rc); Fs = intvec(NE,h,dof,B4, Rs)
        u0 = np.zeros(NT); v0 = np.zeros(NT)
        xs = np.linspace(0,1,NE+1)
        for i,x in enumerate(xs):
            u0[dof(i,0)] = fg(x)*1.0; u0[dof(i,1)] = fgx(x)*1.0   # cos(0)=1
        uf = u0[free].copy(); vf = v0[free].copy()
        Mff=MM[np.ix_(free,free)]; Cff=CC[np.ix_(free,free)]; Kff=KK[np.ix_(free,free)]; Kfp=KK[np.ix_(free,pids)]
        up = np.zeros(len(pids))
        luM = lu_factor(Mff)                       # a0 solved with M  (CORRECTED)
        F0 = Fc*1.0 + Fs*0.0
        af = lu_solve(luM, F0[free]-Cff@vf-Kff@uf-Kfp@up)
        beta,gam = 0.25,0.5
        S = Mff + gam*DT*Cff + beta*DT**2*Kff
        luS = lu_factor(S)
        nsteps = int(round(TEND/DT))
        for n in range(1,nsteps+1):
            t = n*DT
            upr = uf + DT*vf + 0.25*DT**2*af; vpr = vf + 0.5*DT*af
            Fn = Fc*np.cos(OMf*t) + Fs*np.sin(OMf*t)
            an = lu_solve(luS, Fn[free]-Cff@vpr-Kff@upr-Kfp@up)
            vn = vpr + 0.5*DT*an; un = upr + 0.25*DT**2*an
            uf,vf,af = un,vn,an
        sol = np.zeros(NT); sol[free] = uf
        L2,H1 = norms(sol,NE,h,dof,TEND, fscale=lambda x:np.cos(OMf*TEND)*np.ones_like(x))
        rows.append((NE,L2,H1)); print(f"  NE={NE:4d}: L2={L2:.3e}  H1={H1:.3e}")
    print("  orders  L2:", ['%.2f'%o for o in orders([r[1] for r in rows])],
          " H1:", ['%.2f'%o for o in orders([r[2] for r in rows])])
    return rows

if __name__ == "__main__":
    quadrature_sanity()
    LEVELS=[16,32,64,128,256]
    E1(LEVELS)
    E2(LEVELS)
    E3([16,32,64,128], DT=2.5e-6)
