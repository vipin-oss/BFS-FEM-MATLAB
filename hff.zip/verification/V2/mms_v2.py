#!/usr/bin/env python3
"""
PHASE-1 V2 — Temporal-order verification (JV2, 1-D) — FINAL.

MGT Thermoelasticity C^1 BFS-FEM project.

FROZEN AUTHORITY (verbatim definition/gate — not modified):
  * Blueprint J.3 JV2:  "Time order: manufactured evolution; halve Δt;
                         measured order ≈ p."
  * Blueprint §2.10:    "Fixed fine h, Δt → Δt/2: measured time order ≈ p."
  * Blueprint §4.5 gate: "Time-convergence order | measured ≈ p (≥ p−0.1) |
                          Definitional (consistency)."
  * G2a: JV1 order ≥ theoretical − 0.1; V2 ≡ JV2 (time order) feeds G2a.
  * PHASE1_EXECUTION_BASELINE: time integration "consistent Galerkin, order
    p∈{1,2} — p OPEN (D1)"; the implemented scheme (pilot + V1, recorded [I] in
    PHASE1_DERIVATION_RECORD DR#9) is Newmark β=1/4, γ=1/2 (trapezoidal /
    average acceleration) on the second-order state → THEORETICAL p = 2.
  => FROZEN GATE for this run: measured temporal order ≈ 2  (≥ 2 − 0.1 = 1.9).

DESIGN (strictly per Blueprint §2.10 — spatial error must not contaminate):
  * ONE fixed fine mesh NE=256 (h=1/256). Semidiscrete spatial floor at T is
    measured first and compared against every transient error: a transient error
    is "temporally dominated" only where it is well above the spatial floor.
  * Δt halving sequence Δt = 0.08, 0.04, 0.02, 0.01, 0.005, 0.0025 (all divide
    T=4.0 exactly), same problem, same norm, same exact manufactured forcing.
  * No spatial refinement is mixed in: NE is fixed throughout.

MANUFACTURED SOLUTION — the frozen V1 MMS (unchanged; NOT switched after results):
    u*(x,t)  = x²(1−x)²(1 + 0.5 x) · cos(Ωt),   Ω = π/4
    th*(x,t) = x(1−x)(1 + 0.4 x + 0.3 x²) · cos(Ωt)
  Homogeneous Dirichlet data exactly zero; smooth, non-symmetric.
  Forcing (analytical, SymPy — never via FEM matrices):
    R_u  = u*_tt − u*_xx + θ*_x
    R_θ  = t₀(θ*_tt + ξ u*_xtt) + (θ*_t + ξ u*_xt) − θ*_xx,  ξ=0.05, t₀=1.

IMPLEMENTATION: REUSES the verified V1 formulation verbatim (imported from
verification/V1/mms_v1.py — the same Hermite basis, the same scipy
roots_legendre 4-pt Gauss, the same element matrices, the same assembly). The
only V2-specific code here is the Δt-refinement driver and the consistency
controls. CONSISTENT initial acceleration a0 = M⁻¹(F(0) − C v0 − K u0).

CONTROLS printed at every run: (a) consistent-a0 residual; (b) quadrature
sanity; (c) essential-BC pins; (d) ICs = exact manufactured at t=0; (e) no
NaN/Inf; (f) forcing built ONCE and shared by every Δt level (unchanged).

CLASSIFICATION CONTROL (authorized): a single ξ=0 run with SELF-CONSISTENT
sources (ξ=0 is an authorized parameter value of the frozen operator — the
uncoupled limit). It is used ONLY to classify the fine-Δt H¹(θ) behavior
correctly (per the V2 directive: never infer order from a flat/stopped sequence
and never mislabel coupling feedback as spatial contamination). It is NOT a
reopening of the V1 θ-anomaly investigation (V1 is CLOSED): it is a one-line
limiting-parameter control already authorized by the model ladder.

SCOPE: V2 / JV2 ONLY. Not V3/V4/V5/V6, not validation, not a convergence study
beyond the frozen JV2 prescription, not C¹-vs-C⁰, not a parameter study.
"""
import os
import sys
import json
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "V1"))

# The verified V1 primitives (unchanged):
from mms_v1 import (assemble, residual_vectors, exact_nodal, norms,
                    quadrature_sanity, OMf, T0, XI)   # noqa: E402
from scipy.special import roots_legendre               # noqa: E402
from scipy.linalg import lu_factor, lu_solve           # noqa: E402
import sympy as sp                                     # noqa: E402

# ---------------- frozen V2 configuration ----------------
NE   = 256          # FIXED fine mesh (h = 1/256); spatial order is NOT refined here
T    = 4.0          # final evaluation time (all runs march to the same T)
DTS  = [0.08, 0.04, 0.02, 0.01, 0.005, 0.0025]   # halving sequence (divides T exactly)
BETA, GAMMA = 0.25, 0.5                          # Newmark trapezoidal → theoretical p = 2
GATE = 1.9          # frozen: measured order ≥ p − 0.1 = 2 − 0.1

def march(NE, DT, TEND, MM, CC, KK, Fc, Fs, free, pids):
    """Newmark β=¼, γ=½; consistent a0 = M⁻¹(F(0)−C v0−K u0). Returns (norms, NaN_flag)."""
    h, NN, ND, dof = 1.0/NE, NE+1, 4*(NE+1), (lambda n, f, k: 4*n+2*f+k)
    u0, v0, a0e = exact_nodal(NE, 0.0)
    up = np.zeros(ND); up[pids] = u0[pids]
    uf = u0[free].copy(); vf = v0[free].copy()
    Mff = MM[np.ix_(free, free)]; Cff = CC[np.ix_(free, free)]
    Kff = KK[np.ix_(free, free)]; Kfp = KK[np.ix_(free, pids)]
    F0 = Fc[free]   # Fs[free] is ~0 at t=0 (sin part); a0 uses full F(0)=Fc
    af = lu_solve(lu_factor(Mff), F0 - Cff@vf - Kff@uf - Kfp@up[pids])
    a0res = np.linalg.norm(Mff@af + Cff@vf + Kff@uf + Kfp@up[pids] - F0, np.inf)
    S = Mff + GAMMA*DT*Cff + BETA*DT**2*Kff
    luS = lu_factor(S)
    nan = False
    for k in range(1, int(round(TEND/DT))+1):
        t = k*DT
        upr = uf + DT*vf + BETA*DT**2*af
        vpr = vf + GAMMA*DT*af
        Fn = Fc[free]*np.cos(OMf*t) + Fs[free]*np.sin(OMf*t)
        an = lu_solve(luS, Fn - Cff@vpr - Kff@upr - Kfp@up[pids])
        vn = vpr + GAMMA*DT*an; un = upr + BETA*DT**2*an
        uf, vf, af = un, vn, an
        if not np.all(np.isfinite(un)): nan = True; break
    sol = np.zeros(ND); sol[free] = uf
    return norms(sol, NE, h, dof, TEND), nan, a0res

def semidiscrete_floor(NE, MM, CC, KK, Fc, Fs, free):
    """Exact spatial identity K u_h = F − M ü* − C u̇* at time T (zero time error)."""
    h, NN, ND, dof = 1.0/NE, NE+1, 4*(NE+1), (lambda n, f, k: 4*n+2*f+k)
    ye, ve, ae = exact_nodal(NE, T)
    c, s = np.cos(OMf*T), np.sin(OMf*T)
    RHS = Fc*c + Fs*s - MM@ae - CC@ve
    sol = np.zeros(ND); sol[free] = np.linalg.solve(KK[np.ix_(free, free)], RHS[free])
    return norms(sol, NE, h, dof, T)

def orders(v):
    return [np.log(v[k]/v[k+1])/np.log(2.0) for k in range(len(v)-1)]

# =====================================================================
# MAIN (frozen case ξ = 0.05, fixed NE=256, Δt halving)
# =====================================================================
def main():
    np.set_printoptions(precision=6, suppress=False)
    quadrature_sanity()

    h, NN, ND, dof, MM, CC, KK, free, pids, B4 = assemble(NE)
    Fc, Fs = residual_vectors(NE, h, dof, B4)

    # ---- control (f): forcing built once, shared by all Δt levels ----
    fC = float(np.linalg.norm(Fc, np.inf)); fS = float(np.linalg.norm(Fs, np.inf))
    print(f"  [forcing] built once; ||Fc||inf={fC:.6e} ||Fs||inf={fS:.6e} (identical for every Δt)")

    # ---- spatial floor ----
    floor = semidiscrete_floor(NE, MM, CC, KK, Fc, Fs, free)
    print("  [spatial floor] semidiscrete at T=%.1f, NE=%d: L2u=%.3e L2t=%.3e H1u=%.3e H1t=%.3e"
          % (T, NE, *floor))

    # ---- transient Δt sequence ----
    rows = []
    for DT in DTS:
        E, nan, a0res = march(NE, DT, T, MM, CC, KK, Fc, Fs, free, pids)
        rows.append((DT,) + E + (a0res, nan))
        print(f"  DT={DT:.5f}: L2u={E[0]:.3e} L2t={E[1]:.3e} H1u={E[2]:.3e} H1t={E[3]:.3e} "
              f"a0res={a0res:.2e} NaN={nan}")

    cols = ["DT","L2_u","L2_th","H1_u","H1_th"]
    E = {c: [r[i+1] for r in rows] for i, c in enumerate(cols[1:])}
    O = {c: orders(E[c]) for c in cols[1:]}

    print("\nV2 TEMPORAL-ORDER TABLE (fixed NE=256 h=1/256, T=4.0, Newmark beta=0.25 gamma=0.5):")
    print("   " + " | ".join(f"{c:>10}" for c in cols + ["ord?"]))
    for k, r in enumerate(rows):
        o = " | ".join("%9.3f" % O[c][k] for c in cols[1:]) if k < len(rows)-1 else " | ".join("        -" for _ in cols[1:])
        print("   " + " | ".join([f"{r[0]:>10.5f}"] + [f"{r[i+1]:>10.3e}" for i in range(4)]) + " | " + o)

    # ---- classification control: xi=0 (self-consistent sources) ----
    print("\nCLASSIFICATION CONTROL (xi=0 uncoupled limit; self-consistent sources):")
    ctrl = xi0_control()
    for line in ctrl: print("   " + line)

    # ---- gate ----
    # Primary gate quantities: L2(u), L2(th) across ALL halvings; H1(u) across its
    # floor-free halvings; H1(th) across its coupling-feedback-free halvings.
    def first_bad(o):
        for k, x in enumerate(o):
            if x < GATE: return k
        return None
    res = {}
    for c in ["L2_u", "L2_th", "H1_u", "H1_th"]:
        fb = first_bad(O[c])
        res[c] = "PASS" if fb is None else f"order@{fb}->{O[c][fb]:.3f}"
    print("\nGATE (frozen): measured temporal order >= 2-0.1 = 1.9, per halving.")
    for c in ["L2_u", "L2_th", "H1_u", "H1_th"]:
        print(f"   {c}: observed orders {['%.3f'%x for x in O[c]]}  -> {res[c]}")

    outdir = os.path.join(HERE)
    with open(os.path.join(outdir, "v2_error_table.csv"), "w") as f:
        f.write("NE,fixed=256,h=%.6f,T=4.0\n" % (1.0/NE))
        f.write(",".join(cols) + ",a0_res_inf,NaN\n")
        for r in rows:
            f.write("%.6f,%.8e,%.8e,%.8e,%.8e,%.2e,%s\n" % r)
    manifest = {
        "task": "V2 / JV2 temporal-order verification",
        "authority": "Blueprint J.3 JV2; §2.10; §4.5 gate measured≈p (≥p−0.1); G2a",
        "theoretical_p": 2, "integrator": "Newmark beta=0.25 gamma=0.5 (trapezoidal)",
        "gate": GATE,
        "manufactured_u": "x^2(1-x)^2(1+0.5x) cos(pi t/4)",
        "manufactured_theta": "x(1-x)(1+0.4x+0.3x^2) cos(pi t/4)",
        "forcing": "R_u=u*_tt-u*_xx+th*_x ; R_th=t0(th*_tt+xi u*_xtt)+(th*_t+xi u*_xt)-th*_xx",
        "xi": 0.05, "t0": 1.0,
        "NE_fixed": NE, "h": 1.0/NE, "T": T,
        "dt_sequence": DTS,
        "spatial_floor": list(float(x) for x in floor),
        "norm": "L2 and H1 vs manufactured fields (6-pt Gauss error integration)",
        "results": {c: { "errors": E[c], "orders": O[c] } for c in cols[1:]},
        "classification_control_xi0": ctrl,
    }
    with open(os.path.join(outdir, "v2_manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)
    print("\n   -> verification/V2/v2_error_table.csv and v2_manifest.json written.")

def xi0_control():
    """Single limiting-parameter run with self-consistent forcing (xi=0)."""
    xS = sp.symbols('x', real=True)
    P  = xS**2*(1-xS)**2*(1+sp.Rational(1,2)*xS)
    G  = xS*(1-xS)*(1+sp.Rational(2,5)*xS+sp.Rational(3,10)*xS**2)
    OM = sp.pi/4
    Ruc = sp.lambdify(xS, -(OM**2)*P - P.diff(xS,2) + G.diff(xS,1), 'numpy')
    Rtc = sp.lambdify(xS, T0*(-(OM**2)*G) - G.diff(xS,2), 'numpy')   # xi=0: xi-terms drop
    Rts = sp.lambdify(xS, -OM*G, 'numpy')
    h = 1.0/NE; NN = NE+1; ND = 4*NN
    dof = lambda n,f,k: 4*n+2*f+k
    GP, GW = roots_legendre(4); GP = 0.5*(GP+1.0); GW = 0.5*GW
    B4, D4 = (lambda z,hh: (np.vstack([1-3*z**2+2*z**3, hh*(z-2*z**2+z**3),
                                       3*z**2-2*z**3, hh*(-z**2+z**3)]),
                            np.vstack([(-6*z+6*z**2)/hh, 1-4*z+3*z**2,
                                       (6*z-6*z**2)/hh, -2*z+3*z**2])))(GP, h)
    M4 = h*(B4*GW)@B4.T; K4 = h*(D4*GW)@D4.T; E = h*(B4*GW)@D4.T
    MM = np.zeros((ND,ND)); CC = np.zeros((ND,ND)); KK = np.zeros((ND,ND))
    for e in range(NE):
        loc = [dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1),
               dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]
        u4 = slice(0,4); t4 = slice(4,8)
        MM[np.ix_(loc[u4],loc[u4])] += M4
        MM[np.ix_(loc[t4],loc[t4])] += T0*M4
        CC[np.ix_(loc[t4],loc[t4])] += M4
        KK[np.ix_(loc[u4],loc[u4])] += K4
        KK[np.ix_(loc[u4],loc[t4])] += -E.T
        KK[np.ix_(loc[t4],loc[t4])] += K4
    Fc = np.zeros(ND); Fs = np.zeros(ND)
    for e in range(NE):
        xa = e*h + GP*h
        uu = [dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1)]
        tt = [dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]
        Fc[uu] += h*(B4*GW)@Ruc(xa)
        Fc[tt] += h*(B4*GW)@Rtc(xa); Fs[tt] += h*(B4*GW)@Rts(xa)
    pres = {dof(0,0,0):0.,dof(NE,0,0):0.,dof(0,1,0):0.,dof(NE,1,0):0.}
    free = np.array([i for i in range(ND) if i not in pres]); pids = np.array(sorted(pres))
    out = []
    for DT in [0.02, 0.01, 0.005, 0.0025, 0.00125]:
        E, nan, a0res = march(NE, DT, T, MM, CC, KK, Fc, Fs, free, pids)
        out.append(f"xi=0 DT={DT:.5f}: L2u={E[0]:.3e} L2t={E[1]:.3e} H1u={E[2]:.3e} H1t={E[3]:.3e} NaN={nan}")
    return out

if __name__ == "__main__":
    main()
