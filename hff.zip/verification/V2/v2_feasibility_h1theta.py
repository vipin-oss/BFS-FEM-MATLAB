#!/usr/bin/env python3
"""
V2/JV2 FEASIBILITY INVESTIGATION — H1(theta) temporal-order recovery at xi=0.05.

NOT an acceptance test. NO gate verdict, NO PASS/FAIL, NO chain of authority
modification. This is feasibility evidence only.

Approach (strictly the authorized extension):
  * Identical solver/code path as the authoritative V2 run: it IMPORTS the
    exact same primitives (mms_v2.march, mms_v2.assemble, mms_v2.residual_vectors,
    mms_v2.semidiscrete_floor -> which internally use verification/V1/mms_v1.py).
  * Same manufactured fields, same strong-form sources, xi=0.05, NE=256,
    Newmark beta=1/4 gamma=1/2, consistent a0, same quadrature, T=4.0, same norms.
  * ONLY the time step is extended: 0.00125 and 0.000625 are appended to the
    existing halving sequence.
  * Reproducibility: the six previously reported DT values are re-computed and
    compared against the recorded V2 table values before any conclusion.

The xi=0 run is included ONLY as a diagnostic comparison (per instruction), never
as an acceptance substitute.
"""
import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import mms_v2 as V2               # the authoritative V2 code path (unchanged)
from mms_v1 import hermite        # the same basis used inside mms_v2/assemble
from scipy.special import roots_legendre
from scipy.linalg import lu_factor, lu_solve
import sympy as sp

# ---- recorded authoritative V2 table (from PHASE1_V2_REPORT.md / v2_error_table.csv) ----
RECORDED = {
    0.08000: (4.181e-06, 1.086e-05, 1.364e-05, 3.414e-05),
    0.04000: (1.047e-06, 2.718e-06, 3.409e-06, 8.543e-06),
    0.02000: (2.618e-07, 6.796e-07, 8.525e-07, 2.139e-06),
    0.01000: (6.546e-08, 1.699e-07, 2.135e-07, 5.479e-07),
    0.00500: (1.637e-08, 4.247e-08, 5.461e-08, 1.746e-07),
    0.00250: (4.100e-09, 1.062e-08, 1.785e-08, 1.023e-07),
}
DT_ORDERED = [0.08, 0.04, 0.02, 0.01, 0.005, 0.0025, 0.00125, 0.000625]

def orders(v):
    return [np.log(v[k]/v[k+1])/np.log(2.0) for k in range(len(v)-1)]

def main():
    V2.quadrature_sanity()
    NE, T = V2.NE, V2.T
    h, NN, ND, dof, MM, CC, KK, free, pids, B4 = V2.assemble(NE)
    Fc, Fs = V2.residual_vectors(NE, h, dof, B4)
    floor = V2.semidiscrete_floor(NE, MM, CC, KK, Fc, Fs, free)
    print(f"[spatial floor, T=4, NE=256] L2u={floor[0]:.3e} L2t={floor[1]:.3e} "
          f"H1u={floor[2]:.3e} H1t={floor[3]:.3e}")

    print("\nReproducibility check (existing DT values vs recorded V2 table):")
    E = {d: None for d in DT_ORDERED}
    for DT in DT_ORDERED:
        e, nan, a0res = V2.march(NE, DT, T, MM, CC, KK, Fc, Fs, free, pids)
        E[DT] = e
        if DT in RECORDED:
            dev = [abs(e[k]-RECORDED[DT][k]) for k in range(4)]
            md = max(dev)
            flag = "OK" if md < 1e-6*max(1.0, max(RECORDED[DT])) else "MISMATCH"
            print(f"  DT={DT:.5f} max|dev|={md:.2e}  [{flag}]  a0res={a0res:.1e} NaN={nan}")

    print("\nEXTENDED TABLE (xi=0.05, NE=256, T=4.0):")
    print(f"   {'DT':>9} | {'L2(u)':>10} | {'L2(th)':>10} | {'H1(u)':>10} | {'H1(th)':>10}")
    for DT in DT_ORDERED:
        e = E[DT]
        print(f"   {DT:9.5f} | {e[0]:10.3e} | {e[1]:10.3e} | {e[2]:10.3e} | {e[3]:10.3e}")

    names = ["L2_u", "L2_th", "H1_u", "H1_th"]
    OE = {n: orders([E[d][i] for d in DT_ORDERED]) for i, n in enumerate(names)}
    print("\nObserved orders over the FULL 8-point sequence (per halving):")
    for i, d in enumerate(DT_ORDERED[:-1]):
        print(f"   {d:.5f}->{DT_ORDERED[i+1]:.5f}: " +
              "  ".join(f"{n}={OE[n][i]:.3f}" for n in names))

    # ---- H1(theta) tail: plateau decomposition ----
    print("\nH1(theta) tail analysis (is the slowdown a plateau P, or a recovery?):")
    t1, t2, t3, t4 = ((0.005, 0.0025, 0.00125, 0.000625))
    e1, e2 = E[t1][3], E[t2][3]
    e3, e4 = E[t3][3], E[t4][3]
    # model E = C dt^2 + P from the finest two pairs, check constancy of P
    def P_from(a_lo, e_lo, a_hi, e_hi):   # dt_hi = 2*dt_lo
        C = (e_hi - e_lo) / (a_hi**2 - a_lo**2)
        return e_hi - C * a_hi**2, C
    P23, C23 = P_from(t2, e2, t1, e1)
    P34, C34 = P_from(t3, e3, t2, e2)
    P45, C45 = P_from(t4, e4, t3, e3)
    print(f"   pair(0.0025,0.005 ) -> P={P23:.3e}, C={C23:.3e}")
    print(f"   pair(0.00125,0.0025)-> P={P34:.3e}, C={C34:.3e}")
    print(f"   pair(0.000625,0.00125)-> P={P45:.3e}, C={C45:.3e}")
    print(f"   H1(th) spatial floor = {floor[3]:.3e}")

    # ---- diagnostic comparison: xi=0 (self-consistent) at the same fine DT ----
    print("\nDiagnostic comparison (xi=0, self-consistent sources, same assemble/march):")
    for line in xi0_extended(NE, T):
        print("   " + line)

    # write a small result CSV for this investigation
    with open(os.path.join(HERE, "v2_feasibility_h1theta.csv"), "w") as f:
        f.write("DT,L2_u,L2_th,H1_u,H1_th\n")
        for DT in DT_ORDERED:
            f.write("%.6f,%e,%e,%e,%e\n" % (DT, *E[DT]))
    print("\n   -> verification/V2/v2_feasibility_h1theta.csv written.")

def xi0_extended(NE, T):
    """xi=0 reproduction with self-consistent sources; diagnostic only."""
    xS = sp.symbols('x', real=True)
    P  = xS**2*(1-xS)**2*(1+sp.Rational(1,2)*xS)
    G  = xS*(1-xS)*(1+sp.Rational(2,5)*xS+sp.Rational(3,10)*xS**2)
    OM = sp.pi/4
    Ruc = sp.lambdify(xS, -(OM**2)*P - P.diff(xS,2) + G.diff(xS,1), 'numpy')
    Rtc = sp.lambdify(xS, V2.T0*(-(OM**2)*G) - G.diff(xS,2), 'numpy')
    Rts = sp.lambdify(xS, -OM*G, 'numpy')
    h = 1.0/NE; NN = NE+1; ND = 4*NN
    dof = lambda n,f,k: 4*n+2*f+k
    GP, GW = roots_legendre(4); GP = 0.5*(GP+1.0); GW = 0.5*GW
    B4, D4 = hermite(GP, h)
    M4 = h*(B4*GW)@B4.T; K4 = h*(D4*GW)@D4.T; E4 = h*(B4*GW)@D4.T
    MM = np.zeros((ND,ND)); CC = np.zeros((ND,ND)); KK = np.zeros((ND,ND))
    for e in range(NE):
        loc = [dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1),
               dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]
        u4 = slice(0,4); t4 = slice(4,8)
        MM[np.ix_(loc[u4],loc[u4])] += M4
        MM[np.ix_(loc[t4],loc[t4])] += V2.T0*M4
        CC[np.ix_(loc[t4],loc[t4])] += M4
        KK[np.ix_(loc[u4],loc[u4])] += K4
        KK[np.ix_(loc[u4],loc[t4])] += -E4.T
        KK[np.ix_(loc[t4],loc[t4])] += K4
    Fc = np.zeros(ND); Fs = np.zeros(ND)
    for e in range(NE):
        xa = e*h + GP*h
        uu = [dof(e,0,0),dof(e,0,1),dof(e+1,0,0),dof(e+1,0,1)]
        tt = [dof(e,1,0),dof(e,1,1),dof(e+1,1,0),dof(e+1,1,1)]
        Fc[uu] += h*(B4*GW)@Ruc(xa)
        Fc[tt] += h*(B4*GW)@Rtc(xa); Fs[tt] += h*(B4*GW)@Rts(xa)
    pres = {dof(0,0,0):0.,dof(NE,0,0):0.,dof(0,1,0):0.,dof(NE,1,0):0.}
    free = np.array([i for i in range(ND) if i not in pres]); pids = np.array(sorted(pres))
    out = []
    for DT in [0.005, 0.0025, 0.00125, 0.000625]:
        e, nan, a0res = V2.march(NE, DT, T, MM, CC, KK, Fc, Fs, free, pids)
        out.append(f"xi=0 DT={DT:.5f}: L2u={e[0]:.3e} L2t={e[1]:.3e} H1u={e[2]:.3e} H1t={e[3]:.3e} NaN={nan}")
    return out

if __name__ == "__main__":
    main()
