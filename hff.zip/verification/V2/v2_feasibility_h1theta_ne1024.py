#!/usr/bin/env python3
"""
V2/JV2 FEASIBILITY — THIRD FIXED-h CHECK (NE=1024).

Determine whether the H1(theta) temporal-order trajectory continues moving
toward p=2 as h is reduced (NE 256 -> 512 -> 1024).

Same code path as the authoritative V2 run (imports mms_v2 -> verification/V1/mms_v1.py).
Everything fixed except NE (1024) and the required DT sequence. xi=0 diagnostic only.
NOT an acceptance test: no gate verdict, no PASS/FAIL.
"""
import os, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import mms_v2 as V2

T = 4.0
DTS = [0.0025, 0.00125, 0.000625, 0.0003125]

# recorded NE=256 (authoritative V2 + first extension) and NE=512 (second check)
NE256 = {
    0.0025:  (4.100e-09, 1.062e-08, 1.785e-08, 1.023e-07),
    0.00125: (1.031e-09, 2.654e-09, 1.231e-08, 7.107e-08),
    0.000625:(2.645e-10, 6.642e-10, 1.187e-08, 5.610e-08),
    0.0003125: None,
}
NE512 = {
    0.0025:  (4.091e-09, 1.062e-08, 1.340e-08, 3.866e-08),
    0.00125: (1.023e-09, 2.655e-09, 3.647e-09, 1.856e-08),
    0.000625:(2.562e-10, 6.636e-10, 1.701e-09, 1.218e-08),
    0.0003125: None,
}
NE256_floor = (7.328e-12, 1.526e-12, 1.184e-08, 2.463e-09)
NE512_floor = (6.341e-13, 1.027e-13, 1.483e-09, 3.082e-10)

def main():
    V2.quadrature_sanity()
    NE = 1024
    h, NN, ND, dof, MM, CC, KK, free, pids, B4 = V2.assemble(NE)
    Fc, Fs = V2.residual_vectors(NE, h, dof, B4)
    floor = V2.semidiscrete_floor(NE, MM, CC, KK, Fc, Fs, free)
    print(f"[NE=1024 spatial floor, T=4] L2u={floor[0]:.3e} L2t={floor[1]:.3e} "
          f"H1u={floor[2]:.3e} H1t={floor[3]:.3e}")

    E = {}
    for DT in DTS:
        e, nan, a0res = V2.march(NE, DT, T, MM, CC, KK, Fc, Fs, free, pids)
        E[DT] = e
        print(f"  NE=1024 DT={DT:.7f}: L2u={e[0]:.3e} L2t={e[1]:.3e} H1u={e[2]:.3e} "
              f"H1t={e[3]:.3e} a0res={a0res:.1e} NaN={nan}", flush=True)

    with open(os.path.join(HERE,"v2_feasibility_h1theta_ne1024.csv"),"w") as f:
        f.write("NE,DT,L2_u,L2_th,H1_u,H1_th\n")
        for DT in DTS:
            f.write("1024,%.7f,%e,%e,%e,%e\n" % (DT,*E[DT]))
    print("\n   -> verification/V2/v2_feasibility_h1theta_ne1024.csv written.", flush=True)

    names = ["L2_u","L2_th","H1_u","H1_th"]
    print("\nNE=1024 observed orders (per halving):")
    for k in range(len(DTS)-1):
        print(f"   {DTS[k]:.7f}->{DTS[k+1]:.7f}: " +
              "  ".join(f"{n}={np.log(E[DTS[k]][i]/E[DTS[k+1]][i])/np.log(2):.3f}"
                        for i,n in enumerate(names)))

    print("\nH1(theta) across NE=256 / 512 / 1024 (order per halving in parens):")
    print(f"   {'DT':>10} | {'NE256 H1t':>11} | {'NE512 H1t':>11} | {'NE1024 H1t':>11}")
    for k,DT in enumerate(DTS):
        r256 = NE256[DT][3] if NE256[DT] else None
        r512 = NE512[DT][3] if NE512[DT] else None
        s256 = f"{r256:.3e}" if r256 is not None else "        -"
        s512 = f"{r512:.3e}" if r512 is not None else "        -"
        print(f"   {DT:10.7f} | {s256:>11} | {s512:>11} | {E[DT][3]:11.3e}")

    print("\nH1(theta) pairwise temporal order vs NE:")
    print(f"   {'pair':>24} | {'NE256':>8} | {'NE512':>8} | {'NE1024':>8}")
    pairs = [(DTS[k], DTS[k+1]) for k in range(len(DTS)-1)]
    for lo,hi in pairs:
        def od(d):
            a = d[lo]; b = d[hi]
            return None if (a is None or b is None) else np.log(a[3]/b[3])/np.log(2)
        o256 = od(NE256); o512 = od(NE512); o1024 = np.log(E[lo][3]/E[hi][3])/np.log(2)
        print(f"   {lo:.7f}->{hi:.7f} | {('%.3f'%o256) if o256 is not None else '  -':>8} | {('%.3f'%o512) if o512 is not None else '  -':>8} | {o1024:8.3f}")

    print("\nSupporting quantities at NE=1024 vs NE=512 (L2 and H1(u)):")
    for k,DT in enumerate(DTS):
        def fmt(d):
            return f"{d:.3e}" if d is not None else "        -"
        print(f"   DT={DT:.7f}: L2u {fmt(NE512[DT][0] if NE512[DT] else None)} -> {E[DT][0]:.3e} | "
              f"L2t {fmt(NE512[DT][1] if NE512[DT] else None)} -> {E[DT][1]:.3e} | "
              f"H1u {fmt(NE512[DT][2] if NE512[DT] else None)} -> {E[DT][2]:.3e}")

    print("\nH1(theta)/spatial-floor ratio (fine-Δt):")
    for DT in DTS:
        r256 = f"{NE256[DT][3]/NE256_floor[3]:8.1f}" if NE256[DT] else "        -"
        r512 = f"{NE512[DT][3]/NE512_floor[3]:8.1f}" if NE512[DT] else "        -"
        print(f"   DT={DT:.7f}: NE256 {r256} | NE512 {r512} | NE1024 {E[DT][3]/floor[3]:8.1f}")

    with open(os.path.join(HERE,"v2_feasibility_h1theta_ne1024_summary.txt"),"w") as f:
        f.write(f"floor NE=1024: L2u={floor[0]:.3e} L2t={floor[1]:.3e} H1u={floor[2]:.3e} H1t={floor[3]:.3e}\n")
        for DT in DTS:
            f.write(f"NE=1024 DT={DT:.7f}: L2u={E[DT][0]:.3e} L2t={E[DT][1]:.3e} H1u={E[DT][2]:.3e} H1t={E[DT][3]:.3e}\n")
    print("\n   -> verification/V2/v2_feasibility_h1theta_ne1024_summary.txt written.")

if __name__ == "__main__":
    main()
