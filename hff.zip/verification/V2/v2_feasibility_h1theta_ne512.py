#!/usr/bin/env python3
"""
V2/JV2 FEASIBILITY — SECOND FIXED-h CHECK (NE=512).

Purpose: determine whether the H1(theta) temporal-order slowdown is h-dependent
(coupling/spatial contamination) or a genuine temporal-order limitation.

Same code path as the authoritative V2 run (imports mms_v2 -> verification/V1/mms_v1.py).
Everything fixed except NE (256 -> 512) and the required DT sequence.

NOT an acceptance test: no gate verdict, no PASS/FAIL, xi=0 diagnostic only.
"""
import os, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import mms_v2 as V2

T = 4.0
DTS = [0.005, 0.0025, 0.00125, 0.000625]

# recorded NE=256 values (authoritative V2 table + first feasibility extension)
NE256 = {
    0.005:   (1.637e-08, 4.247e-08, 5.461e-08, 1.746e-07),
    0.0025:  (4.100e-09, 1.062e-08, 1.785e-08, 1.023e-07),
    0.00125: (1.031e-09, 2.654e-09, 1.231e-08, 7.107e-08),
    0.000625:(2.645e-10, 6.642e-10, 1.187e-08, 5.610e-08),
}
NE256_floor = (7.328e-12, 1.526e-12, 1.184e-08, 2.463e-09)

def orders(v):
    return [np.log(v[k]/v[k+1])/np.log(2.0) for k in range(len(v)-1)]

def main():
    V2.quadrature_sanity()
    NE = 512
    h, NN, ND, dof, MM, CC, KK, free, pids, B4 = V2.assemble(NE)
    Fc, Fs = V2.residual_vectors(NE, h, dof, B4)
    floor = V2.semidiscrete_floor(NE, MM, CC, KK, Fc, Fs, free)
    print(f"[NE=512 spatial floor, T=4] L2u={floor[0]:.3e} L2t={floor[1]:.3e} "
          f"H1u={floor[2]:.3e} H1t={floor[3]:.3e}   (NE=256 floor was H1u=1.184e-08 H1t=2.463e-09)")

    E = {}
    for DT in DTS:
        e, nan, a0res = V2.march(NE, DT, T, MM, CC, KK, Fc, Fs, free, pids)
        E[DT] = e
        print(f"  NE=512 DT={DT:.6f}: L2u={e[0]:.3e} L2t={e[1]:.3e} H1u={e[2]:.3e} "
              f"H1t={e[3]:.3e} a0res={a0res:.1e} NaN={nan}")

    names = ["L2_u","L2_th","H1_u","H1_th"]
    print("\nNE=512 observed orders (per halving):")
    for k in range(len(DTS)-1):
        print(f"   {DTS[k]:.6f}->{DTS[k+1]:.6f}: " +
              "  ".join(f"{n}={np.log(E[DTS[k]][i]/E[DTS[k+1]][i])/np.log(2):.3f}"
                        for i,n in enumerate(names)))

    print("\nNE=256 vs NE=512 comparison (H1_theta featured):")
    print(f"   {'DT':>9} | {'NE256 H1t':>11} | {'NE512 H1t':>11} | {'ratio':>7} | "
          f"{'NE256 ord':>9} | {'NE512 ord':>9}")
    for k,DT in enumerate(DTS):
        r = NE256[DT][3]/E[DT][3]
        o256 = "" if k==0 else f"{np.log(NE256[DTS[k-1]][3]/NE256[DT][3])/np.log(2):.3f}"
        o512 = "" if k==0 else f"{np.log(E[DTS[k-1]][3]/E[DT][3])/np.log(2):.3f}"
        print(f"   {DT:9.6f} | {NE256[DT][3]:11.3e} | {E[DT][3]:11.3e} | {r:7.2f} | {o256:>9} | {o512:>9}")

    print("\nH1(u) and L2(th) comparison (supporting):")
    for DT in DTS:
        print(f"   DT={DT:.6f}: NE256 H1u={NE256[DT][2]:.3e} vs NE512 H1u={E[DT][2]:.3e} | "
              f"NE256 L2t={NE256[DT][1]:.3e} vs NE512 L2t={E[DT][1]:.3e} | "
              f"NE256 L2u={NE256[DT][0]:.3e} vs NE512 L2u={E[DT][0]:.3e}")

    # h-dependence of the H1(theta) fine-DT plateau: is it h^3 (coupling contamination)?
    print("\nH1(theta) endpoint vs spatial floor:")
    for DT in DTS:
        print(f"   DT={DT:.6f}: NE256 H1t/floor={NE256[DT][3]/NE256_floor[3]:8.1f}   "
              f"NE512 H1t/floor={E[DT][3]/floor[3]:8.1f}")

    with open(os.path.join(HERE,"v2_feasibility_h1theta_ne512.csv"),"w") as f:
        f.write("NE,DT,L2_u,L2_th,H1_u,H1_th\n")
        for DT in DTS:
            f.write("512,%.6f,%e,%e,%e,%e\n" % (DT,*E[DT]))
    print("\n   -> verification/V2/v2_feasibility_h1theta_ne512.csv written.")

if __name__ == "__main__":
    main()
