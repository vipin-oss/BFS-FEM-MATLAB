#!/usr/bin/env python3
"""
V3 DIAGNOSTIC (run after the gate result; read-only w.r.t. targets; solver untouched).
Purpose: localize the discrepancies that made the frozen <=2% rel-Linf gate fail.

(1) CONTROL: same solver, same verified formulation, run at the PAPER'S OWN stated
    discretization (1000 elements / 1250 steps) — to test whether the published
    curves' front structure is reproducible by ANY scheme at that resolution.
(2) BAND METRICS: for the Richardson-converged field R and for the control, the
    curve-normalized rel Linf split into |x - x_f| <= 0.03 (front-transition zone)
    vs the rest, for all 12 comparisons.
(3) BOUNDARY-CORNER OBSERVATION: sigma(x->0) nodal value by level (our scheme's
    pointwise behavior at the singular corner of the sudden-step BC).
Writes v3_diagnostics.json. Does not re-judge anything.
"""
import numpy as np, os, json, importlib.util
HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("v3d", os.path.join(HERE, "v3_fem_ls.py"))
v3d = importlib.util.module_from_spec(spec); spec.loader.exec_module(v3d)

def main():
    T = v3d.load_targets()
    fin = v3d.march(2048, 1.5625e-4)
    mid = v3d.march(1024, 3.125e-4)
    ctl = v3d.march(1000, 1.000e-3)   # paper's own numbers: 1000 elem, 1250 steps
    UNC = v3d.UNC_Y
    out = {}
    hdr = f"{'comparison':12s} {'ctl rel%':>9s} {'ctl@front%':>10s} {'ctl sm%':>8s} {'R rel%':>7s} {'R@front%':>9s} {'R sm%':>6s} {'sm<2unc?':>8s}"
    print(hdr)
    for key in sorted(T):
        xs, ys, p = T[key]
        fld, tstr = key.rsplit("_", 1); t = float(tstr)
        xf = v3d.front_x(t)
        m = (xs >= 0) & (xs <= 1)
        yc = v3d.field_at(1000, ctl["snaps"][t], fld, xs)
        yf = v3d.field_at(2048, fin["snaps"][t], fld, xs)
        ym = v3d.field_at(1024, mid["snaps"][t], fld, xs)
        yR = yf + (yf - ym) / 3.0
        den = float(np.max(np.abs(ys[m])))
        band = np.abs(xs - xf) <= 0.03
        front = m & band; smooth = m & ~band
        row = dict(
            ctl_rel=float(np.max(np.abs(yc[m] - ys[m])) / den * 100),
            ctl_front=float(np.max(np.abs(yc[front] - ys[front])) / den * 100) if front.sum() else None,
            ctl_smooth=float(np.max(np.abs(yc[smooth] - ys[smooth])) / den * 100) if smooth.sum() else None,
            R_rel=float(np.max(np.abs(yR[m] - ys[m])) / den * 100),
            R_front=float(np.max(np.abs(yR[front] - ys[front])) / den * 100) if front.sum() else None,
            R_smooth=float(np.max(np.abs(yR[smooth] - ys[smooth])) / den * 100) if smooth.sum() else None,
            smooth_max_abs=float(np.max(np.abs(yR[smooth] - ys[smooth]))) if smooth.sum() else None,
            smooth_within_2unc=bool(np.max(np.abs(yR[smooth] - ys[smooth])) <= 2 * UNC[fld]) if smooth.sum() else None)
        out[key] = row
        print(f"{key:12s} {row['ctl_rel']:9.2f} {str(row['ctl_front']):>10s} {row['ctl_smooth']:8.2f} "
              f"{row['R_rel']:7.2f} {str(row['R_front']):>9s} {row['R_smooth']:6.2f} {str(row['smooth_within_2unc']):>8s}")

    corner = {}
    for NE, r in ((512, v3d.march(512, 6.25e-4)), (1024, mid), (2048, fin), (1000, ctl)):
        corner[str(NE)] = float(v3d.field_at(NE, r["snaps"][0.25], "sigma", np.array([0.001]))[0])
    out["sigma_corner_x001_by_level_t025"] = corner
    print("sigma(0.001) by level:", corner)
    out["note"] = ("control run = same solver at the paper's own stated resolution (1000 elem, "
                   "1250 steps); used only to characterize scheme-dependence of the front zone")
    json.dump(out, open(os.path.join(HERE, "v3_diagnostics.json"), "w"), indent=1)
    print("wrote v3_diagnostics.json")

if __name__ == "__main__":
    main()
