#!/usr/bin/env python3
"""
V3 — TARGET EXTRACTION (final) from src_audit/nik_wb.pdf page 5.

Recovers the 12 published FEM target curves (theta, u, sigma at t=0.25/0.50/0.75/1.25).
Read-only w.r.t. the published figure; uses ONLY the published figure geometry and
published IBVP facts. Does NOT use our FEM solution.

METHOD
  1) Postfix-interpret the page-5 content stream -> absolute user-space subpaths.
  2) Axis calibration: linear fits of printed tick labels (text layer) to values.
  3) Per panel, the 4 long continuous polylines are the FEM curves; the [26] Bagri
     data are discrete short marker glyphs (kept separate; not converted to curves).
  4) Time assignment (PHYSICS-PURE, from the published IBVP only):
       The normalized wave speeds are cE = cK/sqrt(t0) = 1, so before the first
       reflection (t < 1) the field is EXACTLY 0 ahead of the wavefront, and the
       wavefront is at x = t. Each curve's "support frontier" x_f = max{x: |y|>tol}
       is the wavefront. Sorting the 4 curves by x_f gives t = 0.25, 0.50, 0.75 in
       order, and the curve with x_f ~ 1.0 (front reflected off x=1 at t=1) is t=1.25.
       This is the same "both wavefronts reach x=1 at t=1" physics self-check stated
       in the frozen Blueprint (K.7). It does NOT use our computed solution.
  5) Independent confirmation recorded (not used as primary): (a) the stroke-width
     visual code is identical across panels (w=0.75 -> t=1.25; w=0.5 -> t=0.75;
     w=0.33 -> {0.25,0.50}); (b) the t=0.25 curve has exactly 1001 vertices in every
     panel (the published mesh is "1000 elements").
  6) Validation: points inside axes; BC pins theta(x->0)=1, u(x->1)=0, sigma(x->0)=0
     (all satisfied to sub-pixel plotting precision); per-curve point counts.

NOT performed: V3 error computation/pass-fail; V4; any solver run; Blueprint edits.
"""
import re, json, os
import numpy as np
from pypdf import PdfReader

HERE = os.path.dirname(os.path.abspath(__file__))
PDF = os.path.abspath(os.path.join(HERE, "..", "..", "src_audit", "nik_wb.pdf"))

# --------------------------------------------------------------------------
def parse_subpaths(data):
    toks = [t for t in re.split(rb'[\s]+', data) if t]
    def num(b):
        try: return float(b)
        except Exception: return None
    out = []
    cur_cm = [1.0, 0.0, 0.0, 1.0, 0.0, 0.0]
    cmstack = []
    stack = []
    gsw = None
    seg = None
    def tr(x, y):
        return (cur_cm[0]*x + cur_cm[2]*y + cur_cm[4],
                cur_cm[1]*x + cur_cm[3]*y + cur_cm[5])
    def dump(pts_pairs):
        if not pts_pairs or len(pts_pairs) < 2:
            return
        xs = [p[0] for p in pts_pairs]; ys = [p[1] for p in pts_pairs]
        out.append(dict(w=gsw, n=len(pts_pairs), x0=min(xs), y0=min(ys), x1=max(xs), y1=max(ys),
                        xs=xs, ys=ys))
    i = 0; N = len(toks)
    while i < N:
        t = toks[i]
        if t == b'cm' and len(stack) >= 6:
            a,b,c,d,e,f = stack[-6:]; del stack[-6:]
            X, Y = cur_cm[4], cur_cm[5]
            cur_cm = [a*cur_cm[0]+b*cur_cm[2], a*cur_cm[1]+b*cur_cm[3],
                      c*cur_cm[0]+d*cur_cm[2], c*cur_cm[1]+d*cur_cm[3],
                      a*X+c*Y+e, b*X+d*Y+f]
            i += 1; continue
        if t == b'q': cmstack.append(cur_cm[:]); i += 1; continue
        if t == b'Q': cur_cm = cmstack.pop(); i += 1; continue
        if t == b'w' and stack: gsw = stack.pop(); i += 1; continue
        if t in (b'K', b'k') and len(stack) >= 4: del stack[-4:]; i += 1; continue
        if t in (b'RG', b'rg') and len(stack) >= 3: del stack[-3:]; i += 1; continue
        if t in (b'G', b'g') and stack: del stack[-1:]; i += 1; continue
        if t == b'd': i += 2; continue
        if t == b'm' and len(stack) >= 2:
            y = stack.pop(); x = stack.pop(); seg = [tr(x, y)]; i += 1; continue
        if t == b'l' and len(stack) >= 2:
            y = stack.pop(); x = stack.pop()
            if seg is not None: seg.append(tr(x, y))
            i += 1; continue
        if t == b'c' and len(stack) >= 6:
            x3=stack.pop(); y3=stack.pop(); x2=stack.pop(); y2=stack.pop(); x1=stack.pop(); y1=stack.pop()
            if seg is not None: seg.append(tr(x3, y3))
            i += 1; continue
        if t == b'h':
            if seg is not None: seg.append(seg[0])
            i += 1; continue
        if t == b're' and len(stack) >= 4:
            hh=stack.pop(); w=stack.pop(); yy=stack.pop(); xx=stack.pop()
            seg = [tr(xx, yy), tr(xx+w, yy), tr(xx+w, yy+hh), tr(xx, yy+hh), tr(xx, yy)]
            i += 1; continue
        if t == b'S':
            dump(seg); seg = None; i += 1; continue
        if t in (b's', b'f', b'F', b'B', b'b', b'B*', b'f*'):
            seg = None; i += 1; continue
        v = num(t)
        if v is not None:
            stack.append(v); i += 1; continue
        i += 1
    return out

# --------------------------------------------------------------------------
# axis calibration: measured tick-center px -> printed value (from text layer)
CALIB_TICKS = {
    "theta": dict(
        x=[(88.2,0.0),(127.7,0.2),(167.3,0.4),(206.8,0.6),(246.4,0.8),(285.7,1.0)],
        y=[(643.8,0.0),(673.6,0.5),(703.3,1.0)]),
    "u": dict(
        x=[(84.5,0.0),(124.2,0.2),(163.8,0.4),(203.5,0.6)],
        y=[(380.3,-0.6),(390.6,-0.5),(400.9,-0.4),(411.2,-0.3),(421.5,-0.2),
           (431.8,-0.1),(441.9,0.0),(452.3,0.1),(462.6,0.2),(472.9,0.3)]),
    "sigma": dict(
        x=[(341.8,0.0),(381.4,0.2),(420.9,0.4),(460.5,0.6),(500.1,0.8),(539.6,1.0)],
        y=[(630.4,-2.5),(645.9,-2.0),(661.4,-1.5),(676.9,-1.0),(692.4,-0.5),(707.9,0.0)]),
}
PAN_RANGE = {"theta": (-0.02, 1.30), "u": (-0.70, 0.45), "sigma": (-2.55, 0.30)}
FULLSCALE = {"theta": 1.0, "u": 0.6, "sigma": 2.5}
TIMES = {"0.25": 0, "0.50": 0, "0.75": 0, "1.25": 0}

def fit(vals_pairs, axis):
    p = np.array([pp for pp, v in vals_pairs], float)
    v = np.array([v for pp, v in vals_pairs], float)
    c1, c0 = np.polyfit(p, v, 1)
    return float(c0), float(c1)

def main():
    r = PdfReader(PDF)
    data = r.pages[4].get_contents().get_data()
    subpaths = parse_subpaths(data)
    print(f"parsed subpaths on page 5: {len(subpaths)}")

    maps = {}
    for name, c in CALIB_TICKS.items():
        X0, X1 = fit(c["x"], "x")
        Y0, Y1 = fit(c["y"], "y")
        maps[name] = dict(X0=X0, X1=X1, Y0=Y0, Y1=Y1)
    print("axis maps (value = X0 + X1*px ; value = Y0 + Y1*py):")
    for k, m in maps.items():
        print(f"  {k}: x: {m['X0']:.4f} + {m['X1']:.6f}px ; y: {m['Y0']:.4f} + {m['Y1']:.6f}py")

    targets = {}
    audit = {}
    marker_counts = {}

    for name in ["theta", "u", "sigma"]:
        m = maps[name]
        ylo, yhi = PAN_RANGE[name]
        fs = FULLSCALE[name]
        curves = []
        markers = 0
        for p in subpaths:
            xs = np.array([m["X0"] + m["X1"]*px for px in p["xs"]])
            ys = np.array([m["Y0"] + m["Y1"]*py for py in p["ys"]])
            inx = (xs >= -0.02) & (xs <= 1.02)
            iny = (ys >= ylo) & (ys <= yhi)
            if inx.sum() < 2 or iny.sum() < 2:
                continue
            if p["n"] >= 40:
                curves.append((p, xs, ys))
            else:
                # short interior glyphs = [26] markers (interior only)
                if xs.min() > 0.01 and xs.max() < 0.99:
                    markers += 1
        # dedupe
        seen = set(); uniq = []
        for p, xs, ys in curves:
            key = (p["n"], round(xs.min(), 3), round(ys.min(), 3))
            if key not in seen:
                seen.add(key); uniq.append((p, xs, ys))
        marker_counts[name] = markers
        print(f"\npanel {name}: {len(uniq)} long curves, {markers} interior [26] marker glyphs")

        # support frontier x_f = max x with |y - tail| > tol, where tail = median of y
        # over x in [0.85,1.0] (the quiescent value ahead of the front; ~0 for
        # theta/u, a small plotting baseline for sigma). Tail-relative so the
        # sigma panel's nonzero baseline does not mask the wavefront location.
        def frontier(xs_, ys_):
            o = np.argsort(xs_); xs_ = xs_[o]; ys_ = ys_[o]
            tail = float(np.median(ys_[xs_ > 0.85])) if (xs_ > 0.85).any() else float(ys_[-1])
            thr = max(0.02, 0.02 * fs)
            nz = xs_[np.abs(ys_ - tail) > thr]
            return float(nz.max()) if len(nz) else 0.0, tail

        ent = []
        for p, xs, ys in uniq:
            o = np.argsort(xs); xs_ = xs[o]; ys_ = ys[o]
            xf, tail = frontier(xs_, ys_)
            ent.append(dict(pxs=xs_, pys=ys_, n=p["n"], w=p["w"], xf=xf, tail=tail))
        for e in ent:
            print(f"   curve n={e['n']:4d} w={e['w']}  x_f = {e['xf']:.3f} (tail={e['tail']:+.4f})")

        # assignment: sort by x_f; smallest 3 -> 0.25, 0.50, 0.75; largest -> 1.25
        ent_sorted = sorted(ent, key=lambda e: e["xf"])
        order = ["0.25", "0.50", "0.75", "1.25"]
        assigned = dict(zip(order, ent_sorted))   # 4 curves, sorted ascending -> 0.25..1.25
        for t, e in zip(order, ent_sorted):
            print(f"   -> t={t}: n={e['n']} w={e['w']} x_f={e['xf']:.3f}")

        for t in order:
            e = assigned[t]
            xs_, ys_ = e["pxs"], e["pys"]
            xs_ = xs_[np.abs(np.diff(xs_, prepend=np.inf)) > 1e-7] if False else xs_
            # dedupe exact duplicates
            keep = np.concatenate([[True], np.abs(np.diff(xs_)) > 1e-7])
            xs_, ys_ = xs_[keep], ys_[keep]
            if len(xs_) > 500:
                idx = np.linspace(0, len(xs_)-1, 500).astype(int)
                xs_, ys_ = xs_[idx], ys_[idx]
            key = f"{name}_{t}"
            targets[key] = dict(field=name, t=float(t),
                                x=[float(v) for v in xs_], y=[float(v) for v in ys_])
            audit[key] = dict(n_vec=e["n"], n_out=int(len(xs_)), stroke_w=e["w"],
                              xf=round(e["xf"], 4),
                              x_min=float(xs_.min()), x_max=float(xs_.max()),
                              y_min=float(ys_.min()), y_max=float(ys_.max()))

    # ---- validation ----
    print("\n== extraction validation ==")
    ok_all = True
    for key in sorted(targets):
        d = targets[key]
        x = np.array(d["x"]); y = np.array(d["y"])
        ylo, yhi = PAN_RANGE[d["field"]]
        tol_lo = ylo - 0.005
        tol_hi = yhi + 0.05
        inside = (x >= -0.005).all() and (x <= 1.005).all() and (y >= tol_lo).all() and (y <= tol_hi).all()
        f = d["field"]
        print(f"   {key}: n={len(x):3d} x=[{x.min():.3f},{x.max():.3f}] y=[{y.min():.4f},{y.max():.4f}] "
              f"inside-axes={inside} w={audit[key]['stroke_w']} xf={audit[key]['xf']}")
        ok_all = ok_all and inside

    print("\n== published BC pins (figure-internal) ==")
    pins = []
    for t in ["0.25","0.50","0.75","1.25"]:
        x = np.array(targets[f"theta_{t}"]["x"]); y = np.array(targets[f"theta_{t}"]["y"])
        pins.append(f"theta(0)@t={t}={np.interp(0.0,x,y):.3f}")
    for t in ["0.25","0.50","0.75","1.25"]:
        x = np.array(targets[f"u_{t}"]["x"]); y = np.array(targets[f"u_{t}"]["y"])
        pins.append(f"u(1)@t={t}={np.interp(1.0,x,y):.3f}")
    for t in ["0.25","0.50","0.75","1.25"]:
        x = np.array(targets[f"sigma_{t}"]["x"]); y = np.array(targets[f"sigma_{t}"]["y"])
        pins.append(f"sigma(0)@t={t}={np.interp(0.0,x,y):.3f}")
    print("   " + " ; ".join(pins))

    # extraction uncertainty
    print("\n== extraction uncertainty (vector recovery) ==")
    unc = {}
    for name, m in maps.items():
        unc[name] = dict(x_units=round(0.5*abs(m["X1"]), 4), y_units=round(0.5*abs(m["Y1"]), 4))
        print(f"   {name}: x ±{unc[name]['x_units']} units, y ±{unc[name]['y_units']} units  (±0.5 px tick localization)")

    # ---- write artifacts ----
    os.makedirs(os.path.join(HERE, "targets"), exist_ok=True)
    for key, d in targets.items():
        with open(os.path.join(HERE, "targets", key + ".csv"), "w") as f:
            f.write("x,value\n")
            for x, y in zip(d["x"], d["y"]):
                f.write("%.6f,%.6e\n" % (x, y))
    summary = {
        "source": "src_audit/nik_wb.pdf page 5 (physical); figures 2,3,4",
        "method": ("postfix content-stream interpretation + tick-label axis calibration + "
                   "long-polyline curve recovery + published-wavefront physics time assignment"),
        "series": {k: "FEM" for k in targets},
        "targets": targets,
        "marker_glyphs_left_separate": marker_counts,
        "calibration": maps,
        "uncertainty_per_axis": unc,
        "audit": audit,
    }
    with open(os.path.join(HERE, "v3_targets_fem.json"), "w") as f:
        json.dump(summary, f, indent=1)
    print("\n   -> written verification/V3/targets/<field>_<t>.csv (12) and v3_targets_fem.json")

    verdict = "TARGET-EXTRACTION PASS" if ok_all and len(targets) == 12 else "TARGET-EXTRACTION FAIL"
    print("\n" + verdict)

if __name__ == "__main__":
    main()
