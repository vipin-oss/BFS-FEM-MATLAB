#!/usr/bin/env python3
"""
PHASE-1 V3 — EXTERNAL VALIDATION: converged C^1 BFS-FEM vs the published
Nikolarakis & Theotokoglou (2018) FEM curves (12 comparisons).

FROZEN BENCHMARK (Blueprint K.1 / SOURCE_LOCK_AUDIT §3, verbatim from the paper's
Eq. 11; normalized; kappa-hat = 0 => LS):
    momentum:  u_tt = u_xx - theta_x                                     (cE = 1)
    energy:    t0*(theta_tt + xi*u_xtt) + (theta_t + xi*u_xt) = theta_xx  (cK = 1)
    sigma_xx = u_x - theta ;  q_x = -theta_x
    xi = 0.05, t0 = 1, L = 1, x in [0,1], t in [0, 1.25]
    IC:  u = u_t = theta = theta_t = 0 (quiescent)
    BC:  theta(0,t) = H(t) (essential step at t=0+); sigma_xx(0,t) = 0 (natural);
         q_x(1,t) = 0 (natural); u(1,t) = 0 (essential)

SOLVER: the verified production C^1 formulation — Hermite basis, 4-pt Gauss and
model constants imported from verification/V1/mms_v1.py (the exact code path
verified by V1 spatial-order and V2 temporal-order gates); Newmark (beta=1/4,
gamma=1/2), consistent a0, sparse assembly + superLU. Only the benchmark
load/BC driver is specific here. No model, benchmark or scheme substitution.

RESOLUTION (frozen final-NE constraint = 1024; exceeded for convergence proof):
    levels (512, 6.25e-4), (1024, 3.125e-4), (2048, 1.5625e-4)  — h and dt both
    halved; p = 2 => Richardson reference R = fine + (fine - mid)/3.
    The external comparison uses R (Blueprint: tolerances apply only to the
    Richardson-converged solution, never to an unconverged mesh).

COMPARISON PROCEDURE (declared BEFORE evaluation; targets EXACTLY as stored —
no smoothing / shift / rescale / clip / correction of any kind):
  * evaluate our continuous FE polynomials AT the stored target x-nodes
    (theta, u from Hermite; sigma = du/dx - theta from the same elements);
    targets are never resampled.
  * target nodes with x outside [0,1] (sub-pixel axis-edge artifacts) are
    excluded from metrics and counted.
  * norms per Blueprint: rel L2 and Linf vs published curves at each instant,
    plus peak-value and wavefront-arrival differences.
      abs_linf = max|ours-target| ; rel_linf = abs_linf / max|target| ;
      rel_l2 = trapz|diff| / trapz|target|.
  * UNRESOLVED-SHOCK BAND RULE (gate definition; resolution-based, NOT result-
    based): IBVP wave speed is exactly 1 (Blueprint K.6 self-check) => front at
    x_f = t for t<=1, x_f = 2-t for t=1.25. Inside +-0.001 (= one source
    element; §4.5 basis "code-to-code agreement at the source's published
    resolution") pointwise differencing is dominated by grid alignment at an
    under-resolved jump in BOTH codes; the gated rel_linf excludes those nodes.
    RAW values and 0.002/0.004 sensitivities are reported for full disclosure.
  * SIGMA REGION SPLIT: resolved = |target| >= 4*0.0161 = 0.0644 (pointwise
    relative computed ONLY there); near-zero = absolute error statistics only
    (no division by an effectively zero benchmark value).
"""
import os, sys, json, hashlib, time
import numpy as np
import scipy
import scipy.sparse as sps
import scipy.sparse.linalg as spla

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "V1"))
from mms_v1 import hermite, GP, GW, T0, XI, quadrature_sanity   # verified primitives

LX = 1.0
BETA, GAMMA = 0.25, 0.5
T_OUT = [0.25, 0.50, 0.75, 1.25]
LEVELS = [(512, 6.25e-4), (1024, 3.125e-4), (2048, 1.5625e-4)]
UNC_Y = {"theta": 0.0084, "u": 0.0049, "sigma": 0.0161}
SIGMA_RESOLVED = 4.0 * UNC_Y["sigma"]      # 0.0644
SHOCK_BAND = 0.001                          # one published element
TRAPZ = getattr(np, "trapezoid", np.trapz)

# ---------------------------------------------------------------- assembly
def element_ops(h):
    B4, D4 = hermite(GP, h)
    M4 = h * (B4 * GW) @ B4.T
    K4 = h * (D4 * GW) @ D4.T
    E  = h * (B4 * GW) @ D4.T
    return M4, K4, E

def assemble(NE):
    h = LX / NE; NN = NE + 1; ND = 4 * NN
    dof = lambda n, f, k: 4*n + 2*f + k
    M4, K4, E = element_ops(h); Et = E.T
    def loc_of(e):
        return np.array([dof(e,0,0), dof(e,0,1), dof(e+1,0,0), dof(e+1,0,1),
                         dof(e,1,0), dof(e,1,1), dof(e+1,1,0), dof(e+1,1,1)])
    def build(blocks):
        """blocks: list of (row_slice, col_slice, dense4x4, scale) per element."""
        rows = []; cols = []; vals = []
        for e in range(NE):
            loc = loc_of(e)
            for r0, c0, m4, sc in blocks:
                sub = m4 * sc
                rr = np.repeat(loc[r0*4:(r0+1)*4] if isinstance(r0, int) else loc[np.array([r0]).astype(int)], 4)
                rows.append(rr); cols.append(np.tile(loc[c0], 4)); vals.append(sub.ravel())
        r = np.concatenate(rows); c = np.concatenate(cols); v = np.concatenate(vals)
        return sps.coo_matrix((v, (r, c)), shape=(ND, ND)).tocsr()
    # simpler explicit construction (avoids slice cleverness):
    def add_block(rows, cols, vals, e, rs, cs, m4, sc):
        loc = loc_of(e)
        for a in range(4):
            for b in range(4):
                v = m4[a, b] * sc
                if v != 0.0:
                    rows.append(loc[rs[a]]); cols.append(loc[cs[b]]); vals.append(v)
    def mat(spec):
        rows = []; cols = []; vals = []
        for e in range(NE):
            for rs, cs, m4, sc in spec:
                add_block(rows, cols, vals, e, rs, cs, m4, sc)
        return sps.coo_matrix((vals, (rows, cols)), shape=(ND, ND)).tocsr()
    rU = [0, 1, 2, 3]; rT = [4, 5, 6, 7]
    M = mat([(rU, rU, M4, 1.0), (rT, rT, M4, T0), (rT, rU, E, T0*XI)])
    C = mat([(rT, rT, M4, 1.0), (rT, rU, E, XI)])
    K = mat([(rU, rU, K4, 1.0), (rU, rT, Et, -1.0), (rT, rT, K4, 1.0)])
    pres = {dof(0, 1, 0): 1.0, dof(NE, 0, 0): 0.0}
    free = np.array([i for i in range(ND) if i not in pres])
    pids = np.array(sorted(pres)); pval = np.array([pres[k] for k in pids])
    return h, NN, ND, dof, M, C, K, free, pids, pval

# ---------------------------------------------------------------- time marching
def est_cond_2norm(S, luS, iters=60, seed=3):
    """Rough 2-norm conditioning OBSERVATION (not a certified cond): power
    iteration on S for |lambda_max| and on S^-1 (via the LU) for 1/|lambda_min|.
    Adequate for recording that S is comfortably nonsingular at each level."""
    rng = np.random.default_rng(seed)
    n = S.shape[0]
    v = rng.standard_normal(n); v /= np.linalg.norm(v)
    for _ in range(iters):
        w = S @ v; nrm = np.linalg.norm(w); v = w / nrm
    lmax = nrm
    for _ in range(iters):
        w = luS.solve(v); nrm = np.linalg.norm(w); v = w / nrm
    return float(lmax * nrm)

def march(NE, DT):
    h, NN, ND, dof, M, C, K, free, pids, pval = assemble(NE)
    Mff = M[np.ix_(free, free)]; Cff = C[np.ix_(free, free)]
    Kff = K[np.ix_(free, free)]; Kfp = K[np.ix_(free, pids)]
    up = np.zeros(ND); up[pids] = pval
    uf = np.zeros(len(free)); vf = np.zeros(len(free))
    luM = spla.splu(Mff)
    af = luM.solve(-(Kfp @ up[pids]))          # quiescent ICs + sudden step
    S = Mff + GAMMA*DT*Cff + BETA*DT*DT*Kff
    luS = spla.splu(S)
    condest_S = est_cond_2norm(S, luS)
    nsteps = int(round(1.25 / DT))
    out_idx = {int(round(t / DT)): t for t in T_OUT}
    snaps = {}; nan_flag = False
    for n in range(1, nsteps + 1):
        u_pred = uf + DT*vf + (0.5 - BETA)*DT*DT*af
        v_pred = vf + (1.0 - GAMMA)*DT*af
        rhs = -(Cff @ v_pred) - (Kff @ u_pred) - (Kfp @ up[pids])
        af = luS.solve(rhs)
        vf = v_pred + GAMMA*DT*af
        uf = u_pred + BETA*DT*DT*af
        if not np.all(np.isfinite(uf)):
            nan_flag = True; break
        if n in out_idx:
            full = np.zeros(ND); full[free] = uf; full[pids] = pval
            snaps[out_idx[n]] = full
    # direct-solve accuracy at the final step (machine-precision expectation)
    relres = float(np.abs(S @ af - rhs).max()
                   / (spla.norm(S, np.inf) * max(np.linalg.norm(af, np.inf), 1e-300)))
    return dict(h=h, NN=NN, ND=ND, snaps=snaps, nan=bool(nan_flag), condest=condest_S,
                steps=nsteps, dof=dof, final_step_rel_residual=relres)

# ---------------------------------------------------------------- FE evaluation
def eval_fields(NE, full):
    """Continuous FE evaluation. Global DOF layout is node-major interleaved:
    node n = [u, u', theta, theta'] at dofs 4n..4n+3. Element e therefore gathers
    u-dofs at [4e, 4e+1, 4e+4, 4e+5] and theta-dofs at [4e+2, 4e+3, 4e+6, 4e+7]."""
    h = LX / NE
    def val(xs, field):
        xs = np.clip(np.asarray(xs, float), 0.0, LX)
        e = np.minimum((xs // h).astype(int), NE - 1)
        z = (xs - e*h) / h
        B, _ = hermite(z, h)
        i0 = 4*e + 2*field
        return (B[0]*full[i0] + B[1]*full[i0+1]
                + B[2]*full[i0+4] + B[3]*full[i0+5])
    def dux(xs):
        xs = np.clip(np.asarray(xs, float), 0.0, LX)
        e = np.minimum((xs // h).astype(int), NE - 1)
        z = (xs - e*h) / h
        _, D = hermite(z, h)
        i0 = 4*e
        return (D[0]*full[i0] + D[1]*full[i0+1]
                + D[2]*full[i0+4] + D[3]*full[i0+5])
    return val, dux

def field_at(NE, full, fld, xs):
    val, dux = eval_fields(NE, full)
    if fld == "theta": return val(xs, 1)
    if fld == "u":     return val(xs, 0)
    return dux(xs) - val(xs, 1)

# ---------------------------------------------------------------- targets
def sha256(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()

def load_targets():
    T = {}
    for f in ("theta", "u", "sigma"):
        for t in ("0.25", "0.50", "0.75", "1.25"):
            p = os.path.join(HERE, "targets", f"{f}_{t}.csv")
            rows = open(p).read().strip().splitlines()[1:]
            x = np.array([float(r.split(",")[0]) for r in rows])
            y = np.array([float(r.split(",")[1]) for r in rows])
            T[f"{f}_{t}"] = (x, y, p)
    return T

def front_x(t):
    return t if t <= 1.0 else 2.0 - t

# ---------------------------------------------------------------- metrics
def compare_at(t, field, xs, ys, ours):
    out = {}
    dom = (xs >= 0.0) & (xs <= 1.0)
    out["n_total"] = int(len(xs)); out["n_out_of_domain"] = int((~dom).sum())
    xf = front_x(t)
    band = dom & (np.abs(xs - xf) <= SHOCK_BAND)
    gate = dom & ~band
    out["n_front_excluded"] = int(band.sum())
    denom = float(np.max(np.abs(ys[dom])))       # curve normalization on all in-domain nodes
    denom_at = float(xs[dom][np.argmax(np.abs(ys[dom]))])
    out["norm_denom"] = dict(max_abs_target=denom, at_x=denom_at)
    trap_t = float(np.sqrt(TRAPZ(ys[dom]**2, xs[dom])))
    for tag, sel in (("all", dom), ("gated", gate)):
        d = np.abs(ours[sel] - ys[sel])
        i = int(np.argmax(d))
        out[tag] = dict(n=int(sel.sum()),
                        abs_linf=float(d.max()),
                        abs_linf_x=float(xs[sel][i]),
                        tgt_at_max=float(ys[sel][i]),
                        fem_at_max=float(ours[sel][i]),
                        rel_linf=float(d.max()/denom)*100.0,
                        rel_l2=float(np.sqrt(TRAPZ((ours[sel]-ys[sel])**2, xs[sel]))/trap_t)*100.0,
                        frac_within_1unc=float(np.mean(d < UNC_Y[field]))*100.0,
                        max_diff_in_uncs=float(d.max()/UNC_Y[field]))
    sens = {}
    for w in (0.002, 0.004):
        sel = dom & (np.abs(xs - xf) > w)
        d = np.abs(ours[sel] - ys[sel])
        sens[str(w)] = dict(abs_linf=float(d.max()), rel_linf=float(d.max()/denom)*100.0)
    out["sensitivity"] = sens
    iO = int(np.argmax(np.abs(ours[dom]))); iT = int(np.argmax(np.abs(ys[dom])))
    out["peak"] = dict(our_val=float(ours[dom][iO]), our_x=float(xs[dom][iO]),
                       tgt_val=float(ys[dom][iT]), tgt_x=float(xs[dom][iT]))
    def cross50(vv):
        lo = dom & (xs < xf - 3*SHOCK_BAND); hi = dom & (xs > xf + 3*SHOCK_BAND)
        if lo.sum() == 0 or hi.sum() == 0: return None
        amp = np.max(np.abs(vv[lo])); tail = np.median(vv[hi])
        lev = tail + 0.5*(amp - tail)
        idxs = np.where(dom)[0]
        for k in range(len(idxs)-1):
            i0, i1 = idxs[k], idxs[k+1]
            if (vv[i0]-lev)*(vv[i1]-lev) < 0 and abs(xs[i0]-xf) < 0.05 and abs(xs[i1]-xf) < 0.05:
                f = (lev - vv[i0]) / (vv[i1] - vv[i0])
                return float(xs[i0] + f*(xs[i1]-xs[i0]))
        return None
    f50o, f50t = cross50(ours), cross50(ys)
    out["front50"] = dict(our_x=f50o, tgt_x=f50t,
                          d_x=None if (f50o is None or f50t is None) else float(f50o-f50t))
    if field == "sigma":
        res = dom & (np.abs(ys) >= SIGMA_RESOLVED)
        nz = dom & (np.abs(ys) < SIGMA_RESOLVED)
        out["sigma_resolved"] = dict(
            n=int(res.sum()),
            abs_linf=float(np.max(np.abs(ours[res]-ys[res]))),
            max_pointwise_rel_pct=float(np.max(np.abs(ours[res]-ys[res])/np.abs(ys[res]))*100.0),
            curve_rel_linf_pct=float(np.max(np.abs(ours[res]-ys[res]))/denom*100.0))
        out["sigma_nearzero"] = dict(
            n=int(nz.sum()),
            abs_linf=float(np.max(np.abs(ours[nz]-ys[nz]))),
            mean_abs=float(np.mean(np.abs(ours[nz]-ys[nz]))),
            in_unc_units=float(np.max(np.abs(ours[nz]-ys[nz]))/UNC_Y["sigma"]))
    return out

# ---------------------------------------------------------------- main
def main():
    wall0 = time.time()
    assert quadrature_sanity()

    # ---- evaluator self-tests (guard the interleaved DOF layout; pilot cross-check) ----
    chkv = np.arange(4 * 101, dtype=float)
    vT, _ = eval_fields(100, chkv)
    xn = np.linspace(0, 1, 101); nn = np.arange(101)
    assert np.allclose(vT(xn, 0), 4 * nn, atol=1e-9), "u nodal gather broken"
    assert np.allclose(vT(xn, 1), 4 * nn + 2, atol=1e-9), "theta nodal gather broken"
    pcsv = os.path.abspath(os.path.join(HERE, "..", "..", "pilot", "pilot_data", "pilot_LS_profiles.csv"))
    if os.path.exists(pcsv):
        pv = np.genfromtxt(pcsv, delimiter=",", names=True)
        pz = np.load(os.path.abspath(os.path.join(HERE, "..", "..", "pilot", "pilot_data", "pilot_LS_snapshots.npz")))
        vP, dP = eval_fields(100, pz["theta_0.25"])
        x025 = np.array([0.25])
        print(f"  [eval guard] node-gather exactness: PASS ; pilot@0.25 csv th={pv['theta_025'][int(round(0.25*200))]:.4f} "
              f"u={pv['u_025'][int(round(0.25*200))]:.4f} vs my-eval-on-pilot-state th={float(vP(x025,1)[0]):.4f} "
              f"u={float(vP(x025,0)[0]):.4f}")

    T = load_targets()

    runs = {}
    for (NE, DT) in LEVELS:
        r = march(NE, DT)
        runs[NE] = r
        print(f"  level NE={NE:5d} DT={DT:.3e} steps={r['steps']} DOFs={r['ND']} "
              f"NaN/Inf={r['nan']}  cond(S)~{r['condest']:.2e}  final-step relres={r['final_step_rel_residual']:.1e}")
        # BC pins of our own solution (not targets): theta(0)=1, u(1)=0 exactly
        s = r["snaps"][1.25]
        assert s[4*0 + 2*1 + 0] == 1.0 and s[4*r["NN"]-4 + 0] == 0.0

    NEf, NEm, NEc = 2048, 1024, 512
    # Richardson combination is performed on EVALUATED fields (common evaluation
    # points), never across node vectors of different meshes.

    # self-convergence evidence (max abs diff between levels, all fields, per output)
    xg = np.linspace(0, 1, 20001)
    conv = {"fine-mid": {}, "mid-coarse": {}}
    for tag, (a, b) in {"fine-mid": (NEf, NEm), "mid-coarse": (NEm, NEc)}.items():
        for t in T_OUT:
            diffs = {}
            for fld in ("theta", "u", "sigma"):
                diffs[fld] = float(np.max(np.abs(field_at(a, runs[a]["snaps"][t], fld, xg)
                                            - field_at(b, runs[b]["snaps"][t], fld, xg))))
            conv[tag][str(t)] = diffs
    # Richardson significance: |R - fine| on target nodes
    rich = {}

    results = {}
    for key in sorted(T):
        xs, ys, path = T[key]
        fld, tstr = key.rsplit("_", 1); t = float(tstr)
        fine = field_at(NEf, runs[NEf]["snaps"][t], fld, xs)
        mid = field_at(NEm, runs[NEm]["snaps"][t], fld, xs)
        ours = fine + (fine - mid) / 3.0          # Richardson-converged field
        ours_f = fine
        m = (xs >= 0) & (xs <= 1)
        rich[key] = float(np.max(np.abs(ours[m] - ours_f[m])))
        c = compare_at(t, fld, xs, ys, ours)
        c["key"] = key; c["field"] = fld; c["t"] = t
        c["target_file"] = f"verification/V3/targets/{key}.csv"
        c["target_sha256"] = sha256(path)
        c["richardson_minus_fine_absmax"] = rich[key]
        results[key] = c

    print("\n" + "=" * 110)
    print(f"{'comparison':12s} {'nG':>4s} {'absLinf':>9s} {'relLinf%':>8s} {'relL2%':>7s} "
          f"{'x@max':>7s} {'tgt@max':>9s} {'FEM@max':>9s} {'rawRel%':>8s} {'sens2':>6s} {'sens4':>6s} {'gate':>5s}")
    print("=" * 110)
    gate_all_ok = True
    for key in sorted(results):
        c = results[key]; g = c["gated"]; a = c["all"]
        ok = g["rel_linf"] <= 2.0; gate_all_ok &= bool(ok)
        print(f"{key:12s} {g['n']:4d} {g['abs_linf']:9.4f} {g['rel_linf']:8.2f} {g['rel_l2']:7.2f} "
              f"{g['abs_linf_x']:7.3f} {g['tgt_at_max']:9.4f} {g['fem_at_max']:9.4f} "
              f"{a['rel_linf']:8.2f} {c['sensitivity']['0.002']['rel_linf']:6.2f} "
              f"{c['sensitivity']['0.004']['rel_linf']:6.2f} {'PASS' if ok else 'FAIL'}")
    print("=" * 110)

    print("\nsigma region split:")
    for key in sorted(k for k in results if k.startswith("sigma")):
        r_ = results[key]["sigma_resolved"]; z_ = results[key]["sigma_nearzero"]
        print(f"  {key}: resolved n={r_['n']} curveRel={r_['curve_rel_linf_pct']:.2f}% "
              f"maxPtRel={r_['max_pointwise_rel_pct']:.1f}% | nearzero n={z_['n']} "
              f"abs={z_['abs_linf']:.4f} ({z_['in_unc_units']:.2f}xunc) mean={z_['mean_abs']:.4f}")

    print("\npeaks and fronts:")
    for key in sorted(results):
        p = results[key]["peak"]; f50 = results[key]["front50"]
        print(f"  {key}: peak our {p['our_val']:+.4f}@{p['our_x']:.3f} tgt {p['tgt_val']:+.4f}@{p['tgt_x']:.3f}"
              f" | front50 d_x={f50['d_x']}")

    print("\nself-convergence max|Δ| between adjacent levels (per field, per output):")
    for tag in conv:
        for t in conv[tag]:
            d = conv[tag][t]
            print(f"  {tag} t={t}: theta {d['theta']:.3e}  u {d['u']:.3e}  sigma {d['sigma']:.3e}")
    print("\nRichardson-vs-fine field difference (abs max on target nodes): "
          + ", ".join(f"{k}:{v:.2e}" for k, v in sorted(rich.items())))

    payload = dict(
        benchmark="Nikolarakis & Theotokoglou 2018, DOI 10.1155/2018/7371016, normalized LS IBVP (Eq. 11), cE=cK=1, xi=0.05, t0=1, L=1, khat=0",
        solver="verified C^1 cubic-Hermite (BFS p=2) + Newmark(beta=1/4,gamma=1/2) + 4pt Gauss; primitives imported from verification/V1/mms_v1.py (V1/V2-verified path)",
        levels=[dict(NE=ne, DT=dt, steps=int(round(1.25/dt)), DOFs=runs[ne]["ND"],
                     nan_or_inf=runs[ne]["nan"], condest_S=runs[ne]["condest"],
                     final_step_rel_residual=runs[ne]["final_step_rel_residual"]) for (ne, dt) in LEVELS],
        converged_field="Richardson R = fine + (fine-mid)/3, per output (h and dt halved, p=2)",
        selfconvergence=conv,
        richardson_minus_fine_absmax=rich,
        comparison_rule=dict(norms="curve-normalized rel Linf (denom=max|target|) + rel L2 (trapezoid) + peak + front50",
                             grids="continuous FE field evaluated at stored target nodes; targets untouched",
                             out_of_domain="target nodes with x outside [0,1] excluded and counted",
                             shock_band=SHOCK_BAND,
                             sigma_resolved_threshold=SIGMA_RESOLVED),
        results=results,
        gate="frozen <= 2% relative Linf, curve-normalized, gate set = in-domain nodes outside +-1 published element of the a-priori front",
        gate_all_pass=bool(gate_all_ok))
    json.dump(payload, open(os.path.join(HERE, "v3_results.json"), "w"), indent=1)

    man = dict(created_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               python=sys.version.split()[0], numpy=np.__version__,
               scipy=scipy.__version__, wall_s=round(time.time()-wall0, 1),
               target_sha256={f"{f}_{t}.csv": sha256(os.path.join(HERE, "targets", f"{f}_{t}.csv"))
                              for f in ("theta", "u", "sigma") for t in ("0.25", "0.50", "0.75", "1.25")},
               targets_json_sha256=sha256(os.path.join(HERE, "v3_targets_fem.json")),
               extractor_sha256=sha256(os.path.join(HERE, "v3_extract_targets.py")),
               pdf_sha256=sha256(os.path.abspath(os.path.join(HERE, "..", "..", "src_audit", "nik_wb.pdf"))),
               solver_config=dict(levels=[list(l) for l in LEVELS], beta=BETA, gamma=GAMMA,
                                  quadrature="4-pt Gauss-Legendre (exact through degree 7 on each element)",
                                  xi=XI, t0=T0, cE=1.0, cK=1.0, L=LX, khat=0.0,
                                  ICs="u=u_t=theta=theta_t=0 (quiescent; step applied at t=0+)",
                                  BCs="theta(0,t)=H(t) essential; sigma(0,t)=0 natural; q(1,t)=0 natural; u(1,t)=0 essential",
                                  linear_algebra="direct sparse LU (superLU); no iterative tolerance",
                                  initial_acceleration="consistent a0 = M^-1(-K_fp up) (sudden step)"),
               target_modification="NONE: targets loaded exactly as stored; no smoothing/shift/rescale/clip/correction")
    json.dump(man, open(os.path.join(HERE, "v3_run_manifest.json"), "w"), indent=1)
    print(f"\nwrote: verification/V3/v3_results.json , v3_run_manifest.json   (wall {time.time()-wall0:.1f} s)")
    print("GATE RESULT (12 gated rel Linf <= 2%):", "ALL PASS" if gate_all_ok else "AT LEAST ONE EXCEEDED")

if __name__ == "__main__":
    main()
