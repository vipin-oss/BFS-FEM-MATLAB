clc; clear; close all;
% OM SARASWATYA NAMAH

%% ------------------------------------------------------------
%%  D VALUES (damage parameter)
%% ------------------------------------------------------------
D_vals = [0, 0.002, 0.4, 0.6, 0.8, 0.9];
nD = numel(D_vals);

%% Fixed ξ (you used in previous code)
xi = 1e-2;

%% spatial coordinates
x1 = 0.05;
t  = 0.05;
x3 = 0:0.0001:0.01;
nX3 = numel(x3);

%% ------------------------------------------------------------
%% STORAGE (6 fields × D variations)
%% ------------------------------------------------------------
fields_all = zeros(nX3, nD, 6);

%% ------------------------------------------------------------
%% COMPUTE FIELDS FOR EACH D
%% ------------------------------------------------------------
for j = 1:nD

    D = D_vals(j);

    [u1, N, T, psi11, sigma11, s1_1] = ...
        solver_6fields_D(xi, D, x1, t, x3);

    fields_all(:,j,1) = u1;
    fields_all(:,j,2) = N;
    fields_all(:,j,3) = T;
    fields_all(:,j,4) = psi11;
    fields_all(:,j,5) = sigma11;
    fields_all(:,j,6) = s1_1;
end

%% ------------------------------------------------------------
%% NORMALIZATION
%% ------------------------------------------------------------
fieldsN = fields_all;
for f = 1:6
    mx = max(abs(fields_all(:,:,f)), [], 'all');
    if mx < 1e-30, mx = 1; end
    fieldsN(:,:,f) = fields_all(:,:,f) / mx;
end

%% ------------------------------------------------------------
%% ============================================================
%% TRUE DEVIATION w.r.t D = 0  +  HIGH-VISIBILITY PLOTTING
% ============================================================
% TRUE DEVIATION (BEST VISIBILITY VERSION)
% ============================================================
fields_rel = zeros(size(fieldsN));

for f = 1:6

    ref = fieldsN(:,1,f);   % reference field

    % absolute deviation only for D>0
    for j = 1:nD
        fields_rel(:,j,f) = fieldsN(:,j,f) - ref;
    end

    % -------- visibility scaling --------
    mx = max(abs(fields_rel(:,2:end,f)),[],'all');   % ignore column 1

    if mx < 1e-12
        mx = 1;
    end

    fields_rel(:,:,f) = fields_rel(:,:,f) / mx;   % scale deviations

    % boost visibility
    fields_rel(:,:,f) = 1.8 * fields_rel(:,:,f);
    fields_rel(:,:,f) = min(max(fields_rel(:,:,f),-1),1);
end



% ------------------------------------------------------------
%% PERFECT FIXED TITLES (no string concatenation inside loop)
full_titles = {
    '$\Delta \tilde{u}_{1}$', ...
    '$\Delta \tilde{N}$', ...
    '$\Delta \tilde{T}$', ...
    '$\Delta \tilde{\psi}_{1}^{(1)}$', ...
    '$\Delta \tilde{\sigma}_{11}$', ...
    '$\Delta \tilde{\sigma}_{1}^{(1)}$' };


%% PLOTS
figure('Units','centimeters','Position',[2 2 18 20]);
tiledlayout(3,2,'TileSpacing','compact','Padding','compact');

for f = 1:6
    nexttile;
    imagesc(x3, D_vals, fields_rel(:,:,f).');
    set(gca,'YDir','normal'); 
    caxis([-1 1]);

    xlabel('$x_{3}$','Interpreter','latex');
    ylabel('$D$','Interpreter','latex');

    % Direct fixed title
    title(full_titles{f}, 'Interpreter','latex');
end

cb = colorbar;
cb.Ticks = linspace(-1,1,11);
cb.Label.String = '$\Delta$ (normalized)';
cb.Label.Interpreter = 'latex';


%% relative scaling
function Mout = scale_rel(M)
    m = max(abs(M(:)));
    if m < 1e-30
        Mout = 0*M;
    else
        Mout = M/m;
    end
end

function [u1, N, T, psi11, sigma11, s1_1] = ...
         solver_6fields_D(xi, D, x1, t, x3)

%% ================================================================
%% CONSTANT PARAMETERS  (unchanged)
%% ================================================================
k   = 1;
c   = 2500;
omega = k*c;
b = 1i*omega;

tau = 0.05;     % temporal nonlocal parameter (fixed)
beta = 0.1;

m = 0.5;
n = 0.5;
nu = 0.02;

alpha_T = 0.005;
alpha_N = 0.5;

D1 = 1 - D;     % <<<<<<<<<<<<<<  damage coupling

T0_star = 10;
N0_star = 1e6;

varpi = -9e-31;

lambda_e = 6.4e10;
gamma1   = 0.9e10;
A2 = 0.12e-5;
a2 = 1.23e6;
chi1 = 1.456e-16;
chi2 = 1.546e-16;
kappa = 150;
k_c   = 150;

tau_c = 5e-5;
tau_t = 0.2;

eta = 6.5e10;
gamma2 = 0.1e10;
A3 = 1.1e-5;
a3 = 2.21e10;

nu1 = 0.16e5;
Dc  = 2.5e-3;
dn  = -9e-31;
tau_v = 0.15;

rho  = 2330;
A1   = 1.3e-5;
a1   = 1.2e10;
theta0 = 798;
Ce   = 383.1;
nu2  = 0.219e5;

Eg   = 1.11;
tau_q = 0.25;

a = rho*Ce/theta0;

%% ================================================================
%%  LAMBDA-star (Λ)
%% ================================================================
Lambda = ( ...
    ( -b^2 * nu^2 * (m^2 - 2*n + 1) + 2*b*nu*(m^2 - n) + 2*m^2 )*exp(-b*nu) ...
    + b^2 * nu^2 - 2*b*n*nu + 2*m^2 ) / (b^2 * nu^3);

B1 = 1 + 3*nu*Lambda + (nu^2)*(Lambda^2);
E1 = 2 + nu*Lambda;

%% ================================================================
%% g-MATRIX ENTRIES
%% ================================================================
g0 = 1 + xi^2*k^2 - tau^2*omega^2;

g11 = -D1*(2*eta+lambda_e)*k^2 + rho*omega^2*g0;
g12 = D1*eta + rho*omega^2*xi^2;
g13 = 1i*k*D1*(lambda_e+eta);

g14 = 1i*k*D1*varpi;
g15 = 1i*k*D1*beta;
g16 = 1i*k*D1*gamma1;
g17 = 1i*k*D1*gamma2;

g21 = 1i*k*D1*(eta+lambda_e);
g22 = -D1*eta*k^2 + rho*omega^2*g0;
g23 = D1*(lambda_e + 2*eta) + rho*omega^2*xi^2;

g24 = D1*varpi;
g25 = D1*beta;
g26 = D1*gamma1;
g27 = D1*gamma2;

g31 = -1i*k*gamma1;
g32 = -gamma1;
g33 = -nu1;
g34 = -D1*A1*k^2 - a1 + chi1*k^2*c^2*g0;
g35 = D1*A1 + chi1*omega^2*xi^2;
g36 = -D1*A2*k^2 - a2;
g37 = D1*A2;

g41 = -1i*k*gamma2;
g42 = -gamma2;
g43 = -nu2;
g44 = -A2*k^2*D1 - a2;
g45 = D1*A2;
g46 = -D1*A3*k^2 - a3 + chi2*omega^2*g0;
g47 = D1*A3 + chi2*omega^2*xi^2;

g51 = -B1*theta0*beta*1i*k;
g52 = B1*theta0*beta;
g53 = Eg/(tau_c);
g54 = - E1 * kappa;
g55 = (E1*kappa*k^2 - B1*theta0*rho*Ce/theta0);
g56 = B1*theta0*nu1;
g57 = B1*theta0*nu2;

g61 = -1i*omega + Dc*k^2 + 1/tau_c;
g62 = -Dc;
g63 = -k_c;

%% ------------------------------------------------------------
%% DET(G)=0 → λ_i
%% ------------------------------------------------------------
syms Dz;

G = [
g11+g12*Dz^2,  g13*Dz,        -g14,           -g15,           g16,           g17;
g21*Dz,        g22+g23*Dz^2,  -g24*Dz,        -g25*Dz,        g26*Dz,        g27*Dz;
g31,           g32*Dz,        0,              -g33,           g34+g35*Dz^2,  g36+g37*Dz^2;
g41,           g42*Dz,        0,              -g43,           g44+g45*Dz^2,  g46+g47*Dz^2;
g51,           g52*Dz,        -g53,           -(g54*Dz^2+g55),g56,      g57;
0,             0,             g61+g62*Dz^2,   g63,            0,             0];

Z = vpa(det(G));
syms x
Q = roots(sym2poly(subs(Z, Dz^2, x)));

lambda = abs(sqrt(Q(1:6)));
lambda1=lambda(1); lambda2=lambda(2); lambda3=lambda(3);
lambda4=lambda(4); lambda5=lambda(5); lambda6=lambda(6);

%% ================================================================
%% Solve H1..H5
%% ================================================================
syms lam
A_C = [
g13*lam, g14, g15, -g16, -g17;
g22+g23*lam^2, g24*lam, g25*lam, -g26*lam, -g27*lam;
g32*lam, 0, g33, -g34-g35*lam^2, -g36-g37*lam^2;
g42*lam, 0, g43, -g44-g45*lam^2, -g46-g47*lam^2;
g52*lam, g53, g54*lam^2+g55, -g56, -g57];

B_C = [
g11+g12*lam^2;
g21*lam;
g31;
g41;
g51];

X = vpa(A_C\B_C);

H1=X(1); H2=X(2); H3=X(3); H4=X(4); H5=X(5);

%% Substitute λ_i
for i=1:6
    eval(sprintf('H1%d = subs(H1,lam,lambda%d);',i,i));
    eval(sprintf('H2%d = subs(H2,lam,lambda%d);',i,i));
    eval(sprintf('H3%d = subs(H3,lam,lambda%d);',i,i));
    eval(sprintf('H4%d = subs(H4,lam,lambda%d);',i,i));
    eval(sprintf('H5%d = subs(H5,lam,lambda%d);',i,i));
end

%% ================================================================
%% Compute Ψ for σ11 and σ1^(1)
%% ================================================================
for i=1:6
    eval(sprintf('H61%d = D1*(1i*k*(lambda_e+2*eta) - lambda_e*lambda%d*H1%d + gamma1*H1%d + gamma2*H2%d - varpi*H3%d - beta*H4%d);',...
        i,i,i,i,i,i,i));
end

H71 = D1*(lambda1*1i*k + (lambda_e+2*eta)*(-lambda1*H11) + gamma1*H11 + gamma2*H21 - varpi*H31 - beta*H41);
    H72 = D1*(lambda2*1i*k + (lambda_e+2*eta)*(-lambda2*H12) + gamma1*H12 + gamma2*H22 - varpi*H32 - beta*H42);
    H73 = D1*(lambda3*1i*k + (lambda_e+2*eta)*(-lambda3*H13) + gamma1*H13 + gamma2*H23 - varpi*H33 - beta*H43);
    H74 = D1*(lambda4*1i*k + (lambda_e+2*eta)*(-lambda4*H14) + gamma1*H14 + gamma2*H24 - varpi*H34 - beta*H44);
    H75 = D1*(lambda5*1i*k + (lambda_e+2*eta)*(-lambda5*H15) + gamma1*H15 + gamma2*H25 - varpi*H35 - beta*H45);
    H76 = D1*(lambda6*1i*k + (lambda_e+2*eta)*(-lambda6*H16) + gamma1*H16 + gamma2*H26 - varpi*H36 - beta*H46);

   H81 = eta*D1*(-lambda1 + 1i*k*H11);
H82 = eta*D1*(-lambda2 + 1i*k*H12);
H83 = eta*D1*(-lambda3 + 1i*k*H13);
H84 = eta*D1*(-lambda4 + 1i*k*H14);
H85 = eta*D1*(-lambda5 + 1i*k*H15);
H86 = eta*D1*(-lambda6 + 1i*k*H16);

H911 = D1*(1i*k)*(A1*H41 + A2*H51);
H912 = D1*(1i*k)*(A1*H42 + A2*H52);
H913 = D1*(1i*k)*(A1*H43 + A2*H53);
H914 = D1*(1i*k)*(A1*H44 + A2*H54);
H915 = D1*(1i*k)*(A1*H45 + A2*H55);
H916 = D1*(1i*k)*(A1*H46 + A2*H56);

H101 = -D1*( lambda1*A1*H41 + lambda1*A2*H51 );
H102 = -D1*( lambda2*A1*H42 + lambda2*A2*H52 );
H103 = -D1*( lambda3*A1*H43 + lambda3*A2*H53 );
H104 = -D1*( lambda4*A1*H44 + lambda4*A2*H54 );
H105 = -D1*( lambda5*A1*H45 + lambda5*A2*H55 );
H106 = -D1*( lambda6*A1*H46 + lambda6*A2*H56 );

H111 = D1*(1i*k)*( A2*H41 + A3*H51 );
H112 = D1*(1i*k)*( A2*H42 + A3*H52 );
H113 = D1*(1i*k)*( A2*H43 + A3*H53 );
H114 = D1*(1i*k)*( A2*H44 + A3*H54 );
H115 = D1*(1i*k)*( A2*H45 + A3*H55 );
H116 = D1*(1i*k)*( A2*H46 + A3*H56 );

H121 = -D1*( lambda1*A2*H41 + lambda1*A3*H51 );
H122 = -D1*( lambda2*A2*H42 + lambda2*A3*H52 );
H123 = -D1*( lambda3*A2*H43 + lambda3*A3*H53 );
H124 = -D1*( lambda4*A2*H44 + lambda4*A3*H54 );
H125 = -D1*( lambda5*A2*H45 + lambda5*A3*H55 );
H126 = -D1*( lambda6*A2*H46 + lambda6*A3*H56 );

%% ================================================================
%% Boundary conditions
%% ================================================================
for i=1:6
    HB(i) = eval(sprintf('H61%d',i)) + alpha_T*eval(sprintf('H3%d',i)) + alpha_N*eval(sprintf('H2%d',i));
end

LM = [
 HB(1) HB(2) HB(3) HB(4) HB(5) HB(6);
 1 1 1 1 1 1;
 H21 H22 H23 H24 H25 H26;
 H31 H32 H33 H34 H35 H36;
 H101 H102 H103 H104 H105 H106;
 H121 H122 H123 H124 H125 H126];

R = [0; 0; N0_star; T0_star; 0; 0];

M = LM\R;
M1=M(1); M2=M(2); M3=M(3); M4=M(4); M5=M(5); M6=M(6);

%% ================================================================
%% Fields vs x3
%% ================================================================
phase = exp(1i*k*(x1 - c*t));
lambda_vec = [lambda1 lambda2 lambda3 lambda4 lambda5 lambda6];

for i=1:6
    expL(i,:) = exp(-lambda_vec(i).*x3);
end

%% ----- u1 -----
u1 = real( (M1*expL(1,:) + M2*expL(2,:) + M3*expL(3,:) + ...
            M4*expL(4,:) + M5*expL(5,:) + M6*expL(6,:)) .* phase );

%% ----- N -----
N = real( (H21*M1*expL(1,:) + H22*M2*expL(2,:) + H23*M3*expL(3,:) + ...
           H24*M4*expL(4,:) + H25*M5*expL(5,:) + H26*M6*expL(6,:)) .* phase );

%% ----- T -----
T = real( (H31*M1*expL(1,:) + H32*M2*expL(2,:) + H33*M3*expL(3,:) + ...
           H34*M4*expL(4,:) + H35*M5*expL(5,:) + H36*M6*expL(6,:)) .* phase );

%% ----- psi_1^(1) -----
psi11 = real( (H41*M1*expL(1,:) + H42*M2*expL(2,:) + H43*M3*expL(3,:) + ...
               H44*M4*expL(4,:) + H45*M5*expL(5,:) + H46*M6*expL(6,:)) .* phase );

%% ----- sigma11 -----
for i=1:6
    Ls(i) = 1/(1 + xi^2*k^2 - xi^2*(lambda_vec(i)^2) - tau^2*omega^2);
end

sigma11 = real( ...
    (Ls(1)*H611*M1*expL(1,:) + Ls(2)*H612*M2*expL(2,:) + ...
     Ls(3)*H613*M3*expL(3,:) + Ls(4)*H614*M4*expL(4,:) + ...
     Ls(5)*H615*M5*expL(5,:) + Ls(6)*H616*M6*expL(6,:)) .* phase );

%% ----- sigma1^(1) -----
s1_1 = real( ...
    (Ls(1)*H911*M1*expL(1,:) + Ls(2)*H912*M2*expL(2,:) + ...
     Ls(3)*H913*M3*expL(3,:) + Ls(4)*H914*M4*expL(4,:) + ...
     Ls(5)*H915*M5*expL(5,:) + Ls(6)*H916*M6*expL(6,:)) .* phase );

end
