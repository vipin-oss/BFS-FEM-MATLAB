clc,clear all, close all
x1=0.5;
t=0.05;
x3=0.7;
tau=0.05;
xi=0.05;
beta=0.1;%%%%%%%%%
D=0.5;
m=0.5;
n=0.5;
nu=0.02;
alpha_T = 0.005;
alpha_N     = 0.5;
k   = 1;
c   = 2500;
omega=k*c;
b=1i*omega;
D1=1-D;
T0_star = 10;
N0_star   = 1e6;


%% Material Parameters from Table
varpi = -9e-31;
    
lambda_e   = 6.4e10;        % N/m^2
gamma1    = 0.9e10;        % N/m^2
A2   = 0.12e-5;       % N
a2     = 1.23e6;        % N/m^2
chi1     = 1.456e-16;     % Nm^-2 s^2
chi2     = 1.546e-16;     % Nm^-2 s^2
kappa1   = 150;           % Ns^-1 K^-1
kappa   = 150;           % Ns^-1 K^-1
k_c   = 150;           % Ns^-1 K^-1

tau_c    = 5e-5;          % s
tau_t    = 0.2;           % -

eta       = 6.5e10;        % N/m^2
gamma2    = 0.1e10;        % N/m^2
A3   = 1.1e-5;        % N
a3     = 2.21e10;       % N/m^2
Xi_t     = 1.78e-5;       % K^-1
nu1 = 0.16e5;       % N/m^2 K
Dc       = 2.5e-3;        % m^2/s
dn       = -9e-31;        % m^3
tau_v    = 0.15;          % -

rho      = 2330;          % kg/m^3
A1   = 1.3e-5;        % N
a1     = 1.2e10;        % N/m^2
theta0  = 300;           % K
Ce       = 383.1;         % J kg^-1 K^-1
nu2 = 0.219e5;      % N/m^2 K
Eg       = 1.11;          % eV
tau_q    = 0.25;          % -

a=rho*Ce/theta0;


%-------------------------------------------------------------
% Lambda (Λ) calculation according to the thermo-elasto-diffusion model
%-------------------------------------------------------------

Lambda = ( ...
    ( -b^2 * nu^2 * (m^2 - 2*n + 1) ...        % Term 1
      + 2*b*nu*(m^2 - n) ...                  % Term 2
      + 2*m^2 ) * exp(-b*nu) ...              % Multiply by exp(-b*nu)
    + b^2 * nu^2 ...                          % Term 3
    - 2*b*n*nu ...                            % Term 4
    + 2*m^2 ...                               % Term 5
    ) / ( b^2 * nu^3 );                       % Denominator

%-------------------------------------------------------------
% Function to compute B1 and E1 for all Thermo-Elasto-Diffusion Models
%-------------------------------------------------------------
% function [B1, E1] = TED_parameters(modelType, nu, Lambda)
% 
% switch upper(modelType)
% 
%     case "FOLS"
%         B1 = 1 + nu*Lambda;
%         E1 = 1;
% 
%     case "FOMLS-I"
%         B1 = 1 + 2*nu*Lambda;
%         E1 = 1 + nu*Lambda;
% 
%     case "FOMLS-II"
%         B1 = 1 + nu*Lambda;
%         E1 = 2 + nu*Lambda;
% 
%     case "FOMLS-III"
%         B1 = 1 + 3*nu*Lambda + (nu^2)*(Lambda^2);
%         E1 = 1 + nu*Lambda;
% 
%     case "FOMLS-IV"
%         B1 = 1 + 3*nu*Lambda + (nu^2)*(Lambda^2);
%         E1 = 2 + nu*Lambda;
% 
%     otherwise
%         error("Invalid model type! Choose FOLS, FOMLS-I, FOMLS-II, FOMLS-III, FOMLS-IV");
% end
% 
% end


B1 = 1 + 3*nu*Lambda + (nu^2)*(Lambda^2);
E1 = 2 + nu*Lambda;
% 
%% ------------------ g-parameters (exact from paper) ------------------

g0  = 1 + xi^2 * k^2 - tau^2 * omega^2;

g11 = -D1*(2*eta + lambda_e)*k^2 + rho*omega^2*g0;
g12 = D1*eta + rho*omega^2*xi^2;
g13 = 1i*k*D1*(lambda_e + eta);

g14 = 1i*k*D1*varpi;
g15 = 1i*k*D1*beta;
g16 = 1i*k*D1*gamma1;
g17 = 1i*k*D1*gamma2;

g21 = 1i*k*D1*(eta + lambda_e);
g22 = -D1*eta*k^2 + rho*omega^2*g0;
g23 = D1*(lambda_e + 2*eta) + rho*omega^2*xi^2;
g24 = D1*varpi;
g25 = D1*beta;
g26 = D1*gamma1;
g27 = D1*gamma2;

g31 = -1i*k*gamma1;
g32 = -gamma1;
g33 = -nu1;
g34 = -D1*A1*k^2 - a1 + chi1*k^2*c^2*g0;
g35 = D1*A1 + chi1*omega^2*xi^2;
g36 = -D1*A2*k^2 - a2;
g37 = D1*A2;

g41 = -1i*k*gamma2;
g42 = -gamma2;
g43 = -nu2;
g44 = -A2*k^2*D1 - a2;
g45 = D1*A2;
g46 = -D1*A3*k^2 - a3 + chi2*omega^2*g0;
g47 = D1*A3 + chi2*omega^2*xi^2;

g51 = -B1*theta0*beta*k^2*c;
g52 = B1*theta0*beta*1i*omega;
g53 = Eg/(tau_c) * 1i*omega;
g54 = -1i*omega * E1 * kappa;

g55 = -1i*omega*(E1*kappa - k^2 - B1*theta0*a);
g56 = -B1*theta0*nu1 * 1i*omega;
g57 = -B1*theta0*nu2 * 1i*omega;

g61 = -1i*omega + Dc*k^2 + 1/tau_c;
g62 = -Dc;
g63 = -k_c;

syms Dz
G = [

g11 + g12*Dz^2,   g13*Dz,          -g14,              -g15,              g16,               g17;

g21*Dz,           g22 + g23*Dz^2,  -g24*Dz,           -g25*Dz,           g26*Dz,            g27*Dz;

g31,              g32*Dz,          0,                 -g33,              g34 + g35*Dz^2,    g36 + g37*Dz^2;

g41,              g42*Dz,          0,                 -g43,              g44 + g45*Dz^2,    g46 + g47*Dz^2;

g51,              g52*Dz,          -g53,              -(g54*Dz^2 + g55), g56*Dz^2,          g57*Dz^2;

0,                0,               g61 + g62*Dz^2,    g63,               0,                 0

];

  Z1 = det(G);
    Z2 = collect(Z1);
    determinant_Z = vpa(Z2);

    syms x
    determinant_Z1 = subs(determinant_Z,Dz^2,x);
    Q = roots(sym2poly(determinant_Z1));

    lambda1 = abs(sqrt(Q(1)));
    lambda2 = abs(sqrt(Q(2)));
    lambda3 = abs(sqrt(Q(3)));
    lambda4 = abs(sqrt(Q(4)));
    lambda5 = abs(sqrt(Q(5)));
    lambda6 = abs(sqrt(Q(6)));
    
    
    
        % ======== coupling constants H_i ========
    syms lambda
    A_C = [
    g13*lambda,                 g14,                    g15,                        -g16,                       -g17;
    g22 + g23*lambda^2,         g24*lambda,             g25*lambda,                 -g26*lambda,                -g27*lambda;
    g32*lambda,                 0,                      g33,                        -g34 - g35*lambda^2,        -g36 - g37*lambda^2;
    g42*lambda,                 0,                      g43,                        -g44 - g45*lambda^2,        -g46 - g47*lambda^2;
    g52*lambda,                 g53,                    g54*lambda^2 + g55,         -g56*lambda^2,              -g57*lambda^2
    ];

    B_C = [
    g11 + g12*lambda^2;
    g21*lambda;
    g31;
    g41;
    g51
    ];

    X_C = vpa(A_C\B_C);

    H1 = X_C(1); H2 = X_C(2); H3 = X_C(3); H4 = X_C(4);  H5 = X_C(5);

    H11=subs(H1,lambda,lambda1); H12=subs(H1,lambda,lambda2);
    H13=subs(H1,lambda,lambda3); H14=subs(H1,lambda,lambda4);
    H15=subs(H1,lambda,lambda5); H16=subs(H1,lambda,lambda6);

 
    H21=subs(H2,lambda,lambda1); H22=subs(H2,lambda,lambda2);
    H23=subs(H2,lambda,lambda3); H24=subs(H2,lambda,lambda4);
    H25=subs(H2,lambda,lambda5); H26=subs(H2,lambda,lambda6);

    H31=subs(H3,lambda,lambda1); H32=subs(H3,lambda,lambda2);
    H33=subs(H3,lambda,lambda3); H34=subs(H3,lambda,lambda4);
    H35=subs(H3,lambda,lambda5); H36=subs(H3,lambda,lambda6);

    H41=subs(H4,lambda,lambda1); H42=subs(H4,lambda,lambda2);
    H43=subs(H4,lambda,lambda3); H44=subs(H4,lambda,lambda4);
    H45=subs(H4,lambda,lambda5); H46=subs(H4,lambda,lambda6);

    H51=subs(H5,lambda,lambda1); H52=subs(H5,lambda,lambda2);
    H53=subs(H5,lambda,lambda3); H54=subs(H5,lambda,lambda4);
    H55=subs(H5,lambda,lambda5); H56=subs(H5,lambda,lambda6);
    
   
    H61 = D1*(1i*k*(lambda_e+2*eta) - lambda_e*lambda1*H11 + gamma1*H11 + gamma2*H21 - varpi*H31 - beta*H41);
    H62 = D1*(1i*k*(lambda_e+2*eta) - lambda_e*lambda2*H12 + gamma1*H12 + gamma2*H22 - varpi*H32 - beta*H42);
    H63 = D1*(1i*k*(lambda_e+2*eta) - lambda_e*lambda3*H13 + gamma1*H12 + gamma2*H23 - varpi*H33 - beta*H43);
    H64 = D1*(1i*k*(lambda_e+2*eta) - lambda_e*lambda4*H14 + gamma1*H12 + gamma2*H24 - varpi*H34 - beta*H44);
    H65 = D1*(1i*k*(lambda_e+2*eta) - lambda_e*lambda5*H15 + gamma1*H12 + gamma2*H25 - varpi*H35 - beta*H45);
    H66 = D1*(1i*k*(lambda_e+2*eta) - lambda_e*lambda6*H16 + gamma1*H12 + gamma2*H26 - varpi*H36 - beta*H46);

    
    H71 = D1*(lambda1*1i*k + (lambda_e+2*eta)*(-lambda1*H11) + gamma1*H11 + gamma2*H21 - varpi*H31 - beta*H41);
    H72 = D1*(lambda2*1i*k + (lambda_e+2*eta)*(-lambda2*H12) + gamma1*H12 + gamma2*H22 - varpi*H32 - beta*H42);
    H73 = D1*(lambda3*1i*k + (lambda_e+2*eta)*(-lambda3*H13) + gamma1*H13 + gamma2*H23 - varpi*H33 - beta*H43);
    H74 = D1*(lambda4*1i*k + (lambda_e+2*eta)*(-lambda4*H14) + gamma1*H14 + gamma2*H24 - varpi*H34 - beta*H44);
    H75 = D1*(lambda5*1i*k + (lambda_e+2*eta)*(-lambda5*H15) + gamma1*H15 + gamma2*H25 - varpi*H35 - beta*H45);
    H76 = D1*(lambda6*1i*k + (lambda_e+2*eta)*(-lambda6*H16) + gamma1*H16 + gamma2*H26 - varpi*H36 - beta*H46);

   H81 = eta*D1*(-lambda1 + 1i*k*H11);
H82 = eta*D1*(-lambda2 + 1i*k*H12);
H83 = eta*D1*(-lambda3 + 1i*k*H13);
H84 = eta*D1*(-lambda4 + 1i*k*H14);
H85 = eta*D1*(-lambda5 + 1i*k*H15);
H86 = eta*D1*(-lambda6 + 1i*k*H16);

H91 = D1*(1i*k)*(A1*H41 + A2*H51);
H92 = D1*(1i*k)*(A1*H42 + A2*H52);
H93 = D1*(1i*k)*(A1*H43 + A2*H53);
H94 = D1*(1i*k)*(A1*H44 + A2*H54);
H95 = D1*(1i*k)*(A1*H45 + A2*H55);
H96 = D1*(1i*k)*(A1*H46 + A2*H56);

H101 = -D1*( lambda1*A1*H41 + lambda1*A2*H51 );
H102 = -D1*( lambda2*A1*H42 + lambda2*A2*H52 );
H103 = -D1*( lambda3*A1*H43 + lambda3*A2*H53 );
H104 = -D1*( lambda4*A1*H44 + lambda4*A2*H54 );
H105 = -D1*( lambda5*A1*H45 + lambda5*A2*H55 );
H106 = -D1*( lambda6*A1*H46 + lambda6*A2*H56 );

H111 = D1*(1i*k)*( A2*H41 + A3*H51 );
H112 = D1*(1i*k)*( A2*H42 + A3*H52 );
H113 = D1*(1i*k)*( A2*H43 + A3*H53 );
H114 = D1*(1i*k)*( A2*H44 + A3*H54 );
H115 = D1*(1i*k)*( A2*H45 + A3*H55 );
H116 = D1*(1i*k)*( A2*H46 + A3*H56 );

H121 = -D1*( lambda1*A2*H41 + lambda1*A3*H51 );
H122 = -D1*( lambda2*A2*H42 + lambda2*A3*H52 );
H123 = -D1*( lambda3*A2*H43 + lambda3*A3*H53 );
H124 = -D1*( lambda4*A2*H44 + lambda4*A3*H54 );
H125 = -D1*( lambda5*A2*H45 + lambda5*A3*H55 );
H126 = -D1*( lambda6*A2*H46 + lambda6*A3*H56 );

HB1 = H71 + alpha_T*H31 + alpha_N*H21;
HB2 = H72 + alpha_T*H32 + alpha_N*H22;
HB3 = H73 + alpha_T*H33 + alpha_N*H23;
HB4 = H74 + alpha_T*H34 + alpha_N*H24;
HB5 = H75 + alpha_T*H35 + alpha_N*H25;
HB6 = H76 + alpha_T*H36 + alpha_N*H26;

    % ======== solve for M_i ========
   LM = [
 HB1   HB2   HB3   HB4   HB5   HB6 ;   %  sum(barPsi_i) = 0
 1     1     1     1     1     1   ;   %  sum(M_i) = 0
 H21   H22   H23   H24   H25   H26 ;   %  sum(Psi2_i * Mi) = N0*
 H31   H32   H33   H34   H35   H36 ;   %  sum(Psi3_i * Mi) = T0*
 H101  H102  H103  H104  H105  H106;   %  sum(Psi10_i * Mi) = 0
 H121  H122  H123  H124  H125  H126   %  sum(Psi12_i * Mi) = 0
];

    R = [0; 0; N0_star; T0_star; 0; 0];
    
    M = LM\R;

    M1 = M(1); M2 = M(2); M3 = M(3); M4 = M(4); M5 = M(5); M6 = M(6);


%% ---- Fields vs x3 (6 modes) ----
Lstar_1 = 1 ./ ( 1 + xi.^2 .* k.^2 - xi.^2 .* (lambda1.^2) - tau.^2 .* omega.^2 );  % 1x6
Lstar_2 = 1 ./ ( 1 + xi.^2 .* k.^2 - xi.^2 .* (lambda2.^2) - tau.^2 .* omega.^2 );  % 1x6
Lstar_3 = 1 ./ ( 1 + xi.^2 .* k.^2 - xi.^2 .* (lambda3.^2) - tau.^2 .* omega.^2 );  % 1x6
Lstar_4 = 1 ./ ( 1 + xi.^2 .* k.^2 - xi.^2 .* (lambda4.^2) - tau.^2 .* omega.^2 );  % 1x6
Lstar_5 = 1 ./ ( 1 + xi.^2 .* k.^2 - xi.^2 .* (lambda5.^2) - tau.^2 .* omega.^2 );  % 1x6
Lstar_6 = 1 ./ ( 1 + xi.^2 .* k.^2 - xi.^2 .* (lambda6.^2) - tau.^2 .* omega.^2 );  % 1x6


phase = exp(1i*k*(x1 - c*t));

u1_star = M1*exp(-lambda1*x3) + M2*exp(-lambda2*x3) + ...
          M3*exp(-lambda3*x3) + M4*exp(-lambda4*x3) + ...
          M5*exp(-lambda5*x3) + M6*exp(-lambda6*x3);
u1 = real(u1_star .* phase);

u3_star = H11*M1*exp(-lambda1*x3) + H12*M2*exp(-lambda2*x3) + ...
          H13*M3*exp(-lambda3*x3) + H14*M4*exp(-lambda4*x3) + ...
          H15*M5*exp(-lambda5*x3) + H16*M6*exp(-lambda6*x3);
u3 = real(u3_star .* phase);

N_star = H21*M1*exp(-lambda1*x3) + H22*M2*exp(-lambda2*x3) + ...
         H23*M3*exp(-lambda3*x3) + H24*M4*exp(-lambda4*x3) + ...
         H25*M5*exp(-lambda5*x3) + H26*M6*exp(-lambda6*x3);
N = real(N_star .* phase);

T_star = H31*M1*exp(-lambda1*x3) + H32*M2*exp(-lambda2*x3) + ...
         H33*M3*exp(-lambda3*x3) + H34*M4*exp(-lambda4*x3) + ...
         H35*M5*exp(-lambda5*x3) + H36*M6*exp(-lambda6*x3);
T = real(T_star .* phase);

psi_star_1 = H41*M1*exp(-lambda1*x3) + H42*M2*exp(-lambda2*x3) + ...
           H43*M3*exp(-lambda3*x3) + H44*M4*exp(-lambda4*x3) + ...
           H45*M5*exp(-lambda5*x3) + H46*M6*exp(-lambda6*x3);
psi_1 = real(psi_star_1 .* phase);

psi_star_2 = H51*M1*exp(-lambda1*x3) + H52*M2*exp(-lambda2*x3) + ...
           H53*M3*exp(-lambda3*x3) + H54*M4*exp(-lambda4*x3) + ...
           H55*M5*exp(-lambda5*x3) + H56*M6*exp(-lambda6*x3);
psi_2 = real(psi_star_2 .* phase);


s11_star = Lstar_1*H61*M1*exp(-lambda1*x3) + Lstar_2*H62*M2*exp(-lambda2*x3) + ...
           Lstar_3*H63*M3*exp(-lambda3*x3) + Lstar_4*H64*M4*exp(-lambda4*x3) + ...
           Lstar_5*H65*M5*exp(-lambda5*x3) + Lstar_6*H66*M6*exp(-lambda6*x3);
sigma11 = real(s11_star .* phase);

s33_star = Lstar_1*H71*M1*exp(-lambda1*x3) + Lstar_2*H72*M2*exp(-lambda2*x3) + ...
           Lstar_3*H73*M3*exp(-lambda3*x3) + Lstar_4*H74*M4*exp(-lambda4*x3) + ...
           Lstar_5*H75*M5*exp(-lambda5*x3) + Lstar_6*H76*M6*exp(-lambda6*x3);
sigma33 = real(s33_star .* phase);

s13_star = Lstar_1*H81*M1*exp(-lambda1*x3) + Lstar_2*H82*M2*exp(-lambda2*x3) + ...
           Lstar_3*H83*M3*exp(-lambda3*x3) + Lstar_4*H84*M4*exp(-lambda4*x3) + ...
           Lstar_5*H85*M5*exp(-lambda5*x3) + Lstar_6*H86*M6*exp(-lambda6*x3);
sigma13 = real(s13_star .* phase);

s1_star_1 = Lstar_1*H91*M1*exp(-lambda1*x3) + Lstar_2*H92*M2*exp(-lambda2*x3) + ...
           Lstar_3*H93*M3*exp(-lambda3*x3) + Lstar_4*H94*M4*exp(-lambda4*x3) + ...
           Lstar_5*H95*M5*exp(-lambda5*x3) + Lstar_6*H96*M6*exp(-lambda6*x3);
s1_1 = real(s1_star_1 .* phase);

s3_star_1 = Lstar_1*H101*M1*exp(-lambda1*x3) + Lstar_2*H102*M2*exp(-lambda2*x3) + ...
           Lstar_3*H103*M3*exp(-lambda3*x3) + Lstar_4*H104*M4*exp(-lambda4*x3) + ...
           Lstar_5*H105*M5*exp(-lambda5*x3) + Lstar_6*H106*M6*exp(-lambda6*x3);
s3_1 = real(s3_star_1 .* phase);

s1_star_2 = Lstar_1*H111*M1*exp(-lambda1*x3) + Lstar_2*H112*M2*exp(-lambda2*x3) + ...
           Lstar_3*H113*M3*exp(-lambda3*x3) + Lstar_4*H114*M4*exp(-lambda4*x3) + ...
           Lstar_5*H115*M5*exp(-lambda5*x3) + Lstar_6*H116*M6*exp(-lambda6*x3);
s1_2 = real(s1_star_2 .* phase);

s3_star_2 = Lstar_1*H121*M1*exp(-lambda1*x3) + Lstar_2*H122*M2*exp(-lambda2*x3) + ...
           Lstar_3*H123*M3*exp(-lambda3*x3) + Lstar_4*H124*M4*exp(-lambda4*x3) + ...
           Lstar_5*H125*M5*exp(-lambda5*x3) + Lstar_6*H126*M6*exp(-lambda6*x3);
s3_2 = real(s3_star_2 .* phase);
