# 02_OVERLEAF — Overleaf-ready manuscript folder (elsarticle edition)

This folder compiles **stand-alone**: upload the whole folder to Overleaf
(or run `bash compile.sh` locally) and set `main.tex` as the main document.

## Contents

| File | Role |
|---|---|
| `main.tex` | Manuscript source (Elsevier `elsarticle` class, preprint 12 pt). Author/affiliation placeholders are on the title page — fill them before submission. |
| `references.bib` | Bibliography database (provenance copy). **The compiled document uses the embedded `\begin{thebibliography}` list inside `main.tex`**, so this file is reference material for future re-formatting (e.g. natbib/bibTeX), not a compile dependency. |
| `figures/` | All 11 figure PDFs (`fig1.pdf` … `fig11.pdf`) + EPS companions (`Fig01.eps` … `Fig11.eps`). Figure numbers match file names: printed Figure *N* is `figN.pdf` / `Fig0N.eps`. |
| `tables/` | No external table files: every table is typeset inside `main.tex`. See `tables/README.md`. |
| `supplementary/` | No supplementary files in this folder (the reproducibility package is submitted separately at the journal). See `supplementary/README.md`. |
| `compile.sh` | Compilation script (pdflatex or tectonic). |

## Compilation facts (verified 2026-09-29)

- Document class: Elsevier **`elsarticle`** (`\documentclass[preprint,12pt]{elsarticle}`),
  shipped with TeX Live (`texlive-publishers`) and available on Overleaf by default.
  **No custom .cls or .bst upload is required.**
- Packages used: `amsmath`, `amssymb`, `amsfonts`, `bm`, `mathtools`, `geometry`,
  `graphicx`, `booktabs`, `multirow`, `array`, `subcaption`, `siunitx`, `xcolor`,
  `hyperref` (hidelinks) — template order (mathematics → figures/tables → units →
  colors → hyperref near the end); all standard.
- Bibliography: embedded `\bibitem` list (`\begin{thebibliography}{47}`); there is
  therefore **no `main.bbl`** (NOT APPLICABLE) and no `\addbibresource` step.
- Figure dependencies: exactly `figures/fig1.pdf` … `figures/fig11.pdf`; all present.
  No `\input`/`\include` of external .tex fragments.
- Figures are placed **inline** near their discussion and numbered in order of
  appearance (printed Figure N = `figN.pdf` / `Fig0N.eps`); captions are short.
- All `figure`, `equation`, `table`, and citation labels resolve (3× pdflatex run).

## How to compile on Overleaf

1. Create a new project → Upload Project → upload this folder as a ZIP.
2. Menu → set Main document = `main.tex`.
3. Compiler: `pdfLaTeX` (default) — done.

## Path notes

`\graphicspath{{../figures/output/}{figures/}}` resolves `figures/` inside this
folder; the first entry is only a convenience for the in-repo layout and is
harmless on Overleaf.
