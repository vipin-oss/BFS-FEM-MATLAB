#!/usr/bin/env python3
"""Regenerate the FINAL layout-fixed make_all_figures.py from make_all_figures_v1_original.py.

Layout-only patches (content/semantics unchanged): figure sizes, spacing,
font sizes, label wrapping, math-mode axis labels (fig8), colorbar limits
(fig10), fig7 in-figure note removal (duplicates caption), plus follow-up
nits (fig3 ylabel linespacing, fig5 legend frame, fig9 label pads).
"""
src = open('make_all_figures_v1_original.py').read()
log = []

def rep(old, new, n=1, tag=''):
    global src
    cnt = src.count(old)
    assert cnt == n, f"[{tag}] count {cnt} != {n} for: {old[:90]!r}"
    src = src.replace(old, new)
    log.append(tag or old[:40])

# ============================ FIG 1 ============================
rep('ax.text(0.15, -0.35, "quasicrystal half-space $z>0$ (2D hex., Laue 10)",\n            fontsize=8, color="#333333")',
    'ax.text(0.15, -0.32, "quasicrystal half-space $z>0$ (2D hex., Laue 10)",\n            fontsize=8, color="#333333",\n            bbox=dict(fc="white", ec="none", alpha=0.88, pad=1.2), zorder=6)',
    tag='fig1 bbox half-space text')
rep('ax.add_patch(plt.Rectangle((5.55, -4.85), 4.3, 2.05, fc="white",\n                 ec="#666666", lw=0.7, zorder=5))',
    'ax.add_patch(plt.Rectangle((5.35, -4.92), 4.55, 2.22, fc="white",\n                 ec="#666666", lw=0.7, zorder=5))',
    tag='fig1 box bigger')
rep('ax.text(5.7, -3.05,', 'ax.text(5.5, -3.02,', tag='fig1 line1 pos')
rep('ax.text(5.7, -3.55,', 'ax.text(5.5, -3.52,', tag='fig1 line2 pos')
rep('ax.text(5.7, -4.05,', 'ax.text(5.5, -4.02,', tag='fig1 line3 pos')
rep('ax.text(5.7, -4.55,', 'ax.text(5.5, -4.52,', tag='fig1 line4 pos')
rep('fontsize=8.2, zorder=6)', 'fontsize=7.0, zorder=6)', n=3, tag='fig1 box fonts a')
rep('fontsize=8.2,\n            color="#666666", zorder=6)',
    'fontsize=7.0,\n            color="#666666", zorder=6)', tag='fig1 box font b')

# ============================ FIG 2 ============================
rep('fig, axes = plt.subplots(1, 2, figsize=(7.6, 3.05),\n                             gridspec_kw={"width_ratios": [1.0, 1.15]})',
    'fig, axes = plt.subplots(1, 2, figsize=(10.4, 3.9),\n                             gridspec_kw={"width_ratios": [1.0, 1.15],\n                                          "wspace": 0.34})', tag='fig2 size')
rep('"A (cpl.)", "B/C (cpl.)"]', '"A\\n(cpl.)", "B/C\\n(cpl.)"]', tag='fig2 ticks')
rep('ax.text(2, vals[2] - 0.045, "%.9f" % vals[2], fontsize=6.4, ha="center")',
    'ax.text(2, vals[2] - 0.045, "%.9f" % vals[2], fontsize=8.2, ha="center")', tag='fig2 f1')
rep('ax.text(0, vals[0] + 0.035, "1 (exact)", fontsize=6.4, ha="center")',
    'ax.text(0, vals[0] + 0.035, "1 (exact)", fontsize=8.2, ha="center")', tag='fig2 f2')
rep('ax.text(1, vals[1] + 0.04, "0.5 (exact)", fontsize=6.4, ha="center")',
    'ax.text(1, vals[1] + 0.04, "0.5 (exact)", fontsize=8.2, ha="center")', tag='fig2 f3')
rep('ax.text(4, vals[4] - 0.065, "%.8f" % vals[4], fontsize=6.4, ha="center")',
    'ax.text(4, vals[4] - 0.065, "%.8f" % vals[4], fontsize=8.2, ha="center")', tag='fig2 f4')
rep('ax.text(5, vals[5] + 0.03, "%.7f" % vals[5], fontsize=6.4, ha="center")',
    'ax.text(5, vals[5] + 0.03, "%.7f" % vals[5], fontsize=8.2, ha="center")', tag='fig2 f5')
rep('ax.text(5.55, 0.79, "0.934208 (excl. record)", fontsize=6.2, ha="center")',
    'ax.text(5.62, 0.78, "0.934208 (excl. record)", fontsize=8.0, ha="right")',
    tag='fig2 excl record')
rep('ax.set_xticks(range(6)); ax.set_xticklabels(cats, fontsize=7)',
    'ax.set_xticks(range(6)); ax.set_xticklabels(cats, fontsize=8.4)', tag='fig2 xticks')
rep('ax.legend(fontsize=6.4, loc="lower left")', 'ax.legend(fontsize=8.2, loc="lower left")',
    tag='fig2 leg a')
rep('ax.text(2.5e-3, 4e-15, "roundoff-dominated", fontsize=6.4, color="#555555")',
    'ax.text(2.5e-3, 4e-15, "roundoff-dominated", fontsize=8.2, color="#555555")', tag='fig2 f6')
rep('ax.legend(fontsize=6.2, loc="upper right")', 'ax.legend(fontsize=8.0, loc="upper right")',
    tag='fig2 leg b')

# ============================ FIG 3 ============================
rep('fig, axes = plt.subplots(1, 3, figsize=(7.8, 2.75))\n    ax = axes[0]\n    for mod, c, s in (("A", CA, SM), ("B", CB, SB), ("C", CC, SC)):\n        rr = [r for r in rows if r["model"] == mod]\n        ax.loglog(farr(rr, "Omega"), farr(rr, "V"), color=c, ls=s,',
    'fig, axes = plt.subplots(1, 3, figsize=(11.2, 3.6),\n                             gridspec_kw={"wspace": 0.44})\n    ax = axes[0]\n    for mod, c, s in (("A", CA, SM), ("B", CB, SB), ("C", CC, SC)):\n        rr = [r for r in rows if r["model"] == mod]\n        ax.loglog(farr(rr, "Omega"), farr(rr, "V"), color=c, ls=s,',
    tag='fig3 size')
rep('ax.text(1.3e-3, 0.505, r"$v_S^*/v_0=0.5$", fontsize=7)',
    'ax.text(1.3e-3, 0.505, r"$v_S^*/v_0=0.5$", fontsize=8.6)', tag='fig3 f1')
rep('ax.set_ylim(0.2, 0.6); ax.legend(fontsize=7, loc="lower left")',
    'ax.set_ylim(0.2, 0.6); ax.legend(fontsize=8.4, loc="lower left")', tag='fig3 leg a')
rep('ax.text(2e-3, 3e-5, "max $4.4\\\\times10^{-6}$ abs.\\n($9.5\\\\times10^{-6}$ rel.)",\n            fontsize=6.4)',
    'ax.text(2e-3, 3e-5, "max $4.4\\\\times10^{-6}$ abs.\\n($9.5\\\\times10^{-6}$ rel.)",\n            fontsize=8.2)', tag='fig3 annot')
rep('ax.legend(fontsize=6.6, loc="lower right")', 'ax.legend(fontsize=8.2, loc="lower right")',
    tag='fig3 leg b')
rep('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"phason participation $P_w$")\n    ax.legend(fontsize=7, loc="lower right")',
    'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel("phason participation\\n$P_w$", fontsize=9)\n    ax.yaxis.label.set_linespacing(1.45)\n    ax.legend(fontsize=8.4, loc="lower right")', tag='fig3 ylabel c')

# ============================ FIG 4 ============================
rep('fig, axes = plt.subplots(1, 3, figsize=(7.8, 2.75))\n    ax = axes[0]\n    ax.loglog(Om, np.maximum(farr(rows, "Delta_BC"), 1e-16), color=CB, lw=1.1)',
    'fig, axes = plt.subplots(1, 3, figsize=(11.2, 3.6),\n                             gridspec_kw={"wspace": 0.46})\n    ax = axes[0]\n    ax.loglog(Om, np.maximum(farr(rows, "Delta_BC"), 1e-16), color=CB, lw=1.1)',
    tag='fig4 size')
rep('ax.text(6e0, 4e-10, "below floor:\\nindistinguishable", fontsize=6.4,\n            color="#555555")',
    'ax.text(6e0, 4e-10, "below floor:\\nindistinguishable", fontsize=8.2,\n            color="#555555")', tag='fig4 f1')
rep('ax.set_ylim(1e-10, 1e-4); ax.legend(fontsize=6.8, loc="upper left")',
    'ax.set_ylim(1e-10, 1e-4); ax.legend(fontsize=8.4, loc="upper left")', tag='fig4 leg a')
rep('ax.set_ylim(1e-3, 1e3); ax.legend(fontsize=6.8, loc="upper left")',
    'ax.set_ylim(1e-3, 1e3); ax.legend(fontsize=8.4, loc="upper left")', tag='fig4 leg b')
rep('ax.text(2e-3, 0.1, "strongly separated\\n($\\\\sim1.4\\\\times10^{7}\\\\times$floor)",\n            fontsize=6.4, color="#555555")',
    'ax.text(2e-3, 0.1, "strongly separated\\n($\\\\sim1.4\\\\times10^{7}\\\\times$floor)",\n            fontsize=8.2, color="#555555")', tag='fig4 annot')
rep('ax.legend(fontsize=6.8, loc="lower left")', 'ax.legend(fontsize=8.4, loc="lower left")',
    tag='fig4 leg c')

# ============================ FIG 5 ============================
rep('fig, axes = plt.subplots(1, 3, figsize=(7.9, 2.8))',
    'fig, axes = plt.subplots(1, 3, figsize=(12.6, 3.8),\n                             gridspec_kw={"wspace": 0.52})\n    plt.subplots_adjust(left=0.075)', tag='fig5 size')
rep('fontsize=6.4, loc="lower left", title="B dashed / C dash-dot",\n              title_fontsize=6.0)',
    'fontsize=8.2, loc="lower left", frameon=True, framealpha=1.0,\n              edgecolor="none", title="B dashed / C dash-dot", title_fontsize=7.8)',
    tag='fig5 leg a')
rep('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$\\Delta_{BC}$")\n    ax.legend(fontsize=6.4, loc="lower right")\n    panel(ax, "b")',
    'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$\\Delta_{BC}$", fontsize=9)\n    ax.legend(fontsize=8.2, loc="lower right", framealpha=1.0, edgecolor="none")\n    panel(ax, "b")', tag='fig5 leg b')
rep('ax.set_ylabel(r"$\\Delta_{BC}$")\n    ax.legend(fontsize=6.4, loc="lower right")\n    panel(ax, "c")',
    'ax.set_ylabel(r"$\\Delta_{BC}$", fontsize=9)\n    ax.legend(fontsize=8.2, loc="lower right", framealpha=1.0, edgecolor="none")\n    panel(ax, "c")', tag='fig5 leg c')

# ============================ FIG 6 ============================
rep('fig, axes = plt.subplots(1, 2, figsize=(7.6, 2.85))\n    for axi, (xname, use_chi) in enumerate((("Omega", False), ("chi", True))):',
    'fig, axes = plt.subplots(1, 2, figsize=(10.6, 3.8),\n                             gridspec_kw={"wspace": 0.32})\n    for axi, (xname, use_chi) in enumerate((("Omega", False), ("chi", True))):', tag='fig6 size')
rep('ax.legend(fontsize=5.9, loc="upper left", ncol=1)',
    'ax.legend(fontsize=8.0, loc="upper left", ncol=1, framealpha=1.0,\n                  edgecolor="none")', tag='fig6 leg')

# ============================ FIG 7 ============================
rep('fig, axes = plt.subplots(1, 2, figsize=(7.6, 2.85))\n    ax = axes[0]\n    ax.loglog(Om, np.maximum(farr(rows, "dV_over_V_C"), 1e-16)',
    'fig, axes = plt.subplots(1, 2, figsize=(10.6, 3.8),\n                             gridspec_kw={"wspace": 0.40})\n    ax = axes[0]\n    ax.loglog(Om, np.maximum(farr(rows, "dV_over_V_C"), 1e-16)', tag='fig7 size')
rep('ax.set_ylim(1e-12, 1e-4); ax.legend(fontsize=6.8, loc="lower right")',
    'ax.set_ylim(1e-12, 1e-4); ax.legend(fontsize=8.4, loc="lower right")', tag='fig7 leg a')
rep('ax.set_xlabel(r"$\\Omega^*$")\n    ax.set_ylabel(r"$|\\delta^*_{cl}-\\delta^*_{fr}|/\\delta^*_{fr}$")\n    ax.legend(fontsize=6.8, loc="lower right")\n    panel(ax, "b")\n    fig.text(0.5, -0.06,\n             "Model A: clamping the phason removes the carrier of its "\n             "surface mode -- no finite-speed clamped branch exists "\n             "(degenerate minima not plotted).",\n             fontsize=7.2, ha="center", style="italic", color="#333333")',
    'ax.set_xlabel(r"$\\Omega^*$", fontsize=9)\n    ax.set_ylabel(r"$|\\delta^*_{cl}-\\delta^*_{fr}|/\\delta^*_{fr}$", fontsize=9)\n    ax.legend(fontsize=8.4, loc="lower right")\n    panel(ax, "b")', tag='fig7 note+label')

# ============================ FIG 8 ============================
rep('fig, axes = plt.subplots(3, 3, figsize=(8.6, 7.8), squeeze=False)',
    'fig, axes = plt.subplots(3, 3, figsize=(9.6, 8.6), squeeze=False)', tag='fig8 size')
rep('ax.set_title(f"{mod},  $\\\\Omega^*={Omv:g}$", fontsize=8.2)\n            ax.tick_params(labelsize=7)',
    'ax.set_title(f"{mod},  $\\\\Omega^*={Omv:g}$", fontsize=9.2)\n            ax.tick_params(labelsize=7.6)', tag='fig8 title/ticks')
rep('if im == 2: ax.set_xlabel(r"Re\\,$p$", fontsize=8.5)\n            if io == 0: ax.set_ylabel(r"Im\\,$p$", fontsize=8.5)\n            ax.margins(0.12)',
    'if im == 2: ax.set_xlabel(r"$\\mathrm{Re}\\,p$", fontsize=9.5)\n            if io == 0: ax.set_ylabel(r"$\\mathrm{Im}\\,p$", fontsize=9.5)\n            ax.margins(0.16)', tag='fig8 mathtext labels')
rep('["admissible", "excluded", "grazing"],\n                      fontsize=7, loc="lower left")',
    '["admissible", "excluded", "grazing"],\n                      fontsize=8.2, loc="lower left", framealpha=1.0)', tag='fig8 legend')
rep('fig.subplots_adjust(hspace=0.32, wspace=0.14)',
    'fig.subplots_adjust(hspace=0.42, wspace=0.22)', tag='fig8 spacing')

# ============================ FIG 9 ============================
rep('ax.set_zlabel(zlab, fontsize=7.5, labelpad=0.5)\n    ax.tick_params(labelsize=6.2)',
    'ax.set_zlabel(zlab, fontsize=8.2, labelpad=5)\n    ax.tick_params(labelsize=7.2)', tag='fig9 zlabel')
rep('ax.set_xlabel(r"$\\log_{10}\\Omega^*$", fontsize=7.5, labelpad=1)',
    'ax.set_xlabel(r"$\\log_{10}\\Omega^*$", fontsize=7.5, labelpad=4)', tag='fig9 xlabel pad')
rep('ax.set_ylabel(r"$\\log_{10}D_w^*$", fontsize=7.5, labelpad=1)',
    'ax.set_ylabel(r"$\\log_{10}D_w^*$", fontsize=7.5, labelpad=11)', tag='fig9 ylabel pad')
rep('fig = plt.figure(figsize=(7.9, 3.55))', 'fig = plt.figure(figsize=(12.4, 4.4))', tag='fig9 size')
rep('fig.subplots_adjust(left=0.0, right=1.0, wspace=0.08)',
    'fig.subplots_adjust(left=0.01, right=0.99, wspace=0.30)', tag='fig9 spacing')

# ============================ FIG 10 ============================
rep('fig, ax = plt.subplots(figsize=(6.6, 3.1))', 'fig, ax = plt.subplots(figsize=(8.8, 3.9))',
    tag='fig10 size')
rep('pm = ax.pcolormesh(Xg, Yg, Z, shading="auto", cmap="viridis")',
    'pm = ax.pcolormesh(Xg, Yg, Z, shading="auto", cmap="viridis",\n                       vmin=-16.5, vmax=-4.0)', tag='fig10 vlims')
rep('fig.colorbar(pm, ax=ax, label=r"$\\log_{10}\\Delta_T$", pad=0.01)',
    'cb = fig.colorbar(pm, ax=ax, pad=0.01)\n    cb.set_label(r"$\\log_{10}\\Delta_T$", fontsize=9.5)\n    cb.ax.tick_params(labelsize=8)', tag='fig10 cbar')
rep('ax.set_yticklabels([f"{t:g}" for t in d["taus"]], fontsize=7.2)',
    'ax.set_yticklabels([f"{t:g}" for t in d["taus"]], fontsize=8.4)', tag='fig10 yticks')

# ============================ FIG 11 ============================
rep('fig, axes = plt.subplots(1, 2, figsize=(7.6, 2.85))\n    ax = axes[0]\n    for mod, c, s in (("A", CA, SM), ("B", CB, SB), ("C", CC, SC)):\n        rr = [r for r in rows if r["model"] == mod]\n        ax.loglog(farr(rr, "Omega"), farr(rr, "delta_pen"), color=c, ls=s,',
    'fig, axes = plt.subplots(1, 2, figsize=(10.6, 3.8),\n                             gridspec_kw={"wspace": 0.32})\n    ax = axes[0]\n    for mod, c, s in (("A", CA, SM), ("B", CB, SB), ("C", CC, SC)):\n        rr = [r for r in rows if r["model"] == mod]\n        ax.loglog(farr(rr, "Omega"), farr(rr, "delta_pen"), color=c, ls=s,', tag='fig11 size')
rep('ax.legend(fontsize=7, loc="upper right")', 'ax.legend(fontsize=8.4, loc="upper right")',
    tag='fig11 leg a')
rep('ax.text(2e-3, 3.4, "$\\\\Omega^*\\\\delta^*\\\\approx$ const $\\\\Rightarrow$ "\n            "$\\\\delta^*\\\\propto1/\\\\Omega^*$", fontsize=6.8)',
    'ax.text(2e-3, 3.4, "$\\\\Omega^*\\\\delta^*\\\\approx$ const $\\\\Rightarrow$ "\n            "$\\\\delta^*\\\\propto1/\\\\Omega^*$", fontsize=8.4)', tag='fig11 annot')
rep('ax.legend(fontsize=7, loc="lower right")', 'ax.legend(fontsize=8.4, loc="lower right")',
    tag='fig11 leg b')

# ============================ shared label bumps ============================
for a, b, t in [
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$V^*=\\Omega^*/k^*$")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$V^*=\\Omega^*/k^*$", fontsize=9)', 'lab 3a'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$|V_B-V_C|$")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$|V_B-V_C|$", fontsize=9)', 'lab 3b'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$\\Delta_{BC}$")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$\\Delta_{BC}$", fontsize=9)', 'lab 4a'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$\\Delta_{BC}\\,/\\,$floor")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$\\Delta_{BC}\\,/\\,$floor", fontsize=9)', 'lab 4b'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$\\Delta_{AC}$")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$\\Delta_{AC}$", fontsize=9)', 'lab 4c'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$V^*$")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$V^*$", fontsize=9)', 'lab 5a'),
    ('ax.set_ylabel(r"$\\Delta_T$")',
     'ax.set_ylabel(r"$\\Delta_T$", fontsize=9)', 'lab 6'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$|\\Delta V|/V$ (clamped vs free)")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$|\\Delta V|/V$ (clamped vs free)", fontsize=9)', 'lab 7a'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$\\delta^*=1/|\\mathrm{Im}\\,p|$")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$\\delta^*=1/|\\mathrm{Im}\\,p|$", fontsize=9)', 'lab 11a'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$\\Omega^*\\delta^*$")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$\\Omega^*\\delta^*$", fontsize=9)', 'lab 11b'),
    ('ax.set_xlabel(r"$\\chi=\\Omega^*/\\Omega_c=\\Omega^*\\rho_w^*/D_w^*$")',
     'ax.set_xlabel(r"$\\chi=\\Omega^*/\\Omega_c=\\Omega^*\\rho_w^*/D_w^*$", fontsize=9)', 'lab 5c'),
    ('ax.set_xlabel(r"$\\Omega^*$" if not use_chi else r"$\\tau_0^*\\Omega^*$")',
     'ax.set_xlabel(r"$\\Omega^*$" if not use_chi else r"$\\tau_0^*\\Omega^*$", fontsize=9)', 'lab 6x'),
]:
    rep(a, b, tag=t)

open('make_all_figures.py', 'w').write(src)
print(f"OK: {len(log)} patches applied")
