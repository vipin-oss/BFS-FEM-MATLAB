# supplementary/ — supplementary material

**No supplementary material is contained in this Overleaf folder.** The
accompanying reproducibility package (solver modules, drivers, raw data,
validation records, audit logs, and figure-generation scripts) is submitted
**separately as supplementary material** at the journal together with this
manuscript; it is not duplicated here to keep the Overleaf project minimal.

The folder is retained so the layout is complete and any future supplementary
material has a designated location.

Historical note: the source package carried
`manuscript/supplementary/README.md` with the same statement.
