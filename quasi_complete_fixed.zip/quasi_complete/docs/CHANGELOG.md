# CHANGELOG.md

## Journal-style revision for AMM submission (2026-09-29)

- Manuscript (`overleaf/main.tex` = `program/manuscript/FINAL_MANUSCRIPT.tex`)
  rewritten for Applied Mathematics and Mechanics (English Edition):
  abstract ≤150 words without mathematics; MSC 2010; introduction without
  subsection headings; RQ1–RQ4 labels removed; noun-phrase section headings;
  §6.2/§6.3 merged (cross-references renumbered); software/audit wording
  removed; limitations as prose; data-availability statement (no
  supplementary material); nomenclature and all tables reset to full text
  width. No computed number, equation or result was changed.
- Corrections found in the final read-through: phason balance law written
  for both components (∂_j H_ij = L[w_i]); uncited "Ding et al., 1993"
  mention removed; Fig. 2(a) caption corrected (panel shows velocity ratios,
  not log deviations); Fig. 6 discussion moved to §6.1; undefined symbols in
  §7.7 removed; unsupported "1D lowering" statement in §7.8 rephrased.
- Bibliography (`references.bib` = `FINAL_MANUSCRIPT.bib`, embedded list in
  `main.tex`): AMM reference style, order of first citation; corrected
  first author of shaonan2025actamech (Lu, S., not Li, S.) with full author
  list and 236(8), 4627–4654; zhang2021acta 232(1), 135–151; chadwick1970
  pages 255–274; yang2022zamm year 2023 and title; zhang2025zamm 105,
  e70114; bleustein1968 pages 412–413.
- Figures: Fig. 1 — field-box text no longer clipped, y axis drawn as
  out-of-page symbol, "Laue 10" label removed; Fig. 2 — excluded coarse-scan
  marker 0.934208 removed from panel (a), legend labels "[gate]"/"[evidence]"
  replaced by plain labels. Patches appended to
  `program/figures/reapply_figure_patches.py` (reproduces
  `make_all_figures.py` byte-identically). Fig01/Fig02.eps regenerated with
  `pdftops -eps`. Figures 3–11 regenerate pixel-identically.
- Re-verification: `run_all.py` PASS (invariants 22/22, figures, manuscript
  31 pp, 0 errors, 0 warnings, 0 undefined references); tests V0, V1, V2, V4,
  V5 PASS; raw-data SHA-256 checksums unchanged.

- Round 2 (same day): title changed to "Effect of phason dynamics on surface
  waves in a two-dimensional hexagonal piezoelectric thermoelastic quasicrystal
  half-space"; abstract rewritten (187 words); all 11 figure captions
  shortened; Fig. 1 redrawn (wave field, coordinate triad, amplitude–depth
  profile); patch appended to `reapply_figure_patches.py` (byte-identical
  reproduction verified); Fig01.eps regenerated. `run_all.py` PASS
  (invariants 22/22; manuscript 30 pp, 0 errors, 0 warnings); Figs 3–11
  pixel-identical to the previous build.
- Round 3 (final): abstract ends with an application statement; MSC line
  removed; limitations reduced to three bullets; over-detailed caveats and
  repetitions removed throughout (decoupling argument, boundary-condition
  discussion, conditioning numbers, continuation-seed details, thermal
  dip counts, 1D comparison, penetration-depth discussion); conclusions end
  with an application paragraph. No computed result changed. `run_all.py`
  PASS (invariants 22/22; manuscript 27 pp, 0 errors, 0 warnings).

## Submission build (corrections + re-verification, 2026-09-28)

- Full independent audit of the 2026-09-08 archive followed by a
  corrections pass; raw data, solver, and drivers are byte-unchanged.
- Corrections applied (see 12_CORRECTIONS/CORRECTIONS.md for the full
  log with data evidence): fig4(b) resolution crossing (Ω*≈6 → ≈50–56);
  fig9 z-axis ranges set to the exact data min/max (caption + code +
  regenerated fig9.pdf, 5 copies); fig6(b)/fig10/§6.5/§7.5
  τ0*Ω* similarity claim replaced by the verified onset
  (1.3e-5–1.4e-2) and factor ~2–4.5 matched-χ agreement;
  near-baseline thermal claim corrected (bracketed by swept neighbours,
  order 1e-5, resolvable above Ω≈1); interference-node count made
  reproducible (11–19 resolved local minima per curve); fig5(b) maximum
  location (D_w*≤1); fig7/§6.6 monotonicity qualified (monotone above the
  floor); §3.5 κ(B) → ~5e10 and residual range → 2e-11–3.3e-5;
  §5.3 envelope statement de-inverted (Ω_c/Ω grows, Ω/Ω_c→0);
  §6.1 P_w and δ* ranges re-anchored to the full grid; fig8 caption
  pairing statement corrected (exact p↔−p pairing, not conjugate);
  §5.1 explanation added for the excluded 0.934208 record.
- Bibliography corrected: francoual2003 is PRL 91, 225501 (2003),
  "Dynamics of phason fluctuations in the i-AlPdMn quasicrystal"
  (the previous entry cited an unrelated article, PRL 91, 225502);
  yang1994prb completed (title, pages 12656–12661, DOI, author order);
  deboissieu2012 completed (pages 6778–6786, DOI); audit-note text
  removed from the bibliography.
- Re-verification: all 11 figures reproduce pixel-identically from raw
  data (fig9 differs only by the corrected z-framing, EPS companion
  Fig09.eps regenerated to match); both manuscript PDFs rebuilt (30 pp);
  manifests and checksums regenerated; full verification suite re-run
  (see 12_CORRECTIONS and validation logs).
- Third verification pass: Section 7.2 participation range corrected to
  1.3e-17–1.8e-5 (second instance, C15); Section 5.2 two-path worst
  difference corrected to 9.35e-10 to match the V1 log (C16); recorded
  that the archive's rendered PDF was stale relative to its own shipped
  source (C18) — the rebuilt PDFs faithfully render the source,
  including the V4-verified equation (14) without the spurious k^4
  factor and the corrected Fig. 3 / Section 5.2 root-count narrative.
- External audit response (C19-C28): Rayleigh comparison corrected (sheets
  straddle/lie above the decoupled Rayleigh speed); thermal interference-node
  claim removed (dips are sub-floor scatter); complex-wavenumber dispersion
  check added at 13 representative points (Section 5.5 + table + validation
  log; real-axis speeds verified to <=6.6e-7 relative, model differences far
  better); nonexistence claims search-qualified; pencil/boundary rows and
  tolerances printed (Section 3.7); nondimensionalisation derivation made
  explicit (sigma0 = beta1*T0); P_w and delta* defined; electrical decoupling
  written out (speeds independent of e_ij); resolvability language corrected;
  chi collapse quantified (factor <=1.004); dimensional endpoint table with
  continuum-validity caveat (lambda ~ 0.47 nm at the band top); k11
  sensitivity spot check (1.8e-6); package inventory in data availability.

## Archive closure (final archival packaging, 2026-09-07)

- Built self-contained long-term archive FINAL_QC_SURFACE_WAVES_RESEARCH_ARCHIVE
  from the accepted Task-15 package (science untouched; packaging only).
- Restructured per archive spec: tests/V0…V5 subdirs; figures/style.py and
  figures/make_all_figures.py at figures/ level (paths updated);
  results/manifests/ (raw checksums); verification/{branch_identity,symbolic,
  model_limits,two_path,reports}/; manuscript/{supplementary,figures}/;
  literature/ (metadata-only, 47-entry bib, 8 categories); provenance/ (4
  documents); archive/ (both historical packages).
- run_all.py: manuscript/figures/ journal copies auto-synced before compile.
- Pipeline re-verified in place: invariants 22/22 PASS; figures regenerated
  content-identical; manuscript 29 pp, 0 errors.

## Task 15 (figure polishing + reproducible package closure, 2026-09-07)

- Baseline frozen: upstream ZIP sha256 b8178605…c4244ec2; git ea257c9;
  solver record hash 8c0abbabe66776dd. No science reopened.
- Built FINAL_RESEARCH_PAPER_PACKAGE/: solver, drivers, tests, raw data
  (byte copies), figures pipeline (style.py + make_all_figures.py →
  fig1..fig11.pdf), manuscript (graphicspath-adapted), 6 audits,
  verification/verify_invariants.py (22 checks incl. branch identity at
  Ω*=1000: V_C(D_w*→0)=0.3107266158, |ΔV|=2.4e-11, NOT the 0.467 branch),
  run_all.py (default / --check-only / --from-scratch).
- Fig2a annotations made data-driven (formatted from CSV; grep-verified
  zero hand-typed result values).
- Compile loop fixed to rerun until cross-references stabilise (0 warnings).
- Clean-room reproduction test PASS (fresh dir, artifacts deleted, all
  figures stream-identical, manuscript 29 pp / 0 err / 0 warn).
- Task-15 package archived verbatim at
  archive/FINAL_QC_SURFACE_WAVES_PAPER_PACKAGE_2026-09-07.zip
  (sha256 1c7c55d7672ecf8d9229a44a2b68b0dfe2348e7305042f11a9e87036e8042fe6).


## Task 14 (figure redesign, 2026-09-07) — delta over Task 13

- Figures: 13 → 11. New generation script `figures_v2/make_figures_v2.py`;
  outputs in `figures_v2/`. Old Task-13 script retained for provenance.
- Fig. 1 fully redrawn (embedded title/paragraph removed; continuum-style
  schematic with decay envelope, δ* bracket, BC line, fields/model box).
- Fig. 2 = merged old 2a+2b (2 panels; de-cluttered labels; roundoff band).
- Fig. 3 = 3 panels (branches; |V_B−V_C| vs absolute floor; P_w).
- Fig. 4 = 3 panels (ΔBC; ΔBC/floor with unity criterion; ΔAC).
- Fig. 5 = 3 panels (B/C V* slices at D_w*=1e-2,1,1e2,1e4; ΔBC; χ=Ω*/Ω_c
  master-curve collapse).
- Fig. 6 = 2 panels (Δ_T(Ω*); Δ_T(τ0*Ω*) with merged relaxation branch).
- Fig. 7 = 2 panels (ΔV/V; δ* change) + model-A note; degenerate A values
  never plotted.
- Fig. 8 = enlarged 3×3 roots, per-panel scaling.
- Fig. 9 = NEW genuine 3D: V_B, V_C, log10 Δ_BC surfaces with base-plane
  contour projections; z-ranges exactly the data ranges; Ω_c reference line
  on base plane labelled reference-only.
- Fig. 10 = old 9c as exact-cell heatmap with sample dots (no interpolation).
- Fig. 11 = old 8b upgraded to 121-pt δ*(Ω*) + Ω*δ* scaling panel.
- Captions rewritten in sample-paper style; all cross-references remapped
  (fig2a/2b→2, 9a/9b→9, 9c→10, 8b→11); surrounding interpretation paragraphs
  extended per panel (question→figure→observation→mechanism→implication).
- Science frozen: no number, equation, parameter, gate, floor, branch
  identity, or conclusion changed; raw data read-only; no new simulations.
- New/updated deliverables: FIGURE_REDESIGN_AUDIT.md,
  FIGURE_DATA_TRACEABILITY.md, SPIKE_AND_ANOMALY_AUDIT.md, this changelog,
  FINAL_PRODUCTION_REPORT.md.
- Build: 30 pp, 0 errors / 0 LaTeX warnings / no overfull ≥10 pt; figures
  within one page of first citation.

---

# FINAL_MANUSCRIPT_CHANGELOG.md — Task 13 (presentation upgrade, 2026-09-07)

Baseline: Task-12 FINAL_MANUSCRIPT (21 pp, 18 refs, 13 figures).
Output: 30 pp, 47 refs, 13 figures. **Science frozen throughout: no equation,
parameter, number, gate, threshold, or claim was changed.** All numerical
values in the rewritten manuscript were carried over verbatim from the Task-12
text; figures were regenerated from the same raw data files.

## 1. Structure

- Introduction expanded from ~1.5 pp of unnumbered prose to ~3 pp with
  numbered subsections 1.1–1.5 (sample-paper style): QC/phason foundations →
  phason dynamics classes → surface waves in anisotropic/piezoelectric/
  thermoelastic media → 1D vs 2D hexagonal QC literature → gap, RQ1–RQ4,
  contributions, roadmap. Note: ~3 pp rather than ~2 pp because the verified
  literature base grew from 18 to 47 references; each paragraph states what it
  establishes and why it matters for this study (no citation dumping).
- §5–§6 split: "Verification and benchmarks" (§5) and "Results" (§6) with a
  per-figure interpretation paragraph immediately after each figure
  (what is plotted / what changes / what does not / mechanism / what it
  supports for the RQs / limitations).
- New §7 Discussion with subsections 7.1–7.9 (branch selection; model A
  physics; model B physics; model C and Ω/Ω_c; why the thermal effect is
  small; phason BC physics; penetration structure; relation to 1D hexagonal
  literature; limitations incl. new items 2D-hex scope and parameter ranges).
- §8 Conclusions rewritten as 6 items, each with result + physical meaning +
  modelling implication.
- Nomenclature, Data-availability, Declarations unchanged (placeholders kept).

## 2. Bibliography: 18 → 47 entries

- 29 new entries, all verified by web search on 2026-09-06/07 (see
  FINAL_REFERENCE_AUDIT.md tiers V1/V2). Notable corrections during
  verification: Fan & Mai review is AMR **57**:325–343 (**2004**), not
  AMR 56:549 (2003) as memory suggested; Lubensky–Ramaswamy–Toner
  hydrodynamics paper is PRB **32**:7444 (1985), not PRL.
- Rejected (metadata could not be verified): Socolar 1991 dodecagonal
  elasticity; Abe 2000 PRL; Results-in-Physics 60 (2024) Lamb-wave paper
  (conflicting article numbers 107674/107464); Crystals 14:170 (2024)
  (authors not confirmed); Chadwick & Windle 1964 (not found; replaced by the
  verified Chadwick & Seet 1970 Mathematika thermoelastic-surface-wave paper).
- All 1D hexagonal wave references are labelled 1D at every use; no 1D result
  supports a 2D claim.
- Orphan/undefined/duplicate checks: 0/0/0 (script-verified).

## 3. Figures

- New script `submission/make_figures_publication.py` regenerates 12 PDFs into
  `submission/figures_pub/` from the accepted raw data (read-only):
  identical datasets and plotted quantities to the accepted figures;
  **no embedded titles or caption text** (all captions now live only in the
  tex); serif typography, panel letters (a)/(b)/(a)–(i), compact legends,
  consistent colours (Okabe-Ito) and line weights.
- fig1_schematic.pdf reused unchanged (conceptual drawing, no embedded
  caption).
- The legacy coarse-scan record point (0.934208) in fig2a is **kept** and
  relabelled neutrally ("coarse-scan record, excluded"); the fig6 reference-τ
  flat line and the fig2b frozen 1e-8 evidence curve are kept and explained in
  captions (see FINAL_FIGURE_AUDIT.md items F1–F7).
- Lineage: raw CSV/NPZ (study1_surface_waves/results) → script → figures_pub
  PDF → tex caption; table in FINAL_FIGURE_AUDIT.md §1.

## 4. Suspicious-feature inspection (Part 10)

- Automated scan of every plotted curve (step sizes, NaN census, root counts,
  conditioning, map smoothness) — results and classification of the seven
  flagged features in FINAL_FIGURE_AUDIT.md. No data hidden, smoothed,
  deleted, or cropped; nothing required a fix in the data.

## 5. Language and claim discipline

- Removed the single borderline word ("dramatic" → "change only marginally");
  grep audit for obviously/remarkable/clearly seen/excellent agreement/
  striking/groundbreaking/first-ever: 0 hits.
- Preserved: Ω_c/ω0≈11467.5 reference-line-only treatment; no crossover claim
  in the baseline window; Fig. 9b "reference line only"; 95/121 with the
  91/121 footnote; model-A clamped degeneracy honest handling; k11 6 vs 5.3
  disclosure; surrogate labels; "to the best of our knowledge, within the
  literature surveyed"; no experimental-observability claims; FEM mentioned
  only to state it is out of scope.

## 6. Build

- pdflatex ×2, rc=0, **0 errors, 0 LaTeX warnings**, no overfull boxes ≥10 pt,
  30 pages (within the 26–30 target), all 13 figures embedded, all citations
  resolved.

## 7. Not changed (deliberately)

- All equations, parameter tables, verification gates, sweep results, floor
  conventions, E2 footnote, limitations content (extended, not weakened).
- The accepted reproducibility package ZIP (sha256 unchanged) and the git
  history.

## [2026-09-28] REPRODUCIBILITY ARCHIVE BUILD (v1.0 of SURFACE_WAVES_2D_HEXAGONAL_QC_COMPLETE_REPRODUCIBILITY_ARCHIVE)
- Reorganised the corrected submission package (295 files) into the 9-folder
  reproducibility structure; deduplicated hash-identical mirrors; removed caches.
- Added: parameter_manifest.json, run_manifest.json, REPRODUCE_FROM_SCRATCH.md,
  RUN_ORDER.md, EXPECTED_VALUES.md, FIGURE_PROVENANCE.md, DATA_DICTIONARY.md,
  derivations record, validation record with DOIs, SHA-256 integrity manifests.
- Actual reproduction test performed (clean isolated directory): result and
  verdict in FINAL_PACKAGE_STATUS.md at the archive root.
- C29 (path unification, results/raw/) — see CORRECTIONS_ERRATA.md.
- Reference DOIs re-verified against publisher pages (Agiasofitou & Lazar 2014:
  10.1016/j.ijsolstr.2013.11.016; Chellappan et al. 2015: 10.1063/1.4907212;
  Zhang et al. 2023: 10.3390/cryst13081205).
