# FIGURE_PROVENANCE.md — per-figure generation record

All 11 figures are produced by **one deterministic script**:
`program/figures/make_all_figures.py` (style: `program/figures/style.py`),
reading **only** the raw data in `program/results/raw/` (identical to
`data/raw/`). Command: `python3 figures/make_all_figures.py` (working
directory = `program/`). Outputs: `figures/output/fig1..fig6.pdf` +
vector EPS companions `Fig01..Fig11.eps`. No hard-coded data arrays exist in
the plotting code; annotated reference/floor lines are computed from
`params.json` or the plotted columns. Figure-text values quoted below are the
values printed in the manuscript captions (final, audit-verified).

Colour maps are perceptually uniform (viridis family); Fig. 8 colour limits are
the exact data min/max (no vertical exaggeration). Figures 1–7, 9–11 are
pixel-stable across runs on the same Matplotlib version.

---

**Numbering note (layout revision):** printed figures are numbered in order of appearance in the manuscript; `figN.pdf` / `Fig0N.eps` = printed Figure N. The plotting functions in `make_all_figures.py` keep their historical study names (`fig8()` draws the root diagnostic, `fig3()` the baseline study, ...); the name mapping lives in `program/figures/style.py` (`PAPER_NAME`). Data file names (`fig8_roots.csv`, ...) are historical study names and unchanged.

---


## Fig. 1 — `fig1.pdf` / `Fig01.eps` (schematic)

- **Kind:** vector schematic drawn by the figure script (no data file).
- **Content:** half-space z>0 shaded with the schematic field e^{-z/δ*}cos(kx),
  deformed free surface z=0 with the boundary conditions, propagation
  direction e^{i(kx−ωt)}, coordinate triad (x right, z down, y out of the page),
  and an amplitude–depth profile marking δ*.
- **Data:** none (geometry/labels only).
- **Regeneration:** `make_all_figures.py` fig1 block — deterministic.

## Fig. 2 — `fig2.pdf` / `Fig02.eps` (verification benchmarks)

- **Data:** `results/raw/v2_elastic_limit.csv`, `v3_model_limits.csv`
  (+ constants: v_P/v0=1, v_S/v0=0.5 exact decoupled limits).
- **Quoted values (caption):** decoupled Rayleigh ratio 0.932525906 computed vs
  0.932525905931 analytic (rel. err 1.1e-11); coupled quasi-static free-phason
  ratios 0.62145378 (A), 0.9326028 (B/C). Model limits: 121/121 points with
  maximum deviations 1.110e-9 (C→A) / 3.266e-9 (C→B); dashed curve: model C
  at finite friction 1e-8×baseline. (The former coarse-scan marker 0.934208
  was removed from panel (a) in the 2026-09-29 revision.)
- **Regeneration:** from raw + V2/V3 logs; rerunning tests refreshes the raw files.

## Fig. 4 — `fig4.pdf` / `Fig04.eps` (baseline surface response)

- **Data:** `results/raw/study1_baseline.csv` (363 rows), `fig4_deltas.csv`.
- **Panels:** (a) V*(Ω*) for A/B/C + v_S*=0.5 reference; (b) |V_B−V_C| vs
  absolute floor ε_Δ=1.13e-8 (shaded); (c) phason participation P_w.
- **Quoted values:** A ≈ 0.311 (phason-dominated), B/C ≈ 0.466
  (phonon–Rayleigh); B−C separation grows to 4.4e-6 absolute (9.5e-6 relative)
  at the band top; P_w(A) ≈ 0.991 (caption-value basis; raw column basis
  0.9909513 — see §5.6 clarification in the manuscript).
- **Regeneration:** `study1_baseline.py` → `make_all_figures.py` fig3 block.

## Fig. 5 — `fig5.pdf` / `Fig05.eps` (model differences + resolution logic)

- **Data:** `results/raw/fig4_deltas.csv` (363 rows).
- **Quoted values:** relative Δ_BC with floor ε_Δ/V ≈ 2.42e-8 (95/121 points
  sub-floor); floor-normalised curve crosses unity only above Ω* ≈ 50–56;
  Δ_AC ≈ 0.334 ≈ 1.4e7 × floor (branch-identity difference).
- **Regeneration:** produced as the derived dump of `study1_baseline.py`.

## Fig. 7 — `fig7.pdf` / `Fig07.eps` (controlled-friction study)

- **Data:** `results/raw/study2_map_incremental.csv` (7442 rows),
  `fig5_friction1d.csv` (49 rows).
- **Panels:** (a) V*(Ω*) for B/C at D_w* = 1e-2, 1e0, 1e2, 1e4; (b) Δ_BC(Ω*)
  with floor; (c) differences vs competition coordinate χ = Ω*τ_tel(D_w*)
  (matched-χ collapse factor ≤ 1.0035 — audit-verified worst factor; do not
  re-derive panel (c) by index shifts).
- **Quoted values:** max Δ_BC ≈ 5.0e-3 for D_w*≤1; ≤1.25e-7 at D_w*=1e4;
  dips above floor 0/0/1/0 (only τ0*=1e-2, Ω*=44.7, ΔT=5.83e-8 — see Fig. 9 data).
- **Regeneration:** `study2_friction_map.py` (~15–25 min) → fig5 block.
  NB: the driver is restart-capable; delete `results/raw/study2_map_incremental.csv`
  for a true from-scratch rerun.

## Fig. 9 — `fig9.pdf` / `Fig09.eps` (thermal-relaxation sensitivity)

- **Data:** `results/raw/fig6_tau.csv` (605 rows).
- **Quoted values:** ΔT=|V(τ0*)−V(τref*)|/V(τref*) vs Ω* and vs τ0*Ω*; reference
  τ0*=4.3462e-3 gives ΔT≡0 by construction; onset at τ0*Ω*=1.3e-5–1.4e-2;
  ΔT maxima per τ0*: 1.09e-5 / 1.07e-5 / 2.94e-5 / 7.879e-5; floor-crossing
  dips above the 1e-16 display floor: 0/0/1/0.
- **Regeneration:** `study3_thermal.py` → fig6 block.

## Fig. 11 — `fig11.pdf` / `Fig11.eps` (phason boundary condition)

- **Data:** `results/raw/fig7_bc.csv` (484 rows), `fig7_bc_summary.csv` (121 rows).
- **Quoted values:** |ΔV|/V (model C, clamped vs free) grows 1e-9 → 8.1e-6
  (Ω*: 1e-3 → 1e3); 33 noise-level inversions below Ω*≈1.3 (sub-floor);
  penalty column δpen comparable magnitude. (Model A companion values in raw
  data: fig7 dV/V max 8.0609e-6 — audit-verified.)
- **Regeneration:** `study_bc.py` → fig7 block.

## Fig. 3 — `fig3.pdf` / `Fig03.eps` (depth-root structure)

- **Data:** `results/raw/fig8_roots.csv`, `fig8_roots_summary.csv`.
- **Content:** pencil roots at reference k*=2Ω*, models × Ω* = 0.1/10/1000;
  admissible circles (B/C: 5 per panel; A at reference scan: 4 + 2 grazing
  squares — documented near-grazing behaviour V*<√(K3*) off the solved branch;
  on the solved branch n_ad=5, n_grazing=0 for all models).
- **Regeneration:** `roots_diag.py` → fig8 block.

## Fig. 8 — `fig8.pdf` / `Fig08.eps` (3D study-2 representation)

- **Data:** `results/raw/study2_map_incremental.csv` + `fig9b_map_dBC.npz`
  (boundary-cell fields), `fig6_tau.csv` / `fig9c_map_dT.npz` (panels c,d as per
  caption).
- **Quoted values:** z-limits exactly [0.464987, 0.466301] (V_B) and
  [0.466264, 0.467355] (V_C) — no vertical exaggeration; log10 Δ_BC resolvable
  plateau ≳ −3 at low D_w*.
- **Regeneration:** fig9 block + NPZ precompute (produced by the study2/study3
  pipeline; see `04_REPRODUCTION/RUN_ORDER.md`).

## Fig. 10 — `fig10.pdf` / `Fig10.eps` (thermal map)

- **Data:** `results/raw/fig6_tau.csv` (605 rows; 5×121 cells, no interpolation).
- **Quoted values:** reference row ΔT≡0 (display clip); resolvable band
  upper-right; low-Ω* edge tracks τ0*Ω* = 1.3e-5–1.4e-2.
- **Regeneration:** fig10 block.

## Fig. 6 — `fig6.pdf` / `Fig11.eps` (surface localisation)

- **Data:** `results/raw/study1_baseline.csv` (δ* columns), `fig8_roots_summary.csv`.
- **Quoted values:** δ*=1/|Im p| vs Ω* per model (121 points each); Ω*δ*
  ≈ constant 1.99 (A), 1.29 (B/C) across six decades (classical 1/Ω*
  localisation); δ* is depth localisation, not attenuation.
- **Regeneration:** fig11 block.

---

## Figure-text values audit trail

Every number printed in a figure caption was verified against the raw data in
the 2026-09-28 audit (see `07_DOCUMENTATION/CORRECTIONS_ERRATA.md` C1–C28 for
the correction history; `FIGURE_DATA_TRACEABILITY.md` for the panel→column map).
The only numerical corrections since the first draft were caption/metric
clarifications (e.g. P_w wording), documented in the errata — figure *geometry*
was corrected once (Fig. 8 z-limits, erratum C-series) and re-verified.

## Determinism note

Regenerated figure PDFs embed the creation timestamp and Matplotlib version in
their metadata, so byte-identity across runs is NOT expected; pixel-identity is
expected on the same Matplotlib version, and curve-identity (data bitwise-equal)
across versions.
