# FIX_LOG.md — every change made relative to the original package

This package is the original manuscript/reproducibility archive with a
presentation-fix pass applied. **No scientific content, number, equation, or
data value was changed.** All edits are layout, wording-consistency, and
build-system changes, listed here one by one. **Note:** sections A--D use the
pre-layout figure numbering (figures grouped at the end); section E records the
layout revision (figures inline, renumbered to order of appearance) and carries
the old→new figure mapping table.

## A. Manuscript class & structure

| # | Change | Where |
|---|---|---|
| A1 | `\documentclass[11pt]{article}` + `geometry` → `\documentclass[preprint,12pt]{elsarticle}` (Elsevier standard; `elsarticle.cls` now ships in-package) | `overleaf/main.tex` preamble |
| A2 | Title/author/abstract/keywords converted to `elsarticle` frontmatter (`\begin{frontmatter}`, `\author`, `\ead`, `\affiliation`, `\cortext`, `\begin{keyword}`) | title page |
| A3 | MSC 2020 (74J15; 74F05; 74F15; 52C23) kept in the abstract block (the `MSC` environment is not supported by all elsarticle versions) | abstract |
| A4 | Figure environments reordered to file-name order → **printed Figure N = `figN.pdf` = `FigN.eps`** (previously the depth-root figure was printed as "Figure 3" while its file was `fig8.pdf`, etc.) | float block before "Data and code availability"; Fig. 1 stays in §2 |
| A5 | Overfull-hbox fixes without content change: nomenclature/model/parameter/nondimensional tables resized (wrapping `p`-columns, `\footnotesize`), three wide one-line equations split into two-line `align` rows, `\emergencystretch=3em`, one sentence of §3.x re-ordered (identical information) | throughout |
| A6 | Long `\texttt{...}` file paths → breakable `\path{...}`; the Data-availability package inventory reformatted as an itemized list | Data and code availability |

## B. Figure layout fixes (script: `program/figures/make_all_figures.py`)

All fixes are layout-only; data, panels, annotations, and colours/line styles
are unchanged. The pristine script is kept as
`program/figures/make_all_figures_v1_original.py`; the patch list can be
re-applied with `program/figures/reapply_figure_patches.py` (71 patches).

| Figure | Problem fixed | Fix |
|---|---|---|
| Fig. 1 | Surface wave crossed the "quasicrystal half-space z>0 …" label; field-box text overflowed the box frame; cramped `Im p` in `δ*=1/|Im p|` | white bbox behind the label; box widened & fonts resized so all four box lines fit |
| Fig. 2 | x-tick labels "A (cpl.)"/"B/C (cpl.)" collided; "0.934208 (excl. record)" ran into panel (b); overall fonts too small | 2-line ticks, wider figure/wspace, right-aligned annotation, font bump |
| Fig. 3 | (c) ylabel "phason participation Pw" crossed into panel (b) | 2-line ylabel + `linespacing=1.45`, wider wspace |
| Fig. 4 | (b)/(c) ylabels overlapped neighbouring panels | wider figure + `wspace=0.46` |
| Fig. 5 | (a) `V*` ylabel sat on long tick labels; (b)/(c) ylabels crowded neighbours; legend crossed by curves | wider figure + `wspace=0.52`, left margin, opaque legend frames |
| Fig. 6 | legends cramped (5.9 pt) | larger figure + legend fonts + frames |
| Fig. 7 | long (b) ylabel crowded (a); in-figure italic note duplicated the caption | `wspace=0.40`; note removed (caption retains the sentence) |
| Fig. 8 | **axis labels rendered literally as "Im\,p"/"Re\,p"** (missing math mode); row spacing tight; grazing markers clipped at panel edges | `$\mathrm{Im}\,p$`/`$\mathrm{Re}\,p$`; `hspace=0.42, wspace=0.22`; `margins(0.16)` |
| Fig. 9 | 3D zlabel/ylabel collided with tick labels; panels too close | `labelpad` 5/11/4, `wspace=0.30`, larger figure |
| Fig. 10 | colourbar saturated at the top (data max −4.10 above labelled range); small y-tick labels | explicit `vmin=-16.5, vmax=-4.0` (full data range), font bumps |
| Fig. 11 | fonts small | larger figure + fonts |

Verification: each regenerated figure was checked at text-span level (no
cross-text overlaps except within-label math glyph boxes) and by direct visual
inspection; the patched script regenerates the shipped PDFs **pixel-identically**
(11/11).

## C. Manuscript text corrections

| # | Location | Was | Now | Why |
|---|---|---|---|---|
| C1 | §5.5 | "$\le1.7\%$ of the quoted difference" | "$\le1.7\times10^{-5}$ (i.e.\ $\le0.002\%$) of the quoted difference" | the low-friction complex-mode deviations (8.4×10⁻⁸, 1.7×10⁻⁸) against the quoted ΔBC≈5.0×10⁻³ are a fraction of ≈1.7×10⁻⁵, not 1.7 % (verified against `validation/.../complex_k_dispersion.log`) |
| C2 | Fig. 5 caption + §7.4 | "agree within a factor 1.004 over their common above-floor χ ranges" | "over their pairwise-overlapping (chained) above-floor χ ranges — the four swept χ-windows are chained pairwise and share no four-way common support" | the 4-way common χ support of the swept rectangle is empty; the chained statement is the verified one |
| C3 | §6.5 | "its 11–19 local minima … lie at or below the floor — exactly one dip … rises above the floor" | "… lie at or below the resolution floor — with one exception in the entire sweep, at τ0*=10⁻², Ω*≈44.7, which rises above the floor" | original sentence was self-contradictory |
| C4 | Fig. 8 caption | "… near-grazing behavior ($V^*<\sqrt{K_3^*}$) off the solved branch" | "… at this reference scan, where $V^*<\sqrt{K_3^*}$ (the documented near-grazing threshold of model A); this scan is off the solved branch" | ambiguous attachment of "off the solved branch" |
| C5 | Fig. 7 caption | "of comparable magnitude and likewise growing" | "of the same order and likewise growing" | the two curves are the same order, not equal magnitude |
| C6 | §5.7 / Fig. 6 caption / Conclusions | "three orders of magnitude above the floor" (×2) and "three orders above the floor" | "more than three orders …" (all three) | 7.9×10⁻⁵ / 2.42×10⁻⁸ ≈ 3.3×10³ = 3.5 orders |
| C7 | `supplementary/README.md` | "NOT AVAILABLE. No supplementary material exists…" (contradicts the Data-availability statement) | "No supplementary files in this folder; the reproducibility package is submitted separately at the journal" | internal consistency |

## D. Packaging

| # | Change |
|---|---|
| D1 | `program/figures/make_all_figures.py` is the layout-fixed pipeline (what produced `overleaf/figures/`); pristine v1 kept as `make_all_figures_v1_original.py` |
| D2 | `program/manuscript/FINAL_MANUSCRIPT.tex` = `overleaf/main.tex`, so `run_all.py`'s compile step builds the final manuscript |
| D3 | `elsarticle.cls` shipped in `overleaf/` and `program/manuscript/` |
| D4 | `README_OVERLEAF.md` updated to describe the elsarticle edition |
| D5 | Package-level `README.md` + `MANIFEST.md` added |

## E. Layout revision (template setting; user request)

Sections A--D above describe the first fix pass and use the *pre-layout*
figure numbering (figures were then grouped at the end of the manuscript).
The layout revision renumbered the figures to **order of appearance** and
moved them inline; the mapping is:

| printed Fig. | file | content | pre-layout Fig. |
|---|---|---|---|
| 1 | `fig1.pdf` | configuration geometry | 1 |
| 2 | `fig2.pdf` | verification/limits graphics | 2 |
| 3 | `fig3.pdf` | depth-root structure | 8 |
| 4 | `fig4.pdf` | baseline response | 3 |
| 5 | `fig5.pdf` | baseline model differences | 4 |
| 6 | `fig6.pdf` | surface localisation | 11 |
| 7 | `fig7.pdf` | controlled-friction study | 5 |
| 8 | `fig8.pdf` | study-2 map | 9 |
| 9 | `fig9.pdf` | thermal-relaxation sensitivity | 6 |
| 10 | `fig10.pdf` | thermal map | 10 |
| 11 | `fig11.pdf` | phason boundary condition | 7 |

| ID | Change |
|---|---|
| E1 | All 11 figures placed **inline near their discussion** (the end-of-document `Figures` block was removed). |
| E2 | Figures renumbered to order of appearance; files renamed (`figN.pdf` / `Fig0N.eps` = printed Figure N). The `PAPER_NAME` map in `program/figures/style.py` applies the same renaming at generation time, so `make_all_figures.py` reproduces the shipped names (verified 11/11 pixel-identical). |
| E3 | Preamble rewritten in the template order: mathematics (`amsmath`, `amssymb`, `amsfonts`, `bm`, `mathtools`, `geometry`) → figures/tables (`graphicx`, `booktabs`, `multirow`, `array`, `subcaption`) → units (`siunitx`) → colors (`xcolor`) → `hyperref` (hidelinks) near the end. |
| E4 | Figure captions shortened to 2--4 lines each (template style). Three caption-only caveats were preserved by moving them into the body text (root pairing $p\\leftrightarrow-p$; the four-way $\\chi$-window statement; the 33 sub-floor inversions of the boundary-condition curve). |
| E5 | Labels renamed to descriptive template style (`fig:baseline`, `fig:roots`, ...); all references updated. |
| E6 | Data-availability inventory now names the actual package folders (`overleaf/`, `program/`, `data/`, `validation/`, `docs/`); the complex-$k$ record path corrected to `validation/validation_results/complex_k_dispersion.log`. |
| E7 | Figure-dependent docs updated to the new numbering (`README.md` §5, `FIGURE_PROVENANCE.md`, `FIGURE_DATA_TRACEABILITY.md`, `README_OVERLEAF.md`). Data file names unchanged (historical study names). |

| E8 | Template-conformance polish: `\DeclareMathOperator{\tr}{tr}` / `\sym{sym}` added at the template position; author block in the template `\author[...]\ead{...}\address[...]` form (placeholders preserved); frontmatter banner comments (`%%%% Title %%%%` etc.). |
| E9 | **Regression fix:** the first layout-rewrite pass accidentally dropped the `frontmatter` block (title/authors/abstract/keywords). Restored verbatim from the pre-rewrite backup (abstract, MSC, keywords byte-identical); the final PDF title page is verified present. |

## Not changed (on purpose)

- All physics, equations, parameter values, table values, and quoted numbers
  (except C1, which corrects one erroneous fraction against the archived log).
- The honest "below-floor scatter / double-precision cancellation" captions for
  the noise spikes — these are correct and were verified against the data.
- Bibliography entries (47 items; DOI/consistency audit found no invalid refs).
