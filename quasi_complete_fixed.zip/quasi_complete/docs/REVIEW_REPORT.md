# Manuscript Review Report — `quasi.zip` (BFS-FEM-MATLAB)
**Reviewed:** 2026-09-29 · Manuscript: *Surface waves in a two-dimensional hexagonal piezoelectric thermoelastic quasicrystal half-space…* (35 pages, LaTeX `main.tex`, 11 figures)

---

## 0. Executive Summary (Hinglish)

- **Science aur maths bahut strong hai.** Maine har equation, pencil entry, boundary row, aur har numerical claim independently verify ki hai — sab match karte hain. Koi *scientific* error nahi mila.
- **"Spikes" bilkul OK hain** — wo numerical noise (floor se neeche) aur double-precision cancellation hain, data errors NAHI hain. Aur captions mein already honest explanation likhi hui hai (ye hi aapki referee ke saamne defence hai — hataana mat!).
- **Do bade submission-level issues hain** jo submit karne se PEHLE fix karne chahiye:
  1. **Figure numbers vs file names mismatch** (printed "Figure 3" = `fig8.pdf`/`Fig08.eps`, etc.) — 8 of 11 figures galat naam se mapped hain.
  2. **Reproducibility package ki contradiction** — manuscript "supplementary material" mein pura package promise karta hai, lekin zip ke `supplementary/README.md` mein likha hai "NOT AVAILABLE".
- Ek **numerical statement galat lag raha hai** (Section 5.5 ka "≤1.7%" — ~1000× off), aur kuch figure-label collisions + minor wording issues hain (niche detail mein).

---

## 1. Independently Verified — NO Errors (evidence ke saath)

### 1.1 Formulation (hand-checked line by line)
- All 5 rows of the pencil `M = A₀ + pA₁ + p²A₂` (Section 3.7 implementation record) follow **exactly** from the constitutive equations (2.1–2.4) under `e^{i(kx+pz−ωt)}` — maine har row (uₓ, u_z, wₓ, w_z, θ) manually derive karke match kiya. ✓
- All 5 boundary rows (σ_zz, σ_xz, H_xz, H_zz, θ) match the constitutive law exactly, including the **phason-stress asymmetry** K₃/K₆ placement. ✓
- Identity `A₁(3,4)=A₁(4,3)=−(K₂+K₆)k` consistent with the listing. ✓
- Lord–Shulman thermal row (Φ = iω + τ₀ω², coupling −iT₀β₁Φ) consistent with eq. (LS). ✓
- Static-limit factorisation claim verified **symbolically** (independent sympy computation, exact rationals):
  - `det M(ω=0) = 410478057/25600000000000 · (k²+p²)^5` — **EXACT match** (ratio = 1). ✓✓
  - `deg_p det M = 10` for A, B, C — **EXACT** ✓
  - `deg_ω det M = 10, 8, 10` for A, B, C — **EXACT** ✓
  - `det(A₂) = (C₁₁K₁−R₁²)(C₆₆K₃−R₆²)k₁₁ > 0` — **EXACT match**; value = 1.6034e-5 = the same constant `c` (formulas mutually consistent). ✓✓

### 1.2 Nondimensionalisation & numbers (recomputed from Table 2)
| Quantity | Paper | My recomputation | ✓ |
|---|---|---|---|
| v₀ = √(C₁₁/ρ) | 6917.1446 m/s | 6917.14 | ✓ |
| ω₀ = v₀k₀ | 4.34617e10 rad/s | 4.3462e10 | ✓ |
| U₀ = β₁T₀/(C₁₁k₀) | 4.2636e-10 m | 4.264e-10 | ✓ |
| k₁₁* = k₁₁k₀/(ρc_ev₀) | 2.6077e-3 | 2.6077e-3 | ✓ |
| T₀β₁* = β₁²T₀/(C₁₁ρcₑ) | 2.3047e-3 | 2.3047e-3 | ✓ |
| D_w* | 11467.5 | 11460–11468 (rounding-consistent) | ✓ |
| ω_c = D_w/ρ_w | 4.984e14 rad/s | 4.984e14 | ✓ |
| f_c = ω_c/2π | 79.32 THz | 79.32 | ✓ |
| τ*_tel = 2/Ω_c | 1.744e-4 | 1.744e-4 | ✓ |
| τ_tel = 2/ω_c | 4.013e-15 s | 4.013e-15 | ✓ |
| ν from C₁₂*=0.5 | 1/3 | 1/3 ✓ (Rayleigh 0.932525906 vs analytic 0.932525905931 ✓) | ✓ |
| K₆=K₁−K₂−K₃, R₆=(R₁−R₂)/2 | 10, 2.5 GPa | ✓ | ✓ |
| Ω/Ω_c at band top | 8.7e-2 | 1e3/11467.5 = 8.72e-2 | ✓ |
| v_φ*=√K₃*, A-branch 1.7% below | 0.316 vs 0.31072662 | 1.74% below | ✓ |
| Δ_AC | 0.334 | (0.4663−0.3107)/0.4663 = 0.3337 | ✓ |
| "1.4×10⁷ × floor" | 1.4e7 | 0.334/2.42e-8 = 1.38e7 | ✓ |
| εΔ/V (relative floor) | 2.42e-8 | 1.13e-8/0.4663 = 2.42e-8 | ✓ |
| 4.4e-6 abs ↔ 9.5e-6 rel | ✓ | 4.4e-6/0.46626 = 9.44e-6 | ✓ |
| 95+26 = 121 | ✓ | — | ✓ |
| evidence curve 71/121 at Ω≥0.3162 | 71 | grid k=50..120 = 71 points exactly | ✓ |
| Table 4 (λ, δ* dimensional map) | 311/466 μm etc. | all rows recomputed ✓ | ✓ |
| 0.47 nm continuum caveat | λ_min | 0.466 nm | ✓ |

### 1.3 Figures — content vs captions (all 11 figures inspected at high zoom; Fig 8 audited at **marker/vector level**)
- **Fig 8 marker audit (via PDF vector extraction):** every panel has exactly 10 roots; model-A panels = 4 admissible + 4 excluded + 2 grazing (caption says 4 & 2 ✓); B/C panels = 5+5+0 (caption says 5, 0 ✓); **p ↔ −p pairing is exact** (matches caption "the roots pair exactly as p↔−p"; the depth polynomial evenness is consistent with the z→−z mirror symmetry of 6/mmm). ✓✓
- Fig 2: benchmark markers, dashed Rayleigh line, gate curves maxima (1.11e-9, 3.27e-9), evidence envelope ✓ all match text.
- Fig 3: A flat at 0.3107, B/C at 0.4663, |V_B−V_C| rising to 4.4e-6, P_w 0.99 vs ≤1.8e-5 ✓.
- Fig 4: Δ_BC vs floor (95/121 below), unity crossing at Ω≈50–56, Δ_AC = 0.334 ✓.
- Fig 5: shoulder shifts with D_w*; Δ_BC windows; χ-collapse visual ✓ (see wording issue §2.4).
- Fig 6: dips + floor logic ✓ (see wording issue §2.6); max Δ_T = 7.9e-5 at τ₀*=0.1 ✓.
- Fig 7: 8.1e-6 max, monotone above floor below Ω≈1.3 noise ✓.
- Fig 9: z-axes ticks **exactly** [0.464987, 0.466301] & [0.466264, 0.467355] as caption claims ✓; Ω_c dashed reference line present ✓.
- Fig 10: 5 rows × 121 cols, dark reference row at τ₀*=0.0043462 ✓ (see clipping issue §3.3).
- Fig 11: Ω*δ* ≈ 1.99 (A), 1.29 (B/C) flat ✓ matches text and Table 4.

### 1.4 "Spikes / dips" — kya ye errors hain? → **NAHI.** ✓
Har spike/dip ka source aur status:
| Where | What it looks like | Actual cause | Already explained in paper? |
|---|---|---|---|
| Fig 2(b) gate curves | deep dips to 1e-16 | double-precision cancellation between nearly equal speeds | ✅ caption: "deep dips … are double-precision cancellation, not solver failure" |
| Fig 3(b), 4(a,b), 5(b,c), 7(a,b) | noisy spikes at low Ω (1e-12–1e-8) | sub-floor numerical scatter (below εΔ) | ✅ "below floor: indistinguishable" / "unresolved scatter" |
| Fig 6(a,b) | sharp V-dips (τ₀*=1e-5, 1e-4, 1e-2) | local minima of |signed difference|; all but one dip fall at/below floor | ✅ caption + §6.5 text |
| Fig 8(a-c) | grazing squares in model A | physical: V*=0.5 > v_φ*=√K₃* at the reference scan | ✅ caption (but wording issue §2.5) |
| Fig 9(c) | spiky fringe + flat −16 sheet | floor-clip of unresolvable region | ✅ "unresolved, not measured zeros" |
| Fig 10 | thin vertical dark stripes at low Ω | sub-floor noise in log scale | ✅ (implicitly, via floor logic) |

**Bottom line:** spikes graphically OK hain aur paper mein already honestly labelled hain. **In explanatory sentences ko mat hataana** — agar hataaya to referee zaroor query karega.

### 1.5 LaTeX / bibliography
- Compiles clean: **35 pages, 0 errors, 0 undefined references** (verified with TeX Live).
- 47 `\bibitem` ↔ 47 `\cite` keys — perfect match; no dangling refs, no uncited entries. ✓
- All `\ref`/`\eqref` targets exist. ✓
- Reference spot-checks: Agiasofitou & Lazar IJSS 51, 923–929 (2014) ✓; DOIs resolve (zamm.70114, s00707-025-04361-2, ijheatmasstransfer.2024.126202, cryst13081205 ✓).
- Minor overfull hboxes (≤4 pt) in 4 places — harmless; **one 77 pt overfull** in "Data and code availability" (see §3.4).

---

## 2. Issues to FIX before submission — P0/P1

### 2.1 [P0 — submission-blocking] Figure numbers vs file names mismatch
Compiled PDF mein figure numbering source order se chalti hai, aur wo file names se alag hai. Internal `\ref` sab sahi hain (auto-numbered), **lekin journal ko alag figure files "Fig01…Fig11" ke naam se doge to typesetter galat figures place karega.**

| File (PDF & EPS) | Content | Printed "Figure N" |
|---|---|---|
| fig1 / Fig01 | schematic | **1** ✓ |
| fig2 / Fig02 | verification | **2** ✓ |
| **fig8 / Fig08** | depth-root structure | **3** ✗ |
| **fig3 / Fig03** | baseline surface response | **4** ✗ |
| **fig4 / Fig04** | model differences | **5** ✗ |
| **fig5 / Fig05** | controlled friction | **6** ✗ |
| **fig9 / Fig09** | 3-D Study-2 grid | **7** ✗ |
| **fig6 / Fig06** | thermal relaxation | **8** ✗ |
| **fig10 / Fig10** | thermal map | **9** ✗ |
| **fig7 / Fig07** | clamped phason BC | **10** ✗ |
| fig11 / Fig11 | localisation | **11** ✓ |

**Fix (koi bhi ek):**
- (a) `main.tex` mein figure environments ko file order mein reorder karo (fig8 block ko fig7 ke baad, fig9 ko fig8 ke baad, fig10 ko fig9 ke baad) — text `\ref` se auto-correct ho jayega; **ya**
- (b) files ko printed numbers ke hisaab se rename karo (`Fig03.eps` = depth-roots, etc.) aur `\includegraphics` update karo.
Recommendation: (a) — source order = file order = printed number, sab match.

### 2.2 [P0] Reproducibility package contradiction
- Manuscript ("Data and code availability" + Abstract): "…provided in the accompanying reproducibility package (**submitted as supplementary material**)" with a 12-folder inventory (`01_MANUSCRIPT` … `12_CORRECTIONS`, checksums).
- Lekin isi zip ke `supplementary/README.md` mein: **"NOT AVAILABLE. No supplementary material exists for this project."**
**Fix:** Ya to reproducibility package (02_SOLVER…12_CORRECTIONS + raw data + logs) submission ke saath attach karo, ya `supplementary/README.md` ko hata do / reword karo. Abstract ka "reproducible from the accompanying reproducibility package" bhi isi par depend karta hai — package ke bina ye claim referee ke liye target banega.

### 2.3 [P1] Section 5.5 — "≤1.7% of the quoted difference" lagbhag 1000× galat ho sakta hai
Text: *"…and by 8.4×10⁻⁸ and 1.7×10⁻⁸ at Ω*=1, 10² (low friction) … and ≤1.7% of the quoted difference at the low-friction points."*
- Low-friction points (D_w*=0.01) par quoted Δ_BC ≈ 5.0×10⁻³ (Fig 5b plateau, caption: "maximum ≈5.0×10⁻³ for D_w*≤1").
- 8.4×10⁻⁸ / 5.0×10⁻³ = **1.7×10⁻⁵ = 0.0017 %**, 1.7 % NAHI.
- Do possibilities: (i) "≤1.7%" → "≤2×10⁻⁵ (≤0.002 %) of the quoted difference"; ya (ii) agar 1.7% sahi hai to discrepancy values 10⁻⁵ scale ki honi chahiye thi, 10⁻⁸ ki nahi (par estimator errors (3–5)×10⁻⁸ hain, isliye 8.4×10⁻⁹-plausible value hi sahi lagti hai → wording/percent conversion theek karo).
**Action:** `07_TESTS_VALIDATION/validation_logs/complex_k_dispersion.log` se actual numbers verify karke sentence correct karo.

### 2.4 [P1] Fig 5 caption (c) — "the four frictions' Δ_BC agree within a factor 1.004 over their common above-floor χ ranges"
Four plotted frictions ka χ = Ω*/D_w* swept range:
- D_w*=10⁻² → χ∈[10⁻¹, 10⁴]; D_w*=10⁰ → χ∈[10⁻³, 10²]; D_w*=10² → χ∈[10⁻⁵, 10⁰]; D_w*=10⁴ → χ∈[10⁻⁷, 10⁻²].
- Inka **4-way common range EMPTY hai** (10⁻² wala max 10⁴…10⁻¹ se upar; 10⁴ wala max 10⁻² tak hi). Collapse **pairwise-chained** verify hota hai (adjacent pairs overlap karte hain).
**Fix:** caption ko aisa karo: *"…agree within a factor 1.004 at matched χ over the pairwise-common (chained) above-floor χ ranges"* — ya "wherever any two swept frictions share χ". Claim visual sach hai (Fig 5c collapse convincing hai), sirf wording technically galat hai.

### 2.5 [P1] Fig 8 caption — "(V*<√K₃*) off the solved branch" confusing/ulta padha jata hai
Reference scan par k*=2Ω* → V*=0.5 **>** v_φ*=√K₃*≈0.316 — isliye hi grazing pair wahan banta hai; solved branch par V*=0.3107 **<** 0.316 isliye wahan n_ad=5. Parenthetical "(V*<√K₃*) off the solved branch" contradicting lagta hai.
**Fix suggestion:** *"…grazing (nearly real) roots, appearing in model A at this reference scan because its speed V*=0.5 exceeds the five-root threshold V*<√K₃* (Section 3.6) that the solved branch (V*≈0.3107) satisfies."* Same clarification §7.2 ke "(V*<v_φ* requirement for five roots)" ke saath consistent rakho.

### 2.6 [P1] Section 6.5 wording — self-contradictory sentence
*"Each Δ_T(Ω*) curve is monotone in its resolved part; its 11–19 local minima … lie at or below the resolution floor — exactly one dip in the entire sweep, at τ₀*=10⁻², Ω*≈44.7, rises above the floor —"*
Ek hi sentence mein "monotone in resolved part" + "one dip above the floor" dono nahi ho sakte.
**Fix:** *"All local minima except one lie at or below the resolution floor; the single resolvable dip (τ₀*=10⁻², Ω*≈44.7) coincides with a sign change of the signed difference."* (Caption ka "every dip but one…" version already theek hai — text ko usse align karo.)

---

## 3. Presentation issues — P2 (figures/typography)

### 3.1 Y-label collisions in multi-panel figures (inter-panel gaps chhote hain)
| Figure | Problem |
|---|---|
| **Fig 2(a)** | x-tick labels **"A (cpl.)" aur "B/C (cpl.)" aapas mein takrate hain** (compiled PDF mein bhi "A (cpl.)B/C (cpl.)" ban jaata hai); panel (b) ka y-label "\|ΔV*/V*\|" panel (a) ke annotation "0.934208 (excl. record)" ke upar overlap karta hai |
| **Fig 3** | panel (c) ka lamba label "phason participation P_w" panel (b) ke **data curve** (rising \|V_B−V_C\|) ke upar overlap karta hai |
| **Fig 4** | "Δ_BC/floor" (b) aur "Δ_AC" (c) labels gap mein squeeze ho kar ek dusre ko/panel edge ko chhoo rahe hain |
| **Fig 5** | "Δ_BC" labels (a|b) aur (b|c) gaps mein panel edges par chipak rahe hain |
| **Fig 7** | (b) ka long label "\|δ*_cl−δ*_fr\|/δ*_fr" panel (a) ke right ticks ke paas overlap |

**Fix:** `subplots_adjust(wspace≈0.4)` ya `constrained_layout`, labels ko chhota/2-line karo (e.g. `P_w`, `Δ_BC/floor` → `Δ_BC/ε`), ya `supylabel` use karo.

### 3.2 Fig 8(a) — hidden root + legend glitch
Panel (a) mein thermal root ka excluded mirror (−4.4, −4.4) **exactly legend box ke neeche plot hota hai**: legend ka "grazing" symbol accidentally "⊠" (square + X) dikhata hai jabki data ke grazing markers plain "□" hain; aur panel (a) aisa lagta hai jaise far root ka p↔−p mirror MISSING hai (referee pairing check karega to confuse hoga). Maine vector extraction se confirm kiya ki marker maujood hai — sirf legend ne daba rakha hai.
**Fix:** legend ko upper-left/upper-center ya bahar move karo, ya xlim/ylim expand karo.

### 3.3 Fig 10 — colorbar top clip
Colorbar ≈ −16…−5 tak hai, lekin max log₁₀Δ_T = log₁₀(7.9×10⁻⁵) = **−4.10** — top-right region saturate ho raha hai (τ₀*=10⁻¹ aur 10⁻² ki high-Ω values sab ek hi yellow). Fix: vmax=−4 karo, ya caption mein "values above 10⁻⁵ saturate at the colour scale" likh do.

### 3.4 Overfull hbox 77 pt — "Data and code availability"
`\texttt{01\_MANUSCRIPT}` wala lamba inventory line margin se bahar nikalta hai. Fix: underscores ke baad `\allowbreak`, ya `\seqsplit`/`\path`, ya inventory ko itemize mein todo.

### 3.5 Fig 7 — in-figure italic note duplicates caption
Figure ke andar italic line ("Model A: clamping the phason removes the carrier…") caption ki last sentence ka repeat hai. Ek hata do.

### 3.6 Fig 1 (schematic) — cosmetic
Wavy lines "quasicrystal half space z>0 (2D hex, Laue 10)" label ko cut karti hain; field box waves ko overlap karta hai. Text-box ko thoda neeche/dahine le jao.

---

## 4. P3 — Optional nits (nice-to-fix)
1. "three orders of magnitude above the floor" (max Δ_T): 7.9e-5/2.42e-8 = **3.3×10³ ≈ 3.5 orders** — "≈3.5 orders" zyada accurate.
2. r ki do alag ranges quoted: §3.5 "∼2×10⁻¹¹–3.3×10⁻⁵" vs §5.2 "9.7×10⁻⁹–3.2×10⁻⁵" — subsets clarify karo (ya unify).
3. Fig 7(b) "of comparable magnitude" — δ* change ~5×10⁻⁵ vs speed 8.1×10⁻⁶ (≈6× difference) — "same order of magnitude" likho.
4. Gulyaev ref: "Sov. Phys. JETP **9**, 37 (1969)" — volume 9 technically JETP Lett. ka hai (1969); literature bhi aapki tarah cite karta hai, par "JETP Lett. 9, 37 (1969)" cleaner.
5. §5.2 text: "per-point branch residuals 9.7×10⁻⁹–3.2×10⁻⁵" vs §3.5 sweep range — same note as (2).
6. Fig 2(a): open triangle (excluded record 0.934208) "B/C (cpl.)" ke same x par hai — thoda visually confusing; caption explain karti hai, but marker ko x-offset de sakte ho.

---

## 5. Pre-submission checklist
- [ ] Author names, affiliations, corresponding author (name, e-mail, ORCID) — placeholders currently `[AUTHOR INFORMATION TO BE INSERTED]`
- [ ] Funding, Conflict of interest, Author contributions statements
- [ ] `[PUBLIC ARCHIVE IDENTIFIER …]` — archive DOI (Zenodo/Figshare etc.) agar deposit kiya to
- [ ] **§2.1 figure-order fix** (file names ↔ printed numbers)
- [ ] **§2.2 reproducibility package** attach karo ya statement/README fix karo
- [ ] **§2.3 "≤1.7%"** number verify & fix
- [ ] §2.4–2.6 wording fixes
- [ ] Figure label collisions (§3.1) + Fig 8 legend (§3.2) + Fig 10 colorbar (§3.3)
- [ ] Final compile (clean log), figures ka final visual pass
- [ ] Journal format (publisher class file portal par lagana hai — structure already compliant as per header comment)

---

## 6. Files in this workspace (review artifacts)
- `quasi_work/` — extracted zip (main.tex, figures/, references.bib, compile.sh)
- `quasi_work/main.pdf` — compiled PDF (35 pages) — clean compile
- `fig_png/` — all figures rendered as PNG (plus zoom crops used for the audit)
- `REVIEW_REPORT.md` — this report

**Overall verdict:** Science solid hai, verification framework (classical limits + symbolic identities + model limits + complex-k checks + resolution floor) genuinely impressive hai aur internally consistent hai. Spikes/dips ke baare mein ghabrana mat — wo explained hain. Bas §2 ke fixes (figure numbering, reproducibility package, aur "1.7%" number) karke submit kar do — baaki sab minor hai.
