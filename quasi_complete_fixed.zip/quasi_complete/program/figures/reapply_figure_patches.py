#!/usr/bin/env python3
"""Regenerate the FINAL layout-fixed make_all_figures.py from make_all_figures_v1_original.py.

Layout-only patches (content/semantics unchanged): figure sizes, spacing,
font sizes, label wrapping, math-mode axis labels (fig8), colorbar limits
(fig10), fig7 in-figure note removal (duplicates caption), plus follow-up
nits (fig3 ylabel linespacing, fig5 legend frame, fig9 label pads).
"""
src = open('make_all_figures_v1_original.py').read()
log = []

def rep(old, new, n=1, tag=''):
    global src
    cnt = src.count(old)
    assert cnt == n, f"[{tag}] count {cnt} != {n} for: {old[:90]!r}"
    src = src.replace(old, new)
    log.append(tag or old[:40])

# ============================ FIG 1 ============================
rep('ax.text(0.15, -0.35, "quasicrystal half-space $z>0$ (2D hex., Laue 10)",\n            fontsize=8, color="#333333")',
    'ax.text(0.15, -0.32, "quasicrystal half-space $z>0$ (2D hex., Laue 10)",\n            fontsize=8, color="#333333",\n            bbox=dict(fc="white", ec="none", alpha=0.88, pad=1.2), zorder=6)',
    tag='fig1 bbox half-space text')
rep('ax.add_patch(plt.Rectangle((5.55, -4.85), 4.3, 2.05, fc="white",\n                 ec="#666666", lw=0.7, zorder=5))',
    'ax.add_patch(plt.Rectangle((5.35, -4.92), 4.55, 2.22, fc="white",\n                 ec="#666666", lw=0.7, zorder=5))',
    tag='fig1 box bigger')
rep('ax.text(5.7, -3.05,', 'ax.text(5.5, -3.02,', tag='fig1 line1 pos')
rep('ax.text(5.7, -3.55,', 'ax.text(5.5, -3.52,', tag='fig1 line2 pos')
rep('ax.text(5.7, -4.05,', 'ax.text(5.5, -4.02,', tag='fig1 line3 pos')
rep('ax.text(5.7, -4.55,', 'ax.text(5.5, -4.52,', tag='fig1 line4 pos')
rep('fontsize=8.2, zorder=6)', 'fontsize=7.0, zorder=6)', n=3, tag='fig1 box fonts a')
rep('fontsize=8.2,\n            color="#666666", zorder=6)',
    'fontsize=7.0,\n            color="#666666", zorder=6)', tag='fig1 box font b')

# ============================ FIG 2 ============================
rep('fig, axes = plt.subplots(1, 2, figsize=(7.6, 3.05),\n                             gridspec_kw={"width_ratios": [1.0, 1.15]})',
    'fig, axes = plt.subplots(1, 2, figsize=(10.4, 3.9),\n                             gridspec_kw={"width_ratios": [1.0, 1.15],\n                                          "wspace": 0.34})', tag='fig2 size')
rep('"A (cpl.)", "B/C (cpl.)"]', '"A\\n(cpl.)", "B/C\\n(cpl.)"]', tag='fig2 ticks')
rep('ax.text(2, vals[2] - 0.045, "%.9f" % vals[2], fontsize=6.4, ha="center")',
    'ax.text(2, vals[2] - 0.045, "%.9f" % vals[2], fontsize=8.2, ha="center")', tag='fig2 f1')
rep('ax.text(0, vals[0] + 0.035, "1 (exact)", fontsize=6.4, ha="center")',
    'ax.text(0, vals[0] + 0.035, "1 (exact)", fontsize=8.2, ha="center")', tag='fig2 f2')
rep('ax.text(1, vals[1] + 0.04, "0.5 (exact)", fontsize=6.4, ha="center")',
    'ax.text(1, vals[1] + 0.04, "0.5 (exact)", fontsize=8.2, ha="center")', tag='fig2 f3')
rep('ax.text(4, vals[4] - 0.065, "%.8f" % vals[4], fontsize=6.4, ha="center")',
    'ax.text(4, vals[4] - 0.065, "%.8f" % vals[4], fontsize=8.2, ha="center")', tag='fig2 f4')
rep('ax.text(5, vals[5] + 0.03, "%.7f" % vals[5], fontsize=6.4, ha="center")',
    'ax.text(5, vals[5] + 0.03, "%.7f" % vals[5], fontsize=8.2, ha="center")', tag='fig2 f5')
rep('ax.text(5.55, 0.79, "0.934208 (excl. record)", fontsize=6.2, ha="center")',
    'ax.text(5.62, 0.78, "0.934208 (excl. record)", fontsize=8.0, ha="right")',
    tag='fig2 excl record')
rep('ax.set_xticks(range(6)); ax.set_xticklabels(cats, fontsize=7)',
    'ax.set_xticks(range(6)); ax.set_xticklabels(cats, fontsize=8.4)', tag='fig2 xticks')
rep('ax.legend(fontsize=6.4, loc="lower left")', 'ax.legend(fontsize=8.2, loc="lower left")',
    tag='fig2 leg a')
rep('ax.text(2.5e-3, 4e-15, "roundoff-dominated", fontsize=6.4, color="#555555")',
    'ax.text(2.5e-3, 4e-15, "roundoff-dominated", fontsize=8.2, color="#555555")', tag='fig2 f6')
rep('ax.legend(fontsize=6.2, loc="upper right")', 'ax.legend(fontsize=8.0, loc="upper right")',
    tag='fig2 leg b')

# ============================ FIG 3 ============================
rep('fig, axes = plt.subplots(1, 3, figsize=(7.8, 2.75))\n    ax = axes[0]\n    for mod, c, s in (("A", CA, SM), ("B", CB, SB), ("C", CC, SC)):\n        rr = [r for r in rows if r["model"] == mod]\n        ax.loglog(farr(rr, "Omega"), farr(rr, "V"), color=c, ls=s,',
    'fig, axes = plt.subplots(1, 3, figsize=(11.2, 3.6),\n                             gridspec_kw={"wspace": 0.44})\n    ax = axes[0]\n    for mod, c, s in (("A", CA, SM), ("B", CB, SB), ("C", CC, SC)):\n        rr = [r for r in rows if r["model"] == mod]\n        ax.loglog(farr(rr, "Omega"), farr(rr, "V"), color=c, ls=s,',
    tag='fig3 size')
rep('ax.text(1.3e-3, 0.505, r"$v_S^*/v_0=0.5$", fontsize=7)',
    'ax.text(1.3e-3, 0.505, r"$v_S^*/v_0=0.5$", fontsize=8.6)', tag='fig3 f1')
rep('ax.set_ylim(0.2, 0.6); ax.legend(fontsize=7, loc="lower left")',
    'ax.set_ylim(0.2, 0.6); ax.legend(fontsize=8.4, loc="lower left")', tag='fig3 leg a')
rep('ax.text(2e-3, 3e-5, "max $4.4\\\\times10^{-6}$ abs.\\n($9.5\\\\times10^{-6}$ rel.)",\n            fontsize=6.4)',
    'ax.text(2e-3, 3e-5, "max $4.4\\\\times10^{-6}$ abs.\\n($9.5\\\\times10^{-6}$ rel.)",\n            fontsize=8.2)', tag='fig3 annot')
rep('ax.legend(fontsize=6.6, loc="lower right")', 'ax.legend(fontsize=8.2, loc="lower right")',
    tag='fig3 leg b')
rep('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"phason participation $P_w$")\n    ax.legend(fontsize=7, loc="lower right")',
    'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel("phason participation\\n$P_w$", fontsize=9)\n    ax.yaxis.label.set_linespacing(1.45)\n    ax.legend(fontsize=8.4, loc="lower right")', tag='fig3 ylabel c')

# ============================ FIG 4 ============================
rep('fig, axes = plt.subplots(1, 3, figsize=(7.8, 2.75))\n    ax = axes[0]\n    ax.loglog(Om, np.maximum(farr(rows, "Delta_BC"), 1e-16), color=CB, lw=1.1)',
    'fig, axes = plt.subplots(1, 3, figsize=(11.2, 3.6),\n                             gridspec_kw={"wspace": 0.46})\n    ax = axes[0]\n    ax.loglog(Om, np.maximum(farr(rows, "Delta_BC"), 1e-16), color=CB, lw=1.1)',
    tag='fig4 size')
rep('ax.text(6e0, 4e-10, "below floor:\\nindistinguishable", fontsize=6.4,\n            color="#555555")',
    'ax.text(6e0, 4e-10, "below floor:\\nindistinguishable", fontsize=8.2,\n            color="#555555")', tag='fig4 f1')
rep('ax.set_ylim(1e-10, 1e-4); ax.legend(fontsize=6.8, loc="upper left")',
    'ax.set_ylim(1e-10, 1e-4); ax.legend(fontsize=8.4, loc="upper left")', tag='fig4 leg a')
rep('ax.set_ylim(1e-3, 1e3); ax.legend(fontsize=6.8, loc="upper left")',
    'ax.set_ylim(1e-3, 1e3); ax.legend(fontsize=8.4, loc="upper left")', tag='fig4 leg b')
rep('ax.text(2e-3, 0.1, "strongly separated\\n($\\\\sim1.4\\\\times10^{7}\\\\times$floor)",\n            fontsize=6.4, color="#555555")',
    'ax.text(2e-3, 0.1, "strongly separated\\n($\\\\sim1.4\\\\times10^{7}\\\\times$floor)",\n            fontsize=8.2, color="#555555")', tag='fig4 annot')
rep('ax.legend(fontsize=6.8, loc="lower left")', 'ax.legend(fontsize=8.4, loc="lower left")',
    tag='fig4 leg c')

# ============================ FIG 5 ============================
rep('fig, axes = plt.subplots(1, 3, figsize=(7.9, 2.8))',
    'fig, axes = plt.subplots(1, 3, figsize=(12.6, 3.8),\n                             gridspec_kw={"wspace": 0.52})\n    plt.subplots_adjust(left=0.075)', tag='fig5 size')
rep('fontsize=6.4, loc="lower left", title="B dashed / C dash-dot",\n              title_fontsize=6.0)',
    'fontsize=8.2, loc="lower left", frameon=True, framealpha=1.0,\n              edgecolor="none", title="B dashed / C dash-dot", title_fontsize=7.8)',
    tag='fig5 leg a')
rep('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$\\Delta_{BC}$")\n    ax.legend(fontsize=6.4, loc="lower right")\n    panel(ax, "b")',
    'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$\\Delta_{BC}$", fontsize=9)\n    ax.legend(fontsize=8.2, loc="lower right", framealpha=1.0, edgecolor="none")\n    panel(ax, "b")', tag='fig5 leg b')
rep('ax.set_ylabel(r"$\\Delta_{BC}$")\n    ax.legend(fontsize=6.4, loc="lower right")\n    panel(ax, "c")',
    'ax.set_ylabel(r"$\\Delta_{BC}$", fontsize=9)\n    ax.legend(fontsize=8.2, loc="lower right", framealpha=1.0, edgecolor="none")\n    panel(ax, "c")', tag='fig5 leg c')

# ============================ FIG 6 ============================
rep('fig, axes = plt.subplots(1, 2, figsize=(7.6, 2.85))\n    for axi, (xname, use_chi) in enumerate((("Omega", False), ("chi", True))):',
    'fig, axes = plt.subplots(1, 2, figsize=(10.6, 3.8),\n                             gridspec_kw={"wspace": 0.32})\n    for axi, (xname, use_chi) in enumerate((("Omega", False), ("chi", True))):', tag='fig6 size')
rep('ax.legend(fontsize=5.9, loc="upper left", ncol=1)',
    'ax.legend(fontsize=8.0, loc="upper left", ncol=1, framealpha=1.0,\n                  edgecolor="none")', tag='fig6 leg')

# ============================ FIG 7 ============================
rep('fig, axes = plt.subplots(1, 2, figsize=(7.6, 2.85))\n    ax = axes[0]\n    ax.loglog(Om, np.maximum(farr(rows, "dV_over_V_C"), 1e-16)',
    'fig, axes = plt.subplots(1, 2, figsize=(10.6, 3.8),\n                             gridspec_kw={"wspace": 0.40})\n    ax = axes[0]\n    ax.loglog(Om, np.maximum(farr(rows, "dV_over_V_C"), 1e-16)', tag='fig7 size')
rep('ax.set_ylim(1e-12, 1e-4); ax.legend(fontsize=6.8, loc="lower right")',
    'ax.set_ylim(1e-12, 1e-4); ax.legend(fontsize=8.4, loc="lower right")', tag='fig7 leg a')
rep('ax.set_xlabel(r"$\\Omega^*$")\n    ax.set_ylabel(r"$|\\delta^*_{cl}-\\delta^*_{fr}|/\\delta^*_{fr}$")\n    ax.legend(fontsize=6.8, loc="lower right")\n    panel(ax, "b")\n    fig.text(0.5, -0.06,\n             "Model A: clamping the phason removes the carrier of its "\n             "surface mode -- no finite-speed clamped branch exists "\n             "(degenerate minima not plotted).",\n             fontsize=7.2, ha="center", style="italic", color="#333333")',
    'ax.set_xlabel(r"$\\Omega^*$", fontsize=9)\n    ax.set_ylabel(r"$|\\delta^*_{cl}-\\delta^*_{fr}|/\\delta^*_{fr}$", fontsize=9)\n    ax.legend(fontsize=8.4, loc="lower right")\n    panel(ax, "b")', tag='fig7 note+label')

# ============================ FIG 8 ============================
rep('fig, axes = plt.subplots(3, 3, figsize=(8.6, 7.8), squeeze=False)',
    'fig, axes = plt.subplots(3, 3, figsize=(9.6, 8.6), squeeze=False)', tag='fig8 size')
rep('ax.set_title(f"{mod},  $\\\\Omega^*={Omv:g}$", fontsize=8.2)\n            ax.tick_params(labelsize=7)',
    'ax.set_title(f"{mod},  $\\\\Omega^*={Omv:g}$", fontsize=9.2)\n            ax.tick_params(labelsize=7.6)', tag='fig8 title/ticks')
rep('if im == 2: ax.set_xlabel(r"Re\\,$p$", fontsize=8.5)\n            if io == 0: ax.set_ylabel(r"Im\\,$p$", fontsize=8.5)\n            ax.margins(0.12)',
    'if im == 2: ax.set_xlabel(r"$\\mathrm{Re}\\,p$", fontsize=9.5)\n            if io == 0: ax.set_ylabel(r"$\\mathrm{Im}\\,p$", fontsize=9.5)\n            ax.margins(0.16)', tag='fig8 mathtext labels')
rep('["admissible", "excluded", "grazing"],\n                      fontsize=7, loc="lower left")',
    '["admissible", "excluded", "grazing"],\n                      fontsize=8.2, loc="lower left", framealpha=1.0)', tag='fig8 legend')
rep('fig.subplots_adjust(hspace=0.32, wspace=0.14)',
    'fig.subplots_adjust(hspace=0.42, wspace=0.22)', tag='fig8 spacing')

# ============================ FIG 9 ============================
rep('ax.set_zlabel(zlab, fontsize=7.5, labelpad=0.5)\n    ax.tick_params(labelsize=6.2)',
    'ax.set_zlabel(zlab, fontsize=8.2, labelpad=5)\n    ax.tick_params(labelsize=7.2)', tag='fig9 zlabel')
rep('ax.set_xlabel(r"$\\log_{10}\\Omega^*$", fontsize=7.5, labelpad=1)',
    'ax.set_xlabel(r"$\\log_{10}\\Omega^*$", fontsize=7.5, labelpad=4)', tag='fig9 xlabel pad')
rep('ax.set_ylabel(r"$\\log_{10}D_w^*$", fontsize=7.5, labelpad=1)',
    'ax.set_ylabel(r"$\\log_{10}D_w^*$", fontsize=7.5, labelpad=11)', tag='fig9 ylabel pad')
rep('fig = plt.figure(figsize=(7.9, 3.55))', 'fig = plt.figure(figsize=(12.4, 4.4))', tag='fig9 size')
rep('fig.subplots_adjust(left=0.0, right=1.0, wspace=0.08)',
    'fig.subplots_adjust(left=0.01, right=0.99, wspace=0.30)', tag='fig9 spacing')

# ============================ FIG 10 ============================
rep('fig, ax = plt.subplots(figsize=(6.6, 3.1))', 'fig, ax = plt.subplots(figsize=(8.8, 3.9))',
    tag='fig10 size')
rep('pm = ax.pcolormesh(Xg, Yg, Z, shading="auto", cmap="viridis")',
    'pm = ax.pcolormesh(Xg, Yg, Z, shading="auto", cmap="viridis",\n                       vmin=-16.5, vmax=-4.0)', tag='fig10 vlims')
rep('fig.colorbar(pm, ax=ax, label=r"$\\log_{10}\\Delta_T$", pad=0.01)',
    'cb = fig.colorbar(pm, ax=ax, pad=0.01)\n    cb.set_label(r"$\\log_{10}\\Delta_T$", fontsize=9.5)\n    cb.ax.tick_params(labelsize=8)', tag='fig10 cbar')
rep('ax.set_yticklabels([f"{t:g}" for t in d["taus"]], fontsize=7.2)',
    'ax.set_yticklabels([f"{t:g}" for t in d["taus"]], fontsize=8.4)', tag='fig10 yticks')

# ============================ FIG 11 ============================
rep('fig, axes = plt.subplots(1, 2, figsize=(7.6, 2.85))\n    ax = axes[0]\n    for mod, c, s in (("A", CA, SM), ("B", CB, SB), ("C", CC, SC)):\n        rr = [r for r in rows if r["model"] == mod]\n        ax.loglog(farr(rr, "Omega"), farr(rr, "delta_pen"), color=c, ls=s,',
    'fig, axes = plt.subplots(1, 2, figsize=(10.6, 3.8),\n                             gridspec_kw={"wspace": 0.32})\n    ax = axes[0]\n    for mod, c, s in (("A", CA, SM), ("B", CB, SB), ("C", CC, SC)):\n        rr = [r for r in rows if r["model"] == mod]\n        ax.loglog(farr(rr, "Omega"), farr(rr, "delta_pen"), color=c, ls=s,', tag='fig11 size')
rep('ax.legend(fontsize=7, loc="upper right")', 'ax.legend(fontsize=8.4, loc="upper right")',
    tag='fig11 leg a')
rep('ax.text(2e-3, 3.4, "$\\\\Omega^*\\\\delta^*\\\\approx$ const $\\\\Rightarrow$ "\n            "$\\\\delta^*\\\\propto1/\\\\Omega^*$", fontsize=6.8)',
    'ax.text(2e-3, 3.4, "$\\\\Omega^*\\\\delta^*\\\\approx$ const $\\\\Rightarrow$ "\n            "$\\\\delta^*\\\\propto1/\\\\Omega^*$", fontsize=8.4)', tag='fig11 annot')
rep('ax.legend(fontsize=7, loc="lower right")', 'ax.legend(fontsize=8.4, loc="lower right")',
    tag='fig11 leg b')

# ============================ shared label bumps ============================
for a, b, t in [
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$V^*=\\Omega^*/k^*$")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$V^*=\\Omega^*/k^*$", fontsize=9)', 'lab 3a'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$|V_B-V_C|$")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$|V_B-V_C|$", fontsize=9)', 'lab 3b'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$\\Delta_{BC}$")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$\\Delta_{BC}$", fontsize=9)', 'lab 4a'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$\\Delta_{BC}\\,/\\,$floor")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$\\Delta_{BC}\\,/\\,$floor", fontsize=9)', 'lab 4b'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$\\Delta_{AC}$")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$\\Delta_{AC}$", fontsize=9)', 'lab 4c'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$V^*$")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$V^*$", fontsize=9)', 'lab 5a'),
    ('ax.set_ylabel(r"$\\Delta_T$")',
     'ax.set_ylabel(r"$\\Delta_T$", fontsize=9)', 'lab 6'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$|\\Delta V|/V$ (clamped vs free)")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$|\\Delta V|/V$ (clamped vs free)", fontsize=9)', 'lab 7a'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$\\delta^*=1/|\\mathrm{Im}\\,p|$")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$\\delta^*=1/|\\mathrm{Im}\\,p|$", fontsize=9)', 'lab 11a'),
    ('ax.set_xlabel(r"$\\Omega^*$"); ax.set_ylabel(r"$\\Omega^*\\delta^*$")',
     'ax.set_xlabel(r"$\\Omega^*$", fontsize=9); ax.set_ylabel(r"$\\Omega^*\\delta^*$", fontsize=9)', 'lab 11b'),
    ('ax.set_xlabel(r"$\\chi=\\Omega^*/\\Omega_c=\\Omega^*\\rho_w^*/D_w^*$")',
     'ax.set_xlabel(r"$\\chi=\\Omega^*/\\Omega_c=\\Omega^*\\rho_w^*/D_w^*$", fontsize=9)', 'lab 5c'),
    ('ax.set_xlabel(r"$\\Omega^*$" if not use_chi else r"$\\tau_0^*\\Omega^*$")',
     'ax.set_xlabel(r"$\\Omega^*$" if not use_chi else r"$\\tau_0^*\\Omega^*$", fontsize=9)', 'lab 6x'),
]:
    rep(a, b, tag=t)


# ======== Submission revision (2026-09-29): Fig 1 labels/box, Fig 2 marker and legend ========
rep('    ax.text(10.05, 0, "$z=0$", fontsize=9, va="center")\n    ax.text(0.15, -0.32, "quasicrystal half-space $z>0$ (2D hex., Laue 10)",\n            fontsize=8, color="#333333",\n',
    '    ax.text(10.05, 0, "$z=0$", fontsize=9, va="center")\n    ax.text(0.15, -0.32, "2D hexagonal quasicrystal half-space $z>0$",\n            fontsize=8, color="#333333",\n', tag='rev2026 fig1/2 hunk 1')
rep('    ax.text(0.12, -2.6, "depth $z$", fontsize=9, rotation=90, va="center")\n    ax.annotate("", xy=(2.0, -5.05), xytext=(0.8, -5.05),\n                arrowprops=dict(arrowstyle="-|>", lw=1.1, color="k"))\n    ax.text(2.1, -5.12, "$y$ (periodic direction, out of plane)", fontsize=8,\n            va="top")\n    # boundary conditions at surface\n',
    '    ax.text(0.12, -2.6, "depth $z$", fontsize=9, rotation=90, va="center")\n    # y axis is normal to the page: drawn as the standard "out of page" symbol\n    ax.plot([0.5], [-5.05], "o", ms=7, mfc="white", mec="k", mew=1.0, zorder=6)\n    ax.plot([0.5], [-5.05], "o", ms=1.8, color="k", zorder=7)\n    ax.text(0.75, -5.05, "$y$ (periodic direction, normal to the page)",\n            fontsize=8, va="center")\n    # boundary conditions at surface\n', tag='rev2026 fig1/2 hunk 2')
rep('    # fields box\n    ax.add_patch(plt.Rectangle((5.35, -4.92), 4.55, 2.22, fc="white",\n                 ec="#666666", lw=0.7, zorder=5))\n',
    '    # fields box\n    ax.add_patch(plt.Rectangle((5.0, -4.92), 5.05, 2.22, fc="white",\n                 ec="#666666", lw=0.7, zorder=5))\n', tag='rev2026 fig1/2 hunk 3')
rep('                 ec="#666666", lw=0.7, zorder=5))\n    ax.text(5.5, -3.02, r"active fields:  $\\mathbf{u}=(u_x,u_z)$ phonon,  "\n            r"$\\mathbf{w}=(w_x,w_z)$ phason,  $\\theta$", fontsize=7.0, zorder=6)\n',
    '                 ec="#666666", lw=0.7, zorder=5))\n    ax.text(5.12, -3.02, r"active fields:  $\\mathbf{u}=(u_x,u_z)$ phonon,  "\n            r"$\\mathbf{w}=(w_x,w_z)$ phason,  $\\theta$", fontsize=7.0, zorder=6)\n', tag='rev2026 fig1/2 hunk 4')
rep('            r"$\\mathbf{w}=(w_x,w_z)$ phason,  $\\theta$", fontsize=7.0, zorder=6)\n    ax.text(5.5, -3.52, r"$\\varphi$: decoupled, passive output "\n            r"($\\partial/\\partial y=0$, $u_y=0$)", fontsize=7.0,\n',
    '            r"$\\mathbf{w}=(w_x,w_z)$ phason,  $\\theta$", fontsize=7.0, zorder=6)\n    ax.text(5.12, -3.52, r"$\\varphi$: decoupled, passive output "\n            r"($\\partial/\\partial y=0$, $u_y=0$)", fontsize=7.0,\n', tag='rev2026 fig1/2 hunk 5')
rep('            color="#666666", zorder=6)\n    ax.text(5.5, -4.02, r"thermal: Lord--Shulman $\\tau_0$;  piezoelectric: "\n            r"passive in this cut", fontsize=7.0, zorder=6)\n    ax.text(5.5, -4.52, r"phason operator $\\Lambda$:  "\n            r"A $-\\rho_w\\omega^2$ | B $-\\mathrm{i}\\omega D_w$ | "\n',
    '            color="#666666", zorder=6)\n    ax.text(5.12, -4.02, r"thermal: Lord--Shulman ($\\tau_0$);  piezoelectric "\n            r"coupling inactive", fontsize=7.0, zorder=6)\n    ax.text(5.12, -4.52, r"phason operator $\\Lambda$:  "\n            r"A $-\\rho_w\\omega^2$ | B $-\\mathrm{i}\\omega D_w$ | "\n', tag='rev2026 fig1/2 hunk 6')
rep('    ax.text(5, vals[5] + 0.03, "%.7f" % vals[5], fontsize=8.2, ha="center")\n    ax.plot([5.55], [0.90], "^", mfc="none", mec=CA, ms=5.5, zorder=4)\n    # legacy stage-6 coarse-scan record: documented constant from the package\n    # 08_AUDITS/FINAL_FIGURE_AUDIT.md (F5; not present in results/*.csv); shown but EXCLUDED\n    # from all conclusions.\n    ax.text(5.62, 0.78, "0.934208 (excl. record)", fontsize=8.0, ha="right")\n    ax.set_xticks(range(6)); ax.set_xticklabels(cats, fontsize=8.4)\n',
    '    ax.text(5, vals[5] + 0.03, "%.7f" % vals[5], fontsize=8.2, ha="center")\n    ax.set_xticks(range(6)); ax.set_xticklabels(cats, fontsize=8.4)\n', tag='rev2026 fig1/2 hunk 7')
rep('    Om = farr(rows, "Omega")\n    pairs = [("V_C_Dw14", "V_A", r"C($D_w^*\\!\\!\\to\\!10^{-14}$)$\\to$A [gate]", CA),\n             ("V_C_rhow0", "V_B", r"C($\\rho_w^*\\!\\!\\to\\!10^{-8}$)$\\to$B [gate]", CB),\n             ("V_C_Dw0", "V_A", r"C($D_w^*\\!=\\!10^{-8}$)$\\to$A [evidence]", CC)]\n    for a, b, lab, c in pairs:\n        d = np.abs(farr(rows, a) / farr(rows, b) - 1.0)\n',
    '    Om = farr(rows, "Omega")\n    pairs = [("V_C_Dw14", "V_A", r"C($D_w^*\\!\\!\\to\\!10^{-14}$)$\\to$A", CA, False),\n             ("V_C_rhow0", "V_B", r"C($\\rho_w^*\\!\\!\\to\\!10^{-8}$)$\\to$B", CB, False),\n             ("V_C_Dw0", "V_A", r"C($D_w^*\\!=\\!10^{-8}$) vs A", CC, True)]\n    for a, b, lab, c, dashed in pairs:\n        d = np.abs(farr(rows, a) / farr(rows, b) - 1.0)\n', tag='rev2026 fig1/2 hunk 8')
rep('        ax.loglog(Om, np.maximum(d, 1e-16), color=c, label=lab, lw=1.0,\n                  ls=SC if "evidence" in lab else "-")\n    ax.axhline(1e-6, color="k", ls=":", lw=0.9, label="target $10^{-6}$")\n',
    '        ax.loglog(Om, np.maximum(d, 1e-16), color=c, label=lab, lw=1.0,\n                  ls=SC if dashed else "-")\n    ax.axhline(1e-6, color="k", ls=":", lw=0.9, label="target $10^{-6}$")\n', tag='rev2026 fig1/2 hunk 9')


# ======== Submission revision (2026-09-29, round 2): Fig 1 redrawn ========
rep('def fig1():\n    fig, ax = plt.subplots(figsize=(8.4, 4.7))\n    ax.set_axis_off(); ax.set_xlim(0, 10); ax.set_ylim(-5.2, 2.45)\n    X = np.linspace(0, 10, 400)\n    # half-space\n    ax.fill_between(X, -5.0, 0, color="#0072B2", alpha=0.07, zorder=0)\n    for d in np.arange(-4.8, 0, 0.35):\n        ax.plot(X, np.full_like(X, d), color="#0072B2", lw=0.3, alpha=0.10)\n    ax.plot(X, np.zeros_like(X), "k", lw=1.4, zorder=3)\n    ax.text(10.05, 0, "$z=0$", fontsize=9, va="center")\n    ax.text(0.15, -0.32, "2D hexagonal quasicrystal half-space $z>0$",\n            fontsize=8, color="#333333",\n            bbox=dict(fc="white", ec="none", alpha=0.88, pad=1.2), zorder=6)\n    # surface wave + decay envelope\n    k_ = 2 * np.pi * 0.55\n    surf = 0.42 * np.sin(k_ * X)\n    ax.plot(X, surf, color="#003A70", lw=1.5, zorder=4)\n    for j, d in enumerate((0.9, 1.8, 2.7, 3.6, 4.5)):\n        amp = 0.42 * np.exp(-0.55 * d)\n        ax.plot(X, -d + amp * np.sin(k_ * X), color="#003A70",\n                lw=1.2 - 0.15 * j, alpha=0.75 - 0.12 * j, zorder=2)\n    # penetration bracket\n    xb = 8.6\n    ax.annotate("", xy=(xb, -0.55), xytext=(xb, -2.55),\n                arrowprops=dict(arrowstyle="<->", color="#B00000", lw=1.1))\n    ax.text(xb + 0.15, -1.55, "$\\\\delta^*=1/|\\\\mathrm{Im}\\\\,p|$",\n            color="#B00000", fontsize=8.5)\n    # axes\n    ax.annotate("", xy=(7.6, 1.9), xytext=(4.6, 1.9),\n                arrowprops=dict(arrowstyle="-|>", lw=1.3, color="k"))\n    ax.text(6.1, 2.15, "propagation $x$   $\\\\propto\\\\mathrm{e}^{\\\\mathrm{i}(kx-\\\\omega t)}$",\n            fontsize=8.5, ha="center")\n    ax.annotate("", xy=(0.5, -4.6), xytext=(0.5, -0.4),\n                arrowprops=dict(arrowstyle="-|>", lw=1.3, color="k"))\n    ax.text(0.12, -2.6, "depth $z$", fontsize=9, rotation=90, va="center")\n    # y axis is normal to the page: drawn as the standard "out of page" symbol\n    ax.plot([0.5], [-5.05], "o", ms=7, mfc="white", mec="k", mew=1.0, zorder=6)\n    ax.plot([0.5], [-5.05], "o", ms=1.8, color="k", zorder=7)\n    ax.text(0.75, -5.05, "$y$ (periodic direction, normal to the page)",\n            fontsize=8, va="center")\n    # boundary conditions at surface\n    ax.text(0.15, 0.55, r"free surface:  $\\sigma_{zz}=\\sigma_{xz}=0$,"\n            r"  $H_{xz}=H_{zz}=0$ (free phason),  $\\theta=0$ (isothermal)",\n            fontsize=8.2, color="#111111")\n    # fields box\n    ax.add_patch(plt.Rectangle((5.0, -4.92), 5.05, 2.22, fc="white",\n                 ec="#666666", lw=0.7, zorder=5))\n    ax.text(5.12, -3.02, r"active fields:  $\\mathbf{u}=(u_x,u_z)$ phonon,  "\n            r"$\\mathbf{w}=(w_x,w_z)$ phason,  $\\theta$", fontsize=7.0, zorder=6)\n    ax.text(5.12, -3.52, r"$\\varphi$: decoupled, passive output "\n            r"($\\partial/\\partial y=0$, $u_y=0$)", fontsize=7.0,\n            color="#666666", zorder=6)\n    ax.text(5.12, -4.02, r"thermal: Lord--Shulman ($\\tau_0$);  piezoelectric "\n            r"coupling inactive", fontsize=7.0, zorder=6)\n    ax.text(5.12, -4.52, r"phason operator $\\Lambda$:  "\n            r"A $-\\rho_w\\omega^2$ | B $-\\mathrm{i}\\omega D_w$ | "\n            r"C $-\\rho_w\\omega^2-\\mathrm{i}\\omega D_w$", fontsize=7.0, zorder=6)\n    save(fig, "fig1.pdf")\n\n',
    'def fig1():\n    """Problem geometry (schematic; no data)."""\n    from matplotlib.patches import FancyArrowPatch, Rectangle\n    fig, ax = plt.subplots(figsize=(7.6, 3.7))\n    ax.set_axis_off(); ax.set_aspect("equal")\n    ax.set_xlim(-0.3, 12.2); ax.set_ylim(-5.0, 2.05)\n    L, D = 9.0, 4.5                       # half-space window: 0<x<L, -D<y<0\n    kx, dl = 2 * np.pi / 3.0, 1.35        # schematic wavenumber, decay length\n    # wave field inside the half-space: exp(-z/delta) cos(kx)\n    xx = np.linspace(0, L, 600); zz = np.linspace(0, D, 300)\n    X, Z = np.meshgrid(xx, zz)\n    F = np.exp(-Z / dl) * np.cos(kx * X)\n    ax.imshow(F, extent=(0, L, -D, 0), origin="upper", cmap="RdBu_r",\n              vmin=-1.6, vmax=1.6, aspect="auto", zorder=0, alpha=0.9)\n    ax.add_patch(Rectangle((0, -D), L, D, fill=False, ec="#555555", lw=0.6,\n                           zorder=2))\n    # undeformed and deformed free surface\n    ax.plot([0, L], [0, 0], color="#333333", lw=0.8, ls=(0, (4, 3)), zorder=3)\n    ax.plot(xx, 0.22 * np.cos(kx * xx), color="k", lw=1.5, zorder=4)\n    # medium label\n    ax.text(0.25, -D + 0.3, "2D hexagonal quasicrystal ($z>0$)",\n            fontsize=8.5, va="bottom",\n            bbox=dict(fc="white", ec="none", alpha=0.85, pad=1.5), zorder=5)\n    # boundary conditions\n    ax.text(L / 2, 0.55, r"free surface $z=0$:  $\\sigma_{zz}=\\sigma_{xz}=0$,  "\n            r"$H_{xz}=H_{zz}=0$,  $\\theta=0$", fontsize=8.5, ha="center")\n    # propagation direction\n    ax.add_patch(FancyArrowPatch((L / 2 - 1.6, 1.4), (L / 2 + 1.6, 1.4),\n                 arrowstyle="-|>", mutation_scale=11, lw=1.2, color="k"))\n    ax.text(L / 2 + 1.8, 1.4, r"propagation, $\\mathrm{e}^{\\mathrm{i}(kx-\\omega t)}$",\n            fontsize=8.5, va="center")\n    # coordinate triad (x right, z down, y out of the page)\n    ox, oy = 0.05, 1.75\n    ax.add_patch(FancyArrowPatch((ox, oy), (ox + 0.95, oy), arrowstyle="-|>",\n                 mutation_scale=9, lw=1.0, color="k"))\n    ax.add_patch(FancyArrowPatch((ox, oy), (ox, oy - 0.85), arrowstyle="-|>",\n                 mutation_scale=9, lw=1.0, color="k"))\n    ax.plot([ox], [oy], "o", ms=6.5, mfc="white", mec="k", mew=0.9, zorder=6)\n    ax.plot([ox], [oy], "o", ms=1.6, color="k", zorder=7)\n    ax.text(ox + 1.05, oy, "$x$", fontsize=9, va="center")\n    ax.text(ox + 0.15, oy - 0.8, "$z$", fontsize=9, va="center")\n    ax.text(ox - 0.35, oy, "$y$", fontsize=9, va="center", ha="right")\n    # amplitude profile versus depth\n    x0, w = 10.0, 1.7\n    ax.plot([x0, x0], [0, -D], color="k", lw=0.9)\n    ax.plot([x0, x0 + w + 0.2], [0, 0], color="k", lw=0.9)\n    zp = np.linspace(0, D, 200)\n    ax.plot(x0 + w * np.exp(-zp / dl), -zp, color=CB, lw=1.6)\n    ax.plot([x0, x0 + w * np.exp(-1)], [-dl, -dl], color="#B00000", lw=0.9,\n            ls=(0, (3, 2)))\n    ax.annotate("", xy=(x0 - 0.25, -dl), xytext=(x0 - 0.25, 0),\n                arrowprops=dict(arrowstyle="<->", lw=0.9, color="#B00000"))\n    ax.text(x0 - 0.35, -dl / 2, r"$\\delta^*$", color="#B00000", fontsize=9.5,\n            ha="right", va="center")\n    ax.text(x0 + 0.85, 0.28, "amplitude", fontsize=8.0, ha="center")\n    ax.text(x0 + 0.5, -D + 0.2, r"$\\propto\\mathrm{e}^{-z/\\delta^*}$",\n            fontsize=8.5, color=CB)\n    save(fig, "fig1.pdf")\n\n', tag='rev2026 fig1 redraw')

open('make_all_figures.py', 'w').write(src)
print(f"OK: {len(log)} patches applied")
