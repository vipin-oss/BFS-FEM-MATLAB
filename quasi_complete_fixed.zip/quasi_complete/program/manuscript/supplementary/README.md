# supplementary/ — supplementary material

**No supplementary material is submitted with this manuscript.** All data
supporting the findings are contained in the paper; further details of the
numerical computations are available from the corresponding author on request.

The folder is retained so the layout is complete and any future supplementary
material has a designated location.

Historical note: the source package carried
`manuscript/supplementary/README.md` with the same statement.
