# tables/ — table dependencies

There are **no external table files** in this project.

Every table of the manuscript is typeset directly in `main.tex`
(`\begin{table}...\end{table}` blocks):

| Table (label) | Content | Data source (for regeneration) |
|---|---|---|
| `tab:params` | Dimensional parameter set with provenance | `program/params.json` (`dimensional_SI`, `provenance_labels`) |
| `tab:nondim` | Controlling nondimensional groups + swept ranges | `program/params.json` (`frozen_starred_targets`) + `program/grids.json` |
| `tab:dim` | Dimensional endpoints (f, λ, δ*) | computed from `params.json` scales + Fig. 11 products (documented in `../docs/KEY_RESULTS.md`) |
| `tab:cxk` | Complex-wavenumber dispersion check | `validation/validation_results/complex_k_dispersion.log` |
| (results tables inside sections) | verification gates, model limits | `validation/validation_results/*.log` |

To edit a table, edit `main.tex` directly; there is no table-generation script.
