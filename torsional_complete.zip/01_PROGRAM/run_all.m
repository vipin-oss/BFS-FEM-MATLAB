function run_all()
% Archive-local MATLAB runner.  MATLAB/Octave execution is not claimed
% by this package unless the caller has a compatible interpreter.
archive_root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(archive_root, '01_PROGRAM', 'src', 'matlab'));
script_dir = fullfile(archive_root, '01_PROGRAM', 'scripts', 'matlab');
old_dir = pwd;
cleanup = onCleanup(@() cd(old_dir));
cd(script_dir);
run('generate_all_manuscript_figures.m');
end
