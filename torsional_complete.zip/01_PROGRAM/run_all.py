#!/usr/bin/env python3
"""Run the archive's Python generation and synchronization workflow.

Usage: python 01_PROGRAM/run_all.py
The run is deterministic under the pinned dependency constraints and
writes only to 03_DATA/generated, 02_OVERLEAF/figures, and
08_FINAL_OUTPUTS/final_figures, plus the verification log.
"""
from __future__ import annotations
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "01_PROGRAM" / "src" / "python"
SCRIPTS = ROOT / "01_PROGRAM" / "scripts" / "python"
LOG = ROOT / "04_REPRODUCTION" / "verification" / "run_all_python.log"
commands = [
    ("master_figure_generator", SCRIPTS / "master_figure_generator.py"),
    ("sensitivity_surface_check", SCRIPTS / "sensitivity_surface_check.py"),
    ("make_journal_previews", SCRIPTS / "make_journal_previews.py"),
    ("sync_outputs", SCRIPTS / "sync_outputs.py"),
    ("regen_all", SCRIPTS / "regen_all.py"),
]
env = os.environ.copy()
env["PYTHONPATH"] = str(SRC) + os.pathsep + env.get("PYTHONPATH", "")
LOG.parent.mkdir(parents=True, exist_ok=True)
with LOG.open("w", encoding="utf-8") as log:
    for label, script in commands:
        log.write(f"\n=== {label}: python {script.relative_to(ROOT)} ===\n")
        log.flush()
        completed = subprocess.run(
            [sys.executable, str(script)], cwd=ROOT, env=env,
            stdout=log, stderr=subprocess.STDOUT, text=True)
        if completed.returncode:
            raise SystemExit(f"{label} failed with exit code {completed.returncode}")
print(f"PYTHON_WORKFLOW_PASS log={LOG.relative_to(ROOT)}")
