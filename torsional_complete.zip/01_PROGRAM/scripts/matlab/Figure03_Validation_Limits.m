function Figure03_Validation_Limits()
%% ========================================================================
% FIGURE 03: FINITE-MODEL BOUNDARY AND LIMITING-CASE CHECKS
% ========================================================================
% The welded planar SH equation is shown only as a separately defined
% reference.  It is not claimed to be the limit of the finite-spring,
% finite-shell baseline model.

close all; clc;
fprintf('=================================================================\n');
fprintf('  REPRODUCING FIGURE 03: FINITE-MODEL LIMITING CHECKS            \n');
fprintf('=================================================================\n\n');

p = torsional_waveguide_core.get_default_parameters();
xi_pts = linspace(0.05, 6.0, 300);

%% Panel (a): finite-shell sequence plus separate welded planar reference
beta_vals = [1.50, 3.00, 5.00];
finite_x = cell(size(beta_vals)); finite_o = cell(size(beta_vals));
for i = 1:length(beta_vals)
    pp = p; pp.beta = beta_vals(i); pp.c = pp.beta * pp.b;
    [finite_x{i}, finite_o{i}] = torsional_waveguide_core.track_physical_branch(xi_pts, pp);
end
p_g0 = p; p_g0.mus_star = 0; p_g0.tau0_star = 0;
[xg0, og0] = torsional_waveguide_core.track_physical_branch(xi_pts, p_g0);

planar_x = linspace(0.1, 6.0, 100);
planar_o = NaN(size(planar_x));
for i = 1:length(planar_x)
    xi = planar_x(i);
    om_grid = linspace(1e-4, 0.9999*xi, 1200);
    rv = arrayfun(@(om) planar_spp_det(xi, om, p), om_grid);
    idx = find(isfinite(rv(1:end-1)) & isfinite(rv(2:end)) & ...
               (sign(rv(1:end-1)) ~= sign(rv(2:end))), 1, 'first');
    if ~isempty(idx)
        try
            planar_o(i) = fzero(@(om) planar_spp_det(xi, om, p), ...
                                [om_grid(idx), om_grid(idx+1)]);
        catch
        end
    end
end

%% Panel (b): finite interface and surface references
p_rigid = p; p_rigid.ka_star = 1000; p_rigid.kb_star = 1000;
p_soft = p; p_soft.ka_star = 0.5; p_soft.kb_star = 0.5;
p_g07 = p; p_g07.mus_star = 0.7; p_g07.tau0_star = 0;
[xr, or] = torsional_waveguide_core.track_branch_continuation(xi_pts, p_rigid, 1);
[xs, os] = torsional_waveguide_core.track_branch_continuation(xi_pts, p_soft, 1);
[xc, oc] = torsional_waveguide_core.track_physical_branch(xi_pts, p, 1);
[xg, og] = torsional_waveguide_core.track_physical_branch(xi_pts, p_g07);

fig = figure('Name', 'Figure 03 - Finite Model Limits', 'Color', 'w', ...
             'Position', [100, 100, 950, 420]);
subplot(1,2,1); hold on;
plot(finite_x{1}, finite_o{1}, 'b-', 'LineWidth', 2.0, ...
     'DisplayName', 'Finite shell \beta=1.50 (baseline)');
plot(finite_x{2}, finite_o{2}, 'm--', 'LineWidth', 1.8, ...
     'DisplayName', 'Finite shell \beta=3.00');
plot(finite_x{3}, finite_o{3}, 'c-', 'LineWidth', 1.8, ...
     'DisplayName', 'Finite shell \beta=5.00');
plot(xg0, og0, 'g:', 'LineWidth', 1.8, ...
     'DisplayName', 'Vanishing surface elasticity (\mu_s^*=0)');
plot(planar_x, planar_o, 'k-.', 'LineWidth', 1.6, ...
     'DisplayName', 'Welded planar reference (separate model)');
xlabel('Dimensionless Wavenumber \xi = kb');
ylabel('Dimensionless Frequency \Omega');
title('(a) Finite-shell checks and separate planar reference', 'FontWeight', 'bold');
legend('Location', 'upper left'); grid on; box on;
xlim([0,6]); ylim([0,0.35]);

subplot(1,2,2); hold on;
plot(xr, or, 'm-', 'LineWidth', 2.0, ...
     'DisplayName', 'Stiff interfaces (k_a^*=k_b^*=1000)');
plot(xc, oc, 'b--', 'LineWidth', 1.8, ...
     'DisplayName', 'Finite springs (k_a^*=k_b^*=5)');
plot(xs, os, 'r-.', 'LineWidth', 1.8, ...
     'DisplayName', 'Compliant reference (k_a^*=k_b^*=0.5)');
plot(xg, og, 'c:', 'LineWidth', 2.0, ...
     'DisplayName', 'Strong surface elasticity (\mu_s^*=0.7)');
xlabel('Dimensionless Wavenumber \xi = kb');
ylabel('Dimensionless Frequency \Omega');
title('(b) Interface and surface-parameter reference cases', 'FontWeight', 'bold');
legend('Location', 'upper left'); grid on; box on;
xlim([0,6]); ylim([0,0.7]);

if exist('sgtitle', 'builtin') || exist('sgtitle', 'file')
    sgtitle('Finite-Model Boundary and Limiting-Case Checks', 'FontWeight', 'bold');
end

output_dir = fullfile(fileparts(fileparts(fileparts(mfilename('fullpath')))), '02_OVERLEAF', 'figures');
if ~exist(output_dir, 'dir'), mkdir(output_dir); end
saveas(fig, fullfile(output_dir, 'fig_validation_limits.png'));
fprintf('Saved figure as: %s\n', fullfile(output_dir, 'fig_validation_limits.png'));

end

function res = planar_spp_det(xi, Omega, p)
    [~, g2, g3, m3, isValid] = torsional_waveguide_core.compute_wavenumbers(xi, Omega, p);
    if ~isValid
        res = NaN;
    else
        % Deliberately a separate welded planar reference; finite springs and
        % the finite outer boundary are not present in this equation.
        res = m3*g3 + g2;
    end
end
