%% =========================================================================
% FIGURE 06: COMPARATIVE INFLUENCE OF CORE (ka*) VS SHELL (kb*) BONDING
% =========================================================================
% Manuscript Reference: Figure 6 (Section 4.3)
%
% Physical Problem:
%   Analyzes the sensitivity of torsional wave propagation to bonding quality
%   at the two distinct concentric interfaces:
%     - Panel (a): Sweep of inner core interface stiffness ka* in {0.5, 2, 5, 20, 100}
%       at fixed outer shell stiffness kb* = 5.
%     - Panel (b): Sweep of outer shell interface stiffness kb* in {0.5, 2, 5, 20, 100}
%       at fixed inner core stiffness ka* = 5.
%
% Output: Generates EXACT Figure 6 (fig_interface_stiffness_comparison.png)
% =========================================================================

close all; clc;

fprintf('=================================================================\n');
fprintf('  REPRODUCING FIGURE 06: CORE (ka*) VS SHELL (kb*) STIFFNESS      \n');
fprintf('=================================================================\n\n');

p_base = torsional_waveguide_core.get_default_parameters();
xi_pts = linspace(0.05, 6.0, 300);  % seed before the xi~0.1-0.2 crossing region

k_vals = [0.5, 2.0, 5.0, 20.0, 100.0];
colors = {[0 0.447 0.741], [0.85 0.325 0.098], [0.929 0.694 0.125], ...
          [0.494 0.184 0.556], [0.466 0.674 0.188]};

fig = figure('Name', 'Figure 06 - Interface Stiffness Comparison', 'Color', 'w', ...
             'Position', [100, 100, 950, 400]);

% --- Subplot (a): ka* sweep at fixed kb* = 5 ---
subplot(1, 2, 1);
hold on;
fprintf('Panel (a): Sweeping ka* with fixed kb* = 5.0...\n');
for i = 1:length(k_vals)
    p = p_base;
    p.ka_star = k_vals(i);
    p.kb_star = 5.0;
    [xo, om_sol] = torsional_waveguide_core.track_physical_branch(xi_pts, p);
    plot(xo, om_sol, 'LineWidth', 1.8, 'Color', colors{i}, ...
         'DisplayName', sprintf('k_a^* = %g', k_vals(i)));
end
xlabel('Dimensionless Wavenumber \xi');
ylabel('Dimensionless Frequency \Omega');
title('(a) Inner Interface Stiffness Sweep (k_a^*, with k_b^* = 5)', 'FontWeight', 'bold');
legend('Location', 'southeast');
grid on; box on;
xlim([0, 6]);
ylim([0, 0.22]);

% --- Subplot (b): kb* sweep at fixed ka* = 5 ---
subplot(1, 2, 2);
hold on;
fprintf('Panel (b): Sweeping kb* with fixed ka* = 5.0...\n');
for i = 1:length(k_vals)
    p = p_base;
    p.ka_star = 5.0;
    p.kb_star = k_vals(i);
    [xo, om_sol] = torsional_waveguide_core.track_physical_branch(xi_pts, p);
    plot(xo, om_sol, 'LineWidth', 1.8, 'Color', colors{i}, ...
         'DisplayName', sprintf('k_b^* = %g', k_vals(i)));
end
xlabel('Dimensionless Wavenumber \xi');
ylabel('Dimensionless Frequency \Omega');
title('(b) Outer Interface Stiffness Sweep (k_b^*, with k_a^* = 5)', 'FontWeight', 'bold');
legend('Location', 'southeast');
grid on; box on;
xlim([0, 6]);
ylim([0, 0.22]);

if exist('sgtitle', 'builtin') || exist('sgtitle', 'file')
    sgtitle('Comparative Influence of Core (k_a^*) vs Shell (k_b^*) Interface Bonding', ...
        'FontSize', 12, 'FontWeight', 'bold');
end

output_dir = fullfile(fileparts(fileparts(fileparts(mfilename('fullpath')))), '02_OVERLEAF', 'figures');
if ~exist(output_dir, 'dir'), mkdir(output_dir); end
saveas(fig, fullfile(output_dir, 'fig_interface_stiffness_comparison.png'));
fprintf('Saved figure as: fig_interface_stiffness_comparison.png\n');
