%% ========================================================================
% FIGURE 15: LOGARITHMIC OAT SENSITIVITY HEATMAP MATRIX
% ========================================================================
% The matrix in this figure is the same dynamic matrix written to
% DATA/oat_sensitivity.npz by the Python generator.  Perturbations are
% a_minus=0.5*a and a_plus=2*a, with
% S = [ln Q(a_plus)-ln Q(a_minus)]/ln(4).
% Responses: Omega(6), xi_on, vp(6), L(r_ref=1e-4 b), and R_cb(6).
% ========================================================================

function Figure15_Sensitivity_Matrix()
    close all; clc;
    fprintf('=================================================================\n');
    fprintf('  REPRODUCING FIGURE 15: DYNAMIC LOGARITHMIC SENSITIVITY MATRIX  \n');
    fprintf('=================================================================\n\n');

    p0 = torsional_waveguide_core.get_default_parameters();
    xi_eval = 6.0;
    cfg = torsional_waveguide_core.numerical_settings();
    factors = cfg.oat_factors;

    [~, base_xic, base_q] = evaluate_metrics(p0, xi_eval);
    fprintf('Baseline Q = [Omega %.6f, xi_on %.4f, vp %.4f, L %.4e, R_cb %.4f]\n', ...
            base_q(1), base_xic, base_q(3), base_q(4), base_q(5));

    param_names = {'\mu_s^*', 'k_a^*', 'k_b^*'};
    n_params = length(param_names);
    n_metrics = 5;
    S = zeros(n_params, n_metrics);
    raw_low = zeros(n_params, n_metrics);
    raw_high = zeros(n_params, n_metrics);

    for i = 1:n_params
        fprintf('Evaluating logarithmic OAT row %d/%d...\n', i, n_params);
        p_minus = p0; p_plus = p0;
        if i == 1
            p_minus.mus_star = p0.mus_star * factors(1);
            p_plus.mus_star  = p0.mus_star * factors(2);
        elseif i == 2
            p_minus.ka_star = p0.ka_star * factors(1);
            p_plus.ka_star  = p0.ka_star * factors(2);
        else
            p_minus.kb_star = p0.kb_star * factors(1);
            p_plus.kb_star  = p0.kb_star * factors(2);
        end
        [~, ~, q_minus] = evaluate_metrics(p_minus, xi_eval);
        [~, ~, q_plus]  = evaluate_metrics(p_plus, xi_eval);
        raw_low(i, :) = q_minus;
        raw_high(i, :) = q_plus;
        S(i, :) = (log(q_plus) - log(q_minus)) / log(factors(2) / factors(1));
    end

    fprintf('Computed 3x5 matrix [Omega, xi_on, vp, L, R_cb]:\n');
    disp(S);

    row_labels = {'\mu_s^*', 'k_a^*', 'k_b^*'};
    col_labels = {'\Omega(6)', '\xi_{on}', 'v_p(6)', 'L', 'R_{cb}'};
    fig = figure('Name', 'Figure 15 - Sensitivity Matrix', 'Color', 'w', ...
                 'Position', [100, 100, 760, 380]);

    c_blue = [0.230, 0.299, 0.754];
    c_white = [1.0, 1.0, 1.0];
    c_red = [0.706, 0.016, 0.150];
    n_half = 128;
    custom_bwr = [[linspace(c_blue(1), c_white(1), n_half), linspace(c_white(1), c_red(1), n_half)]', ...
                  [linspace(c_blue(2), c_white(2), n_half), linspace(c_white(2), c_red(2), n_half)]', ...
                  [linspace(c_blue(3), c_white(3), n_half), linspace(c_white(3), c_red(3), n_half)]'];
    imagesc(S);
    colormap(custom_bwr);
    caxis([-0.65, 0.65]);
    cb = colorbar;
    ylabel(cb, '\partial ln Q / \partial ln a_i', 'FontWeight', 'bold');
    set(gca, 'XTick', 1:n_metrics, 'XTickLabel', col_labels, 'FontWeight', 'bold');
    set(gca, 'YTick', 1:n_params, 'YTickLabel', row_labels, 'FontWeight', 'bold');
    xlabel('Response Q_j'); ylabel('Perturbed parameter a_i');

    for i = 1:n_params
        for j = 1:n_metrics
            txt_color = 'k';
            if abs(S(i,j)) > 0.4, txt_color = 'w'; end
            text(j, i, sprintf('%.2f', S(i,j)), 'HorizontalAlignment', 'center', ...
                 'Color', txt_color, 'FontWeight', 'bold');
        end
    end
    hold on;
    for k = 0.5:1:(n_metrics + 0.5)
        plot([k, k], [0.5, n_params + 0.5], 'Color', [0.8 0.8 0.8], 'LineWidth', 1.0);
    end
    for k = 0.5:1:(n_params + 0.5)
        plot([0.5, n_metrics + 0.5], [k, k], 'Color', [0.8 0.8 0.8], 'LineWidth', 1.0);
    end
    box on;

    output_dir = fullfile(fileparts(fileparts(fileparts(mfilename('fullpath')))), '02_OVERLEAF', 'figures');
    if ~exist(output_dir, 'dir'), mkdir(output_dir); end
    saveas(fig, fullfile(output_dir, 'fig_sensitivity_journal.png'));
    fprintf('Saved figure as: fig_sensitivity_journal.png\n');
end

function [om, xic, q] = evaluate_metrics(p, xi_eval)
    cfg = torsional_waveguide_core.numerical_settings();
    xi_grid = linspace(cfg.xi_start, cfg.xi_end, cfg.grid_points);
    [xi_track, om_track, ~] = torsional_waveguide_core.track_physical_branch(xi_grid, p);
    ok = isfinite(om_track);
    if ~any(ok)
        om = NaN; xic = NaN; q = NaN(1,5); return;
    end
    xok = xi_track(ok); ook = om_track(ok);
    xic = xok(1);
    % xi_eval is the last configured grid point here; interpolate only if a
    % caller requests another point that is covered by the tracked branch.
    om = interp1(xok, ook, xi_eval, 'linear', 'extrap');
    [~, ~, ~, ~, is_valid] = torsional_waveguide_core.compute_wavenumbers(xi_eval, om, p);
    if ~is_valid
        q = NaN(1,5); return;
    end
    C = torsional_waveguide_core.solve_wave_field_constants(xi_eval, om, p);
    [g1, g2, g3, ~, ~] = torsional_waveguide_core.compute_wavenumbers(xi_eval, om, p);
    r_ref = 1e-4;
    u_ref = abs(C(1) * besseli(1, g1 * r_ref));
    u_c = abs(C(4) * besseli(1, p.beta*g3) + C(5) * besselk(1, p.beta*g3));
    u_bp = abs(C(4) * besseli(1, g3) + C(5) * besselk(1, g3));
    L = u_c / max(u_ref, realmin);
    Rcb = u_c / max(u_bp, realmin);
    q = [om, xic, p.v2 * om / xi_eval, L, Rcb];
end
