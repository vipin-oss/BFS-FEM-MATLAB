%% =========================================================================
% RUN_ALL_MATLAB_SIMULATIONS.M
% =========================================================================
% Master Execution Script for the Research Project:
% "Torsional Surface Waves in a Thermoelastic Cylinder Embedded in an
%  Elastic Metamaterial with Gurtin-Murdoch Surface Elasticity for
%  Sensing Applications"
%
% This script runs all individual simulation modules from zero:
%   - Script 01: Dispersion relations, phase and group velocities, ZGV point
%   - Script 02: Parametric sweep of Gurtin-Murdoch surface elasticity
%   - Script 03: Parametric sweep of interface spring stiffnesses
%   - Script 04: Waveguide geometry & metamaterial shell thickness effects
%   - Script 05: Radial mode shapes, shear stress, and spring step jumps
%   - Script 06: Finite-model checks and separate planar reference
%   - Script 07: Acoustic mass and viscous liquid sensing analysis
%
% All simulations compute results directly from first principles
% (Bessel functions, 5x5 boundary matrices, root solving, SVD nullspace)
% with NO precomputed data files.
% =========================================================================

clear; clc; close all;

fprintf('==========================================================================\n');
fprintf('  TORSIONAL WAVEGUIDE RESEARCH PROJECT: MASTER SIMULATION RUNNER          \n');
fprintf('==========================================================================\n\n');
fprintf('Available Simulation Modules:\n');
fprintf('  [1] Script 01: Dispersion Curve, Phase & Group Velocity, ZGV Trapping\n');
fprintf('  [2] Script 02: Gurtin-Murdoch Surface Elasticity Parametric Study\n');
fprintf('  [3] Script 03: Imperfect Interface Spring Compliance Study\n');
fprintf('  [4] Script 04: Waveguide Geometry & Shell Thickness Effects\n');
fprintf('  [5] Script 05: Radial Mode Shapes, Shear Stress Profiles, & Spring Jumps\n');
fprintf('  [6] Script 06: Finite-Model Checks / Separate Planar Reference\n');
fprintf('  [7] Script 07: Theoretical Sensing Framework (Mass & Liquid Loading)\n');
fprintf('  [8] Run ALL Modules Sequentially (Comprehensive Run)\n\n');

% Default: Run modules 1, 5, and 6 as a fast demonstration suite if run non-interactively
choice = 8; % Set to 1-7 for individual script, or 8 to run all

scripts = {
    'script01_dispersion_and_velocities', ...
    'script02_parametric_surface_elasticity', ...
    'script03_parametric_interface_springs', ...
    'script04_geometry_thickness_effects', ...
    'script05_mode_shapes_and_stress', ...
    'script06_independent_validation_limits', ...
    'script07_sensing_analysis'
};

if choice >= 1 && choice <= 7
    to_run = choice;
else
    to_run = 1:7;
end

t_start_total = tic;
failed_modules = {};

for s = to_run
    script_name = scripts{s};
    fprintf('\n>>> Running Module [%d]: %s.m ...\n', s, script_name);
    t_mod = tic;
    try
        if strcmp(script_name, 'script06_independent_validation_limits') || strcmp(script_name, 'script07_sensing_analysis')
            feval(script_name);
        else
            run(script_name);
        end
        fprintf('>>> Module [%d] completed successfully in %.2f seconds.\n', s, toc(t_mod));
    catch ME
        failed_modules{end+1} = script_name; %#ok<AGROW>
        fprintf('>>> Error running module [%d]: %s\n', s, ME.message);
    end
end

total_time = toc(t_start_total);
fprintf('\n==========================================================================\n');
if isempty(failed_modules)
    fprintf('  ALL REQUESTED SIMULATION MODULES COMPLETED WITHOUT ERRORS IN %.2f S.  \n', total_time);
else
    fprintf('  COMPLETED WITH %d FAILURE(S) IN %.2f SECONDS. FAILED MODULES:          \n', numel(failed_modules), total_time);
    for j = 1:numel(failed_modules)
        fprintf('    - %s\n', failed_modules{j});
    end
end
fprintf('==========================================================================\n');
