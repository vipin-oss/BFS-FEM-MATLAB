function script06_independent_validation_limits()
%% ========================================================================
% SCRIPT 06: FINITE-MODEL CHECKS AND SEPARATE PLANAR REFERENCE
% ========================================================================
% This module deliberately does not call the welded planar SH equation a
% limit of the baseline finite-spring/finite-shell determinant.  It evaluates
% that equation as a separate reference and reports finite parameter checks.
% The continuous benchmark cutoff is handled in Figure02_Validation_Benchmark
% with the shared bounded scalar optimization convention.
% ========================================================================

close all; clc;
fprintf('=================================================================\n');
fprintf('  SCRIPT 06: FINITE-MODEL CHECKS / SEPARATE PLANAR REFERENCE    \n');
fprintf('=================================================================\n\n');

p = torsional_waveguide_core.get_default_parameters();
p.ka_star = 5.0;
p.kb_star = 5.0;
p.mus_star = 1e-5;
p.tau0_star = 0.0;
xi_pts = linspace(0.05, 6.0, 300);

% Baseline and finite-parameter cases.
[~, om_base] = torsional_waveguide_core.track_physical_branch(xi_pts, p);
p_g0 = p; p_g0.mus_star = 0; p_g0.tau0_star = 0;
[~, om_g0] = torsional_waveguide_core.track_physical_branch(xi_pts, p_g0);
p_rigid = p; p_rigid.ka_star = 1000; p_rigid.kb_star = 1000;
[~, om_rigid] = torsional_waveguide_core.track_branch_continuation(xi_pts, p_rigid, 1);
p_soft = p; p_soft.ka_star = 0.5; p_soft.kb_star = 0.5;
[~, om_soft] = torsional_waveguide_core.track_branch_continuation(xi_pts, p_soft, 1);

% Welded planar SH relation: separate half-space equation, not the finite
% model's asymptotic limit.
planar_xi = linspace(0.1, 6.0, 100);
planar_om = NaN(size(planar_xi));
for i = 1:numel(planar_xi)
    xi = planar_xi(i);
    om_grid = linspace(1e-4, min(0.9999*xi, 0.9999*p.Omega_p), 1200);
    rv = arrayfun(@(om) planar_spp_residual(xi, om, p), om_grid);
    idx = find(isfinite(rv(1:end-1)) & isfinite(rv(2:end)) & ...
               (sign(rv(1:end-1)) ~= sign(rv(2:end))), 1, 'first');
    if ~isempty(idx)
        try
            planar_om(i) = fzero(@(om) planar_spp_residual(xi, om, p), ...
                                 [om_grid(idx), om_grid(idx+1)]);
        catch
        end
    end
end

fprintf('Separate welded planar reference at xi=6: Omega=%.6f\n', planar_om(end));
fprintf('Baseline finite model at xi=6:             Omega=%.6f\n', om_base(end));
fprintf('Vanishing surface elasticity at xi=6:      Omega=%.6f\n', om_g0(end));
fprintf('Stiff-interface finite surrogate at xi=6:   Omega=%.6f\n', om_rigid(end));
fprintf('Compliant-interface finite reference at xi=6: Omega=%.6f\n', om_soft(end));
fprintf(['Interpretation: the planar curve is a separately defined welded ', ...
         'half-space reference; no baseline convergence claim is made.\n']);

% This diagnostic plot is intentionally separate from the manuscript Figure
% 03; Figure03_Validation_Limits.m is the figure-producing implementation.
fig = figure('Name', 'Script 06 finite checks', 'Color', 'w');
plot(xi_pts, om_base, 'b-', 'LineWidth', 1.6, 'DisplayName', 'Finite baseline'); hold on;
plot(planar_xi, planar_om, 'k-.', 'LineWidth', 1.4, ...
     'DisplayName', 'Welded planar reference (separate)');
plot(xi_pts, om_g0, 'g:', 'LineWidth', 1.4, 'DisplayName', 'mu_s^*=0 finite case');
plot(xi_pts, om_rigid, 'm--', 'LineWidth', 1.4, ...
     'DisplayName', 'Finite stiff-interface surrogate');
plot(xi_pts, om_soft, 'r-.', 'LineWidth', 1.4, ...
     'DisplayName', 'Finite compliant-interface reference');
xlabel('Dimensionless Wavenumber \xi = kb');
ylabel('Dimensionless Frequency \Omega');
title('Finite-model checks and separate welded planar reference');
legend('Location', 'northwest'); grid on; box on;
xlim([0, 6]); ylim([0, 0.35]);

out = fullfile(fileparts(fileparts(fileparts(mfilename('fullpath')))), '02_OVERLEAF', 'figures');
if ~exist(out, 'dir'), mkdir(out); end
saveas(fig, fullfile(out, 'fig_script06_validation.png'));
end

function res = planar_spp_residual(xi, Omega, p)
    [~, g2, g3, m3, isValid] = torsional_waveguide_core.compute_wavenumbers(xi, Omega, p);
    if ~isValid
        res = NaN;
    else
        res = m3*g3 + g2;
    end
end
