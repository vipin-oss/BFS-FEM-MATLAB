#!/usr/bin/env python3
"""Archive launcher for src/python/scoping_check.py."""
from pathlib import Path
import runpy
import sys

HERE = Path(__file__).resolve()
ROOT = HERE.parents[3]
SRC = ROOT / "01_PROGRAM" / "src" / "python"
sys.path.insert(0, str(SRC))
runpy.run_path(str(SRC / "scoping_check.py"), run_name="__main__")
