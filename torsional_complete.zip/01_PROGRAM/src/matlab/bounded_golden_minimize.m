function [x, fval, n] = bounded_golden_minimize(fun, lo, hi, tol, max_iter)
%BOUNDED_GOLDEN_MINIMIZE Deterministic bounded golden-section minimization.
%   Mirrors PROGRAMS/PYTHON/benchmark_kielczynski.py so both benchmark
%   implementations use the same objective, bounds, tolerance, and stopping
%   rule.  No toolbox optimizer is required.
if nargin < 4 || isempty(tol), tol = 1e-8; end
if nargin < 5 || isempty(max_iter), max_iter = 200; end
phi = (sqrt(5) - 1) / 2;
a = lo; b = hi;
c = b - phi * (b - a);
d = a + phi * (b - a);
fc = fun(c); fd = fun(d);
n = 0;
while abs(b - a) > tol && n < max_iter
    if fc < fd
        b = d; d = c; fd = fc;
        c = b - phi * (b - a);
        fc = fun(c);
    else
        a = c; c = d; fc = fd;
        d = a + phi * (b - a);
        fd = fun(d);
    end
    n = n + 1;
end
x = 0.5 * (a + b);
fval = fun(x);
end
