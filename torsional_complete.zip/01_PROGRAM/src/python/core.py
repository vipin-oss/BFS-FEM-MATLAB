#!/usr/bin/env python3
"""Shared dimensionless solver core for the reproducibility package."""
import json
from pathlib import Path

import numpy as np
from scipy.optimize import brentq
from scipy.special import iv, kv, ive, kve


# The same small configuration file is read by the MATLAB mirror.  Defaults
# keep the solver usable when this module is copied on its own.
_CONFIG_DEFAULTS = {
    "scan_points": 4000,
    "correction_points": 40,
    "brent_xtol": 1e-13,
    "brent_rtol": 1e-14,
    "continuation_windows": [0.01, 0.02, 0.05, 0.10, 0.20, 0.35],
    "jump_fraction": 0.30,
    "max_retries": 6,
    "branch_onset_samples": 200,
}
try:
    for _cfg_path in (
        Path(__file__).resolve().parents[2] / "config" / "numerical_settings.json",
        Path(__file__).resolve().parents[3] / "CONFIG" / "numerical_settings.json",
    ):
        try:
            with _cfg_path.open("r", encoding="utf-8") as _fh:
                _CONFIG_DEFAULTS.update(json.load(_fh))
            break
        except (OSError, ValueError):
            continue
except (OSError, ValueError):
    pass

SCAN_POINTS = int(_CONFIG_DEFAULTS["scan_points"])
CORRECTION_POINTS = int(_CONFIG_DEFAULTS["correction_points"])
BRENT_XTOL = float(_CONFIG_DEFAULTS["brent_xtol"])
BRENT_RTOL = float(_CONFIG_DEFAULTS["brent_rtol"])
DEFAULT_WINDOWS = [float(x) for x in _CONFIG_DEFAULTS["continuation_windows"]]
JUMP_FRACTION = float(_CONFIG_DEFAULTS["jump_fraction"])
MAX_RETRIES = int(_CONFIG_DEFAULTS["max_retries"])
ONSET_SAMPLES = int(_CONFIG_DEFAULTS["branch_onset_samples"])

# ----------------------------- parameters ------------------------------------
mu1   = 3.86e10
rho1  = 8954.0
rho2  = 1180.0
s44_2 = 70.03e-11
rho3  = 2650.0
s0    = 1.474e-11
fp    = 1.0e6
b     = 0.35016e-3
alpha = 0.5
beta  = 1.5

m1      = mu1*s44_2
r12     = rho1/rho2
r32     = rho3/rho2
s2_s0   = s44_2/s0
omega_p = 2.0*np.pi*fp
Omega_p = omega_p*b*np.sqrt(rho2*s44_2)
v2      = 1.0/np.sqrt(rho2*s44_2)

def gammas2(xi, om, ka, kb, mus, tau0):
    if abs(om) < 1e-10:
        return None
    den = 1.0 - (Omega_p**2)/(om**2)
    if abs(den) < 1e-12:
        return None
    m3 = s2_s0/den
    g12 = xi*xi - r12*om*om/m1
    g22 = xi*xi - om*om
    g32 = xi*xi - r32*om*om/m3
    if g12 <= 0 or g22 <= 0 or g32 <= 0:
        return None
    return g12, g22, g32, m3

def Mmat(xi, om, ka, kb, mus, tau0):
    """The manuscript 5x5 matrix (R1..R5 dimensionless) or None."""
    g = gammas2(xi, om, ka, kb, mus, tau0)
    if g is None:
        return None
    g12, g22, g32, m3 = g
    g1, g2, g3 = np.sqrt(g12), np.sqrt(g22), np.sqrt(g32)
    # Corrected Gurtin-Murdoch constitutive relation (Gurtin & Murdoch 1978):
    # Under the displayed tangent law, prescribed geometry, and zero surface
    # inertia, tau0 cancels from pure torsional shear. The production baseline
    # sets tau0=0; the argument remains for Python/MATLAB API parity and is
    # intentionally not interpreted as a universal prestress result.
    a, c, G = alpha, beta, mus
    M = np.zeros((5, 5))
    M[0, 0] = m1*g1*iv(2, a*g1)
    M[0, 1] = -g2*iv(2, a*g2)
    M[0, 2] = g2*kv(2, a*g2)
    M[1, 0] = m1*g1*iv(2, a*g1) + ka*iv(1, a*g1)
    M[1, 1] = -ka*iv(1, a*g2)
    M[1, 2] = -ka*kv(1, a*g2)
    M[2, 1] = g2*iv(2, g2)
    M[2, 2] = -g2*kv(2, g2)
    M[2, 3] = -m3*g3*iv(2, g3)
    M[2, 4] = m3*g3*kv(2, g3)
    M[3, 1] = g2*iv(2, g2) + kb*iv(1, g2)
    M[3, 2] = -g2*kv(2, g2) + kb*kv(1, g2)
    M[3, 3] = -kb*iv(1, g3)
    M[3, 4] = -kb*kv(1, g3)
    M[4, 3] = m3*g3*iv(2, c*g3) + G*xi*xi*iv(1, c*g3)
    M[4, 4] = -m3*g3*kv(2, c*g3) + G*xi*xi*kv(1, c*g3)
    return M

def _I_scaled(order, z, ref):
    """Return I_order(z) multiplied by exp(-ref), without overflow.

    All callers choose ref >= z, so the remaining exponential is <= 1.
    The positive column scale does not change determinant zeros or signs.
    """
    return ive(order, z) * np.exp(z - ref)


def _K_scaled(order, z, ref):
    """Return K_order(z) multiplied by exp(ref), without overflow."""
    return kve(order, z) * np.exp(ref - z)


def Mmat_stable(xi, om, ka, kb, mus, tau0):
    """Column-scaled characteristic matrix for determinant/root searches.

    Each Bessel column is multiplied by a positive exponential reference
    factor.  The scaled matrix has exactly the same roots and determinant
    signs as the raw matrix, while avoiding I_n overflow and severe column
    imbalance.  ``Mmat`` remains the raw physical matrix for mode-shape
    reconstruction and manuscript-equation diagnostics.
    """
    g = gammas2(xi, om, ka, kb, mus, tau0)
    if g is None:
        return None
    g12, g22, g32, m3 = g
    g1, g2, g3 = np.sqrt(g12), np.sqrt(g22), np.sqrt(g32)
    a, c, G = alpha, beta, mus
    M = np.zeros((5, 5))

    # Column 0: reference exp(alpha*g1), core I terms occur only at alpha.
    I1a = _I_scaled(1, a*g1, a*g1)
    I2a = _I_scaled(2, a*g1, a*g1)
    M[0, 0] = m1*g1*I2a
    M[1, 0] = m1*g1*I2a + ka*I1a

    # Column 1: reference exp(g2), layer I terms at alpha and 1.
    I2a2 = _I_scaled(2, a*g2, g2)
    I1a2 = _I_scaled(1, a*g2, g2)
    I2b2 = _I_scaled(2, g2, g2)
    I1b2 = _I_scaled(1, g2, g2)
    M[0, 1] = -g2*I2a2
    M[1, 1] = -ka*I1a2
    M[2, 1] = g2*I2b2
    M[3, 1] = g2*I2b2 + kb*I1b2

    # Column 2: reference exp(alpha*g2), layer K terms.
    K2a2 = _K_scaled(2, a*g2, a*g2)
    K1a2 = _K_scaled(1, a*g2, a*g2)
    K2b2 = _K_scaled(2, g2, a*g2)
    K1b2 = _K_scaled(1, g2, a*g2)
    M[0, 2] = g2*K2a2
    M[1, 2] = -ka*K1a2
    M[2, 2] = -g2*K2b2
    M[3, 2] = -g2*K2b2 + kb*K1b2

    # Column 3: reference exp(beta*g3), shell I terms at 1 and beta.
    I2b3 = _I_scaled(2, g3, c*g3)
    I1b3 = _I_scaled(1, g3, c*g3)
    I2c3 = _I_scaled(2, c*g3, c*g3)
    I1c3 = _I_scaled(1, c*g3, c*g3)
    M[2, 3] = -m3*g3*I2b3
    M[3, 3] = -kb*I1b3
    M[4, 3] = m3*g3*I2c3 + G*xi*xi*I1c3

    # Column 4: reference exp(g3), shell K terms at 1 and beta.
    K2b3 = _K_scaled(2, g3, g3)
    K1b3 = _K_scaled(1, g3, g3)
    K2c3 = _K_scaled(2, c*g3, g3)
    K1c3 = _K_scaled(1, c*g3, g3)
    M[2, 4] = m3*g3*K2b3
    M[3, 4] = -kb*K1b3
    M[4, 4] = -m3*g3*K2c3 + G*xi*xi*K1c3
    return M


def Dfun(xi, om, ka, kb, mus, tau0):
    """Row-equilibrated determinant of the column-scaled matrix.

    Column exponential factors and positive row norms preserve the zero set
    and determinant sign.  Returning the equilibrated determinant keeps the
    bracket function finite over the tested argument range.
    """
    M = Mmat_stable(xi, om, ka, kb, mus, tau0)
    if M is None:
        return np.nan
    row_norm = np.max(np.abs(M), axis=1)
    row_norm = np.maximum(row_norm, np.finfo(float).tiny)
    M = M / row_norm[:, None]
    d = np.linalg.det(M)
    return d if np.isfinite(d) else np.nan


def find_roots_at_xi(xi, ka, kb, mus, tau0, ngrid=None, om_max=None):
    if ngrid is None:
        ngrid = SCAN_POINTS
    if om_max is None:
        om_max = 0.9999*xi
    grid = np.linspace(1e-4, om_max, int(ngrid))
    vals = np.asarray([Dfun(xi, o, ka, kb, mus, tau0) for o in grid], dtype=float)
    roots = []
    for i in range(ngrid-1):
        f1, f2 = vals[i], vals[i+1]
        if not (np.isfinite(f1) and np.isfinite(f2)):
            continue
        # The scaled determinant can change magnitude strongly with Omega;
        # signbit comparison avoids overflow in f1*f2.  Invalid intervals
        # (including Bessel/Drude poles) are never bracketed across.
        if np.signbit(f1) != np.signbit(f2):
            try:
                r = brentq(lambda o: Dfun(xi, o, ka, kb, mus, tau0),
                            grid[i], grid[i+1], xtol=BRENT_XTOL, rtol=BRENT_RTOL, maxiter=200)
                if not any(abs(r-x) < 1e-7 for x in roots):
                    roots.append(r)
            except Exception:
                pass
    return sorted(roots, reverse=True)


def _correct_near(xi, pred, ka, kb, mus, tau0, windows):
    """Find the determinant root nearest a predictor using nested brackets."""
    for w in windows:
        lo, hi = max(pred-w, 1e-8), min(pred+w, 0.9999*xi)
        if hi <= lo:
            continue
        grid = np.linspace(lo, hi, 40)
        vals = np.asarray([Dfun(xi, o, ka, kb, mus, tau0) for o in grid], dtype=float)
        candidates = []
        for i in range(len(grid)-1):
            f1, f2 = vals[i], vals[i+1]
            if not (np.isfinite(f1) and np.isfinite(f2)):
                continue
            if np.signbit(f1) == np.signbit(f2):
                continue
            try:
                r = brentq(lambda o: Dfun(xi, o, ka, kb, mus, tau0),
                           grid[i], grid[i+1], xtol=BRENT_XTOL, rtol=BRENT_RTOL,
                           maxiter=200)
                candidates.append(r)
            except Exception:
                pass
        if candidates:
            return min(candidates, key=lambda r: abs(r-pred))
    return None


def _relative_jump(om, prev, max_jump):
    return prev is not None and abs(om-prev) > max_jump*max(abs(prev), 1e-12)


def track_branch(ka, kb, mus, tau0, xi_grid, seed_xi, branch_rank,
                 windows=None, max_jump=JUMP_FRACTION, verbose=False, max_retries=MAX_RETRIES):
    """Track a branch with sign-change correction and adaptive jump recovery.

    The recorded output remains on ``xi_grid``.  If a corrected root changes
    by more than ``max_jump`` relative to the preceding accepted root, the
    interval is re-evaluated through successively halved internal steps.  A
    jump is reported if recovery cannot satisfy the criterion.
    """
    if windows is None:
        windows = DEFAULT_WINDOWS
    info = dict(xi=[], om=[], ok_mask=[], jumps=[], retry_events=[],
                loss_count=0, lost_at=None)
    prev = None; prev2 = None; prev_xi = None
    for xi in xi_grid:
        om = None
        if prev is None:
            roots = find_roots_at_xi(xi, ka, kb, mus, tau0)
            if branch_rank <= len(roots):
                om = roots[branch_rank-1]
        else:
            pred = prev if prev2 is None else 2.0*prev - prev2
            om = _correct_near(xi, pred, ka, kb, mus, tau0, windows)
            if om is not None and _relative_jump(om, prev, max_jump):
                # Re-evaluate with internal half-steps.  The first midpoint
                # starts from the last accepted root; later midpoints use the
                # most recently accepted internal point.
                old_prev, old_prev2, old_xi = prev, prev2, prev_xi
                local_prev, local_prev2, local_xi = prev, prev2, prev_xi
                recovered = False
                for retry in range(1, max_retries+1):
                    mid = 0.5*(local_xi + xi)
                    mid_pred = local_prev if local_prev2 is None else 2.0*local_prev-local_prev2
                    mid_om = _correct_near(mid, mid_pred, ka, kb, mus, tau0, windows)
                    if mid_om is None:
                        break
                    final = _correct_near(xi, mid_om, ka, kb, mus, tau0, windows)
                    if final is not None and not _relative_jump(final, mid_om, max_jump):
                        om = final
                        info["retry_events"].append((xi, retry, old_prev, om))
                        recovered = True
                        break
                    local_prev2, local_prev, local_xi = local_prev, mid_om, mid
                if not recovered:
                    info["jumps"].append((xi, prev, om))
                elif verbose:
                    print("adaptive retry at xi=%.6g after %d half-step(s)" % (xi, retry))
        if om is None:
            info["loss_count"] += 1
            if info["lost_at"] is None and info["loss_count"] > 25:
                info["lost_at"] = xi
            info["ok_mask"].append(False)
        else:
            # Do not duplicate a recovered jump in the ordinary path.
            if prev is not None and _relative_jump(om, prev, max_jump) and not any(e[0] == xi for e in info["retry_events"]):
                info["jumps"].append((xi, prev, om))
            info["ok_mask"].append(True)
            prev2 = prev; prev = om; prev_xi = xi
        info["xi"].append(xi)
        info["om"].append(om if om is not None else np.nan)
    info["xi"] = np.array(info["xi"])
    info["om"] = np.array(info["om"])
    info["ok_mask"] = np.array(info["ok_mask"])
    return info

def find_branch_onset(xi_lo, xi_hi, n, ka, kb, mus, tau0, rank, ngrid=None):
    if ngrid is None:
        ngrid = SCAN_POINTS
    for xi in np.linspace(xi_lo, xi_hi, n):
        if len(find_roots_at_xi(xi, ka, kb, mus, tau0, ngrid=ngrid)) >= rank:
            return xi
    return None

def track_physical_branch(ka, kb, mus, tau0, xi_g, n_on=ONSET_SAMPLES):
    # Convention: roots are sorted DESCENDING, so branch rank 1 is the
    # highest-Omega physical surface branch wherever two roots coexist.  A
    # weak-surface seed with an O(1) phase ratio is already that branch; a
    # strong-surface seed containing only the low branch is re-seeded at the
    # first rank-2 onset.  Track on a fine grid (>= ~300 points over [0.05,6]).
    roots0 = find_roots_at_xi(xi_g[0], ka, kb, mus, tau0)
    # If the only seed root has the ordinary O(1) phase ratio, it is the
    # baseline physical branch (the weak-surface case).  For strong surface
    # elasticity the seed may contain only the low branch; then wait for the
    # declared two-root onset before selecting the highest root.
    seed_is_physical = bool(roots0) and roots0[0] / max(xi_g[0], 1e-12) > 0.25
    if len(roots0) >= 2 or mus < 1e-12 or seed_is_physical:
        return track_branch(ka, kb, mus, tau0, xi_g, xi_g[0], 1), xi_g[0]
    xi_on = find_branch_onset(xi_g[0], min(xi_g[-1], 3.0), n_on,
                              ka, kb, mus, tau0, 2)
    if xi_on is None:
        # Some parameter sets have only one branch.  Fall back to the first
        # available root instead of returning an unexplained NaN branch.
        first = None
        for x in xi_g:
            if len(find_roots_at_xi(x, ka, kb, mus, tau0)) >= 1:
                first = x
                break
        if first is None:
            return None, None
        g2 = xi_g[xi_g >= first]
        return track_branch(ka, kb, mus, tau0, g2, first, 1), first
    g2 = xi_g[xi_g >= xi_on]
    return track_branch(ka, kb, mus, tau0, g2, xi_on, 1), xi_on


# =========================================================================
# KIELCZYNSKI ET AL. (2025) REDUCED BENCHMARK DISPERSION RESIDUAL
# =========================================================================
def kiel_dispersion_residual(w, k, a=0.01, rho1=2650.0, s0=1.474e-11,
                            wp=2*np.pi*1.0e6, rho2=1180.0, s44_2=70.03e-11):
    """
    Evaluates the residual of the Kiełczyński et al. (2025) [Sensors 25(1):143]
    dispersion relation for acoustic-surface-plasmon polaritons:
      F(w, k) = [K2(g2*a) / K1(g2*a)] + [s44_2 / s1(w)] * (g1 / g2) * [I2(g1*a) / I1(g1*a)] = 0
    """
    s1 = s0 * (1.0 - (wp / w)**2)
    g1_sq = k**2 - rho1 * (w**2) * s1
    g2_sq = k**2 - rho2 * (w**2) * s44_2
    
    if (g1_sq <= 0) or (g2_sq <= 0) or (s1 >= 0):
        return np.nan
        
    g1 = np.sqrt(g1_sq)
    g2 = np.sqrt(g2_sq)
    
    # Exponential factors cancel in each ratio; scaled Bessel functions
    # protect the benchmark residual at large cylindrical arguments.
    term1 = kve(2, g2 * a) / kve(1, g2 * a)
    term2 = (s44_2 / s1) * (g1 / g2) * (ive(2, g1 * a) / ive(1, g1 * a))
    
    return term1 + term2

