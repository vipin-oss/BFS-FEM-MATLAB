#!/usr/bin/env python3
"""Mode-shape reconstruction shared by the figure and sensitivity scripts.

Importing this module is side-effect free.  Run it as a script for the
optional diagnostic report.
"""
import numpy as np
from scipy.special import iv, kv
import core as C

KA, KB, MUS, TAU0 = 5.0, 5.0, 1.0e-5, 0.0


def mode_shape(xi, om, ka, kb, mus, tau0, nr=60):
    """Return the SVD null vector, piecewise profiles, and interface metrics."""
    M = C.Mmat(xi, om, ka, kb, mus, tau0)
    if M is None:
        raise ValueError("(xi, Omega) is outside the evanescent regime")
    _, singular, vh = np.linalg.svd(M)
    v = vh[-1].copy()
    A1, B1, B2, C1, C2 = v
    g = C.gammas2(xi, om, ka, kb, mus, tau0)
    g1, g2, g3 = np.sqrt(g[0]), np.sqrt(g[1]), np.sqrt(g[2])
    r1 = np.linspace(1e-4, C.alpha, nr)
    r2 = np.linspace(C.alpha, 1.0, nr)
    r3 = np.linspace(1.0, C.beta, nr)
    u1 = A1 * iv(1, g1 * r1)
    u2 = B1 * iv(1, g2 * r2) + B2 * kv(1, g2 * r2)
    u3 = C1 * iv(1, g3 * r3) + C2 * kv(1, g3 * r3)
    diag = dict(
        smin_s2=singular[-1] / singular[-2],
        resid=float(np.linalg.norm(M @ v) / np.linalg.norm(M, "fro")),
        u_0p=abs(A1 * iv(1, g1 * 1e-8)),
        u_0p_g=abs(u1[0]),
        u_am=abs(u1[-1]),
        u_ap=abs(u2[0]),
        u_bm=abs(u2[-1]),
        u_bp=abs(u3[0]),
        u_c=abs(u3[-1]),
    )
    diag["loc_factor"] = diag["u_c"] / (diag["u_0p_g"] + 1e-30)
    diag["loc_factor_analytic"] = diag["u_c"] / (diag["u_0p"] + 1e-30)
    umax = max(np.abs(u1).max(), np.abs(u2).max(), np.abs(u3).max())
    diag["umax"] = umax
    diag["jump_a"] = abs(u2[0] - u1[-1]) / (umax + 1e-30)
    diag["jump_b"] = abs(u3[0] - u2[-1]) / (umax + 1e-30)
    return dict(v=v, g1=g1, g2=g2, g3=g3, r1=r1, r2=r2, r3=r3,
                u1=u1, u2=u2, u3=u3, diag=diag)


def report(name, ms, show_u=True):
    d = ms["diag"]
    print("  %-8s smin/s2=%.2e resid=%.2e max|u|=%.4e" %
          (name, d["smin_s2"], d["resid"], d["umax"]))
    if show_u:
        print("  %-8s |u|: 0+(1e-4)=%.3e 0+(1e-8)=%.3e a-=%.3e a+=%.3e b-=%.3e b+=%.3e c=%.3e" %
              (name, d["u_0p_g"], d["u_0p"], d["u_am"], d["u_ap"],
               d["u_bm"], d["u_bp"], d["u_c"]))
    print("  %-8s loc(grid)=%.3e loc(analytic)=%.3e jump_a=%.3e jump_b=%.3e" %
          (name, d["loc_factor"], d["loc_factor_analytic"],
           d["jump_a"], d["jump_b"]))


def _diagnostics():
    print("=== mode-shape verification (Python reference) ===")
    print("b=%.6e m; a=%.6e mm; b=%.6e mm; c=%.6e mm" %
          (C.b, C.alpha * C.b * 1e3, C.b * 1e3, C.beta * C.b * 1e3))
    print("\n--- baseline roots ---")
    for xi in (0.5, 1.0, 5.0):
        om = C.find_roots_at_xi(xi, KA, KB, MUS, TAU0)[0]
        report("xi=%.1f" % xi, mode_shape(xi, om, KA, KB, MUS, TAU0))


if __name__ == "__main__":
    _diagnostics()
