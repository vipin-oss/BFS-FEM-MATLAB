"""Shared logarithmic OAT response and sensitivity calculations.

Both the journal preview generator and the standalone sensitivity audit import
this module.  Interface-side values are evaluated analytically; the radial
reference for L is the first defined core point r_ref/b = 1e-4.
"""
from __future__ import annotations

import numpy as np

import core as C
from mode_shape_check import mode_shape

KA0, KB0, MUS0, TAU00 = 5.0, 5.0, 1.0e-5, 0.0
XI_GRID = np.linspace(0.05, 6.0, 300)
OAT_FACTORS = (0.5, 2.0)


def branch_metrics(ka: float, kb: float, mus: float, tau0: float,
                   xi_grid=XI_GRID):
    """Return [Omega6, xi_on, vp6, L6, R_cb6] for one parameter set."""
    tracked, onset = C.track_physical_branch(ka, kb, mus, tau0, xi_grid)
    if tracked is None:
        return np.full(5, np.nan), None
    ok = tracked["ok_mask"]
    if not np.any(ok):
        return np.full(5, np.nan), onset
    xi_ok = tracked["xi"][ok]
    om_ok = tracked["om"][ok]
    xi_on = float(xi_ok[0])
    om6 = float(om_ok[-1])
    ms = mode_shape(6.0, om6, ka, kb, mus, tau0)
    d = ms["diag"]
    # L is intentionally a finite, reproducible core-to-surface amplitude
    # ratio at r_ref/b=1e-4, not a limiting value at r=0 (which is zero for I1).
    L = float(d["u_c"] / (d["u_0p_g"] + 1e-30))
    R_cb = float(d["u_c"] / (d["u_bp"] + 1e-30))
    return np.array([om6, xi_on, om6 / 6.0 * C.v2, L, R_cb]), xi_on


def _parameter_set(which: str, factor: float):
    if which == "mu_s":
        return KA0, KB0, MUS0 * factor, TAU00
    if which == "k_a":
        return KA0 * factor, KB0, MUS0, TAU00
    if which == "k_b":
        return KA0, KB0 * factor, MUS0, TAU00
    raise ValueError(which)


def oat_matrix(factors=OAT_FACTORS):
    """Return the dynamic 3x5 logarithmic OAT matrix and raw responses."""
    raw = {}
    matrix = []
    for which in ("mu_s", "k_a", "k_b"):
        low, _ = branch_metrics(*_parameter_set(which, factors[0]))
        high, _ = branch_metrics(*_parameter_set(which, factors[1]))
        raw[which] = {"low": low, "high": high}
        with np.errstate(divide="ignore", invalid="ignore"):
            row = (np.log(high) - np.log(low)) / np.log(factors[1] / factors[0])
        matrix.append(row)
    return np.asarray(matrix), raw
