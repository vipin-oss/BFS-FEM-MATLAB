"""Archive-local paths for reproducible Python generation.

The source tree is deliberately independent of the historical project
layout.  Generated data and figures are kept separate from the
manuscript copies; sync_outputs.py promotes them to the two final
figure locations after a successful run.
"""
from pathlib import Path
import os

PYTHON_DIR = Path(__file__).resolve().parent
PROGRAM_DIR = PYTHON_DIR.parent.parent
ARCHIVE_ROOT = PROGRAM_DIR.parent
OUT_DIR = Path(os.environ.get(
    "TORSIONAL_OUT", str(ARCHIVE_ROOT / "03_DATA" / "generated" / "figures"))).resolve()
DATA_DIR = Path(os.environ.get(
    "TORSIONAL_DATA", str(ARCHIVE_ROOT / "03_DATA" / "generated"))).resolve()
OUT_DIR.mkdir(parents=True, exist_ok=True)
DATA_DIR.mkdir(parents=True, exist_ok=True)
