#!/usr/bin/env python3
"""Check the current physical-branch routing convention.

Weak-surface seeds with an O(1) phase ratio are continued directly.  Strong
surface cases whose seed contains only the low branch are delayed until the
first declared two-root onset.  This is the convention mirrored in the
MATLAB core.
"""
from __future__ import annotations

import numpy as np
import core as C


def report(ka: float, kb: float, mus: float, tau0: float) -> None:
    xi = np.linspace(0.05, 6.0, 300)
    roots = C.find_roots_at_xi(xi[0], ka, kb, mus, tau0)
    seed_ratio = roots[0] / xi[0] if roots else float("nan")
    branch, onset = C.track_physical_branch(ka, kb, mus, tau0, xi)
    ok = branch["ok_mask"] if branch is not None else np.zeros_like(xi, dtype=bool)
    om6 = branch["om"][ok][-1] if np.any(ok) else float("nan")
    route = "direct rank-1" if (len(roots) >= 2 or mus < 1e-12 or seed_ratio > 0.25) else "delayed rank-2 onset"
    print(f"mus={mus:5g}: seed_roots={len(roots)}, seed_Omega/xi={seed_ratio:.4f}, "
          f"route={route}, onset={onset:.6f}, Omega(6)={om6:.6f}")


if __name__ == "__main__":
    print("Current physical-branch routing check")
    for value in (0.0, 0.2, 0.5, 0.7, 1.0, 2.0):
        report(5.0, 5.0, value, 0.0 if value else 0.0)
    report(5.0, 5.0, 1e-5, 0.0)
    print("Expected strong-surface onsets: mu_s*=0.7 -> approximately 0.1834; "
          "1.0 -> approximately 0.3465; 2.0 -> approximately 0.6133")
