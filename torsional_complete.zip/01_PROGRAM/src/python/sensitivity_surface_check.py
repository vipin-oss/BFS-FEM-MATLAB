#!/usr/bin/env python3
"""Generate deterministic sensitivity data and the surface-grid source array."""
from __future__ import annotations

import numpy as np

import core as C
import paths
from mode_shape_check import mode_shape
from oat import (KA0, KB0, MUS0, TAU00, XI_GRID, branch_metrics,
                 oat_matrix)


def main():
    print("=== (A) logarithmic one-at-a-time sensitivity (base case) ===")
    print("perturbations: a- = 0.5a, a+ = 2a; S = [ln Q(a+) - ln Q(a-)] / ln 4")
    print("responses: Omega(6), xi_on, vp(6), L(r_ref=1e-4 b), R_cb(6)")
    base, onset = branch_metrics(KA0, KB0, MUS0, TAU00)
    print("base:", base, "xi_on=", onset)
    S, raw = oat_matrix()
    for i, name in enumerate(("mu_s*", "ka*", "kb*")):
        print(f"{name}: low={raw[('mu_s' if i == 0 else 'k_a' if i == 1 else 'k_b')]['low']} ")
        print(f"       high={raw[('mu_s' if i == 0 else 'k_a' if i == 1 else 'k_b')]['high']}")
        print("       S=", np.array2string(S[i], precision=6))
    np.savez(paths.DATA_DIR / "oat_sensitivity.npz", S=S,
             response_names=np.array(["Omega(6)", "xi_on", "vp(6)", "L(6)", "R_cb(6)"]),
             responses=np.array([[raw[k]["low"], raw[k]["high"]]
                                 for k in ("mu_s", "k_a", "k_b")]))

    print("\n=== (B) Omega(xi, mu_s*) surface grid ===")
    G_grid = np.linspace(0.0, 2.0, 21)
    XI_S = np.linspace(0.05, 6.0, 31)
    Z = np.full((len(G_grid), len(XI_S)), np.nan)
    for i, G in enumerate(G_grid):
        tracked, onset = C.track_physical_branch(KA0, KB0, G, 0.0, XI_GRID)
        if tracked is None:
            continue
        ok = tracked["ok_mask"]
        if np.any(ok):
            Z[i] = np.interp(XI_S, tracked["xi"][ok], tracked["om"][ok])
            Z[i, XI_S < tracked["xi"][ok][0] - 1e-9] = np.nan
    np.savez(paths.DATA_DIR / "omega_grid.npz", Omega=Z, G=G_grid, xi=XI_S)
    for G in (0.0, 0.2, 0.5, 1.0, 2.0):
        i = int(np.argmin(abs(G_grid - G)))
        print(f"  G={G:4.2f}: Omega(6)={Z[i, -1]:.6f}")
    print("saved", paths.DATA_DIR / "omega_grid.npz")

    print("\n=== (C) field-panel roots and amplitudes ===")
    tracked, _ = C.track_physical_branch(KA0, KB0, MUS0, TAU00, XI_GRID)
    ok = tracked["ok_mask"]
    for target_xi, label in ((0.507692, "panel a"), (5.005017, "panel b")):
        i = int(np.argmin(abs(tracked["xi"][ok] - target_xi)))
        xi = float(tracked["xi"][ok][i]); om = float(tracked["om"][ok][i])
        ms = mode_shape(xi, om, KA0, KB0, MUS0, TAU00)
        print(f"{label}: xi={xi:.9f}, Omega={om:.9f}, |u|max={ms['diag']['umax']:.6e}")

    print("sensitivity data generation complete")


if __name__ == "__main__":
    main()
