#!/usr/bin/env python3
"""Promote generated PNGs to the manuscript and final-output copies."""
from __future__ import annotations

import hashlib
import os
import shutil
from pathlib import Path
import paths

ROOT = Path(__file__).resolve().parents[3]
SOURCE = Path(os.environ.get("TORSIONAL_SYNC_SOURCE", str(paths.OUT_DIR))).resolve()
TARGETS = [ROOT / "02_OVERLEAF" / "figures",
           ROOT / "08_FINAL_OUTPUTS" / "final_figures"]
NAMES = sorted(p.name for p in SOURCE.glob("fig_*.png")) + ["model.png"]

def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def sync() -> None:
    if len(NAMES) != 15:
        raise RuntimeError(f"expected 15 PNG assets, found {len(NAMES)} in {SOURCE}")
    missing = [name for name in NAMES if not (SOURCE / name).exists()]
    if missing:
        raise FileNotFoundError("missing generated assets: " + ", ".join(missing))
    for target in TARGETS:
        target.mkdir(parents=True, exist_ok=True)
        for name in NAMES:
            shutil.copy2(SOURCE / name, target / name)
    for target in TARGETS:
        for name in NAMES:
            if digest(SOURCE / name) != digest(target / name):
                raise RuntimeError(f"asset mismatch after synchronization: {target/name}")
    print(f"synchronized {len(NAMES)} assets to {len(TARGETS)} targets")

if __name__ == "__main__":
    sync()
