#!/usr/bin/env python3
"""Small deterministic smoke test for the relocated Python solver."""
from __future__ import annotations
import sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "01_PROGRAM" / "src" / "python"))
import core

roots = core.find_roots_at_xi(6.0, 5.0, 5.0, 1e-5, 0.0)
assert roots, "no baseline root at xi=6"
omega = float(roots[0])
# This is a regression check against the reconciled source package, not
# a new scientific claim.  The tolerance is intentionally wider than
# the source solver tolerance to catch relocation/configuration errors.
assert abs(omega - 0.1629) < 3e-3, omega
M = core.Mmat(6.0, omega, 5.0, 5.0, 1e-5, 0.0)
assert M is not None and np.isfinite(M).all()
print(f"NUMERICAL_SMOKE_PASS omega_xi6={omega:.10f}")
