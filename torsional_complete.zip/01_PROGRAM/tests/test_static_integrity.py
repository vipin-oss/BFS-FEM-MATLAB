#!/usr/bin/env python3
"""Fast archive-local integrity test; no external network is used."""
from __future__ import annotations
import hashlib
import json
import re
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
tex = ROOT / "02_OVERLEAF" / "main.tex"
text = tex.read_text(encoding="utf-8")
refs = re.findall(r"\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}", text)
assert len(refs) == 15, f"expected 15 graphics references, found {len(refs)}"
for ref in refs:
    name = Path(ref).name
    assert (ROOT / "02_OVERLEAF" / "figures" / name).exists(), name
assert (ROOT / "02_OVERLEAF" / "references.bib").exists()
assert "\\bibliography{references}" in text
for data_name in ("oat_sensitivity.npz", "omega_grid.npz"):
    with np.load(ROOT / "03_DATA" / "generated" / data_name) as data:
        assert data.files, data_name
assert len(list((ROOT / "02_OVERLEAF" / "figures").glob("*.png"))) == 15
forbidden = ["/" + "home" + "/user/", "/" + "Users" + "/", "C:" + "\\"]
workflow_files = list((ROOT / "01_PROGRAM").rglob("*.py")) + list((ROOT / "02_OVERLEAF").rglob("*.sh"))
for path in workflow_files:
    body = path.read_text(encoding="utf-8", errors="ignore")
    assert not any(token in body for token in forbidden), path
print("STATIC_INTEGRITY_PASS")
