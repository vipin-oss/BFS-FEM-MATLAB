# Archive utilities

The path and synchronization utilities used by the Python workflow are
authoritative in `01_PROGRAM/src/python/paths.py` and
`01_PROGRAM/src/python/sync_outputs.py`.  This directory is reserved
for archive-level helpers; no untracked helper or temporary patch is
required by the final workflow.
