# Authoritative manuscript source

`main.tex` is the reconciled manuscript source packaged for an
independent LaTeX working directory.  `references.bib`, the Springer
class, bibliography styles, and all 15 referenced PNG assets are
included locally.  The only source edits made for this archive are
non-scientific path normalizations: the bibliography basename is
`references`, and `\graphicspath{{figures/}}` points to the packaged
figure directory.  No manuscript PDF or `.bbl` is included because no
LaTeX toolchain was available during package construction.

`compile.sh` is the exact local compilation entry point.  It exits with
an explicit NOT AVAILABLE status when `pdflatex` or `bibtex` is absent;
the archive does not contain a stale or hand-generated PDF.
