#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v pdflatex >/dev/null 2>&1; then
  echo "NOT AVAILABLE: pdflatex is not installed on PATH" >&2
  exit 2
fi
if ! command -v bibtex >/dev/null 2>&1; then
  echo "NOT AVAILABLE: bibtex is not installed on PATH" >&2
  exit 2
fi
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
echo "LATEX_COMPILE_PASS: main.pdf"
