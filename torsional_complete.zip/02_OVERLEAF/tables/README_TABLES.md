# Manuscript table assets

The manuscript's tables are authored inline in `main.tex`; no external
table include is required for compilation.  Machine-readable audit
tables derived from the same authoritative source are in
`08_FINAL_OUTPUTS/final_tables/` and are not hidden compilation
dependencies.
