# Generated numerical data

`omega_grid.npz` contains the generated frequency/grid arrays used by
the field/figure workflow.  `oat_sensitivity.npz` contains the 3-by-5
one-at-a-time sensitivity matrix `S`, response names, and low/high raw
responses for the five responses including `R_cb`.  File
hashes and key dictionaries are recorded in `03_DATA/metadata/` and
`09_ARCHIVE_METADATA/SHA256SUMS.txt`.
