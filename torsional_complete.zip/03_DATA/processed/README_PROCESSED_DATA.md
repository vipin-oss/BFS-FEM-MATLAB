# Processed-data status

No separate processed-data files were supplied.  The two NPZ files in
`generated/` are the supplied generated arrays used by the Python and
figure workflow.
