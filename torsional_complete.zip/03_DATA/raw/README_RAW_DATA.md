# Raw-data status

No experimental/raw-data files were present in the supplied project
inventory.  The package contains analytical-model outputs and a
reconstructed published benchmark table, not raw measurements.
