# Reproduction record

This section separates executable workflow instructions from supplied
evidence.  `source_*.log` files are historical logs from the supplied
project; `run_all_python.log` is created by the archive-local runner.
Numerical acceptance facts are recorded in `expected_outputs/` and in
`06_VALIDATION/validation_results/`.  No result is claimed for a tool
that was unavailable during this package build.
