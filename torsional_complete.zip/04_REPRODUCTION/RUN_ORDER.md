# Reproduction order

1. Install the Python dependencies listed in
   `01_PROGRAM/requirements.txt` in an isolated environment.
2. From the archive root run `python 01_PROGRAM/tests/test_static_integrity.py`.
3. Run `python 01_PROGRAM/tests/test_numerical_regression.py`.
4. Run `python 01_PROGRAM/run_all.py`.  It generates the benchmark and
   manuscript figures, both NPZ datasets, the journal previews,
   synchronizes all 15 PNGs, and records a log in
   `04_REPRODUCTION/verification/run_all_python.log`.
5. Optional focused checks are available in
   `01_PROGRAM/scripts/python/`; they are not silently run by the
   default workflow.
6. For MATLAB, add `01_PROGRAM/src/matlab` to the path and run
   `01_PROGRAM/run_all.m` in MATLAB or a compatible Octave release.
   MATLAB/Octave was not available during archive construction, so
   this step is documented but not marked passed.
7. From `02_OVERLEAF/` run `./compile.sh` when `pdflatex` and `bibtex`
   are installed.  No PDF is pre-generated in this archive.
