# Runner entry points

Python: `01_PROGRAM/run_all.py`.

MATLAB: `01_PROGRAM/run_all.m`.

LaTeX: `02_OVERLEAF/compile.sh`.

The archive-local runners use relative paths only and do not depend on
the historical source-package location.
