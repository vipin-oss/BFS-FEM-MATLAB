# Archive-local reproduction test

**Status: PASS for the Python path tested on 2026-09-28.**

The staged archive tree was executed independently of the historical
source layout with:

* `python 01_PROGRAM/tests/test_static_integrity.py` — PASS.
* `python 01_PROGRAM/tests/test_numerical_regression.py` — PASS,
  `omega_xi6=0.1629112443`.
* `python 01_PROGRAM/run_all.py` — exit code 0.  The run generated the
  benchmark, validation, journal, sensitivity, geometry, localization,
  field, and sensing assets; regenerated both NPZ datasets; and passed
  the 15-asset synchronization check.
* The regenerated PNG SHA-256 values matched the supplied synchronized
  PNG set byte-for-byte.

This is an isolated Python reproduction result, not a MATLAB/Octave or
LaTeX result.  Those tools were unavailable and remain NOT RUN.
