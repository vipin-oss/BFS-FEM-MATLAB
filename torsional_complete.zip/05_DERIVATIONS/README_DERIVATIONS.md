# Derivation record

The manuscript in `02_OVERLEAF/main.tex` remains the authoritative
scientific source.  The files below are line-addressable excerpts and
explanatory index records made from that source; they do not introduce
alternative equations.  Numerical implementation details are mirrored
in `01_PROGRAM/src/python/core.py` and
`01_PROGRAM/src/matlab/torsional_waveguide_core.m`.

The archive preserves the reconciled scope: conditional residual-
tension cancellation, explicit zero-tau-zero production baseline,
torsional-only thermoelastic decoupling, qualified onset/cutoff claims,
lossless Drude/ZGV/backward-wave scope, shell-face localization scope,
strong-coating and sensing limitations, normalized residual reporting,
and benchmark/planar-limit distinction.
