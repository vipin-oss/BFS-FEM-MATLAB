# Thermoelastic scope

The supplied manuscript states that, under the torsional-only kinematics
used here, the thermal field does not couple into the shear-wave
characteristic equation.  The numerical values of the thermal symbols
are not supplied; they are intentionally recorded as NOT DOCUMENTED in
`04_REPRODUCTION/manifests/parameter_manifest.json`.
