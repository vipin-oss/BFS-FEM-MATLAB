# Dimensionless variables

The exact definitions and scaling are in the source excerpt and
`main.tex`.  The Python and MATLAB implementations use the same
dimensionless groups and numerical settings; no independently guessed
scaling is added by the archive.
