# Numerical method

The solver evaluates the characteristic determinant/matrix with scaled
modified Bessel functions, brackets roots over a configured scan, and
tracks the selected physical branch by continuation.  The complete
implementation is in the packaged source; the excerpt is provided for
provenance, not as a second implementation.
