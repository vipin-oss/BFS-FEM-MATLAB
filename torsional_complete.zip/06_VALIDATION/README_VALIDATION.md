# Validation record

This section distinguishes supplied numerical evidence from checks
that could not be executed in the current environment.  Python source
and figure/data checks are executable through the archive-local
runners.  MATLAB/Octave and LaTeX are BLOCKED because the interpreters
were not available during construction.
