# Benchmark source

The benchmark is identified in the supplied script and bibliography as
Daniel A. Kiefer, Bor Plestenjak, Hauke Gravenkamp, and Claire Prada,
“Computing zero-group-velocity points in anisotropic elastic waveguides:
Globally and locally convergent methods,” *J. Acoust. Soc. Am.* 153,
1386–1398 (2023), DOI: 10.1121/10.0017252, for ZGV terminology and
method context.  The numerical Table 2 comparison used by the supplied
benchmark script is attributed there to Kiełczyński et al. (2025),
*Sensors* 25(1):143; the source paper itself is not included in this
archive.  Values are reproduced only as recorded in the supplied code
and log.
