# Validation summary

## Passed or supplied evidence

* The archive-local isolated Python reproduction test passed; see
  `04_REPRODUCTION/verification/archive_local_reproduction_test.md`.
* The reconciled Python regeneration and figure synchronization records
  are present in the source-package logs and can be rerun from the
  archive-local runner.
* Baseline normalized residuals are recorded as
  2.7513502071e-21 to 3.0073698624e-16; raw residuals as
  3.8484125561e-18 to 4.1785635184e-14.
* The 300/600 grid comparison is recorded as maximum 2.236e-6 and mean
  2.277e-7.
* The benchmark record reports maximum relative deviations of 0.009%
  in wavenumber and 0.018% in phase velocity.
* The cylindrical cutoff is 145.024330 kHz; the welded planar value is
  retained as a separately labelled reference, not asserted as the
  finite-spring limit.
* The shell endpoint audit records zero interior shell local maxima and
  a side transition near xi approximately 1.5027.

## Not passed / blocked

* MATLAB/Octave execution: BLOCKED, interpreter not available.
* LaTeX compilation: BLOCKED, `pdflatex`/`bibtex` not available.
* Compiled manuscript PDF and `.bbl`: NOT AVAILABLE.
* Raw experimental data and separate supplementary source/PDF: NOT
  AVAILABLE in the supplied inventory.

These statements are package status records, not claims that the
unavailable tools were run.
