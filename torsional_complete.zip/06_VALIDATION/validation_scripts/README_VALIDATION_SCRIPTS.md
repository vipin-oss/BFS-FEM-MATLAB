# Validation entry points

`run_python_validation.py` runs the fast static and numerical smoke
tests.  Full figure/data regeneration is `01_PROGRAM/run_all.py`.
The original focused validation scripts remain under
`01_PROGRAM/scripts/python/`.
