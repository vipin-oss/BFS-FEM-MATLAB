#!/usr/bin/env python3
"""Run fast archive-local validation checks."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
for rel in [
    '01_PROGRAM/tests/test_static_integrity.py',
    '01_PROGRAM/tests/test_numerical_regression.py',
]:
    subprocess.run([sys.executable, str(root / rel)], cwd=root, check=True)
print('PYTHON_VALIDATION_PASS')
