# Archive changelog

* 2026-09-28 — Created the structured long-term archive from the
  reconciled manuscript, synchronized figures, Python/MATLAB source,
  generated NPZ data, configuration, and supplied validation logs.
* 2026-09-28 — Added archive-local relative-path runners, manifests,
  derivation excerpts, data/figure dictionaries, and explicit status
  records.  No scientific parameter or result was added when the
  source record was unavailable.
