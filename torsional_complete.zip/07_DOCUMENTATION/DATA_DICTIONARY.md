# Data dictionary

* `omega_grid.npz`: keys `Omega`, `G`, and `xi`; generated frequency/grid
  arrays used by the field workflow.
* `oat_sensitivity.npz`: keys `S`, `response_names`, and `responses`;
  five-response one-at-a-time sensitivity data, including `R_cb`.
* `benchmark_table2_reconstructed.csv`: published and reproduced
  benchmark columns reconstructed from the supplied benchmark script
  and its log; not raw measurements.
* `oat_sensitivity_reconstructed.csv`: CSV view of the supplied NPZ
  sensitivity array.

NPZ hashes and file-level provenance are in the archive metadata.
