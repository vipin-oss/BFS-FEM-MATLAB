# Figure provenance

The 15 synchronized PNG assets are the 14 manuscript figures plus
`model.png`.  Figures 2–15 have Python and/or MATLAB generator paths
recorded by matching output names in `01_PROGRAM/src/python/` and
`01_PROGRAM/scripts/matlab/`; the Python run is the archive's tested
path.  `model.png` is supplied as an asset, but its original editable
source is NOT DOCUMENTED in the inventory.  The copies in
`02_OVERLEAF/figures/` and `08_FINAL_OUTPUTS/final_figures/` are
SHA-256 checked against the generated source set.
