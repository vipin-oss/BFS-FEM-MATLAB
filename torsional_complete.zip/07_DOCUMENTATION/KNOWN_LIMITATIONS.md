# Known limitations and unavailable items

* MATLAB/Octave execution was not possible in the build environment.
* `pdflatex` and `bibtex` were not available; no compiled manuscript
  PDF or `.bbl` is supplied.
* No separate supplementary source/PDF, raw experimental data, CSV
  environment lockfile, or standalone derivation source was present in
  the supplied inventory.  The archive records these as NOT AVAILABLE
  or NOT DOCUMENTED rather than manufacturing them.
* The Drude, ZGV, backward-wave, strong-coating, and sensing results
  retain the manuscript's lossless, hypothetical, scope and
  qualification language.
* The benchmark publication's source paper is cited by provenance but
  is not redistributed; the numerical comparison uses only the values
  already present in the supplied benchmark script/log.
