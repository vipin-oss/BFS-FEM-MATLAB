# Model description and scope

The characteristic system is a five-by-five interface/boundary matrix
built from modified Bessel functions for the torsional radial fields.
Interface stiffnesses, surface shear elasticity, shell geometry, and
the lossless frequency-dependent compliance are represented in the
dimensionless equations.  The manuscript's qualifications govern all
interpretation: torsional-only thermoelastic decoupling; conditional,
not universal, residual-tension cancellation; lossless Drude/ZGV/
backward-wave scope; shell-face localization only; and strong-coating
and sensing results as limitations/hypothetical parameter studies.
