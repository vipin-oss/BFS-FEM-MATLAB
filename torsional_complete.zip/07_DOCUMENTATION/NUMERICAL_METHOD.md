# Numerical method and conventions

Python and MATLAB use synchronized parameter conventions and numerical
settings.  The Python implementation uses scaled modified Bessel
functions, bracketed root searches, continuation windows, retry rules,
and explicit residual diagnostics.  The numerical settings JSON is the
primary configuration record.  The MATLAB core mirrors those settings
in its `numerical_settings` method; actual MATLAB execution is not
claimed in this archive status.
