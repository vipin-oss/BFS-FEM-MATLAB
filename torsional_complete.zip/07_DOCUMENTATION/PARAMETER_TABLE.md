# Parameter and provenance index

The complete machine-readable parameter record is
`04_REPRODUCTION/manifests/parameter_manifest.json`.  Numeric values
are transcribed from the supplied code/configuration.  Thermal
quantities K, C_v, tau, gamma_T, and T_0 have no supplied numerical
values and are explicitly marked NOT DOCUMENTED; no replacement values
are guessed.
