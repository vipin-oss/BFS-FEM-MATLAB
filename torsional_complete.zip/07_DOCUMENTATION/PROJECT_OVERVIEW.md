# Project overview

This package studies a torsional elastic waveguide with a core, host
medium, and lossless Drude-type shell/metamaterial representation,
finite interface springs, and a surface shear-elasticity term.  The
model is analytical/numerical rather than an experimental data package.
The baseline uses the explicit zero-residual-tension production setting
and reports the five-response OAT sensitivity, including R_cb.

The archive is self-contained for source inspection and Python
regeneration.  MATLAB/Octave and LaTeX remain optional external tools
and are statused separately rather than assumed.
