# Documentation index

This directory contains human-facing descriptions of the model,
numerical method, provenance, data dictionary, and limitations.  It
intentionally excludes private audit conversation and temporary patch
scripts.  The authoritative scientific text remains in
`02_OVERLEAF/main.tex`; executable source remains in `01_PROGRAM/`.
