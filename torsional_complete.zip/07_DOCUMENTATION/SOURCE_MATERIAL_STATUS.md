# Supplied-source status

Present: authoritative manuscript source, bibliography, Springer class
and bibliography styles, 15 PNG assets, 17 Python source files, 26
MATLAB source files, two NPZ datasets, numerical settings, dependency
constraints, and supplied check logs.

Absent: compiled PDF, `.bbl`, supplementary source/PDF, raw
experimental data, separate CSV/YAML environment lockfile, and
standalone derivation files.  These absences are preserved as status
facts throughout the package.
