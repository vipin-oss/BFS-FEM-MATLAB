# Final outputs

`final_figures/` contains the 15 synchronized PNG assets used by the
manuscript.  `final_tables/` contains documented machine-readable
views.  No manuscript PDF, `.bbl`, supplementary PDF, or experimental
data is included because those items were not available in the source
inventory.  See `FINAL_PACKAGE_STATUS.md` for the exact blockers.
