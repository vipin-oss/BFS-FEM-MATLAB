# Machine-readable final tables

These CSVs are audit views reconstructed from supplied manuscript/code/
log records.  They are not independent experimental data and do not
replace the inline tables in `02_OVERLEAF/main.tex`.
