# Count definitions

* Source-code files: `.py` and `.m` files under `01_PROGRAM/`, including
  archive launchers/tests.
* Data files: `.npz` and `.csv` files under `03_DATA/` and
  `08_FINAL_OUTPUTS/final_tables/`.
* Figure files: unique PNG asset names; synchronized copies are not
  counted as additional scientific figures.
* Manuscript/LaTeX files: `.tex`, `.bib`, `.cls`, and `.bst` files under
  `02_OVERLEAF/`.
* Validation files: all regular files under `06_VALIDATION/`.
