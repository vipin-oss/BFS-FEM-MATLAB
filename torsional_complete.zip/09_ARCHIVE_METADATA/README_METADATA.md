# Archive metadata

`archive_inventory.json` defines the root and provenance anchors.
`SHA256SUMS.txt` covers every regular file in the archive except the
SHA manifest itself; the exception is deliberate because a file cannot
contain its own final SHA-256 without a circular update.  The archive
ZIP is hashed separately in the delivery record outside the ZIP.
