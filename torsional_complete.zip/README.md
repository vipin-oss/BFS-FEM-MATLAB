# torsional_waveguide_COMPLETE_REPRODUCIBILITY_ARCHIVE

This is a self-contained long-term reproducibility archive for the
reconciled torsional-waveguide manuscript and its supplied numerical
source package.

## Required sections

* `01_PROGRAM` — Python/MATLAB source, archive-local runners, config,
  and tests.
* `02_OVERLEAF` — authoritative manuscript source, bibliography,
  styles, and synchronized figure assets.
* `03_DATA` — generated NPZ data, validation CSV views, and data status.
* `04_REPRODUCTION` — commands, manifests, expected results, and logs.
* `05_DERIVATIONS` — exact manuscript derivation excerpts and index.
* `06_VALIDATION` — validation evidence, figures, citations, and
  unavailable-tool records.
* `07_DOCUMENTATION` — model, method, provenance, dictionary, and
  limitations.
* `08_FINAL_OUTPUTS` — final figure/table views and explicit unavailable
  output placeholders.
* `09_ARCHIVE_METADATA` — inventory, status, hashes, and package facts.

Start with `FINAL_PACKAGE_STATUS.md`, then `07_DOCUMENTATION/`, and
execute the Python smoke tests before running the full workflow.  All
important files are covered by SHA-256 records in
`09_ARCHIVE_METADATA/SHA256SUMS.txt`; the hash manifest documents its
own coverage boundary to avoid a self-referential hash.
