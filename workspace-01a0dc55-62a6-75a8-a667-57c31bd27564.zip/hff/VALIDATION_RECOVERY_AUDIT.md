# VALIDATION_RECOVERY_AUDIT.md — External-Validation Route Audit & Benchmark Candidate Assessment
### MGT Thermoelasticity C¹ BFS-FEM · Post-V3 (post-failure) · AUDIT ONLY — no production runs, no V3 re-run, no target/metric/criterion change, no Blueprint modification, no V5/V6 execution

**Date:** 2026-09-26 (UTC) · **Trigger:** V3 (Nikolarakis overlay) FAILED 0/12 against the frozen provisional ≤2% criterion; failure independently audited — execution/metric/target provenance found VALID. Owner directive: validation is mandatory; the benchmark is NOT fixed to Nikolarakis ("kisi bhi relevant SCI paper se validate kar sakte ho"); validation recovery is the priority, not mechanical phase continuation.

**Protected (verified untouched this turn):** `Blueprint_Complete_MGT_BFS-FEM.md`, `BLUEPRINT_FREEZE_RECORD.md`, all `verification/V3/*` targets/results/manifests, `PHASE1_*` records.

---

## 1. SCOPE OF THIS AUDIT (what was / was not done)

**Done:**
1. Full re-read of the frozen Blueprint (all four parts) and all validation-related Phase-1 records (source lock, execution baseline, derivation record R2, V3 report + V3 results/manifest, G1 audits R1/R2).
2. Determination of the exact external-validation route required by the frozen Blueprint (Section 2 below).
3. Inventory of every *already-authorized* external benchmark in the frozen corpus (Section 3).
4. Focused literature/source search for candidate published benchmarks for the MGT/thermoelastic FEM problem (Section 4), selected strictly on reproducibility + scientific suitability (never on expected agreement).
5. Model-identity analysis: is each candidate the *same model* as the Blueprint's? (Section 5 — decisive finding).
6. Symbolic (SymPy) transcription check of the strongest candidate's exact solution against its printed PDEs/BCs/ICs — **VERIFIED, residual = 0** (this is a transcription check, not a validation run).

**Not done (per directive):** no production FEM run; no V3 re-run; no metric/target/criterion/tolerance change; no V5/V6 or downstream phase invocation; no Blueprint modification (amendment proposed in Section 8, NOT applied); no claim of validation anywhere in this document.

---

## 2. EXACT EXTERNAL-VALIDATION ROUTE REQUIRED BY THE FROZEN BLUEPRINT

**Q: What does the frozen Blueprint require for external validation? Is Nikolarakis the *only* authorized external benchmark, or merely the first?**

### 2.1 The frozen requirement (verbatim sources)

| Frozen location | Content |
|---|---|
| Part I **K.1** | **Primary benchmark** = Lord–Shulman thermal shock of a homogeneous layer; source = Nikolarakis & Theotokoglou (2018), DOI 10.1155/2018/7371016 (OA); "a single open paper chains two independent published datasets" (own FEM curves + Bagri [26] overlay). |
| Part I **K.2** | Classical-limit (CTE) benchmark — **OPTIONAL**, "additional, non-load-bearing": Sternberg & Chakravorty (1959) / Boley & Tolins (1962), "may be added **only if lawfully obtained** (ASME paywalled)". |
| Part I **K.3** | Model-reduction ping-points (symbolic) + "**Independent 1-D cross-check against Bazarra et al. (2022) MGT FEM (linear elements) — same parameters, compare fields at fixed station; if only figures are available, digitize and label the comparison accordingly (K.11)**". |
| Part I **K.13** | "**External validation (A):** only the *published* benchmark reproduction (K.1/V3), **plus any *independent published* source actually obtained (K.2/K.3 optional)**. Additional external parameter points are added **only when a published target exists** — no published target is ever invented or inferred." |
| Part I **§T · G3 (hard gate)** | "external validation **V3 (Nikolarakis benchmark, 12 comparisons, ≤ provisional 2%)** + internal cross-validation V5 (C⁰ reference, ≤ provisional 1%) + model-reduction identity V6 — provisional tolerances fixed in Phase 1–3 (K.11); **without G3 the paper is not submitted.**" |
| Part I **§T (package)** | "mandatory = **V1, V2, V3, V5, V6**; V4 is supporting"; "V4, V7, V7b, V8, V9, V10 feed G3/G4 only as their sources/conditions are met; **no optional item is a submission gate**." |
| Part II §2 | Source-by-source audit: S1 Nikolarakis = AVAILABLE (primary); S2 Bagri 2006 = PARTIALLY AVAILABLE (paywalled; same IBVP transcribed via S1); S3 Boley–Tolins 1962 = OPEN (paywalled; optional, not on critical path); S4 Quintanilla 2019 = PARTIALLY AVAILABLE (model definition, no benchmark data); S6 Bazarra ZAMM 2024 = model law only; S7 Bazarra JCAM "2022, 409:114181" = "**used for gap documentation only**" (metadata only, paywalled at the time). |
| Part III §3 (ladder) | L2 (LS benchmark vs two published datasets) = "A — mandatory publication validation"; L4 (Nikolarakis+Bagri overlay) = "A — mandatory publication validation"; L6 (Boley–Tolins) = "D — optional"; **L7 (Bazarra 2022 1-D MGT FEM cross-check) = "C — useful supporting … only if its figures/data are lawfully obtained"**. |
| Part III §5 (V-table) | **V3** = "LS benchmark vs Nikolarakis FEM overlay — **mandatory (G3)**"; **V4** = digitized Bagri series — supporting; **V8** = Boley–Tolins overlay — "Optional (D), only if lawfully obtained"; **V9** = "**Bazarra 2022 1-D MGT cross-check — only if figures/data in hand — selected field comparisons — ≤5% (digitized) — Optional (C)**". |
| Part III §6 (stop conditions) | #5: "V3 vs. Nikolarakis exceeds the tolerance fixed in Phase 3 from measured convergence … **after convergence is established and the published resolution verified; the failure is reported, not masked**." |
| Freeze record §5 | "No validation results have been obtained" (at freeze); tolerances PROVISIONAL — "to be fixed from measured convergence/error characterization" in Phases 1–3. |

### 2.2 Answer

1. **The frozen Blueprint's mandatory external-validation component of G3 is exactly one item: V3 = the Nikolarakis LS benchmark (12 comparisons, provisional ≤2% rel L∞),** paired with the *internal* items V5 (C⁰ cross-validation) and V6 (MGT→LS identity). "Without G3 the paper is not submitted."
2. **Nikolarakis is therefore the only *mandatory* authorized external benchmark** — not merely "the first". The other authorized external sources are explicitly **optional and non-gating**:
   - **V8 / K.2** = Boley–Tolins (1962) CTE half-space — optional, CTE-limit only, "only if lawfully obtained" (ASME paywalled; no lawful copy exists — see Part II §2 Source 3, which records that a shadow-library copy exists but is *excluded on provenance grounds*).
   - **V9 / K.3 / L7** = "Bazarra et al. (2022) MGT FEM cross-check" — optional, class C "useful supporting", "only if figures/data in hand". **(This citation is defective — see Section 5.3.)**
   - **V4** = digitized Bagri "[26]" series — supporting/corroborative, *same IBVP* as V3 (not an independent problem; original paywalled).
3. **K.13 is the only clause that admits "any independent published source actually obtained"** into the external-validation class — but it attaches to the same discipline: "Additional external parameter points are added only when a published target exists — no published target is ever invented or inferred." Any new benchmark therefore enters via an explicit amendment + source lock, under the same no-invention discipline.
4. **Consequence:** under the *frozen* text, G3's external slot is name-locked to V3 (Nikolarakis). V3 has been executed and failed (0/12) and is closed by owner directive (no re-run, no metric change, no target modification, no criterion relaxation). The frozen Blueprint provides **no** alternative that can close G3 as written → the route question is exactly what this audit decides (Sections 3–8).

### 2.3 V3 failure status (recorded, not re-litigated)

Per `PHASE1_V3_REPORT.md` (2026-09-26) and the independent audit of the failure (execution/metric/target provenance = VALID):
- Gate result: **0/12 ≤ 2% (provisional)** → V3 FAIL, "reported, not masked".
- Diagnosed causes (all three *structure-level*, none a model/implementation error): (i) pointwise-L∞ signature at a *true propagating discontinuity* — the two schemes (ours: converged C¹ Gibbs shoulder; theirs: 1000-elem linear, CFL≈1 Newmark undershoot) carry different dispersive signatures in the front band, which no independent code can be expected to reproduce pointwise (a same-resolution control run also does not reproduce the published front zone: 2.05–46%); (ii) sub-pixel extraction baseline offsets (dominant for ũ, whose peaks are O(0.1)); (iii) singular corner-node σ oscillation at the incompatible traction-free corner.
- Physics-level agreement *within* the failure: front positions ≤3.2e-3; jump amplitudes 0.0002 (θ̃@0.25) / 0.5% (σ̃ spike); θ̃ smooth-decay 1.0–1.4%; ũ peaks 0.5–1.8%; both wavefronts cross x̃=1 at t̃=1.
- **This audit does not change any of the above, and no part of this audit re-opens it.** It is listed here only because the recovery route must be defined *relative* to this frozen fact.

---

## 3. INVENTORY OF ALREADY-AUTHORIZED EXTERNAL BENCHMARKS (from the frozen corpus)

| # | Authorized item | Status (frozen) | Complete IBVP? | Parameters? | BC/IC? | Quantitative reference data? | Independently reproducible? | Usable now? |
|---|---|---|---|---|---|---|---|---|
| A1 | **Nikolarakis 2018, §4.1 (V3)** — LS layer thermal shock | MANDATORY (G3) | YES (printed Eq. 11 + BCs/ICs) | YES (ξ=0.05, t̃₀=1, c̃E=c̃K=1, L̃=1) | YES | **Figures only** (Figs 2–4) → digitized targets (±3–5% class; measured ±0.0025 x̃ / ±0.0084–0.0161 ỹ) | YES (any code) — and WAS executed | **EXECUTED — FAILED 0/12; closed by owner directive** |
| A2 | Bagri et al. 2006 (V4) — same LS layer IBVP | Supporting | Only via verbatim transcription in A1 | YES (via A1) | YES (via A1) | Original figures NOT obtained (paywalled); the "[26]" series survives only *inside* A1's figures | NO without original; and **not an independent problem** (same IBVP) | NO (paywall + non-independence) |
| A3 | Boley & Tolins 1962 (V8/K.2) — CTE half-space | Optional | NO (abstract-level only; paywalled) | NO (unobtainable) | NO (unobtainable) | Unknown (no figures in hand) | Unknown | NO (not lawfully obtainable; CTE-limit only in any case) |
| A4 | "Bazarra et al. (2022) JCAM 409:114181" (V9/K.3/L7) | Optional (class C) | — | — | — | — | — | **CITATION DEFECT — see Section 5.3** |
| A5 | Quintanilla 2019 (S4) | Model definition (NOT a benchmark) | n/a (no benchmark data in source) | n/a | n/a | none | n/a | n/a |
| A6 | Bazarra et al. ZAMM 2024 (S6) | Model law (NOT a benchmark) | n/a (rigid-body heat law; simulations = discrete-energy decay only, no field data, no exact solution) | n/a | n/a | none usable | n/a | n/a |

**Inventory conclusion:** the only *already-authorized, actually-obtainable* external benchmark is A1 (Nikolarakis) — which has been executed and failed and is closed. A4 is the only other authorized item with any prospect of quantitative data, but its citation is defective and — decisively — the real source turns out to be a **different model** (Section 5). A3 is not lawfully obtainable. **No already-authorized benchmark can currently be used to close the mandatory external gate.**

---

## 4. FOCUSED LITERATURE SEARCH — CANDIDATE BENCHMARKS (selection basis: reproducibility + scientific suitability; never expected agreement)

**Searches performed (2026-09-26):** (i) Crossref metadata resolution for every Bazarra/Quintanilla JCAM/ZAMM IJCM paper + the Blueprint-cited DOI; (ii) full-text retrieval of the open Bazarra 2021 JCAM paper (10 chunks); (iii) targeted searches: LS/GN-III/CTE transient FEM with published numerical data (time-domain), Eiras/Oteo/Quintanilla FEM for LS/Cattaneo/MGT, "MGT finite element manufactured solution", Boley–Tolins lawful access, OA LS thermal-shock papers (MDPI/PLOS/Springer/T&F), acoustic-MGT FEM benchmarks. Findings below; negative results are recorded as findings, not gaps.

### 4.1 CANDIDATE C1 — Nikolarakis & Theotokoglou (2018) LS layer (same as A1)
Already executed; failed; closed. (No re-assessment per directive.)

### 4.2 CANDIDATE C2 — Bagri, Taheri, Eslami & Fariborz (2006), *J. Thermal Stresses* 29:359–370
- **Model:** unified generalized (LS/GL/GN) thermoelasticity of a layer, Laplace-domain + numerical inversion; the LS specialization = the A1 benchmark IBVP.
- **Assessment:** paywalled (no lawful OA copy found); **same IBVP as A1** (not an independent problem); its only data series is what A1 already carries as the "[26]" overlay (V4, supporting).
- **Verdict: REJECTED** (paywall + non-independence). Contributes nothing new to recovery.

### 4.3 CANDIDATE C3 — Boley & Tolins (1962), *J. Appl. Mech.* 29:637–646
- **Model:** classical coupled (Fourier) thermoelasticity — CTE half-space, step surface temperature, "for program testing".
- **Assessment:** ASME paywalled; the frozen corpus explicitly excludes the shadow-library copy on provenance grounds; even if obtained, it validates only the **CTE limit** (τ̂→0, κ̂→0) of our model — not the LS/MGT region the paper is about.
- **Verdict: REJECTED** (unobtainable + wrong part of the model ladder for the primary gate). Remains the optional V8 exactly as frozen.

### 4.4 CANDIDATE C4 — ⭐ Bazarra, Fernández & Quintanilla (2021), "Analysis of a Moore–Gibson–Thompson thermoelastic problem", *J. Comput. Appl. Math.* **382**:113058, DOI 10.1016/j.cam.2020.113058 — **Example 1D-1 ("Problem P1D")**

**Access:** full text retrieved 2026-09-26 from ScienceDirect (PII S0377042720303496) — **OPEN ARCHIVE** (banner + Crossref "vor" license start 2025-01-15). Lawful, no paywall. (Direct PDF bot-wall observed; HTML full text complete; owner should archive an OA copy into `src_audit/` with SHA at adoption time.)

**Exact model (Problem P, 1-D, as printed in the paper, Eq. (8) + Remark 3 + §4.2):**
```
Momentum:   ρ ü = (λ+2μ) u_xx − β (θ̇ + τ θ̈)_x
Energy:     c θ̈ + c τ θ⃛ = −β u̇_x + K1 θ̇_xx + K2 θ_xx        [numerical-section naming, see §5.3]
```
i.e. the **Quintanilla (2019) school MGT thermoelasticity**: the thermal variable θ is a *technical transform* (paper Remark 1), the momentum couples to (θ̇+τθ̈), and the third-order thermal equation carries a rate channel (θ̇_xx) plus a thermal-displacement channel (θ_xx). (Full model-identity analysis vs the Blueprint's model: Section 5 — **different model**.)

**Problem P1D (the benchmark instance) — COMPLETE, as printed:**
- **Governing equations (printed, with sources):**
  ```
  ü  = 2 u_xx − (θ̇_x + 2 θ̈_x) + F1        in (0,1)×(0,1)
  θ̈ + 2 θ⃛ = −u̇_x + 3 θ̇_xx + θ_xx + F2    in (0,1)×(0,1)
  ```
- **Parameters (printed):** Ω=(0,1), T=1, ρ=1, μ=2 (PDE fixes λ+2μ=2 ⇒ λ=−2, 1-D-only use — documented), β=1, τ=2, c=1, K1=3, K2=1. **Complete.**
- **BCs (printed):** u(0,t)=θ(0,t)=0 for t∈[0,1] (and the same at x=1 — homogeneous Dirichlet on both fields at both ends; matches the printed exact solution's zeros).
- **ICs (printed):** u0(x)=v0(x)=x(x−1); θ0(x)=e0(x)=ξ0(x)=x³(x−1), for x∈(0,1).
- **Body forces (printed):**
  ```
  F1(x,t) = e^t ( x(x−1) − 4 + 3(4x³−3x²) )
  F2(x,t) = e^t ( 3x³(x−1) + (2x−1) − 4(12x²−6x) )
  ```
- **Reference data — TWO independent, machine-usable forms:**
  1. **ANALYTIC EXACT SOLUTION (printed):** `u(x,t) = e^t x(x−1)`, `θ(x,t) = e(x,t) = ξ(x,t) = e^t x³(x−1)`. → **No digitization at all; zero extraction uncertainty.**
  2. **PUBLISHED TABLE (Table 1, machine-readable, 6 significant digits):** numerical errors `max_n {‖v−v_hk‖_Y + ‖(u−u_hk)_x‖_Y + ‖ξ−ξ_hk‖_Y + ‖(e−e_hk)_x‖_Y + ‖(θ−θ_hk)_x‖_Y}` for an 11×7 grid (h = 1/2³ … 1/2¹³, k = 1e-2 … 1e-4) from *their* P1-FEM/backward-Euler scheme — a published numerical experiment with tabulated outcomes, independently re-runnable (their §4.1 prints the full discrete scheme).
- **Method fully printed:** P1 Lagrange spaces, backward Euler, discrete scheme (4.1), MATLAB; "a typical 1D run (h=k=0.001) took about 0.92 s" — seconds-to-minutes here.
- **Transcription check (executed this audit, SymPy):** the printed exact solution satisfies both printed PDEs **with residual exactly 0**, all 4 BC values, all 6 IC values (u0=v0=x(x−1); θ0=e0=ξ0=x³(x−1)), and both printed forces follow identically. → The benchmark is internally consistent and fully determined. **[VERIFIED — transcription only, not a validation run.]**

**Per-candidate report (task item 6):**
| Field | Assessment |
|---|---|
| Source | Bazarra, Fernández, Quintanilla (2021), JCAM 382:113058, DOI 10.1016/j.cam.2020.113058, OA open archive (retrieved 2026-09-26) |
| Exact model | Quintanilla-2019-school MGT thermoelasticity (1-D): **NOT identical to the Blueprint's model** (Section 5 proof) |
| Governing equations | Complete (printed P1D pair + full Problem P + weak form + discrete scheme) |
| BC/IC completeness | Complete (homogeneous Dirichlet both fields/both ends; all 6 IC functions printed) |
| Parameter completeness | Complete (ρ, μ, β, τ, c, K1, K2, Ω, T all printed; λ fixed by PDE in 1-D — documented) |
| Reference-data availability | **Best available: analytic exact solution (printed) + published 6-digit error table** — no digitization needed |
| Independent reproduction realistically possible? | **YES** — the IBVP is fully re-solvable by any code; their own scheme is fully printable and re-runnable (Table 1 reproduction) |
| Satisfies the frozen validation requirement? | **Partially — see Section 5.** As *an external reproduction of a published quantitative benchmark*: yes (arguably stronger data than V3). As *validation of the Blueprint's exact model (G3's object)*: **NO, not by itself** — the model mismatch (Section 5) is a scientific-suitability limitation that the Blueprint must explicitly amend for (owner decision, Section 8). |

### 4.5 CANDIDATE C5 — Bazarra, Fernández & Quintanilla (2024), *ZAMM* 104:e202300531 (OA)
- **Model:** MGT heat conduction in a **rigid** (non-centrosymmetric) solid — **no thermoelastic coupling**; 1-D simulations = **discrete-energy decay only** (T=500/1000, k=1e-7, h=1e-3; no field data, no exact solution, no tabulated fields).
- **Verdict: REJECTED as a field benchmark** (rigid body; energy-decay figures only). Remains S6 (model-law source) exactly as frozen.

### 4.6 CANDIDATE C6 — Bazarra, Fernández, Liverani, Quintanilla (2024), *JCAM* **438**:115571 (OA since 2023-09-13)
- **Model:** MGT thermoelasticity **with microtemperatures** (two extra fields) — different model (extra micro-temperature physics); no indication of a manufactured-solution benchmark matching our fields.
- **Verdict: REJECTED** (different model; not needed if C4 is adopted).

### 4.7 CANDIDATE C7 — Bazarra, Fernández, Quintanilla (2025), *JCAM* 457:116317, "MGT type with history dependence in the thermal displacement"
- **Model:** MGT with **memory/history dependence** in the thermal displacement — different (non-Markov) model.
- **Verdict: REJECTED** (different model).

### 4.8 CANDIDATE C8 — Other LS / GN-III / CTE transient numerical works (systematic negative)
Searched: LS/GN-III/CTE 1-D transients (Eslami-school disks/layers/cracks; DQM+Newmark layer papers; Nowruzpour Mehrian FGM plates; Zamani–Hetnarski–Eslami 2011 cracked layer; Hosseini-Tehrani–Hosseini-Godarzi 2004 LS crack BEM; Eslami–Bagri 2009 book-chapter Galerkin FEM for CTE/LS disk/sphere/beam; nonlinear LS layers (GDQ–Newmark)).
- **Findings:** (i) essentially all are **Laplace-transform + numerical inversion** (not time-domain direct FEM) with **figures only**; (ii) mostly **different geometries** (disk, cylinder, sphere, plate, crack) — not the 1-D layer/bar of our code; (iii) mostly **paywalled** (T&F/ASME/Springer); (iv) several add effects (rotation, initial stress, nonlinearity, FG grading, cracks) → different problems; (v) Nikolarakis 2018's own introduction states it: *"Due to the absence of analytical results for the Lord-Shulman theory, the finite element code shall be verified based on known numerical data in the literature."* — i.e. **the LS state of the art has exactly one time-domain FEM benchmark with published data: A1 itself.**
- **Verdict: NO additional same-model (Biot/LS-family) time-domain benchmark with quantitative data exists in lawfully obtainable form.** (This negative is itself a recordable finding: the frozen V3 target set is the community-standard, and it is unique for our model.)

### 4.9 CANDIDATE C9 — Undamped-MGT-heat / MCV–GK hp-FEM / acoustic-MGT literature (e.g. Pellicer–Quintanilla 2023 *Acta Mech*; Springer 2024 two-field hp FEM for MCV/GK)
- **Model:** undamped heat channels (Cattaneo/MCV, GN-III/GK heat equations) — **no thermoelastic coupling**.
- **Verdict: REJECTED for the primary gate** (validates only the decoupled heat operator; our V1/V2 already verify that machinery; not external validation of the coupled model). Recorded for completeness.

### 4.10 Candidate summary

| ID | Source | Same model as Blueprint? | Obtainable (lawful)? | Quantitative data? | Independent problem? | Recovery role |
|---|---|---|---|---|---|---|
| C1 | Nikolarakis 2018 | YES (LS limit) | YES (held) | Figures→digitized | YES | **Executed, FAILED, closed** |
| C2 | Bagri 2006 | YES (same IBVP as C1) | NO (paywall) | via C1 only | **NO** (same IBVP) | Rejected |
| C3 | Boley–Tolins 1962 | CTE limit only | NO (paywall; provenance-excluded copy) | unknown | YES | Rejected (remains optional V8) |
| **C4** | **Bazarra 2021 JCAM P1D** | **NO — different MGT sub-model (proof: §5)** | **YES — OA open archive** | **Analytic exact solution + 6-digit table** | **YES (fully independent IBVP)** | **Strongest candidate — requires explicit amendment (decision B)** |
| C5 | Bazarra ZAMM 2024 | NO (rigid body) | YES (OA) | energy-decay figures only | — | Rejected |
| C6 | Bazarra JCAM 2024 438 | NO (microtemperatures) | YES (OA) | not assessed (unnecessary) | — | Rejected |
| C7 | Bazarra JCAM 2025 457 | NO (history dependence) | metadata only | not assessed | — | Rejected |
| C8 | LS/GN-III/CTE transient works | mixed (mostly same family) | mostly NO / figures only | figures only (transform methods) | mixed | Negative result recorded |
| C9 | undamped-MGT / MCV-GK hp | NO (undamped heat) | mixed | mixed | — | Rejected (internal-verification territory) |

---

## 5. DECISIVE FINDING — MODEL-IDENTITY ANALYSIS (why C4 is not "the same problem" as V3)

**Blueprint's model (frozen; derivation record R2 §3.1, dimensioned [D] form):**
```
Momentum:  ρ ü = (λ+2μ) u_xx − β θ_x
Energy:    τ(ρc θ̈ + T₀β ü_x) + (ρc θ̇ + T₀β u̇_x) = k θ_xx + k* ψ_xx ,  ψ̇ = θ
```
(θ = true temperature; LS limit κ̂→0 reproduces benchmark Eq. (11) coefficient-by-coefficient — G1 audit Chk-2; CTE limit τ̂→0,κ̂→0 = classical Biot CTE.)

**C4's model (Bazarra 2021, printed Eq. (8) + P1D):**
```
Momentum:  ρ ü = (λ+2μ) u_xx − β (θ̇ + τ θ̈)_x
Energy:    c θ̈ + c τ θ⃛ = −β u̇_x + K1 θ̇_xx + K2 θ_xx        (their θ = thermal-displacement-type transform, Remark 1)
```

**Proof of non-identity (three independent algebraic arguments; full working available on request):**
1. **Momentum structure:** the Blueprint couples stress to θ_x (temperature, 0th time-derivative). C4 couples to (θ̇+τθ̈)_x. Any local linear-in-time-derivatives change of variable θ_C4 = Σ aᵢ θ_t⁽ⁱ⁾ that maps one momentum to the other requires a₀θ_t = θ̇+τθ̈ (in true-temperature variables), which has no finite-order local solution (it is an integral/memory transform) — and no u-shift removes it either (the (λ+2μ)θ_t,xx term would survive).
2. **Thermal-equation structure in the same (true-temperature) variables:** Blueprint: τ(ρcθ̈_t + T₀βü_x) + (ρcθ̇_t + T₀βu̇_x) = kθ_t,xx + k*ψ_xx — **local**, second order in θ_t with the k* channel on the thermal displacement ψ. C4 (with θ_t := θ̇_C4+τθ̈_C4): cθ̇_t = −βu̇_x + K1 θ̇_C4,xx + K2 θ_C4,xx — **first order in θ_t with a memory (time-integral) RHS** in θ_t variables. A local second-order PDE in θ_t ≠ a first-order+memory PDE in θ_t.
3. **LS-limit test (decisive for the benchmark region):** C4's "LS case" (their §4.3: "K2=0 … the Lord–Shulman model") is **not** the Biot/Lord–Shulman (1967) equation: in true-temperature variables it still carries the memory kernel, and its momentum still couples to (θ̇+τθ̈). The classical LS equation t₀(θ̈+ξü_x)+(θ̇+ξu̇_x)=θ_xx (our Eq. (11)) is **not** a special case of C4's system. Conversely, C4's τ→0 limit is Green–Naghdi type III (their own statement), not CTE. The two "MGT" formulations share the CTE corner and the third-order-in-thermal-variable skeleton, but **differ in the thermoelastic coupling structure** (temperature-in-stress vs thermal-inertia-in-stress; source −T₀β(ü_x+τü̇_x)·… vs −βu̇_x).

**Consequence (scientific):** C4 is a genuine, fully-documented, peer-reviewed **MGT-thermoelasticity** benchmark — but of the **Quintanilla-2019 formulation**, not of the **Biot/LS-family formulation** that the Blueprint's model (and hence the paper's claims) instantiates. It validates the *MGT time-integration machinery* (τθ⃛+θ̈ handling, rate channel, 5-field first-order state form, C¹ Hermite on a smooth coupled problem) against an independent published problem with an exact solution — **but it is not, by itself, a same-model validation of the Blueprint's coupling.** A manuscript that presented C4 as "the" external validation of the LS-family MGT model would be scientifically mis-scoped; a reviewer fluent in this literature (the Quintanilla group is the most active) would flag it immediately. **This is exactly why it cannot be adopted silently — it requires the explicit, owner-approved amendment in Section 8, which must also fix the manuscript's model scope.**

### 5.3 The frozen V9/K.3/L7 citation is defective (factual finding, recorded — no change made)

The frozen corpus cites "Bazarra et al. (2022), *J. Comput. Appl. Math.* **409:114181**, DOI **10.1016/j.cam.2022.114181**". Crossref resolution (executed this audit): that DOI resolves to **"Fourier transforms and L2-stability of diffusion equations" (Kang & Kim, 2022)** — an unrelated paper. The actual MGT-thermoelastic FEM paper is **Bazarra, Fernández & Quintanilla (2021), JCAM 382:113058, DOI 10.1016/j.cam.2020.113058** (the one whose full text is retrieved and analyzed above; it is also cited under its correct identity throughout the citing literature). Additionally, the K.3 clause "same parameters, compare fields at fixed station" is **not executable as written** for C4: the parameter names overlap but the *meanings* differ (their K1=3 is the rate channel / their θ is the transform; our k is the temperature channel), and the coupling structures differ (Section 5). The frozen V9 was therefore only ever a "gap documentation" item (Part II §2 S7: "used for gap documentation only") — and its content was mis-cited. **No change is made here; the correction is part of the proposed amendment (Section 8).**

### 5.4 Naming-convention note for C4 (for the future source lock; recorded, not acted on)
In C4's **numerical section** the data list "K1=3, K2=1" pairs **K1 with the rate channel θ̇_xx** and **K2 with the displacement channel θ_xx** (as printed in the P1D PDEs); the **introduction's** Eq. (7) uses the opposite pairing (K2 with θ̇, K1 with θ). Both sections are self-consistent; §4.3's statements ("K2=0 ⇒ LS", "τ=0 ⇒ GN-III") confirm the numerical-section pairing. Any future transcription must use the **printed P1D PDEs verbatim** (as done in this audit) and record this convention note.

---

## 6. ANSWER TO TASK ITEM 2 (consolidated)

- The frozen Blueprint requires: **one mandatory external reproduction (V3 = Nikolarakis LS benchmark, 12 comparisons, provisional ≤2%) as part of hard gate G3, plus the internal V5 (C⁰ cross-validation) and V6 (MGT→LS identity); "without G3 the paper is not submitted".**
- Nikolarakis is the **only mandatory authorized external benchmark** (not "the first of several"). The only other authorized external sources are **optional and non-gating** (V8 Boley–Tolins — unobtainable, CTE-only; V9 "Bazarra" — mis-cited, different model, class C supporting; V4 Bagri — same IBVP, paywalled original, supporting).
- K.13's "any independent published source actually obtained" clause is the only entry point for a new benchmark — it requires an explicit amendment + source lock and carries the standing discipline "no published target is ever invented or inferred".

---

## 7. DECISION (task item: A / B / C)

### **DECISION: B — with an explicit C-overlay on the frozen primary gate.**

**B (primary):** A scientifically suitable NEW external benchmark exists — **C4: Bazarra, Fernández & Quintanilla (2021), JCAM 382:113058, Problem P1D** (OA open archive; fully printed IBVP; complete parameters/BCs/ICs; **analytic exact solution + published 6-digit error table**; fully re-runnable peer scheme; independently verified consistent this audit). It is *not* already usable in its authorized form (the frozen V9 slot is mis-cited, optional, class-C, and its "same parameters" clause is inexecutable as written), so its adoption **requires an explicit Blueprint amendment** — identified exactly in Section 8 and **NOT made** (per directive 8).

**C-overlay (on the frozen G3 as literally written):** for the *mandatory same-model* external gate exactly as frozen (V3 = Nikolarakis, our LS-family model, provisional ≤2%), **no reproducible external benchmark can currently be established**:
1. V3 (the unique same-model published time-domain benchmark — C8's negative result) has been executed and **failed 0/12** under the frozen provisional criterion, and is closed by owner directive (no re-run / no metric change / no target modification / no criterion relaxation).
2. The other authorized external anchors are not lawfully obtainable (Boley–Tolins; Bagri original) or non-independent (Bagri = same IBVP).
3. No other published time-domain benchmark with quantitative data for the Biot/LS-family MGT model exists in lawfully obtainable form (C8, documented negative).
→ The frozen primary gate therefore **cannot be closed by execution alone**; closing it is an **owner decision** among the paths in Section 8.4 (α/β/γ). That is the precise sense of the C-overlay: *not* "no benchmark exists at all" (C4 exists and is excellent for what it is), but "no *same-model* benchmark can currently satisfy the frozen gate".

**Why not A:** "An already-authorized benchmark can be used" is false — the only authorized benchmark with data (V3) is executed/closed; the only other authorized external items are unobtainable (V8) or defective+cross-model (V9, as analyzed).

**Honesty statement (task item 11):** no validation of the Blueprint's model has been claimed, obtained, or implied in this audit. C4 reproduces a *different* published MGT model's problem (with an exact solution); until the owner decides the model scope (Section 8.4 β-i/ii), C4's results can be labeled only as a **cross-model / peer-method external cross-check of the MGT time-integration machinery** — never as "validation of the MGT thermoelasticity" of the paper's model.

---

## 8. THE EXACT BLUEPRINT AMENDMENT REQUIRED (PROPOSED — NOT MADE — owner approval needed)

> Status: **proposal for the change record only.** Nothing in the frozen Blueprint, BLUEPRINT_FREEZE_RECORD, or any V3 artifact is touched. The amendment below is what the owner would ratify (or modify) in a new change record, per the freeze record's rule that "no further redesign, expansion, or reinterpretation … is permitted without a new change record".

**Amendment A1 (factual correction — required in any case):**
- **Where:** Part I K.3, Part II §2 (S7) & §8 item 6, Part III §3 (L7) & §5 (V9), `PHASE1_SOURCE_LOCK.md` S7.
- **Change:** "Bazarra et al. (2022), *J. Comput. Appl. Math.* 409:114181, DOI 10.1016/j.cam.2022.114181" → "Bazarra, Fernández & Quintanilla (2021), 'Analysis of a Moore–Gibson–Thompson thermoelastic problem', *J. Comput. Appl. Math.* **382**:113058, DOI **10.1016/j.cam.2020.113058** — open archive (full text lawfully retrieved 2026-09-26; OA copy to be archived in `src_audit/` with SHA256 at adoption)".
- **Record:** the frozen DOI resolves to an unrelated paper (Kang & Kim 2022, "Fourier transforms and L2-stability of diffusion equations") — a citation defect in the frozen source list, corrected here factually; no scientific content of the frozen document is altered by this item.

**Amendment A2 (source-lock content — required if C4 is adopted):**
- Add verified content of C4 to the source register (new S11): Problem P (Eq. (8)), Remark 3, §4.1 discrete scheme, §4.2 Problem P1D (PDEs, parameters ρ=1, μ=2, β=1, τ=2, c=1, K1=3, K2=1, Ω=(0,1), T=1, BCs, ICs, forces F1/F2, exact solution u=e^t x(x−1), θ=e^t x³(x−1), Table 1 grid and metric), with provenance (publisher OA URL, retrieval date 2026-09-26, page/eq/table identifiers, SHA256 of the archived copy) and the **naming-convention note (§5.4)** and the **λ=−2 (1-D-only) note (§4.4)**.

**Amendment A3 (scientific-scope decision — the owner's core call; this is the part that must be explicit):**
Record, with the Section-5 proof attached: *C4 is the Quintanilla-2019-formulation MGT thermoelasticity; the Blueprint's model is the Biot/LS-family (Nikolarakis-anchored) MGT; the two share the CTE corner and the third-order thermal skeleton but differ in the thermoelastic coupling structure (Section 5, arguments 1–3). The LS limit of C4 is not benchmark Eq. (11).* Then the owner chooses one of:
- **(β-i) Extended scope:** the paper's method is presented as a **unified C¹ FEM framework for both standard MGT-thermoelasticity formulations** (Biot/LS-family *and* Quintanilla-family), with the relation between them (CTE common corner; different LS corners) stated explicitly. → C4 (P1D) becomes a **primary external benchmark of the Quintanilla-formulation branch**, alongside V3 (Nikolarakis) as the primary external benchmark of the Biot/LS branch.
- **(β-ii) Scope retained:** the paper keeps the Biot/LS-family model only. → C4 is adopted as a **clearly-labeled cross-model external cross-check** (re-defined V9′, supporting tier): it validates the MGT time-integration machinery (τθ⃛+θ̈, rate channel, 5-field state form) against an independent published problem with an exact solution; it is *never* presented as validation of the paper's coupling, and G3's external slot remains V3 (subject to A4).

**Amendment A4 (validation-package & gate re-mapping — only under the owner's chosen β-i or β-ii):**
- Under **(β-i):** new item **V11 = "MGT external benchmark (Bazarra 2021 P1D, Quintanilla branch)"**: targets = printed analytic exact solution (u, θ) **and** printed Table 1 (same-scheme reproduction of their P1/backward-Euler errors); comparison floor: u and θ profiles at t∈{0.5, 1.0} with rel L∞ + rel L² + peak (plus, for the Table-1 reproduction, pointwise error-table agreement); **no digitization band applies (targets are analytic/printed)**; tolerance PROVISIONAL, to be fixed from measured self-convergence per the standing §4.5 discipline (no pre-chosen pass number). **G3 := { V11 + V5 + V6 }** with V3's frozen failure **recorded as-is** (reported, not masked; PHASE1_V3_REPORT.md stands as the record of the Biot-branch external attempt and its diagnosis). V3's 2% re-fixing (the Blueprint's own mandated Phase 1–3 tolerance-fixing, triggered by its stop-condition #5) remains available as the Biot-branch recovery path — an owner decision independent of A4.
- Under **(β-ii):** V9′ = cross-model cross-check (supporting, non-gating, ≤ tolerance fixed from measured self-convergence, labeled "different MGT formulation — peer-method check"); G3 unchanged (V3 + V5 + V6), with the Biot-branch recovery = the owner's decision on V3's Phase 1–3 tolerance re-fixing (8.4 α).
- **Unchanged under either branch:** V1–V6 definitions and results; JV1–JV6; V5/V6 status; all provisional-tolerance discipline; the "no published target is ever invented or inferred" rule; V3 targets/results (frozen as-is).

**A5 (procedural):** the amendment is a new change record appended to `BLUEPRINT_FREEZE_RECORD.md`-style discipline (version v1.1, dated, with the freeze statement amended); the Blueprint file itself is regenerated ONLY by the owner's explicit instruction.

### 8.4 Owner decision items (this audit stops here)
- **(α)** Biot-branch recovery: re-fix the V3 tolerance/metric from the already-measured Phase-1–3 convergence data (the Blueprint's own mandated mechanism; stop-condition #5; the V3 report's §2/§5 measurements) — and whether the re-fixed criterion can be met given the diagnosed front-band structure. [Owner's criterion decision — NOT made here.]
- **(β)** Adopt C4 via amendment A1–A5, with the scope choice **(β-i) extended** (recommended if the manuscript should carry a *currently-passable* primary external benchmark with analytic targets — P1D is the only such asset found) or **(β-ii) retained** (C4 as honest supporting cross-check; Biot-branch gate stays on the α path).
- **(γ)** If neither α nor β is accepted: stop for owner re-scope decision (no further execution under the frozen gate).

---

## 9. SMALLEST FEASIBILITY REPRODUCTION / PILOT FOR C4 (task item 7 — PROPOSED, NOT EXECUTED)

**Precondition:** owner go-ahead (recommended *after* the A-scope decision, so the pilot's acceptance framing is fixed; a feasibility-labeled run before the decision is also permissible and would change nothing frozen).

**Pilot scope (smallest possible; 1-D; T=1; seconds-to-minutes per run; no cluster):**

| Step | Content | Deliverable |
|---|---|---|
| P0 (done this audit) | SymPy transcription check: printed exact solution ⇢ printed PDEs/BCs/ICs/forces, residual = 0 | §4.4 verification note |
| P1 — **same-scheme reproduction (code-to-code)** | Implement C4's own discrete scheme exactly as printed (§4.1: P1 Lagrange, backward Euler, 5-field state (u,v,θ,e,ξ), all-Dirichlet BCs) in a standalone driver; re-run the **Table 1 grid (or a 4×4 sub-grid: h∈{1/2⁶…1/2⁹}, k∈{2e-3,5e-4,1e-4,2e-4} ≈ their coarser corner)**; compare the reproduced error values against the **printed 6-digit Table 1** | `verification/V11/pilot_table1.py` + JSON (reproduced vs printed, per cell) |
| P2 — **C¹ convergence vs analytic target** | New 5-field first-order state-form driver on the **verified C¹ cubic-Hermite primitives** (reused from `verification/V1/mms_v1.py`; Newmark β=¼,γ=½; 4-pt Gauss — exact for the resulting integrands; direct sparse LU) solving P1D; 3 refinement levels (e.g., NE=256/512/1024 with Δt=2⁻¹¹/2⁻¹²/2⁻¹³, T=1); Richardson; compare u and θ at t=0.5, 1.0 against the **printed analytic exact solution** (L∞, L², peak) | `verification/V11/pilot_c1.py` + JSON (orders, Richardson field, target errors) |
| P3 — **pass/fail framing (feasibility only)** | Expected: P1 table agreement at the ~1e-5–1e-4 level (same scheme, 6-digit printing); P2 measured orders H¹≈3 / L²≈4 (smooth exact data) / time≈2; P2 target error at the coarsest level small, shrinking with refinement. Any deviation → diagnose (like V3's §5), report, do not tune | feasibility verdict + diagnosis, if any |

**Cost estimate:** P1 ≈ 12–77 short runs (≲ minutes total at the sub-grid; the full 77-cell table ≲ 30 min single-core, optional); P2 ≈ 3 runs (≈ 10–60 s each at these sizes, per the V3 run costs at comparable DOFs). Total ≪ 1 h. **No production claim attaches to the pilot** (feasibility label only).

**Explicitly excluded from the pilot:** any run of the Blueprint's LS/MGT model; any V5/V6; any comparison against V3 targets; any tolerance fixing; any manuscript claim.

---

## 10. PROVENANCE OF THIS AUDIT

| Item | Detail |
|---|---|
| Frozen documents read (in full or section-complete) | `Blueprint_Complete_MGT_BFS-FEM.md` (all four parts; K, L, T, U, V; Part II §1–9; Part III §1–8), `BLUEPRINT_FREEZE_RECORD.md`, `PRE_FREEZE_AUDIT.md`, `SOURCE_LOCK_AUDIT.md` (via Part II), `PHASE1_SOURCE_LOCK.md`, `PHASE1_EXECUTION_BASELINE.md`, `PHASE1_DERIVATION_RECORD.md` (§0–4.1), `G1_INDEPENDENT_AUDIT(R2).md` (§1–8), `PHASE1_V3_REPORT.md` (full), `verification/V3/v3_run_manifest.json`, `verification/V3/v3_results.json` (summary) |
| External retrievals (2026-09-26) | Crossref API: DOIs 10.1016/j.cam.2022.114181 (→ Kang & Kim 2022, **unrelated**), 10.1016/j.cam.2020.113058 (→ Bazarra 2021 JCAM 382:113058; "vor" OA license start 2025-01-15), 10.1016/j.cam.2023.115571 (→ Bazarra et al. 2024 JCAM 438, OA), 10.1080/00207160.2025.2519320 (not resolved — paper not needed); ScienceDirect full-text HTML of S0377042720303496 (open archive; 10 chunks: outline, model §2, scheme §3.1, examples §4.1–4.3, Table 1, Figs 1–8); ZAMM 2024 (via search snippets — §6 data: energy decay only); web searches: LS/GN-III/CTE transient FEM benchmarks, Eiras/Oteo MGT FEM, acoustic-MGT benchmarks, Boley–Tolins access, OA LS thermal-shock works |
| Symbolic check executed | SymPy: P1D exact solution vs printed PDEs/BCs/ICs/forces — residual 0 (both PDEs), all BC/IC values exact |
| NOT modified (verified by read-only access) | Blueprint, freeze record, all V3 targets/results/manifests, all PHASE1_* records |
| Files created this audit | `hff/VALIDATION_RECOVERY_AUDIT.md` (this document) only |

**STATUS: AUDIT COMPLETE — DECISION B (primary) + C-overlay (frozen G3 as literally written). Stopping for owner decision on §8.4 (α/β/γ) before any pilot run or amendment.**
