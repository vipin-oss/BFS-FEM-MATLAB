#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
P1D-P1: reproduction of the PUBLISHED numerical scheme for Problem P1D of
  Bazarra, Fernandez & Quintanilla (2021), "Analysis of a Moore-Gibson-Thompson
  thermoelastic problem", J. Comput. Appl. Math. 382:113058,
  DOI 10.1016/j.cam.2020.113058 (open archive; retrieved 2026-09-26, PII S0377042720303496).

Purpose
-------
Feasibility pilot P1 of hff/VALIDATION_RECOVERY_AUDIT.md: establish whether the
published benchmark is computationally reproducible from the information in the
paper.  This script makes NO validation claim and is completely separate from the
V3 (Nikolarakis) benchmark.

Implemented exactly as printed (see table1_published.json for verbatim provenance)
--------------------------------------------------------------------------
* Problem P1D PDEs (Sec 4.2), parameters (rho=1, mu=2 => lambda+2mu=2, beta=1,
  tau=2, c=1, K1=3, K2=1), BCs (Problem P eq.(9): u=theta=0 on Gamma={0,1}),
  ICs (10), forces F1,F2, printed exact solution.
* Discrete problem VPhk (17)-(19), Sec 3: uniform P1 Lagrange spaces (15),
  backward Euler in time, uniform time grid t_n = n k, T=1, N = round(T/k).
* Discrete ICs (16): nodal (classical FE) interpolation for all five fields.
* Metric (Sec 4.2 / Table 1 caption, verbatim):
    E(h,k) = max_{0<=n<=N} { ||v - vh||_L2 + ||(u - uh)_x||_L2
             + ||xi - xih||_L2 + ||(e - eh)_x||_L2 + ||(theta - thetah)_x||_L2 },
  evaluated with per-element 5-point Gauss quadrature (exact for all integrands).
* Forces: P1D = Problem P + F1,F2.  They enter the backward-Euler scheme as
  k*(F1(t^n), w) on the momentum RHS and k*(F2(t^n), z) on the thermal RHS
  (natural BE treatment; the printed scheme (17)-(18) is for homogeneous Problem P).

Variants (documented sensitivities; see p1d_P1_report.md)
---------------------------------------------------------
sign_e = 'plus'  : momentum RHS contains +k*b(w, e^{n-1})  [algebraically implied
                   by the printed (17); the scheme that is backward Euler for P1D]
           'minus': momentum RHS contains -k*b(w, e^{n-1})  [the sign as printed in
                   the Sec 4.1 solved form of (17)-(18)]
load   = 'exact' : force load vectors (F, N_i) by exact per-element Gauss
                   quadrature (3 points; F is a cubic in x, N_i degree 1)
           'Mf'   : force load vectors = M * F(nodes) (consistent nodal projection)
ftime  = 'tn'    : forces evaluated at t^n (default)
           'tnm1' : forces evaluated at t^{n-1}

Scheme (1D uniform P1, n elements, interior DOFs 1..n, v_0=v_{n+1}=xi_0=xi_{n+1}=0):
  A = [[ rho*M + k^2*(lam2mu)*S ,  k*(k+tau)*beta*B ],
       [ beta*B                ,  (c+c*tau)*M + (k*K1 + k^2*K2)*S ]]
  A * [v^n ; xi^n] =
      [ rho*M*v^{n-1} + sE*k*beta*B*e^{n-1} - k*lam2mu*S*u^{n-1} + k*lF1^n ;
        c*tau*M*xi^{n-1} - K2*S*theta^{n-1} - (K1 + k*K2)*S*e^{n-1} + lF2^n ]
  u^n = u^{n-1} + k v^n ;  e^n = e^{n-1} + k xi^n ;  theta^n = theta^{n-1} + k e^n
  where sE = +1 for sign_e='plus', -1 for sign_e='minus'.
  M = (h/6) tridiag(2,4,2);  S = (1/h) tridiag(-1,2,-1);
  (B v)_i = (v_{i+1} - v_{i-1})/h  (skew-symmetric; boundary terms vanish).

Usage
-----
  python3 p1d_scheme.py           # full pilot: 4x4 primary + sensitivity variants
  python3 p1d_scheme.py --quick   # 2 cells only (sanity)
Outputs: results/p1d_results.json, results/table1_4x4_comparison.csv (and prints)
"""
import argparse
import json
import os
import time

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

HERE = os.path.dirname(os.path.abspath(__file__))

# ----------------------------- published data --------------------------------
PARAMS = dict(rho=1.0, lam2mu=2.0, beta=1.0, tau=2.0, c=1.0, K1=3.0, K2=1.0, T=1.0)
# exact solution / derivatives (polynomial-in-x parts; factor exp(t) applied at runtime)
def q_u(x):   return x * (x - 1.0)          # u = v  (since u(x,t)=exp(t)*x(x-1), u_t = same)
def q_ux(x):  return 2.0 * x - 1.0          # u_x
def q_theta(x): return x**3 * (x - 1.0)     # theta = e = xi  (since theta=exp(t)*x^3(x-1))
def q_thetax(x): return 4.0 * x**3 - 3.0 * x**2   # theta_x = e_x
# forces (polynomial-in-x parts; factor exp(t))
def q_F1(x):
    return x * (x - 1.0) - 4.0 + 3.0 * (4.0 * x**3 - 3.0 * x**2)
def q_F2(x):
    return 3.0 * x**3 * (x - 1.0) + (2.0 * x - 1.0) - 4.0 * (12.0 * x**2 - 6.0 * x)

# 5-point Gauss on (-1,1) (exact to degree 9) and 3-point (exact to degree 5)
G5_X = np.array([0.0, 0.5384693101056831, -0.5384693101056831,
                 0.9061798459386640, -0.9061798459386640])
G5_W = np.array([0.5688888888888889, 0.4786286704962234, 0.4786286704962234,
                 0.23692688505618908, 0.23692688505618908])
G3_X = np.array([0.0, 0.7745966692414834, -0.7745966692414834])
G3_W = np.array([0.5555555555555556, 0.4444444444444444, 0.4444444444444444])

# ----------------------------- FE matrices -----------------------------------
# Convention: n_el elements on [0,1] -> n_el+1 nodes x_i=i*h, i=0..n_el;
# interior DOFs = nodes 1..n_el-1 (count m = n_el-1); boundary values = 0 (Dirichlet).
P_BETA = PARAMS['beta']

def build_matrices(n_el):
    """n_el elements -> m = n_el-1 interior DOF matrices."""
    h = 1.0 / n_el
    m = n_el - 1
    M = sp.diags([h / 6, 2 * h / 3, h / 6], [-1, 0, 1], shape=(m, m), format="csr")  # P1 mass: (h/6)[1 2 1]
    S = sp.diags([-1.0 / h, 2.0 / h, -1.0 / h], [-1, 0, 1], shape=(m, m), format="csr")
    # b(w,r) = beta * int w' r  =>  (B r)_j = beta (r_{j-1} - r_{j+1}) / 2  (NO 1/h:
    # one derivative (1/h) times the element length (h) cancels; exact for P1 r).
    B = sp.diags([0.5 * P_BETA, -0.5 * P_BETA], [-1, 1], shape=(m, m), format="csr")
    return h, M, S, B

def gauss_on_elements(n_el, xg, wg):
    """Gauss points/weights on each element (local -> global); (n_el, m) arrays."""
    h = 1.0 / n_el
    el = np.arange(n_el)
    X = (el[:, None] + 0.5 * (xg[None, :] + 1.0)) * h
    W = 0.5 * h * wg[None, :]
    return X, W

def extend_nodes(field_interior):
    """Interior field -> full nodal array with zero Dirichlet boundary nodes."""
    return np.concatenate(([0.0], np.asarray(field_interior), [0.0]))

def force_load_exact(n_el, f_poly, t):
    """Exact (F(t), N_i) load vectors for interior DOFs; F = exp(t)*f_poly (cubic in x).
    3-point Gauss per element: F*N_i is degree <= 4 -> exact."""
    X, W = gauss_on_elements(n_el, G3_X, G3_W)                  # (n_el, m)
    fvals = np.exp(t) * f_poly(X)                               # (n_el, m)
    m = n_el - 1
    ell = np.zeros(m)
    for mi in range(len(G3_X)):
        w = W[:, mi] * fvals[:, mi]                             # (n_el,)
        # element e: left node e (interior DOF e-1 if e>=1), right node e+1 (DOF e if e+1<=n_el-1)
        ell += w[:-1]    # right-node contributions: DOF e, e=0..n_el-2
        ell += w[1:]     # left-node contributions:  DOF e-1, e=1..n_el-1
    return ell

# ----------------------------- solver ----------------------------------------
def solve_one(n_el, k, sign_e="plus", load="exact", ftime="tn"):
    """Run the published scheme for P1D on h=1/n_el, step k. Returns dict with E(h,k)."""
    P = PARAMS
    rho, lam2mu, beta, tau, c = P["rho"], P["lam2mu"], P["beta"], P["tau"], P["c"]
    K1, K2, T = P["K1"], P["K2"], P["T"]
    N = int(round(T / k))

    h, M, S, B = build_matrices(n_el)
    m = n_el - 1
    # block system (time-constant) -> factorize once
    A11 = rho * M + (k**2) * lam2mu * S
    A12 = k * (k + tau) * B
    A21 = B
    A22 = (c + c * tau) * M + (k * K1 + k**2 * K2) * S
    A = sp.block_array([[A11, A12], [A21, A22]]).tocsr()
    lu = spla.splu(A.tocsc())

    # 5-pt Gauss machinery for the metric
    X5, W5 = gauss_on_elements(n_el, G5_X, G5_W)
    s_local = 0.5 * (G5_X + 1.0)                                 # in [0,1]
    # polynomial parts at Gauss points (x-dependent), per element:
    qU = q_u(X5); qUX = q_ux(X5); qT = q_theta(X5); qTX = q_thetax(X5)
    # N0,N1 at Gauss points: (n_el, m)
    N0 = 1.0 - s_local[None, :]; N1 = s_local[None, :]

    # nodal interpolation of initial data (printed (16): P1h/P2h classical FE interpolation)
    xnodes = np.linspace(0.0, 1.0, n_el + 1)
    u = q_u(xnodes[1:-1]).copy()
    v = q_u(xnodes[1:-1]).copy()          # v0 = u0 = x(x-1)
    theta = q_theta(xnodes[1:-1]).copy()
    e = q_theta(xnodes[1:-1]).copy()      # e0 = xi0 = theta0
    xi = q_theta(xnodes[1:-1]).copy()

    # metric (printed Table 1 definition): SUM of the five L2 NORMS (each = sqrt of integral),
    # per-element 5-pt Gauss (exact for all integrands)
    def metric_at(u, v, theta, e, xi, t):
        et = np.exp(t)
        un = extend_nodes(u); vn = extend_nodes(v)
        thn = extend_nodes(theta); en = extend_nodes(e); xin = extend_nodes(xi)
        vh = N0 * vn[:-1][:, None] + N1 * vn[1:][:, None]
        d = et * qU - vh
        tot = float(np.sqrt(np.sum(W5 * d * d)))                          # ||v - vh||
        duh = (un[1:] - un[:-1]) / h
        d = et * qUX - duh[:, None]
        tot += float(np.sqrt(np.sum(W5 * d * d)))                         # ||(u-uh)_x||
        xih = N0 * xin[:-1][:, None] + N1 * xin[1:][:, None]
        d = et * qT - xih
        tot += float(np.sqrt(np.sum(W5 * d * d)))                         # ||xi - xih||
        deh = (en[1:] - en[:-1]) / h
        d = et * qTX - deh[:, None]
        tot += float(np.sqrt(np.sum(W5 * d * d)))                         # ||(e-eh)_x||
        dth = (thn[1:] - thn[:-1]) / h
        d = et * qTX - dth[:, None]
        tot += float(np.sqrt(np.sum(W5 * d * d)))                         # ||(theta-thetah)_x||
        return tot

    Emax = metric_at(u, v, theta, e, xi, 0.0)      # n = 0 (included: max over 0<=n<=N)
    nmax = 0

    sE = 1.0 if sign_e == "plus" else -1.0
    t = 0.0
    for nstep in range(1, N + 1):
        t = nstep * k
        tf = t if ftime == "tn" else (nstep - 1) * k
        if load == "exact":
            lF1 = force_load_exact(n_el, q_F1, tf)
            lF2 = force_load_exact(n_el, q_F2, tf)
        else:  # 'Mf'
            lF1 = M @ (np.exp(tf) * q_F1(xnodes[1:-1]))
            lF2 = M @ (np.exp(tf) * q_F2(xnodes[1:-1]))

        rhs1 = rho * M @ v + sE * k * (B @ e) - k * lam2mu * (S @ u) + k * lF1
        rhs2 = c * tau * M @ xi - K2 * (S @ theta) - (K1 + k * K2) * (S @ e) + lF2
        sol = lu.solve(np.concatenate([rhs1, rhs2]))
        vn = sol[:m]; xinn = sol[m:]

        u = u + k * vn
        e = e + k * xinn
        theta = theta + k * e
        v = vn; xi = xinn

        E = metric_at(u, v, theta, e, xi, t)
        if E > Emax:
            Emax = E; nmax = nstep

    return dict(h=1.0 / n_el, k=k, N=N, E=Emax, n_at_max=nmax)

# ----------------------------- comparison ------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    args = ap.parse_args()

    with open(os.path.join(HERE, "table1_published.json")) as f:
        pub = json.load(f)
    subset = pub["subset_4x4_for_pilot"]["cells"]

    os.makedirs(os.path.join(HERE, "results"), exist_ok=True)

    runs = []

    if args.quick:
        cells = [("h=1/128", 128, "0.001"), ("h=1/512", 512, "0.0002")]
    else:
        cells = [(hk, n, kk) for hk, n in
                 [("h=1/64", 64), ("h=1/128", 128), ("h=1/256", 256), ("h=1/512", 512)]
                 for kk in ["0.002", "0.001", "0.0005", "0.0002"]]

    # primary: printed (17)-(18) with the algebraically-correct sign (sign_e='plus'),
    # exact force quadrature, forces at t^n
    for hk, n, kk in cells:
        k = float(kk)
        t0 = time.time()
        r = solve_one(n, k, sign_e="plus", load="exact", ftime="tn")
        r["variant"] = "primary (printed (17)-(18); +k b(w,e^{n-1}); exact force quadrature; F(t^n))"
        r["wall_s"] = round(time.time() - t0, 3)
        r["published"] = subset[hk][kk]
        r["abs_err"] = r["E"] - r["published"]
        r["rel_err"] = r["abs_err"] / r["published"]
        runs.append(r)
        print(f"[primary] {hk} k={kk}: E={r['E']:.9f}  published={r['published']:.6f}  "
              f"abs={r['abs_err']:+.3e} rel={r['rel_err']:+.3e}  ({r['wall_s']} s)")

    if not args.quick:
        # ---- sensitivity variants (2 cells each) ----
        sens_cells = [("h=1/128", 128, "0.001"), ("h=1/512", 512, "0.0002")]
        variants = [
            ("asprinted_sec41 (sign_e='minus')", dict(sign_e="minus", load="exact", ftime="tn")),
            ("nodal force load (load='Mf')", dict(sign_e="plus", load="Mf", ftime="tn")),
            ("forces at t^{n-1} (ftime='tnm1')", dict(sign_e="plus", load="exact", ftime="tnm1")),
        ]
        for label, kw in variants:
            for hk, n, kk in sens_cells:
                k = float(kk)
                r = solve_one(n, k, **kw)
                r["variant"] = label
                r["published"] = subset[hk][kk]
                r["abs_err"] = r["E"] - r["published"]
                r["rel_err"] = r["abs_err"] / r["published"]
                r["cell"] = f"{hk} k={kk}"
                runs.append(r)
                print(f"[{label}] {hk} k={kk}: E={r['E']:.9f} published={r['published']:.6f} "
                      f"abs={r['abs_err']:+.3e} rel={r['rel_err']:+.3e}")

    # ---- convergence-ratio diagnostics on the primary column (k=0.0002) ----
    col = [r for r in runs if r["variant"].startswith("primary") and abs(r["k"] - 0.0002) < 1e-15]
    col.sort(key=lambda r: -r["h"])
    ratios = []
    for a, b in zip(col, col[1:]):
        ratios.append(b["E"] / a["E"])
    print("\nHalving ratios of primary E(h, k=0.0002):", [f"{x:.5f}" for x in ratios])

    # ---- write outputs ----
    results = {
        "task": "P1D-P1 published-scheme reproduction (feasibility pilot; no validation claim)",
        "source": pub["provenance"]["source"],
        "primary_variant": runs[0]["variant"],
        "runs": runs,
        "halving_ratios_primary_k_2e-4": ratios,
    }
    outjson = os.path.join(HERE, "results", "p1d_results.json")
    with open(outjson, "w") as f:
        json.dump(results, f, indent=2)

    csv = os.path.join(HERE, "results", "table1_4x4_comparison.csv")
    prim = {f"{r['h']}|{r['k']}": r for r in runs if r["variant"].startswith("primary")}
    if args.quick:
        print(f"\nwrote {outjson} (quick mode: no 4x4 CSV)")
        return
    with open(csv, "w") as f:
        f.write("h,k,published,reproduced,abs_err,rel_err,n_at_max,wall_s\n")
        for hk, n in [("h=1/64", 64), ("h=1/128", 128), ("h=1/256", 256), ("h=1/512", 512)]:
            for kk in ["0.002", "0.001", "0.0005", "0.0002"]:
                r = prim[f"{1.0/n}|{float(kk)}"]
                f.write(f"{1.0/n:.6g},{float(kk):.6g},{r['published']:.6f},{r['E']:.9f},"
                        f"{r['abs_err']:+.6e},{r['rel_err']:+.6e},{r['n_at_max']},{r['wall_s']}\n")
    print(f"\nwrote {outjson}\nwrote {csv}")

if __name__ == "__main__":
    main()
